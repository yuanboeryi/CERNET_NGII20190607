## EasyConfigIR
---
a easy tool for configuration of IR.

[>>> 前往下载](https://king-1025.lanzous.com/igPKif3j0xa "最新版本v0.1.0")