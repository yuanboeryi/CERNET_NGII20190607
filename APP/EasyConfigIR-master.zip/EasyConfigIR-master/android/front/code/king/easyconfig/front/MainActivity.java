package king.easyconfig.front;

import androidx.annotation.NonNull;
import androidx.multidex.BuildConfig;

import android.Manifest;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.List;

import king.easyconfigir.front.R;

import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.activity.EasyConfigIRActivity;

public class MainActivity extends EasyConfigIRActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showIRSettingFragment();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (BuildConfig.DEBUG) {
            int id = item.getItemId();
            switch (id) {
                case R.id.ir_setting_fragment:
                    showIRSettingFragment();
                    break;
                case R.id.preset_edit_fragment:
                    showPresetEditFragment();
                    break;
                default:
                    break;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (BuildConfig.DEBUG) {
            getMenuInflater().inflate(R.menu.main_menu, menu);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (BuildConfig.DEBUG) {
            LogTool.i(this, "main activity is show!");
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
//        requestCodeQRCodePermissions();
    }

//    @Override
//    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
//        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults);
//    }

//    @Override
//    public void onPermissionsGranted(int requestCode, List<String> perms) {
//    }
//
//    @Override
//    public void onPermissionsDenied(int requestCode, List<String> perms) {
//    }

//    private static final int REQUEST_CODE_QRCODE_PERMISSIONS = 1;
//
//    @AfterPermissionGranted(REQUEST_CODE_QRCODE_PERMISSIONS)
//    private void requestCodeQRCodePermissions() {
//        String[] perms = {Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE};
//        if (!EasyPermissions.hasPermissions(this, perms)) {
//            EasyPermissions.requestPermissions(this, "扫描二维码需要打开相机和散光灯的权限", REQUEST_CODE_QRCODE_PERMISSIONS, perms);
//        }
//    }

}