package king.easyconfigir.support.activity;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.Objects;

import king.easyconfigir.support.R;
import king.easyconfigir.support.fragment.BaseFragment;

public class BaseActivity extends AppCompatActivity {
    private ArrayList<BaseFragment> listFragment;
    private int layoutId;
    private boolean isHideDefaultActionBar;

    public BaseActivity() {
        this(true);
    }

    public BaseActivity(boolean isHideDefaultActionBar) {
        this.layoutId = R.layout.ui;
        this.isHideDefaultActionBar = isHideDefaultActionBar;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layoutId);
        if (isHideDefaultActionBar) {
            Objects.requireNonNull(getSupportActionBar()).hide();
        }
        listFragment = new ArrayList<>();
        onLoad();
    }

    protected void onLoad() {
        // TODO do something
    }

    protected void showFragmentByTitle(String title) {
        FragmentTransaction ft = getFragmentTransaction();
        for (BaseFragment fragment : listFragment) {
            if (fragment.getTitle().equals(title)) {
                ft.show(fragment);
            } else {
                ft.hide(fragment);
            }
        }
        ft.commit();
    }

    protected void hideAllFragments() {
        FragmentTransaction ft = getFragmentTransaction();
        for (BaseFragment fragment : listFragment) {
            ft.hide(fragment);
        }
        ft.commit();
    }

    protected void addFragment(BaseFragment baseFragment) {
        listFragment.add(baseFragment);
        getFragmentTransaction().add(R.id.ui_container, baseFragment).hide(baseFragment).commit();
    }

    protected void removeFragment(BaseFragment baseFragment) {
        listFragment.remove(baseFragment);
        getFragmentTransaction().remove(baseFragment).commit();
    }

    private FragmentTransaction getFragmentTransaction() {
        return getSupportFragmentManager().beginTransaction();
    }

    protected Context getContext() {
        return this.getApplicationContext();
    }
}
