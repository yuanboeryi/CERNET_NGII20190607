package king.easyconfigir.support.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;

import java.util.Objects;

import king.easyconfigir.support.fragment.IRSettingsFragment;
import king.easyconfigir.support.fragment.PresetEditFragment;
import king.easyconfigir.support.fragment.PresetManageFragment;
import king.easyconfigir.support.model.PresetPoint;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.ToastTool;

public class EasyConfigIRActivity extends BaseActivity implements PresetManageFragment.PresetPointEvent {

    private IRSettingsFragment irSettingsFragment;
    private PresetEditFragment presetEditFragment;

    private final static int REQUEST_CODE_QR_SCAN = 0x1;

    @Override
    protected void onLoad() {
        super.onLoad();
        initIRSettingsFragment();
        initPresetEditFragment();
    }

    private void initIRSettingsFragment() {
        irSettingsFragment = IRSettingsFragment.getInstance("ir_settings");
        irSettingsFragment.setIRSettingsEvent(this::startQRScanActivity);
        addFragment(irSettingsFragment);
    }

    private void initPresetEditFragment() {
        presetEditFragment = PresetEditFragment.getInstance("preset_edit");
        presetEditFragment.setOnPresetEditEvent(this::showIRSettingFragment);
        addFragment(presetEditFragment);
    }

    protected void showIRSettingFragment() {
        showFragmentByTitle(irSettingsFragment.getTitle());
    }

    protected void showPresetEditFragment() {
        showFragmentByTitle(presetEditFragment.getTitle());
    }

    @Override
    public void onRequestPresetPointEdit(PresetPoint presetPoint, int position) {
        showPresetEditFragment();
    }

    protected void startQRScanActivity() {
        Intent intent = new Intent(this, QRScanActivity.class);
        startActivityForResult(intent, REQUEST_CODE_QR_SCAN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        ToastTool.i(getContext(), "onActivityResult called " + requestCode + " " + resultCode);
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE_QR_SCAN) {
            Bundle bundle = Objects.requireNonNull(data).getExtras();
            assert bundle != null;
            updateDeviceCodeByQR(bundle);
            updateDeviceMacByQR(bundle);
        }
    }

    private void updateDeviceCodeByQR(Bundle data) {
        String code = data.getString("device_code", null);
        if (code != null) {
            irSettingsFragment.setDeviceId(code);
            LogTool.i(this, "device_code: " + code);
//            ToastTool.i(getContext(), "device_code: " + code);
        }
    }

    private void updateDeviceMacByQR(Bundle data) {
        String mac = data.getString("device_mac", null);
        if (mac != null) {
            irSettingsFragment.setDeviceMac(mac);
            LogTool.i(this, "device_mac: " + mac);
//            ToastTool.i(getContext(), "device_mac: " + mac);
        }
    }

}