package king.easyconfigir.support.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import king.easyconfigir.support.fragment.QRScanFragment;
import king.easyconfigir.support.model.ScanResult;
import king.easyconfigir.support.tool.ToastTool;

public class QRScanActivity extends BaseActivity {
    private QRScanFragment qrScanFragment;
    private Bundle scanData;

    @Override
    protected void onLoad() {
        super.onLoad();
        initQRScanFragment();
        showQRScanFragment();
    }

    private void initQRScanFragment() {
        scanData = new Bundle();
        qrScanFragment = QRScanFragment.getInstance("qr_scan");
        qrScanFragment.setQRScanEvent(new QRScanFragment.QRScanEvent() {

            @Override
            public boolean onQRScanSuccess(ScanResult result) {
                ScanResult.Type type = result.getType();
                Bundle data = result.getData();
                switch (type) {
                    case DEVICE_CODE:
                    case DEVICE_MAC:
                    case DEVICE_CODE_AND_MAC:
                        scanData.putAll(data);
                        break;
                    default:
                        break;
                }
                ToastTool.i(getContext(), "扫描到" + type.getName());
                return true;
            }

            @Override
            public void onQRScanFailed() {

            }

            @Override
            public void onRequestFragmentBack() {
                backToEasyConfigIRActivity();
            }

        });
        addFragment(qrScanFragment);
    }

    @Override
    public void onBackPressed() {
        backToEasyConfigIRActivity();
    }

    protected void showQRScanFragment() {
        showFragmentByTitle(qrScanFragment.getTitle());
    }

    private void backToEasyConfigIRActivity() {
        Intent intent = new Intent();
        intent.putExtras(scanData);
        setResult(Activity.RESULT_OK, intent);
        finish();
    }

}
