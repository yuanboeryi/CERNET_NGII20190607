package king.easyconfigir.support.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import king.easyconfigir.support.model.Device;
import king.easyconfigir.support.tool.LogTool;

public class BaseAdapter<T> extends android.widget.BaseAdapter {
    private List<T> data;
    private Context context;
    private int resid;
    private int dropDownResId;
    private int position;
    protected boolean TILL_CREATE_VIEW = false;

    public BaseAdapter(Context context, List<T> data, int resid) {
        this(context, data, resid, resid);
    }

    public BaseAdapter(Context context, List<T> data, int resid, int dropDownResId) {
        this.data = data;
        this.context = context;
        this.resid = resid;
        this.dropDownResId = dropDownResId;
    }

    public List<T> getData() {
        return data;
    }

    public Context getContext() {
        return context;
    }

    public int getResid() {
        return resid;
    }

    public int getDropDownResId() {
        return dropDownResId;
    }

    protected int getPosition() {
        return this.position;
    }

    protected int getResColor(int id) {
        return context.getResources().getColor(id);
    }

    protected String getResString(int id) {
        return context.getResources().getString(id);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return data.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
//        LogTool.i("LogTool", "TIIL_CREATE_VIEW: "+TILL_CREATE_VIEW);
        if (view == null || TILL_CREATE_VIEW) {
            view = LayoutInflater.from(context).inflate(resid, null);
        }
        this.position = i;
        onCreateView(view, data.get(i), i + 1);
        return view;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(dropDownResId, null);
        }
        this.position = position;
        onCreateDropDownView(convertView, data.get(position));
        return convertView;
    }

    protected void onCreateDropDownView(View view, T obj) {

    }

    protected void onCreateView(View view, T obj) {

    }

    protected void onCreateView(View view, T obj, int position) {
        onCreateView(view, obj);
    }
}
