package king.easyconfigir.support.adapter;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.LinearLayout;


import java.util.List;

import king.easyconfigir.support.R;
import king.easyconfigir.support.model.Device;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.widget.LineTagLayout;
import king.easyconfigir.support.widget.SwitchLayout;

public class DeviceAdapter extends BaseAdapter<Device> {

    private onViewEvent onViewEvent;

    public interface onViewEvent {
        void onViewLongClick(int position);
    }

    public void setOnViewEvent(DeviceAdapter.onViewEvent onViewEvent) {
        this.onViewEvent = onViewEvent;
    }

    public DeviceAdapter(Context context, List<Device> data) {
        super(context, data, R.layout.preset_edit_item_layout);
    }

    @Override
    protected void onCreateView(View view, Device obj, int position) {
        final ViewHolder vh;
        if (view.getTag() instanceof ViewHolder) {
            vh = (ViewHolder) view.getTag();
        } else {
            vh = new ViewHolder(view);
            view.setTag(vh);
        }
        vh.update(obj, position);
        view.setOnLongClickListener(v -> {
            if (onViewEvent != null) {
                onViewEvent.onViewLongClick(position); // position 比数据索引大1
            }
            return false;
        });
    }

    private static class ViewHolder {
        private LineTagLayout ltlName;
        private LineTagLayout ltlMac;
        private LineTagLayout ltlWarnTemp;
        private LineTagLayout ltlDistance;
        private SwitchLayout ltlLookupPoint;
        private SwitchLayout ltlTrack;

        public ViewHolder(View view) {
            ltlName = view.findViewById(R.id.peil_lineTag_name);
            ltlMac = view.findViewById(R.id.peil_lineTag_mac);
            ltlWarnTemp = view.findViewById(R.id.peil_lineTag_warnTemp);
            ltlDistance = view.findViewById(R.id.peil_lineTag_distance);
            ltlLookupPoint = view.findViewById(R.id.peil_switch_lookup_point);
            ltlTrack = view.findViewById(R.id.peil_switch_track);
        }

        public void update(Device device, int position) {
            maybeClearListener();

            ltlName.setLeftText(device.getTag() + position);
            ltlName.setInputText(device.getName());

            ltlMac.setInputText(device.getMac());

            ltlWarnTemp.setInputText(device.getWarnTemperature());
            ltlDistance.setInputText(device.getDistance());

            ltlLookupPoint.setFlag(device.isLookPoint());
            ltlTrack.setFlag(device.isTrack());

            updateListener(device, position);
//            LogTool.i("LogTool", "ViewHolder update oK!");
        }

        private void maybeClearListener() {
            ltlName.maybeClearInputTextChangedListener();
            ltlMac.maybeClearInputTextChangedListener();
            ltlWarnTemp.maybeClearInputTextChangedListener();
            ltlDistance.maybeClearInputTextChangedListener();

            ltlLookupPoint.maybeClearOnFlagEventListener();
            ltlTrack.maybeClearOnFlagEventListener();
        }

        private void updateListener(Device device, int positon) {
            ltlName.setInputTextChangedListener(new DeviceListener(device, positon, DeviceListener.DEV_TYPE_NAME));
            ltlMac.setInputTextChangedListener(new DeviceListener(device, positon, DeviceListener.DEV_TYPE_MAC));

            ltlWarnTemp.setInputTextChangedListener(new DeviceListener(device, positon, DeviceListener.DEV_TYPE_WARN_TEMP));
            ltlDistance.setInputTextChangedListener(new DeviceListener(device, positon, DeviceListener.DEV_TYPE_DISTANCE));

            ltlLookupPoint.setOnFlagEvent(new DeviceListener(device, positon, DeviceListener.DEV_TYPE_LOOKUP_POINT));
            ltlTrack.setOnFlagEvent(new DeviceListener(device, positon, DeviceListener.DEV_TYPE_TRACK));
        }
    }

    private static class DeviceListener implements TextWatcher, SwitchLayout.OnFlagEvent {

        private Device device;
        private int positon;
        private int type;
        public final static int DEV_TYPE_NAME = 0x0;
        public final static int DEV_TYPE_MAC = 0x1;
        public final static int DEV_TYPE_WARN_TEMP = 0x2;
        public final static int DEV_TYPE_DISTANCE = 0x3;
        public final static int DEV_TYPE_LOOKUP_POINT = 0x4;
        public final static int DEV_TYPE_TRACK = 0x5;

        public DeviceListener(Device device, int positon, int type) {
            this.device = device;
            this.positon = positon;
            this.type = type;
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            String value = "";
            if (editable != null) {
                value = editable.toString();
            }
            LogTool.i("afterTextChanged", "position: " + positon);
            switch (type) {
                case DEV_TYPE_NAME:
                    device.setName(value);
                    LogTool.i("afterTextChanged", "name: " + value);
                    break;
                case DEV_TYPE_MAC:
                    device.setMac(value);
                    LogTool.i("afterTextChanged", "mac: " + value);
                    break;
                case DEV_TYPE_WARN_TEMP:
                    device.setWarnTemperature(value);
                    LogTool.i("afterTextChanged", "warn_temp: " + value);
                    break;
                case DEV_TYPE_DISTANCE:
                    device.setDistance(value);
                    LogTool.i("afterTextChanged", "distance: " + value);
                    break;
                default:
                    break;
            }
        }

        @Override
        public void onChanged(boolean flag) {
            LogTool.i("onChanged", "position: " + positon);
            switch (type) {
                case DEV_TYPE_LOOKUP_POINT:
                    device.setLookPoint(flag);
                    LogTool.i("onChanged", "lookup point flag: " + flag);
                    break;
                case DEV_TYPE_TRACK:
                    device.setTrack(flag);
                    LogTool.i("onChanged", "track flag: " + flag);
                    break;
                default:
                    break;
            }
        }
    }
}
