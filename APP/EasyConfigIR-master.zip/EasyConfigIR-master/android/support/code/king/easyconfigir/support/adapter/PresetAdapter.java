package king.easyconfigir.support.adapter;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

import king.easyconfigir.support.R;
import king.easyconfigir.support.model.PresetPoint;

public class PresetAdapter extends BaseAdapter<PresetPoint> {

    private TextView title;
    private Button btLeft;
    private Button btRight;

    private PresetAdapterEvent presetAdapterEvent;

    public interface PresetAdapterEvent {
        void onLeftClick(PresetPoint presetPoint, int position);

        void onRightClick(PresetPoint presetPoint, int position);
    }

    public void setPresetAdapterEvent(PresetAdapterEvent presetAdapterEvent) {
        this.presetAdapterEvent = presetAdapterEvent;
    }

    public PresetAdapter(Context context, List<PresetPoint> data) {
        super(context, data, R.layout.preset_item_layout);
    }

    @Override
    protected void onCreateView(View view, PresetPoint presetPoint, int position) {
        title = view.findViewById(R.id.pil_text);
        btLeft = view.findViewById(R.id.pil_left);
        btRight = view.findViewById(R.id.pil_right);
        title.setText(presetPoint.getName());

        if (presetPoint.isAdd()) {
            btLeft.setBackgroundResource(R.drawable.bg_play_button);
        } else {
            btLeft.setBackgroundResource(R.drawable.bg_add_button);
        }

        btLeft.setOnClickListener(e -> {
            if (presetAdapterEvent != null) {
                presetAdapterEvent.onLeftClick(presetPoint, position);
            }
        });

        btRight.setOnClickListener(e -> {
            if (presetAdapterEvent != null) {
                presetAdapterEvent.onRightClick(presetPoint, position);
            }
        });
    }

}
