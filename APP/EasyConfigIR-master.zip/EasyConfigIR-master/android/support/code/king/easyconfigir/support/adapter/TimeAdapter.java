package king.easyconfigir.support.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import java.util.List;

import king.easyconfigir.support.R;
import king.easyconfigir.support.model.TimeEntity;

public class TimeAdapter extends BaseAdapter<TimeEntity> {
    private View hasTouchedView;

    public TimeAdapter(Context context, List<TimeEntity> data) {
        super(context, data, R.layout.time_item_layout);
    }

    @Override
    protected void onCreateView(View view, TimeEntity timeEntity) {
        TextView tv = view.findViewById(R.id.ti_text);
        tv.setText(timeEntity.getName());
    }

    @Override
    protected void onCreateDropDownView(View view, TimeEntity timeEntity) {
        view.setOnTouchListener(this::onTouch);
        view.setBackgroundColor(Color.WHITE);
        TextView tv = view.findViewById(R.id.ti_text);
        tv.setText(String.format("%s min", timeEntity.getName()));
        tv.setTextColor(getResColor(R.color.colorPrimaryDark));
    }

    private boolean onTouch(View view, MotionEvent motionEvent) {
        if (hasTouchedView != null) {
            hasTouchedView.setBackgroundColor(Color.WHITE);
            TextView tv = hasTouchedView.findViewById(R.id.ti_text);
            tv.setTextColor(getResColor(R.color.colorPrimaryDark));
        }
        view.setBackgroundColor(getResColor(R.color.colorPrimaryDark));
        TextView tv = view.findViewById(R.id.ti_text);
        tv.setTextColor(Color.WHITE);
        hasTouchedView = view;
        return false;
    }
}
