package king.easyconfigir.support.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.util.Objects;

import king.easyconfigir.support.R;
import king.easyconfigir.support.widget.ActionBar;

public class BaseFragment extends Fragment {
    private ActionBar actionBar;

    private String title;
    private int layoutId;
    private boolean hasActionBar;
    private int actionBarId;
    private int actionBarTitleId;
    private boolean hasActionBarMenu;
    private int actionBarMenuId;

    private boolean hasNavigationBack;

    public BaseFragment(String title, int layoutId) {
        this(title, layoutId, false, 0, 0, false, 0, false);
    }

    public BaseFragment(String title, int layoutId, int actionBarId, int actionBarTitleId) {
        this(title, layoutId, true, actionBarId, actionBarTitleId, false, 0, false);
    }

    public BaseFragment(String title, int layoutId, int actionBarId, int actionBarTitleId, int actionBarMenuId) {
        this(title, layoutId, true, actionBarId, actionBarTitleId, true, actionBarMenuId, false);
    }

    public BaseFragment(String title, int layoutId, int actionBarId, int actionBarTitleId, int actionBarMenuId, boolean hasNavigationBack) {
        this(title, layoutId, true, actionBarId, actionBarTitleId, true, actionBarMenuId, hasNavigationBack);
    }

    public BaseFragment(String title, int layoutId, boolean hasActionBar, int actionBarId, int actionBarTitleId, boolean hasActionBarMenu, int actionBarMenuId, boolean hasNavigationBack) {
        this.title = title;
        this.layoutId = layoutId;
        this.hasActionBar = hasActionBar;
        this.actionBarId = actionBarId;
        this.actionBarTitleId = actionBarTitleId;
        this.hasActionBarMenu = hasActionBarMenu;
        this.actionBarMenuId = actionBarMenuId;
        this.hasNavigationBack = hasNavigationBack;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(layoutId, container, false);
        if (hasActionBar) {
            initActionBar(view);
        }
        onLoadView(view);
        return view;
    }

    private void initActionBar(View view) {
        actionBar = view.findViewById(actionBarId);
        actionBar.setTitle(actionBarTitleId);
        if (hasActionBarMenu) {
            actionBar.inflateMenu(actionBarMenuId);
            actionBar.setOnMenuItemClickListener(this::onActionBarMenuItemClick);
        }
        if (hasNavigationBack) {
            actionBar.setNavigationIcon(R.drawable.ic_action_backspace);
            actionBar.setNavigationOnClickListener(e -> {
                onNavigationBack();
            });
        }
        onActionBarLoad(actionBar);
    }

    protected void onActionBarLoad(ActionBar actionBar) {

    }

    protected void onNavigationBack() {

    }

    protected boolean onActionBarMenuItemClick(MenuItem item) {
        return false;
    }

    protected void onLoadView(View view) {

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    protected int getResColor(int resid) {
        return ContextCompat.getColor(Objects.requireNonNull(getContext()), resid);
    }

    protected String getResString(int resid) {
        return getResources().getString(resid);
    }

}
