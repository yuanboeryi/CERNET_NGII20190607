package king.easyconfigir.support.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;

import king.easyconfigir.support.R;
import king.easyconfigir.support.model.ApiResultWrapper;
import king.easyconfigir.support.network.Api;
import king.easyconfigir.support.network.ApiManager;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.TextTool;
import king.easyconfigir.support.tool.ToastTool;
import king.easyconfigir.support.widget.CaptureLayout;
import king.easyconfigir.support.widget.DoubleLayout;
import king.easyconfigir.support.widget.FusionLayout;
import king.easyconfigir.support.widget.LineLayout;

@SuppressLint("ValidFragment")
public class DeviceManageFragment extends BaseFragment implements ApiManager.ApiEventListener {

    private DoubleLayout updateWifiLayout;
    private LineLayout cloudAddressLayout;
    private LineLayout emissivityLayout;
    private CaptureLayout captureLayout;
    private FusionLayout fusionLayout;

    public static DeviceManageFragment getInstance(String title) {
        return new DeviceManageFragment(title);
    }

    private DeviceManageFragment(String title) {
        super(title, R.layout.device_manage_layout);
        ApiManager.instance().addApiEventListener(this);
    }

    @Override
    protected void onLoadView(View view) {
        super.onLoadView(view);
        initUpdateWifiLayout(view);
        initCloudAddressLayout(view);
        initEmissivityLayout(view);
        initCaptureLayout(view);
        initFusionLayout(view);
    }

    private void initUpdateWifiLayout(View view) {
        this.updateWifiLayout = view.findViewById(R.id.dml_wifi_update);
        this.updateWifiLayout.setClickListener(e -> {
            String[] vv = this.updateWifiLayout.getDoubleInputValue();
            String ssid = vv[0];
            String password = vv[1];
            if (!TextTool.checkNull(ssid)) {
                if (!TextTool.checkNull(password)) {
                    if (ApiManager.instance().checkDeviceInfo()) {
                        ApiManager.instance().updateWifi(ssid, password);
                        LogTool.i(this, "ssid: " + ssid + " password: " + password);
                    } else {
                        ToastTool.i(getContext(), "设备编号和MAC不能为空");
                    }
                } else {
                    ToastTool.i(getContext(), "Wifi密码不能为空");
                }
            } else {
                ToastTool.i(getContext(), "Wifi名称不能为空");
            }
        });
    }

    private void initCloudAddressLayout(View view) {
        this.cloudAddressLayout = view.findViewById(R.id.dml_cloud_address);
        this.cloudAddressLayout.setClickListener(e -> {
            String address = this.cloudAddressLayout.getInputValue();
            if (!TextTool.checkNull(address)) {
                if (TextTool.isValidIP(address)) {
                    if (ApiManager.instance().checkDeviceInfo()) {
                        ApiManager.instance().updateCloudAddress(address);
                    } else {
                        ToastTool.i(getContext(), "设备编号和MAC不能为空");
                    }
                } else {
                    ToastTool.i(getContext(), "服务器地址无效");
                }
            } else {
                ToastTool.i(getContext(), "服务器地址不能为空");
            }
        });
    }

    private void initEmissivityLayout(View view) {
        this.emissivityLayout = view.findViewById(R.id.dml_emissivity);
        this.emissivityLayout.setClickListener(e -> {
            String value = this.emissivityLayout.getInputValue();
            if (!TextTool.checkNull(value)) {
                if (TextTool.isValidFloatRange(value, 0, 1.0, TextTool.LEFT_OPEN_RIGHT_CLOSE)) {
                    if (ApiManager.instance().checkDeviceInfo()) {
                        ApiManager.instance().updateEmissivity(value);
                    } else {
                        ToastTool.i(getContext(), "设备编号和MAC不能为空");
                    }
                } else {
                    ToastTool.i(getContext(), "辐射率无效");
                }
            } else {
                ToastTool.i(getContext(), "辐射率不能为空");
            }
        });
    }

    private void initCaptureLayout(View view) {
        this.captureLayout = view.findViewById(R.id.dml_capture);
        this.captureLayout.setClickListener(e -> {
            String[] vv = this.captureLayout.getSelectValue();
            String inspection = vv[0];
            String shootingCycle = vv[1];
            if (ApiManager.instance().checkDeviceInfo()) {
                ApiManager.instance().updateCapture(inspection, shootingCycle);
            } else {
                ToastTool.i(getContext(), "设备编号和MAC不能为空");
            }
        });
    }

    private void initFusionLayout(View view) {
        this.fusionLayout = view.findViewById(R.id.dml_fusion);
        this.fusionLayout.setClickListener(e -> {
            String[] vv = this.fusionLayout.getFusionValue();
            String S = vv[0];
            String R = vv[1];
            String L = vv[2];
            String T = vv[3];
            if (TextTool.isValidFloatRange(S, 0, 10, TextTool.ALL_CLOSE)) {
                if (TextTool.isValidFloatRange(R, -180, 180, TextTool.ALL_CLOSE)) {
                    if (TextTool.isValidIntegerRange(L, -320, 320, TextTool.ALL_CLOSE)) {
                        if (TextTool.isValidIntegerRange(T, -240, 240, TextTool.ALL_CLOSE)) {
                            if (ApiManager.instance().checkDeviceInfo()) {
                                ApiManager.instance().updateFusion(S, R, L, T);
                            } else {
                                ToastTool.i(getContext(), "设备编号和MAC不能为空");
                            }
                        } else {
                            ToastTool.i(getContext(), "T值无效，有效范围: [ -240, 240 ]");
                        }
                    } else {
                        ToastTool.i(getContext(), "L值无效，有效范围: [ -320, 320 ]");
                    }
                } else {
                    ToastTool.i(getContext(), "R值无效，有效范围: [ -180, 180 ]");
                }
            } else {
                ToastTool.i(getContext(), "S值无效，有效范围: [ 0, 10 ]");
            }
        });
    }

    @Override
    public void onApiSuccess(ApiResultWrapper wrapper, Bundle bundle) {
        Api.Type type = wrapper.getType();
        switch (type) {
            case UPDATE_WIFI:
            case UPDATE_CLOUD_ADDRESS:
            case UPDATE_EMISSIVITY:
            case UPDATE_CAPTURE:
            case UPDATE_FUSION:
                ToastTool.i(getContext(), type.getName() + "成功");
                break;
            default:
                break;
        }
    }

    @Override
    public void onApiFailed(ApiResultWrapper wrapper, Bundle bundle) {
        Api.Type type = wrapper.getType();
        switch (type) {
            case UPDATE_WIFI:
            case UPDATE_CLOUD_ADDRESS:
            case UPDATE_EMISSIVITY:
            case UPDATE_CAPTURE:
            case UPDATE_FUSION:
                ToastTool.i(getContext(), "服务异常");
                LogTool.i(this, (String) wrapper.getData());
                break;
            default:
                break;
        }
    }

}