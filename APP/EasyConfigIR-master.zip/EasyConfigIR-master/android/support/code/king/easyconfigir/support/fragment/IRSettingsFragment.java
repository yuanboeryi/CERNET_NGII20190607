package king.easyconfigir.support.fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import org.videolan.libvlc.util.VLCVideoLayout;

import java.util.ArrayList;
import java.util.Objects;

import king.easyconfigir.third.dialog.view.LoadingDialog;
import king.easyconfigir.third.listener.CustomTabEntity;
import king.easyconfigir.third.listener.OnTabSelectListener;
import king.easyconfigir.third.widget.CommonTabLayout;
import king.easyconfigir.third.widget.SegmentTabLayout;

import king.easyconfigir.support.R;
import king.easyconfigir.support.help.DeviceConnectHelper;
import king.easyconfigir.support.help.VideoPlayHelper;
import king.easyconfigir.support.model.LinkSrc;
import king.easyconfigir.support.model.TabEntity;
import king.easyconfigir.support.model.VideoSrc;
import king.easyconfigir.support.network.ApiManager;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.ToastTool;
import king.easyconfigir.support.widget.LineLayout;
import king.easyconfigir.support.widget.PartLayout;

public class IRSettingsFragment extends BaseFragment implements DeviceConnectHelper.OnDeviceEvent {

    private CommonTabLayout topTabLayout;
    private SegmentTabLayout bottomTabLayout;
    private LineLayout connectLayout;
    private FrameLayout videoParentLayout;
    private VLCVideoLayout videoLayout;
    private TextView videoTitle;

    private DeviceConnectHelper deviceConnectHelper;
    private VideoPlayHelper videoPlayHelper;

    private PartLayout deviceIdLayout;
    private PartLayout deviceMacLayout;

    private LoadingDialog loadingDialog;

    private IRSettingsEvent irSettingsEvent;

    public interface IRSettingsEvent {
        void onRequestQRScanFragment();
    }

    public void setIRSettingsEvent(IRSettingsEvent irSettingsEvent) {
        this.irSettingsEvent = irSettingsEvent;
    }

    public static IRSettingsFragment getInstance(String title) {
        return new IRSettingsFragment(title);
    }

    public IRSettingsFragment(String title) {
        super(title,
                R.layout.ir_scroll_layout,
                R.id.ir_setting_action_bar,
                R.string.device_config,
                R.menu.ir_menu
        );
    }

    @Override
    protected boolean onActionBarMenuItemClick(MenuItem item) {
        if (item.getItemId() == R.id.irl_scan) {
            requestQRScan();
        }
        return super.onActionBarMenuItemClick(item);
    }

    @Override
    protected void onLoadView(View view) {
        super.onLoadView(view);
        initTopTabLayout(view);
        initBottomTabLayout(view);
        initVideoLayout(view);
        ininConnectLayout(view);
        initDeviceInfoLayout(view);
    }

    @Override
    public void onResume() {
        super.onResume();
        topTabLayout.setCurrentTab(0);
        bottomTabLayout.setCurrentTab(0);
    }

    private void requestQRScan() {
        if (irSettingsEvent != null) {
            irSettingsEvent.onRequestQRScanFragment();
        }
    }

    private void initTopTabLayout(View view) {
        topTabLayout = view.findViewById(R.id.top_tab_layout);
        ArrayList<CustomTabEntity> mTabEntities = new ArrayList<>();
        String[] mTitles = getResources().getStringArray(R.array.top_tab_text_array);
        for (String title : mTitles) {
            mTabEntities.add(new TabEntity(title));
        }
        topTabLayout.setTabData(mTabEntities);
        topTabLayout.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                if (deviceConnectHelper.isDeviceConnected()) {
                    videoPlayHelper.play(VideoSrc.parse(deviceConnectHelper.getCurrentLinkSrc(), position));
                    LogTool.i(topTabLayout, "tabSelect position: " + position);
                } else {
                    ToastTool.i(getContext(), "设备未连接");
                }
                updateVideoTitle();
            }

            @Override
            public void onTabReselect(int position) {
                LogTool.i(topTabLayout, "tabReselect position: " + position);
            }
        });
    }

    private void initBottomTabLayout(View view) {
        bottomTabLayout = view.findViewById(R.id.bottom_tab_layout);
        ArrayList<Fragment> mFragments = new ArrayList<>();
        String[] mTitles = getResources().getStringArray(R.array.bottom_tab_text_array);

        for (int i = 0; i < mTitles.length; i++) {
            String title = mTitles[i];
            Fragment fragment = null;
            if (i == 0) {
                fragment = DeviceManageFragment.getInstance("Switch Fragment " + title);
            } else if (i == 1) {
                fragment = PresetManageFragment.getInstance("Switch Fragment " + title);
            } else if (i == 2) {
                fragment = PresetEditFragment.getInstance("Switch Fragment " + title);
            }
            if (fragment != null) {
                mFragments.add(fragment);
            }
        }

        bottomTabLayout.setTabData(mTitles, Objects.requireNonNull(getActivity()), R.id.bottom_fragment_change, mFragments);
        bottomTabLayout.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                LogTool.i(bottomTabLayout, "position: " + position);
            }

            @Override
            public void onTabReselect(int position) {
                LogTool.i(bottomTabLayout, "position: " + position);
            }
        });
    }

    private void initVideoLayout(View view) {
        videoParentLayout = view.findViewById(R.id.isl_video_parent_layout);
        videoLayout = view.findViewById(R.id.isl_video_layout);
        videoPlayHelper = new VideoPlayHelper(getContext(), getActivity());
        videoPlayHelper.prepareVLCMediaPlayer(videoLayout);
        videoTitle = view.findViewById(R.id.isl_video_info);
    }

    private void ininConnectLayout(View view) {
        connectLayout = view.findViewById(R.id.isl_connect_layout);
        connectLayout.setInputText(getResources().getString(R.string.default_hs_ip));
        deviceConnectHelper = new DeviceConnectHelper(getContext(), getActivity());
        deviceConnectHelper.setOnDeviceEvent(this);
        connectLayout.setOnLineClickEvent(v -> {
            loadingDialog = new LoadingDialog(getContext());
            deviceConnectHelper.connectDevice(v);
//            ApiManager.instance().getAllPresetPoints();;
        });
    }

    private void initDeviceInfoLayout(View view) {
        deviceIdLayout = view.findViewById(R.id.isl_device_id);
        deviceMacLayout = view.findViewById(R.id.isl_device_mac);
        ApiManager.instance().setDeviceId(deviceIdLayout.getInputValue());
        ApiManager.instance().setDeviceMac(deviceMacLayout.getInputValue());
        deviceIdLayout.setInputTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String value = editable.toString();
                ApiManager.instance().setDeviceId(value);
            }
        });
        deviceMacLayout.setInputTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String value = editable.toString();
                ApiManager.instance().setDeviceMac(value);
            }
        });
    }

    public void setDeviceId(String id) {
        this.deviceIdLayout.setInputText(id);
    }

    public void setDeviceMac(String mac) {
        this.deviceMacLayout.setInputText(mac);
    }

    private void updateVideoTitle() {
        if (!deviceConnectHelper.isDeviceConnected()) {
            if (topTabLayout.getCurrentTab() == 0) {
                videoTitle.setText(getResources().getString(R.string.high_title));
            } else if (topTabLayout.getCurrentTab() == 1) {
                videoTitle.setText(getResources().getString(R.string.ir_title));
            }
            videoTitle.setVisibility(View.VISIBLE);
        } else {
            videoTitle.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (deviceConnectHelper.isDeviceConnected()) {
            videoPlayHelper.play(VideoSrc.parse(deviceConnectHelper.getCurrentLinkSrc(), topTabLayout.getCurrentTab()));
        }
        updateVideoTitle();
    }

    @Override
    public void onStop() {
        super.onStop();
        videoPlayHelper.stop();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {
//            videoPlayHelper.stop();
//            videoPlayHelper.updateVideoSurfaces();
//            videoParentLayout.setVisibility(View.INVISIBLE);
        } else {
//            if (deviceConnectHelper.isDeviceConnected()) {
//                videoPlayHelper.play(VideoSrc.parse(deviceConnectHelper.getCurrentLinkSrc(), topTabLayout.getCurrentTab()));
//            }
//            updateVideoTitle();
//            videoPlayHelper.updateVideoSurfaces();
//            videoParentLayout.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        videoPlayHelper.release();
        deviceConnectHelper.release();
    }

    @Override
    public void onDeviceConnectBefore(LinkSrc linkSrc) {
        loadingDialog.setLoadingText("正在连接...").setSuccessText("连接成功").show();
        connectLayout.setClickEnable(false);
        connectLayout.setInputEditEnable(false);
    }

    @Override
    public void onDeviceConnectAfter(LinkSrc linkSrc) {
        videoPlayHelper.play(VideoSrc.parse(linkSrc, topTabLayout.getCurrentTab()));
    }

    @Override
    public void onDeviceDisconnectBefore() {
        loadingDialog.setLoadingText("正在断开...").setSuccessText("断开成功").show();
        connectLayout.setClickEnable(false);
        connectLayout.setInputEditEnable(false);
    }

    @Override
    public void onDeviceDisconnectAfter() {
        videoPlayHelper.stop();
    }

    @Override
    public void onDeviceCommandSendError() {
        videoPlayHelper.stop();
        connectLayout.setClickEnable(true);
        connectLayout.setInputEditEnable(true);
        connectLayout.setClickText(getResources().getString(R.string.connect));
        updateVideoTitle();
    }

    @Override
    public void onDeviceCommandSendStart() {
        connectLayout.setClickEnable(true);
        connectLayout.setClickText(getResources().getString(R.string.disconnect));
        updateVideoTitle();
        loadingDialog.loadSuccess();
    }

    @Override
    public void onDeviceCommandSendStop() {
        connectLayout.setClickEnable(true);
        connectLayout.setInputEditEnable(true);
        connectLayout.setClickText(getResources().getString(R.string.connect));
        updateVideoTitle();
        loadingDialog.loadSuccess();
    }
}