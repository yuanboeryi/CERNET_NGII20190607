package king.easyconfigir.support.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import java.util.List;

import king.easyconfigir.support.R;
import king.easyconfigir.support.model.ApiResultWrapper;
import king.easyconfigir.support.model.Device;
import king.easyconfigir.support.network.Api;
import king.easyconfigir.support.network.ApiManager;
import king.easyconfigir.support.tool.JsonTool;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.TextTool;
import king.easyconfigir.support.tool.ToastTool;
import king.easyconfigir.support.widget.ActionBar;
import king.easyconfigir.support.widget.PresetEditListLayout;
import king.easyconfigir.third.dialog.view.LoadingDialog;

@SuppressLint("ValidFragment")
public class PresetEditFragment extends BaseFragment implements ApiManager.ApiEventListener {

    private PresetEditListLayout presetEditListLayout;
    private Button save;
    private final static String SAVED_DEVICE_ID = "saved_device_id";
    private final static String IS_LAST_SAVED_DEVICE = "is_last_saved_device";

    private OnPresetEditEvent onPresetEditEvent;

    private LoadingDialog loadingDialog;

    public interface OnPresetEditEvent {
        void onRequestFragmentBack();
    }

    public void setOnPresetEditEvent(OnPresetEditEvent onPresetEditEvent) {
        this.onPresetEditEvent = onPresetEditEvent;
    }

    public static PresetEditFragment getInstance(String title) {
        return new PresetEditFragment(title);
    }

    public PresetEditFragment(String title) {
        super(title,
                R.layout.preset_edit_layout,
                R.id.pel_action_bar,
                R.string.preset_point_edit,
                R.menu.preset_menu,
                true
        );
        ApiManager.instance().addApiEventListener(this);
    }

    @Override
    protected void onNavigationBack() {
        super.onNavigationBack();
        if (onPresetEditEvent != null) {
            onPresetEditEvent.onRequestFragmentBack();
        }
    }

    @Override
    protected boolean onActionBarMenuItemClick(MenuItem item) {
        if (item.getItemId() == R.id.pel_delete) {
//                ToastTool.i(getContext(), "delete");
            this.presetEditListLayout.empty();
        }
        return super.onActionBarMenuItemClick(item);
    }

    @Override
    protected void onLoadView(View view) {
        super.onLoadView(view);
        initPresetEditListLayout(view);
        initSaveButton(view);
    }

    private void initPresetEditListLayout(View view) {
        this.presetEditListLayout = view.findViewById(R.id.pel_edit);
    }

    private void initSaveButton(View view) {
        this.save = view.findViewById(R.id.pel_save);
        this.save.setOnClickListener(e -> {
//            if (!ApiManager.instance().checkDeviceInfo()) {
//                ToastTool.i(getContext(), "保存失败，设备编号和MAC不能为空");
//                return;
//            }
            List<Device> deviceList = presetEditListLayout.getListData();
            int size = deviceList.size();
            if (size <= 0) {
                ToastTool.i(getContext(), "没有数据保存");
                return;
            }
            new Thread(() -> {
                int i = 1;
                boolean hasShowDialog = false;
                for (Device device : deviceList) {
                    if (TextTool.checkNull(device.getMac())) {
                        LogTool.i(this, device.getTag() + "MAC为空");
                        continue;
                    }
                    if (!hasShowDialog) {
                        loadingDialog = new LoadingDialog(getContext());
                        loadingDialog.setLoadingText("正在保存...").setSuccessText("保存成功").setFailedText("保存失败").show();
                        hasShowDialog = true;
                    }
                    if (TextTool.checkNull(device.getWarnTemperature())) {
                        device.setWarnTemperature("80");
                    }
                    if (TextTool.checkNull(device.getDistance())) {
                        device.setDistance("4");
                    }
                    Bundle bundle = new Bundle();
                    bundle.putInt(SAVED_DEVICE_ID, i);
                    bundle.putBoolean(IS_LAST_SAVED_DEVICE, (i == size));
                    ApiManager.instance().updateDeviceConfig(device, bundle);
                    LogTool.i(PresetEditFragment.this, i + ": " + JsonTool.toJson(device));
                    i++;
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }
            }).start();
        });
    }

    @Override
    public void onApiSuccess(ApiResultWrapper wrapper, Bundle bundle) {
        Api.Type type = wrapper.getType();
        switch (type) {
            case UPDATE_DEVICE_CONFIG:
                if (bundle.getBoolean(IS_LAST_SAVED_DEVICE)) {
                    loadingDialog.loadSuccess();
                    ToastTool.i(getContext(), type.getName() + "成功");
                }
                LogTool.i(this, "save device: " + bundle.getInt(SAVED_DEVICE_ID));
                break;
            default:
                break;
        }
    }

    @Override
    public void onApiFailed(ApiResultWrapper wrapper, Bundle bundle) {
        Api.Type type = wrapper.getType();
        switch (type) {
            case UPDATE_DEVICE_CONFIG:
                ToastTool.i(getContext(), "保存失败");
                LogTool.i(this, (String) wrapper.getData());
                break;
            default:
                break;
        }
    }
}