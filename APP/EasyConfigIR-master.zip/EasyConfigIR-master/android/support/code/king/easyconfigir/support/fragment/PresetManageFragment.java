package king.easyconfigir.support.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;

import king.easyconfigir.support.R;
import king.easyconfigir.support.adapter.PresetAdapter;
import king.easyconfigir.support.model.ApiResultWrapper;
import king.easyconfigir.support.model.PresetPoint;
import king.easyconfigir.support.network.Api;
import king.easyconfigir.support.network.ApiManager;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.TextTool;
import king.easyconfigir.support.tool.ToastTool;
import king.easyconfigir.support.widget.PresetListLayout;

@SuppressLint("ValidFragment")
public class PresetManageFragment extends BaseFragment implements ApiManager.ApiEventListener, PresetAdapter.PresetAdapterEvent {

    private PresetListLayout presetListLayout;

    private PresetPointEvent presetPointEvent;

    private final static String PRESET_POINT_POSITION = "preset_point_position";

    public interface PresetPointEvent {
        void onRequestPresetPointEdit(PresetPoint presetPoint, int position);
    }

    public void setPresetPointEvent(PresetPointEvent presetPointEvent) {
        this.presetPointEvent = presetPointEvent;
    }

    public static PresetManageFragment getInstance(String title) {
        return new PresetManageFragment(title);
    }

    public PresetManageFragment(String title) {
        super(title, R.layout.preset_manage_layout);
        ApiManager.instance().addApiEventListener(this);
    }

    @Override
    protected void onLoadView(View view) {
        super.onLoadView(view);
        initPresetListLayout(view);
    }

    private void initPresetListLayout(View view) {
        this.presetListLayout = view.findViewById(R.id.pml_list_layout);
        this.presetListLayout.setPresetAdapterEvent(this);
        if (getActivity() instanceof PresetPointEvent) {
            this.setPresetPointEvent((PresetPointEvent) getActivity());
        }
    }

    @Override
    public void onLeftClick(PresetPoint presetPoint, int position) {
        if (presetPoint.isAdd()) {
            // 调用预设点
            String presetId = String.valueOf(position);
            if (TextTool.isValidIntegerRange(presetId, 1, 125, TextTool.ALL_CLOSE)) {
                if (ApiManager.instance().checkDeviceMac()) {
                    ApiManager.instance().callPresetPoint(presetId);
                } else {
                    ToastTool.i(getContext(), "设备MAC不能为空");
                }
            } else {
                ToastTool.i(getContext(), "超出预设点调用范围 [1, 125]");
            }
        } else {
            // 添加预设点
            String presetIndex = String.valueOf(position - 1);
            String distance = "4";
            if (TextTool.isValidIntegerRange(presetIndex, 0, 128, TextTool.ALL_CLOSE)) {
                if (TextTool.isValidIntegerRange(distance, 4, 20, TextTool.ALL_CLOSE)) {
                    if (ApiManager.instance().checkDeviceMac()) {
                        Bundle bundle = new Bundle();
                        bundle.putInt(PRESET_POINT_POSITION, position);
                        ApiManager.instance().addPresetPoint(presetIndex, distance, bundle);
                    } else {
                        ToastTool.i(getContext(), "设备MAC不能为空");
                    }
                } else {
                    ToastTool.i(getContext(), "超出预设点距离 [4, 20]");
                }
            } else {
                ToastTool.i(getContext(), "超出预设点索引 [0, 128]");
            }
        }
    }

    @Override
    public void onRightClick(PresetPoint presetPoint, int position) {
        if (presetPoint.isAdd()) {
            if (presetPointEvent != null) {
                presetPointEvent.onRequestPresetPointEdit(presetPoint, position);
            }
        } else {
            ToastTool.i(getContext(), "无法编辑，请先添加预设点！");
        }
    }

    @Override
    public void onApiSuccess(ApiResultWrapper wrapper, Bundle bundle) {
        Api.Type type = wrapper.getType();
        switch (type) {
            case CALL_PRESET_POINT:
                ToastTool.i(getContext(), type.getName() + "成功");
                break;
            case ADD_PRESET_POINT:
                ToastTool.i(getContext(), type.getName() + "成功");
                this.presetListLayout.setPresetPointAddStateByPosition(true, bundle.getInt(PRESET_POINT_POSITION));
                break;
            default:
                break;
        }
    }

    @Override
    public void onApiFailed(ApiResultWrapper wrapper, Bundle bundle) {
        Api.Type type = wrapper.getType();
        switch (type) {
            case CALL_PRESET_POINT:
            case ADD_PRESET_POINT:
                ToastTool.i(getContext(), "服务异常, " + type.getName() + "失败");
                LogTool.i(this, (String) wrapper.getData());
                break;
            default:
                break;
        }
    }

}