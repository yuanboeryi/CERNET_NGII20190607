package king.easyconfigir.support.fragment;

import android.app.Activity;
import android.content.Intent;
import android.hardware.Camera;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Objects;

import king.easyconfigir.support.R;
import king.easyconfigir.support.model.ScanResult;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.OtherTool;
import king.easyconfigir.support.tool.ParseTool;
import king.easyconfigir.support.tool.ToastTool;
import king.easyconfigir.third.qr.widget.QRCodeView;
import king.easyconfigir.third.qr.widget.ZXingView;

public class QRScanFragment extends BaseFragment implements QRCodeView.Delegate {

    private final static int REQUEST_CODE_CHOOSE_QRCODE_FROM_GALLERY = 0x1;

    private ZXingView zxingView;

    private Button ibLight;
    private TextView tvLight;

    private QRScanEvent qrScanEvent;

    private boolean isLightOpen = false;
    private boolean isUseFrontCamera = false;

    public interface QRScanEvent {
        boolean onQRScanSuccess(ScanResult result);

        void onQRScanFailed();

        void onRequestFragmentBack();
    }

    public void setQRScanEvent(QRScanFragment.QRScanEvent qrScanEvent) {
        this.qrScanEvent = qrScanEvent;
    }

    public static QRScanFragment getInstance(String title) {
        return new QRScanFragment(title);
    }

    public QRScanFragment(String title) {
        super(title, R.layout.qr_scan_layout,
                R.id.qrsl_action_bar,
                R.string.args_scan,
                R.menu.qr_scan_menu,
                true
        );
    }

    @Override
    protected void onNavigationBack() {
        super.onNavigationBack();
        if (qrScanEvent != null) {
            qrScanEvent.onRequestFragmentBack();
        }
    }

    @Override
    protected boolean onActionBarMenuItemClick(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.qs_photo) {
            selectPhoto();
        } else if (id == R.id.qs_switch) {
            switchCamera();
        } else if (id == R.id.qs_parse) {
            // TODO 扫描模式
        }
        return super.onActionBarMenuItemClick(item);
    }

    @Override
    protected void onLoadView(View view) {
        super.onLoadView(view);
        initZxingView(view);
        initLight(view);
    }

    private void initZxingView(View view) {
        zxingView = view.findViewById(R.id.qrsl_zxing_view);
        zxingView.setDelegate(this);
    }

    private void initLight(View view) {
        ibLight = view.findViewById(R.id.qrsl_light);
        tvLight = view.findViewById(R.id.qrsl_light_text);
        ibLight.setOnClickListener(e -> {
            changeLightState();
        });
    }

    private void selectPhoto() {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, REQUEST_CODE_CHOOSE_QRCODE_FROM_GALLERY);
    }

    private void switchCamera() {
        stopQRScan();
        isUseFrontCamera = !isUseFrontCamera;
        if (isUseFrontCamera) {
            ToastTool.i(getContext(), "切换为前置摄像头");
        } else {
            ToastTool.i(getContext(), "切换为后置摄像头");
        }
        startQRScan();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE_CHOOSE_QRCODE_FROM_GALLERY) {
            String picturePath = OtherTool.parseUri(Objects.requireNonNull(getContext()), data);
            if (picturePath != null) {
                zxingView.decodeQRCode(picturePath);
            } else {
                ToastTool.i(getContext(), "无效图片");
            }
            LogTool.i(this, "select picture: " + picturePath);
        }
    }

    private void changeLightState() {
        if (isLightOpen) {
            ibLight.setBackgroundResource(R.drawable.ic_action_light_close);
            tvLight.setText("开灯");
            tvLight.setTextColor(getResColor(R.color.colorPrimaryDark));
            zxingView.closeFlashlight();
        } else {
            ibLight.setBackgroundResource(R.drawable.ic_action_light_open);
            tvLight.setText("关灯");
            tvLight.setTextColor(getResColor(R.color.white));
            zxingView.openFlashlight();
        }
        isLightOpen = !isLightOpen;
    }

    private void maybeCloseLight() {
        if (isLightOpen) {
            ibLight.setBackgroundResource(R.drawable.ic_action_light_close);
            tvLight.setText("开灯");
            tvLight.setTextColor(getResColor(R.color.colorPrimaryDark));
            zxingView.closeFlashlight();
            isLightOpen = false;
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {
            stopQRScan();
        } else {
            startQRScan();
        }
        maybeCloseLight();
        LogTool.i(this, "hidden: " + hidden);
    }

    @Override
    public void onResume() {
        super.onResume();
        LogTool.i(this, "onResume");
    }

    @Override
    public void onPause() {
        super.onPause();
        LogTool.i(this, "onPause");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopQRScan();
        zxingView.onDestroy();
    }

    private void startQRScan() {
        if (isUseFrontCamera) {
            zxingView.startCamera(Camera.CameraInfo.CAMERA_FACING_FRONT);
        } else {
            zxingView.startCamera(Camera.CameraInfo.CAMERA_FACING_BACK);
        }
        zxingView.startSpotAndShowRect();
        LogTool.i(this, "startQRScan");
    }

    private void stopQRScan() {
        zxingView.stopCamera();
        zxingView.stopSpotAndHiddenRect();
        LogTool.i(this, "stopQRScan");
    }

    @Override
    public void onScanQRCodeSuccess(String result) {
        boolean isContinueSpot = true;
        OtherTool.vibrate(getActivity(), 200);
        if (qrScanEvent != null) {
            isContinueSpot = qrScanEvent.onQRScanSuccess(ParseTool.parseQrResult(result));
        }
        if (isContinueSpot) {
            zxingView.startSpot();
        }
    }

    @Override
    public void onCameraAmbientBrightnessChanged(boolean isDark) {
        // 这里是通过修改提示文案来展示环境是否过暗的状态，接入方也可以根据 isDark 的值来实现其他交互效果
        String tipText = zxingView.getScanBoxView().getTipText();
        String ambientBrightnessTip = "\n环境过暗，请打开闪光灯";
        if (isDark) {
            if (!tipText.contains(ambientBrightnessTip)) {
                zxingView.getScanBoxView().setTipText(tipText + ambientBrightnessTip);
            }
        } else {
            if (tipText.contains(ambientBrightnessTip)) {
                tipText = tipText.substring(0, tipText.indexOf(ambientBrightnessTip));
                zxingView.getScanBoxView().setTipText(tipText);
            }
        }
    }

    @Override
    public void onScanQRCodeOpenCameraError() {
        if (qrScanEvent != null) {
            qrScanEvent.onQRScanFailed();
        }
        LogTool.i(this, "open camera error!");
    }
}
