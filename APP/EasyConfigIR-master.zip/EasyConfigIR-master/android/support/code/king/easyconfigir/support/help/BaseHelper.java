package king.easyconfigir.support.help;

import android.app.Activity;
import android.content.Context;

import androidx.fragment.app.FragmentActivity;

public class BaseHelper {

    private Context context;
    private FragmentActivity activity;

    public BaseHelper(Context context, FragmentActivity activity) {
        this.context = context;
        this.activity = activity;
    }

    public Context getContext() {
        return this.context;
    }

    public FragmentActivity getActivity() {
        return this.activity;
    }

    protected String getResString(int id) {
        return this.context.getResources().getString(id);
    }

}
