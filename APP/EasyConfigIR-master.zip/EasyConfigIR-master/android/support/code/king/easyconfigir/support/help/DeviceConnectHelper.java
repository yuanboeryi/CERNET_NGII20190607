package king.easyconfigir.support.help;

import android.content.Context;

import androidx.fragment.app.FragmentActivity;

import java.util.HashMap;
import java.util.Objects;

import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.common.manager.CommandSender;
import king.easyconfigir.common.model.CommandWrapper;
import king.easyconfigir.support.model.LinkSrc;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.TextTool;
import king.easyconfigir.support.tool.ToastTool;
import king.easyconfigir.third.dialog.view.LoadingDialog;

public class DeviceConnectHelper extends BaseHelper implements CommandSender.OnSenderEvent {

    private boolean isDeviceConnected = false;
    private LinkSrc currentLinkSrc = null;

    // 指令发送成功提示 测试模式下启用
    private boolean isDisabledToastSend = true;

    private OnDeviceEvent onDeviceEvent;

    public interface OnDeviceEvent {
        void onDeviceConnectBefore(LinkSrc linkSrc);

        void onDeviceConnectAfter(LinkSrc linkSrc);

        void onDeviceDisconnectBefore();

        void onDeviceDisconnectAfter();

        void onDeviceCommandSendError();

        void onDeviceCommandSendStart();

        void onDeviceCommandSendStop();
    }

    public void setOnDeviceEvent(OnDeviceEvent onDeviceEvent) {
        this.onDeviceEvent = onDeviceEvent;
    }

    public DeviceConnectHelper(Context context, FragmentActivity activity) {
        super(context, activity);
        this.isDeviceConnected = false;
        CommandSender.instance().addOnSenderEvent(this);
    }

    public boolean isDeviceConnected() {
        return isDeviceConnected;
    }

    public LinkSrc getCurrentLinkSrc() {
        return currentLinkSrc;
    }

    public void connectDevice(String value) {
        if (isDeviceConnected) {
            if (onDeviceEvent != null) {
                onDeviceEvent.onDeviceDisconnectBefore();
            }
            CommandSender.instance().stop();
            if (onDeviceEvent != null) {
                onDeviceEvent.onDeviceDisconnectAfter();
            }
        } else {
            LinkSrc linkSrc = parseLinKSrc(value);
            if (linkSrc != null && linkSrc != LinkSrc.NONE) {
                this.currentLinkSrc = linkSrc;
                if (onDeviceEvent != null) {
                    onDeviceEvent.onDeviceConnectBefore(linkSrc);
                }
                if (!CommandSender.instance().isStart()) {
                    CommandSender.instance().setHost(linkSrc.getIp()).setPort(linkSrc.getPort()).start();
                }
                CommandFactory.instance().setDeviceID(linkSrc.getDeviceId());
                if (onDeviceEvent != null) {
                    onDeviceEvent.onDeviceConnectAfter(linkSrc);
                }
            } else {
                this.currentLinkSrc = null;
            }
        }
    }

    private LinkSrc parseLinKSrc(String value) {
        LinkSrc linkSrc;
        if (!TextTool.checkNull(value)) {
            HashMap<String, String> ss = TextTool.matchDeviceToken(value);
            if (ss != null) {
                String header = ss.get("header");
                if (header != null) {
                    if (LinkSrc.HS.checkHeader(header)) {
                        linkSrc = LinkSrc.HS;
                    } else if (LinkSrc.SMP.checkHeader(header)) {
                        linkSrc = LinkSrc.SMP;
                    } else {
                        ToastTool.i(getContext(), "未知设备类型");
                        LogTool.i(this, "unknown device! " + value);
                        return LinkSrc.NONE;
                    }
                } else {
                    // 没有头部，默认 hs://
                    linkSrc = LinkSrc.HS;
                    LogTool.i(this, "use default header: hs://");
                }
                String ip = ss.get("host");
                String port = CommandSender.instance().getPort();
                String deviceId = CommandFactory.instance().getDeviceID();
                if (ss.get("port") != null) {
                    port = ss.get("port");
                }
                if (ss.get("device_id") != null) {
                    deviceId = ss.get("device_id");
                }
                linkSrc.setIp(ip);
                linkSrc.setPort(port);
                linkSrc.setDeviceId(deviceId);
            } else {
                ToastTool.i(getContext(), "设备地址无效");
                LogTool.i(this, "device address is invalid! " + value);
                return LinkSrc.NONE;
            }
        } else {
            ToastTool.i(getContext(), "请输入设备地址");
            LogTool.i(this, "device address is null!");
            return LinkSrc.NONE;
        }
        LogTool.i(this, "link: " + linkSrc.getLink());
        return linkSrc;
    }

    public void release() {
        CommandSender.instance().release();
    }

    @Override
    public void onCSError(Exception e) {
        Objects.requireNonNull(getActivity()).runOnUiThread(() -> {
            isDeviceConnected = false;
            if (onDeviceEvent != null) {
                onDeviceEvent.onDeviceCommandSendError();
            }
            ToastTool.i(getContext(), "服务运行异常！");
            e.printStackTrace();
        });
    }

    @Override
    public void onCSStart() {
        Objects.requireNonNull(getActivity()).runOnUiThread(() -> {
            isDeviceConnected = true;
            if (onDeviceEvent != null) {
                onDeviceEvent.onDeviceCommandSendStart();
            }
            ToastTool.i(getContext(), "服务已正常启动！");
            LogTool.i(this, "CommandSender: " + CommandSender.instance().getHost() + ":" + CommandSender.instance().getPort() + " is waiting...");
        });
    }

    @Override
    public void onCSSend(CommandWrapper commandWrapper, String jsonData) {
        Objects.requireNonNull(getActivity()).runOnUiThread(() -> {
            LogTool.i(this, "send ok! " + commandWrapper.getName());
            LogTool.i(this, jsonData);
            String name = commandWrapper.getName();
            if (
                    "设置预设点指令".equals(name) ||
                            "调用预设点指令".equals(name) ||
                            "清除预设点指令".equals(name) ||
                            "修改预设点距离指令".equals(name) ||
                            isDisabledToastSend
            ) {
                return;
            }
            ToastTool.i(getContext(), "发送" + commandWrapper.getName() + "成功!");
        });
    }


    @Override
    public void onCSRunning() {

    }

    @Override
    public void onCSStop() {
        Objects.requireNonNull(getActivity()).runOnUiThread(() -> {
            isDeviceConnected = false;
            if (onDeviceEvent != null) {
                onDeviceEvent.onDeviceCommandSendStop();
            }
            ToastTool.i(getContext(), "服务已成功关闭！");
            LogTool.i(this, "CommandSender: " + CommandSender.instance().getHost() + ":" + CommandSender.instance().getPort() + " exited!");
        });
    }
}
