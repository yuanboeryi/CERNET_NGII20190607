package king.easyconfigir.support.help;

import android.content.Context;
import android.net.Uri;

import androidx.fragment.app.FragmentActivity;

import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.util.VLCVideoLayout;

import java.util.ArrayList;
import java.util.Objects;

import king.easyconfigir.support.model.VideoSrc;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.ToastTool;

public class VideoPlayHelper extends BaseHelper {
    private LibVLC mLibVLC;
    private MediaPlayer mMediaPlayer;
    private VLCVideoLayout videoLayout;

    private static final boolean VLC_USE_TEXTURE_VIEW = false;
    private static final boolean VLC_ENABLE_SUBTITLES = true;

    private boolean isPlaying = false;
    private VideoSrc currentVideoSrc = null;

    public VideoPlayHelper(Context context, FragmentActivity activity) {
        super(context, activity);
    }

    public boolean isPlaying() {
        return isPlaying;
    }

    public VideoSrc getCurrentVideoSrc() {
        return currentVideoSrc;
    }

    public void prepareVLCMediaPlayer(VLCVideoLayout videoLayout) {
        this.videoLayout = videoLayout;
        final ArrayList<String> args = new ArrayList<>();
        args.add("-vvv");
//        args.add("--no-drop-late-frames");
//        args.add("--no-skip-frames");
        args.add("--rtsp-tcp");
        mLibVLC = new LibVLC(Objects.requireNonNull(getContext()), args);
        mMediaPlayer = new MediaPlayer(mLibVLC);
        mMediaPlayer.attachViews(videoLayout, null, VLC_ENABLE_SUBTITLES, VLC_USE_TEXTURE_VIEW);
        mMediaPlayer.setEventListener(event -> {
//                LogTool.i("play", "buffer: " + event.getBuffering());
        });
        // 防止闪屏
        mMediaPlayer.detachViews();
    }

    public void play(VideoSrc videoSrc) {
        if (isPlaying) {
            stop();
        }
        if (videoSrc != null) {
            this.currentVideoSrc = videoSrc;
            VideoSrc.Header header = videoSrc.getHeader();
            switch (header) {
                case TCP:
//                    playByOther(videoSrc.getHost(), videoSrc.getPort());
                    playFake(videoSrc);
                    break;
                case RTSP:
                    playByVLC(videoSrc.getUrl(), videoSrc.getNetworkCaching());
                    //   playFake(videoSrc);
                    break;
                default:
                    this.isPlaying = false;
                    this.currentVideoSrc = null;
                    break;
            }
        } else {
            this.isPlaying = false;
            this.currentVideoSrc = null;
        }
    }

    private void playFake(VideoSrc videoSrc) {
        isPlaying = true;
        LogTool.i(this, "play: " + videoSrc.getUrl());
        ToastTool.i(getContext(), "play: " + videoSrc.getUrl());
    }

    private void playByOther(String host, long port) {
        // TODO playByOther
        this.isPlaying = true;
    }

    private void playByVLC(String url, long netcaching) {
        if (url != null) {
            mMediaPlayer.attachViews(videoLayout, null, VLC_ENABLE_SUBTITLES, VLC_USE_TEXTURE_VIEW);
            try {
                final Media media = new Media(mLibVLC, Uri.parse(url));
                media.setHWDecoderEnabled(true, false);
                media.addOption(":network-caching=" + netcaching);
                media.addOption(":rtsp-tcp");
                media.addOption(":clock-jitter=0");
                media.addOption(":clock-synchro=0");
                mMediaPlayer.setMedia(media);
                media.release();
            } catch (Exception e) {
                this.isPlaying = false;
                e.printStackTrace();
                throw new RuntimeException("play error! url: " + url);
            }
            this.isPlaying = true;
//            mMediaPlayer.setAspectRatio("336:251");
//            mMediaPlayer.setScale(0);
//            mMediaPlayer.setVideoScale();
//            mMediaPlayer.setVideoScale(MediaPlayer.ScaleType.SURFACE_4_3);
            mMediaPlayer.play();
//            ToastTool.i(getContext(), "play: " + url);
            LogTool.i(this, "play: " + url);
        } else {
            LogTool.i(this, "play url is null!");
        }
    }

    public void stop() {
        if (currentVideoSrc != null) {
            VideoSrc.Header header = currentVideoSrc.getHeader();
            switch (header) {
                case TCP:
                    stopOtherVideoPlay();
                    break;
                case RTSP:
                    stopVLCVideoPlay();
                    break;
                default:
                    this.isPlaying = false;
                    break;
            }
            LogTool.i(this, "stop: " + currentVideoSrc.getUrl());
        }
    }

    private void stopOtherVideoPlay() {
        // TODO stopOtherVideoPlay
        this.isPlaying = false;
    }

    private void stopVLCVideoPlay() {
        if (this.isPlaying) {
            mMediaPlayer.stop();
            mMediaPlayer.detachViews();
            this.isPlaying = false;
        }
    }

    public void release() {
        stop();
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
            mMediaPlayer = null;
        }
        if (mLibVLC != null) {
            mLibVLC.release();
            mLibVLC = null;
        }
    }

}
