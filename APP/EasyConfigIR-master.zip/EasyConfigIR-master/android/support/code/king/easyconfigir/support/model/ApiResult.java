package king.easyconfigir.support.model;

public class ApiResult {
    private String msg;

    public ApiResult(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
