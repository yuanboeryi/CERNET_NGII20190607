package king.easyconfigir.support.model;

import king.easyconfigir.support.network.Api;

public class ApiResultWrapper<T> {
    private boolean status;
    private Api.Type type;
    private T data;

    public ApiResultWrapper() {

    }

    public ApiResultWrapper(Api.Type type, T data, boolean status) {
        this.status = status;
        this.type = type;
        this.data = data;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Api.Type getType() {
        return type;
    }

    public void setType(Api.Type type) {
        this.type = type;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
