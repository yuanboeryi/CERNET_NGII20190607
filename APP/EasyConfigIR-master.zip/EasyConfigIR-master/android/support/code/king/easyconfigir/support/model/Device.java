package king.easyconfigir.support.model;

public class Device {
    private String tag;
    private String name;
    private String mac;
    private String warnTemperature;
    private String distance;
    private boolean isLookPoint;
    private boolean isTrack;

    public Device() {

    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public String getWarnTemperature() {
        return warnTemperature;
    }

    public void setWarnTemperature(String warnTemperature) {
        this.warnTemperature = warnTemperature;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public boolean isLookPoint() {
        return isLookPoint;
    }

    public void setLookPoint(boolean lookPoint) {
        isLookPoint = lookPoint;
    }

    public boolean isTrack() {
        return isTrack;
    }

    public void setTrack(boolean track) {
        isTrack = track;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("tag: ").append(tag);
        sb.append(" name: ").append(name);
        sb.append(" mac: ").append(mac);
        sb.append(" warnTemperature: ").append(warnTemperature);
        sb.append(" distance: ").append(distance);
        sb.append(" isLookPoint: ").append(isLookPoint);
        sb.append(" isTrack: ").append(isTrack);
        return sb.toString();
    }
}
