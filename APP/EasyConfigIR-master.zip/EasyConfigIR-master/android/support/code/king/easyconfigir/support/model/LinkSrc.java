package king.easyconfigir.support.model;

import king.easyconfigir.support.tool.LogTool;

public enum LinkSrc {
    SMP(Header.SMP, "192.168.8.112", "8000"),
    HS(Header.HS, "192.168.8.100", "12345"),
    NONE(Header.NONE, null, null);

    private Header header;
    private String ip;
    private String port;
    private String deviceId;

    LinkSrc(Header header, String ip, String port) {
        this(header, ip, port, "hi00000001");
    }

    LinkSrc(Header header, String ip, String port, String deviceId) {
        this.header = header;
        this.ip = ip;
        this.port = port;
        this.deviceId = deviceId;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public boolean checkHeader(String value) {
        return this.header.getValue().equals(value);
    }

    public String getLink() {
        return header.getValue() + ip + ":" + port + "/" + deviceId;
    }

    public enum Header {
        HS("hs://"),
        SMP("smp://"),
        NONE("unknow://");

        private String value;

        Header(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }
    }
}
