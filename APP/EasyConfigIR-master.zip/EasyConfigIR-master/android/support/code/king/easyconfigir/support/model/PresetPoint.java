package king.easyconfigir.support.model;

import java.util.List;

import king.easyconfigir.support.fragment.PresetEditFragment;

public class PresetPoint {
    private String name;
    private boolean isAdd;
    private List<Device> deviceList;

    public PresetPoint(String name) {
        this(name, null);
    }

    public PresetPoint(String name, List<Device> deviceLis) {
        this(name, deviceLis, false);
    }

    public PresetPoint(String name, List<Device> deviceList, boolean isAdd) {
        this.name = name;
        this.deviceList = deviceList;
        this.isAdd = isAdd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isAdd() {
        return isAdd;
    }

    public void setAdd(boolean add) {
        isAdd = add;
    }

    public List<Device> getDeviceList() {
        return deviceList;
    }

    public void setDeviceList(List<Device> deviceList) {
        this.deviceList = deviceList;
    }
}
