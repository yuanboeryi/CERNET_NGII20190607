package king.easyconfigir.support.model;

import android.os.Bundle;

public class ScanResult {
    private Type type;
    private Bundle data;

    public ScanResult() {
        this(Type.NONE, null);
    }

    public ScanResult(Type type, Bundle data) {
        this.type = type;
        this.data = data;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Bundle getData() {
        return data;
    }

    public void setData(Bundle data) {
        this.data = data;
    }

    public enum Type {
        DEVICE_CODE("设备编号"),
        DEVICE_MAC("设备MAC"),
        DEVICE_CODE_AND_MAC("设备编号和MAC"),
        NONE("未知参数"),
        ;

        private String name;

        Type(String name) {
            this.name = name;
        }

        public String getName() {
            return this.name;
        }
    }
}
