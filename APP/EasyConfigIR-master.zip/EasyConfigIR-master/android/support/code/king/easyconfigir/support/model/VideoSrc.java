package king.easyconfigir.support.model;

public enum VideoSrc {
    TEST(Header.RTSP, "127.0.0.1", 8554, "/test", 1000),

    HS_IR(Header.RTSP, "192.168.8.100", 5554, "/ir.h264", 3000),
    HS_HIGH(Header.RTSP, "192.168.8.100", 5554, "/high.h264", 1000),

    SMP_IR(Header.TCP, "192.168.8.100", 8000),
    SMP_HIGH(Header.TCP, "192.168.8.100", 8001),

    NONE(Header.NONE, null, -1, null, -1);

    private Header header;
    private String user;
    private String password;
    private String host;
    private long port;
    private String path;
    private long networkCaching;

    VideoSrc(Header header, String host, long port) {
        this(header, host, port, null, 0);
    }

    VideoSrc(Header header, String host, long prot, String path, long networkCaching) {
        this(header, null, null, host, prot, path, networkCaching);
    }

    VideoSrc(Header header, String user, String password, String host, long port, String path, long networkCaching) {
        this.header = header;
        this.user = user;
        this.password = password;
        this.host = host;
        this.port = port;
        this.path = path;
        this.networkCaching = networkCaching;
    }

    public static VideoSrc parse(LinkSrc linkSrc, int position) {
        VideoSrc src = null;
        if (linkSrc != null) {
            switch (linkSrc) {
                case HS:
                    if (0 == position) {
                        src = HS_HIGH;
                    } else if (1 == position) {
                        src = HS_IR;
                    }
                    break;
                case SMP:
                    if (0 == position) {
                        src = SMP_HIGH;
                    } else if (1 == position) {
                        src = SMP_IR;
                    }
                    break;
                default:
                    break;
            }
            if (src != null) {
                src.setHost(linkSrc.getIp());
            }
        }
        return src;
    }

//    public static VideoSrc parse(String v) {
//        VideoSrc src = NONE;
//        if ("test".equals(v)) {
//            src = TEST;
//        } else if ("high".equals(v)) {
//            src = HS_HIGH;
//        } else if ("ir".equals(v)) {
//            src = HS_IR;
//        }
//        return src;
//    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public void setPort(long port) {
        this.port = port;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Header getHeader() {
        return header;
    }

    public String getHost() {
        return host;
    }

    public long getPort() {
        return port;
    }

    public long getNetworkCaching() {
        return this.networkCaching;
    }

    public String getUrl() {
        String url = this.header.getValue();

        if (url == null) return null;

        if (this.user != null) {
            url += this.user;
            if (this.password != null) {
                url += ":" + this.password;
            }
            url += "@";
        }

        if (this.host != null) {
            url += host;
            if (this.port > 0 && this.port < 65536) {
                url += ":" + this.port;
            }
        } else {
            url = null;
        }

        if (url == null) return null;

        if (this.path != null) {
            url += path;
        }

        return url;
    }

    public enum Header {
        RTSP("rtsp://"),
        HTTP("http://"),
        HTTPS("https://"),
        TCP("tcp://"),
        UDP("udp://"),
        NONE("unknown://");

        private String value;

        Header() {
            this(null);
        }

        Header(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }

    }
}
