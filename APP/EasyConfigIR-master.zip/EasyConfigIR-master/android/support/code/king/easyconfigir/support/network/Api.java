package king.easyconfigir.support.network;

import java.util.List;

import king.easyconfigir.support.model.ApiResult;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface Api {

    String BASE_URL = "http://116.255.207.148:8080/ConfigTool/ConfigService.asmx/";

    @POST("b_setWifi")
    @FormUrlEncoded
    Call<List<ApiResult>> updateWifi(
            @Field("machinemac") String mac,
            @Field("deviceID") String deviceId,
            @Field("wifiname") String ssid,
            @Field("wifipass") String password
    );

    @POST("c_setCloudAddr")
    @FormUrlEncoded
    Call<List<ApiResult>> updateCloudAddress(
            @Field("machinemac") String mac,
            @Field("deviceID") String deviceId,
            @Field("Cloud_addr") String cloudAddress,
            @Field("ftp_addr") String ftpAddress
    );

    @POST("d_setFusheLv")
    @FormUrlEncoded
    Call<List<ApiResult>> updateEmissivity(
            @Field("machinemac") String mac,
            @Field("deviceID") String deviceId,
            @Field("value") String value
    );

    @POST("l_setCatchSpan")
    @FormUrlEncoded
    Call<List<ApiResult>> updateCapture(
            @Field("machinemac") String mac,
            @Field("deviceID") String deviceId,
            @Field("value_Catch") String inspection,
            @Field("value_Xun") String shootingCycle
    );

    @POST("g_setRonghe")
    @FormUrlEncoded
    Call<List<ApiResult>> updateFusion(
            @Field("machinemac") String mac,
            @Field("deviceID") String deviceId,
            @Field("rong_S") String S,
            @Field("rong_R") String R,
            @Field("rong_L") String L,
            @Field("rong_T") String T
    );

    @POST("Y_device_Config")
    @FormUrlEncoded
    Call<List<ApiResult>> updateDeviceConfig(
            @Field("machinemac") String mac,
            @Field("deviceID") String deviceId,
            @Field("devicename") String deviceName,
            @Field("offsetvalue") String warnTemp,
            @Field("distance") String distance,
            @Field("isWatch") String isLookup,
            @Field("isKeypoint") String isTrack
    );

    @POST("do_ysd")
    @FormUrlEncoded
    Call<List<ApiResult>> callPresetPoint(@Field("machinemac") String mac, @Field("value") String value);

    @POST("addysd")
    @FormUrlEncoded
    Call<List<ApiResult>> addPresetPoint(
            @Field("machinemac") String mac,
            @Field("ysdindex") String index,
            @Field("distance") String distance
    );

//    @POST("getdeviceBuysd")
//    @FormUrlEncoded
//    Call<ResponseBody> getDeviceListById(@Field("ysdid") String id);

    @POST("getYsdinforBymachine")
    @FormUrlEncoded
    Call<ResponseBody> getAllPresetPointsById(@Field("machineid") String id);

    @POST("goUp")
    @FormUrlEncoded
    Call<List<ApiResult>> directionUp(@Field("machinemac") String mac);

    @POST("goDown")
    @FormUrlEncoded
    Call<List<ApiResult>> directionDown(@Field("machinemac") String mac);

    @POST("goLeft")
    @FormUrlEncoded
    Call<List<ApiResult>> directionLeft(@Field("machinemac") String mac);

    @POST("goright")
    @FormUrlEncoded
    Call<List<ApiResult>> directionRight(@Field("machinemac") String mac);

    @POST("goStop")
    @FormUrlEncoded
    Call<List<ApiResult>> directionStop(@Field("machinemac") String mac);

    enum Type {
        UPDATE_WIFI("更新wifi"),
        UPDATE_CLOUD_ADDRESS("更新云服务器地址"),
        UPDATE_EMISSIVITY("更新辐射率"),
        UPDATE_CAPTURE("更新抓拍和巡视周期"),
        UPDATE_FUSION("更新融合参数"),
        UPDATE_DEVICE_CONFIG("更新设备配置"),
        CALL_PRESET_POINT("调用预设点"),
        ADD_PRESET_POINT("添加预设点"),
        GET_ALL_PRESET_POINTS("获取所有预设点"),

        DIRECTION_UP("云台向上"),
        DIRECTION_DOWN("云台向下"),
        DIRECTION_LEFT("云台向左"),
        DIRECTION_RIGHT("云台向右"),
        DIRECTION_STOP("云台停止"),


        ;
//        GET_DEVICE_LIST("获取设备列表");

        private String name;

        private Type(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }
}
