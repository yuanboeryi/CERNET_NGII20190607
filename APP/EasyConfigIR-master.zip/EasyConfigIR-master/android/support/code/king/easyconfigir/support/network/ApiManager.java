package king.easyconfigir.support.network;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import king.easyconfigir.support.model.ApiResult;
import king.easyconfigir.support.model.ApiResultWrapper;
import king.easyconfigir.support.model.Device;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.TextTool;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ApiManager extends RetrofitFactory {

    private static ApiManager instance;

    private Api api;
    private String deviceId;
    private String deviceMac;

    private ArrayList<ApiEventListener> apiEventListeners;

    public interface ApiEventListener {
        void onApiSuccess(ApiResultWrapper wrapper, Bundle bundle);

        void onApiFailed(ApiResultWrapper wrapper, Bundle bundle);
    }

    public void addApiEventListener(ApiEventListener apiEventListener) {
        this.apiEventListeners.add(apiEventListener);
    }

    private ApiManager() {
        super();
        initBaseApi();
        initApiEventListener();
    }

    private void initBaseApi() {
        this.api = getBuilder().baseUrl(Api.BASE_URL).build().create(Api.class);
    }

    private void initApiEventListener() {
        this.apiEventListeners = new ArrayList<>();
    }

    public Api getApi() {
        return api;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceMac() {
        return deviceMac;
    }

    public void setDeviceMac(String deviceMac) {
        this.deviceMac = deviceMac;
    }

    public boolean checkDeviceId() {
        return (!TextTool.checkNull(deviceId));
    }

    public boolean checkDeviceMac() {
        return (!TextTool.checkNull(deviceMac));
    }

    public boolean checkDeviceInfo() {
        return (checkDeviceId() && checkDeviceMac());
    }

    public void updateWifi(String ssid, String password) {
        api.updateWifi(deviceMac, deviceId, ssid, password).enqueue(new ApiResultCallback(Api.Type.UPDATE_WIFI));
    }

    public void updateCloudAddress(String cloudAddress) {
        String ftpAddress = cloudAddress; // 云服务地址和ftp服务器地址默认一样
        api.updateCloudAddress(deviceMac, deviceId, cloudAddress, ftpAddress).enqueue(new ApiResultCallback(Api.Type.UPDATE_CLOUD_ADDRESS));
    }

    public void updateEmissivity(String value) {
        api.updateEmissivity(deviceMac, deviceId, value).enqueue(new ApiResultCallback(Api.Type.UPDATE_EMISSIVITY));
    }

    public void updateCapture(String inspection, String shootingCycle) {
        api.updateCapture(deviceMac, deviceId, inspection, shootingCycle).enqueue(new ApiResultCallback(Api.Type.UPDATE_CAPTURE));
    }

    public void updateFusion(String S, String R, String L, String T) {
        api.updateFusion(deviceMac, deviceId, S, R, L, T).enqueue(new ApiResultCallback(Api.Type.UPDATE_FUSION));
    }

    public void updateDeviceConfig(Device device, Bundle bundle) {
        this.updateDeviceConfig(device.getName(), device.getWarnTemperature(), device.getDistance(), device.isLookPoint(), device.isTrack(), bundle);
    }

    public void updateDeviceConfig(String deviceName, String warnTemp, String distance, boolean isLookup, boolean isTrack, Bundle bundle) {
        api.updateDeviceConfig(deviceMac, deviceId, deviceName, warnTemp, distance, String.valueOf(isLookup), String.valueOf(isTrack)).enqueue(new ApiResultCallback(Api.Type.UPDATE_DEVICE_CONFIG, bundle));
    }

    public void callPresetPoint(String value) {
        api.callPresetPoint(deviceMac, value).enqueue(new ApiResultCallback(Api.Type.CALL_PRESET_POINT));
    }

    public void addPresetPoint(String index, String distance, Bundle bundle) {
        api.addPresetPoint(deviceMac, index, distance).enqueue(new ApiResultCallback(Api.Type.ADD_PRESET_POINT, bundle));
    }

    public void getAllPresetPoints() {
        api.getAllPresetPointsById(deviceId).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                LogTool.i(this, response.message());
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });
    }

    public void directionUp() {
        api.directionUp(deviceMac).enqueue(new ApiResultCallback(Api.Type.DIRECTION_UP));
    }

    public void directionDown() {
        api.directionDown(deviceMac).enqueue(new ApiResultCallback(Api.Type.DIRECTION_DOWN));
    }

    public void directionLeft() {
        api.directionLeft(deviceMac).enqueue(new ApiResultCallback(Api.Type.DIRECTION_LEFT));
    }

    public void directionRight() {
        api.directionRight(deviceMac).enqueue(new ApiResultCallback(Api.Type.DIRECTION_RIGHT));
    }

    public void directionStop() {
        api.directionStop(deviceMac).enqueue(new ApiResultCallback(Api.Type.DIRECTION_STOP));
    }

    private class ApiResultCallback implements Callback<List<ApiResult>> {

        private Api.Type type;

        private Bundle bundle;

        public ApiResultCallback(Api.Type type) {
            this(type, new Bundle());
        }

        public ApiResultCallback(Api.Type type, Bundle bundle) {
            this.type = type;
            this.bundle = bundle;
        }

        @Override
        public void onResponse(Call<List<ApiResult>> call, Response<List<ApiResult>> response) {
            LogTool.i(ApiManager.this, "name: " + type.getName());
            LogTool.i(ApiManager.this, "response: " + response);
            try {
                if (response.code() == 200) {
                    assert response.body() != null;
                    for (ApiEventListener listener : apiEventListeners) {
                        listener.onApiSuccess(new ApiResultWrapper<>(type, response.body().get(0), true), bundle);
                    }
                } else {
                    assert response.errorBody() != null;
                    for (ApiEventListener listener : apiEventListeners) {
                        listener.onApiFailed(new ApiResultWrapper<>(type, response.errorBody().string(), false), bundle);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                for (ApiEventListener listener : apiEventListeners) {
                    listener.onApiFailed(new ApiResultWrapper<>(type, e.getMessage(), false), bundle);
                }
            }
        }

        @Override
        public void onFailure(Call<List<ApiResult>> call, Throwable t) {
            t.printStackTrace();
            for (ApiEventListener listener : apiEventListeners) {
                listener.onApiFailed(new ApiResultWrapper<>(type, t.getMessage(), false), bundle);
            }
        }
    }

    public static ApiManager instance() {
        return (instance != null) ? instance : (instance = new ApiManager());
    }

}
