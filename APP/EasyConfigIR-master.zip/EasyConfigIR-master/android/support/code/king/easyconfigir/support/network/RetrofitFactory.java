package king.easyconfigir.support.network;

import android.text.TextUtils;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import king.easyconfigir.support.BuildConfig;
import king.easyconfigir.support.tool.LogTool;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitFactory {

    private static final int CONNECT_TIMEOUT = 10;
    private static final int READ_TIMEOUT = 20;
    private static final int WRITE_TIMEOUT = 20;

    protected Retrofit.Builder retrofitBuilder;

    public RetrofitFactory() {

        //OKHttp进行超时设置
        OkHttpClient.Builder builder = new OkHttpClient().newBuilder();
        builder.connectTimeout(CONNECT_TIMEOUT, TimeUnit.SECONDS); // 连接超时时间阈值
        builder.readTimeout(READ_TIMEOUT, TimeUnit.SECONDS);   // 数据获取时间阈值
        builder.writeTimeout(WRITE_TIMEOUT, TimeUnit.SECONDS);  // 写数据超时时间阈值

        builder.retryOnConnectionFailure(true);              //错误重连

        // Debug时才设置Log拦截器，才可以看到
        if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor(
                    // 添加json数据拦截
                    message -> {
                        if (TextUtils.isEmpty(message)) return;
//                        LogTool.i(this, message);
//                        如果收到响应是json才打印
                        String s = message.substring(0, 1);
                        if ("{".equals(s) || "[".equals(s)) {
                            LogTool.i(this, "message: " + message);
                        }
                    }
            );
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            builder.addInterceptor(interceptor);
        }

        // 设置 公共请求参数 如 token 设备版本 软件版本 语言
        builder.addInterceptor(new AddQueryParameterInterceptor());

        // 设置请求头 也是通过拦截器

        // 创建okhttpClient 将builder建立
        OkHttpClient okHttpClient = builder.build();

        this.retrofitBuilder = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
//                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(okHttpClient);

    }

    protected Retrofit.Builder getBuilder() {
        return this.retrofitBuilder;
    }

    // 封装rxjava
//    public void doHttpRequest(Observable pObservable, Observer observer) {
//        Observable observable = pObservable;
//        observable.subscribeOn(Schedulers.io())
//                .unsubscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(observer);                      // unchecked generify
//    }


    private static class AddQueryParameterInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Request originalRequest = chain.request();
            Request request;
            HttpUrl modifiedUrl = originalRequest.url().newBuilder()
                    // Provide your custom parameter here
//                    .addQueryParameter("token", GlobalVariable.Token)
//                    .addQueryParameter("version", GlobalVariable.VERSION)
//                    .addQueryParameter("deviceOs", GlobalVariable.DEVICE_OS)
//                    .addQueryParameter("lang", GlobalVariable.LANG)
//                    .addQueryParameter("deviceCode", GlobalVariable.DEVICE_CODE)
                    .build();
            request = originalRequest.newBuilder().url(modifiedUrl).build();
            return chain.proceed(request);
        }
    }

}
