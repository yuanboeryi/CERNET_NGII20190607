package king.easyconfigir.support.tool;

public class JsonTool extends king.easyconfigir.common.tool.JsonTool {

}
