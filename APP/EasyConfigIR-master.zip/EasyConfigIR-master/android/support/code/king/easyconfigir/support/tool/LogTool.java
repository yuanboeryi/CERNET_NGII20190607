package king.easyconfigir.support.tool;

import android.util.Log;

public class LogTool {

    public static void i(Object obj, String msg) {
        if (obj != null) {
            i(obj.getClass(), msg);
        } else {
            i("", msg);
        }
    }

    public static void i(Class<?> cls, String msg) {
        if (cls != null) {
            String name[] = cls.getName().split("\\.");
            i(name[name.length - 1], msg);
        } else {
            i("", msg);
        }
    }

    public static void i(String tag, String msg) {
        Log.i("LogTool -> " + tag, msg);
    }
}
