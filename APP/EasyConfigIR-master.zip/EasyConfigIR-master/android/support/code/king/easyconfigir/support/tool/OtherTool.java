package king.easyconfigir.support.tool;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Vibrator;
import android.provider.MediaStore;

import java.util.Objects;

public class OtherTool {

    public static void vibrate(Activity activity, long time) {
        Vibrator vibrator = (Vibrator) Objects.requireNonNull(activity).getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(time);
    }

    public static String parseUri(Context context, Intent data) {
        Uri uri = data.getData();
        String imagePath;
        assert uri != null;
        Cursor cursor = context.getContentResolver().query(uri, new String[]{MediaStore.Images.ImageColumns.DATA}, null, null, null);
        if (cursor == null) {
            imagePath = uri.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            imagePath = cursor.getString(index);
            cursor.close();
        }
        return imagePath;
    }

}
