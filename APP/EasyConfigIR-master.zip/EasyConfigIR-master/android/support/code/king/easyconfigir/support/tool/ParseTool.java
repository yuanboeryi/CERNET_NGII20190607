package king.easyconfigir.support.tool;

import android.os.Bundle;

import java.util.HashMap;

import king.easyconfigir.support.model.ScanResult;

public class ParseTool {
    public static ScanResult parseQrResult(String qrstr) {
        ScanResult scanResult = new ScanResult();
        // TODO 解析各种QR字符串, 简单轮询

        HashMap<String, String> result = TextTool.matchDeviceInfo(qrstr);
        if (result != null) {
            scanResult.setType(ScanResult.Type.DEVICE_CODE_AND_MAC);
            Bundle bundle = new Bundle();
            bundle.putString("device_code", result.get("device_code"));
            bundle.putString("device_mac", result.get("device_mac"));
            scanResult.setData(bundle);
            return scanResult;
        }

        return scanResult;
    }
}
