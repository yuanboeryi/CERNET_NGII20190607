package king.easyconfigir.support.tool;

import king.easyconfigir.common.manager.CommandSender;
import king.easyconfigir.common.model.CommandWrapper;

public class SendTool {
    public static boolean send(CommandWrapper commandWrapper) {
        if (CommandSender.instance().isCanSend() && commandWrapper != null) {
            CommandSender.instance().send(commandWrapper);
            return true;
        }
        return false;
    }
}
