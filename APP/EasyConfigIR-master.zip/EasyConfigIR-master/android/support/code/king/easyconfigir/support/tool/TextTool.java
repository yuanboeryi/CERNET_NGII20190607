package king.easyconfigir.support.tool;

public class TextTool extends king.easyconfigir.common.tool.TextTool {

}
