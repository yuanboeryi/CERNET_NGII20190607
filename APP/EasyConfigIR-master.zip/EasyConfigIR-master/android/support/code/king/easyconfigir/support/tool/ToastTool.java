package king.easyconfigir.support.tool;

import android.content.Context;
import android.widget.Toast;

public class ToastTool {
    public static void i(Context context, String message) {
         i(context, message, Toast.LENGTH_SHORT);
    }

    public static void i(Context context, String message, int time){
         Toast.makeText(context, message, time).show();
    }
}
