package king.easyconfigir.support.widget;


import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;

public class ActionBar extends Toolbar {

//    private ImageButton ibLeft;
//    private ImageButton ibRight;
//    private TextView title;

    public ActionBar(Context context) {
        this(context, null);
    }

    public ActionBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    private void initView() {
        this.setTitleTextColor(Color.WHITE);
    }

//    private void initView(Context context) {
//        LayoutInflater.from(context).inflate(R.layout.action_bar_layout, this, true);
//        ibLeft = findViewById(R.id.abl_ib_left);
//        ibRight = findViewById(R.id.abl_ib_right);
//        title = findViewById(R.id.abl_title);
//
//        ibLeft.setOnClickListener(e -> {
//            ToastTool.i(getContext(), "ibLeft");
//        });
//
//        ibRight.setOnClickListener(e -> {
//            ToastTool.i(getContext(), "ibRight");
//        });
//    }

}
