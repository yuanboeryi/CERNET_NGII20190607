package king.easyconfigir.support.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;

import king.easyconfigir.support.R;

public class BaseLayout extends LinearLayout {

    private TextView singleText;
    private TextView leftText;
    private TextView rightText;
    private EditText input;
    private Spinner spinner;
    private Button click;
    private View centerLine;
    private View bottomLine;
    private TypedArray mTypedArray;

    protected final static int INT = 0x0;
    protected final static int TEXT = 0x1;
    protected final static int COLOR = 0x2;
    protected final static int FLOAT = 0x3;
    protected final static int BOOL = 0x4;
    protected final static int RESID = 0x5;

    private TextWatcher bindToInputTextWatcher;

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId) {
        this(context, attrs, layoutId, null, 0, false, 0, false, 0, false);
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int clickId) {
        this(context, attrs, layoutId, null, clickId, true, 0, false, 0, false);
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int[] styleableId) {
        this(context, attrs, layoutId, styleableId, 0, false, 0, false, 0, false);
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int[] styleableId, int bottomLineId) {
        this(context, attrs, layoutId, styleableId, 0, false, 0, false, bottomLineId, true);
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int clickId, int centerLineId, int bottomLineId) {
        this(context, attrs, layoutId, null, clickId, true, centerLineId, true, bottomLineId, true);
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int[] styleableId, int clickId, int bottomLineId) {
        this(context, attrs, layoutId, styleableId, clickId, true, 0, false, bottomLineId, true);
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int[] styleableId, int clickId, int centerLineId, int bottomLineId) {
        this(context, attrs, layoutId, styleableId, clickId, true, centerLineId, true, bottomLineId, true);
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int[] styleableId,
                      int clickId, boolean hasClick,
                      int centerLineId, boolean hasCenterLine,
                      int bottomLineId, boolean hasBottomLine
    ) {
        this(context, attrs, layoutId, styleableId,
                0, false,
                0, 0, false,
                0, false,
                0, false,
                clickId, hasClick,
                centerLineId, hasCenterLine,
                bottomLineId, hasBottomLine);
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int[] styleableId,
                      int singleText,
                      int inputId, boolean forPart
    ) {
        this(context, attrs, layoutId, styleableId,
                singleText, true,
                0, 0, false,
                inputId, true,
                0, false,
                0, false,
                0, false,
                0, false
        );
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId,
                      int leftTextId, int rightTextId,
                      int bottomLineId,
                      boolean forSwitch
    ) {
        this(context, attrs, layoutId, null,
                0, false,
                leftTextId, rightTextId, true,
                0, false,
                0, false,
                0, false,
                0, false,
                bottomLineId, true
        );
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int[] styleableId,
                      int leftTextId, int rightTextId,
                      int inputId,
                      int bottomLineId
    ) {
        this(context, attrs, layoutId, styleableId,
                0, false,
                leftTextId, rightTextId, true,
                inputId, true,
                0, false,
                0, false,
                0, false,
                bottomLineId, true
        );
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int[] styleableId,
                      int leftTextId, int rightTextId,
                      int spinnerId,
                      boolean forSpinner,
                      boolean forSelect
    ) {
        this(context, attrs, layoutId, styleableId,
                0, false,
                leftTextId, rightTextId, true,
                0, false,
                spinnerId, true,
                0, false,
                0, false,
                0, false
        );
    }

    public BaseLayout(Context context, @Nullable AttributeSet attrs, int layoutId, int[] styleableId,
                      int singleTextId, boolean hasSingleText,
                      int leftTextId, int rightTextId, boolean hasLeftAndRightText,
                      int inputId, boolean hasInput,
                      int spinnerId, boolean hasSpinner,
                      int clickId, boolean hasClick,
                      int centerLineId, boolean hasCenterLine,
                      int bottomLineId, boolean hasBottomLine
    ) {
        super(context, attrs);
        LayoutInflater.from(context).inflate(layoutId, this, true);
        this.mTypedArray = context.obtainStyledAttributes(attrs, R.styleable.BaseLayout);
        if (hasSingleText) {
            singleText = getView(singleTextId);
            setText(getAttr(TEXT, R.styleable.BaseLayout_bl_text));
            setTextSize(getAttr(FLOAT, R.styleable.BaseLayout_bl_text_size, getRes(FLOAT, R.integer.default_text_size)));
            setTextColor(getAttr(COLOR, R.styleable.BaseLayout_bl_text_color, getRes(COLOR, R.color.default_text_color)));
        }
        if (hasLeftAndRightText) {
            leftText = getView(leftTextId);
            rightText = getView(rightTextId);
            setLeftText(getAttr(TEXT, R.styleable.BaseLayout_bl_left_text));
            setLeftTextSize(getAttr(FLOAT, R.styleable.BaseLayout_bl_left_text_size, getRes(FLOAT, R.integer.default_text_size)));
            setLeftTextColor(getAttr(COLOR, R.styleable.BaseLayout_bl_left_text_color, getRes(COLOR, R.color.default_text_color)));

            setRightText(getAttr(TEXT, R.styleable.BaseLayout_bl_right_text));
            setRightTextSize(getAttr(FLOAT, R.styleable.BaseLayout_bl_right_text_size, getRes(FLOAT, R.integer.default_text_size)));
            setRightTextColor(getAttr(COLOR, R.styleable.BaseLayout_bl_right_text_color, getRes(COLOR, R.color.default_text_color)));
        }
        if (hasInput) {
            input = getView(inputId);
            setInputText(getAttr(TEXT, R.styleable.BaseLayout_bl_input_text));
            setInputLineVisible(getAttr(BOOL, R.styleable.BaseLayout_bl_input_line_visible, true));
            setInputEditEnable(getAttr(BOOL, R.styleable.BaseLayout_bl_input_edit_enable, true));
            setInputHint(getAttr(TEXT, R.styleable.BaseLayout_bl_input_hint));
            setInputHintTextColor(getAttr(COLOR, R.styleable.BaseLayout_bl_input_hint_text_color, getRes(COLOR, R.color.default_hint_text_color)));
            setInputContentRight(getAttr(BOOL, R.styleable.BaseLayout_bl_input_content_right, false));

            if (hasAttr(R.styleable.BaseLayout_bl_input_ems)) {
                setInputEms(getAttr(INT, R.styleable.BaseLayout_bl_input_ems, 10));
            }
        }
        if (hasSpinner) {
            spinner = getView(spinnerId);
        }
        if (hasClick) {
            click = getView(clickId);
            setClickText(getAttr(TEXT, R.styleable.BaseLayout_bl_button_text));
            setClickTextSize(getAttr(FLOAT, R.styleable.BaseLayout_bl_button_text_size, getRes(FLOAT, R.integer.default_button_text_size)));
            setClickTextColor(getAttr(COLOR, R.styleable.BaseLayout_bl_button_text_color, getRes(COLOR, R.color.default_button_text_color)));
            if (hasAttr(R.styleable.BaseLayout_bl_button_background_color)) {
                setClickBackgroundColor(getAttr(COLOR, R.styleable.BaseLayout_bl_button_background_color, getRes(COLOR, R.color.default_button_background_color)));
            } else {
                setClickBackgroundResource(getAttr(RESID, R.styleable.BaseLayout_bl_button_background, R.drawable.bg_button));
            }
            click.setOnClickListener(e -> onClick());
        }
        if (hasCenterLine) {
            centerLine = getView(centerLineId);
            if (getAttr(BOOL, R.styleable.BaseLayout_bl_center_line_visible, true)) {
                centerLine.setVisibility(View.VISIBLE);
            } else {
                centerLine.setVisibility(View.GONE);
            }
        }
        if (hasBottomLine) {
            bottomLine = getView(bottomLineId);
            if (getAttr(BOOL, R.styleable.BaseLayout_bl_bottom_line_visible, true)) {
                bottomLine.setVisibility(View.VISIBLE);
            } else {
                bottomLine.setVisibility(View.GONE);
            }
        }
        onLoadView();
        this.mTypedArray.recycle();
        this.mTypedArray = null;
        if (styleableId != null) {
            this.mTypedArray = context.obtainStyledAttributes(attrs, styleableId);
            onLoadAttrs();
            this.mTypedArray.recycle();
            this.mTypedArray = null;
        }
    }

    protected void onClick() {

    }

    protected void onLoadView() {

    }

    protected void onLoadAttrs() {

    }

    protected <T> T getRes(int flag, int id) {
        T v = null;
        Resources res = getResources();
        switch (flag) {
            case TEXT:
                String ss = res.getString(id);
                if (ss == null) {
                    ss = "";
                }
                v = (T) String.valueOf(ss);
                break;
            case INT:
                v = (T) Integer.valueOf(res.getInteger(id));
                break;
            case COLOR:
                v = (T) Integer.valueOf(res.getColor(id));
                break;
            case FLOAT:
                v = (T) Float.valueOf(res.getInteger(id));
                break;
            case BOOL:
                v = (T) Boolean.valueOf(res.getBoolean(id));
                break;
            default:
                break;
        }
        return v;
    }

    protected <T> T getAttr(int flag, int id) {
        return getAttr(flag, id, 0);
    }

    protected <T, D> T getAttr(int flag, int id, D def) {
        T v = null;
        if (mTypedArray != null) {
            switch (flag) {
                case TEXT:
                    String ss = mTypedArray.getString(id);
                    if (ss == null) {
                        ss = "";
                    }
                    v = (T) String.valueOf(ss);
                    break;
                case INT:
                    v = (T) Integer.valueOf(mTypedArray.getInteger(id, (Integer) def));
                    break;
                case COLOR:
                    v = (T) Integer.valueOf(mTypedArray.getColor(id, (Integer) def));
                    break;
                case FLOAT:
                    v = (T) Float.valueOf(mTypedArray.getFloat(id, (Float) def));
                    break;
                case BOOL:
                    v = (T) Boolean.valueOf(mTypedArray.getBoolean(id, (Boolean) def));
                    break;
                case RESID:
                    v = (T) Integer.valueOf(mTypedArray.getResourceId(id, (Integer) def));
                    break;
                default:
                    break;
            }
        }
        return v;
    }

    protected <T> T getView(int id) {
        return (T) this.findViewById(id);
    }

    protected boolean hasAttr(int id) {
        if (mTypedArray != null) {
            return mTypedArray.hasValue(id);
        }
        return false;
    }

    private void setText(View v, String text) {
//        if (v == null) return;
        if (v instanceof Button) {
            ((Button) v).setText(text);
        } else if (v instanceof EditText) {
            ((EditText) v).setText(text);
        } else if (v instanceof TextView) {
            ((TextView) v).setText(text);
        }
    }

    private void setTextSize(View v, float size) {
//        if (v == null) return;
        if (v instanceof TextView) {
            ((TextView) v).setTextSize(size);
        } else if (v instanceof EditText) {
            ((EditText) v).setTextSize(size);
        } else if (v instanceof Button) {
            ((Button) v).setTextSize(size);
        }
    }

    private void setTextColor(View v, int color) {
//        if (v == null) return;
        if (v instanceof TextView) {
            ((TextView) v).setTextColor(color);
        } else if (v instanceof EditText) {
            ((EditText) v).setTextColor(color);
        } else if (v instanceof Button) {
            ((Button) v).setTextColor(color);
        }
    }

    private void setBackgroundColor(View v, int color) {
//        if (v == null) return;
        if (v instanceof TextView) {
            ((TextView) v).setBackgroundColor(color);
        } else if (v instanceof EditText) {
            ((EditText) v).setBackgroundColor(color);
        } else if (v instanceof Button) {
            ((Button) v).setBackgroundColor(color);
        }
    }

    private void setBackgroundResource(View v, int resid) {
//        if (v == null) return;
        if (v instanceof TextView) {
            ((TextView) v).setBackgroundResource(resid);
        } else if (v instanceof EditText) {
            ((EditText) v).setBackgroundResource(resid);
        } else if (v instanceof Button) {
            ((Button) v).setBackgroundResource(resid);
        }
    }

    public void setText(String title) {
        setText(this.singleText, title);
    }

    public void setTextSize(float size) {
        setTextSize(this.singleText, size);
    }

    public void setTextColor(int color) {
        setTextColor(this.singleText, color);
    }

    public void setLeftText(String title) {
        setText(this.leftText, title);
    }

    public void setLeftTextSize(float size) {
        setTextSize(this.leftText, size);
    }

    public void setLeftTextColor(int color) {
        setTextColor(this.leftText, color);
    }

    public void setRightText(String title) {
        setText(this.rightText, title);
    }

    public void setRightTextSize(float size) {
        setTextSize(this.rightText, size);
    }

    public void setRightTextColor(int color) {
        setTextColor(this.rightText, color);
    }

    public void setInputText(String text) {
        setText(this.input, text);
    }

    public void setInputEditEnable(boolean enable) {
        this.input.setEnabled(enable);
    }

    public void setInputHint(String hint) {
        this.input.setHint(hint);
    }

    public void setInputHintTextColor(int color) {
        this.input.setHintTextColor(color);
    }

    public void setInputEms(int ems) {
        this.input.setEms(ems);
    }

    public void setInputLineVisible(boolean visible) {
        if (!visible) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                this.input.setBackground(null);
            }
        }
    }

    public void setInputContentRight(boolean enable) {
        if (enable) {
            this.input.setGravity(Gravity.RIGHT);
        }
    }

    public void setClickText(String title) {
        setText(this.click, title);
    }

    public void setClickTextSize(float size) {
        setTextSize(this.click, size);
    }

    public void setClickTextColor(int color) {
        setTextColor(this.click, color);
    }

    public void setClickBackgroundColor(int color) {
        setBackgroundColor(this.click, color);
    }

    public void setClickBackgroundResource(int resid) {
        setBackgroundResource(this.click, resid);
    }

    public void setClickListener(OnClickListener onClickListener) {
        this.click.setOnClickListener(onClickListener);
    }

    public void setClickEnable(boolean enable) {
        this.click.setEnabled(enable);
    }

    public String getInputValue() {
        return input.getText().toString();
    }

    public Spinner getSpinner() {
        return spinner;
    }

    public void setInputTextChangedListener(TextWatcher tw) {
        this.bindToInputTextWatcher = tw;
        this.input.addTextChangedListener(tw);
    }

    public void maybeClearInputTextChangedListener() {
        if (this.bindToInputTextWatcher != null) {
            this.input.removeTextChangedListener(this.bindToInputTextWatcher);
            this.bindToInputTextWatcher = null;
        }
    }

}
