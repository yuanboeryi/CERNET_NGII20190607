package king.easyconfigir.support.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import king.easyconfigir.support.R;
import king.easyconfigir.support.adapter.TimeAdapter;
import king.easyconfigir.support.model.TimeEntity;
import king.easyconfigir.support.tool.ToastTool;

public class CaptureLayout extends BaseLayout {

    private SelectLayout topSelect;
    private SelectLayout bottomSelect;

    public CaptureLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs, R.layout.capture_layout, R.id.cl_button, R.id.cl_center_line, R.id.cl_bottom_line);
    }

    @Override
    protected void onLoadView() {
        super.onLoadView();
        topSelect = getView(R.id.cl_top_select);
        bottomSelect = getView(R.id.cl_bottom_select);
        initTopSelect();
        initBottomSelect();
    }

    @Override
    protected void onClick() {
        super.onClick();
        String ss[] = getSelectValue();
        ToastTool.i(getContext(), ss[0] + " : " + ss[1]);
    }

    private void initTopSelect() {
        List<TimeEntity> list = new ArrayList<>();
        forTimeEntity(list, 0, 4, 30, 30, 30);
        TimeAdapter timeAdapter = new TimeAdapter(getContext(), list);
        Spinner spinner = topSelect.getSpinner();
        spinner.setAdapter(timeAdapter);
    }

    private void initBottomSelect() {
        List<TimeEntity> list = new ArrayList<>();
        forTimeEntity(list, 0, 4, 15, 15, 15);
        forTimeEntity(list, 0, 2, 90, 30, 15);
        TimeAdapter timeAdapter = new TimeAdapter(getContext(), list);
        Spinner spinner = bottomSelect.getSpinner();
        spinner.setAdapter(timeAdapter);
    }

    private void forTimeEntity(List<TimeEntity> list, int start, int end, int first, int step, int per) {
        for (int i = start; i < end; i++) {
            int v = first + step * i;
            list.add(new TimeEntity(String.valueOf(v), (v / per)));
        }
    }

    private int pickSelectTimeValue(SelectLayout selectLayout) {
        if (selectLayout != null) {
            Spinner spinner = selectLayout.getSpinner();
            TimeEntity te = (TimeEntity) spinner.getSelectedItem();
            if (te != null) {
                return te.getValue();
            }
        }
        return 0;
    }

    public String[] getSelectValue() {
        return new String[]{
                String.valueOf(pickSelectTimeValue(topSelect)),
                String.valueOf(pickSelectTimeValue(bottomSelect))
        };
    }
}
