package king.easyconfigir.support.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;

import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.common.manager.CommandSender;
import king.easyconfigir.support.R;
import king.easyconfigir.support.model.ApiResultWrapper;
import king.easyconfigir.support.network.Api;
import king.easyconfigir.support.network.ApiManager;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.SendTool;
import king.easyconfigir.support.tool.ToastTool;

public class DirectionControlLayout extends BaseLayout implements ApiManager.ApiEventListener {

    private Button left;
    private Button right;
    private Button up;
    private Button down;
    private Button stop;

    public DirectionControlLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs, R.layout.direction_control_layout);
    }

    @Override
    protected void onLoadView() {
        super.onLoadView();
        left = getView(R.id.dcl_left);
        right = getView(R.id.dcl_right);
        up = getView(R.id.dcl_up);
        down = getView(R.id.dcl_down);
        stop = getView(R.id.dcl_stop);
        initButtons();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void initButtons() {
        left.setOnTouchListener(this::onTouch);
        right.setOnTouchListener(this::onTouch);
        up.setOnTouchListener(this::onTouch);
        down.setOnTouchListener(this::onTouch);
        stop.setOnTouchListener(this::onTouch);
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (view == left) {
            doAction(0, action, "左转");
        } else if (view == right) {
            doAction(1, action, "右转");
        } else if (view == up) {
            doAction(2, action, "上转");
        } else if (view == down) {
            doAction(3, action, "下转");
        } else if (view == stop) {
            doAction(4, action, "停止");
        }
        return false;
    }

    private void doAction(int flag, int action, String msg) {
//        if (!CommandSender.instance().isStart()) {
//            ToastTool.i(getContext(), "设备未连接", 300);
//            return;
//        }
        if (!ApiManager.instance().checkDeviceMac()) {
            ToastTool.i(getContext(), "设备MAC不能为空", 300);
            return;
        }
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                switch (flag) {
                    case 0:
                        directionLeft();
                        break;
                    case 1:
                        directionRight();
                        break;
                    case 2:
                        directionUp();
                        break;
                    case 3:
                        directionDown();
                        break;
                    case 4:
                        directionStop();
                        break;
                }
                LogTool.i(this, "doAction: flag: " + flag + " 按下 " + msg);
                break;
            case MotionEvent.ACTION_UP:
                directionStop();
                LogTool.i(this, "doAction: flag: " + flag + " 抬起 " + msg);
                break;
            default:
                break;
        }
    }

    private void directionUp() {
//        SendTool.send(CommandFactory.instance().commandDirectionUp());
        ApiManager.instance().directionUp();
    }

    private void directionDown() {
//        SendTool.send(CommandFactory.instance().commandDirectionDown());
        ApiManager.instance().directionDown();
    }

    private void directionLeft() {
//        SendTool.send(CommandFactory.instance().commandDirectionLeft());
        ApiManager.instance().directionLeft();
    }

    private void directionRight() {
//        SendTool.send(CommandFactory.instance().commandDirectionRight());
        ApiManager.instance().directionRight();
    }

    private void directionStop() {
//        SendTool.send(CommandFactory.instance().commandDirectionStop());
        ApiManager.instance().directionStop();
    }

    @Override
    public void onApiSuccess(ApiResultWrapper wrapper, Bundle bundle) {
        Api.Type type = wrapper.getType();
        switch (type) {
            case DIRECTION_UP:
            case DIRECTION_DOWN:
            case DIRECTION_LEFT:
            case DIRECTION_RIGHT:
            case DIRECTION_STOP:
                ToastTool.i(getContext(), type.getName() + "成功");
                break;
            default:
                break;
        }
    }

    @Override
    public void onApiFailed(ApiResultWrapper wrapper, Bundle bundle) {
        Api.Type type = wrapper.getType();
        switch (type) {
            case DIRECTION_UP:
            case DIRECTION_DOWN:
            case DIRECTION_LEFT:
            case DIRECTION_RIGHT:
            case DIRECTION_STOP:
//                ToastTool.i(getContext(), "服务异常");
                LogTool.i(this, (String) wrapper.getData());
                break;
            default:
                break;
        }
    }
}
