package king.easyconfigir.support.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import king.easyconfigir.support.R;

public class DoubleLayout extends BaseLayout {

    private PartLayout topPart;
    private PartLayout bottomPart;

    public DoubleLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs, R.layout.double_layout, R.styleable.DoubleLayout, R.id.dl_button, R.id.dl_center_line, R.id.dl_bottom_line);
    }

    @Override
    protected void onLoadView() {
        super.onLoadView();
        topPart = getView(R.id.dl_top_part);
        bottomPart = getView(R.id.dl_bottom_part);
    }

    @Override
    protected void onLoadAttrs() {
        super.onLoadAttrs();
        topPart.setText(getAttr(TEXT, R.styleable.DoubleLayout_dl_top_text));
        topPart.setTextSize(getAttr(FLOAT, R.styleable.DoubleLayout_dl_top_text_size, getRes(FLOAT, R.integer.default_text_size)));
        topPart.setTextColor(getAttr(COLOR, R.styleable.DoubleLayout_dl_top_text_color, getRes(COLOR, R.color.default_text_color)));

        bottomPart.setText(getAttr(TEXT, R.styleable.DoubleLayout_dl_bottom_text));
        bottomPart.setTextSize(getAttr(FLOAT, R.styleable.DoubleLayout_dl_bottom_text_size, getRes(FLOAT, R.integer.default_text_size)));
        bottomPart.setTextColor(getAttr(COLOR, R.styleable.DoubleLayout_dl_bottom_text_color, getRes(COLOR, R.color.default_text_color)));
    }

    public String[] getDoubleInputValue() {
        return new String[]{
                this.topPart.getInputValue(),
                this.bottomPart.getInputValue()
        };
    }

}
