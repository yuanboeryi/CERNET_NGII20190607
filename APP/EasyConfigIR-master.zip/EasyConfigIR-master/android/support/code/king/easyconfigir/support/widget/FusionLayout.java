package king.easyconfigir.support.widget;

import android.content.Context;
import android.provider.Telephony;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.Spinner;

import androidx.annotation.Nullable;

import king.easyconfigir.support.R;
import king.easyconfigir.support.tool.ToastTool;

public class FusionLayout extends BaseLayout {
    private PartLayout SPart;
    private PartLayout RPart;
    private PartLayout LPart;
    private PartLayout TPart;

    public FusionLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs, R.layout.fusion_layout, R.id.fl_button, R.id.fl_center_line, R.id.fl_bottom_line);
    }

    @Override
    protected void onLoadView() {
        super.onLoadView();
        SPart = getView(R.id.fl_s_part);
        RPart = getView(R.id.fl_r_part);
        LPart = getView(R.id.fl_l_part);
        TPart = getView(R.id.fl_t_part);
    }

    @Override
    protected void onClick() {
        super.onClick();
        String ss = "S: " + SPart.getInputValue() + " R: " + RPart.getInputValue() + " L: " + LPart.getInputValue() + " T: " + TPart.getInputValue();
        ToastTool.i(getContext(), ss);
    }

    public String[] getFusionValue() {
        return new String[]{
                SPart.getInputValue(),
                RPart.getInputValue(),
                LPart.getInputValue(),
                TPart.getInputValue()
        };
    }
}
