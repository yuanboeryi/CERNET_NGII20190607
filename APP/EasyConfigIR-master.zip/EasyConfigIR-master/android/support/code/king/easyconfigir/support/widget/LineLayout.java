package king.easyconfigir.support.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

import king.easyconfigir.support.R;

public class LineLayout extends BaseLayout {
    private PartLayout part;

    private OnLineClickEvent onLineClickEvent;

    public interface OnLineClickEvent {
        void onClick(String inputValue);
    }

    public void setOnLineClickEvent(OnLineClickEvent onLineClickEvent) {
        this.onLineClickEvent = onLineClickEvent;
    }

    public LineLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs, R.layout.line_layout, R.styleable.LineLayout, R.id.ll_button, R.id.ll_bottom_line);
    }

    @Override
    protected void onLoadView() {
        super.onLoadView();
        part = getView(R.id.ll_part);
    }

    @Override
    protected void onLoadAttrs() {
        super.onLoadAttrs();
        part.setText(getAttr(TEXT, R.styleable.LineLayout_ll_text));
        part.setTextSize(getAttr(FLOAT, R.styleable.LineLayout_ll_text_size, getRes(FLOAT, R.integer.default_text_size)));
        part.setTextColor(getAttr(COLOR, R.styleable.LineLayout_ll_text_color, getRes(COLOR, R.color.default_text_color)));
    }

    @Override
    protected void onClick() {
        super.onClick();
        if (onLineClickEvent != null) {
            onLineClickEvent.onClick(getInputValue());
        }
    }

    @Override
    public void setInputEditEnable(boolean enable) {
        this.part.setInputEditEnable(enable);
    }


    @Override
    public void setInputText(String value) {
        this.part.setInputText(value);
    }

    @Override
    public String getInputValue() {
        return this.part.getInputValue();
    }

}
