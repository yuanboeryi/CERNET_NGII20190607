package king.easyconfigir.support.widget;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.Nullable;

import king.easyconfigir.support.R;

public class LineTagLayout extends BaseLayout {

    public LineTagLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs,
                R.layout.line_tag_layout,
                null,
                R.id.ltl_left_text,
                R.id.ltl_right_text,
                R.id.ltl_input,
                R.id.ltl_bottom_line
        );
    }

}
