package king.easyconfigir.support.widget;

import android.content.Context;
import android.util.AttributeSet;

import king.easyconfigir.support.R;

public class PartLayout extends BaseLayout {

    public PartLayout(Context context, AttributeSet attrs) {
        super(context, attrs,
                R.layout.part_layout,
                null,
                R.id.pl_text,
                R.id.pl_input,
                true
        );
    }
}
