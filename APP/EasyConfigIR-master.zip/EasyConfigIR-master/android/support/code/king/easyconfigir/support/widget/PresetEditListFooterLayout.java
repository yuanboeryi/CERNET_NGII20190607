package king.easyconfigir.support.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Button;

import androidx.annotation.Nullable;

import king.easyconfigir.support.R;
import king.easyconfigir.support.tool.ToastTool;

public class PresetEditListFooterLayout extends BaseLayout {

    private PresetEditListLayout presetEditListLayout;

    public PresetEditListFooterLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs, R.layout.preset_edit_list_footer_layout, R.id.pefl_button);
    }

    @Override
    protected void onClick() {
        super.onClick();
        presetEditListLayout.addDevice();
    }

    public void setPresetEditListLayout(PresetEditListLayout presetEditListLayout) {
        this.presetEditListLayout = presetEditListLayout;
    }

    static class Builder {
        private BaseLayout layout;
        private AttributeSet attrs;

        public Builder() {

        }

        public PresetEditListFooterLayout create() {
            PresetEditListFooterLayout footerLayout = new PresetEditListFooterLayout(this.layout.getContext(), this.attrs);
            footerLayout.setClickText(layout.getRes(TEXT, R.string.add_device));
            footerLayout.setClickTextColor(layout.getRes(COLOR, R.color.add_device_button_text_color));
            footerLayout.setClickTextSize(layout.getRes(FLOAT, R.integer.default_text_size));
            footerLayout.setClickBackgroundColor(layout.getRes(COLOR, R.color.add_device_button_color));
            footerLayout.setPresetEditListLayout((PresetEditListLayout) layout);
            return footerLayout;
        }

        public Builder setLayout(BaseLayout layout) {
            this.layout = layout;
            return this;
        }

        public Builder setAttrs(AttributeSet attrs) {
            this.attrs = attrs;
            return this;
        }
    }
}
