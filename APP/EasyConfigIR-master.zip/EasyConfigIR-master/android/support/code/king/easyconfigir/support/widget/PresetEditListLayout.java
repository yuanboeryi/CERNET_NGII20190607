package king.easyconfigir.support.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import king.easyconfigir.support.R;
import king.easyconfigir.support.adapter.DeviceAdapter;
import king.easyconfigir.support.model.Device;
import king.easyconfigir.support.tool.LogTool;
import king.easyconfigir.support.tool.ToastTool;

public class PresetEditListLayout extends BaseLayout {

    private List<Device> listData;
    private ListView presetEditList;
    private DeviceAdapter deviceAdapter;

    private final static boolean IS_LIMIT_MAX_DEVICE_COUNT = true;
    private final static int MAX_DEVICE_COUNT = 255;

    private PresetEditListFooterLayout.Builder builder = new PresetEditListFooterLayout.Builder();

    public PresetEditListLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs, R.layout.preset_edit_list_layout);
        builder.setLayout(this).setAttrs(attrs);
        initPresetEditList();
    }

    @Override
    protected void onLoadView() {
        super.onLoadView();
        presetEditList = getView(R.id.pell_list);
    }

    public void addDevice() {
        int position = getSize() + 1;
        if (position > MAX_DEVICE_COUNT && IS_LIMIT_MAX_DEVICE_COUNT) {
            ToastTool.i(getContext(), String.format(getRes(TEXT, R.string.limit_device_count_warn), MAX_DEVICE_COUNT));
            return;
        }
        forDevice(1);
        fresh();
        // 滑动到底部
        presetEditList.setSelection(presetEditList.getBottom());
//        ToastTool.i(getContext(), String.format(getRes(TEXT, R.string.add_device_info), position), 200);
        LogTool.i("LogTool", Arrays.toString(listData.toArray()));
    }

    public void deleteDevice(int position) {
        listData.remove(position - 1);
        fresh();
//        ToastTool.i(getContext(), String.format(getRes(TEXT, R.string.delete_device_info), position), 200);
    }

    public void empty() {
        listData.clear();
        fresh();
    }

    public int getSize() {
        return listData.size();
    }

    private void initPresetEditList() {
        listData = new ArrayList<>();
        forDevice(1);
        deviceAdapter = new DeviceAdapter(getContext(), listData);
        deviceAdapter.setOnViewEvent(this::deleteDevice);
        presetEditList.addFooterView(builder.create());
        presetEditList.setAdapter(deviceAdapter);
    }

    private void forDevice(int count) {
        for (int i = 0; i < count; i++) {
            Device device = new Device();
            device.setTag(getRes(TEXT, R.string.default_device_tag));
            device.setName(getRes(TEXT, R.string.default_device_name));
//            device.setWarnTemperature("80");
//            device.setDistance("4");
            device.setLookPoint((i % 2 == 0));
            device.setTrack((i % 3 == 0));
//            device.setWarnTemperature(String.valueOf(i + 80));
//            device.setDistance(String.valueOf(i + 5));
            listData.add(device);
        }
    }

    public void fresh() {
        deviceAdapter.notifyDataSetChanged();
    }

    public List<Device> getListData() {
        return listData;
    }
}
