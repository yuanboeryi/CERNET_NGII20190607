package king.easyconfigir.support.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import king.easyconfigir.support.R;
import king.easyconfigir.support.adapter.PresetAdapter;
import king.easyconfigir.support.model.PresetPoint;

public class PresetListLayout extends BaseLayout {

    private ListView presetList;
    private PresetAdapter presetAdapter;

    private List<PresetPoint> presetPoints;

    public PresetListLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs, R.layout.preset_list_layout);
    }

    @Override
    protected void onLoadView() {
        super.onLoadView();
        presetList = getView(R.id.pll_list);
        initPresetList();
    }

    private void initPresetList() {
        presetPoints = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            PresetPoint presetPoint = new PresetPoint("预设点" + (i + 1));

//            presetPoint.setAdd((i % 2 == 0));

            presetPoints.add(presetPoint);
        }
        presetAdapter = new PresetAdapter(getContext(), presetPoints);
        presetList.setAdapter(presetAdapter);
    }

    public void setPresetAdapterEvent(PresetAdapter.PresetAdapterEvent presetAdapterEvent) {
        this.presetAdapter.setPresetAdapterEvent(presetAdapterEvent);
    }

    public void fresh() {
        this.presetAdapter.notifyDataSetChanged();
    }

    public void setPresetPointAddStateByPosition(boolean isAdd, int position) {
        presetPoints.get(position - 1).setAdd(isAdd);
        fresh();
    }
}
