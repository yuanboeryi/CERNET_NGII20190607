package king.easyconfigir.support.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import king.easyconfigir.support.R;
import king.easyconfigir.support.tool.LogTool;

import static android.widget.AdapterView.*;

public class SelectLayout extends BaseLayout {

    public SelectLayout(Context context, AttributeSet attrs) {
        super(context, attrs,
                R.layout.select_layout,
                null,
                R.id.sl_left_text,
                R.id.sl_right_text,
                R.id.sl_spinner,
                true,
                true
        );

    }

    public void test() {
        getSpinner().setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                view.setBackgroundColor(Color.DKGRAY);
                LogTool.i("test", "onSelect " + i + " " + l);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}
