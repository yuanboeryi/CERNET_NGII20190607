package king.easyconfigir.support.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

import king.easyconfigir.support.R;

public class SwitchLayout extends BaseLayout {

    private ImageView iv;
    private ObjectAnimator objectAnimator;
    private boolean flag = false;
    private final static long DEFAULT_DURATION = 200;

    private OnFlagEvent onFlagEvent;

    public interface OnFlagEvent {
        void onChanged(boolean flag);
    }

    public void setOnFlagEvent(OnFlagEvent onFlagEvent) {
        this.onFlagEvent = onFlagEvent;
    }

    public SwitchLayout(Context context, AttributeSet attrs) {
        super(context, attrs,
                R.layout.switch_layout,
                R.id.swl_left_text,
                R.id.swl_right_text,
                R.id.swl_bottom_line,
                true
        );
    }

    @Override
    protected void onLoadView() {
        super.onLoadView();
        iv = getView(R.id.swl_iv);
        initListener();
        initAnim();
    }

    public boolean isFlag() {
        return flag;
    }

    private void initAnim() {
        objectAnimator = new ObjectAnimator();
        objectAnimator.setTarget(this);
        objectAnimator.setPropertyName("IVRotation");
        objectAnimator.setDuration(DEFAULT_DURATION);
        objectAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                flag = !flag;
                checkFlag();
                if (onFlagEvent != null) {
                    onFlagEvent.onChanged(flag);
                }
            }
        });
    }

    private void initListener() {
        iv.setOnClickListener(e -> {
            if (flag) {
                objectAnimator.setFloatValues(-180f, 0f);
            } else {
                objectAnimator.setFloatValues(0f, -180f);
            }
            objectAnimator.start();
        });
    }

    public void setFlag(boolean f) {
        if (this.flag != f) {
            iv.callOnClick();
        }
    }

    public void maybeClearOnFlagEventListener() {
        if (onFlagEvent != null) {
            onFlagEvent = null;
        }
    }

    private void checkFlag() {
        if (flag) {
            setRightText(getRes(TEXT, R.string.switch_yes));
        } else {
            setRightText(getRes(TEXT, R.string.switch_no));
        }
    }

    public void setIVRotation(float f) {
        this.iv.setRotation(f);
    }
}
