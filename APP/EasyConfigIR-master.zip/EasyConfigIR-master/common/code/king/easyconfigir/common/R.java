package king.easyconfigir.common;

public class R {

    public class value {
        public final static String DEFAULT_DEVICE_ID = "hi00000001";
        public final static int DEFAULT_TIMEOUT = 10000;
        public final static String DEFAULT_HOST = "192.168.8.100";
        public final static String DEFAULT_COMMAND_PORT = "12345";
        public final static String DEFAULT_MEDIA_HOST = "39.98.142.122";
        public final static String DEFAULT_MEDIA_PORT = "3389";

        // 跳过指令发送 dry-run
        public final static boolean DISABLED_SOCKET_SEND = false;
    }

}
