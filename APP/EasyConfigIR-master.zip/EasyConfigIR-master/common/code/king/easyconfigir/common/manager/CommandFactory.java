package king.easyconfigir.common.manager;

import java.util.ArrayList;
import java.util.List;

import king.easyconfigir.common.R;
import king.easyconfigir.common.model.Command;
import king.easyconfigir.common.model.CommandWrapper;
import king.easyconfigir.common.model.Message;
import king.easyconfigir.common.tool.TextTool;

public class CommandFactory {

    private String deviceID;
    private String mediaHost;
    private String mediaPort;

    private CommandWrapper.Type currentType;

    private static CommandFactory instance;

    private CommandFactory() {
        this(R.value.DEFAULT_DEVICE_ID, CommandWrapper.Type.HS);
    }

    public CommandFactory(String deviceID, CommandWrapper.Type type) {
        this.deviceID = deviceID;
        this.currentType = type;
        this.mediaHost = R.value.DEFAULT_MEDIA_HOST;
        this.mediaPort = R.value.DEFAULT_MEDIA_PORT;
    }

    public static CommandFactory instance() {
        return (instance != null) ? instance : (instance = new CommandFactory());
    }

    public String getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public String getMediaHost() {
        return mediaHost;
    }

    public void setMediaHost(String mediaHost) {
        this.mediaHost = mediaHost;
    }

    public String getMediaPort() {
        return mediaPort;
    }

    public void setMediaPort(String mediaPort) {
        this.mediaPort = mediaPort;
    }

    public String getMediaAddress() {
        return getMediaHost()+":"+getMediaPort();
    }

    public CommandWrapper.Type getCurrentType() {
        return currentType;
    }

    public void setCurrentType(CommandWrapper.Type currentType) {
        this.currentType = currentType;
    }

    // 云台停止指令：0x00
    public CommandWrapper commandDirectionStop() {
        return direction("云台停止指令", "0x00");
    }

    // 云台右转指令：0x02
    public CommandWrapper commandDirectionRight() {
        return direction("云台右转指令", "0x02");
    }

    // 设置预设点指令：0x03
    public CommandWrapper commandPresetPointSet(String p0, String p1) {
        return command("设置预设点指令", "0x03",
                Integer.valueOf(p0),
                Integer.valueOf(p1)
        );
    }

    // 云台左转指令：0x04
    public CommandWrapper commandDirectionLeft() {
        return direction("云台左转指令", "0x04");
    }

    // 清除预设点指令：0x05
    public CommandWrapper commandPresetPointClear(String p0) {
        return command("清除预设点指令", "0x05",
                Integer.valueOf(p0)
        );
    }

    // 调用预设点指令：0x07
    public CommandWrapper commandPresetPointCall(String p0) {
        return command("调用预设点指令", "0x07", p0);
    }

    // 获取当前红外帧指令：0x80
    public CommandWrapper commandCaptureIRFrame() {
        return command("获取当前红外帧指令", "0x80");
    }

    // 设置存储图片色带指令： 0x81
    public CommandWrapper commandPictureColorSet(String p0) {
        return command("设置存储图片色带指令", "0x81",
                Integer.valueOf(p0)
        );
    }

    // 设置守望点指令：0x97
    public CommandWrapper commandLookupPointSet(String p0) {
        return command("设置守望点指令", "0x97",
                Integer.valueOf(p0)
        );
    }

    // 扫描所有预设点指令：0x9a
    public CommandWrapper commandAllPresetPointScan() {
        return command("扫描所有预设点指令", "0x9a");
    }

    // 启动云台校准指令：0x9b
    public CommandWrapper commandCloudAdjust() {
        return command("启动云台校准指令", "0x9b");
    }

    // 设置守望点高温告警温度指令：0x9c
    public CommandWrapper commandLookupPointWarnTemperature(String p0) {
        return command("设置守望点高温告警温度指令", "0x9c", p0);
    }

    // 设置服务器地址指令：0x9d
    public CommandWrapper commandServerAddressSet(String p0, String p1) {
        return command("设置服务器地址指令", "0x9d", p0, p1);
    }

    // 云台上转指令：0xA0
    public CommandWrapper commandDirectionUp() {
        return direction("云台上转指令", "0xA0");
    }

    // 云台下转指令：0xA1
    public CommandWrapper commandDirectionDown() {
        return direction("云台下转指令", "0xA1");
    }

    // 全预设点清除指令：0xA2
    public CommandWrapper commandAllPresetPointClear() {
        return command("全预设点清除指令", "0xA2");
    }

    // wifi配置指令：0xA3
    public CommandWrapper commandWifiSet(String p0, String p1) {
        return command("wifi配置指令", "0xA3", p0, p1);
    }

    // 复位参数配置指令：0xA4
    public CommandWrapper commandArgsReset() {
        return command("复位参数配置指令", "0xA4");
    }

    // 设置辐射率指令：0xA5
    public CommandWrapper commandEmissivitySet(String p0) {
        return command("设置辐射率指令", "0xA5", p0);
    }

    // 复位系统指令：0xA6
    public CommandWrapper commandOSReset() {
        return command("复位系统指令", "0xA6");
    }

    // 配置ssh参数指令：0xA8
    public CommandWrapper commandSSH(String p0, String p1) {
        return command("配置ssh参数指令", "0xA8", p0,
                Integer.valueOf(p1)
        );
    }

    // 设置红外呈现参数指令：0xA9
    public CommandWrapper commandIRShowArgs(String p0) {
        return command("设置红外呈现参数指令", "0xA9", p0);
    }

    // 设置红外勾边参数指令：0xAA
    public CommandWrapper commandIRSideArgs(String p0) {
        return command("设置红外勾边参数指令", "0xAA", p0);
    }

    // 设置红外融合偏移指令：0xAB
    public CommandWrapper commandIROffset(String p0, String p1) {
        return command("设置红外融合偏移指令", "0xAB", p0, p1);
    }

    // 设置红外融合旋转和放大参数指令：0xAC
    public CommandWrapper commandIRRotationAndEnlarge(String p0, String p1) {
        return command("设置红外融合旋转和放大参数指令", "0xAC", p0, p1);
    }

    // 重启ssh服务指令：0xAD
    public CommandWrapper commandSSHRestart() {
        return command("重启ssh服务指令", "0xAD");
    }

    // 测温区域设定指令：0xAE
    public CommandWrapper commandRegionSet(String p0) {
        return command("测温区域设定指令", "0xAE", p0);
    }

    // 测温区域清除指令：0xAF
    public CommandWrapper commandRegionClear(String p0) {
        return command("测温区域清除指令", "0xAF", p0);
    }

    // 修改预设点距离指令：0xB0
    public CommandWrapper commandPresetPointDistanceModify(String p0, String p1) {
        return command("修改预设点距离指令", "0xB0", p0, p1);
    }

    // 周期预设点扫描开关指令：0xB2
    public CommandWrapper commandPresetPointScanSwitcher(String p0) {
        return command("周期预设点扫描开关指令", "0xB2", p0);
    }

    // 远程程序更新指令：0xB3
    public CommandWrapper commandRemoteUpdate(String p0, String p1) {
        return command("远程程序更新指令", "0xB3", p0, p1);
    }

    // 设置巡检和拍图周期指令：0xB4
    public CommandWrapper commandInspectionAndShootingCycle(String p0, String p1) {
        return command("设置巡检和拍图周期指令", "0xB4", p0, p1);
    }

    // 开启/关闭视频推流指令：0xB5
    public CommandWrapper commandRtspSwitcher(String p0) {
        return command("开启/关闭视频推流指令", "0xB5", p0, getMediaAddress());
    }

    // 系统时间校准指令：0xB6
    public CommandWrapper commandOSTimeAdjust(String p0) {
        return command("系统时间校准指令", "0xB6", p0);
    }

    // 修改设备ID号指令：0xB7
    public CommandWrapper commandDeviceIDModify(String p0) {
        return command("修改设备ID号指令", "0xB7", p0);
    }

    // 测温区域边界呈现指令：0xB8
    public CommandWrapper commandRegionOutlook(String p0) {
        return command("测温区域边界呈现指令", "0xB8", p0);
    }

    // 继电器开关控制指令：0x01
    public CommandWrapper commandRelaySwitcher(String p0) {
        return command("继电器开关控制指令", "0x01", p0);
    }

    public CommandWrapper direction(String name, String p0) {
        List<Message> data = new ArrayList<>();
        data.add(new Message(0x00, "", ""));
        data.add(new Message(TextTool.convertHexStr(p0), "", ""));
        return new CommandWrapper(name, new Command(deviceID, data), CommandWrapper.Type.HS);
    }

    public CommandWrapper command(String name, String p0) {
        return command(name, p0, "", "");
    }

    public <V> CommandWrapper command(String name, String p0, V p1) {
        return command(name, p0, p1, "");
    }

    public <V, S> CommandWrapper command(String name, String p0, V p1, S p2) {
        return command(name, p0, p1, p2, currentType);
    }

    public <V, S> CommandWrapper command(String name, String p0, V p1, S p2, CommandWrapper.Type type) {
        List<Message> data = new ArrayList<>();
        data.add(new Message(TextTool.convertHexStr(p0), p1, p2));
        return new CommandWrapper(name, new Command(deviceID, data), type);
    }

}
