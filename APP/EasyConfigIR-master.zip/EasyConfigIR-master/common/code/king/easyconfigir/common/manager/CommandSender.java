package king.easyconfigir.common.manager;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import king.easyconfigir.common.R;
import king.easyconfigir.common.model.Command;
import king.easyconfigir.common.model.CommandWrapper;
import king.easyconfigir.common.tool.JsonTool;
import king.easyconfigir.common.tool.LogTool;

public class CommandSender implements Runnable {

    private String host;
    private String port;
    private Thread sendThread;
    private Queue<CommandWrapper> commandQueue;
    private boolean isStart = false;
    private boolean isCanSend = false;
    private List<OnSenderEvent> onSenderEventList;
    private final static String TAG = "CommandSender";

    private Socket socket;
    private int timeout;
    private boolean disabledSocketSend;

    private final static CommandSender instance = new CommandSender();

    public CommandSender() {
        this(R.value.DEFAULT_TIMEOUT, R.value.DISABLED_SOCKET_SEND);
    }

    public CommandSender(int timeout, boolean disabledSocketSend) {
        this(R.value.DEFAULT_HOST, R.value.DEFAULT_COMMAND_PORT, timeout, disabledSocketSend);
    }

    public CommandSender(String host, String port, int timeout, boolean disabledSocketSend) {
        this.host = host;
        this.port = port;
        this.timeout = timeout;
        this.disabledSocketSend = disabledSocketSend;
        commandQueue = new LinkedList<>();
        onSenderEventList = new ArrayList<>();
    }

    public interface OnSenderEvent {
        void onCSError(Exception e);

        void onCSStart();

        void onCSSend(CommandWrapper commandWrapper, String jsonData);

        void onCSRunning();

        void onCSStop();
    }

    public void addOnSenderEvent(OnSenderEvent onSenderEvent) {
        if (onSenderEvent != null) {
            onSenderEventList.add(onSenderEvent);
        }
    }

    public void removeOnSenderEvent(OnSenderEvent onSenderEvent) {
        if (onSenderEvent != null) {
            onSenderEventList.remove(onSenderEvent);
        }
    }

    public void emptyCommandQueue() {
        commandQueue.clear();
    }

    public boolean isCanSend() {
        if (disabledSocketSend) {
            return true;
        } else {
            return isCanSend;
        }
    }

    public boolean isStart() {
        return isStart;
    }

    public boolean send(CommandWrapper commandWrapper) {
        return commandQueue.offer(commandWrapper);
    }

    public void start() {
        if (host != null && port != null) {
            sendThread = new Thread(this);
            sendThread.start();
        } else {
            LogTool.i(TAG, "host: " + host + " port:" + port);
        }
    }

    public void stop() {
        isStart = false;
    }

    public void release() {
        stop();
        if (socket != null && socket.isConnected()) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                socket = null;
            }
        }
        if (sendThread != null && sendThread.isAlive()) {
            sendThread.interrupt();
            sendThread = null;
            LogTool.i(TAG, "sendThread interrupt");
        }
    }

    @Override
    public void run() {
        boolean isError = false;
        try {
            isStart = true;
            for (OnSenderEvent onSenderEvent : onSenderEventList) {
                onSenderEvent.onCSStart();
            }
            while (true) {
                isCanSend = true;
                if (!commandQueue.isEmpty()) {
                    CommandWrapper commandWrapper = commandQueue.poll();
                    Command command = commandWrapper.getCommand();

                    String data = "[" + JsonTool.toJson(command) + "]";
                    //String data=genData(command);

                    if (!disabledSocketSend) {
//                        LogTool.i(TAG, "socket host: "+host+" port: "+port);
//                        Socket socket = new Socket(host, Integer.parseInt(port));
//                        socket.setSoTimeout(timeout);

                        if (socket == null || socket.isClosed()) {
                            socket = new Socket(host, Integer.parseInt(port));
                            socket.setSoTimeout(timeout);
                            LogTool.i(TAG, "init socket...");
                        }

                        if (socket != null && socket.isConnected()) {
                            DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());
                            outputStream.write(data.getBytes());
                            outputStream.flush();
                        } else {
                            throw new Exception("bad socket!");
                        }

//                        socket.close();
                    }

                    for (OnSenderEvent onSenderEvent : onSenderEventList) {
                        onSenderEvent.onCSSend(commandWrapper, data);
                    }

                    LogTool.i(TAG, "send data: " + data);
                    Thread.sleep(100);
                    if (!isStart) {
                        LogTool.i(TAG, "isStart: " + isStart + ", but the queue of command is not empty! remain sending...");
                    }
                    continue;
                } else {
                    if (!isStart) {
                        break;
                    }
                }

                for (OnSenderEvent onSenderEvent : onSenderEventList) {
                    onSenderEvent.onCSRunning();
                }

                // LogTool.i(TAG, "no message, sleep 1s ...");
                Thread.sleep(1000);
            }

        } catch (Exception e) {
            isStart = false;
            isError = true;
            e.printStackTrace();
            for (OnSenderEvent onSenderEvent : onSenderEventList) {
                onSenderEvent.onCSError(e);
            }
            this.emptyCommandQueue();
        } finally {
            isCanSend = false;
        }
        if (!isError) {
            for (OnSenderEvent onSenderEvent : onSenderEventList) {
                onSenderEvent.onCSStop();
            }
        }

        if (socket != null) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                socket = null;
            }
        }

        sendThread = null;
        LogTool.i(TAG, "host: " + host + " port:" + port + " exited!");
    }


//		   public String genData(Command command) {
//			   String data="";
//			   List<Message> list = command.getData();
//			   data+="[{ \"deviceID\" : \""+command.getDeviceID()+"\",  \"data\" : [";
//			   int last=list.size();
//			   for(Message message : list) {
//				    data+="{";
//				    data+="\"type\" : "+convertHexStr(message.getType())+", ";
//				    if(message.getType().equals("0x03")) {
//				    	     data+="\"value\" : "+Integer.valueOf(message.getValue())+", ";
//				    }else {
//				    	    data+="\"value\" : "+maybeNULL(message.getValue())+", ";
//				    }
//				    
//				    if(message.getType().equals("0x03")) {
//				    	   data+="\"status\" : "+Integer.valueOf(message.getStatus());
//				    }else {
//				    	   data+="\"status\" : "+maybeNULL(message.getStatus());
//				    }
//		
//				    data+="}";
//				    if(last>1) {
//				    	data+=",";
//				    }
//				    last--;
//			   }
//			   data+="]}]";
//			   return data;
//		   }

//		   public String maybeNULL(String s) {
//			            if(TextTool.checkNull(s)) {
//			            	return "\"\"";
//			            }else {
//			            	return "\""+s+"\"";
//			            }
//		   }

    public String getHost() {
        return host;
    }

    public CommandSender setHost(String host) {
        this.host = host;
        return this;
    }

    public String getPort() {
        return port;
    }

    public CommandSender setPort(String port) {
        this.port = port;
        return this;
    }

    public static CommandSender instance() {
        return instance;
    }

    public static CommandSender instance(String host, String port) {
        if (host != null && port != null) {
            instance.setHost(host).setPort(port);
        }
        return instance;
    }
}
