package king.easyconfigir.common.manager;

public class SMP {
    public static String stepL = "MV:L"; // Move left
    public static String stepT = "MV:U"; // Move up
    public static String stepR = "MV:R"; // Move right
    public static String stepB = "MV:B"; // Move down
    public static String stepZ = "MV:Z"; // Move stop
    // Preset points all
    public static String reset = "SV:Z"; // Reset preset
    // Preset point single
    public static String savex = "SV:A"; // Save preset point.
    public static String rsetx = "SV:E"; // Request for reseting preset point. 2019-01-17
    public static String rseta = "RS:P"; // Answer to preset point reset request.  2019-01-17
    // WiFi Setting
    public static String savew = "SV:W"; // Save WiFi
    public static String qrwfi = "QR:W"; // Query for WiFi 2019-01-17
    public static String qawfi = "QA:W"; // Answer for WiFi query 2019-01-17
    // merge configuration.
    public static String savem = "SV:M"; // Save merge configuration.
    public static String qrmrg = "QR:M"; // Query for merge configuration 2019-01-17
    public static String qamrg = "QA:M"; // Answer for merge configuration query 2019-01-17
    // ???
    public static String savep = "SV:P"; // Save rectification parameters.
    // Cloud address
    public static String cloud = "SV:C"; // Save cloud address
    public static String qrcld = "QR:C"; // Query for cloud address 2019-01-17
    public static String qacld = "QA:C"; // Answer for cloud address query 2019-01-17
    // ???
    public static String confz = "CF:X"; // Clean all configurations.
    public static String check = "CK:A"; // Check saved preset.
    // radiation
    public static String saver = "SV:R"; // Save radiation ratio.
    public static String qrrro = "QR:R"; // Query for  radiation ratio.  2019-01-17
    public static String qarro = "QA:R"; // Answer for radiation ratio query  2019-01-17
    // Other
    public static String saved = "SV:D"; // Save watch point
    public static String savet = "SV:T"; // Save temperature warning threshold.
    public static String rebot = "RT:R"; // Reboot
    public static String captr = "CP:R"; // Capture.
    public static String query = "QA:R"; // Query device identifier, MAC.
    public static String upprt = "UP:P"; // Update the config tools receiving port.
    public static String qprcf = "PR:Q"; // Query saved preset configuration
    public static String warnq = "WR:Q"; // Query saved high temperature warning threshold
    // Device Number
    public static String devnq = "DN:Q"; // Query for device number
    public static String devna = "DN:A"; // Answer for device number query.
    public static String devnu = "DN:U"; // Update the device number to the device.

    // IR Image
    public static String irtgq = "IR:Q"; // Query for gamma value of the IR transform algorithm
    public static String irtga = "IR:A"; // Answer for the gamma value query.
    public static String irtgu = "IR:U"; // Update the the gamma value to the device.

    // Edge Image.
    public static String iedgq = "EG:Q"; // Query for the parameter value for the edge showing
    public static String iedga = "EG:A"; // Answer for the query "EG:Q".
    public static String iedgu = "EG:U"; // Update the parameter value for the edge showing to the device.

    // Transmite polygen sequence
    public static String polyq = "PG:Q"; // Query for the polygen sequence.
    public static String polya = "PG:A"; // Answer for the query "PG:Q".
    public static String polyu = "PG:U"; // Update the polygen sequence to the device.
    public static String polyz = "PG:Z"; // Clean the polygen sequence to the device.

    // Transmite Console Config
    public static String cslcq = "CC:Q";
    public static String cslca = "CC:A";
    public static String cslcu = "CC:U";

    // Transmite Wiper Config
    public static String wipcq = "WC:Q";
    public static String wipca = "WC:A";
    public static String wipcu = "WC:U";

    // Transmite Reset Config
    public static String rstcq = "RC:Q";
    public static String rstca = "RC:A";
    public static String rstcu = "RC:U";

    public static String serate = "BR:S";
}
