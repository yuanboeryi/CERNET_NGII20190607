package king.easyconfigir.common.model;

import java.util.List;

public class Command {

	   private String deviceID;
	   private  List<Message>data;
	   
	   public Command(String deviceID, List<Message> data) {
		 super();
		 this.deviceID = deviceID;
		 this.data = data;
	  }

	  public String getDeviceID() {
		 return deviceID;
	  }

	  public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	 }

	  public List<Message> getData() {
		 return data;
	 }

	 public void setData(List<Message> data) {
		this.data = data;
	 }
	   
}
