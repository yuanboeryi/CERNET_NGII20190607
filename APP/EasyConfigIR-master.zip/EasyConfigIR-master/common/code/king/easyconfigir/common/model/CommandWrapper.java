package king.easyconfigir.common.model;

public class CommandWrapper {

    private String name;
    private Command command;
    private Type type;

    public CommandWrapper(String name, Command command, Type type) {
        super();
        this.name = name;
        this.command = command;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Command getCommand() {
        return command;
    }

    public void setCommand(Command command) {
        this.command = command;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public enum Type {
        HS, SMP;
    }
}
