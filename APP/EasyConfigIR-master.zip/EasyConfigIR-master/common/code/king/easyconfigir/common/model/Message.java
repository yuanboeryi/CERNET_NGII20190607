package king.easyconfigir.common.model;

public class Message<T, V, S> {
    private T type;
    private V value;
    private S status;

    public Message(T type, V value, S status) {
        super();
        this.type = type;
        this.value = value;
        this.status = status;
    }

    public T getType() {
        return type;
    }


    public void setType(T type) {
        this.type = type;
    }


    public V getValue() {
        return value;
    }


    public void setValue(V value) {
        this.value = value;
    }


    public S getStatus() {
        return status;
    }


    public void setStatus(S status) {
        this.status = status;
    }


    @Override
    public String toString() {
        return "Message [type=" + type + ", value=" + value + ", status=" + status + "]";
    }

}
