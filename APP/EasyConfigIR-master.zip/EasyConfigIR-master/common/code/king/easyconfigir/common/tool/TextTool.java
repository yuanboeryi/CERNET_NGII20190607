package king.easyconfigir.common.tool;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TextTool {

    public static final int ALL_CLOSE = 0x0;
    public static final int ALL_OPEN = 0x1;
    public static final int LEFT_CLOSE_RIGHT_OPEN = 0x2;
    public static final int LEFT_OPEN_RIGHT_CLOSE = 0x3;

//	public staitc boolean isValidHS

    public static int convertHexStr(String s) {
        return Integer.parseInt(s.replaceAll("^0[x|X]", ""), 16);
    }

    public static HashMap<String, String> matchDeviceInfo(String info) {
        String regex = "<([\\d|a-z]{1,}):([\\d|a-z]{1,})>";
        Pattern r = Pattern.compile(regex);
        Matcher m = r.matcher(info);
        if (m.find()) {
            HashMap res = new HashMap();
            res.put("device_code", m.group(1));
            res.put("device_mac", m.group(2));
            return res;
        } else {
            return null;
        }
    }

    public static HashMap<String, String> matchDeviceToken(String token) {
        String regex = "([^\\d]+)?([\\d|\\.|:]{7,})(/([\\d|a-z|A-Z|_|-]+))?";
        Pattern r = Pattern.compile(regex);
        Matcher m = r.matcher(token);
        if (m.find()) {
//            LogTool.i("matchDeviceToken", "g1: " + m.group(1));
//            LogTool.i("matchDeviceToken", "g2: " + m.group(2));
//            LogTool.i("matchDeviceToken", "g3: " + m.group(3));
//            LogTool.i("matchDeviceToken", "g4: " + m.group(4));
            HashMap hs = matchIP(m.group(2));
            if (hs != null) {
                String header = m.group(1);
                hs.put("header", header);
                String devid = m.group(4);
                hs.put("device_id", devid);
            }
            return hs;
        }
        return null;
    }

    public static HashMap<String, String> matchIP(String line) {
        String pat = "\\d{1,3}";
        String regex = "^(" + pat + "\\." + pat + "\\." + pat + "\\." + pat + ")(:(\\d+))?$";
        Pattern r = Pattern.compile(regex);
        Matcher m = r.matcher(line);
        if (m.find()) {
            HashMap res = new HashMap();
            res.put("host", m.group(1));
            res.put("port", m.group(3));
            return res;
        } else {
            return null;
        }
    }

    public static boolean isValidIP(String ip) {
        return (matchIP(ip) != null);
    }

    public static boolean checkNull(String value) {
        return (value == null || (value != null && value.trim().equals("")));
    }

    public static boolean isValidPort(String port) {
        return isValidIntegerRange(port, 0, 65535, ALL_CLOSE);
    }

    public static boolean isValidIntegerRange(String value, int d, int e, int flag) {
        String regex = "^-?\\d+$";
        if (Pattern.matches(regex, value)) {
            int pp = Integer.parseInt(value);
            switch (flag) {
                case ALL_OPEN:
                    return (pp > d && pp < e);
                case LEFT_CLOSE_RIGHT_OPEN:
                    return (pp >= d && pp < e);
                case LEFT_OPEN_RIGHT_CLOSE:
                    return (pp > d && pp <= e);
                case ALL_CLOSE:
                default:
                    return (pp >= d && pp <= e);
            }
        } else {
            return false;
        }
    }

    public static boolean isValidFloatRange(String value, double d, double e, int flag) {
        String regex = "^-?\\d+(\\.\\d+)?$";
        if (Pattern.matches(regex, value)) {
            float pp = Float.parseFloat(value);
            switch (flag) {
                case ALL_OPEN:
                    return (pp > d && pp < e);
                case LEFT_CLOSE_RIGHT_OPEN:
                    return (pp >= d && pp < e);
                case LEFT_OPEN_RIGHT_CLOSE:
                    return (pp > d && pp <= e);
                case ALL_CLOSE:
                default:
                    return (pp >= d && pp <= e);
            }
        } else {
            return false;
        }
    }

    public static boolean isValidTime(String value) {
        boolean convertSuccess = true;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            format.setLenient(false);
            format.parse(value);
        } catch (ParseException e) {
            //e.printStackTrace();
            // 如果throw java.text.ParseException或者NullPointerException，就说明格式不对
            convertSuccess = false;
        }
        return convertSuccess;
    }

}
