package king.autogen.mapper;

import java.util.List;
import king.autogen.model.MQTTServer;
import king.autogen.model.MQTTServerExample;
import org.apache.ibatis.annotations.Param;

public interface MQTTServerMapper {
    long countByExample(MQTTServerExample example);

    int deleteByExample(MQTTServerExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(MQTTServer record);

    int insertSelective(MQTTServer record);

    List<MQTTServer> selectByExample(MQTTServerExample example);

    MQTTServer selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") MQTTServer record, @Param("example") MQTTServerExample example);

    int updateByExample(@Param("record") MQTTServer record, @Param("example") MQTTServerExample example);

    int updateByPrimaryKeySelective(MQTTServer record);

    int updateByPrimaryKey(MQTTServer record);
}