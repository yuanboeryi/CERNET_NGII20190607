package king.autogen.mapper;

import java.util.List;
import king.autogen.model.RtspServer;
import king.autogen.model.RtspServerExample;
import org.apache.ibatis.annotations.Param;

public interface RtspServerMapper {
    long countByExample(RtspServerExample example);

    int deleteByExample(RtspServerExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(RtspServer record);

    int insertSelective(RtspServer record);

    List<RtspServer> selectByExample(RtspServerExample example);

    RtspServer selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") RtspServer record, @Param("example") RtspServerExample example);

    int updateByExample(@Param("record") RtspServer record, @Param("example") RtspServerExample example);

    int updateByPrimaryKeySelective(RtspServer record);

    int updateByPrimaryKey(RtspServer record);
}