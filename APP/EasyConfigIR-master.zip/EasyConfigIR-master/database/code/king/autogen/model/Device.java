package king.autogen.model;

import java.io.Serializable;

public class Device implements Serializable {
    private Integer id;

    private String name;

    private String code;

    private String icon;

    private String details;

    private String createdate;

    private String onlinedate;

    private Integer status;

    private Integer tid;

    private Integer controlSid;

    private Integer highSid;

    private Integer irSid;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon == null ? null : icon.trim();
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details == null ? null : details.trim();
    }

    public String getCreatedate() {
        return createdate;
    }

    public void setCreatedate(String createdate) {
        this.createdate = createdate == null ? null : createdate.trim();
    }

    public String getOnlinedate() {
        return onlinedate;
    }

    public void setOnlinedate(String onlinedate) {
        this.onlinedate = onlinedate == null ? null : onlinedate.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getTid() {
        return tid;
    }

    public void setTid(Integer tid) {
        this.tid = tid;
    }

    public Integer getControlSid() {
        return controlSid;
    }

    public void setControlSid(Integer controlSid) {
        this.controlSid = controlSid;
    }

    public Integer getHighSid() {
        return highSid;
    }

    public void setHighSid(Integer highSid) {
        this.highSid = highSid;
    }

    public Integer getIrSid() {
        return irSid;
    }

    public void setIrSid(Integer irSid) {
        this.irSid = irSid;
    }
}