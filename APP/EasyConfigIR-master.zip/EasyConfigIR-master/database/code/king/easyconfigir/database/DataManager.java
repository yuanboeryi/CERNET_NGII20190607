package king.easyconfigir.database;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSession;

import java.io.InputStream;
import java.lang.Exception;


public class DataManager {
       private static Logger logger = LoggerFactory.getLogger(DataManager.class);	
       private static SqlSessionFactory sqlSessionFactory;
       private final static String DEFAULT_RESOURCE = "mybatis.xml";

       private static final DataManager dm = new DataManager();
       
       public static DataManager self() {
    	            return dm;
       }
       
       public interface OnSqlSession {
              void onOpen(SqlSession sqlSession);
       }

       public interface OnGetMapper<T> {
              void onGet(T mapper);
       }

       private OnSqlSession onSqlSession;

       private Class<?> mapperType;
       private OnGetMapper onGetMapper;

       public DataManager() {
             this(DEFAULT_RESOURCE); 
       }

       public DataManager(String resource) {
	    logger.info("load mybatis config: {}", resource);
	    try {
                InputStream inputStream = Resources.getResourceAsStream(resource);
                sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
	    } catch (Exception e) {
		e.printStackTrace();
	    }

       } 

       public DataManager setOnSqlSession(OnSqlSession onSqlSession) {
             this.onSqlSession = onSqlSession;
	     return this;
       }

       public DataManager setOnGetMapper(Class<?> mapperType, OnGetMapper onGetMapper) {
	     this.mapperType = mapperType;
             this.onGetMapper = onGetMapper;
	     return this;
       }
       
       public void open() {
             try (SqlSession session = sqlSessionFactory.openSession()) {
		     if(onSqlSession != null) {
                        onSqlSession.onOpen(session);
			session.commit();
                        session.close();
		     }
             } catch (Exception e) {
		e.printStackTrace();
	     }

       }

       public void get() {
             try (SqlSession session = sqlSessionFactory.openSession()) {
		     if(mapperType != null && onGetMapper != null) {
                        onGetMapper.onGet(session.getMapper(mapperType));
			session.commit();
                        session.close();
		     }
	     } catch (Exception e) {
		e.printStackTrace();
	     }
       }

/*
       new DataManager().setOnSqlSession(new DataManager.OnSqlSession(){
	       public void onOpen(SqlSession session) {


	       }
       }).open();

*/
}
