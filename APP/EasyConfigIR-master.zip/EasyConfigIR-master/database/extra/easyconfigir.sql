attach database 'easyconfigir.db' as db_easyconfigir;

pragma foreign_keys = on;

create table tb_type (
    id                integer primary key autoincrement,
    value          varchar(30)
);

create table tb_status (
    id                integer primary key autoincrement,
    value          varchar(30)
);

create table tb_server (
    id                   integer primary key autoincrement,
    tid                 integer,
    sid                 integer,
    name            text default 'undefined',
    icon              text,
    details          text default 'no details',
    createdate   datetime default (datetime('now', 'localtime')),
    status           integer,
    foreign key (tid) references tb_type(id),
    foreign key (status) references tb_status(id)
);

create table tb_mqtt_server (
    id                  integer primary key autoincrement,
    host             text default 'localhost',
    port             varchar(10) default '61613',
    username   varchar(20) default 'admin',
    password    varchar(30) default 'password',
    client_id      varchar(50) default 'easyconfigir-mqtt-client-default' 
);

create table tb_mqtt_topic (
    id                   integer primary key autoincrement,
    topic             text,
    sid                 integer,
    comments   text,
    foreign key (sid) references tb_mqtt_server(id)
);

create table tb_rtsp_server (
    id                   integer primary key autoincrement,
    host              text default '192.168.0.1',
    port              varchar(10) default '5554',
    username    varchar(20),
    password     varchar(30),
    vpath           text
);

create table tb_device (
    id                     integer primary key autoincrement,
    name               text default 'unknown',
    code                text,
    icon                 text,
    details             text default 'no details',
    createdate      datetime default (datetime('now', 'localtime')),
    onlinedate      datetime,
    status              integer,
    tid                    integer,
    control_sid      integer,
    high_sid           integer,
    ir_sid                 integer,
    foreign key (tid) references tb_type(id),
    foreign key (control_sid) references tb_server(id),
    foreign key (high_sid) references tb_server(id),
    foreign key (ir_sid) references tb_server(id),
    foreign key (status) references tb_status(id)
);