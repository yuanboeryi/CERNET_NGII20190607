package king.easyconfigir.database;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import king.autogen.mapper.*;
import king.autogen.model.*;

public class DataManagerTest {

       private final DataManager dm = new DataManager();
       private static Logger logger = LoggerFactory.getLogger(DataManagerTest.class);

       @DisplayName("Test DataManager")
       @Test
       public void test() {
          dm.setOnSqlSession(new DataManager.OnSqlSession(){
	       public void onOpen(SqlSession session) {
		      logger.info("open success!");
              MQTTServerMapper mapper = session.getMapper(MQTTServerMapper.class);
              MQTTServerExample example = new MQTTServerExample();
              List<MQTTServer> list = mapper.selectByExample(example);
              for (MQTTServer server : list) {
            	  //int ret = server.getId();
            	  Assertions.assertNotNull(server);
              }
               //    
	      }
          }).open();	   
     }
}
