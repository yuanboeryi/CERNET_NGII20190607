package king.easyconfigir;

import java.io.File;

import javax.swing.JOptionPane;

import king.easyconfigir.tool.LogTool;
import king.easyconfigir.ui.ControlWindow;
import king.easyconfigir.update.model.Target;
import king.easyconfigir.update.panel.UpdateControlPanel;
import king.easyconfigir.video.EasyconfigirNativeDiscoveryStrategy;

import uk.co.caprica.vlcj.factory.discovery.NativeDiscovery;
import uk.co.caprica.vlcj.factory.discovery.strategy.LinuxNativeDiscoveryStrategy;
import uk.co.caprica.vlcj.factory.discovery.strategy.OsxNativeDiscoveryStrategy;
import uk.co.caprica.vlcj.factory.discovery.strategy.WindowsNativeDiscoveryStrategy;

@SuppressWarnings("ALL")
public class App extends king.easyconfigir.update.App {

    private final static String DEFAULT_APP_PATH = System.getProperty("user.dir");

    private final static String APP_PATH = DEFAULT_APP_PATH;
    private final static String APP_UPDATE_URL = R.url.JSON;

    private final static String APP_CONFIG_NAME = "app.json";
    private final static String APP_BACKUP_DIR_NAME = "backup";
    private final static String APP_UPDATE_DIR_NAME = "update";
    private final static String APP_UPDATE_CONFIG_NAME = "config.json";

    private static Target target;

    @Override
    public Target obtainTarget() {
        String appConfigPath = APP_PATH + File.separator + APP_CONFIG_NAME;

        target = loadTarget(appConfigPath);

        if (target == null) {
            target = new Target();
            target.setUpdateMode(R.flag.UPDATE_MODE);
            target.setLastTime(0);
            target.setStartCheckUpdate(R.flag.IS_START_CHECK_UPDATE);

            target.setPath(APP_PATH);
            target.setAppConfig(appConfigPath);

            target.setName(R.app.EN_NAME);
            target.setUrl(APP_UPDATE_URL);
            target.setCode(R.app.CODE);
            target.setVersion(R.app.VERSION);

            String updatePath = APP_PATH + File.separator + APP_UPDATE_DIR_NAME;
            String backupPath = APP_PATH + File.separator + APP_BACKUP_DIR_NAME;
            String updateConfigPath = updatePath + File.separator + APP_UPDATE_CONFIG_NAME;

            target.setBackup(backupPath);
            target.setUpdate(updatePath);
            target.setUpdateConfig(updateConfigPath);
        }

        return target;
    }

    public static UpdateControlPanel getUpdateControlPanel() {
        if (target == null) {
            String appConfigPath = APP_PATH + File.separator + APP_CONFIG_NAME;
            target = loadTarget(appConfigPath);
        }
        UpdateControlPanel ucp = new UpdateControlPanel();
        ucp.setTarget(target);
        return ucp;
    }

    public static String getVersionMessage() {
        String version = R.app.VERSION;
        if (target == null) {
            String appConfigPath = APP_PATH + File.separator + APP_CONFIG_NAME;
            target = loadTarget(appConfigPath);
        }
        if (target != null) {
            version = target.getVersion();
        }
        return "当前版本: " + version + " by " + R.app.AUTHOR;
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!ControlWindow.instance().isShowing()) {
            if (checkVLC()) {
                ControlWindow.instance().display();
            } else {
                JOptionPane.showMessageDialog(null, "VLC not found!");
            }
        } else {
            LogTool.i(this, "ControlWindow is showing...");
        }
    }

    @Override
    protected void onLatest() {
        super.onLatest();
        if (!ControlWindow.instance().isShowing()) {
            start();
        } else {
            JOptionPane.showMessageDialog(null, "已经最新版本啦!");
        }
    }

    @Override
    protected void onCancel() {
        super.onCancel();
        if (!ControlWindow.instance().isShowing()) {
            start();
        }
    }

    @Override
    protected void onUpdateError(String error) {
        JOptionPane.showMessageDialog(null, "检查更新失败！\n"+error);
        start();
    }

    @Override
    protected void onStartUpdate() {
        super.onStartUpdate();
        if (ControlWindow.instance().isShowing()) {
            ControlWindow.instance().closeSelf();
        } else {
            LogTool.i(this, "ControlWindow does not be needed to close itself");
        }
    }

    @SuppressWarnings("AlibabaLowerCamelCaseVariableNaming")
    private boolean checkVLC() {
        LogTool.i("App", "user.dir: " + System.getProperty("user.dir"));
        boolean is = new NativeDiscovery(
                new EasyconfigirNativeDiscoveryStrategy(),
                new WindowsNativeDiscoveryStrategy(),
                new LinuxNativeDiscoveryStrategy(),
                new OsxNativeDiscoveryStrategy()
        ).discover();
        return is;
    }

//    private static void useWindowsStyle() {
//        try {
//            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
//            ControlWindow.instance().display();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


    //    public static void testPic() {
//        try {
//            System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
//
//            Mat capImg = new Mat();
//            VideoCapture capture = new VideoCapture();
//            capture.open("rtsp://192.168.8.106:5554/high.h264");
//            int height = (int) capture.get(Videoio.CAP_PROP_FRAME_HEIGHT);
//            int width = (int) capture.get(Videoio.CAP_PROP_FRAME_WIDTH);
//            if (height == 0 || width == 0) {
//                throw new Exception("camera not found!");
//            }
//
//            JFrame frame = new JFrame("camera");
//            frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
//            CaptureBasic panel = new CaptureBasic();
//            frame.setContentPane(panel);
//            frame.setVisible(true);
//            frame.setSize(width + frame.getInsets().left + frame.getInsets().right,
//                    height + frame.getInsets().top + frame.getInsets().bottom);
//            while (frame.isShowing()) {
//                capture.read(capImg);
//                panel.mImg = panel.mat2BI(capImg);
//                panel.repaint();
//            }
//            capture.release();
//            frame.dispose();
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            System.out.println("--done--");
//        }
//
//    }

//    public static Command getCommand(int index) {
//        List<Message> data = new ArrayList<>();
//        data.add(new Message("0x" + index, "hello", "world!"));
//        return new Command("fsdfasfd", data);
//    }

//    private static void runMQTTClient() {
//        new Client();

//		try {
//	         UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
//	         new Client();
//	    } catch (Exception e) {
//	       e.printStackTrace();
//	    }

//		SwingUtilities.invokeLater ( new Runnable ()
//        {
//            @Override
//            public void run ()
//            {
//                WebLookAndFeel.install();
//                new Client();
//            }
//        } );

//    }

//    private static void useDefaultStyle() {
//        ControlWindow.instance().display();
//    }
//
//    private void useWebLookStyle() {
//        SwingUtilities.invokeLater(new Runnable() {
//            @Override
//            public void run() {
//
//            }
//        });
//    }

    public static void main(String[] args) {
        new App().lanuch();
//        App.useWebLookStyle();
//        App.useWindowsStyle();
//        App.useDefaultStyle();

//        App.runMQTTClient();

//        new ControlWindow().setVisible(true);
//        testPic();
//        TextTool.matchDeviceToken("hs://1.1.1.1:5050/hi123456");
//        TextTool.matchDeviceToken("hs://1.1.1.1/hi123456");
//        TextTool.matchDeviceToken("hs://1.1.1.1:5050/hi1...23456");
//
//        new RtspVideo().start("rtsp://192.168.8.114:5554/high.h264");
//        new RtspVideo().start("rtsp://192.168.8.114:5554/ir.h264");
//
//        ToastTool.testToast();
//        CommandSender ss = new CommandSender("192.168.8.108", "50001");
//        ss.start();
//
//        new Thread(new Runnable() {
//
//            @Override
//            public void run() {
//                Command comm = App.getCommand(0);
//                for (int i = 0; i < 200; i++) {
//                    ss.send(comm);
//                }
//            }
//
//        }).start();
//
//        ss.stop();
    }

}
