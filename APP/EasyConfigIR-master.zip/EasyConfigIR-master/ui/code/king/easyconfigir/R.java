package king.easyconfigir;

import java.awt.Color;

public class R {
    public static class app {
        public final static String CH_NAME = "红外局域网配置工具";
        public final static String EN_NAME = "EasyConfigIR";

        public final static int CODE = 0;

        public final static String NAME = CH_NAME;
        public final static String VERSION = "0.1.0";
        public final static String AUTHOR = "King-1025";
        public final static String EMAIL = "1543641386@qq.com";
    }

    public static class test {
        public final static String APP_PATH = "D:\\OO\\other\\http\\config\\test";
        public final static String UPDATE_CONFIG = "http://127.0.0.1/config/update_sample.json";
    }

    public static class url {
        public final static String GITEE = "https://gitee.com/King-1025/EasyConfigIR";
        public final static String DOWNLOAD = "https://king-1025.lanzous.com/igPKif3j0xa";
        public final static String DOWNLOAD2 = "http://122.114.204.83:801/test/";
        public final static String JSON = "http://122.114.204.83:801/test/update_config.json";

        public final static String UPDATE = DOWNLOAD2;

    }

    public static class json {
        public final static String main_menu_bar = "json/main_menu_bar.json";
        public final static String control_menu_bar = "json/control_menu_bar.json";
        public final static String navigation_popumenu = "json/navigation_popumenu.json";
    }

    public class flag {
        public final static boolean DISABLED_TOAST_SEND = true;
        public final static boolean DISABLED_VIDEO = false;
        public final static boolean SHOW_OVERLAY_ON_IR = true; // 启用红外画布

        public final static int DEFAULT_PANEL_FLAG = 0x1; // 0x0: none 0x1: region 0x2: control

        public final static int UPDATE_MODE = 0; // 每次
        public final static boolean IS_START_CHECK_UPDATE = true;
    }

    public class value {
        public final static String DEFAULT_DEVICE_WIFI_NAME = "ythd";
        public final static String DEFAULT_DEVICE_WIFI_PASSWORD = "zzkt123456";

        public final static long DEFAULT_HIGH_VIDEO_NETWORKCACHING = 2000;
        public final static long DEFAULT_IR_VIDEO_NETWORKCACHING = 3000;

        public final static long OPEN_VIDEO_INTERVAL = 2500;
        public final static long CLOSE_VIDEO_INTERVAL = 2500;

        public final static float REGION_WIDTH = 320;
        public final static float REGION_HEIGHT = 240;

        public final static float XW = 380;
        public final static float XH = 380;

        public final static float FX = REGION_WIDTH / XW; // 横向偏移率
        public final static float FY = REGION_HEIGHT / XH;  // 纵向偏移率

        public final static float OFX = 5; // 横轴像素偏移
        public final static float OFY = 15; // 纵轴像素偏移

        public final static float LINE_THICK = 1.5f; // 线宽
        public final static int POINT_R = 4; // 点半径

        public final static int DEFAULT_SUBMIT_PRESET_POINT_START_OFFSET = 0;
        public final static int DEFAULT_CLEAN_PRESET_POINT_START_OFFSET = 0;

    }

    public class ip {
        //		public final static String DEFAULT_COMMAND_IP="47.93.58.31";
        public final static String DEFAULT_COMMAND_IP = "192.168.8.100";
        public final static String TEST_COMMAND_IP = "192.168.8.108";
    }

    public class prot {
        public final static String TEST_COMMAND_PORT = "50001";
        public final static String HS_VIDEO_PROT = "5554";
        public final static String HS_COMMAND_PORT = "12345";
        // public final static String HS_COMMAND_PORT = "38888";
    }

    public class title {
        public final static String APP_NAME = R.app.NAME;
        public final static String NAVIGATION_PANEL = "导航栏";
        public final static String BODY_PANEL = "主面板";
        public final static String VIDEO_PANEL = "视频面板";
        public final static String ARGS_PANEL = "参数面板";
        public final static String PRESET_PANEL = "预设面板";
        public final static String PRESET_CONTROL_PANEL = "预设点控制面板";
        public final static String VIDEO_CONTROL_PANEL = "视频控制面板";
        public final static String MISC_CONTROL_PANEL = "杂项";
        public final static String UPDATE_CONTROL_PANEL = "更新控制";
        public final static String MEDIA_CONTROL_PANEL = "推流控制";
    }

    public class info {
        public final static String UNIMPLEMENT = "该功能暂未实现!";
        public final static String SUPPORT_VLC_WARN = "你的系统必须支持VLC才能浏览视频!";
//        public final static String VERSION_MESSAGE = "当前版本: " + R.app.VERSION + " by " + R.app.AUTHOR;
    }

    public class size {
        public final static int PAD = 3;
        public final static int MAIN_WINDOW_WIDTH = 1230;
        public final static int MAIN_WINDOW_HEIGHT = 730;

        public final static int MAIN_MENU_BAR_WIDTH = MAIN_WINDOW_WIDTH;
        public final static int MAIN_MENU_BAR_HEIGHT = 30;

        public final static int CONTROL_WINDOW_WIDTH = 1200;
        public final static int CONTROL_WINDOW_HEIGHT = 730;

        public final static int CONTROL_VIDEO_WIDTH = (int) (CONTROL_WINDOW_WIDTH - 434);
        public final static int CONTROL_VIDEO_HEIGHT = (int) (CONTROL_WINDOW_HEIGHT - 316);

        public final static int CONTROL_ARGS_WIDTH = CONTROL_VIDEO_WIDTH;
        public final static int CONTROL_ARGS_HEIGHT = CONTROL_WINDOW_HEIGHT - MAIN_MENU_BAR_HEIGHT - CONTROL_VIDEO_HEIGHT - 24;

        public final static int CONTROL_PRESET_WIDTH = CONTROL_WINDOW_WIDTH - CONTROL_VIDEO_WIDTH - 12;
        public final static int CONTROL_PRESET_HEIGHT = CONTROL_WINDOW_HEIGHT - MAIN_MENU_BAR_HEIGHT;

        public final static int MAIN_NAVIGATION_WIDTH = (int) (MAIN_WINDOW_WIDTH * 0.2);
        public final static int MAIN_NAVIGATION_HEIGHT = MAIN_WINDOW_HEIGHT;

        public final static int MAIN_BODY_WIDTH = (int) (MAIN_WINDOW_WIDTH * 0.7);
        public final static int MAIN_BODY_HEIGHT = MAIN_WINDOW_HEIGHT;
    }

    public static class color {
        public final static Color MAIN_MENU_BAR_BACKGROUND_COLOR = Color.decode("#666666");
        public final static Color MAIN_MENU_FONT_COLOR = Color.decode("#000000");
        // public final static Color MAIN_MENU_ITEM_BACKGROUND_COLOR = MAIN_MENU_FONT_COLOR;
        public final static Color MAIN_MENU_ITEM_BACKGROUND_COLOR = Color.decode("#FFFFFF");
        public final static Color MAIN_NAVIGATION_BACKGROUND_COLOR = Color.decode("#220000");
        public final static Color MAIN_BODY_BACKGROUND_COLOR = Color.decode("#000044");
        public final static Color CAT_COLOR = new Color(255, 205, 17);
        public final static Color CATHELLO_COLOR = Color.decode("#FF4500");
    }

}
