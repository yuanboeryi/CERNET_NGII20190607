package king.easyconfigir.button;

import java.awt.Font;
import java.util.List;

import javax.swing.JButton;

import king.easyconfigir.model.PresetPoint;

public class PresetButton extends JButton {

    private PresetPoint presetPoint;

    public PresetButton(int id, String text, List<PresetButton> list) {
        this(id, 150, 56, text, list);
    }

    public PresetButton(int id, int width, int height, String text, List<PresetButton> list) {
        super(text);
        this.setSize(width, height);
        this.setText(text);
        this.setFont(new Font("微软雅黑", 1, 15));
        this.presetPoint = new PresetPoint(id, genName(id, -1), -1);
    }

    private String genName(int p0, int p1) {
        return p0 + " (" + p1 + "米)";
    }

    public int getId() {
        return this.presetPoint.getId();
    }

    public void setId(int id) {
        this.presetPoint.setId(id);
        this.presetPoint.setName(genName(id, getDistance()));
    }

    public int getDistance() {
        return this.presetPoint.getDistance();
    }

    public void setDistance(int distance) {
        this.presetPoint.setDistance(distance);
        this.presetPoint.setName(genName(getId(), distance));
    }

    public PresetPoint getPresetPoint() {
        return presetPoint;
    }
}
