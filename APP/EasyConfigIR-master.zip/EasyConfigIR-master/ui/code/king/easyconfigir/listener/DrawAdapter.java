package king.easyconfigir.listener;

import java.awt.event.MouseAdapter;

public class DrawAdapter extends MouseAdapter {


}