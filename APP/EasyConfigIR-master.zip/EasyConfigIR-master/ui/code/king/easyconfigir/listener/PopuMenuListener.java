package king.easyconfigir.listener;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import king.easyconfigir.R;
import king.easyconfigir.model.MenuItemRes;
import king.easyconfigir.tool.JsonTool;
import king.easyconfigir.tool.ResTool;

public class PopuMenuListener implements MouseListener{

	private JList mJList;
	private JPopupMenu jpm;
	
	public PopuMenuListener(JList jlist) {
		  this.mJList = jlist;
	      this.jpm = new JPopupMenu();
	      MenuItemRes menuItemRes = JsonTool.fromJson(ResTool.loadJson(R.json.navigation_popumenu), MenuItemRes.class);
		  for(String item : menuItemRes.getItems()) {
			       jpm.add(new JMenuItem(item));
		  }
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		if(e.getButton()==3&&mJList.getSelectedIndex()!=-1) {
			jpm.show(e.getComponent(), e.getX(), e.getY());
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
	
	}

}
