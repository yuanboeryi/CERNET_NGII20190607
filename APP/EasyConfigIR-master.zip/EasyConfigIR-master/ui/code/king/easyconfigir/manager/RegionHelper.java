package king.easyconfigir.manager;

import king.easyconfigir.R;
import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.common.manager.CommandSender;
import king.easyconfigir.model.Point;
import king.easyconfigir.model.PresetPoint;
import king.easyconfigir.model.Shape;
import king.easyconfigir.tool.JsonTool;
import king.easyconfigir.tool.LogTool;
import king.easyconfigir.ui.panel.ArgsPanel;
import king.easyconfigir.ui.panel.VideoPanel;
import king.easyconfigir.video.Overlay;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;

public class RegionHelper extends MouseAdapter implements VideoPanel.OverlayEventListener {

    private static RegionHelper instance;

    private ArrayList<Shape> region;
    private ArrayList<Shape> recycleShape;
    private ArrayList<Point> recyclePoint;

    private ArrayList<PresetPoint> presetPoints;

    private Shape currentShape;
    private Point currentPoint;
    private Point lastPoint;
    private Point startPoint;
    private Overlay mOverlay;

    private int currentType = Shape.TYPE_POINT;
    private Color currentPointColor;
    private Color currentShapeColor;

    private ArrayList<RegionEvent> regionEvents;

    private Overlay overlay;

    private boolean isCanAccept = false;

    private int submitPresetPointStartOffset = R.value.DEFAULT_SUBMIT_PRESET_POINT_START_OFFSET;
    private int cleanPresetPointStartOffset = R.value.DEFAULT_CLEAN_PRESET_POINT_START_OFFSET;

    public final static int MAX_REGION_SIZE = 10;

    public int getSubmitPresetPointStartOffset() {
        return submitPresetPointStartOffset;
    }

    public void setSubmitPresetPointStartOffset(int submitPresetPointStartOffset) {
        this.submitPresetPointStartOffset = submitPresetPointStartOffset;
    }

    public int getCleanPresetPointStartOffset() {
        return cleanPresetPointStartOffset;
    }

    public void setCleanPresetPointStartOffset(int cleanPresetPointStartOffset) {
        this.cleanPresetPointStartOffset = cleanPresetPointStartOffset;
    }

    public void freshOverlay() {
        if (overlay != null) {
            overlay.fresh();
        }
    }

    public void setOverlayVisible(boolean isVisible) {
        if (overlay != null) {
            overlay.setVisible(isVisible);
        }
        isCanAccept = isVisible;
    }

    @Override
    public void onOverlayCreate(Overlay overlay) {
        this.overlay = overlay;
    }

    public interface RegionEvent {
        void onAddPoint(Point point);

        void onDeleteShape(Shape shape);

        void onDeletePoint(Point point);
    }

    private PresetPointEvent presetPointEvent;

    public interface PresetPointEvent {
        void onChangedPresetPoints(ArrayList<PresetPoint> presetPoints);
    }

    public void setPresetPointEvent(PresetPointEvent presetPointEvent) {
        this.presetPointEvent = presetPointEvent;
    }

    private RegionHelper() {
        this.region = new ArrayList<>();
        this.regionEvents = new ArrayList<>();
        this.recycleShape = new ArrayList<>();
        this.recyclePoint = new ArrayList<>();
        this.presetPoints = new ArrayList<>();
    }

    public void addPresetPoint(PresetPoint presetPoint) {
        if (presetPoint != null) {
            this.presetPoints.add(presetPoint);
            if (this.presetPointEvent != null) {
                this.presetPointEvent.onChangedPresetPoints(this.presetPoints);
            }
        }
    }

    public void cleanPresetPoint() {
        this.presetPoints.clear();
        if (this.presetPointEvent != null) {
            this.presetPointEvent.onChangedPresetPoints(this.presetPoints);
        }
    }

    public ArrayList<PresetPoint> getPresetPoints() {
        return this.presetPoints;
    }

    private void sample() {
        Shape plane = new Shape(Shape.TYPE_PLANE);
        ArrayList<Point> ap = new ArrayList<>();

        ap.add(new Point(20, 20));
        ap.add(new Point(80, 20));
        ap.add(new Point(50, 50));

        plane.setPoints(ap);

        region.add(plane);
    }

    public void addRegionEventListener(RegionEvent regionEvent) {
        this.regionEvents.add(regionEvent);
    }

    public void cleanRecycleShape() {
        recycleShape.clear();
    }

    public void cleanRecyclePoint() {
        recyclePoint.clear();
    }

    public void cleanRegion(int id) {
        // FIXME 清除预设区域
        if (CommandSender.instance().isCanSend()) {
            int value = id - 1 + cleanPresetPointStartOffset;
            ArgsPanel.send(CommandFactory.instance().commandRegionClear(String.valueOf(value)));
        }
        currentShape = null;
        region.clear();
        freshOverlay();
    }

    public void submitRegion(int id) {
        cleanRecyclePoint();
        cleanRecycleShape();
        currentShape = null;
        freshOverlay();
        int value = id - 1 + submitPresetPointStartOffset;
        ArgsPanel.send(CommandFactory.instance().commandRegionClear(String.valueOf(value)));
        if (region != null && region.size() > 0) {
            // be kind of the device
            new Thread(() -> {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                ArgsPanel.send(CommandFactory.instance().commandRegionSet(getRegionString(value)));
            }).start();
        } else {
//            ArgsPanel.send(CommandFactory.instance().commandRegionClear(String.valueOf(value)));
            LogTool.i("RegionHelper", "region size is 0, instead of clean region");
        }
    }

    public boolean checkRegionFinished() {
        if (currentShape != null) {
            if (!currentShape.checkSelf().isStatus()) {
                return false;
            }
        }
        return true;
    }

    public boolean checkRegionSize() {
        return (this.region.size() <= MAX_REGION_SIZE);
    }

    public boolean checkPresetPointsNotEmpty() {
        return (this.presetPoints.size() > 0);
    }

    public boolean cancelPoint() {
        if (currentShape != null) {
            if (transfer(currentShape.getPoints(), recyclePoint)) {
                freshOverlay();
                return true;
            }
        }
        return false;
    }

    public boolean redoPoint() {
        if (currentShape != null) {
            if (transfer(recyclePoint, currentShape.getPoints())) {
                freshOverlay();
                return true;
            }
        }
        return false;
    }

    public boolean recoverShape() {
        if (transfer(recycleShape, region)) {
            currentShape = null;
            freshOverlay();
            return true;
        } else {
            return false;
        }
    }

    public boolean deleteShape() {
        if (transfer(region, recycleShape)) {
            currentShape = null;
            freshOverlay();
            return true;
        } else {
            return false;
        }
    }

    private <T> boolean transfer(ArrayList<T> a, ArrayList<T> b) {
        boolean is = false;
        if (a != null && b != null) {
            int size = a.size();
            if (size > 0) {
                T v = a.remove(size - 1);
                b.add(v);
                is = true;
            }
        }
        return is;
    }


    public String getRegionString(int id) {
        String value = format(id, region);
        LogTool.i("RegionHelper", "getRegionString value: " + value);
        return value;
    }

    public String getRegionJson() {
        String value = format(region);
        LogTool.i("RegionHelper", "getRegionJson value: " + value);
        return value;
    }

    private String format(int presetId, ArrayList<Shape> region) {
        // TODO 格式化区域坐标字符串
        int pointType = presetId; // FIXME 预设点编号从1开始
        StringBuilder data = new StringBuilder();
        int count = 0;

        int dx = (int) R.value.REGION_WIDTH;
        int dy = (int) R.value.REGION_HEIGHT;

        float fx = R.value.FX; // 横轴像素偏移率
        float fy = R.value.FY; // 纵轴像素偏移率

        float ofx = R.value.OFX; // 横轴像素偏移
        float ofy = R.value.OFY; // 纵轴像素偏移

        for (Shape shape : region) {
            int type = shape.getType();
            int rx = 0;
            int ry = 0;
            ArrayList<Point> points = shape.getPoints();
            LogTool.i("RegionHelper", "fx: " + fx + " fy: " + fy + " ofx: " + ofx + " ofy: " + ofy);
            switch (type) {
                case Shape.TYPE_POINT:
                    for (Point point : points) {
                        rx = Math.round(point.getX() * fx + ofx);
                        ry = Math.round(point.getY() * fy + ofy);
                        rx = Math.min(rx, dx);
                        rx = Math.max(rx, 0);
                        ry = Math.min(ry, dy);
                        ry = Math.max(ry, 0);
                        LogTool.i("RegionHelper", "POINT rx:" + rx + " ry:" + ry);
                        data.append("d,2/").append(rx).append(",").append(ry).append("/2,0/:");
                        count++;
                    }
                    break;
                case Shape.TYPE_LINE:
                case Shape.TYPE_PLANE:
                    data.append((type == Shape.TYPE_LINE) ? "l," : "p,");
                    data.append(points.size()).append("/");
                    for (Point point : points) {
                        rx = Math.round(point.getX() * fx + ofx);
                        ry = Math.round(point.getY() * fy + ofy);
                        rx = Math.min(rx, dx);
                        rx = Math.max(rx, 0);
                        ry = Math.min(ry, dy);
                        ry = Math.max(ry, 0);
                        LogTool.i("RegionHelper", ((type == Shape.TYPE_LINE) ? "LINE" : "PANEL") + " rx:" + rx + " ry:" + ry);
                        data.append(rx).append(",").append(ry).append("/");
                    }
                    data.append(":");
                    count++;
                    break;
                default:
                    break;
            }
        }

        data.insert(0, dx + "," + dy + ":" + pointType + "," + count + ":");

        return data.toString();
    }

    private String format(ArrayList<Shape> region) {
        String json = "";
        if (region != null) {
            ArrayList<Object> data = new ArrayList<>();
            for (Shape shape : region) {
                HashMap<String, Object> item = new HashMap<>();
                item.put("type", String.valueOf(shape.getType()));
                ArrayList<Object> xy = new ArrayList<>();
                for (Point point : shape.getPoints()) {
                    HashMap<String, String> value = new HashMap<>();
                    value.put("x", String.valueOf(point.getX()));
                    value.put("y", String.valueOf(point.getY()));
                    xy.add(value);
                }
                item.put("data", xy);
                data.add(item);
            }
            json = JsonTool.toJson(data);
        }
        return json;
    }

    public ArrayList<Shape> getRegion() {
        return region;
    }

    private void accept(int x, int y) {
        if (currentShape == null) {
            currentShape = new Shape(currentType, currentShapeColor);
            region.add(currentShape);
        }
        lastPoint = currentPoint;
        currentPoint = new Point(x, y);
        currentPoint.setColor(currentPointColor);
        if (currentShape.getSize() == 0) {
            startPoint = currentPoint;
        }
        currentShape.add(currentPoint);
        for (RegionEvent re : regionEvents) {
            re.onAddPoint(currentPoint);
        }
    }

    public void render(Graphics2D g) {
        for (Shape shape : region) {
            if (shape.getType() == Shape.TYPE_PLANE) {
                shape.drawSelf(g, (shape != currentShape));
            } else {
                shape.drawSelf(g);
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (!isCanAccept) return;
        int px = e.getX();
        int py = e.getY();
        accept(px, py);
        LogTool.i("RegionHelper", "mousePressed x: " + px + " y: " + py);
    }

    public void setCurrentType(int currentType) {
        this.currentType = currentType;
        if (currentShape != null) {
            currentShape.maybeLinkSelf();
            currentShape = null;
        }
        cleanRecyclePoint();
    }

    public void setCurrentPointColor(Color currentPointColor) {
        this.currentPointColor = currentPointColor;
    }

    public void setCurrentShapeColor(Color currentShapeColor) {
        this.currentShapeColor = currentShapeColor;
    }

    public Shape getCurrentShape() {
        return currentShape;
    }

    public int getCurrentType() {
        return currentType;
    }

    public static RegionHelper instance() {
        return (instance != null) ? instance : (instance = new RegionHelper());
    }
}