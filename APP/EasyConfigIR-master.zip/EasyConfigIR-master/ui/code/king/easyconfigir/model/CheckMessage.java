package king.easyconfigir.model;

public class CheckMessage {

        private boolean status;
        private String value;

        public CheckMessage(boolean status, String value) {
            this.status = status;
            this.value = value;
        }

        public boolean isStatus() {
            return status;
        }

        public void setStatus(boolean status) {
            this.status = status;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
}
