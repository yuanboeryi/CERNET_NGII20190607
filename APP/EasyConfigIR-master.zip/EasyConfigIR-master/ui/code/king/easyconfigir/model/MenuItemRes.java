package king.easyconfigir.model;

public class MenuItemRes {
	private String title;
    private String items[];
    
    public String getTitle() {
		return title;
	}
    
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String[] getItems() {
		return items;
	}
	
	public void setItems(String[] items) {
		this.items = items;
	}
	
	public int getCount() {
          if(items==null) return 0;
          else return items.length;
	}
}