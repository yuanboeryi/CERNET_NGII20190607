package king.easyconfigir.model;

/*
 * 菜单资源结构
 * {
 *     "name":"main",
 *     "menus":[
 *          {
 *                "title":"home",
 *                "items":["save", "edit"]
 *          },
 *          {
 *                "title":"file",
 *                "items":["save", "edit"]
 *          }
 *     ]
 * }
 */
public class MenuRes {
	private String name;
	private  MenuItemRes[]  menus;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public MenuItemRes[] getMenus() {
		return menus;
	}
	
	public void setMenus(MenuItemRes[] menus) {
		this.menus = menus;
	}
	
	public int getCount() {
        if(menus==null) return 0;
        else return menus.length;
	}
}
