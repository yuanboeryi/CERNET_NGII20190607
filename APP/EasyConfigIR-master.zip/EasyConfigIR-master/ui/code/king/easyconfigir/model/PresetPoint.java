package king.easyconfigir.model;

import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.ui.panel.ArgsPanel;

public class PresetPoint {
    private int id;
    private String name;
    private int distance;

    public PresetPoint(int id, String name, int distance) {
        this.id = id;
        this.name = name;
        this.distance = distance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public void callSelf() {
        ArgsPanel.send(CommandFactory.instance().commandPresetPointCall(String.valueOf(getId())));
    }
}
