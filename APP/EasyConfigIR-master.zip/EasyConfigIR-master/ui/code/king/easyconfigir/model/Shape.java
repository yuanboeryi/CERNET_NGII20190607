package king.easyconfigir.model;

import king.easyconfigir.R;
import king.easyconfigir.tool.LogTool;

import java.awt.*;
import java.util.ArrayList;

public class Shape {
    private int type;
    private Color color;
    private ArrayList<Point> points;

    // 线条宽瘦
    private final static float DEFAULT_THICK = R.value.LINE_THICK;

    private BasicStroke basicStroke;

    private Graphics2D g;

    public final static int TYPE_POINT = 0x00;
    public final static int TYPE_LINE = 0x01;
    public final static int TYPE_PLANE = 0x02;

    private final static Color DEFAULT_COLOR = new Color(255, 0, 0);

    public Shape() {
        this(TYPE_LINE);
    }

    public Shape(int type) {
        this(type, null);
    }

    public Shape(int type, Color color) {
        this(type, color, new ArrayList<>());
    }

    public Shape(int type, Color color, ArrayList<Point> points) {
        this.type = type;
        if (color == null) {
            this.color = DEFAULT_COLOR;
        } else {
            this.color = color;
        }
        this.points = points;
        this.basicStroke = new BasicStroke(DEFAULT_THICK, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND);
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public ArrayList<Point> getPoints() {
        return points;
    }

    public void setPoints(ArrayList<Point> points) {
        this.points = points;
    }

    public void clear() {
        if (this.points != null) {
            points.clear();
        }
    }

    public void add(Point point) {
        if (this.points != null) {
            this.points.add(point);
        }
    }

    public int getSize() {
        return (this.points != null) ? this.points.size() : 0;
    }

    public Point get(int index) {
        if (this.points != null) {
            if (index >= 0 && index < this.points.size()) {
                return this.points.get(index);
            }
        }
        return null;
    }

    public void drawSelf(Graphics2D g) {
        this.drawSelf(g, false);
    }

    public void drawSelf(Graphics2D g, boolean isFinishedPanel) {
        this.g = g;
        switch (type) {
            case Shape.TYPE_POINT:
                for (Point point : points) {
                    point.drawSelf(g);
                }
                break;
            case Shape.TYPE_LINE:
            case Shape.TYPE_PLANE:
                Point last = null;
                for (Point point : points) {
                    point.drawSelf(g);
                    if (last != null) {
                        drawLine(g, last, point);
                    }
                    last = point;
                }
                if (isFinishedPanel && points.size() >= 3) {
                    drawLine(g, last, points.get(0));
                    LogTool.i("Shape", "drawSelf size: " + points.size());
                }
                break;
            default:
                break;
        }
    }

    public void maybeLinkSelf() {
        if (type == Shape.TYPE_PLANE) {
            linkSelf(g);
        }
    }

    public void linkSelf(Graphics2D g) {
        int a = getSize() - 1;
        int b = 0;
        ArrayList<Point> c = getPoints();
        if (a != b && c != null) {
            drawLine(g, c.get(a), c.get(b));
        }
    }

    public CheckMessage checkSelf() {
        if (type == TYPE_POINT) return new CheckMessage((getPoints().size() > 0), "点至少包含1个坐标！");
        if (type == TYPE_LINE) return new CheckMessage((getPoints().size() > 1), "线至少包含2个坐标！");
        if (type == TYPE_PLANE) return new CheckMessage((getPoints().size() > 2), "面至少包含3个坐标！");
        return new CheckMessage(false, "未知检测类型: " + type);
    }

    private void drawLine(Graphics2D g, Point a, Point b) {
        g.setColor(color);
        g.setStroke(basicStroke);
        g.drawLine(a.getX(), a.getY(), b.getX(), b.getY());
        a.drawSelf(g);
        b.drawSelf(g);
    }
}
