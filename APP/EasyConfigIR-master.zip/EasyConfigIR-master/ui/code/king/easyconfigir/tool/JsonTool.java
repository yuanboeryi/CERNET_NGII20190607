package king.easyconfigir.tool;

public class JsonTool extends king.easyconfigir.common.tool.JsonTool {
}
