package king.easyconfigir.tool;

public class LogTool extends king.easyconfigir.common.tool.LogTool {
}
