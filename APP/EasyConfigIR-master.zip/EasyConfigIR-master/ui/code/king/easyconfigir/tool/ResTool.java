package king.easyconfigir.tool;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class ResTool {

    public static String loadJson(String url) {
        StringBuilder sb = new StringBuilder();
        try {
            InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(url);
            assert is != null;
            BufferedReader buff = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            String line;
            while ((line = buff.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    public static void tryOpenURL(String url) {
        if (!Desktop.isDesktopSupported()) {
            //测试当前平台是否支持此类
            JOptionPane.showMessageDialog(null, "浏览器设置不支持，请手动输入链接：\n " + url);
            return;
        }
        //用来打开系统默认浏览器浏览指定的URL
        Desktop desktop = Desktop.getDesktop();
        try {
            //创建URI统一资源标识符
            URI uri = new URI(url);
            //使用默认浏览器打开超链接
            desktop.browse(uri);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
