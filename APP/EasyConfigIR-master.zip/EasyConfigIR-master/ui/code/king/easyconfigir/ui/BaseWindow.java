package king.easyconfigir.ui;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;

import javax.swing.JFrame;
import javax.swing.SpringLayout;

import king.easyconfigir.tool.LogTool;
import king.easyconfigir.ui.menu.MainMenuBar;

public class BaseWindow extends JFrame {
	protected SpringLayout mainLayout;
	protected JFrame window;
	protected MainMenuBar mainMenuBar;
	protected int width;
	protected int height;

	public BaseWindow(String title, int width, int height) {
		super(title);
		this.window = this;
		this.setSize(width, height);
		this.width = width;
		this.height = height;
		this.initWindowConfig(this.window);
		this.initWindowLocation(this.window);
	}

	protected void initWindowConfig(JFrame window) {
		// window.setResizable(true);
		window.setResizable(false);
	}

	protected void setLogo(String path) {
		URL url = Thread.currentThread().getContextClassLoader().getResource(path);
		LogTool.i("setLogo", "url: "+url.getPath());
		Image image = Toolkit.getDefaultToolkit().createImage(url);
		if (image != null) {
			window.setIconImage(image);
		}
	}

	/*
	 * 调整主窗体位置
	 */
	protected void initWindowLocation(JFrame window) {
		Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int) screensize.getWidth();
		int height = (int) screensize.getHeight();
		window.setLocation((width - window.getWidth()) / 2, (height - window.getHeight()) / 2);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
