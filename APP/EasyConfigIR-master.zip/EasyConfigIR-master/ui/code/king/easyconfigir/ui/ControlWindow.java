package king.easyconfigir.ui;

import king.easyconfigir.R;
import king.easyconfigir.common.manager.CommandSender;
import king.easyconfigir.manager.RegionHelper;
import king.easyconfigir.tool.LogTool;
import king.easyconfigir.tool.ResTool;
import king.easyconfigir.ui.menu.MainMenuBar;
import king.easyconfigir.ui.panel.ArgsPanel;
import king.easyconfigir.ui.panel.PresetPanel;
import king.easyconfigir.ui.panel.VideoPanel;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ControlWindow extends BaseWindow implements MouseListener {

    private VideoPanel videoPanel;
    private ArgsPanel argsPanel;
    private PresetPanel presetPanel;

    // 使用懒汉加载模式
    private static ControlWindow instance;

    private ControlWindow() {
        this(R.title.APP_NAME,
                R.size.CONTROL_WINDOW_WIDTH,
                R.size.CONTROL_WINDOW_HEIGHT
        );
    }

    private ControlWindow(String title, int width, int height) {
        super(title, width, height);
        this.initWindowViews(this);
        this.addWindowListener(new WindowAdapter() {

            @Override
            public void windowOpened(WindowEvent e) {
                LogTool.i("ControlWindow", "window has been opened.");
            }

            @Override
            public void windowClosing(WindowEvent e) {
                release();
                LogTool.i("ControlWindow", "window has been closed.");
            }

        });

        this.setLogo("image/logo.gif");
        //获取焦点，监听键盘事件
        this.setFocusable(true);
    }

    private void initWindowViews(ControlWindow window) {
        window.setLayout(null);
        mainMenuBar = new MainMenuBar(ResTool.loadJson(R.json.control_menu_bar));
        videoPanel = new VideoPanel();
        argsPanel = new ArgsPanel();
        presetPanel = new PresetPanel();
        mainMenuBar.setLocation(0, 0);
        videoPanel.setLocation(2, mainMenuBar.getHeight() + 2);
        argsPanel.setLocation(2, mainMenuBar.getHeight() + videoPanel.getHeight() + 2);
        presetPanel.setLocation(videoPanel.getWidth() + 4, mainMenuBar.getHeight() + 2);
        window.add(mainMenuBar);
        window.add(videoPanel);
        window.add(argsPanel);
        window.add(presetPanel);

        argsPanel.setWindow(window);
        presetPanel.setWindow(window);

        mainMenuBar.setPresetPanel(presetPanel);
        argsPanel.setPresetPanel(presetPanel);

        videoPanel.setOverlayEventListener(RegionHelper.instance());

        mainMenuBar.setVideoPanel(videoPanel);

        argsPanel.addMouseListener(window);
        presetPanel.addMouseListener(window);
    }

    public void display() {
        this.display(true);
    }

    public void display(boolean isOverlay) {
        this.setVisible(true);
        if (isOverlay) {
            videoPanel.showOverlay(this);
            this.setVisible(false);
            this.setVisible(true);
        }
    }

    public void release() {
        CommandSender.instance().release();
        videoPanel.release();
    }

    public MainMenuBar getMainMenuBar() {
        return mainMenuBar;
    }

    public VideoPanel getVideoPanel() {
        return videoPanel;
    }

    public void closeSelf() {
        if (instance != null) {
            release();
            this.setVisible(false);
            LogTool.i("ControlWindow", "Bye, closeSelf oK!");
        }
//        System.exit(0);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub
        this.requestFocusInWindow();
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    public static ControlWindow instance() {
        if (instance == null) {
            instance = new ControlWindow();
        }
        return instance;
    }

}
