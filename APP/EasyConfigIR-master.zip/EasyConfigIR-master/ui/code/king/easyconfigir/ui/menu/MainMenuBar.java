package king.easyconfigir.ui.menu;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SpringLayout;

import king.easyconfigir.App;
import king.easyconfigir.R;
import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.model.MenuItemRes;
import king.easyconfigir.model.MenuRes;
import king.easyconfigir.tool.JsonTool;
import king.easyconfigir.tool.LogTool;
import king.easyconfigir.ui.ControlWindow;
import king.easyconfigir.ui.panel.ArgsPanel;
import king.easyconfigir.ui.panel.MediaControlPanel;
import king.easyconfigir.ui.panel.MiscPanel;
import king.easyconfigir.ui.panel.PresetPanel;
import king.easyconfigir.ui.panel.PresetPointControlListPanel;
import king.easyconfigir.ui.panel.PresetPointControlPanel;
import king.easyconfigir.ui.panel.SwitchPanel;
import king.easyconfigir.ui.panel.VideoControlPanel;
import king.easyconfigir.ui.panel.VideoPanel;
import king.easyconfigir.update.panel.UpdateControlPanel;

public class MainMenuBar extends BaseMenuBar {

    private final static String TAG = "MainMenuBar";
    private MenuRes mMenuRes;
    private JFrame window;
    private JDialog jdPreset0;
    private JDialog jdPreset1;
    private JDialog jdVideoControl;
    private JDialog jdMediaControl;
    private JDialog jdMiscControl;

    private JDialog jdUpdateControl;

    private SwitchPanel switchPanel;
    private PresetPanel presetPanel;

    private VideoControlPanel videoControlPanel;

    private int x = 0;
    private int y = 0;

    public MainMenuBar(String jsonRes) {
        this(null, jsonRes, null);
    }

    public MainMenuBar(JFrame window, String jsonRes) {
        this(window, jsonRes, null);
    }

    public MainMenuBar(JFrame window, String jsonRes, SpringLayout layout) {
        this(window, jsonRes,
                R.size.MAIN_MENU_BAR_WIDTH,
                R.size.MAIN_MENU_BAR_HEIGHT,
                layout
        );
    }

    public MainMenuBar(JFrame window, String jsonRes, int width, int height, SpringLayout layout) {
        super(width, height, layout);
        this.window = window;
        mMenuRes = JsonTool.fromJson(jsonRes, MenuRes.class);
        this.createMenus(mMenuRes);
        this.setBackground(R.color.MAIN_MENU_BAR_BACKGROUND_COLOR);
//	  			   PresetPointControlPanel ppc= new PresetPointControlPanel();
        //jd.setSize(280, 200);
        this.jdPreset0 = this.createDialog(window, 280, 200, R.title.PRESET_CONTROL_PANEL, new PresetPointControlPanel());
        PresetPointControlListPanel ppcp = new PresetPointControlListPanel();
        this.jdPreset1 = this.createDialog(window, ppcp.getWidth(), ppcp.getHeight(), R.title.PRESET_CONTROL_PANEL, ppcp);
        videoControlPanel = new VideoControlPanel();
        this.jdVideoControl = this.createDialog(window, videoControlPanel.getWidth(), videoControlPanel.getHeight(), R.title.VIDEO_CONTROL_PANEL, videoControlPanel);
        MiscPanel miscPanel = new MiscPanel();
        this.jdMiscControl = this.createDialog(window, miscPanel.getWidth(), miscPanel.getHeight(), R.title.MISC_CONTROL_PANEL, miscPanel);
        MediaControlPanel mediaPanel = new MediaControlPanel();
        this.jdMediaControl = this.createDialog(window, miscPanel.getWidth(), miscPanel.getHeight(), R.title.MEDIA_CONTROL_PANEL, mediaPanel);
    }

    private void createMenus(MenuRes menuRes) {
        if (menuRes != null) {
            this.setName(mMenuRes.getName());
            x = 0;
            for (MenuItemRes menu : mMenuRes.getMenus()) {
                JMenu child = new JMenu(menu.getTitle());
                child.setForeground(R.color.MAIN_MENU_FONT_COLOR);
                y = 0;
                for (String item : menu.getItems()) {
                    JMenuItem jmi = new JMenuItem(item);
                    jmi.setBackground(R.color.MAIN_MENU_ITEM_BACKGROUND_COLOR);
                    if (is(0, 3)) {
                        jmi.addActionListener(e -> {
                            if (jdPreset0 != null) {
                                jdPreset0.setVisible(true);
                            }
                        });
                    } else if (is(0, 0)) {
                        jmi.addActionListener(e -> {
                            if (jdPreset1 != null) {
                                jdPreset1.setVisible(true);
                            }
                        });
                    } else if (is(0, 1)) {
                        jmi.addActionListener(e -> {
                            showInfoMessage("perform AllPresetPointScan...");
                            ArgsPanel.send(CommandFactory.instance().commandAllPresetPointScan());
                        });
                    } else if (is(0, 2)) {
                        jmi.addActionListener(e -> {
                            showInfoMessage("perform AllPresetPointClear...");
                            ArgsPanel.send(CommandFactory.instance().commandAllPresetPointClear());
                        });
                    } else if (is(1, 0)) {
                        jmi.addActionListener(e -> {
                            showInfoMessage("perform CloudAdjust...");
                            ArgsPanel.send(CommandFactory.instance().commandCloudAdjust());
                        });
                    } else if (is(1, 1)) {
                        jmi.addActionListener(e -> {
                            showInfoMessage("perform ArgsReset...");
                            ArgsPanel.send(CommandFactory.instance().commandArgsReset());
                        });
                    } else if (is(1, 2)) {
                        jmi.addActionListener(e -> {
                            showInfoMessage("perform OSReset...");
                            ArgsPanel.send(CommandFactory.instance().commandOSReset());
                        });
                    } else if (is(1, 3)) {
                        jmi.addActionListener(e -> {
                            showInfoMessage("perform CaptureIRFrame...");
                            ArgsPanel.send(CommandFactory.instance().commandCaptureIRFrame());
                        });
                    } else if (is(1, 4)) {
                        jmi.addActionListener(e -> {
                            showInfoMessage("perform SSHRestart...");
                            ArgsPanel.send(CommandFactory.instance().commandSSHRestart());
                        });
                    } else if (is(1, 5)) {
                        jmi.addActionListener(e -> switchPanel.changeView());
                    } else if (is(1, 6)) {
                        jmi.addActionListener(e -> showInfoMessage(R.info.UNIMPLEMENT));
                    } else if (is(2, 0)) {
                        jmi.addActionListener(e -> JOptionPane.showMessageDialog(null, R.info.UNIMPLEMENT));
                    } else if (is(3, 0)) {
                        jmi.addActionListener(e -> {
                            if (jdVideoControl != null) {
                                jdVideoControl.setVisible(true);
                            }
                        });
                    } else if (is(3, 1)) {
                        jmi.addActionListener(e -> {
                            if (jdUpdateControl == null) {
                                UpdateControlPanel updateControlPanel = App.getUpdateControlPanel();
                                this.jdUpdateControl = this.createDialog(window, updateControlPanel.getWidth(), updateControlPanel.getHeight(), R.title.UPDATE_CONTROL_PANEL, updateControlPanel);
                            }
                            jdUpdateControl.setVisible(true);
                        });
                    } else if (is(3, 2)) {
                        jmi.addActionListener(e -> {
                            if (jdMediaControl != null) {
                                jdMediaControl.setVisible(true);
                            }
                        });
                    } else if (is(3, 3)) {
                        jmi.addActionListener(e -> {
                            if (jdMiscControl != null) {
                                jdMiscControl.setVisible(true);
                            }
                        });
                    } else if (is(4, 0)) {
                        jmi.addActionListener(e -> JOptionPane.showMessageDialog(null, R.info.SUPPORT_VLC_WARN));
                    } else if (is(4, 1)) {
//                        jmi.addActionListener(e -> ResTool.tryOpenURL(R.url.UPDATE));
//                        jmi.addActionListener(e -> ControlWindow.instance().closeSelf());
                        jmi.addActionListener(e -> {
//                            ControlWindow.instance().closeSelf();
                            App.checkUpdate();
                        });
                    } else if (is(4, 2)) {
                        jmi.addActionListener(e -> {
                            JOptionPane.showMessageDialog(null, App.getVersionMessage());
                        });
                    } else if (is(4, 3)) {
                        jmi.addActionListener(e -> {
                            ControlWindow.instance().closeSelf();
                            System.exit(0);
                        });
                    }
                    child.add(jmi);
                    y++;
                }
                this.add(child);
                x++;
            }
        } else {
            LogTool.i(TAG, "createMenus( ) -> menuRes is null!");
        }
    }

    public void setSwitchPanel(SwitchPanel switchPanel) {
        this.switchPanel = switchPanel;
    }

    public void setPresetPanel(PresetPanel presetPanel) {
        this.presetPanel = presetPanel;
    }

    public void setVideoPanel(VideoPanel videoPanel) {
        this.videoControlPanel.setVideoPanel(videoPanel);
    }

    private JDialog createDialog(JFrame window, int w, int h, String text, JPanel content) {
        JDialog jd = new JDialog(window, text, false);
        jd.setSize(w, h);
        jd.setContentPane(content);
        Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = (int) screensize.getWidth();
        int height = (int) screensize.getHeight();
        jd.setLocation((width - jd.getWidth()) / 2, (height - jd.getHeight()) / 2);
        jd.setResizable(false);
        return jd;
    }

    public boolean is(int xx, int yy) {
        return (x == xx && y == yy);
    }

    public void showErrorMessage(String message) {
        presetPanel.showErrorMessage(message);
    }

    public void showWarnMessage(String message) {
        presetPanel.showWarnMessage(message);
    }

    public void showInfoMessage(String message) {
        presetPanel.showInfoMessage(message);
    }

    public void showMessage(String message) {
        presetPanel.showMessage(message);
    }
}
