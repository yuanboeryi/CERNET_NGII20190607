package king.easyconfigir.ui.panel;

import king.easyconfigir.R;
import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.common.manager.CommandSender;
import king.easyconfigir.common.model.CommandWrapper;
import king.easyconfigir.common.tool.LogTool;
import king.easyconfigir.tool.TextTool;
import king.easyconfigir.ui.ControlWindow;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class ArgsPanel extends BasePanel implements CommandSender.OnSenderEvent, ActionListener {

    private String color[] = {"紫黄色", "铁红色", "彩虹色(红黄蓝)", "灰白色", "多彩色", "红白色"};
    private String fss[] = {"0.05,铝,抛光处理",
            "0.25,铝,氧化处理",
            "0.85,砖,普通",
            "0.54,混凝土",
            "0.02,铜,抛光处理",
            "0.65,铜,氧化处理",
            "0.95,绝缘胶带,黑色",
            "0.94,涂料",
            "0.92,瓷,上釉处理",
            "0.90,纸,白色",
            "0.93,橡胶",
            "1.00,黑体",
    };
    //  private VideoPanel videoPanel;
//	  private MainMenuBar mainMenuBar;
//	  
    private LinePanel lpip;
    private DoublePanel pl;
    private DoublePanel yunip;
    private DoublePanel sship;
    private SwitchPanel swp;
    private SelectPanel sp;
    private SelectPanel fs;
    private LinePanel hwc;
    private LinePanel gbc;
    private LinePanel rec;
    private LinePanel dem;
    private LinePanel sw;

    private boolean isDeviceConnected = false;

    private ControlWindow window;

    private PresetPanel presetPanel;

    public void setPresetPanel(PresetPanel presetPanel) {
        this.presetPanel = presetPanel;
        this.swp.setPresetPanel(presetPanel);
    }

    public void setWindow(ControlWindow window) {
//        ArgsPanel.window = window;
        this.window = window;
        this.swp.setWindow(window);
    }

    public ArgsPanel() {
        this(null);
    }

    public ArgsPanel(SpringLayout layout) {
        this(R.size.CONTROL_ARGS_WIDTH,
                R.size.CONTROL_ARGS_HEIGHT,
                layout
        );
    }

    public ArgsPanel(int width, int height, SpringLayout layout) {
        this(R.title.ARGS_PANEL, width, height, layout);
    }

    public ArgsPanel(String title, int width, int height, SpringLayout layout) {
        super(title, width, height, layout);
        this.setLayout(null);
        this.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        int lpad = 4;
        int lhei = 8;
        lpip = new LinePanel("设备地址:", "连接设备");
        lpip.setLocation(lpad, lhei);
        this.add(lpip);

        pl = new DoublePanel("WIFI名称:", "WIFI密码:", "设置WIFI");
        lhei += 2 + lpip.getHeight();
        pl.setLocation(lpad, lhei);
        this.add(pl);

        yunip = new DoublePanel("MQTT地址:", "FTP地址:", "保存地址");
        lhei += 2 + pl.getHeight();
        yunip.setLocation(lpad, lhei);
        this.add(yunip);

        sship = new DoublePanel("SSH地址:", "端口号:", "确认地址");
        lhei += 2 + yunip.getHeight();
        sship.setLocation(lpad, lhei);
        this.add(sship);

        // 中间区域
        swp = new SwitchPanel();
        lpad = (width - swp.getWidth()) / 2;
        lhei = 8;
        swp.setLocation(lpad, lhei);
        this.add(swp);

        lpad = width - sship.getWidth() - 2;
        lhei = 8;

        sp = new SelectPanel("图片色带:", color, "设置");
        sp.setLocation(lpad, lhei);
        this.add(sp);

        fs = new SelectPanel("辐射率:", fss, "设置");
        lhei += 2 + sp.getHeight();
        fs.setLocation(lpad, lhei);
        this.add(fs);

        hwc = new LinePanel("红外呈现参数:", 80, 5, "更新");
        lhei += 2 + fs.getHeight();
        hwc.setLocation(lpad, lhei);
        this.add(hwc);

        gbc = new LinePanel("红外勾边参数:", 80, 5, "更新");
        lhei += 2 + hwc.getHeight();
        gbc.setLocation(lpad, lhei);
        this.add(gbc);

        rec = new LinePanel("系统时间:", "校准");
        lhei += 2 + gbc.getHeight();
        rec.setLocation(lpad, lhei);
        this.add(rec);

        dem = new LinePanel("设备ID:", "修改");
        lhei += 2 + rec.getHeight();
        dem.setLocation(lpad, lhei);
        this.add(dem);

        sw = new LinePanel("守望点:", "标记");
        lhei += 2 + dem.getHeight();
        sw.setLocation(lpad, lhei);
        this.add(sw);

        lpip.setValue("hs://" + R.ip.DEFAULT_COMMAND_IP);

        pl.setFirstValue(R.value.DEFAULT_DEVICE_WIFI_NAME);
        pl.setSecondValue(R.value.DEFAULT_DEVICE_WIFI_PASSWORD);

        lpip.setListener(this);
        pl.setListener(this);
        yunip.setListener(this);
        sship.setListener(this);
        sp.setListener(this);
        fs.setListener(this);
        hwc.setListener(this);
        gbc.setListener(this);
        rec.setListener(this);
        dem.setListener(this);
        sw.setListener(this);

        CommandSender.instance().addOnSenderEvent(this);
    }

    public void showSuccessToast(String message) {
        presetPanel.showSuccessToast(message);
    }

    public void showNormalToast(String message) {
        presetPanel.showNormalToast(message);
    }

    public void showErrorToast(String message) {
        presetPanel.showErrorToast(message);
    }

    public void showErrorMessage(String message) {
        presetPanel.showErrorMessage(message);
    }

    public void showWarnMessage(String message) {
        presetPanel.showWarnMessage(message);
    }

    public void showInfoMessage(String message) {
        presetPanel.showInfoMessage(message);
    }

    public void showMessage(String message) {
        presetPanel.showMessage(message);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == lpip.getSource()) {
            connectDevice();
        } else if (e.getSource() == pl.getSource()) {
            String wifi = pl.getFirstValue();
            String password = pl.getSecondValue();
            if (TextTool.checkNull(wifi)) {
                showWarnMessage("wifi name is null! ");
                return;
            }
            if (TextTool.checkNull(password)) {
                showWarnMessage("password is null!");
                return;
            }
            showInfoMessage("input wifi: " + wifi + " password: " + password);
            send(CommandFactory.instance().commandWifiSet(wifi, password));
        } else if (e.getSource() == yunip.getSource()) {
            String mqtt = yunip.getFirstValue();
            String ftp = yunip.getSecondValue();
            if (checkIP(mqtt, "mqtt address") && checkIP(ftp, "ftp address")) {
                showInfoMessage("input mqtt: " + mqtt + " ftp:" + ftp);
                send(CommandFactory.instance().commandServerAddressSet(mqtt, ftp));
            }
        } else if (e.getSource() == sship.getSource()) {
            String ssh = sship.getFirstValue();
            String port = sship.getSecondValue();
            if (checkIP(ssh, "ssh address") && checkPort(port, "prot")) {
                showInfoMessage("input ssh: " + ssh + " port:: " + port);
                send(CommandFactory.instance().commandSSH(ssh, port));
            }
        } else if (e.getSource() == sp.getSource()) {
            String value = sp.getValue();
            if (TextTool.isValidIntegerRange(value, 0, color.length, TextTool.LEFT_CLOSE_RIGHT_OPEN)) {
                showInfoMessage("input picture color index: " + value);
                send(CommandFactory.instance().commandPictureColorSet(value));
            } else {
                showInfoMessage("input picture color index invalid. range: [ 0, " + (color.length - 1) + " ]");
            }
        } else if (e.getSource() == fs.getSource()) {
            String value = fss[Integer.valueOf(fs.getValue())];
            value = value.substring(0, 4);
            if (TextTool.isValidFloatRange(value, 0, 1.0, TextTool.LEFT_OPEN_RIGHT_CLOSE)) {
                showInfoMessage("input emissivity: " + value);
                send(CommandFactory.instance().commandEmissivitySet(value));
            } else {
                showInfoMessage("input emissivity invalid. float range: ( 0, 1.0 ]");
            }
        } else if (e.getSource() == hwc.getSource()) {
            String value = hwc.getValue();
            if (TextTool.isValidFloatRange(value, 1.0, 5.0, TextTool.ALL_OPEN)) {
                showInfoMessage("input IRShowArgs: " + value);
                send(CommandFactory.instance().commandIRShowArgs(value));
            } else {
                showInfoMessage("input IRShowArgs invalid. float range: ( 1.0, 5.0 )");
            }
        } else if (e.getSource() == gbc.getSource()) {
            String value = gbc.getValue();
            if (TextTool.isValidFloatRange(value, 0, 1.0, TextTool.ALL_OPEN)) {
                showInfoMessage("input IRSideArgs: " + value);
                send(CommandFactory.instance().commandIRSideArgs(value));
            } else {
                showInfoMessage("input IRSideArgs invalid. float range: ( 0, 1.0 )");
            }
        } else if (e.getSource() == rec.getSource()) {
            String value = rec.getValue();
            if (TextTool.isValidTime(value)) {
                showInfoMessage("input OSTime: " + value);
                send(CommandFactory.instance().commandOSTimeAdjust(value));
            } else {
                showInfoMessage("input time format invalid. format: xxxx-xx-xx xx:xx:xx");
            }
        } else if (e.getSource() == dem.getSource()) {
            String value = dem.getValue();
            if (!TextTool.checkNull(value)) {
                showInfoMessage("input device id: " + value);
                send(CommandFactory.instance().commandDeviceIDModify(value));
            } else {
                showInfoMessage("device id is null.");
            }
        } else if (e.getSource() == sw.getSource()) {
            String value = sw.getValue();
            if (TextTool.isValidIntegerRange(value, 1, 128, TextTool.ALL_CLOSE)) {
                showInfoMessage("input lookup point: " + value);
                send(CommandFactory.instance().commandLookupPointSet(value));
            } else {
                showInfoMessage("input lookup point invalid. integer range: [ 1, 128 ]");
            }
        }
    }

    private boolean checkIP(String p0, String p1) {
        boolean is = false;
        if (!TextTool.checkNull(p0)) {
            if (TextTool.isValidIP(p0)) {
                is = true;
            } else {
                showWarnMessage(p1 + " is invalid! " + p0);
            }
        } else {
            showWarnMessage(p1 + " is null!");
        }
        return is;
    }

    private boolean checkPort(String p0, String p1) {
        boolean is = false;
        if (!TextTool.checkNull(p0)) {
            if (TextTool.isValidPort(p0)) {
                is = true;
            } else {
                showWarnMessage(p1 + " is invalid! " + p0);
            }
        } else {
            showWarnMessage(p1 + " is null!");
        }
        return is;
    }

    private void connectDevice() {
        String ip = null;
        String port = R.prot.HS_COMMAND_PORT;
        String device_id = CommandFactory.instance().getDeviceID();
        String value = lpip.getValue();
        if (!TextTool.checkNull(value)) {
            HashMap<String, String> ss = TextTool.matchDeviceToken(value);
            if (ss != null) {
                ip = ss.get("host");
                if (ss.get("port") != null) {
                    port = ss.get("port");
                }
                if (ss.get("device_id") != null) {
                    device_id = ss.get("device_id");
                    CommandFactory.instance().setDeviceID(device_id);
                }
            } else {
                showWarnMessage("device address is invalid! " + value);
                return;
            }
        } else {
            showWarnMessage("device address is null!");
            return;
        }

        lpip.setEnabled(false);
        if (isDeviceConnected) {
            CommandSender.instance().stop();
            window.getVideoPanel().stop();
        } else {
            showInfoMessage("input ip: " + ip + " port: " + port + " device_id: " + device_id);
            if (!CommandSender.instance().isStart()) {
                //CommandSender.instance(R.ip.TEST_COMMAND_IP, R.prot.TEST_COMMAND_PORT).start();
                CommandSender.instance(ip, port).start();
            }
            window.getVideoPanel().playHS(ip);
            LogTool.i("ArgsPanel", "input ip: " + ip + " port: " + port + " device_id: " + device_id);
        }
    }

    public static void send(CommandWrapper commandWrapper) {
        if (CommandSender.instance().isCanSend()) {
            CommandSender.instance().send(commandWrapper);
        } else {
//             ToastTool.makeText(ControlWindow.instance(), "请先连接设备！", ToastTool.Style.NORMAL).display();
            JOptionPane.showMessageDialog(null, "请先连接设备！");
        }
    }

    @Override
    public void onCSError(Exception e) {
        // TODO Auto-generated method stub
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                isDeviceConnected = false;
                showErrorMessage(e.toString());
                window.getVideoPanel().release();
                showWarnMessage("videoPanel release");
                lpip.setButtonText("连接设备");
                lpip.setEnabled(true);
                showErrorToast("服务运行异常！");

            }
        });

    }

    @Override
    public void onCSStart() {
        // TODO Auto-generated method stub
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                lpip.setButtonText("断开设备");
                isDeviceConnected = true;
                lpip.setEnabled(true);
                showInfoMessage("CommandSender: " + CommandSender.instance().getHost() + ":" +
                        CommandSender.instance().getPort() + " is waiting...");
                showSuccessToast("服务已正常启动！");
            }
        });

    }

    @Override
    public void onCSRunning() {
        // TODO Auto-generated method stub
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                //showMessage("CommandSender: "+CommandSender.instance().getHost()+":"+ CommandSender.instance().getPort()+" is waiting...");
            }
        });

    }

    @Override
    public void onCSStop() {
        // TODO Auto-generated method stub
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                lpip.setButtonText("连接设备");
                isDeviceConnected = false;
                lpip.setEnabled(true);
                showInfoMessage("CommandSender: " + CommandSender.instance().getHost() + ":" +
                        CommandSender.instance().getPort() + " exited!");
                showSuccessToast("服务已成功关闭！");
            }
        });

    }

    @Override
    public void onCSSend(CommandWrapper commandWrapper, String jsonData) {
        // TODO Auto-generated method stub
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                showMessage("send ok! " + commandWrapper.getName());
                showMessage(jsonData);
                String name = commandWrapper.getName();

                if ("修改设备ID号指令".equals(name)) {
                    String token = "hs://" + CommandSender.instance().getHost() + ":" + CommandSender.instance().getPort() + "/" + dem.getValue();
                    lpip.doClick();
                    JOptionPane.showMessageDialog(null, "你已成功修改设备ID，3秒后，将自动重连设备。如果，连接失败，请手动重连！");
                    new Thread(
                            () -> {
                                try {
                                    Thread.sleep(3000);
                                    SwingUtilities.invokeLater(() -> {
                                        dem.setValue("");
                                        lpip.setValue(token);
                                        lpip.doClick();
                                    });
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                    ).start();
                }

                if (
                        "设置预设点指令".equals(name) ||
                                "调用预设点指令".equals(name) ||
                                "清除预设点指令".equals(name) ||
                                "修改预设点距离指令".equals(name) ||
                                R.flag.DISABLED_TOAST_SEND
                ) {

                    return;
                }

                showSuccessToast("发送" + commandWrapper.getName() + "成功!");
            }
        });
    }
}