package king.easyconfigir.ui.panel;

import javax.swing.JPanel;
import javax.swing.Spring;
import javax.swing.SpringLayout;

public class BasePanel extends JPanel{
     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    protected SpringLayout layout;
    protected SpringLayout.Constraints layoutCons;
    
	public BasePanel(String title, int width,  int height, SpringLayout layout) {
		   super();
   	       this.setName(title);
   	       this.setSize(width, height);
	       this.setBounds(0, 0, width, height);
   	       this.layout = layout;
   	       if(layout!=null) {
   	    	   layoutCons = layout.getConstraints(this);
   	    	   layoutCons.setWidth(Spring.constant(width));
   	    	   layoutCons.setHeight(Spring.constant(height));
	       }
	}

	public  SpringLayout.Constraints getConstraints() {
            return this.layoutCons;
    }
	
	public Spring getConstraint(String flag) {
		 if(this.layoutCons != null) {
			  return this.layoutCons.getConstraint(flag);
		  }
		 return Spring.constant(0);
	}
	
	public int getSpringSouthValue() {
		   return this.getSpringSouth().getValue();
	}
	
	public int getSpringNorthValue() {
		   return this.getSpringNorth().getValue();
	}
	
	public int getSpringWestValue() {
		   return this.getSpringWest().getValue();
	}
	
	public int getSpringEastValue() {
		   return this.getSpringEast().getValue();
	}
	
	public Spring getSpringSouth() {
		 return this.getConstraint(SpringLayout.SOUTH);
	}
	
	public Spring getSpringNorth() {
		 return this.getConstraint(SpringLayout.NORTH);
	}
	
	public Spring getSpringEast() {
		 return this.getConstraint(SpringLayout.EAST);
	}
	
	public Spring getSpringWest() {
		 return this.getConstraint(SpringLayout.WEST);
	}
	
	public BasePanel setSpringXY(int x, int y) {
		   return this.setSpringXY(Spring.constant(x), Spring.constant(y));
	}
	
	public BasePanel setSpringXY(Spring x, Spring y) {
		   if(this.layoutCons !=null ) {
			   this.layoutCons.setX(x);
			   this.layoutCons.setY(y);
		   }
		   return this;
	}
	
	public BasePanel setSpringWidth(int width) {
		  return this.setSpringWidth(Spring.constant(width));
	}
	
	public BasePanel setSpringWidth(Spring width) {
		  if(this.layoutCons !=null ) {
       	      layoutCons.setWidth(width);
		  }
		  return this;
	}
	
	public BasePanel setSpringHeight(int height) {
		  return this.setSpringHeight(Spring.constant(height));
	}
	
	public BasePanel setSpringHeight(Spring height) {
		  if(this.layoutCons !=null ) {
     	      layoutCons.setWidth(height);
		  }
		  return this;
	}
	
	public BasePanel setSpringSize(int width, int height) {
		  this.setSpringWidth(width);
		  this.setSpringHeight(height);
		  return this;
	}
	
	public BasePanel setSpringSize(Spring width, Spring height) {
		  this.setSpringWidth(width);
		  this.setSpringHeight(height);
		  return this;
	}
	
	public BasePanel setSpringNSWE(Spring n, Spring s, Spring w, Spring e) {
		  if(this.layoutCons !=null ) {
			   this.layoutCons.setConstraint(SpringLayout.NORTH, n);
			   this.layoutCons.setConstraint(SpringLayout.SOUTH, s);
			   this.layoutCons.setConstraint(SpringLayout.WEST, w);
			   this.layoutCons.setConstraint(SpringLayout.EAST, e);
		  }
		 return this;
	}
	
	public BasePanel setSpringNSWE(int n, int s, int w, int e) {
		   return this.setSpringNSWE(
				   Spring.constant(n),
				   Spring.constant(s), 
				   Spring.constant(w), 
				   Spring.constant(e)
				   );
	}

}
