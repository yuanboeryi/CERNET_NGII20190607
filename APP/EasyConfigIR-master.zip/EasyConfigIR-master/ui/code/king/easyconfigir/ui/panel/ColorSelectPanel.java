package king.easyconfigir.ui.panel;

import javax.swing.*;
import java.awt.*;

public class ColorSelectPanel extends JPanel {

    private JLabel jl;
    private JPanel jp;
    private JButton jb;

    private JColorChooser jcc;
    private Color color;
    private final static int offset = -35;

    private JFrame window;

    private OnColorSelecter onColorSelecter;

    public interface OnColorSelecter {
        void onSelect(ColorSelectPanel colorSelectPanel, Color color);
    }

    public ColorSelectPanel(String text, String bustr) {
        this(text, Color.RED, bustr);
    }

    public ColorSelectPanel(String text, Color color, String bustr) {
        this(240, 30, text, 55, 113, color, bustr);
    }

    public ColorSelectPanel(int width, int height, String text, int textlen, int colen, Color color, String bustr) {
        this.setLayout(null);
        this.setSize(width, height);
        jl = new JLabel(text, JLabel.LEFT);
        jp = new JPanel();
        jb = new JButton(bustr);
        jl.setBounds(0, 0, textlen, height);
        jp.setBounds(textlen, 5, colen - 3, height - 10);
        jb.setBounds(textlen + colen, 0, width - textlen - colen, height);
        this.add(jl);
        this.add(jp);
        this.add(jb);
        jb.setFocusable(false);
        jp.setFocusable(false);

        updateColor(color);

        jb.addActionListener(e -> {
            Color tcolor = showColorChooseDialog("选择颜色", getColor());
            if (ColorSelectPanel.this.color != tcolor && tcolor!=null) {
                updateColor(tcolor);
                if (onColorSelecter != null) {
                    onColorSelecter.onSelect(ColorSelectPanel.this, tcolor);
                }
            }
        });
    }

    public void setWindow(JFrame window) {
        this.window = window;
    }

    public Color showColorChooseDialog(String title, Color initColor) {
        return JColorChooser.showDialog(window, "选择颜色", initColor);
    }

    public void setOnColorSelecter(OnColorSelecter onColorSelecter) {
        this.onColorSelecter = onColorSelecter;
    }

    private void updateColor(Color color) {
        if(color!=null){
            this.color = color;
            jp.setBackground(color);
            jp.setBorder(BorderFactory.createLineBorder(
                    new Color(
                            checkColorValue(color.getRed(), offset),
                            checkColorValue(color.getGreen(), offset),
                            checkColorValue(color.getBlue(), offset)
                    )
            ));
        }
    }

    private int checkColorValue(int a, int b) {
        int c = a + b;
        if (c < 0) {
            c = 0;
        }
        if (c > 255) {
            c = 255;
        }
        return c;
    }

    public Color getColor() {
        return this.color;
    }
}
