package king.easyconfigir.ui.panel;

import king.easyconfigir.ui.ControlWindow;

import javax.swing.*;
import java.awt.*;

public class ControlPanel extends JPanel {

	private DirectionPanel dp;
	private JButton jbd;
	private JButton jbx;

	public ControlPanel(int width,  int height) {
        this.setLayout(null);
        this.setSize(width, height);

        dp = new DirectionPanel(56);
        dp.setBounds((width - dp.getWidth()) / 2, 4, dp.getWidth(), dp.getHeight());

        int jblen = 46;

        JLabel dpt = new JLabel("[ 云 台 操 控 ]", JLabel.CENTER);
        dpt.setFont(new Font("微软雅黑", 1, 15));
        dpt.setSize(100, 30);
        int dpx = (width - dpt.getWidth()) / 2;
        int dpy = dp.getHeight() + 10;
        dpt.setBounds(dpx, dpy, dpt.getWidth(), dpt.getHeight());

        jbd = new JButton("放大");
        jbx = new JButton("缩小");
        jbd.setSize(jblen, jblen);
        jbx.setSize(jblen, jblen);
        jbd.setBounds((width - jbd.getWidth()) / 2 - 2 * jbd.getWidth(), dpy, jbd.getWidth(), jbd.getHeight());
        jbx.setBounds((width - jbx.getWidth()) / 2 + 2 * jbx.getWidth(), dpy, jbx.getWidth(), jbx.getHeight());

        this.add(jbd);
        this.add(jbx);
        this.add(dpt);

        this.add(dp);

		jbd.setFocusable(false);
		jbx.setFocusable(false);
	}

	public DirectionPanel getDirectionPanel() {
		return dp;
	}
}
