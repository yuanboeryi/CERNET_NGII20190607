package king.easyconfigir.ui.panel;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.common.manager.CommandSender;
import king.easyconfigir.tool.LogTool;

public class DirectionPanel extends JPanel implements MouseListener, KeyListener {
    private JButton up;
    private JButton down;
    private JButton left;
    private JButton right;
    private JButton stop;
    private PresetPanel presetPanel;
    private SwitchPanel switchPanel;

    public void setPresetPanel(PresetPanel pesetPanel) {
        this.presetPanel = pesetPanel;
    }

    public void setSwitchPanel(SwitchPanel switchPanel) {
        this.switchPanel = switchPanel;
    }

    private final static String TAG = "DirectionPanel";

    private boolean isKeyPressed = false;

    public DirectionPanel() {
        this(50);
    }

    public DirectionPanel(int bshap) {
        this(bshap, 6);
    }

    public DirectionPanel(int bshap, int offset) {
        int pshap = 3 * bshap + offset;
        up = new JButton("向上");
        down = new JButton("向下");
        left = new JButton("向左");
        right = new JButton("向右");
        stop = new JButton("停止");
        this.setLayout(null);
        this.setSize(pshap, pshap);
        int pb = pshap - bshap;
        int mb = pb / 2;
        up.setBounds(mb, 0, bshap, bshap);
        down.setBounds(mb, pb, bshap, bshap);
        left.setBounds(0, mb, bshap, bshap);
        right.setBounds(pb, mb, bshap, bshap);
        stop.setBounds(mb, mb, bshap, bshap);
        this.add(up);
        this.add(down);
        this.add(left);
        this.add(right);
        this.add(stop);
        up.addMouseListener(this);
        down.addMouseListener(this);
        left.addMouseListener(this);
        right.addMouseListener(this);
        stop.addMouseListener(this);

        up.setFocusable(false);
        down.setFocusable(false);
        left.setFocusable(false);
        right.setFocusable(false);
        stop.setFocusable(false);
    }

    private void actionPerformed(JButton eb) {
        if (eb == up) {
            LogTool.i(TAG, "direction: up");
            showInfoMessage("direction: up");
            ArgsPanel.send(CommandFactory.instance().commandDirectionUp());
        } else if (eb == down) {
            LogTool.i(TAG, "direction: down");
            showInfoMessage("direction: down");
            ArgsPanel.send(CommandFactory.instance().commandDirectionDown());
        } else if (eb == left) {
            LogTool.i(TAG, "direction: left");
            showInfoMessage("direction: left");
            ArgsPanel.send(CommandFactory.instance().commandDirectionLeft());
        } else if (eb == right) {
            LogTool.i(TAG, "direction: right");
            showInfoMessage("direction: right");
            ArgsPanel.send(CommandFactory.instance().commandDirectionRight());
        } else if (eb == stop) {
            LogTool.i(TAG, "direction: stop");
            showInfoMessage("direction: stop");
            ArgsPanel.send(CommandFactory.instance().commandDirectionStop());
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (CommandSender.instance().isCanSend()) {
            JButton eb = (JButton) e.getSource();
            this.actionPerformed(eb);
        } else {
            showWarnMessage("设备未连接!");
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (CommandSender.instance().isCanSend()) {
            ArgsPanel.send(CommandFactory.instance().commandDirectionStop());
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void keyTyped(KeyEvent e) {
        // TODO Auto-generated method stub
        // LogTool.i("DirectionPanel", "keyTyped code: "+ e.getKeyCode());
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (isKeyPressed) {
            //LogTool.i("DirectionPanel", "keyPressed isKeyPressed: "+isKeyPressed);
            return;
        } else {
            isKeyPressed = true;
        }
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
            case KeyEvent.VK_W:
                LogTool.i("DirectionPanel", "key UP");
                this.actionPerformed(up);
                break;
            case KeyEvent.VK_DOWN:
            case KeyEvent.VK_S:
                LogTool.i("DirectionPanel", "key DOWN");
                this.actionPerformed(down);
                break;
            case KeyEvent.VK_LEFT:
            case KeyEvent.VK_A:
                LogTool.i("DirectionPanel", "key LEFT");
                this.actionPerformed(left);
                break;
            case KeyEvent.VK_RIGHT:
            case KeyEvent.VK_D:
                LogTool.i("DirectionPanel", "key RIGHT");
                this.actionPerformed(right);
                break;
            case KeyEvent.VK_SPACE:
                LogTool.i("DirectionPanel", "key SPACE");
                this.actionPerformed(stop);
                break;
            case KeyEvent.VK_E:
                // 放大倍数
                LogTool.i("DirectionPanel", "key E");
                break;
            case KeyEvent.VK_R:
                // 缩小倍数
                LogTool.i("DirectionPanel", "key R");
                break;
            case KeyEvent.VK_DELETE:
                LogTool.i("DirectionPanel", "key DELETE");
                clearAllMessage();
                break;
            case KeyEvent.VK_C:
                LogTool.i("DirectionPanel", "key C");
                this.switchPanel.changeView();
                break;
            default:
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // LogTool.i("DirectionPanel", "keyReleased code: "+ e.getKeyCode());
        if (isKeyPressed) {
            isKeyPressed = false;
        } else {
            //LogTool.i("DirectionPanel", "keyReleased isKeyPressed: "+isKeyPressed);
            return;
        }
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
            case KeyEvent.VK_DOWN:
            case KeyEvent.VK_LEFT:
            case KeyEvent.VK_RIGHT:
            case KeyEvent.VK_SPACE:
                ArgsPanel.send(CommandFactory.instance().commandDirectionStop());
                break;
        }
    }

    public void showErrorMessage(String message) {
        presetPanel.showErrorMessage(message);
    }

    public void showWarnMessage(String message) {
        presetPanel.showWarnMessage(message);
    }

    public void showInfoMessage(String message) {
        presetPanel.showInfoMessage(message);
    }

    public void showMessage(String message) {
        presetPanel.showMessage(message);
    }

    public void clearAllMessage() {
        presetPanel.clearAllMessage();
    }
}
