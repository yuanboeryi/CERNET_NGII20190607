package king.easyconfigir.ui.panel;

import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class DoublePanel extends JPanel{
	 private PartPanel pp0;
  	 private PartPanel pp1;
  	 private JButton jb;
  	 
  	 public DoublePanel(String text0, String text1, String bustr) {
  		 this(240, 62, text0, text1, bustr);
  	 }
  	 
   	 public DoublePanel(int width, int height, String text0, String text1, String bustr) {
		  this.setLayout(null);
		  this.setSize(width, height);
		  pp0 =new PartPanel(text0);
		  pp1 =new PartPanel(text1);
		  jb = new JButton(bustr);
		  pp0.setBounds(0, 0, pp0.getWidth(), pp0.getHeight());
		  pp1.setBounds(0, pp0.getHeight()+2 , pp0.getWidth(), pp0.getHeight());
		  jb.setBounds(pp0.getWidth(), 0, width-pp0.getWidth(), height);
		  this.add(pp0);
		  this.add(pp1);
		  this.add(jb);
		  jb.setFocusable(false);
   	 }
   	 
 	public void setListener(ActionListener listener) {
	     jb.addActionListener(listener);
	}
 	
 	public Object getSource() {
		return jb;
	}
 	
 	public String getFirstValue(){
 		 return pp0.getValue();
 	}
 	
 	public String getSecondValue() {
 		return pp1.getValue();
 	}
 	
	public void setFirstValue(String value){
		 pp0.setValue(value);
	}
	
	public void setSecondValue(String value) {
		pp1.setValue(value);
	}
 	
 	
}
