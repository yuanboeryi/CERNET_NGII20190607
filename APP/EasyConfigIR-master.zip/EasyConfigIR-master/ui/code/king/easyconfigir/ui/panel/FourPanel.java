package king.easyconfigir.ui.panel;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class FourPanel extends JPanel{

	private JLabel jl;
	private List<PartPanel> pp;
	private JButton reset;
	private JButton save;
	
	public FourPanel(String text, String[]ss, String restr, String bustr) {
		    this(200,116, text, ss, restr, bustr);
	}
	
	public FourPanel(int width, int height, String text, String[]ss, String restr, String bustr) {
		   this.setLayout(null);
		   this.setSize(width, height);
	       this.setBorder(BorderFactory.createLineBorder(Color.GRAY));
		   jl=new JLabel(text, JLabel.CENTER);
		   pp=new ArrayList<>();
		   for(int i=0; i<ss.length; i++) {
			    pp.add(new PartPanel(60, 30, ss[i], 20, 5));
		   }
		   reset=new JButton(restr);
		   save=new JButton(bustr);
		   int textlen=width;
		   int texthh=20;
		   jl.setBounds((width-textlen)/2, 0, textlen, texthh);
		   this.add(jl);
		   int cc=0, dd=0;
		   for(int i=0; i<pp.size(); i++) {
			   PartPanel ite=pp.get(i);
			   if(i%2==0) {
				   ite.setBounds((width/2-ite.getWidth())/2, cc*ite.getHeight()+texthh, ite.getWidth(), ite.getHeight());
				   cc++;
			   }else {
				   ite.setBounds((width/2-ite.getWidth())/2+width/2, dd*ite.getHeight()+texthh, ite.getWidth(), ite.getHeight());
				   dd++;
			   }
			   this.add(ite);
		   }
		   int xx=(cc>dd)?cc:dd;
		   int bulen=60;
		   int buhh=30;
		   reset.setBounds((width/2-bulen)/2, xx*pp.get(0).getHeight()+texthh, bulen, buhh);
		   save.setBounds((width/2-bulen)/2+width/2, xx*pp.get(0).getHeight()+texthh, bulen, buhh);
		   this.add(reset);
		   this.add(save);
		   
		   reset.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				  for(PartPanel sp : pp) {
		 			    sp.setValue("");
		 		  }
			}});
		   reset.setFocusable(false);
		   save.setFocusable(false);
	}
	
	public void setListener(ActionListener listener) {
	     save.addActionListener(listener);
	}
	
 	public Object getSource() {
		return save;
	}
	
 	public List<String> getValue() {
 		  List<String> list = new ArrayList<>();
 		  for(PartPanel sp : pp) {
 			  list.add(sp.getValue());
 		  }
 		  return list;
 	}
}
