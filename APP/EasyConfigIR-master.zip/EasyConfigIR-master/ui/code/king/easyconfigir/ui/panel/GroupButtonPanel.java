package king.easyconfigir.ui.panel;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GroupButtonPanel extends JPanel implements ActionListener {

    private OnClickListener onClickListener;

    @Override
    public void actionPerformed(ActionEvent e) {
        if (onClickListener != null) {
            IButton ib = (IButton) e.getSource();
            onClickListener.onClick(ib.getId());
        }
    }

    public interface OnClickListener {
        void onClick(int id);
    }

    public void setOnClickListener(OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public GroupButtonPanel(String bustr[]) {
        this(210, 200, 90, 30, 3, bustr);
    }

    public GroupButtonPanel(int width, int height, int buw, int buh, int pad, String bustr[]) {
        this.setLayout(null);
        this.setSize(width, height);
        int x, y, lx, rx;
        lx = pad;
        rx = width - buw - pad;
        for (int i = 0; i < bustr.length; i++) {
            IButton jb = new IButton(i, bustr[i]);
            jb.setSize(buw, buh);
            if (((i + 1) % 2) != 0) {
                x = lx;
                y = i;
            } else {
                x = rx;
                y = i - 1;
            }
            y = (y / 2 * buh) + (y / 2 + 1) * pad;
            jb.setLocation(x, y);
            jb.setFocusable(false);
            jb.addActionListener(this);
            this.add(jb);
        }
    }

    private class IButton extends JButton {
        private int id;

        public IButton(int id, String text) {
            super(text);
            this.id = id;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }
    }
}
