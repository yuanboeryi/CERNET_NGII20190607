package king.easyconfigir.ui.panel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

import king.easyconfigir.R;

public class IntegerRangePanel extends JPanel  implements ActionListener, DocumentListener{

	private JLabel jl;
	private JTextField jtf;
	private JButton sub;
	private JButton add;
	private int value;
	private int step;
	private int max;
	private int min;
	private int limit;
	public final static int TEXT_TOP=0x0;
	public final static int TEXT_BOTTOM=0x1;
	public final static int TEXT_LEFT=0x2;
	public final static int TEXT_RIGHT=0x3;
	
	public IntegerRangePanel(String text, int min, int max) {
		   this(text, min, max, 1, 3);
	}
	
	public IntegerRangePanel(String text, int min, int max, int step, int limit){
		    this(100,66, text, min, max, step, limit, TEXT_TOP);
	}
	
	public IntegerRangePanel(int width, int height, String text, int min, int max, int step, int limit ,int directionText) {
        this.setLayout(null);
        this.setSize(width, height);
        this.setBackground(R.color.CAT_COLOR);
        //this.setBackground(Color.decode("#FF4500"));
        this.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        jl = new JLabel(text, JLabel.CENTER);
        jtf = new JTextField(3);
        sub = new JButton("-");
        add = new JButton("+");
        sub.setFont(new Font("微软雅黑", 1, 12));
        add.setFont(new Font("微软雅黑", 1, 12));
        this.min = min;
        this.max = max;
        this.step = Math.abs(step);
        value = (min + max) / 2;
        this.limit = limit;
        jtf.setDocument(new NumberLenghtLimitedDmt(this));
        jtf.setText(String.valueOf(value));
        jtf.setFont(new Font("微软雅黑", 1, 15));
        jtf.setHorizontalAlignment(JTextField.CENTER);

        int pad = 3;
        int textlen = width;
        int halfH = (int) (height * 0.6);
        int jbshap = halfH - 4 * pad;
        int jtfshap = halfH - 2 * pad;
        int texthh = height - halfH;
        int bh = (height - texthh - jbshap) / 2 + texthh;
        int fh = (height - texthh - jtfshap) / 2 + texthh;
		  switch(directionText) {
              case TEXT_BOTTOM:
                  jl.setBounds((width - textlen) / 2, fh + 2 * pad, textlen, texthh);
                  sub.setBounds(0, bh - texthh, jbshap, jbshap);
                  add.setBounds(width - jbshap, bh - texthh, jbshap, jbshap);
                  jtf.setBounds((width - jtfshap) / 2, fh - texthh, jtfshap, jtfshap);
                  break;
              case TEXT_LEFT:
                  break;
              case TEXT_RIGHT:
                  //TODO 实现水平放置标签
                  break;
              case TEXT_TOP:
              default:
                  jl.setBounds((width - textlen) / 2, 2 * pad, textlen, texthh);
                  sub.setBounds(0, bh, jbshap, jbshap);
                  add.setBounds(width - jbshap, bh, jbshap, jbshap);
                  jtf.setBounds((width - jtfshap) / 2, fh, jtfshap, jtfshap);
                  break;
          }
		  
		  this.add(jl);
		  this.add(sub);
		  this.add(add);
		  this.add(jtf);  
		  
		  sub.addActionListener(this);
		  add.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JButton jb = (JButton) e.getSource();
		if(add==jb) {
			if(value<max) {
			   value+=step;
			   jtf.setText(String.valueOf(value));
			}
		}else if(sub==jb) {
			if(value>min) {
			    value-=step;
			    jtf.setText(String.valueOf(value));
	        }
	    }
	}
	
	 public String getValue() {
		return String.valueOf(value);
	 }
	
	 class NumberLenghtLimitedDmt extends PlainDocument {

	 private static final long serialVersionUID = -7371120135793981234L;

	 public NumberLenghtLimitedDmt(IntegerRangePanel irp) {
	             super();
	             this.addDocumentListener(irp);
	 }

	 public void insertString(int offset, String str, AttributeSet attr) throws BadLocationException {
	          if (str == null) return;
	          if ((getLength() + str.length()) <= limit) {
	                char[] upper = str.toCharArray();
	                int length = 0;
	               for (int i = 0; i < upper.length; i++) {
	                      if ((upper[i] >= '0' && upper[i] <= '9') || upper[i]=='-') {
	                          upper[length++] = upper[i];
	                }
	           }
	          String ost=new String(upper, 0, length);
              super.insertString(offset, ost, attr);
	         }
	 }
}

	@Override
	public void insertUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		String ss=jtf.getText();
		if(ss!=null&&ss.trim().length()>0&&!ss.equals("-")) {
			value=Integer.valueOf(ss);
		}
	}
	@Override
	public void removeUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		String ss=jtf.getText();
		if(ss!=null&&ss.trim().length()>0&&!ss.equals("-")) {
			value=Integer.valueOf(ss);
		}
	}
	@Override
	public void changedUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		
	}
}
