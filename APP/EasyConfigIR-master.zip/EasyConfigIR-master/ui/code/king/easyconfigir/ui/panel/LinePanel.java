package king.easyconfigir.ui.panel;

import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class LinePanel extends JPanel {
    private PartPanel pp;
    private JButton jb;

    public LinePanel(String text, String bustr) {
        this(text, 55, 8, bustr);
    }

    public LinePanel(String text, int textlen, int jtflen, String bustr) {
        this(240, 30, text, textlen, jtflen, bustr);
    }

    public LinePanel(int width, int height, String text, int textlen, int jtflen, String bustr) {
        this(width, height, text, 168, textlen, jtflen, bustr);
    }

    public LinePanel(int width, int height, String text, int parlen, int textlen, int jtflen, String bustr) {

        this.setLayout(null);
        this.setSize(width, height);
        pp = new PartPanel(parlen, height, text, textlen, jtflen);
        jb = new JButton(bustr);
        pp.setBounds(0, 0, pp.getWidth(), height);
        jb.setBounds(pp.getWidth(), 0, width - pp.getWidth(), height);

        this.add(pp);
        this.add(jb);
        jb.setFocusable(false);
    }

    public void setListener(ActionListener listener) {
        jb.addActionListener(listener);
    }

    public String getValue() {
        return pp.getValue();
    }

    public void setValue(String value) {
        pp.setValue(value);
    }

    public void setButtonText(String text) {
        this.jb.setText(text);
    }

    public Object getSource() {
        return jb;
    }

    public void doClick() {
        this.jb.doClick();
    }
}
