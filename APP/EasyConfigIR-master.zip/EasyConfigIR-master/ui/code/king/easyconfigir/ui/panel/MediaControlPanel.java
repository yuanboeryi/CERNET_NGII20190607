package king.easyconfigir.ui.panel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.tool.TextTool;

public class MediaControlPanel extends JPanel implements ActionListener {

    private LinePanel mhost;
    private LinePanel mport;

    public MediaControlPanel() {
        this(280, 130);
    }

    public MediaControlPanel(int width, int height) {
        this.setLayout(null);
        this.setSize(width, height);
        initView(width, height);
    }

    private void initView(int width, int height) {
        int lpad = 4;
        int lhei = 16;
        mhost = new LinePanel(240, 30, "推流IP地址: ", 180, 80, 12, "设置");
        lpad = (width - mhost.getWidth() - 2 * lpad) / 2 + lpad;
        mhost.setLocation(lpad, lhei);
        this.add(mhost);

        mport = new LinePanel(240, 30, "推流端口号: ", 180, 80, 12, "设置");
        lhei += 2 + mhost.getHeight();
        mport.setLocation(lpad, lhei);
        this.add(mport);

        mhost.setListener(this);
        mport.setListener(this);

        updateData();
    }

    private void updateData() {
        mport.setValue(String.valueOf(CommandFactory.instance().getMediaPort()));
        mhost.setValue(String.valueOf(CommandFactory.instance().getMediaHost()));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == mport.getSource()) {
            String value = mport.getValue();
            if (TextTool.isValidPort(value)) {
                CommandFactory.instance().setMediaPort(value);
                JOptionPane.showMessageDialog(null, "设置成功! ");
            } else {
                JOptionPane.showMessageDialog(null, "参数无效! " + value);
                mport.setValue(String.valueOf(CommandFactory.instance().getMediaPort()));
            }
        } else if (e.getSource() == mhost.getSource()) {
            String value = mhost.getValue();
            if (TextTool.isValidIP(value)) {
                CommandFactory.instance().setMediaHost(value);
                JOptionPane.showMessageDialog(null, "设置成功! ");
            } else {
                JOptionPane.showMessageDialog(null, "参数无效! " + value);
                mhost.setValue(String.valueOf(CommandFactory.instance().getMediaHost()));
            }

        }
    }

}
