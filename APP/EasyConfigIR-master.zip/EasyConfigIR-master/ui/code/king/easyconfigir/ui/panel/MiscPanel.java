package king.easyconfigir.ui.panel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import king.easyconfigir.manager.RegionHelper;
import king.easyconfigir.tool.TextTool;

public class MiscPanel extends JPanel implements ActionListener {

    private LinePanel ppsc;
    private LinePanel ppss;

    public MiscPanel() {
        this(280, 130);
    }

    public MiscPanel(int width, int height) {
        this.setLayout(null);
        this.setSize(width, height);
        initView(width, height);
    }

    private void initView(int width, int height) {
        int lpad = 4;
        int lhei = 16;
        ppss = new LinePanel(240, 30, "提交区域时预设点起始值: ", 190, 150, 12, "设置");
        lpad = (width - ppss.getWidth() - 2 * lpad) / 2 + lpad;
        ppss.setLocation(lpad, lhei);
        this.add(ppss);

        ppsc = new LinePanel(240, 30, "清除区域时预设点起始值: ", 190, 150, 12, "设置");
        lhei += 2 + ppss.getHeight();
        ppsc.setLocation(lpad, lhei);
        this.add(ppsc);

        ppss.setListener(this);
        ppsc.setListener(this);

        updateData();
    }

    private void updateData() {
        ppsc.setValue(String.valueOf(RegionHelper.instance().getCleanPresetPointStartOffset()));
        ppss.setValue(String.valueOf(RegionHelper.instance().getSubmitPresetPointStartOffset()));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == ppsc.getSource()) {
            String value = ppsc.getValue();
            if (TextTool.isValidIntegerRange(value, 0, 128, TextTool.ALL_CLOSE)) {
                RegionHelper.instance().setCleanPresetPointStartOffset(Integer.parseInt(value));
                JOptionPane.showMessageDialog(null, "设置成功! ");
            } else {
                JOptionPane.showMessageDialog(null, "参数无效! " + value);
                ppsc.setValue(String.valueOf(RegionHelper.instance().getCleanPresetPointStartOffset()));
            }
        } else if (e.getSource() == ppss.getSource()) {
            String value = ppss.getValue();
            if (TextTool.isValidIntegerRange(value, 0, 128, TextTool.ALL_CLOSE)) {
                RegionHelper.instance().setSubmitPresetPointStartOffset(Integer.parseInt(value));
                JOptionPane.showMessageDialog(null, "设置成功! ");
            } else {
                JOptionPane.showMessageDialog(null, "参数无效! " + value);
                ppss.setValue(String.valueOf(RegionHelper.instance().getSubmitPresetPointStartOffset()));
            }

        }
    }

}
