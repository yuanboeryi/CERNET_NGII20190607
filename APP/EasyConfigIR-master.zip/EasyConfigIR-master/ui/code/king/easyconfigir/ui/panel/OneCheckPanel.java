package king.easyconfigir.ui.panel;

import java.awt.Color;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class OneCheckPanel extends JPanel{
	private JLabel jl;
	private JCheckBox jcb;
	
	public OneCheckPanel(String text) {
		this(120, 30, text);
	}
			
	public OneCheckPanel(int width, int height, String text) {
		   this.setSize(width, height);
	       this.setLayout(null);
	       
	       jl=new JLabel(text, JLabel.CENTER);
	       jcb = new JCheckBox();
	       int textlen=(int) (width*0.7);
	       int texthh=30;
	       int hh = (height-texthh)/2;
	       jl.setBounds(0, hh, textlen, texthh);
	       jcb.setBounds(textlen+3, hh, texthh, texthh);
	       
	       this.add(jl);
	       this.add(jcb);
	       jcb.setSelected(false);
	}
	
	public void setSelected(boolean isSelected) {
		jcb.setSelected(isSelected);
	}
	
	public boolean isSelected() {
		return jcb.isSelected();
	}
	
	public void setEnabled(boolean isEnabled) {
		jcb.setEnabled(isEnabled);
	}
	
	public void setListener(ActionListener listener) {
	     jcb.addActionListener(listener);
	}
	
	public Object getSource() {
		return jcb;
	}
}
