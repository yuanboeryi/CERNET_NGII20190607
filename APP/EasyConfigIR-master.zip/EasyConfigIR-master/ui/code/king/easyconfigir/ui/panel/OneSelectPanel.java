package king.easyconfigir.ui.panel;

import java.awt.Color;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class OneSelectPanel extends JPanel{

	private JLabel jl;
	private JRadioButton jrb0;
	private JRadioButton jrb1;
	private JButton jb;
	private ButtonGroup group;
	
	public OneSelectPanel(String text) {
        this(text, "打开", "关闭");
    }
	
	public OneSelectPanel(String text, String mb0, String mb1) {
        this(text, mb0, mb1, "确认");
    }
	
	public OneSelectPanel(String text, String mb0, String mb1, String bustr) {
	            this(160,50, text, mb0, mb1, bustr);
	}
	
	public OneSelectPanel(int width, int height, String text, String mb0, String mb1, String bustr) {
		       this.setSize(width, height);
		       this.setLayout(null);
		       this.setBorder(BorderFactory.createLineBorder(Color.GRAY));
		       
		       jl=new JLabel(text, JLabel.CENTER);
		       jrb0=new JRadioButton(mb0);
		       jrb1=new JRadioButton(mb1);
		       jb=new JButton(bustr);
		       group=new ButtonGroup();
		       group.add(jrb0);
		       group.add(jrb1);
		       int textlen=(int) (width*0.7);
		       int texthh=30;
		       jl.setBounds(0, 0, textlen,texthh);
		       jrb0.setBounds(0, height/2, textlen/2, height/2);
		       jrb1.setBounds(textlen/2, height/2, textlen/2, height/2);
		       jb.setBounds(textlen-2, 2, width-textlen, height-4);
		       this.add(jl);
		       this.add(jrb0);
		       this.add(jrb1);
		       this.add(jb);
		       
		       jrb0.setSelected(true);
		       
		       jb.setFocusable(false);
		       
		       jrb0.setFocusable(false);
		       jrb1.setFocusable(false);
	}
	
	public String getValue() {
		   return (jrb0.isSelected()&&!jrb1.isSelected()) ? "1":"0"; 
	}
	
	public void setListener(ActionListener listener) {
	     jb.addActionListener(listener);
	}
	
	public Object getSource() {
		return jb;
	}
}
