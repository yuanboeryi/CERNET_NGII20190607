package king.easyconfigir.ui.panel;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.*;

public class PartPanel extends JPanel{
	    private JLabel jl;
	    private JTextField jtf;
	    
	    public PartPanel(String text) {
	    	  this(text,55, 8);
	    }
	    
	    public PartPanel(String text, int textlen, int jtflen) {
	    	this(168,30,text,textlen, jtflen);
	    }
	    
	    public PartPanel(int width, int height, String text,  int textlen, int jtflen) {
	    	  this.setLayout(null);
			  this.setSize(width, height);
			  jl = new JLabel(text, JLabel.LEFT);
			  jtf = new JTextField(jtflen);
			  
			  jl.setBounds(0, 0, textlen,height);
			  jtf.setBounds(textlen, 0, width-textlen, height);

			  this.add(jl);
			  this.add(jtf);
	    }
	    
		public String getValue() {
			 return jtf.getText();
		}
		
		public void setValue(String value) {
			jtf.setText(value);
		}
}
