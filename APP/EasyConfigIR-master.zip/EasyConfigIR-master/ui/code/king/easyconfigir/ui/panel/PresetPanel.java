package king.easyconfigir.ui.panel;

import king.easyconfigir.R;
import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.tool.TextTool;
import king.easyconfigir.tool.ToastTool;
import king.easyconfigir.ui.ControlWindow;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class PresetPanel extends BasePanel implements ActionListener {

    public StatusShowPanel sspx;

    private OneSelectPanel osp;
    private OneSelectPanel ssp;
    private OneSelectPanel jdq;
    private OneSelectPanel zhq;
    private LinePanel gj;
    private DoublePanel ppt;
    private FourPanel fp;

    private ControlWindow window;

    public void setWindow(ControlWindow window) {
        this.window = window;
    }

    public ControlWindow getWindow() {
        return this.window;
    }

    public PresetPanel() {
        this(null);
    }

    public PresetPanel(SpringLayout layout) {
        this(R.size.CONTROL_PRESET_WIDTH,
                R.size.CONTROL_PRESET_HEIGHT,
                layout
        );
    }

    public PresetPanel(int width, int height, SpringLayout layout) {
        this(R.title.PRESET_PANEL, width, height, layout);
    }

    public PresetPanel(String title, int width, int height, SpringLayout layout) {
        super(title, width, height, layout);
        this.setLayout(null);
        this.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        int hd = 4;
        osp = new OneSelectPanel("测温区域边界呈现");
        osp.setLocation(4, hd);
        this.add(osp);

        ssp = new OneSelectPanel("视频推流");
        hd += osp.getHeight() + 4;
        ssp.setLocation(4, hd);
        this.add(ssp);

        jdq = new OneSelectPanel("继电器开关控制");
        hd += ssp.getHeight() + 4;
        jdq.setLocation(4, hd);
        this.add(jdq);

        zhq = new OneSelectPanel("周期预设点扫描", "启用", "禁用");
        hd += jdq.getHeight() + 4;
        zhq.setLocation(4, hd);
        this.add(zhq);


        hd = 4;
        gj = new LinePanel("告警温度:", "设置");
        gj.setLocation(width - gj.getWidth() - 2, hd);
        this.add(gj);

        ppt = new DoublePanel("拍图周期:", "巡检周期:", "设置");
        hd += gj.getHeight() + 2;
        ppt.setLocation(width - ppt.getWidth() - 2, hd);
        this.add(ppt);

        fp = new FourPanel("融合参数", new String[]{"S:", "R:", "L:", "T:"}, "重置", "保存");
        hd += ppt.getHeight() + 2;
        fp.setLocation(width - fp.getWidth() - 20, hd);
        this.add(fp);

        hd += fp.getHeight() + 4;
        sspx = new StatusShowPanel(width - 12, height - hd - 36);
        sspx.setLocation((width - sspx.getWidth()) / 2, hd);
        this.add(sspx);

        osp.setListener(this);
        ssp.setListener(this);
        jdq.setListener(this);
        zhq.setListener(this);
        gj.setListener(this);
        ppt.setListener(this);
        fp.setListener(this);
    }

    public void showSuccessToast(String message) {
        ToastTool.makeText(ControlWindow.instance(), message, ToastTool.Style.SUCCESS).display();
    }

    public void showNormalToast(String message) {
        ToastTool.makeText(ControlWindow.instance(), message, ToastTool.Style.NORMAL).display();
    }

    public void showErrorToast(String message) {
        ToastTool.makeText(ControlWindow.instance(), message, ToastTool.Style.ERROR).display();
    }

    public void showErrorMessage(String message) {
        sspx.updateStatus(makeInfo(message, Color.RED));
    }

    public void showWarnMessage(String message) {
        sspx.updateStatus(makeInfo(message, Color.YELLOW));
    }

    public void showInfoMessage(String message) {
        sspx.updateStatus(makeInfo(message, Color.GREEN));
    }

    public void showMessage(String message) {
        sspx.updateStatus(makeInfo(message, null));
    }

    private StatusShowPanel.Info makeInfo(String message, Color color) {
        StatusShowPanel.Info info = sspx.obtainInfo();
        info.setText(message);
        if (color != null) {
            info.setTextColor(color);
        }
        // LogTool.i("sspx", "makeInfo message: " + message);
        return info;
    }

    public void clearAllMessage() {
        sspx.doClear();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == osp.getSource()) {
            String value = osp.getValue();
            showInfoMessage("input region outlook: " + value);
            ArgsPanel.send(CommandFactory.instance().commandRegionOutlook(value));
        } else if (e.getSource() == ssp.getSource()) {
            String value = ssp.getValue();
            showInfoMessage("input rtsp switcher: " + value);
            ArgsPanel.send(CommandFactory.instance().commandRtspSwitcher(value));
        } else if (e.getSource() == jdq.getSource()) {
            String value = jdq.getValue();
            showInfoMessage("input relay switcher: " + value);
            ArgsPanel.send(CommandFactory.instance().commandRelaySwitcher(value));
        } else if (e.getSource() == zhq.getSource()) {
            String value = zhq.getValue();
            showInfoMessage("input preset point scan switcher: " + value);
            ArgsPanel.send(CommandFactory.instance().commandPresetPointScanSwitcher(value));
        } else if (e.getSource() == gj.getSource()) {
            String value = gj.getValue();
            if (TextTool.isValidIntegerRange(value, 0, 65536, TextTool.ALL_CLOSE)) {
                showInfoMessage("input LookupPointWarnTemperature: " + value);
                ArgsPanel.send(CommandFactory.instance().commandLookupPointWarnTemperature(value));
            } else {
                showInfoMessage("input LookupPointWarnTemperature invalid. integer range: [ 0, 65536 ]");
            }
        } else if (e.getSource() == ppt.getSource()) {
            String value0 = ppt.getFirstValue();
            String value1 = ppt.getSecondValue();
            if (TextTool.isValidIntegerRange(value0, 1, 100, TextTool.ALL_CLOSE)) {
                if (TextTool.isValidIntegerRange(value1, 1, 100, TextTool.ALL_CLOSE)) {
                    showInfoMessage("input Inspection: " + value0);
                    showInfoMessage("input ShootingCycle: " + value1);
                    ArgsPanel.send(CommandFactory.instance().commandInspectionAndShootingCycle(value0, value1));
                } else {
                    showInfoMessage("input ShootingCycle invalid. " + value1);
                }
            } else {
                showInfoMessage("input Inspection invalid. " + value0);
            }
        } else if (e.getSource() == fp.getSource()) {
            List<String> ss = fp.getValue();
            String S = ss.get(0);
            String R = ss.get(1);
            String L = ss.get(2);
            String T = ss.get(3);
            if (TextTool.isValidIntegerRange(S, -320, 320, TextTool.ALL_CLOSE)) {
                if (TextTool.isValidIntegerRange(R, -240, 240, TextTool.ALL_CLOSE)) {
                    if (TextTool.isValidIntegerRange(L, -180, 180, TextTool.ALL_CLOSE)) {
                        if (TextTool.isValidIntegerRange(T, 0, 10, TextTool.ALL_CLOSE)) {
                            ArgsPanel.send(CommandFactory.instance().commandIROffset(S, R));
                            ArgsPanel.send(CommandFactory.instance().commandIRRotationAndEnlarge(L, T));
                        } else {
                            showInfoMessage("input T invalid. integer range: [ 0, 10 ]");
                        }
                    } else {
                        showInfoMessage("input L invalid. integer range: [ -180, 180 ]");
                    }
                } else {
                    showInfoMessage("input R invalid. integer range: [ -240, 240 ]");
                }
            } else {
                showInfoMessage("input S invalid. integer range: [ -320, 320 ]");
            }
        }
    }

}
