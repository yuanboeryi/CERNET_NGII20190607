package king.easyconfigir.ui.panel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import king.easyconfigir.R;
import king.easyconfigir.button.PresetButton;
import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.common.manager.CommandSender;
import king.easyconfigir.manager.RegionHelper;
import king.easyconfigir.model.PresetPoint;
import king.easyconfigir.tool.LogTool;
import king.easyconfigir.tool.TextTool;

public class PresetPointControlListPanel extends JPanel implements ActionListener {

    private List<PresetButton> list;

    private PresetButton pb;

    private final static int ROWS = 4;
    private final static int COLS = 4;

    public PresetPointControlListPanel() {
        this(612, 400);
    }

    public PresetPointControlListPanel(int width, int height) {
        this.setLayout(null);
        this.setSize(width, height);
        this.setBackground(R.color.CAT_COLOR);
        list = new ArrayList<>();
        int x, y, pbw = 0, pbh = 0;
        y = 20;
        int pad = 2;
        for (int i = 0; i < ROWS; i++) {
            x = 0;
            for (int j = 0; j < COLS; j++) {
                int id = 4 * i + j + 1;
                pb = new PresetButton(id, "预设点" + id, list);
                pbw = pb.getWidth();
                pbh = pb.getHeight();
                pb.setBounds(x, y, pbw, pbh);
                x = pbw + pad + x;
                this.add(pb);
                list.add(pb);
                if (id > 1) {
                    pb.setEnabled(false);
                    pb.setForeground(Color.BLACK);
                } else {
                    pb.setForeground(Color.GREEN);
                }
                pb.addActionListener(new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        handlePresetButton(((PresetButton) e.getSource()));
                    }
                });
            }
            y = pbh + 2 + y;
        }

        JButton empty = new JButton("清空全部预设点");
        empty.setFont(new Font("微软雅黑", 1, 15));
        empty.setBounds((2 * pbw - 150 / 2) + 2 * pad, y + 10, 150, 60);
        this.add(empty);

        empty.addActionListener(this);
    }

    public void handlePresetButton(PresetButton pb) {
        if (pb.getDistance() < 0) {
            String value = JOptionPane.showInputDialog(null, "请输入预设点距离（米）：", 4);
            //PresetPanel.showWarnMessage("value: "+value);
            if (!TextTool.checkNull(value)) {
                if (TextTool.isValidIntegerRange(value, 4, 20, TextTool.ALL_CLOSE)) {
                    if (CommandSender.instance().isCanSend()) {
                        int id = pb.getId();
                        int next = id;
                        if (next > 0 && next < list.size()) {
                            list.get(next).setEnabled(true);
                            list.get(next).setForeground(Color.GREEN);
                        }

                        LogTool.i("PresetPointControlListPanel", "PresetButton -> id: " + id + " distance: " + value);

                        pb.setForeground(R.color.CATHELLO_COLOR);
                        pb.setText(pb.getText() + "（" + value + "米）");
                        pb.setDistance(Integer.parseInt(value));
                        ArgsPanel.send(CommandFactory.instance().commandPresetPointSet(
                                String.valueOf(id),
                                String.valueOf(pb.getDistance())
                        ));
                        RegionHelper.instance().addPresetPoint(pb.getPresetPoint());
                    } else {
                        JOptionPane.showMessageDialog(null, "设备未连接!");
                    }
                }
            }
        } else {
            ArgsPanel.send(CommandFactory.instance().commandPresetPointCall(String.valueOf(pb.getId())));
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        for (int i = 0; i < list.size(); i++) {
            PresetButton pb = list.get(i);
            if (i > 0) {
                pb.setEnabled(false);
                pb.setForeground(Color.BLACK);
            } else {
                pb.setForeground(Color.GREEN);
            }
            pb.setText("预设点" + (i + 1));
            pb.setDistance(-1);
            pb.setId(i + 1);
        }
        ArgsPanel.send(CommandFactory.instance().commandAllPresetPointClear());
        RegionHelper.instance().cleanPresetPoint();
    }

}
