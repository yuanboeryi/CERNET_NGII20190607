package king.easyconfigir.ui.panel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import king.easyconfigir.R;
import king.easyconfigir.common.manager.CommandFactory;
import king.easyconfigir.common.manager.CommandSender;

public class PresetPointControlPanel extends JPanel implements ActionListener {

    private JButton add;
    private JButton delete;
    private JButton call;
    private JButton modify;
    private IntegerRangePanel bhh;
    private IntegerRangePanel irp;

    public PresetPointControlPanel() {
        this(230, 150);
    }

    public PresetPointControlPanel(int width, int height) {
        this.setLayout(null);
        this.setSize(width, height);
        //this.setBackground(R.color.CAT_COLOR);
        this.setBackground(R.color.CATHELLO_COLOR);
        bhh = new IntegerRangePanel("预设点编号", 1, 128);
        irp = new IntegerRangePanel("距离/米", 4, 20);
        int sh = (height / 2 - bhh.getHeight()) / 2;
        bhh.setBounds(4, sh + 2, bhh.getWidth(), bhh.getHeight());
        sh = (height / 2 - irp.getHeight()) / 2;
        irp.setBounds(4, sh + height / 2 - 2, irp.getWidth(), irp.getHeight());
        add = new JButton("添加");
        delete = new JButton("删除");
        call = new JButton("调用");
        modify = new JButton("修改");
        int jbw = width / 4;
        int jbh = jbw / 2;
        int pad = 3;
        int ah = (height / 2 - jbh) / 2;
        add.setBounds(bhh.getWidth() + 3 * pad, ah, jbw, jbh);
        delete.setBounds(bhh.getWidth() + 3 * pad, ah + height / 2, jbw, jbh);
        call.setBounds(width - (jbw + 3 * pad), ah, jbw, jbh);
        modify.setBounds(width - (jbw + 3 * pad), ah + height / 2, jbw, jbh);
        this.add(bhh);
        this.add(irp);
        this.add(add);
        this.add(delete);
        this.add(call);
        this.add(modify);

        add.addActionListener(this);
        delete.addActionListener(this);
        call.addActionListener(this);
        modify.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (CommandSender.instance().isCanSend()) {
            String value0 = bhh.getValue();
            String value1 = irp.getValue();
            //PresetPanel.showInfoMessage("input : preset point number: "+value0);
            //PresetPanel.showInfoMessage("input : preset point distance: "+value1);
            if (e.getSource() == add) {
                ArgsPanel.send(CommandFactory.instance().commandPresetPointSet(value0, value1));
            } else if (e.getSource() == delete) {
                ArgsPanel.send(CommandFactory.instance().commandPresetPointClear(value0));
            } else if (e.getSource() == call) {
                ArgsPanel.send(CommandFactory.instance().commandPresetPointCall(value0));
            } else if (e.getSource() == modify) {
                ArgsPanel.send(CommandFactory.instance().commandPresetPointDistanceModify(value0, value1));
            }
        } else {
            JOptionPane.showMessageDialog(null, "设备未连接!");
        }

    }
}
