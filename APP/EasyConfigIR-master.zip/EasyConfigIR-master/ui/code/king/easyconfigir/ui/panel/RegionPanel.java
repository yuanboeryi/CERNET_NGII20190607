package king.easyconfigir.ui.panel;

import king.easyconfigir.R;
import king.easyconfigir.manager.RegionHelper;
import king.easyconfigir.model.CheckMessage;
import king.easyconfigir.model.PresetPoint;
import king.easyconfigir.model.Shape;
import king.easyconfigir.tool.LogTool;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ItemEvent;
import java.util.ArrayList;

public class RegionPanel extends JPanel implements ColorSelectPanel.OnColorSelecter, RegionHelper.PresetPointEvent {

    private String stype[] = {
            "点", "线", "面"
    };

    private SelectPanel sp;
    private SelectPanel psd;
    private ColorSelectPanel csd;
    private ColorSelectPanel csx;
    private GroupButtonPanel gbp;

    private final static String bustr[] = {"撤销", "重做", "删除形状", "恢复形状", "清空区域", "提交区域"};
    private PresetPanel presetPanel;

    public void setPresetPanel(PresetPanel pesetPanel) {
        this.presetPanel = pesetPanel;
        csd.setWindow(presetPanel.getWindow());
        csx.setWindow(presetPanel.getWindow());
    }

    public RegionPanel(int width, int height) {
        this.setLayout(null);
        this.setSize(width, height);

        sp = new SelectPanel("绘图类型:", stype, "完成");
        int lpad = (width - sp.getWidth()) / 2;
        int lhei = 0;
        sp.setLocation(lpad, lhei);
        this.add(sp);

        psd = new SelectPanel("预设点:", genPsdData(), "调用");
        lhei += 2 + sp.getHeight();
        psd.setLocation(lpad, lhei);
        this.add(psd);

        csd = new ColorSelectPanel("点颜色: ", R.color.CATHELLO_COLOR, "更改");
        lhei += 2 + psd.getHeight();
        csd.setLocation(lpad, lhei);
        this.add(csd);

        csx = new ColorSelectPanel("线颜色: ", R.color.CAT_COLOR, "更改");
        lhei += 2 + csd.getHeight();
        csx.setLocation(lpad, lhei);
        this.add(csx);

        gbp = new GroupButtonPanel(bustr);
        lpad = (width - gbp.getWidth()) / 2;
        lhei += 2 + csx.getHeight();
        gbp.setLocation(lpad, lhei);
        this.add(gbp);

        gbp.setOnClickListener(id -> {
//            ArgsPanel.showNormalToast(bustr[id]);
            // showErrorMessage(bustr[id]);
            switch (id) {
                case 0:
                    if (!RegionHelper.instance().cancelPoint()) {
                        showErrorToast("无法撤销！");
                    }
                    ;
                    break;
                case 1:
                    if (!RegionHelper.instance().redoPoint()) {
                        showErrorToast("无法重做！");
                    }
                    break;
                case 2:
                    if (!RegionHelper.instance().deleteShape()) {
                        showErrorToast("没有可删除的形状！");
                    }
                    break;
                case 3:
                    if (!RegionHelper.instance().recoverShape()) {
                        showErrorToast("没有可恢复的形状！");
                    }
                    break;
                case 4:
                    if (RegionHelper.instance().checkPresetPointsNotEmpty()) {
                        int clearPresetId = RegionHelper.instance().getPresetPoints().get(psd.getIntValue()).getId();
                        RegionHelper.instance().cleanRegion(clearPresetId);
                    } else {
                        JOptionPane.showMessageDialog(null, "没有可用预设点！");
                    }
                    break;
                case 5:
                    if (RegionHelper.instance().checkRegionSize()) {
                        if (RegionHelper.instance().checkRegionFinished()) {
                            if (RegionHelper.instance().checkPresetPointsNotEmpty()) {
                                int presetId = RegionHelper.instance().getPresetPoints().get(psd.getIntValue()).getId();
                                RegionHelper.instance().submitRegion(presetId);
                                showSuccessToast("提交成功!");
                            } else {
//                                showErrorMessage("没有可用预设点！");
                                JOptionPane.showMessageDialog(null, "没有可用预设点！");
                            }
                        } else {
                            showErrorToast("无法提交，你有未完成的图形！");
                        }
                    } else {
                        showErrorMessage("无法提交，每个预设点最多支持" + RegionHelper.MAX_REGION_SIZE + "个图形!");
                    }
                    break;
                default:
                    break;
            }
        });

        sp.setListener(e -> {
            if (RegionHelper.instance().getCurrentShape() != null) {
                if (changeType(RegionHelper.instance().getCurrentType())) {
                    showSuccessToast("已确认完成绘制，你现在可以进行新的绘制！");
                }
            } else {
                showErrorToast("无法完成，你当前还没有绘制任何图形！");
            }
        });

        sp.setItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                int type = convertToType(sp.getIntValue());
                if (type != RegionHelper.instance().getCurrentType()) {
                    changeType(type);
                }
            }
        });

        psd.setListener(e -> {
            int size = RegionHelper.instance().getPresetPoints().size();
            if (size <= 0) {
                JOptionPane.showMessageDialog(null, "没有可调用的预设点!");
            } else {
                RegionHelper.instance().getPresetPoints().get(psd.getIntValue()).callSelf();
            }
            LogTool.i("RegionPanel", "PresetPoints size: " + size + " value: " + psd.getIntValue());
        });

        csd.setOnColorSelecter(this);
        csx.setOnColorSelecter(this);

        RegionHelper.instance().setCurrentType(convertToType(sp.getIntValue()));
        RegionHelper.instance().setCurrentPointColor(csd.getColor());
        RegionHelper.instance().setCurrentShapeColor(csx.getColor());

        RegionHelper.instance().setPresetPointEvent(this);

        // select last index
        sp.setIntValue(stype.length-1);
    }

    private String[] genPsdData() {
        ArrayList<PresetPoint> list = RegionHelper.instance().getPresetPoints();
        int size = list.size();
        if (size <= 0) {
            return new String[]{"无"};
        } else {
            ArrayList<String> items = new ArrayList<>();
            for (PresetPoint presetPoint : list) {
                items.add(presetPoint.getName());
            }
            return (String[]) items.toArray();
        }
    }

    @Override
    public void onSelect(ColorSelectPanel colorSelectPanel, Color color) {
        if (colorSelectPanel == csd) {
            RegionHelper.instance().setCurrentPointColor(color);
        } else if (colorSelectPanel == csx) {
            RegionHelper.instance().setCurrentShapeColor(color);
        }
    }

    private boolean changeType(int type) {
        boolean is = true;
        Shape sh = RegionHelper.instance().getCurrentShape();
        if (sh == null) {
            RegionHelper.instance().setCurrentType(type);
        } else {
            CheckMessage cm = sh.checkSelf();
            if (cm.isStatus()) {
                RegionHelper.instance().setCurrentType(type);
                RegionHelper.instance().freshOverlay();
            } else {
                is = false;
                sp.setIntValue(converToIndex(sh.getType()));
                showErrorToast(cm.getValue());
                LogTool.i("RegionPanel", "shape illegal! " + cm.getValue());
            }
        }
        return is;
    }

    private int converToIndex(int value) {
        int index = 0;
        switch (value) {
            case Shape.TYPE_POINT:
                index = 0;
                break;
            case Shape.TYPE_LINE:
                index = 1;
                break;
            case Shape.TYPE_PLANE:
                index = 2;
                break;
            default:
                break;
        }
        return index;
    }

    private int convertToType(int value) {
        int type = Shape.TYPE_POINT;
        switch (value) {
            case 0:
                type = Shape.TYPE_POINT;
                break;
            case 1:
                type = Shape.TYPE_LINE;
                break;
            case 2:
                type = Shape.TYPE_PLANE;
                break;
            default:
                break;
        }
        return type;
    }

    public void showErrorMessage(String message) {
        presetPanel.showErrorMessage(message);
    }

    public void showWarnMessage(String message) {
        presetPanel.showWarnMessage(message);
    }

    public void showInfoMessage(String message) {
        presetPanel.showInfoMessage(message);
    }

    public void showMessage(String message) {
        presetPanel.showMessage(message);
    }

    public void showSuccessToast(String message) {
        presetPanel.showSuccessToast(message);
    }

    public void showNormalToast(String message) {
        presetPanel.showNormalToast(message);
    }

    public void showErrorToast(String message) {
        presetPanel.showErrorToast(message);
    }

    @Override
    public void onChangedPresetPoints(ArrayList<PresetPoint> presetPoints) {
        psd.removeAllitems();
        if (presetPoints.size() <= 0) {
            psd.addItem("无");
        } else {
            for (PresetPoint presetPoint : presetPoints) {
                psd.addItem(presetPoint.getName());
            }
        }
    }
}
