package king.easyconfigir.ui.panel;

import javax.swing.*;

import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.util.List;

public class SelectPanel extends JPanel {
    private JLabel jl;
    private JComboBox jcb;
    private JButton jb;

    public SelectPanel(String text, String str[], String bustr) {
        this(240, 30, text, 55, 113, str, bustr);
    }

    public SelectPanel(int width, int height, String text, int textlen, int jcblen, String str[], String bustr) {
        this.setLayout(null);
        this.setSize(width, height);
        jl = new JLabel(text, JLabel.LEFT);
        jcb = new JComboBox(str);
        jb = new JButton(bustr);
        jl.setBounds(0, 0, textlen, height);
        jcb.setBounds(textlen, 0, jcblen, height);
        jb.setBounds(textlen + jcblen, 0, width - textlen - jcblen, height);
        this.add(jl);
        this.add(jcb);
        this.add(jb);
        jb.setFocusable(false);
        jcb.setFocusable(false);
    }

    public void setButtonVisible(boolean isVisible) {
        jb.setVisible(isVisible);
    }

    public String getValue() {
        return String.valueOf(getIntValue());
    }

    public int getIntValue() {
        return jcb.getSelectedIndex();
    }

    public void setIntValue(int index) {
        jcb.setSelectedIndex(index);
    }

    public void setListener(ActionListener listener) {
        jb.addActionListener(listener);
    }

    public Object getSource() {
        return jb;
    }

    public void setItemListener(ItemListener itemListener) {
        jcb.addItemListener(itemListener);
    }

    public JComboBox getJComboBox() {
        return jcb;
    }

    public void removeAllitems() {
        this.jcb.removeAllItems();
    }

    public void addItem(String value) {
        this.jcb.addItem(value);
    }
}
