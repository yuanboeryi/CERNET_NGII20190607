package king.easyconfigir.ui.panel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListModel;

public class StatusShowPanel extends JPanel implements ActionListener{

	private JScrollPane jsp;
	private JList jl;
	private JLabel totalInfo;
	private JButton clear;
	private int count;
	private int maxSize=50;
	private String other[]= {"运行状态","无消息","清空"};
	
	public StatusShowPanel() {
		// TODO Auto-generated constructor stub
    	this(400,505);
	}
	
	public StatusShowPanel(int width, int height) {
		this.setLayout(null);
		this.setSize(width, height);
		this.setBorder(BorderFactory.createLineBorder(Color.GRAY));
//		this.setBackground(Color.gray);
	    jsp=new JScrollPane();
	    jl=new JList();
	    jl.setSelectionBackground(Color.GREEN);
	    jsp.setViewportView(jl);
	    jsp.setHorizontalScrollBarPolicy(
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				jsp.setVerticalScrollBarPolicy(
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		JPanel jp=new JPanel();
		totalInfo=new JLabel(other[1]);
		clear=new JButton(other[2]);
		clear.addActionListener(this);
		clear.setBackground(Color.LIGHT_GRAY);
		clear.setVisible(false);
		//jp.setBackground(Color.GRAY);
		jp.setLayout(new FlowLayout(FlowLayout.CENTER));
		jp.add(totalInfo);
		jp.add(clear);
		JLabel ht=new JLabel(other[0], JLabel.CENTER);
	
		ht.setBounds(0, 0, width, 30);
		jp.setBounds(0,height-32 , width,  32);
		jsp.setBounds(0, 30, width, height-30-32);

		this.add(ht);
		this.add(jsp);
		this.add(jp);
		
		//jl.setCellRenderer(new LineRender());
		clear.setFocusable(false);
	}
	
	class LineRender extends DefaultListCellRenderer {
		@Override
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
				boolean cellHasFocus) {
			// TODO Auto-generated method stub
		    super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
			Info info=(Info) value;
			this.setText(info.getText());
//			this.setFont(info.getFont());
//			this.setForeground(info.getTextColor());
//		//	this.setBackground(info.getBgColor());
			return this;
		}
	
	}
	
	class Line extends JPanel {
		private JLabel jl;
		public Line(int width, int height) {
			this.setLayout(null);
			this.setPreferredSize(new Dimension(width, height));
			jl = new JLabel("fsfds");
			int pad=3;
			jl.setBounds(pad, pad, width-pad, height-pad);
			this.add(jl);
		}
		
		public void setText(String text) {
			jl.setText(text);
		}
		
		public void setBgColor(Color color) {
		     this.setBackground(color);	
		}
		
		public void setTextColor(Color color) {
			jl.setForeground(color);
		}
		
		public void setTextFont(Font font) {
			jl.setFont(font);
		}
		
	}
	
   public class Info {
	    private String text;
		private Font font;
		private Color textColor;
		private Color bgColor;
		
		
		public Info() {
			this("");
		}
		
		public Info(String text) {
			 this(text, null);
		}
		
		public Info(String text, Color textColor) {
			this(text, textColor, Color.WHITE);
		}
		
		public Info(String text, Color textColor, Color bgColor) {
		    this(text, textColor, bgColor, new Font("Times New Roman", Font.PLAIN, 12));
		}
		
		public Info(String text, Color textColor, Color bgColor, Font font) {
			this.text=text;
			this.textColor=textColor;
			this.bgColor=bgColor;
			this.font=font;
		}

		public Color getTextColor() {
			return textColor;
		}

		public void setTextColor(Color textColor) {
			this.textColor = textColor;
		}

		public Color getBgColor() {
			return bgColor;
		}

		public void setBgColor(Color bgColor) {
			this.bgColor = bgColor;
		}

		public String getText() {
			return text;
		}

		public void setText(String text) {
			this.text = text;
		}

		public Font getFont() {
			return font;
		}

		public void setFont(Font font) {
			this.font = font;
		}

	}
    
   
   public Info obtainInfo() {
	   return new Info();
   }
    
	public void updateStatus(String info) {
		updateStatus(new Info(info));
	}
	
	public void doClear() {
		if(clear!=null) {
			clear.doClick();
		}
	}
	
	public void updateStatus(Info message) {
		int size=jl.getModel().getSize();
		String info=message.getText();
		DefaultListModel listModel=null;
		if(size==0) {
			listModel=new DefaultListModel();
			listModel.addElement(info);
		}else if(size<maxSize) {
			listModel=(DefaultListModel) jl.getModel();
			listModel.addElement(info);
		}else {
			listModel=(DefaultListModel) jl.getModel();
			listModel.removeRange(0, maxSize/2);
			listModel.addElement(info);
		}
		count++;
		jl.setModel(listModel);
		size=jl.getModel().getSize();
		jl.setSelectedIndex(size-1);
		
		jsp.getVerticalScrollBar().setValue(jsp.getVerticalScrollBar().getMaximum());
		
		totalInfo.setText("总接收:"+count+"条,可显示:"+size+"条");
		
		if(!clear.isVisible())
		{clear.setVisible(true);}
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(clear==arg0.getSource()) {
			ListModel listModel=jl.getModel();
			if(listModel.getSize()>0) {
				((DefaultListModel)listModel).removeAllElements();
				totalInfo.setText(other[1]);
				totalInfo.setText("总接收:"+count+"条,可显示:0条");
				if(clear.isVisible())
				{clear.setVisible(false);}
			}
		}
	}
}
