package king.easyconfigir.ui.panel;

import javax.swing.JLayeredPane;

import king.easyconfigir.R;
import king.easyconfigir.manager.RegionHelper;
import king.easyconfigir.tool.LogTool;
import king.easyconfigir.ui.ControlWindow;

public class SwitchPanel extends JLayeredPane {

    private ControlPanel controlPanel;
    private RegionPanel regionPanel;

    public final static int FLAG_NONE = 0x0;
    public final static int FLAG_REGION = 0x1;
    public final static int FLAG_CONTROL = 0x2;

    private final static int BEGAIN_FLAG = FLAG_REGION;
    private final static int END_FLAG = FLAG_CONTROL;

    // 设置默认首次显示的面板
    public final static int DEFAULT_PANEL_FLAG = R.flag.DEFAULT_PANEL_FLAG;

    private int flag = DEFAULT_PANEL_FLAG;

    public SwitchPanel() {
        this(250, 230);
    }

    public SwitchPanel(int width, int height) {
        this.setSize(width, height);
        this.setLayout(null);

        controlPanel = new ControlPanel(width, height);
        regionPanel = new RegionPanel(width, height);

        this.add(controlPanel, 1);
        this.add(regionPanel, 0);

        switchPanel(flag);
    }

    public void changeView() {
        if (flag >= BEGAIN_FLAG && flag < END_FLAG) {
            flag += 0x1;
        } else {
            flag = BEGAIN_FLAG;
        }
        switchPanel(flag);
    }

    public void switchPanel(int flag) {
        switch (flag) {
            case FLAG_CONTROL:
                regionPanel.setVisible(false);
                controlPanel.setVisible(true);
                RegionHelper.instance().setOverlayVisible(false);
                LogTool.i("SwitchPanel", "change to control panel");
                break;
            case FLAG_REGION:
                controlPanel.setVisible(false);
                regionPanel.setVisible(true);
                RegionHelper.instance().setOverlayVisible(true);
                LogTool.i("SwitchPanel", "change to region panel");
                break;
            default:
                regionPanel.setVisible(false);
                controlPanel.setVisible(false);
                break;
        }
    }

    public void setPresetPanel(PresetPanel presetPanel) {
        controlPanel.getDirectionPanel().setPresetPanel(presetPanel);
        controlPanel.getDirectionPanel().setSwitchPanel(this);
        regionPanel.setPresetPanel(presetPanel);
    }

    public void setWindow(ControlWindow window) {
        window.addKeyListener(controlPanel.getDirectionPanel());
        window.getMainMenuBar().setSwitchPanel(this);
    }

    public RegionPanel getRegionPanel() {
        return regionPanel;
    }
}
