package king.easyconfigir.ui.panel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import king.easyconfigir.tool.TextTool;

public class VideoControlPanel extends JPanel implements ActionListener {
    private OneCheckPanel ocp0;
    private OneCheckPanel ocp1;
    private OneCheckPanel ocp2;
    private LinePanel highLP;
    private LinePanel irLP;
    private LinePanel openVideoIntervalLP;
    private LinePanel closeVideoIntervalLP;

    private VideoPanel videoPanel;

    public VideoControlPanel() {
        this(300, 300);
    }

    public VideoControlPanel(int width, int height) {
        this.setLayout(null);
        this.setSize(width, height);
        initView(width, height);
    }

    private void initView(int width, int height) {
        int lpad = 4;
        int lhei = 16;
        ocp0 = new OneCheckPanel("禁用全部视频: ");
        lpad = (width - ocp0.getWidth() - 2 * lpad) / 2 + lpad;
        ocp0.setLocation(lpad, lhei);
        this.add(ocp0);

        ocp1 = new OneCheckPanel("禁用高清视频: ");
        lhei += 2 + ocp0.getHeight();
        ocp1.setLocation(lpad, lhei);
        this.add(ocp1);

        ocp2 = new OneCheckPanel("禁用红外视频: ");
        lhei += 2 + ocp1.getHeight();
        ocp2.setLocation(lpad, lhei);
        this.add(ocp2);

        lpad = 4;
        highLP = new LinePanel(230, 30, "高清视频网络缓存: ", 108, 12, "设置");
        lpad = (width - highLP.getWidth() - 2 * lpad) / 2 + lpad;
        lhei += 2 + ocp2.getHeight();
        highLP.setLocation(lpad, lhei);
        this.add(highLP);

        irLP = new LinePanel(230, 30, "红外视频网络缓存: ", 108, 12, "设置");
        lhei += 2 + highLP.getHeight();
        irLP.setLocation(lpad, lhei);
        this.add(irLP);

        openVideoIntervalLP = new LinePanel(230, 30, "打开视频时间隔: ", 108, 12, "设置");
        lhei += 2 + irLP.getHeight();
        openVideoIntervalLP.setLocation(lpad, lhei);
        this.add(openVideoIntervalLP);

        closeVideoIntervalLP = new LinePanel(230, 30, "关闭视频时间隔: ", 108, 12, "设置");
        lhei += 2 + openVideoIntervalLP.getHeight();
        closeVideoIntervalLP.setLocation(lpad, lhei);
        this.add(closeVideoIntervalLP);

        ocp0.setListener(this);
        ocp1.setListener(this);
        ocp2.setListener(this);
        highLP.setListener(this);
        irLP.setListener(this);
        openVideoIntervalLP.setListener(this);
        closeVideoIntervalLP.setListener(this);
    }

    private void updateDate() {
        if (videoPanel != null) {
            if (videoPanel.isDisableVideo()) {
                ocp0.setSelected(true);
                ocp1.setEnabled(false);
                ocp2.setEnabled(false);
            } else {
                ocp1.setSelected(videoPanel.isDisableHighVideo());
                ocp2.setSelected(videoPanel.isDisableIRVideo());
            }
            highLP.setValue(String.valueOf(videoPanel.getHighVideoNetworkCaching()));
            irLP.setValue(String.valueOf(videoPanel.getIrVideoNetworkCaching()));
            openVideoIntervalLP.setValue(String.valueOf(videoPanel.getOpenVideoInterval()));
            closeVideoIntervalLP.setValue(String.valueOf(videoPanel.getCloseVideoInterval()));
        }
    }

    public VideoPanel getVideoPanel() {
        return videoPanel;
    }

    public void setVideoPanel(VideoPanel videoPanel) {
        this.videoPanel = videoPanel;
        this.updateDate();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (this.videoPanel == null) return;
        if (e.getSource() == ocp0.getSource()) {
            videoPanel.setDisableVideo(ocp0.isSelected());
            ocp1.setEnabled(!ocp0.isSelected());
            ocp2.setEnabled(!ocp0.isSelected());
        } else if (e.getSource() == ocp1.getSource()) {
            videoPanel.setDisableHighVideo(ocp1.isSelected());
        } else if (e.getSource() == ocp2.getSource()) {
            videoPanel.setDisableIRVideo(ocp2.isSelected());
        } else if (e.getSource() == highLP.getSource()) {
            String value = highLP.getValue();
            if (TextTool.isValidIntegerRange(value, 0, 20000, TextTool.ALL_CLOSE)) {
                videoPanel.setHighVideoNetworkCaching(Long.parseLong(value));
                JOptionPane.showMessageDialog(null, "设置成功! ");
            } else {
                JOptionPane.showMessageDialog(null, "参数无效! " + value);
                highLP.setValue(String.valueOf(videoPanel.getHighVideoNetworkCaching()));
            }
        } else if (e.getSource() == irLP.getSource()) {
            String value = irLP.getValue();
            if (TextTool.isValidIntegerRange(value, 0, 20000, TextTool.ALL_CLOSE)) {
                videoPanel.setIrVideoNetworkCaching(Long.parseLong(value));
                JOptionPane.showMessageDialog(null, "设置成功! ");
            } else {
                JOptionPane.showMessageDialog(null, "参数无效! " + value);
                irLP.setValue(String.valueOf(videoPanel.getIrVideoNetworkCaching()));
            }
        } else if (e.getSource() == openVideoIntervalLP.getSource()) {
            String value = openVideoIntervalLP.getValue();
            if (TextTool.isValidIntegerRange(value, 0, 20000, TextTool.ALL_CLOSE)) {
                videoPanel.setOpenVideoInterval(Long.parseLong(value));
                JOptionPane.showMessageDialog(null, "设置成功! ");
            } else {
                JOptionPane.showMessageDialog(null, "参数无效! " + value);
                openVideoIntervalLP.setValue(String.valueOf(videoPanel.getOpenVideoInterval()));
            }
        } else if (e.getSource() == closeVideoIntervalLP.getSource()) {
            String value = closeVideoIntervalLP.getValue();
            if (TextTool.isValidIntegerRange(value, 0, 20000, TextTool.ALL_CLOSE)) {
                videoPanel.setCloseVideoInterval(Long.parseLong(value));
                JOptionPane.showMessageDialog(null, "设置成功! ");
            } else {
                JOptionPane.showMessageDialog(null, "参数无效! " + value);
                closeVideoIntervalLP.setValue(String.valueOf(videoPanel.getCloseVideoInterval()));
            }
        }
    }

}
