package king.easyconfigir.ui.panel;

import com.sun.jna.Pointer;

import java.awt.Color;
import java.awt.Font;
import java.awt.Window;

import javax.swing.JLabel;
import javax.swing.SpringLayout;

import king.easyconfigir.R;
import king.easyconfigir.common.manager.CommandSender;
import king.easyconfigir.tool.LogTool;
import king.easyconfigir.video.Overlay;
import uk.co.caprica.vlcj.binding.internal.libvlc_media_close_cb;
import uk.co.caprica.vlcj.binding.internal.libvlc_media_open_cb;
import uk.co.caprica.vlcj.binding.internal.libvlc_media_read_cb;
import uk.co.caprica.vlcj.binding.internal.libvlc_media_seek_cb;
import uk.co.caprica.vlcj.media.Media;
import uk.co.caprica.vlcj.media.callback.CallbackMedia;
import uk.co.caprica.vlcj.player.base.MediaPlayer;
import uk.co.caprica.vlcj.player.component.EmbeddedMediaPlayerComponent;
//import uk.co.caprica.vlcj.player.base.MediaPlayer;
//import uk.co.caprica.vlcj.player.component.EmbeddedMediaPlayerComponent;

public class VideoPanel extends BasePanel {

    private EmbeddedMediaPlayerComponent highPlayer;
    private EmbeddedMediaPlayerComponent IRPlayer;

    private MediaPlayer mph;
    private MediaPlayer mpi;

    private Overlay mOverlay;
    private int xw = (int) R.value.XW;
    private int xh = (int) R.value.XH;

    private boolean isDisableVideo = R.flag.DISABLED_VIDEO;
    private boolean isDisableHighVideo = false;
    private boolean isDisableIRVideo = false;

    private long highVideoNetworkCaching = R.value.DEFAULT_HIGH_VIDEO_NETWORKCACHING;
    private long irVideoNetworkCaching = R.value.DEFAULT_IR_VIDEO_NETWORKCACHING;

    private long openVideoInterval = R.value.OPEN_VIDEO_INTERVAL;
    private long closeVideoInterval = R.value.CLOSE_VIDEO_INTERVAL;

    private OverlayEventListener overlayEventListener;

    private final static int FLAG_HIGH = 0x0;
    private final static int FLAG_IR = 0x1;

    public interface OverlayEventListener {
        void onOverlayCreate(Overlay overlay);
    }

    public void setOverlayEventListener(OverlayEventListener overlayEventListener) {
        this.overlayEventListener = overlayEventListener;
    }

    public VideoPanel() {
        this(null);
    }

    public VideoPanel(SpringLayout layout) {
        this(R.size.CONTROL_VIDEO_WIDTH,
                R.size.CONTROL_VIDEO_HEIGHT,
                layout
        );
    }

    public VideoPanel(int width, int height, SpringLayout layout) {
        this(R.title.VIDEO_PANEL, width, height, layout);
    }

    public VideoPanel(String title, int width, int height, SpringLayout layout) {
        super(title, width, height, layout);
        this.setLayout(null);
        //this.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JLabel high = new JLabel("高清视频", JLabel.CENTER);
        JLabel ir = new JLabel("红外视频", JLabel.CENTER);
        high.setFont(new Font("微软雅黑", 1, 18));
        ir.setFont(new Font("微软雅黑", 1, 18));
        ir.setForeground(new Color(228, 20, 6));

        highPlayer = new EmbeddedMediaPlayerComponent();
        IRPlayer = new EmbeddedMediaPlayerComponent();

        int ww = (int) (width * 0.4);
        int hh = 30;
        high.setBounds((width / 2 - ww) / 2, 0, ww, hh);
        ir.setBounds((width / 2 - ww) / 2 + width / 2, 0, ww, hh);

        highPlayer.setBounds(2, hh + 2, xw, xh);
        IRPlayer.setBounds(width - xw - 2, hh + 2, xw, xh);

        this.add(highPlayer);
        this.add(IRPlayer);

        this.add(high);
        this.add(ir);
    }

    public void showOverlay(Window window) {
        EmbeddedMediaPlayerComponent view = highPlayer;
        if (R.flag.SHOW_OVERLAY_ON_IR) {
            view = IRPlayer;
        }
        mOverlay = new Overlay(window, xw, xh);
        if (overlayEventListener != null) {
            overlayEventListener.onOverlayCreate(mOverlay);
        }
        view.mediaPlayer().overlay().set(
                mOverlay
        );
        mOverlay.setVisible(true);
        view.mediaPlayer().overlay().enable(true);
    }

    public Overlay getOverlay() {
        return mOverlay;
    }

    public void playHigh(String mrl) {
        if (mrl != null && !"".equals(mrl)) {
            if (mph == null) {
                mph = highPlayer.mediaPlayer();
            }
            mph.media().play(mrl, this.genPlayArgs(FLAG_HIGH));
        }
    }

    public void playIR(String mrl) {
        if (mrl != null && !"".equals(mrl)) {
            if (mpi == null) {
                mpi = IRPlayer.mediaPlayer();
            }
            mpi.media().play(mrl, this.genPlayArgs(FLAG_IR));
        }
    }

    public void playHS(String ip) {
        if (this.isDisableVideo) {
            LogTool.i("VideoPanel", "You have disabled all videos(2)! isDisableVideo: " + this.isDisableVideo);
            return;
        }
        if (null != ip && !"".equals(ip)) {
            new Thread(() -> {
                String videoURL = "rtsp://127.0.0.1:5554/test";
                if (!isDisableHighVideo) {
                    videoURL = "rtsp://" + ip + ":" + R.prot.HS_VIDEO_PROT + "/high.h264";
                    playHigh(videoURL);
                    LogTool.i("VideoPanel", "play: " + videoURL);
                } else {
                    LogTool.i("VideoPanel", "HighVideo is disabled! ");
                }

                if (!isDisableHighVideo && !isDisableIRVideo) {
                    try {
                        LogTool.i("VideoPanel", "openVideoInterval: " + openVideoInterval);
                        Thread.sleep(openVideoInterval);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                if (!isDisableIRVideo) {
                    videoURL = "rtsp://" + ip + ":" + R.prot.HS_VIDEO_PROT + "/ir.h264";
                    playIR(videoURL);
                    LogTool.i("VideoPanel", "play: " + videoURL);
                } else {
                    LogTool.i("VideoPanel", "IRVideo is disabled! ");
                }
            }).start();
        } else {
            LogTool.i("VideoPanel", "palyHS ip: " + ip);
        }
    }

    public void stop() {
        try {
            new Thread(() -> {
                try {
                    assert mph != null;
                    assert mpi != null;
                    mph.controls().stop();
                    try {
                        LogTool.i("VideoPanel", "closeVideoInterval: " + closeVideoInterval);
                        Thread.sleep(closeVideoInterval);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    mpi.controls().stop();
                } catch (Exception e) {
                    // java.lang.NullPointerException mph, mpi
                }
            }).start();
        } catch (Exception e) {
//            LogTool.i("VideoPanel", "stop video...");
        }
    }

    public void release() {
        try {
            if (mph != null
                    &&
                    mpi != null
            ) {
                stop();
                if (mph.status().isPlaying()) {
                    mph.release();
                }
                if (mpi.status().isPlaying()) {
                    mpi.release();
                }
                mph = null;
                mpi = null;
                LogTool.i("VideoPanel", "player release");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private String genPlayArgs(int flag) {
        String args = "";
        switch (flag) {
            case FLAG_HIGH:
                args = ":network-caching=" + this.getHighVideoNetworkCaching();
                break;
            case FLAG_IR:
                args = ":network-caching=" + this.getIrVideoNetworkCaching();
                break;
        }
        LogTool.i("VideoPanel", "genPlayArgs args: " + args);
        return args;
    }

    public boolean isDisableVideo() {
        return isDisableVideo;
    }

    public void setDisableVideo(boolean isDisableVideo) {
        this.isDisableVideo = isDisableVideo;
    }

    public boolean isDisableHighVideo() {
        return isDisableHighVideo;
    }

    public void setDisableHighVideo(boolean isDisableHighVideo) {
        this.isDisableHighVideo = isDisableHighVideo;
    }

    public boolean isDisableIRVideo() {
        return isDisableIRVideo;
    }

    public void setDisableIRVideo(boolean isDisableIRVideo) {
        this.isDisableIRVideo = isDisableIRVideo;
    }

    public long getIrVideoNetworkCaching() {
        return irVideoNetworkCaching;
    }

    public void setIrVideoNetworkCaching(long irVideoNetworkCaching) {
        this.irVideoNetworkCaching = irVideoNetworkCaching;
    }

    public long getHighVideoNetworkCaching() {
        return highVideoNetworkCaching;
    }

    public void setHighVideoNetworkCaching(long highVideoNetworkCaching) {
        this.highVideoNetworkCaching = highVideoNetworkCaching;
    }

    public long getOpenVideoInterval() {
        return openVideoInterval;
    }

    public void setOpenVideoInterval(long openVideoInterval) {
        this.openVideoInterval = openVideoInterval;
    }

    public long getCloseVideoInterval() {
        return closeVideoInterval;
    }

    public void setCloseVideoInterval(long closeVideoInterval) {
        this.closeVideoInterval = closeVideoInterval;
    }
}
