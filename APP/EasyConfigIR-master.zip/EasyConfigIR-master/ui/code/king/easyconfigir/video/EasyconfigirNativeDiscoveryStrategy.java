package king.easyconfigir.video;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import king.easyconfigir.tool.LogTool;
import uk.co.caprica.vlcj.binding.LibC;
import uk.co.caprica.vlcj.binding.RuntimeUtil;
import uk.co.caprica.vlcj.factory.discovery.strategy.BaseNativeDiscoveryStrategy;

public class EasyconfigirNativeDiscoveryStrategy extends BaseNativeDiscoveryStrategy {
	
    private static final String[] FILENAME_PATTERNS = new String[] {
            "libvlc\\.dll",
            "libvlccore\\.dll"
    };

    private static final String[] PLUGIN_PATH_FORMATS = new String[] {
            "%s\\plugins",
            "%s\\vlc\\plugins"
    };
        
    public EasyconfigirNativeDiscoveryStrategy() {
    	 this(FILENAME_PATTERNS, PLUGIN_PATH_FORMATS);
    }
    
	public EasyconfigirNativeDiscoveryStrategy(String[] filenamePatterns, String[] pluginPathFormats) {
		super(filenamePatterns, pluginPathFormats);
	}

	@Override
	public boolean supported() {
		return RuntimeUtil.isWindows();
	}

	@Override
	protected List<String> discoveryDirectories() {
		List<String> directories = new ArrayList<String>();
		String path = System.getProperty("user.dir") + File.separator+"vlc"+File.separator+"xxx";
	    LogTool.i("EasyconfigirNativeDiscoveryStrategy", "path: "+path);
		directories.add(path);
		return directories;
	}

	@Override
	protected boolean setPluginPath(String pluginPath) {
		return LibC.INSTANCE._putenv(String.format("%s=%s", PLUGIN_ENV_NAME, pluginPath)) == 0;
	}

}
