package king.easyconfigir.video;

import java.awt.*;

import com.sun.jna.platform.WindowUtils;
import king.easyconfigir.manager.RegionHelper;
import king.easyconfigir.model.Point;
import king.easyconfigir.model.Shape;

public class Overlay extends Window implements RegionHelper.RegionEvent{

	private int width;
	private int height;

	public Overlay(Window owner, int width, int height) {
        super(owner, WindowUtils.getAlphaCompatibleGraphicsConfiguration());
        this.width = width;
        this.height = height;
        this.setSize(width, height);
        // 透明度必须大于0，否则无法监听鼠标事件
        setBackground(new Color(0, 0, 0, 0.1f));
        this.setFocusable(false);
        this.addMouseListener(RegionHelper.instance());
        RegionHelper.instance().addRegionEventListener(this);
    }

	public void fresh() {
        // 渲染Overlay
        this.setVisible(false);
        this.setVisible(true);
    }

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		RegionHelper.instance().render(g2);
	}

	@Override
	public void onAddPoint(Point point) {
		fresh();
	}

	@Override
	public void onDeleteShape(Shape shape) {
		fresh();
	}

	@Override
	public void onDeletePoint(Point point) {
		fresh();
	}
}
