package king.easyconfigir.video;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import king.easyconfigir.tool.LogTool;
import uk.co.caprica.vlcj.factory.MediaPlayerFactory;
import uk.co.caprica.vlcj.player.base.MediaPlayer;
import uk.co.caprica.vlcj.player.embedded.EmbeddedMediaPlayer;
import uk.co.caprica.vlcj.player.embedded.videosurface.callback.BufferFormat;
import uk.co.caprica.vlcj.player.embedded.videosurface.callback.BufferFormatCallbackAdapter;
import uk.co.caprica.vlcj.player.embedded.videosurface.callback.RenderCallbackAdapter;
import uk.co.caprica.vlcj.player.embedded.videosurface.callback.format.RV32BufferFormat;

public class RtspHelper {

	private final static String[] EMBEDDED_MEDIA_PLAYER_ARGS = {
			"--video-title=vlcj video output",
			"--no-snapshot-preview",
			"--quiet",
			"--intf=dummy",
			"--rtsp-tcp",
			"--h264-fps=24.0" 
			};
	private final JPanel panel;
	private final BufferedImage image;
	private final EmbeddedMediaPlayer mediaPlayer;

	public RtspHelper() {
		this(320, 240);
	}

	public RtspHelper(int width, int height) {
		image = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration()
				.createCompatibleImage(width, height);
		panel = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				Graphics2D g2 = (Graphics2D) g;
				g2.setColor(Color.black);
				g2.fillRect(0, 0, getWidth(), getHeight());
				g2.drawImage(image, null, 0, 0);
				LogTool.i("paintComponent", "...");
			}
		};
		panel.setBackground(Color.black);
		panel.setOpaque(true);
		panel.setSize(new Dimension(width, height));
		
		mediaPlayer = initMediaPlayer(width, height);
	}

	public JPanel getRenderPanel() {
		return panel;
	}

	public MediaPlayer getMediaPlayer() {
		return mediaPlayer;
	}
	
	public void play(String mrl) {
		mediaPlayer.media().play(mrl, ":file-caching=1500", ":network-caching=300", ":codec=mediacodec,iomx,all",
				":demux=h264");
	}

	public void release() {
		mediaPlayer.release();
	}

	private EmbeddedMediaPlayer initMediaPlayer(int width, int height) {
		MediaPlayerFactory mpf = new MediaPlayerFactory(EMBEDDED_MEDIA_PLAYER_ARGS);
		EmbeddedMediaPlayer mediaPlayer = mpf.mediaPlayers().newEmbeddedMediaPlayer();
		mediaPlayer.videoSurface().set(mpf.videoSurfaces().newVideoSurface(new BufferFormatCallbackAdapter() {
			@Override
			public BufferFormat getBufferFormat(int sourceWidth, int sourceHeight) {
				// TODO Auto-generated method stub
				LogTool.i("getBufferFormat", "sourceWidth: " + sourceWidth + " sourceHeight: " + sourceHeight);
				return new RV32BufferFormat(width, height);
			}
		}, new InnerRenderCallbackAdapter(width, height), true));
		return mediaPlayer;
	}

	private class InnerRenderCallbackAdapter extends RenderCallbackAdapter {

		private int width;
		private int height;

		private InnerRenderCallbackAdapter(int width, int height) {
			super(new int[width * height]);
			this.width = width;
			this.height = height;
		}

		@Override
		protected synchronized void onDisplay(MediaPlayer mediaPlayer, int[] buffer) {
			image.setRGB(0, 0, width, height, buffer, 0, width);
			panel.repaint();
		}
	}
}
