package king.easyconfigir.video;

import javax.swing.JFrame;

import uk.co.caprica.vlcj.player.component.EmbeddedMediaPlayerComponent;

//import org.bytedeco.javacpp.opencv_core;
//import org.bytedeco.javacv.CanvasFrame;
//import org.bytedeco.javacv.FFmpegFrameGrabber;
//import org.bytedeco.javacv.Frame;
//import org.bytedeco.javacv.FrameGrabber.Exception;
//import org.bytedeco.javacv.OpenCVFrameConverter;
//import org.opencv.core.Core;
//import uk.co.caprica.vlcj.player.component.EmbeddedMediaPlayerComponent;

public class RtspVideo {
	
	private final JFrame frame;

    private final EmbeddedMediaPlayerComponent mediaPlayerComponent;
    
    public RtspVideo() {
        mediaPlayerComponent = new EmbeddedMediaPlayerComponent();
        frame = new JFrame("vlcj quickstart");
        frame.setLocation(50, 50);
        frame.setSize(300, 250);
        frame.setContentPane(mediaPlayerComponent);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public void start(String mrl) {

        mediaPlayerComponent.mediaPlayer().media().play(mrl);
    }

//	static {
//		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
//	}
//	
//	public RtspVideo () throws Exception{
//		String file = "rtsp://192.168.8.114:5554/high.h264";
//        FFmpegFrameGrabber grabber = FFmpegFrameGrabber.createDefault(file);
//       // grabber.setOption("rtsp_transport", "tcp"); // 使用tcp的方式，不然会丢包很严重
//        // 一直报错的原因！！！就是因为是 2560 * 1440的太大了。。
//        grabber.setImageWidth(300);
//        grabber.setImageHeight(250);
//      
//        System.out.println("grabber start");
//        grabber.start();
//        CanvasFrame canvasFrame = new CanvasFrame("sdsaf");
//        canvasFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        canvasFrame.setAlwaysOnTop(true);
//        OpenCVFrameConverter.ToMat converter = new OpenCVFrameConverter.ToMat();
//       // OpenCVFrameConverter.ToIplImage converter = new OpenCVFrameConverter.ToIplImage();
//        while (true){
//            Frame frame = grabber.grabImage();
//            opencv_core.Mat mat = converter.convertToMat(frame);
//            canvasFrame.showImage(frame);
//        }
//
//	}
}
