package king.easyconfigir.feature.render;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import king.autogen.model.Device;

public class BlockRender extends JPanel implements TableCellRenderer {

	public JLabel info;
	public JButton test;
	
	public BlockRender() {
		  super();
	      this.setLayout(new BorderLayout());
	      info = new JLabel();
	      test = new JButton();
	      this.add(test, BorderLayout.NORTH);
	      this.add(info, BorderLayout.CENTER);
	}
	 
	 public void setText(String text) {
		    this.info.setText(text);
	 }
	
	@Override
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		 // TODO Auto-generated method stub
		 table.setRowHeight(table.getWidth()/4);
		
		 Device device = (Device) value;
		 this.setText(device.getName());
	 	 
		 if(isSelected) {
		    	this.setBackground(table.getSelectionBackground());
		    	this.setForeground(table.getSelectionForeground());
		 } else {
		    	this.setBackground(table.getBackground());
		    	this.setForeground(table.getForeground());
	    }
		return this;
	}
}
