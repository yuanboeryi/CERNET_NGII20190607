package king.easyconfigir.feature.render;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.ListCellRenderer;
import javax.swing.SwingConstants;

import king.autogen.model.Server;

public class LineRender extends JPanel implements ListCellRenderer<Server> {
	 private JLabel icon;
	 private JLabel info;
	 private JLabel status;
	 private JSeparator jse;
	 
	 public LineRender(int width, int height) {
		  super();
		  this.setPreferredSize(new Dimension(width, height));
	      this.setLayout(null);
	      icon = new JLabel();
	      info = new JLabel();
	      status = new JLabel();
	      jse = new JSeparator(SwingConstants.CENTER);
	      
	      int pad = 3, s0 = 2, s1 = 2, s2=6, s3=1;
	      int ls0=(int) (height-s0*pad);
	      int ls1=(int) (height-s2*pad);
	      int ls2 = width-4;
	      icon.setBounds(s0/2*pad,  s0/2*pad,  ls0, ls0);
	      info.setBounds(height+s1*pad, 0,width-2*height-s1*pad  , height);
	      status.setBounds(width-height, s2/2*pad, ls1, ls1);
	      jse.setBounds((width-ls2)/2, height-s3, ls2, s3);
	      
	      icon.setHorizontalAlignment(JLabel.CENTER);
	      status.setHorizontalAlignment(JLabel.CENTER);
	      jse.setBackground(Color.RED);
	      
	      this.add(icon);
	      this.add(info);
	      this.add(status);
	      this.add(jse);
	      
	 }
	 
	 public void setIcon(String uri) {
		    ImageIcon img=new ImageIcon(uri);
			this.icon.setIcon(img);
			this.status.setIcon(img);
	 }
	 
	 public void setText(String text) {
		    this.info.setText(text);
	 }
	 
	//@Override
	public Component getListCellRendererComponent(JList<? extends Server> list, Server value, int index,
			boolean isSelected, boolean cellHasFocus) {
		    // TODO Auto-generated method stub
		
//		     
//		     LogTool.i(this.getClass().getName(), 
//       		 "id: "+value.getId()+
//       		 " name: "+value.getName()+
//       		 " icon: "+value.getIcon()
//       		 );
//		       
		    String uri = value.getIcon();
		    String text = value.getName();
		    
		    this.setIcon(uri);
		    this.setText(text);
		    
		    if(isSelected) {
		    	this.setBackground(list.getSelectionBackground());
		    	this.setForeground(list.getSelectionForeground());
		    } else {
		    	this.setBackground(list.getBackground());
		    	this.setForeground(list.getForeground());
		    }
		    
		    this.setEnabled(list.isEnabled());
		    this.setFont(this.getFont());
		    this.setOpaque(true);
		    return this;
	}

}
