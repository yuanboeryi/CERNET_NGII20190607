package king.easyconfigir.feature.ui;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JFrame;
import javax.swing.SpringLayout;

import king.easyconfigir.R;
import king.easyconfigir.tool.ResTool;
import king.easyconfigir.ui.BaseWindow;
import king.easyconfigir.ui.menu.MainMenuBar;
import king.easyconfigir.ui.panel.BodyPanel;
import king.easyconfigir.ui.panel.NavigationPanel;

public class MainWindow extends BaseWindow {

	   private NavigationPanel mainNavigationPanel;
	   private BodyPanel bodyPanel;
	   
	   public MainWindow() {
           this(R.app.NAME,
                   R.size.MAIN_WINDOW_WIDTH,
                   R.size.MAIN_WINDOW_HEIGHT
           );
       }
	   
	   public MainWindow(String title, int width, int height) {
		           super(title, width, height); 
		           this.initWindowViews(this.window);
		           this.initWindowListener(this.window);
	   }
	   
	   private void initWindowListener(JFrame window) {
		    window.addComponentListener(new ComponentAdapter() {
	              public void componentResized(ComponentEvent e) {
	         		       //   updateViewLocation();
	              }
            });
	   }
	   
	   private void initWindowViews(JFrame window) {
		      mainLayout = new SpringLayout();
		      window.setLayout(mainLayout); 
		      mainMenuBar = new MainMenuBar(window, ResTool.loadJson(R.json.main_menu_bar), mainLayout);
		      mainNavigationPanel = new NavigationPanel(mainLayout);
		      bodyPanel = new BodyPanel(mainLayout);
		      window.add(mainMenuBar);
		      window.add(mainNavigationPanel);
		      window.add(bodyPanel);
		      updateViewLocation();
	   }
	   
	   private void updateViewLocation() {
		      int ww =window.getWidth(), wh = window.getHeight();
		      int pad = 3;
		      mainMenuBar.setSpringNSWE(3, mainMenuBar.getHeight(), 3, ww-3);
		      mainNavigationPanel.setSpringNSWE(
		    		  mainMenuBar.getSpringSouthValue()+pad,
		    		  wh - mainMenuBar.getHeight()-pad,
		    		  mainMenuBar.getSpringWestValue(), 
		    		  mainMenuBar.getSpringWestValue() +  mainNavigationPanel.getWidth()
		    		  );
		      bodyPanel.setSpringNSWE(
		    		  mainMenuBar.getSpringSouthValue()+pad,
		    		  wh - mainMenuBar.getHeight()-pad,
		    		  mainNavigationPanel.getSpringEastValue()+3,
		    		  ww - 3
		    		  );
		      System.out.println("width: "+ww+" height: "+wh);
	   }

}
