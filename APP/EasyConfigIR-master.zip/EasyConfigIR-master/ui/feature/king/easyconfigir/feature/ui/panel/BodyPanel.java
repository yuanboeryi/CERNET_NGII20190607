package king.easyconfigir.feature.ui.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.List;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SpringLayout;
import javax.swing.table.DefaultTableModel;

import org.apache.ibatis.session.SqlSession;

import king.autogen.mapper.DeviceMapper;
import king.autogen.model.Device;
import king.autogen.model.DeviceExample;
import king.easyconfigir.R;
import king.easyconfigir.database.DataManager;
import king.easyconfigir.render.BlockRender;
import king.easyconfigir.ui.panel.BasePanel;

public class BodyPanel extends BasePanel {
	
	private JScrollPane jsp;
	private JTable jt;
	private int total;
	
	public BodyPanel() {
	      this(null);
    }

    public BodyPanel(SpringLayout layout) {
	      this( R.size.MAIN_BODY_WIDTH,
	    		   R.size.MAIN_BODY_HEIGHT,
	    		   layout
	    		   );
    }

    public BodyPanel( int width, int height,  SpringLayout layout) {
		this(R.title.BODY_PANEL, width, height, layout);
	}
    
	public BodyPanel(String title, int width, int height, SpringLayout layout) {
		       super(title, width, height, layout);
		       this.setLayout(new BorderLayout());
			   this.setBackground(R.color.MAIN_BODY_BACKGROUND_COLOR);
			   this.setBorder(BorderFactory.createLineBorder(Color.GRAY));
		       this.add(this.obtainHeaderPanel(), BorderLayout.NORTH);
		       this.add(this.obtainDevicePanel(), BorderLayout.CENTER);
	}
	
	private JPanel obtainHeaderPanel() {
		    JPanel header = new JPanel();
            JLabel title =new JLabel(this.getName());
            header.setLayout(new FlowLayout(FlowLayout.LEFT));
            header.add(title);
		    return header;
	}
	
	private JPanel obtainDevicePanel() {
		    JPanel device = new JPanel();
		    device.setLayout(new BorderLayout());
		    jsp=new JScrollPane();
		    jsp.setBorder(BorderFactory.createLineBorder(Color.GRAY));
		    jsp.setHorizontalScrollBarPolicy(
		      	    JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			jsp.setVerticalScrollBarPolicy(
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		   jt=new JTable();
		   jt.setModel(this.getTableModel(4));
		   jt.getTableHeader().setPreferredSize(new Dimension(0,0));
		   jt.setCellSelectionEnabled(true);		
		   jt.setDefaultRenderer(Object.class, new BlockRender());
		   jsp.setViewportView(jt);
		   device.add(jsp, BorderLayout.CENTER);
		   return device;
	}
	
	private DefaultTableModel getTableModel(int per) {
		Vector title= new Vector();
		for(int i=0; i<per; i++) {
			title.add("col "+i);
		}
		Vector data =new Vector();
	    DataManager.self().setOnSqlSession(new DataManager.OnSqlSession(){
		       public void onOpen(SqlSession session) {
		    	  
	              DeviceMapper mapper = session.getMapper(DeviceMapper.class);
	              Device record = new Device();
	              record.setName("");
	              mapper.insert(record);
	              DeviceExample example = new DeviceExample();
	              List<Device> list = mapper.selectByExample(example);
	              int  count=1;
	              Vector line=null;
	              for (Device device : list) {
					  if (line == null) line = new Vector();
					  device.setName("设备" + count);
					  line.addElement(device);
					  if (0 == (count % per)) {
						  data.addElement(line);
						  line = null;
					  }
					  count += 1;
				  }
	              total = count-1;
		      }
	          }).open();
	    System.out.println("total: "+total);
		DefaultTableModel model=new DefaultTableModel(data, title);
		return model;
	}
	
}
