package king.easyconfigir.feature.ui.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SpringLayout;

import org.apache.ibatis.session.SqlSession;

import king.autogen.mapper.ServerMapper;
import king.autogen.model.Server;
import king.autogen.model.ServerExample;
import king.easyconfigir.R;
import king.easyconfigir.database.DataManager;
import king.easyconfigir.listener.PopuMenuListener;
import king.easyconfigir.render.LineRender;
import king.easyconfigir.ui.panel.BasePanel;

public class NavigationPanel extends BasePanel {

	private JScrollPane jsp;
	private JList jl;
	private JLabel status;
	
	public NavigationPanel() {
		      this(null);
	}
	
	public NavigationPanel(SpringLayout layout) {
		      this( R.size.MAIN_NAVIGATION_WIDTH,
		    		   R.size.MAIN_NAVIGATION_HEIGHT,
		    		   layout
		    		   );
	}
	
	public NavigationPanel( int width, int height,  SpringLayout layout) {
        this(R.title.NAVIGATION_PANEL, width, height, layout);
    }
	
	public NavigationPanel(String title, int width, int height,  SpringLayout layout) {
		      super(title, width, height, layout);
		      this.setLayout(new BorderLayout());
		      this.setBackground(R.color.MAIN_NAVIGATION_BACKGROUND_COLOR);
		 	  //this.setBorder(BorderFactory.createLineBorder(Color.GRAY));
		      this.add(obtainHeaderPanel(), BorderLayout.NORTH);
		      this.add(obtainFooterPanel(), BorderLayout.SOUTH);
			  this.add(obtainBodyPanel(),    BorderLayout.CENTER);
			  
	}
	
	private JPanel obtainHeaderPanel() {
		 JPanel header = new JPanel();
         JLabel title =new JLabel(this.getName());
         header.setLayout(new FlowLayout(FlowLayout.LEFT));
        // header.setBackground(Color.CYAN);
         header.add(title);
		 return header;
	}
	
	private JPanel obtainBodyPanel() {
	    JPanel body = new JPanel();
	    body.setLayout(null);
	    jsp=new JScrollPane();
	    jsp.setBounds(R.size.PAD, R.size.PAD, this.getWidth()-R.size.PAD, this.getHeight()*2/3-R.size.PAD);
	    jsp.setBorder(BorderFactory.createLineBorder(Color.GRAY));
	    jsp.setViewportBorder(BorderFactory.createLineBorder(Color.GRAY));
	    jl=new JList();
	    jl.setCellRenderer(new LineRender(this.getWidth()-5,  30));
	    jl.setModel(this.getListModel());
	    jl.addMouseListener(new PopuMenuListener(jl));
	    jsp.setViewportView(jl);
	    jsp.setHorizontalScrollBarPolicy(
	      	    JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jsp.setVerticalScrollBarPolicy(
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
	   body.add(jsp);
	   return body;
	}
	
	private DefaultListModel getListModel() {
		   DefaultListModel listModel=new DefaultListModel();
		   DataManager.self().setOnSqlSession(new DataManager.OnSqlSession(){
		       public void onOpen(SqlSession session) {
		    
	              ServerMapper mapper = session.getMapper(ServerMapper.class);
	              ServerExample example = new ServerExample();
	              List<Server> list = mapper.selectByExample(example);
	              for (Server server : list) {
	                     listModel.addElement(server);
	              }
	              if(status!=null) {
                      status.setText("服务器总数：" + list.size());
                  }
	               
		      }
	          }).open();	 
		   return listModel;
	}
	
	public void updateServerList(String info) {
		int size=jl.getModel().getSize();
		DefaultListModel listModel=null;
		if(size==0) {
			listModel=new DefaultListModel();
			listModel.addElement(info);
		} else {
			listModel=(DefaultListModel) jl.getModel();
			listModel.addElement(info);
		}
		
		jl.setModel(listModel);
		size=jl.getModel().getSize();
		jl.setSelectedIndex(size-1);
		
		jsp.getVerticalScrollBar().setValue(jsp.getVerticalScrollBar().getMaximum());
	}
	
	private JPanel obtainFooterPanel() {
		JPanel footer = new JPanel();
		footer.setPreferredSize(new Dimension(this.getWidth(), 100));
		footer.setLayout(new FlowLayout(FlowLayout.CENTER));
		status = new JLabel();
	    footer .add(status);
		return footer;
	}
}
