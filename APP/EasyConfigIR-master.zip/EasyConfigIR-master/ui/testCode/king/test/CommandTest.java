package king.test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CommandTest {

    @DisplayName("云台停止指令：0x00")
    @Test
    public void testDirectionStop() {
    	
    }

    @DisplayName("云台右转指令：0x02")
    @Test
    public void testDirectionRight() {
    	
    }

    @DisplayName("设置预设点指令：0x03")
    @Test
    public void testPresetPointSet() {
    	
    }

    @DisplayName("云台左转指令：0x04")
    @Test
    public void testDirectionLeft() {
    	
    }

    @DisplayName("清除预设点指令：0x05")
    @Test
    public void testPresetPointClear() {
    	
    }

    @DisplayName("调用预设点指令：0x07")
    @Test
    public void testPresetPointCall() {
    	
    }

    @DisplayName("获取当前红外帧指令：0x80")
    @Test
    public void testCaptureIRFrame() {
    	
    }

    @DisplayName("设置存储图片色带指令： 0x81")
    @Test
    public void testPictureColorSet() {
    	
    }

    @DisplayName("设置守望点指令：0x97")
    @Test
    public void testLookupPointSet() {
    	
    }

    @DisplayName("扫描所有预设点指令：0x9a")
    @Test
    public void testAllPresetPointScan() {
    	
    }

    @DisplayName("启动云台校准指令：0x9b")
    @Test
    public void testCloudAdjust() {
    	
    }

    @DisplayName("设置守望点高温告警温度指令：0x9c")
    @Test
    public void testLookupPointWarnTemperature() {
    	
    }

    @DisplayName("设置服务器地址指令：0x9d")
    @Test
    public void testServerAddressSet() {
    	
    }

    @DisplayName("云台上转指令：0xA0")
    @Test
    public void testDirectionUp() {
    	
    }

    @DisplayName("云台下转指令：0xA1")
    @Test
    public void testDirectionDown() {
    	
    }

    @DisplayName("全预设点清除指令：0xA2")
    @Test
    public void testAllPresetPointClear() {
    	
    }

    @DisplayName("wifi配置指令：0xA3")
    @Test
    public void testWifiSet() {
    	
    }

    @DisplayName("复位参数配置指令：0xA4")
    @Test
    public void testArgsReset() {
    	
    }

    @DisplayName("设置辐射率指令：0xA5")
    @Test
    public void testEmissivitySet() {
    	
    }

    @DisplayName("复位系统指令：0xA6")
    @Test
    public void testOSReset() {
    	
    }

    @DisplayName("配置ssh参数指令：0xA8")
    @Test
    public void testSSH() {
    	
    }

    @DisplayName("设置红外呈现参数指令：0xA9")
    @Test
    public void testIRShowArgs() {
    	
    }

    @DisplayName("设置红外勾边参数指令：0xAA")
    @Test
    public void testIRSideArgs() {
    	
    }

    @DisplayName("设置红外融合偏移指令：0xAB")
    @Test
    public void testIROffset() {
    	
    }

    @DisplayName("设置红外融合旋转和放大参数指令：0xAC")
    @Test
    public void testIRRotationAndEnlarge() {
    	
    }

    @DisplayName("重启ssh服务指令：0xAD")
    @Test
    public void testSSHRestart() {
    	
    }

    @Disabled
    @DisplayName("测温区域设定指令：0xAE")
    @Test
    public void testRegionSet() {
    	Assertions.assertNotNull(null);
    }

    @Disabled
    @DisplayName("测温区域清除指令：0xAF")
    @Test
    public void testRegionClear() {
    	Assertions.assertNotNull(null);
    }

    @DisplayName("修改预设点距离指令：0xB0")
    @Test
    public void testPresetPointDistanceModify() {
    	
    }

    @DisplayName("周期预设点扫描开关指令：0xB2")
    @Test
    public void testPresetPointScanSwitcher() {
    	
    }

    @Disabled
    @DisplayName("远程程序更新指令：0xB3")
    @Test
    public void testRemoteUpdate() {
    	Assertions.assertNotNull(null);
    }

    @DisplayName("设置巡检和拍图周期指令：0xB4")
    @Test
    public void testInspectionAndShootingCycle() {
    	
    }

    @DisplayName("开启/关闭视频推流指令：0xB5")
    @Test
    public void testRtspSwitcher() {
    	
    }

    @DisplayName("系统时间校准指令：0xB6")
    @Test
    public void testOSTimeAdjust() {
    	
    }

    @DisplayName("修改设备ID号指令：0xB7")
    @Test
    public void testDeviceIDModify() {
    	
    }

    @DisplayName("测温区域边界呈现指令：0xB8")
    @Test
    public void testRegionOutlook() {
    	
    }

    @DisplayName("继电器开关控制指令：0x01")
    @Test
    public void testRelaySwitcher() {
    	
    }
}
