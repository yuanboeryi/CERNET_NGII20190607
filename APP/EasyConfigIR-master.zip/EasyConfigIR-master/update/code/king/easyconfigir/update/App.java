package king.easyconfigir.update;

import com.alee.laf.WebLookAndFeel;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import king.easyconfigir.update.manager.UpdateAgent;
import king.easyconfigir.update.model.Backup;
import king.easyconfigir.update.model.Target;
import king.easyconfigir.update.model.UpdateItem;
import king.easyconfigir.update.model.UpdatePackage;
import king.easyconfigir.update.panel.UpdateControlPanel;
import king.easyconfigir.update.panel.UpdateStatusPanel;
import king.easyconfigir.update.tool.JsonTool;
import king.easyconfigir.update.tool.LogTool;

public abstract class App implements UpdateAgent.UpdateEvent {

    private JDialog dialog;
    private UpdateStatusPanel updateStatusPanel;
    private boolean isFinishedUpdate = false;

    public App() {

    }

    public abstract Target obtainTarget();

    public static Target loadTarget(String path) {
        Target target = null;
        File appConfig = new File(path);
        if (appConfig.exists()) {
            target = JsonTool.fromJson(appConfig, Target.class);
        }
        LogTool.i("App", "load target path: " + path);
        LogTool.i("App", "target: " + JsonTool.toJson(target));
        return target;
    }

    public final void lanuch() {
        WebLookAndFeel.install();
        Target target = obtainTarget();
        if (target != null) {
            UpdateAgent.instance(target).setUpdateEvent(this);
            if (target.isStartCheckUpdate()) {
                boolean isMatch = matchUpdate(target);
                LogTool.i(this, "matchUpdate: " + isMatch);
                if (isMatch) {
                    UpdateAgent.instance().checkUpdate();
                    return;
                }
            }
        }
        start();
    }

    public static boolean matchUpdate(Target target) {
        UpdateAgent.Mode mode = UpdateAgent.Mode.parse(target.getUpdateMode());
        return (mode == UpdateAgent.Mode.EVERY_TIME) || UpdateAgent.Mode.match(mode, target.getLastTime());
    }

    public static void checkUpdate() {
        UpdateAgent.instance().checkUpdate();
    }

    protected void onStartUpdate() {

    }

    protected void onStart() {
        LogTool.i(this, "onStart");
    }

    protected void start() {
        onStart();
    }

    protected void onLatest() {
        LogTool.i(this, "onLatest");
    }

    protected void onCancel() {
        LogTool.i(this, "onCancel");
    }

    @Override
    public void onLatestUpdate() {
        SwingUtilities.invokeLater(this::onLatest);
    }

    @Override
    public void onCancelUpdate() {
        SwingUtilities.invokeLater(this::onCancel);
    }

    @Override
    public boolean onConfirmUpdate(UpdatePackage updatePackage) {
        boolean isUpdate = (JOptionPane.showConfirmDialog(null,
                String.format("发现新版本v%s啦！你确定要更新吗？", updatePackage.getVersion()),
                "更新提示",
                JOptionPane.YES_NO_OPTION) == 0);
        return isUpdate;
    }

    @Override
    public void onPrepareUpdate(UpdatePackage updatePackage) {
        SwingUtilities.invokeLater(() -> {
            onStartUpdate();
            updateStatusPanel = new UpdateStatusPanel();
            updateStatusPanel.setMaxUpdateValue(updatePackage.getItems().size());
            updateStatusPanel.setUpdateValue(0);
            updateStatusPanel.setClickText("取消");
            updateStatusPanel.setClickListener(e -> {
                if (isFinishedUpdate) {
                    dialog.setVisible(false);
                    JOptionPane.showMessageDialog(null, "更新成功");
                    start();
                    //                    System.exit(0);
                } else {
//                                JOptionPane.showMessageDialog(null, isFinishedUpdate);
                    int option = JOptionPane.showConfirmDialog(null,
                            "你确定要取消更新吗？",
                            "提示",
                            JOptionPane.YES_NO_OPTION);
                    if (option == 0) {
                        UpdateAgent.instance().revokeUpdate();
                    }
                }
            });
            dialog = createDialog(null, updateStatusPanel.getWidth(), updateStatusPanel.getHeight(), "更新进度", updateStatusPanel);
            dialog.setVisible(true);
        });
    }

    @Override
    public void onUpdateItem(UpdateAgent.Action action, UpdateItem updateItem, int total, int index) {
        SwingUtilities.invokeLater(() -> {
            int value = index + 1;
            updateStatusPanel.setTitleText(String.format("正在处理 (%d/%d):", value, total));
            updateStatusPanel.setStatusText(String.format("%s %s...", action.getName(), updateItem.getName()));
            updateStatusPanel.setUpdateValue(value);
            LogTool.i(this, "update item: " + JsonTool.toJson(updateItem));
        });
    }

    @Override
    public void onPrepareRevokeUpdate(ArrayList<Backup> backupList) {
        SwingUtilities.invokeLater(() -> updateStatusPanel.setClickEnable(false));
    }

    @Override
    public void onRevokeUpdateItem(UpdateAgent.Action action, UpdateItem updateItem, int total, int index) {
        SwingUtilities.invokeLater(() -> {
            int value = index - 1;
            updateStatusPanel.setTitleText(String.format("正在撤销 (%d/%d):", value, total));
            updateStatusPanel.setStatusText(String.format("取消%s %s...", action.getName(), updateItem.getName()));
            updateStatusPanel.setUpdateValue(value);
            LogTool.i(this, "revoke update item: " + JsonTool.toJson(updateItem));
        });
    }

    @Override
    public void onFinishedUpdate(Target target) {
        SwingUtilities.invokeLater(() -> {
            updateStatusPanel.setClickEnable(true);
            updateStatusPanel.setClickText("完成");
            isFinishedUpdate = true;
        });
    }

    protected void onUpdateError(String error) {
        LogTool.i(this, "onError");
        JOptionPane.showMessageDialog(null, error);
    }

    @Override
    public void onCheckUpdateError(String error) {
//        LogTool.i(this, "update error: " + error);
        SwingUtilities.invokeLater(() -> onUpdateError(error));
    }

    private JDialog createDialog(JFrame window, int w, int h, String text, JPanel content) {
        JDialog jd = new JDialog(window, text, false);
        jd.setSize(w, h);
        jd.setContentPane(content);
        Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = (int) screensize.getWidth();
        int height = (int) screensize.getHeight();
        jd.setLocation((width - jd.getWidth()) / 2, (height - jd.getHeight()) / 2);
        jd.setResizable(false);
        jd.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        return jd;
    }

//    private Target obtainTestTarget() {
//        Target target = new Target();
//        target.setName("easyconfigir");
//        target.setUrl("http://127.0.0.1/config/update_sample.json");
//        target.setCode(0);
//        String up = "D:\\OO\\other\\http\\config\\test\\update";
//        String bk = "D:\\OO\\other\\http\\config\\test\\backup";
//        //            String userDir = System.getProperty("user.dir");
//        String path = "D:\\OO\\other\\http\\config\\test\\app";
//        File backupDir = new File(bk);
//        File updateDir = new File(up);
//        File updateConfig = new File(up + File.separator + "config.json");
//        target.setPath(path);
//        target.setUpdateDir(updateDir);
//        target.setUpdateConfig(updateConfig);
//        target.setBackupDir(backupDir);
////        String command = String.format("update.exe %s %s", updateDir.getAbsolutePath(), updateConfig.getAbsolutePath());
////        String path = "D:\\OO\\project\\java\\EasyConfigIR\\update\\build\\install\\update";
////        File userDir = new File(path);
////        target.setUpdateCommand(userDir + File.separator + command);
//        return target;
//    }

//    public static void main(String[] args) {
//        WebLookAndFeel.install();
//        App.run();
//
////        UpdateStatusPanel updateStatusPanel = new UpdateStatusPanel();
////        App.createDialog(null, updateStatusPanel.getWidth(), updateStatusPanel.getHeight(), "更新进度",
////                updateStatusPanel).setVisible(true);
//    }

}