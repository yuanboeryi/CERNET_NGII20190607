package king.easyconfigir.update;

public class R {

}
