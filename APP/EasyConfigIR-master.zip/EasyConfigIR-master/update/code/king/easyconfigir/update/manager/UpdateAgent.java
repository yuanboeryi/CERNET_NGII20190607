package king.easyconfigir.update.manager;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import king.easyconfigir.update.model.Backup;
import king.easyconfigir.update.model.Target;
import king.easyconfigir.update.model.UpdateItem;
import king.easyconfigir.update.model.UpdatePackage;
import king.easyconfigir.update.tool.DownloadTool;
import king.easyconfigir.update.tool.FileTool;
import king.easyconfigir.update.tool.JsonTool;
import king.easyconfigir.update.tool.LogTool;
import king.easyconfigir.update.tool.TextTool;

public class UpdateAgent {
    private Target target;
    private static UpdateAgent instance;

    private UpdateEvent updateEvent;

    private ArrayList<Backup> backupList;

    private boolean isRevokeUpdate = false;

    public interface UpdateEvent {
        boolean onConfirmUpdate(UpdatePackage updatePackage);

        void onLatestUpdate();

        void onCancelUpdate();

        void onPrepareUpdate(UpdatePackage updatePackage);

        void onUpdateItem(Action action, UpdateItem updateItem, int total, int index);

        void onPrepareRevokeUpdate(ArrayList<Backup> backupList);

        void onRevokeUpdateItem(Action action, UpdateItem updateItem, int total, int index);

        void onFinishedUpdate(Target target);

        void onCheckUpdateError(String error);
    }

    public UpdateAgent setUpdateEvent(UpdateEvent updateEvent) {
        this.updateEvent = updateEvent;
        return this;
    }

    private UpdateAgent(Target target) {
        this.target = target;
        this.backupList = new ArrayList<>();
    }

    public void checkUpdate() {
        if (target != null) {
            new Thread(this::check).start();
        }
    }

    private void check() {
        String errorMessage = null;
        String configUrl = target.getUrl();
        File backupDir = new File(target.getBackup());
        File updateDir = new File(target.getUpdate());
        File updateConfig = new File(target.getUpdateConfig());
        LogTool.i(this, "backupDir: " + backupDir.getAbsolutePath());
        LogTool.i(this, "updateDir: " + updateDir.getAbsolutePath());
        LogTool.i(this, "updateConfig: " + updateConfig.getAbsolutePath());
        if (!TextTool.checkNull(configUrl)) {    
            try {
                FileTool.copyURLToFile(new URL(configUrl), updateConfig);
                UpdatePackage updatePackage = JsonTool.fromJson(updateConfig, UpdatePackage.class);
                if (updatePackage != null) {
                    if (updatePackage.isForceUpdate()) {
                        updateByPackage(updatePackage, backupDir);
                    } else {
                        if (updatePackage.getCode() > target.getCode()) {
                            if (updateEvent != null) {
                                if (updateEvent.onConfirmUpdate(updatePackage)) {
                                    updateByPackage(updatePackage, backupDir);
                                } else {
                                    FileTool.remove(updateDir);
                                    updateEvent.onCancelUpdate();
                                }
                            }
                        } else {
                            FileTool.remove(updateDir);
                            if (updateEvent != null) {
                                updateEvent.onLatestUpdate();
                            }
                        }
                    }
                } else {
                    errorMessage = "updatePackage is invalid";
                }
            } catch (IOException e) {
            	e.printStackTrace();
                errorMessage = e.getMessage();
            }
        } else {
            errorMessage = "update config url is null";
        }

        if (updateEvent != null && errorMessage != null) {
            updateEvent.onCheckUpdateError(errorMessage);
        }
    }

    public void revokeUpdate() {
        this.isRevokeUpdate = true;
    }

    private void updateByPackage(UpdatePackage updatePackage, File backupDir) {
        if (updateEvent != null) {
            updateEvent.onPrepareUpdate(updatePackage);
        }
        int size = updatePackage.getItems().size();
        int index = 0;
        for (UpdateItem item : updatePackage.getItems()) {
            Action action;
            if (isRevokeUpdate) {
//                size = backupList.size();
                if (updateEvent != null) {
                    updateEvent.onPrepareRevokeUpdate(backupList);
                }
                for (Backup backup : backupList) {
                    if (updateEvent != null) {
                        updateEvent.onRevokeUpdateItem(backup.getAction(), backup.getUpdateItem(), size, index);
                    }
                    action = backup.getAction();
                    switch (action) {
                        case REMOVE:
                        case REPLACE:
                            FileTool.copy(backup.getOld(), backup.getNow());
                            break;
                        case ADD:
                            FileTool.remove(backup.getNow());
                            break;
                        default:
                            break;
                    }

                    index--;

                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
                break;
            }

            LogTool.i(this, "item: " + item);

            if (item.getAction() instanceof String) {
                action = Action.parseActionByValue((String) item.getAction());
            } else if (item.getAction() instanceof Double) {
                action = Action.parseAction((Double) item.getAction());
            } else {
                action = Action.SKIP;
            }

            if (updateEvent != null) {
                updateEvent.onUpdateItem(action, item, size, index);
            }

            if (action != Action.SKIP && action != Action.NONE) {
                String command = null;
                File file = null;
                File backupFile = null;
                if (action == Action.COMMAND) {
                    command = parseCommand(item);
                } else if (action == Action.SCRIPT) {
                    command = parseCommand(fetchFile(item));
                } else {
                    file = parseFile(item);
                    if (action != Action.ADD) {
                        backupFile = genBackupFile(backupDir, index, item);
                    }
                    backup(action, item, backupFile, file);
                }
                if (file != null || command != null) {
                    switch (action) {
                        case REPLACE:
                            FileTool.copy(file, backupFile);
                            FileTool.replace(item.getUrl(), file);
                            break;
                        case REMOVE:
                            FileTool.copy(file, backupFile);
                            FileTool.remove(file);
                            break;
                        case ADD:
                            FileTool.add(item.getUrl(), file);
                            break;
                        case COMMAND:
                            runCommand(command);
                            break;
                        case SCRIPT:
                            runCommandOnThread(command);
                            break;
                        default:
                            LogTool.i(this, action.getName() + " action: " + item.getAction());
                            break;
                    }
                }
            }

            index++;

            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        updateAppConfig(updatePackage, target);

        if (updateEvent != null) {
            updateEvent.onFinishedUpdate(target);
        }

        cleanup();
    }

    private void updateAppConfig(UpdatePackage updatePackage, Target target) {
        if (target != null) {
            try {
                File config = new File(target.getAppConfig());
                if (!config.exists()) {
                    config.createNewFile();
                }
                FileWriter fileWriter = new FileWriter(config);

                target.setLastTime(System.currentTimeMillis());
                target.setVersion(updatePackage.getVersion());
                target.setCode(updatePackage.getCode());

                fileWriter.write(JsonTool.toJson(target));
                fileWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String parseCommand(UpdateItem item) {
        String command = null;
        if (item != null) {
            command = TextTool.matchCommand(item.getLocation());
            LogTool.i(this, "parse command: " + command);
        }
        return command;
    }

    private String parseCommand(File file) {
        String command = null;
        if (file.exists()) {
            command = file.getAbsolutePath();
            LogTool.i(this, "parse command: " + command);
        }
        return command;
    }

    private File parseFile(UpdateItem item) {
        if (item != null) {
            String location = item.getLocation();
            String name = item.getName();
            if (!(TextTool.checkNull(location) || TextTool.checkNull(name))) {
                // 解释路径 target.getPath()
                String path = target.getPath() + File.separator + location.replace('/', File.separatorChar) + File.separator + name;
                LogTool.i(this, "parse path: " + path);
                return new File(path);
            }
        }
        return null;
    }

    private File fetchFile(UpdateItem item) {
        File file = null;
        if (item != null) {
            String url = item.getUrl();
            if (url != null) {
                file = new File(target.getUpdate(), item.getName());
                DownloadTool.downloadByApacheCommonIO(url, file.getParent(), file.getName());
            }
        }
        return file;
    }

    private File genBackupFile(File backupDir, int index, UpdateItem item) {
        return new File(backupDir.getAbsolutePath() + File.separator + index + "_" + item.getName());
    }

    private void backup(Action action, UpdateItem item, File old, File now) {
        backupList.add(new Backup(action, item, old, now));
    }

    private void cleanup() {
        FileTool.remove(new File(target.getBackup()));
        FileTool.remove(new File(target.getUpdate()));
    }

    private void runCommandOnThread(String command) {
        if (command != null) {
            new Thread(() -> runCommand(command)).start();
        }
    }

    private void runCommand(String command) {
        if (command != null) {
            try {
                LogTool.i(this, "run command: " + command);
                Runtime.getRuntime().exec(command);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            LogTool.i(this, "command is null");
        }
    }

    public Target getTarget() {
        return target;
    }

    public void setTarget(Target target) {
        this.target = target;
    }

    public static UpdateAgent instance() {
        return instance(null);
    }

    public static UpdateAgent instance(Target target) {
        if (instance == null) {
            instance = new UpdateAgent(target);
        }
        return instance;
    }

    public enum Action {
        REPLACE("替换", "replace"),
        REMOVE("清除", "remove"),
        ADD("添加", "add"),
        COMMAND("执行", "run"),
        SKIP("跳过", "skip"),
        SCRIPT("运行", "script"),
        NONE("未知动作", "unknown");

        private String name;
        private String value;

        Action(String name, String value) {
            this.name = name;
            this.value = value;
        }

        public static Action parseActionByName(String flag) {
            Action action = NONE;
            if (flag != null) {
                if (REPLACE.getName().equals(flag)) {
                    action = REPLACE;
                } else if (REMOVE.getName().equals(flag)) {
                    action = REMOVE;
                } else if (ADD.getName().equals(flag)) {
                    action = ADD;
                } else if (COMMAND.getName().equals(flag)) {
                    action = COMMAND;
                } else if (SKIP.getName().equals(flag)) {
                    action = SKIP;
                } else if (SCRIPT.getName().equals(flag)) {
                    action = SCRIPT;
                }
            }
            return action;
        }

        public static Action parseActionByValue(String flag) {
            Action action = NONE;
            if (flag != null) {
                if (REPLACE.getValue().equals(flag)) {
                    action = REPLACE;
                } else if (REMOVE.getValue().equals(flag)) {
                    action = REMOVE;
                } else if (ADD.getValue().equals(flag)) {
                    action = ADD;
                } else if (COMMAND.getValue().equals(flag)) {
                    action = COMMAND;
                } else if (SKIP.getValue().equals(flag)) {
                    action = SKIP;
                } else if (SCRIPT.getValue().equals(flag)) {
                    action = SCRIPT;
                }
            }
            return action;
        }

        public static Action parseAction(double flag) {
            Action action = NONE;
            int f = (int) flag;
            switch (f) {
                case 0:
                    action = REPLACE;
                    break;
                case 1:
                    action = REMOVE;
                    break;
                case 2:
                    action = ADD;
                    break;
                case 3:
                    action = COMMAND;
                    break;
                case 4:
                    action = SKIP;
                    break;
                case 5:
                    action = SCRIPT;
                    break;
                default:
                    break;
            }
            return action;
        }

        public String getName() {
            return name;
        }

        public String getValue() {
            return value;
        }
    }

    public enum Mode {
        EVERY_TIME("每次", 0, 0),
        EVERY_DAY("每天", 1, 24),
        EVERY_WEEK("每周", 2, 168),
        EVERY_MONTH("每月", 3, 720),
        NONE("未知模式", 4, -1);

        private String name;
        private int flag;
        private long value;

        Mode(String name, int flag, long value) {
            this.name = name;
            this.flag = flag;
            this.value = value;
        }

        public static Mode parse(int flag) {
            Mode mode = NONE;
            switch (flag) {
                case 0:
                    mode = EVERY_TIME;
                    break;
                case 1:
                    mode = EVERY_DAY;
                    break;
                case 2:
                    mode = EVERY_WEEK;
                    break;
                case 3:
                    mode = EVERY_MONTH;
                    break;
                default:
                    break;
            }
            return mode;
        }

        public static boolean match(Mode mode, long time) {
            if (mode != null && mode != NONE) {
                long v = System.currentTimeMillis() - time;
                LogTool.i("Mode", "mode: " + JsonTool.toJson(mode));
                LogTool.i("Mode", "v: " + v);
                if (v > 0) {
                    return ((v / 1000 / 60 / 60) >= mode.getValue());
                } else {
                    return true;
                }
            }
            return false;
        }

        public int getFlag() {
            return flag;
        }

        public String getName() {
            return name;
        }

        public long getValue() {
            return value;
        }
    }

}
