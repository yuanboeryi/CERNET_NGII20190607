package king.easyconfigir.update.model;

import java.io.File;

import king.easyconfigir.update.manager.UpdateAgent;

public class Backup {
    private UpdateAgent.Action action;
    private UpdateItem updateItem;
    private File old;
    private File now;

    public Backup(UpdateAgent.Action action, UpdateItem updateItem, File old, File now) {
        this.action = action;
        this.updateItem = updateItem;
        this.old = old;
        this.now = now;
    }

    public UpdateAgent.Action getAction() {
        return action;
    }

    public void setAction(UpdateAgent.Action action) {
        this.action = action;
    }

    public UpdateItem getUpdateItem() {
        return updateItem;
    }

    public void setUpdateItem(UpdateItem updateItem) {
        this.updateItem = updateItem;
    }

    public File getOld() {
        return old;
    }

    public void setOld(File old) {
        this.old = old;
    }

    public File getNow() {
        return now;
    }

    public void setNow(File now) {
        this.now = now;
    }
}
