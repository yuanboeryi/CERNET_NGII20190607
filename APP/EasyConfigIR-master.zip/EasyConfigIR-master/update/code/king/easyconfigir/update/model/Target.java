package king.easyconfigir.update.model;

public class Target {
    private String name;
    private String url;
    private long code;
    private String path;
    private String update;
    private String backup;
    private String updateConfig;
    private String updateCommand;
    private String appConfig;
    private String version;
    private long lastTime;
    private int updateMode;
    private boolean isStartCheckUpdate;

    public Target() {

    }

    public boolean isStartCheckUpdate() {
        return isStartCheckUpdate;
    }

    public void setStartCheckUpdate(boolean startCheckUpdate) {
        isStartCheckUpdate = startCheckUpdate;
    }

    public long getLastTime() {
        return lastTime;
    }

    public void setLastTime(long lastTime) {
        this.lastTime = lastTime;
    }

    public int getUpdateMode() {
        return updateMode;
    }

    public void setUpdateMode(int updateMode) {
        this.updateMode = updateMode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public long getCode() {
        return code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getUpdate() {
        return update;
    }

    public void setUpdate(String update) {
        this.update = update;
    }

    public String getBackup() {
        return backup;
    }

    public void setBackup(String backup) {
        this.backup = backup;
    }

    public String getUpdateConfig() {
        return updateConfig;
    }

    public void setUpdateConfig(String updateConfig) {
        this.updateConfig = updateConfig;
    }

    public String getUpdateCommand() {
        return updateCommand;
    }

    public void setUpdateCommand(String updateCommand) {
        this.updateCommand = updateCommand;
    }

    public String getAppConfig() {
        return appConfig;
    }

    public void setAppConfig(String appConfig) {
        this.appConfig = appConfig;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
