package king.easyconfigir.update.model;

import java.util.ArrayList;

public class UpdatePackage {
    private String name;
    private String version;
    private long code;
    private String publisher;
    private String date;
    private String details;
    private boolean isForceUpdate;
    private int mode;
    private String command;

    private ArrayList<UpdateItem> items;

    public UpdatePackage() {

    }

    public UpdatePackage(String name, String version, long code, String publisher, String date, String details, boolean isForceUpdate, int mode, String command, ArrayList<UpdateItem> items) {
        this.name = name;
        this.version = version;
        this.code = code;
        this.publisher = publisher;
        this.date = date;
        this.details = details;
        this.isForceUpdate = isForceUpdate;
        this.mode = mode;
        this.command = command;
        this.items = items;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public long getCode() {
        return code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public boolean isForceUpdate() {
        return isForceUpdate;
    }

    public void setForceUpdate(boolean forceUpdate) {
        isForceUpdate = forceUpdate;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public ArrayList<UpdateItem> getItems() {
        return items;
    }

    public void setItems(ArrayList<UpdateItem> items) {
        this.items = items;
    }

}
