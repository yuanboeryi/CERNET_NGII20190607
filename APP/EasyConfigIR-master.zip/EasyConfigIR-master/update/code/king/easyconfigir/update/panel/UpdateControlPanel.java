package king.easyconfigir.update.panel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import king.easyconfigir.update.manager.UpdateAgent;
import king.easyconfigir.update.model.Target;
import king.easyconfigir.update.tool.JsonTool;

public class UpdateControlPanel extends JPanel implements ActionListener {

    private String options[] = {
            "每次", "每天", "每周", "每月", "从不"
    };

    private JLabel jl;
    private JComboBox jcb;

    private JLabel jlh;
    private JCheckBox jhb;

    private JButton save;

    private Target target;

    public UpdateControlPanel() {
        this(380, 100);
    }

    public UpdateControlPanel(int width, int height) {
        initView(width, height, 60, 60, 100, 30, 60, 30, 30, 10);
    }

    public void initView(int width, int height, int w0, int w1, int w2, int w3, int w4, int h0, int h1, int i0) {
        this.setLayout(null);
        this.setSize(width, height);

        int lpad = (width - w0 - w1 - w2 - w3 - w4 - i0) / 2;
        int lhei = 16;

        jl = new JLabel("更新频率", JLabel.LEFT);
        jl.setBounds(lpad, lhei, w0, h0);
        this.add(jl);

        jcb = new JComboBox(options);
        lpad += jl.getWidth();
        jcb.setBounds(lpad, lhei, w1, h0);
        this.add(jcb);

        jlh = new JLabel("启动时检查更新: ", JLabel.LEFT);
        lpad += jcb.getWidth() + i0;
        jlh.setBounds(lpad, lhei, w2, h0);
        this.add(jlh);

        jhb = new JCheckBox();
        lpad += jlh.getWidth();
        jhb.setBounds(lpad, lhei, w3, w3);
        this.add(jhb);

        save = new JButton("保存");
        lpad += jhb.getWidth();
        save.setBounds(lpad, lhei, w4, h1);
        this.add(save);

        save.setFocusable(false);
        jcb.setFocusable(false);

        jhb.addActionListener(this);
        save.addActionListener(this);
    }

    public Target getTarget() {
        return target;
    }

    public void setTarget(Target target) {
        this.target = target;
        updateData();
    }

    private void updateData() {
        if (target != null) {
            int value = UpdateAgent.Mode.parse(target.getUpdateMode()).getFlag();
            jcb.setSelectedIndex(value);
            boolean isStartCheckUdpate = target.isStartCheckUpdate();
            jhb.setSelected(isStartCheckUdpate);
            jcb.setEnabled(jhb.isSelected());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == jhb) {
            jcb.setEnabled(jhb.isSelected());
        } else if (e.getSource() == save) {
            if (target != null) {
                target.setUpdateMode(jcb.getSelectedIndex());
                target.setStartCheckUpdate(jhb.isSelected());
                updateAppConfig(target);
                JOptionPane.showMessageDialog(null, "设置成功! ");
            } else {
                JOptionPane.showMessageDialog(null, "应用程序未初始化配置");
            }
        }
    }

    private void updateAppConfig(Target target) {
        if (target != null) {
            try {
                File config = new File(target.getAppConfig());
                if (!config.exists()) {
                    config.createNewFile();
                }
                FileWriter fileWriter = new FileWriter(config);
                fileWriter.write(JsonTool.toJson(target));
                fileWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
