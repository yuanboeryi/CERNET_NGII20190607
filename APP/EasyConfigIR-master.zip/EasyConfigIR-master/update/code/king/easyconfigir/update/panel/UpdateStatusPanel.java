package king.easyconfigir.update.panel;

import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

public class UpdateStatusPanel extends JPanel {

    private JLabel jlTitle;
    private JLabel jlStatus;
    private JProgressBar jProgressBar;
    private JButton action;

    public UpdateStatusPanel() {
        this(400, 165, 90, 35, 380, 24, 60, 28);
    }

    public UpdateStatusPanel(int width, int height, int textW, int textH, int barW, int barH, int btW, int btH) {
        this.setLayout(null);
        this.setSize(width, height);
        int lpad = 4;
        int lhei = 16;
        jlTitle = new JLabel("正在处理 (3/5):", JLabel.LEFT);
        jlTitle.setFont(new Font("微软雅黑", Font.PLAIN, 11));
        jlTitle.setBounds(lpad, lhei, textW, textH);
        this.add(jlTitle);

        lpad += jlTitle.getWidth();

        jlStatus = new JLabel("删除ui.jar...", JLabel.LEFT);
        jlStatus.setFont(new Font("微软雅黑", Font.PLAIN, 11));
        jlStatus.setBounds(lpad, lhei, width - lpad - 4, textH);
        this.add(jlStatus);

        lpad = 4;

        jProgressBar = new JProgressBar();
        lhei += jlStatus.getHeight() + 4;
        jProgressBar.setBounds((width - barW - 2 * lpad) / 2, lhei, barW, barH);
        jProgressBar.setValue(50);
        this.add(jProgressBar);

        action = new JButton("取消");
        lpad = width - btW - 4 * lpad;
        lhei += jProgressBar.getHeight() + 10;
        action.setBounds(lpad, lhei, btW, btH);
        action.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        this.add(action);
    }

    public void setMaxUpdateValue(int max) {
        jProgressBar.setMaximum(max);
    }

    public void setUpdateValue(int value) {
        jProgressBar.setValue(value);
    }

    public void setTitleText(String text) {
        jlTitle.setText(text);
    }

    public void setStatusText(String text) {
        jlStatus.setText(text);
    }

    public void setClickText(String text) {
        action.setText(text);
    }

    public void setClickEnable(boolean enable) {
        action.setEnabled(enable);
    }

    public void setClickListener(ActionListener l) {
        action.addActionListener(l);
    }
}
