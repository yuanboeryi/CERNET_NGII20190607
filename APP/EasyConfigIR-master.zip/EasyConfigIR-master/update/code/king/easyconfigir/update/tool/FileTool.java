package king.easyconfigir.update.tool;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;

public class FileTool extends FileUtils {

    public static void remove(File file) {
        if (file != null) {
            if (file.exists()) {
                try {
                    forceDelete(file);
                    LogTool.i("FileTool", "remove file: " + file.getAbsolutePath());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                LogTool.i("FileTool", "remove -> not exist! " + file);
            }
        }
    }

    public static void replace(String url, File file) {
        if (file != null) {
            DownloadTool.downloadByApacheCommonIO(url, file.getParent(), file.getName());
            LogTool.i("FileTool", "replace file: " + file.getAbsolutePath());
        }
    }

    public static void add(String url, File file) {
        if (file != null) {
            DownloadTool.downloadByApacheCommonIO(url, file.getParent(), file.getName());
            LogTool.i("FileTool", "add file: " + file.getAbsolutePath());
        }
    }

    public static void copy(File src, File dst) {
        if (src != null && dst != null) {
            if (src.exists()) {
                try {
                    FileTool.copyFile(src, dst);
                    LogTool.i("FileTool", "copy " + src + " " + dst);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                LogTool.i("FileTool", "copy -> not exist! " + src);
            }
        }
    }

}
