package king.easyconfigir.update.tool;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

public class JsonTool {
    private final static Gson gson = new Gson();

    public static <T> T fromJson(String jsonRes, Class<T> mClass) {
        return gson.fromJson(jsonRes, mClass);
    }

    public static <T> T fromJson(File file, Class<T> mClass) {
        if (file != null && file.exists() && file.isFile()) {
            try {
                InputStream is = new FileInputStream(file);
                T t = fromJson(new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8)), mClass);
                is.close();
                return t;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public static <T> T fromJson(Reader reader, Class<T> mClass) {
        return gson.fromJson(reader, mClass);
    }

    public static String toJson(Object src) {
        return gson.toJson(src);
    }

}
