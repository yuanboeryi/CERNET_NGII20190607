package king.easyconfigir.update.tool;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TextTool {

    public static boolean checkNull(String value) {
        return value == null || value.trim().equals("");
    }

    public static String matchCommand(String info) {
        String regex = "^#(.*)$";
        Pattern r = Pattern.compile(regex);
        Matcher m = r.matcher(info);
        if (m.find()) {
            return m.group(1);
        } else {
            return null;
        }
    }
}
