var id='',idDe='';
var order='',areaid='',fenbuid='',ywbid='',stationid='',buildingid='',devicetype='',isok='',deviceid='';
$(document).ready(function () {

    layui.use(['table','layer'], function(){
        var layer = layui.layer;
        var table = layui.table;
        var $ = layui.jquery
        ,element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块
        
		
        // 温升告警记录
        $("#alarmTemp").on('click',function(){
          var url="alarm_temp.html";
          Util.popFullScreen3(100,100,url);
        });

        //监听工具条
        table.on('tool(test)', function(obj){
          var data = obj.data;
          
          //查看报告
          if(obj.event === 'report'){
            var id=obj.data.id;
            var url = "alarm_report.html?id="+id;
            Util.popFullScreen2('',1200,900,url);
          } else if(obj.event === 'del'){
            
              id=obj.data.id;
              layer.confirm('确认删除行', {
                    title: false,
                    closeBtn: 0, //不显示关闭按钮
                    btn: ['确认', '取消'],
                    area: ['478px', '172px'],
              },function(index){
                    $.ajax({
                          type:'POST',
                          url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/DeleteAlarm',
                          dataType:'JSON',
                          data:{idlist:id},
                          success:function(data){
                            layer.msg(data[0].msg);
                            layer.close(index);
                            table.reload('test');
                          },
                          error:function(err){
                              console.log(err)
                          }
          
                    });
            },function (index) {//cancel回调
                layer.close(index);
            });
          }else if(obj.event === 'setTem'){
              idDe=obj.data.deviceid;
              $(".temSet_tanchu").show();        
          }
		  else if(obj.event === 'realVideo'){
			  // console.log(obj.data);
			  
			  //跳转到实时视频页面
			  // var deviceid=obj.data.deviceid,machineid=obj.data.machineid;
			  // var url="tem_videos.html?machineid="+machineid+'&deviceid='+deviceid;
			  // Util.popFullScreen3(100,100,url);
			  
			  //跳转到测温查看页面
			  var machineid = obj.data.machineid;
			  var deviceid = obj.data.deviceid;
			  var url="tem_mentDetail.html?deviceid="+deviceid+"&&machineid="+machineid;
			  Util.popFullScreen3(100,100,url);
		  }
        });

        //事件告警分析的事件
        var active = {
          
          batchdel: function(){
              var checkStatus = table.checkStatus('test')
              ,checkData = checkStatus.data; //得到选中的数据
              
              var obj = {};
              for(var i = 0; i < checkData.length; i++){
                  obj[i]= checkData[i].id;
              }
              var id=Object.values(obj).toString();
              if(checkData.length === 0){
                // return layer.msg('请选择要删除的数据');
                return alert('请选择要删除的数据');
              }
              layer.confirm('确认删除?', {
                  title: false,
                  closeBtn: 0, //不显示关闭按钮
                  btn: ['确认', '取消'],
                  area: ['478px', '172px'],
                },function(index){
                      $.ajax({
                            type:'POST',
                            url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/DeleteAlarm',
                            dataType:'JSON',
                            data:{
                              idlist:id
                            },
                            success:function(data){
                              layer.msg(data[0].msg,{
                                offset: '15px'
                                ,time: 500
                              });
                              layer.close(index);
                              table.reload('test');
                            },
                            error:function(err){
                                console.log(err)
                            }
            
                      });
              },function (index) {//cancel回调
                  layer.close(index);
              });
          }
          ,getCheckData: function(){
            // 确认所选告警
            var checkStatus = table.checkStatus('test')
            ,checkData = checkStatus.data; //得到选中的数据
            var obj = {};
            for(var i = 0; i < checkData.length; i++){
                obj[i]= checkData[i].id;
            }
            id=Object.values(obj).toString();
            if(checkData.length === 0){
              return layer.msg('请选择的数据');
            };
            if(checkData.length === 1){
                // 单个确认告警确定
                $(".oneAlarem_tanchu").css("display","block");
            }else{
                $(".MoreAlarem_tanchu").css("display","block");
            }
          },
          getCheckAll: function(){
            id="all";
            
            $(".MoreAlarem_tanchu").css("display","block");
          }
        };
        $('.layui-btn.btn-top').on('click', function(){
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });

        
        // 单个确认告警确定
        $(".oneAlarem_tanchu .btn0").click(function(){
          var fuhe=$("#edit_oneAlarem1").val();
          var human=$("#edit_oneAlarem2").val();
          var time=$("#edit_oneAlarem3").val();
          edit_oneAlarem(id,fuhe,human,time);
          $(".oneAlarem_tanchu").css("display","none");
        });
        // 单个确认告警取消
        $(".oneAlarem_tanchu .btn1").click(function(){
            $(".oneAlarem_tanchu").css("display","none");
        });
        $(".MoreAlarem_tanchu .btn0").click(function(){
            var human=$("#edit_MoreAlarem1").val();
            var time=$("#edit_MoreAlarem2").val();
            edit_MoreAlarem(id,human,time)
            $(".MoreAlarem_tanchu").css("display","none");
        });
        // 批量确认告警取消
        $(".MoreAlarem_tanchu .btn1").click(function(){
          $(".MoreAlarem_tanchu").css("display","none");
        });



        // 修改告警温度确定
        $(".temSet_tanchu .btn0").click(function(){
          var tem1=$("#edit_Tem1").val();
          var tem2=$("#edit_Tem2").val();
          edit_SetTemAlarem(idDe,tem1,tem2);
          $(".temSet_tanchu").show(); 
        });
        // 修改告警温度取消
        $(".temSet_tanchu .btn1").click(function(){
          $(".temSet_tanchu").hide(); 
        });
        
    });




});


// 饼图 变电站告警类型统计 
function alarmInfoTopModule2(repair1,repair2,repair3){
  var dom = document.getElementById("alarmInfoTopModule2");
  var total=parseInt(repair1)+parseInt(repair2)+parseInt(repair3);
  if(!dom){
      return;
  }else{
      var myChart=echarts.init(dom);
  
      option = {
          title: {
              text:total,
              subtext:'总计',
              x: '78',
              y: 'center',
              top:"28%",
              itemGap:0,
              textStyle: {
                  color: '#fff',
                  fontWeight:"normal",
              },
              subtextStyle:{
                  color: '#fff',
              }
          },
          tooltip: {
              trigger: 'item',
          },
          legend: {
              // orient: 'vertical',
              left: 'center',
              top: 'bottom',
              data: ["80°-100°","100°-120°","120°以上"],
              textStyle: {
                  color: '#f0f0f0',
                  fontSize: '10'
              },
              itemWidth: 6,
              itemHeight: 6,
              itemGap: 2,
          },
          color: ['#00FFD2','#FFFC9F','#FF5E5E'],
          series: [{
              name: '',
              type: 'pie',
              radius: ['55%', '65%'],
              center: ['50%', '50%'],
              label: {
                show: false
                // textStyle: {
                //     color: "#ffffff",
                //     fontSize: 14,
                // }
              },
              labelLine: {
                show: false
              },
              data: [
                  {
                      name: "80°-100°",
                      value: repair1
                  },
                  {
                      name: "100°-120°",
                      value: repair2
                  }, {
                      name: "120°以上",
                      value: repair3
                  }
              ]
          }]
      };
      if (option && typeof option === "object") {
          myChart.setOption(option, true);
      }
      
  }
};
