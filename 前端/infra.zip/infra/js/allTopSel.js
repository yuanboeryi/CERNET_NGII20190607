
var userid='';
$(function () {
        var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
        var datas = $.parseJSON(Arr);
        userid=datas.Userid;
        top_selAll(userid)
});
function top_selAll(userid){
        
        var area='',manageArea='',fenbu='',ywb='',bdz='',sbq='',machine='',
                deviceMachine='',ysd='',device='', device_area='',device_fenbu='',device_ywb='',device_bdz='';

        // var area='',manageArea='',fenbu='<span class="select">全部</span>',
        //         ywb='<span class="select">全部</span>',bdz='<span class="select">全部</span>',
        //         sbq='<span class="select">全部</span>',machine='<span class="select">全部</span>',
        //         deviceMachine='<span class="select">全部</span>',ysd='',device='', 
        //         device_area='<span class="select">全部</span>',
        //         device_fenbu='<span class="select">全部</span>',
        //         device_ywb='<span class="select">全部</span>',
        //         device_bdz='<span class="select">全部</span>';
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/x_getAllInforByUser',
                dataType:'JSON',  
                data:{
                        userid:userid,
                },
                success:function(data){
                        //工区
                        for(let item of data.Arealist){
                                area+=`<li class="table_active" data-areaid="${item[0]}" data-areaname="${item[1]}">${item[1]}</li>`;
                                // 设备管理
                                manageArea+=`<span class="select" data-areaname="${item[1]}">${item[1]}</span>`;
                        
                                device_area+=`<li class="li-item">
                                                <div class="item_left fl"><span>${item[1]}</span></div>
                                                <div class="item_right fr">
                                                <a class="area_event ac_edit edit1 layui-btn layui-btn-xs" data-areaid="${item[0]}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="area_event ac_del del1 layui-btn layui-btn-xs" data-areaid="${item[0]}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                </div>
                                        </li>`;
                        };
                        
                        //分部
                        for(let item of data.Fenbulist){
                                fenbu+=`<span data-fenbuid="${item[0]}" data-fenbuname="${item[1]}">${item[1]}</span>`;

                                // 设备管理
                                device_fenbu+=`<li class="li-item">
                                                <div class="item_left fl"><span>${item[1]}</span></div>
                                                <div class="item_right fr">
                                                <a class="fenbu_event ac_edit edit2 layui-btn layui-btn-xs" data-fenbuid="${item[0]}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="fenbu_event ac_del del2 layui-btn layui-btn-xs" data-fenbuid="${item[0]}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                </div>
                                        </li>`;
                        };
                        //运维班
                        for(let item of data.Ywblist){
                                ywb+=`<span data-ywbid="${item[0]}" data-ywbname="${item[1]}">${item[1]}</span>`;

                                // 设备管理
                                device_ywb+=`<li class="li-item">
                                                <div class="item_left fl"><span>${item[1]}</span></div>
                                                <div class="item_right fr">
                                                <a class="ywb_event ac_edit edit3 layui-btn layui-btn-xs" data-ywbid="${item[0]}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="ywb_event ac_del del3 layui-btn layui-btn-xs" data-ywbid="${item[0]}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                </div>
                                        </li>`;
                                
                        };
                        //变电站
                        for(let item of data.Stationlist){
                                
                                bdz+=`<span <span data-stationid="${item[0]} data-stationname="${item[1]}">${item[1]}</span>`;

                                // 设备管理
                                device_bdz+=`<li class="li-item">
                                                <div class="item_left fl"><span>${item[1]}</span></div>
                                                <div class="item_right fr">
                                                <a class="bdz_event ac_edit edit4 layui-btn layui-btn-xs" data-stationid="${item[0]}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="bdz_event ac_del del4 layui-btn layui-btn-xs" data-stationid="${item[0]}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                </div>
                                        </li>`;
                        };
                        //设备区
                        for(let item of data.Buildinglist){
                            sbq+=`<span data-buildingid="${item[0]}" data-buildingname="${item[1]}">${item[1]}</span>`;
                        };
                        //监视设备
                        for(let item of data.Machinelist){
                                machine+=`<span data-machineid="${item[0]}" data-machinename="${item[1]}">${item[1]}</span>`;
                        };

                        //预设点
                        for(let item of data.Machinelist){
                                deviceMachine+=`<li class="li-item">
                                        <div class="item_left fl"  data-machineid="${item[0]}"><span>${item[1]}</span></div><div class="item_right fr">
                                        <a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-machineid="${item[0]}" data-event="edit">
                                                <i class="layui-icon layui-icon-edit"></i>
                                        </a>
                                        <a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-machineid="${item[0]}" data-event="del">
                                                <i class="layui-icon layui-icon-delete"></i>
                                        </a>
                                        </div>
                                        </li>`;
                        };
                        //预设点
                        for(let item of data.Ysdlist){
                                ysd+=`<li class="li-item">
                                        <div class="item_left fl"  data-ysdid="${item[0]}"><span>${item[1]}</span></div><div class="item_right fr">
                                        <a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-ysdid="${item[0]}" data-event="edit">
                                                <i class="layui-icon layui-icon-edit"></i>
                                        </a>
                                        <a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-ysdid="${item[0]}" data-event="del">
                                                <i class="layui-icon layui-icon-delete"></i>
                                        </a>
                                        </div>
                                        </li>`;
                        };
                        //监测设备
                        for(let item of data.Devicelist){
                                device+=`<li class="li-item">
                                        <div class="item_left fl" data-deviceid="${item[0]}"><span>${item[1]}</span></div><div class="item_right fr">
                                        <a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-deviceid="${item[0]}" data-event="edit">
                                                <i class="layui-icon layui-icon-edit"></i>
                                        </a>
                                        <a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-deviceid="${item[0]}" data-event="del">
                                                <i class="layui-icon layui-icon-delete"></i>
                                        </a>
                                        </div>
                                        </li>`;
                        };
                        $("#tab").html(area);
                        $("#manageArea").html(manageArea);
                        $("#fenbuDD").html(fenbu);
                        $("#ywbDD").html(ywb);
                        $("#bdzDD").html(bdz);
                        $("#sbqDD").html(sbq);
                        $("#sbq_ulDD").html(sbq);
                        $("#jianshiDD").html(machine);
                        $("#status_shebeiDD").html(machine);

                        $("#jkq_ul").html(deviceMachine);
                        $("#ysd_ul").html(ysd);
                        $("#shebei_ul").html(device);


                        

                        // 设备管理点击
                        $("#gq_ul").html(device_area);
                        $("#fenbu_ul").html(device_fenbu);
                        $("#ywb_ul").html(device_ywb);
                        $("#bdz_ul").html(device_bdz);
                        $("#sbq_ul").html(sbq);
                },
                error:function(err){
                        console.log(err)
                }

        });
}