const IS_TEST=false; //测试
const Tool={
	log:function(tag,msg){
		console.log(new Date().toLocaleTimeString()+" "+tag+": "+msg);
	}
};
/**
 * 管理ｃａｍｅｒａ的所有状态
 * @constructor
 */
Camera=function(){
	const TAG="Camera";
	// 摄像机影子
	this.shadow={
	     who:this.who,
		 opclass:this.opclass,
		 station:this.station,
		 building:this.building,
		 code:this.code
	};
	this.setWho=function(who){
		this.shadow.who=this.who;
		this.who=who;
	};
	this.setOpclass=function (opclass) {
		this.shadow.opclass=this.opclass;
		this.opclass=opclass;
	};
	this.setStation=function(station){
		this.shadow.station=this.station;
		this.station=station;
	};
	this.setBuilding=function(building){
		this.shadow.building=this.building;
		this.building=building;
	};
	this.setCode=function (code) {
		this.shadow.code=this.code;
		this.code=code;
	};
	this.setDataStatus=function(dataStatus){
		this.dataStatus=dataStatus;
	};
	this.setPlaformPointList=function(plaformPointList){
		this.plaformPointList=plaformPointList;
		Tool.log(TAG,"called setPlatformPointList()");
	};
	this.pointIndex=-1;
	this.setOnFocusPoint=function(index){
		if(index<0){
			this.onFocusPoint=null;
			this.pointIndex=-1;
		}else{
			this.onFocusPoint=this.plaformPointList[index];
			this.pointIndex=index;
		}
	};
	this.toString=describe;
    function describe(){
	   return "["+this.who+","+this.opclass+","+this.station+","+this.building+","+this.code+","+this.dataStatus+"]";
    }
};

/**
 * 使用key-value的方式,统一处理请求到的字段
 * 
 * @constructor
 */
KeyParser=function(){
	const TAG="CameraKeyParser";
	this.keyTable={
		ID:0x00,
		RESULT:0x01,
		CONTENT:0x02,
		OP_NAME:0x03,
		ST_NAME:0x04,
		BU_NAME:0x05,
		SE_NAME:0x06,
		SE_CODE:0x07,
		RECORDS:0x08,
		ROWS:0x09
	};

	this.obtainVaule=function(data,key){
		var value=null;
		switch (key) {
			case this.keyTable.RESULT:
				value=data.result;
				break;
			case this.keyTable.CONTENT:
				value=data.content;
				break;
			case this.keyTable.ID:
				value=data.id;
				break;
			case this.keyTable.OP_NAME:
				value=data.op_name;
				break;
			case this.keyTable.ST_NAME:
				value=data.station_name;
				break;
			case this.keyTable.BU_NAME:
				value=data.building_name;
				break;
			case this.keyTable.SE_NAME:
				value=data.name;
				break;
			case this.keyTable.SE_CODE:
				value=data.sensor_code;
				break;
			case this.keyTable.RECORDS:
				value=data.records;
				break;
			case this.keyTable.ROWS:
				value=data.rows;
				break;
			default:
				Tool.log(TAG,"parse failed! data:"+data+" key:"+key);
				break;
		}
		return value;
	}
};

/**
 * 代理所有对摄像机的动作
 * 
 * @constructor
 */
CameraHelper=function(){
   const TAG="CameraHelper";
   const keyParser=new KeyParser();
   // 接口列表,统一请求格式
   const interfaceList={
		getOpClass:{
			url:"/getoperation",
			id:keyParser.keyTable.ID,
			body:keyParser.keyTable.OP_NAME,
			status:keyParser.keyTable.RESULT,
			result:keyParser.keyTable.CONTENT
		},
	    getStation:{
			url:"/building/getStation",
			id:keyParser.keyTable.ID,
			body:keyParser.keyTable.ST_NAME,
			status:keyParser.keyTable.RESULT,
			result:keyParser.keyTable.CONTENT
		},
	   getBuilding:{
			url:"/building/getBuilding",
		    id:keyParser.keyTable.ID,
		    body:keyParser.keyTable.BU_NAME,
		    status:keyParser.keyTable.RESULT,
		    result:keyParser.keyTable.CONTENT
	   },
	   getSensorCode:{
		   url:"/sensorlist/getSensorCode",
		   id:keyParser.keyTable.SE_CODE,
		   body:keyParser.keyTable.SE_NAME,
		   status:keyParser.keyTable.RESULT,
		   result:keyParser.keyTable.CONTENT
	   },
	   getSingleSensorCode:{
	     url:'/sensorlook/getSingleSensor',
	     id:keyParser.keyTable.SE_CODE,
		   body:keyParser.keyTable.SE_NAME,
		   status:keyParser.keyTable.RESULT,
		   result:keyParser.keyTable.CONTENT
	   },
	   getPlatformPoint:{
			url:"/realtimevideo/getPlatformPoint",
		    status:keyParser.keyTable.RESULT,
            result:keyParser.keyTable.CONTENT
	   },
	   setPointWarnTemp:{
			url:"/realtimevideo/setPointWarnTemp",
		    status:keyParser.keyTable.RESULT,
		    result:keyParser.keyTable.CONTENT
	   },
	   cameraManage:{
			url:"/realtimevideo/camera",
		    status:keyParser.keyTable.RESULT,
		    result:keyParser.keyTable.CONTENT
	   },
	   tempFix:{
		   url:"/realtimevideo/tempFix",
		   status:keyParser.keyTable.RESULT,
		   result:keyParser.keyTable.CONTENT
	   },
	   cameraCapture:{
		   url:"/looktemp/createImage",
		   status:keyParser.keyTable.RESULT
	   },
	   enableCameraCapture:{
		   url:"/looktemp/enableCapture",
		   status:keyParser.keyTable.RESULT
	   },	   
	   closeCameraCapture:{
		   url:"/looktemp/closeCapture",
		   status:keyParser.keyTable.RESULT
	   },
	   cameraCaptureSinglePoint:{
		   url:"/looktemp/createImageSinglePoint",
		   status:keyParser.keyTable.RESULT
	   },
	   cameraCaptureDeletePoint:{
		   url:"/looktemp/createImageDeletePoint",
		   status:keyParser.keyTable.RESULT
	   },
	   // 此请求接口随时改变
	   getCaptureImage:{
		   url:"/looktemp/getCaptureImage",
		   status:keyParser.keyTable.RESULT,
		   result:keyParser.keyTable.CONTENT
	   },
	// 此请求接口随时改变
	   getCaptureImageSinglePoint:{
		   url:"/looktemp/getCaptureImageSinglePoint",
		   status:keyParser.keyTable.RESULT,
		   result:keyParser.keyTable.CONTENT
	   }
   };
   const statusList={
   	     CAMERA_DATA_EMPTY:0x00,
         CAMERA_DATA_CHANGE:0x01,
	     CAMERA_DATA_NORMAL:0x02,
	     // 摄像机方向状态,与接口进行对应
	     CAMERA_DIRECTION_STOP:0x100,
	     CAMERA_DIRECTION_UP:0x101,
   	     CAMERA_DIRECTION_DOWN:0x102,
	     CAMERA_DIRECTION_LEFT:0x103,
	     CAMERA_DIRECTION_RIGHT:0x104,
	     CAMERA_DIRECTION_CENTER:0x105,

   };
   const toastList={
   	     INFO:0x00,
	     WARNING:0x01,
	     ERROR:0x02,
	     SUCCESS:0x03
   };

   let _TOAST_=null;
   
   this.isFirstView=false;

   // 基本成员
   this.hasInit=false; // 是否初始化
   this.context=null;
   this.operator=null;
   this.imagePath=null;
   this.statusList=statusList;
   this.interfaceList=interfaceList;
   this.currentCamera=new Camera();
   this.currentPlatformPointView=null;
   this.isFillInLightOpen=false;
   this.toastList=toastList;
   // 初始化方法
   this.init=initEveryting;
   // 数据更新方法
   this.updateOperationClass=updateOpClass;
   this.updateStation=updateStation;
   this.updateBuilding=updateBuilding;
   this.updateSensor=updateSensor;
   this.updateSensorCode=updateCameraCode;
   this.updatePlatformPoint=updatePlatformPoint; //updatePlatformPoint;
   this.updatePointWarnTemp=updatePointWarnTemp;
   this.updateCurrentPlatformPointView = updateCurrentPlatformPointView;
// 摄像机控制方法
   this.cameraDirectionControl=cameraDirectionControl;
   this.cameraFillinLightControl=cameraFillinLightControl;
   this.cameraReboot=cameraReboot;
   this.cameraReset=cameraReset;
   this.cameraUpdateINR=cameraUpdateINR;
   this.cameraUpdateEDR=cameraUpdateEDR;
   this.saveFusionConfig=cameraSaveFusionConfig;
   this.cameraTemperatureCalibration=cameraTemperatureCalibration;
   this.updateDeviceNumber=cameraUpdateDeviceNumber;
   this.setWiFi=cameraUpdateWiFiConfig;
   this.saveCloudServerIP=cameraUpdateCloudServerIP;
   this.setEmissivity=cameraUpdateEmissivity;
   this.cameraCapture=cameraCapture;
   this.enableCameraCapture=enableCameraCapture;
   this.closeCameraCapture=closeCameraCapture;
   this.cameraCaptureSinglePoint=cameraCaptureSinglePoint;
   this.cameraCaptureDeletePoint=cameraCaptureDeletePoint;
   this.updateCaptureImageList=updateCaptureImageList;
   this.updatePlatformPointRegion=updatePlatformPointRegion;
   this.pointPresentCalled=pointPresentCalled;
   // 其他辅助方法
   this.checkSensor=checkSensor;
   this.log=function (msg) {
   	    log(TAG,msg);
   };
   this.showToast=function(type,msg){
   	    if(!_TOAST_){
   	    	return log(TAG,"TOAST is null!");
		}
   	    switch(type){
			case toastList.INFO:
				_TOAST_.info(msg);
				break;
			case toastList.ERROR:
				_TOAST_.error(msg);
				break;
			case toastList.SUCCESS:
				_TOAST_.success(msg);
				break;
			case toastList.WARNING:
				_TOAST_.warning(msg);
				break;
		}
   };

   function initEveryting(context,operator,imagePath,firstSelectId,platformPointId,captureImageListId){
   	   if(!this.hasInit){
		   log(TAG,"CameraHelper init...");
		   _TOAST_=bindToastTool(); //绑定toast工具
		   this.context=context;
		   this.operator=operator; // 当前操作员
		   this.imagePath=imagePath;
		   log(TAG,"imagePath:"+this.imagePath);
		   this.currentCamera.setDataStatus(statusList.CAMERA_DATA_EMPTY);
		   this.updateOperationClass(firstSelectId); //更新第一个Ｓｅｌｅｃｔ元素
		   initPlatformPointPanel(platformPointId);
		   initCaptureImagePanel(captureImageListId);
		   this.hasInit=true;
	   }
   }

   function updateOpClass(id){
   	    updateSelect(id,"请选择班组",this.context,{"username":this.operator},interfaceList.getOpClass);
   	    this.currentCamera.setWho(this.operator);
   	    checkCameraDataStatus(this.currentCamera,this.currentCamera.shadow.who,this.currentCamera.who);
	    log(TAG,"update who:"+this.operator);
   }

   function updateStation(id,opclass){
	   updateSelect(id,"请选择变电站",this.context,{"opclass":opclass},interfaceList.getStation);
	   this.currentCamera.setOpclass(opclass);
	   checkCameraDataStatus(this.currentCamera,this.currentCamera.shadow.opclass,this.currentCamera.opclass);
	   log(TAG,"update opclass:"+opclass);
   }

   function updateBuilding(id,station){
   	    updateSelect(id,"请选择设备间",this.context,{"station":station},interfaceList.getBuilding);
	    this.currentCamera.setStation(station);
        checkCameraDataStatus(this.currentCamera,this.currentCamera.shadow.station,this.currentCamera.station);
	    log(TAG,"update station:"+station);
   }

   function updateSensor(id,building){
		updateSelect(id,"请选择监控器编号",this.context,{"building_id":building},interfaceList.getSensorCode);
	    this.currentCamera.setBuilding(building);
	    checkCameraDataStatus(this.currentCamera,this.currentCamera.shadow.building,this.currentCamera.building);
	    log(TAG,"update building:"+building);
   }
   /*
   function updateCameraCode(code){
   	 this.currentCamera.setCode(code);
   	 checkCameraDataStatus(this.currentCamera,this.currentCamera.shadow.code,this.currentCamera.code);
   	 log(TAG,"update code:"+code);
   }*/
   
   function updateCameraCode(code){
	   	this.currentCamera.setCode(code);
	   	
	   	var arg={
	   			'code':code
	   	}
	   	 var int=interfaceList.getSingleSensorCode;
		 var url=this.context+int.url+"?code="+code;
	   	 $.ajax({
			type:"GET",
			dataType:"json",
			url:url,
			processData: false,
			contentType: false,
			success:function(data){
				var result = data.result;
				console.log('result:'+result);
				var sensor = data.sensor;
				if(result){
					if(null != data.sensor){
						var sensor = data.sensor;
						//console.log("xxxxxxx"+sensor.inf_x_offset);
						
						$('#in-inr').val(sensor['inf_fusion_render']);
						$('#in-edr').val(sensor['inf_fusion_edge']);
						
						$('#in-fs').val(sensor['inf_fusion_amplify']);
						$('#in-fr').val(sensor['inf_fusion_rotate']);
						$('#in-fl').val(sensor['inf_x_offset']);
						$('#in-ft').val(sensor['inf_y_offset']);
						
						$('#in-na').val(sensor['wifi_name']);
						$('#in-pw').val(sensor['wifi_pass']);
						$('#in-ip').val(sensor['server_ip']);
						
					}else {
						
					}
					
					
				}
			},
			error:function(result){
		    	  alert("error");
		    	  
		     }

		});
	   	
	   	//checkCameraDataStatus(this.currentCamera,this.currentCamera.shadow.code,this.currentCamera.code);
	   	//log(TAG,"update code:"+code);
   }

	// TODO 更新抓怕图片列表
   function updateCaptureImageList(table){
	   $(table).empty();
	   var body="<tr><td><lable class='label center-block label-info'>暂无抓拍图片！</lable></td></tr>";
	   var list=this.currentCamera.plaformPointList;
	   if(list){
		   for(var i=0;i<list.length;i++){
		   	  if(i===0){
		   	  	body="";
			  }
		   	  body+="<tr><td>";
		   	  var imageName=list[i].images;
		   	  log(TAG,"imageName:"+imageName);
		   	  if(imageName){
		   	  	 body+="<img alt=\"加载失败！"+imageName+"\" src=\""+this.imagePath+imageName+"\">";
			  }else{
		   	  	 body+="<img alt=\"图片异常\" src=\""+this.context+"/img/noimage.jpg\">";
			  }
		   	  body+="</td></tr>";
		   }
	   }
	   // log(TAG,"body:"+body);
	   $(table).append(body);

	   // var int=interfaceList.getCaptureImage;
	   // var url=this.context+int.url;
	   // var camera=this.currentCamera;
	   // var arg={"username":camera.who,
		// "op_id":camera.opclass,
		// "station":camera.station,
		// "building":camera.building
	   // };
	   // var imagePath=this.imagePath;
	   // log(TAG,"called updateCaptureImageList()");
	   // request(url,arg,function(data){
		// $(table).empty();
		// var body="<tr><td>暂无抓拍图片！</td></tr>";
		// var isOk=keyParser.obtainVaule(data,int.status);
		// if(isOk) {
		// var list = keyParser.obtainVaule(data, int.result);
		// $.each(list, function(i,item){
		// var points=item.points;
		// if(points){
		// $.each(points,function(j,pt){
		//
		// });
		// }
		// });
		// body="<tr><td>图片更新成功!</td></tr>";
		// }log(TAG,"body:"+body);
	   // $(table).append(body);
	   // });

   }

   // function updatePlaformPointByJSON(table){
	//    var int=interfaceList.getPlatformPoint;
	//    var url=this.context+int.url;
	//    var camera=this.currentCamera;
	//    var arg={"username":camera.who,
	// 	   "op_id":camera.opclass,
	// 	   "station":camera.station,
	// 	   "building":camera.building,
	// 	   "sensor_code":camera.code
	//    };
	//    log(TAG,"called updatePlatformPoint()");
	//    request(url,arg,function(data){
	// 	   var isOk=keyParser.obtainVaule(data,int.status);
	// 	   if(isOk){
	// 		   var list=keyParser.obtainVaule(data,int.result);
	// 		   camera.setPlaformPointList(list);
	// 		   log(TAG,"list:"+list.length);
	// 		   for(var i=0;i<list.length;i++){
	// 		   	  var pty=list[i].point_type;
	// 		   	  $("#platform-point-"+pty).attr("disabled",false);
	// 		   	  $("#sel-"+pty).attr("disabled",false);
	// 		   	  $("#platform-point-"+pty).attr("onclick",'alert("调用成功！")');
	// 		   	  $("#sel-"+pty).attr("onchange",'onPlatformPointButtonClick("#platform-point-'+pty+'",'+i+')');
	// 		   }
	// 	   }
	//    });
   // }

   function updatePlatformPoint(table){
   	   var int=interfaceList.getPlatformPoint;
   	   var url=this.context+int.url;
   	   var camera=this.currentCamera;
   	   var arg={"username":camera.who,
			     "op_id":camera.opclass,
			     "station":camera.station,
			     "building":camera.building,
			     "sensor_code":camera.code
       };
   	   log(TAG,"called updatePlatformPoint()");
   	   request(url,arg,function(data){
		   $(table).empty();
		   var body="<tr><td><label class='label center-block label-info'>暂无预设点！</label></td></tr>";
		   var isOk=keyParser.obtainVaule(data,int.status);
   	   	   if(isOk){
   	   	  	 var list=keyParser.obtainVaule(data,int.result);
   	   	  	 camera.setPlaformPointList(list);
   	   	  	 log(TAG,"list:"+list.length);
   	   	  	 var o=list.length%4;
   	   	  	 var f=list.length-o;
   	   	  	 log(TAG,"o:"+o+" f:"+f);
   	   	  	 for(var i=0;i<list.length;i++){
				 if((i%4)===0){
				 	if(i===0){
				 		body="<tr>";
					}else{
				 		body+="</tr><tr>";
					}
				 }
				 var st="<td>";
				 if(i>=f){
					 switch (o) {
						 case 1:
						 	st="<td colspan='4'>";
						 	break;
						 case 2:
						 	st="<td colspan='2'>";
						 	break;
						 case 3:
						 	if(i===f){
						 		st="<td colspan='2'>";
							}
						 	break;
					 }
				 }
				 // log(TAG,"st:"+st);
				 //id format: _ppb0,1,2...
				 body+=st+"<button id=\"_ppb"+i+"\" class=\"btn btn-block btn-default\" onclick=\"onPlatformPointButtonClick(this,"+i+")\">"+
					 list[i].platform_code+"("+list[i].distance+"米)</button></td>";
				 //log(TAG,list[i].region);
				 if((i+1)===list.length){
				 	body+="</tr>";
				 }
			 }
           }
   	   	   // log(TAG,"body:"+body);
   	   	   $(table).append(body);
       });
     }

	function updateCurrentPlatformPointView(it){
   	    var newView=it;
		var oldView=this.currentPlatformPointView;
		if(oldView){
			oldView.style.backgroundColor="";
			//newView.css("background-color","#FFF");
		}
		if(newView){
			newView.style.backgroundColor="#666";
			//newView.css("background-color","#E00");
		}
		this.currentPlatformPointView=newView;
	}

	function updatePointWarnTemp(button,temp){
   	   log(TAG,"temp:"+temp+" point temp:"+this.currentCamera.onFocusPoint.warn_temp);
	   var int=interfaceList.setPointWarnTemp;
	   var url=this.context+int.url;
	   var camera=this.currentCamera;
	   var point=this.currentCamera.onFocusPoint;
	   var arg={"id":point.id,
		        "warn_temp":temp,
		        "sensor_code":camera.code,
		        "platform_code":point.platform_code,
	   };
	   var cameraHelper=this;
	   request(url,arg,function(data){
		   var isOk=keyParser.obtainVaule(data,int.status);
		   var content=keyParser.obtainVaule(data,int.result);
		   if(isOk){
		   	  point.warn_temp=temp;
		   	  cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"更新温度成功！");
		   }else{
		   	  cameraHelper.showToast(cameraHelper.toastList.ERROR,"更新温度失败！");
		   }
		   //alert(content);
	   });
   }

   function cameraDirectionControl(button,direction){
   	    var operator=this.operator;
   	    var code=this.currentCamera.code;
	    var int=interfaceList.cameraManage;
	    var url=this.context+int.url;
	    var arg={
			     "operator":operator,
			     "intent":0x000,
	    	     "sensor_code":code,
			     "action":direction
		};
	    var cameraHelper=this;
   	    getRequest(url,arg,function(data){
			var isOk=keyParser.obtainVaule(data,int.status);
			var content=keyParser.obtainVaule(data,int.result);
			log(TAG,"isOK:"+isOk+" content:"+content);
			//alert("isOK:"+isOk+" content:"+content);
			if(isOk){
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,content);
			}else{
			    cameraHelper.showToast(cameraHelper.toastList.ERROR,content);
			}
	    });
    }

    function cameraFillinLightControl(button) {
		 var int=interfaceList.cameraManage;
		 var url=this.context+int.url;
		 var camera=this.currentCamera;
		 var isOpen=!this.isFillInLightOpen;
		 var arg={
			  "operator":this.operator,
			  "intent":0x001,
			  "sensor_code":camera.code,
			  "is_open":isOpen};
		 var cameraHelper=this;
		 getRequest(url,arg,function(data){
			var isOk=keyParser.obtainVaule(data,int.status);
			var content=keyParser.obtainVaule(data,int.result);
			if(isOk){
				cameraHelper.isFillInLightOpen=isOpen;
				if(cameraHelper.isFillInLightOpen){
					button.style.backgroundColor="#0f0";
				}else{
					button.style.backgroundColor="";
				}
			}
			log(TAG,"isOK:"+isOk+" content:"+content);
			// alert("isOK:"+isOk+" content:"+content);
		 });
	}

	function cameraReboot(button){
		var cameraHelper=this;
		cameraRequestEmpty(cameraHelper,0x002,function(isOk){
			 if(isOk){
			 	//alert("重启成功！");
			 	cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"重启成功！");
			 }else{
			 	//alert("重启失败！");
			 	cameraHelper.showToast(cameraHelper.toastList.ERROR,"重启失败！");
			 }
		});
	}

	function cameraReset(button){
		var cameraHelper=this;
		
		cameraRequestEmpty(cameraHelper,0x003,function(isOk,content){
			if(isOk){
				//alert("恢复出厂成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"恢复出厂成功！");
			}else{
				//alert("恢复出厂失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,"恢复出厂失败！");
			}
		});
	}

	function cameraUpdateINR(button,value){
		var cameraHelper=this;
		cameraRequestSingleUpdate(cameraHelper,0x04,value,function (isOk,content){
			if(isOk){
				//alert("更新成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,content);
			}else{
				//alert("更新失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,content);
			}
		});
	}

	function cameraUpdateEDR(button,value) {
		var cameraHelper=this;
		cameraRequestSingleUpdate(cameraHelper,0x05,value,function (isOk,content){
			if(isOk){
				//alert("更新成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,content);
			}else{
				//alert("更新失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,content);
			}
		});
	}

	function cameraSaveFusionConfig(button,fs,fr,fl,ft){
   	    var value=fs+","+fr+","+fl+","+ft;
		var cameraHelper=this;
		cameraRequestSingleUpdate(cameraHelper,0x006,value,function (isOk,content){
			if(isOk){
				//alert("更新成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,content);
			}else{
				//alert("更新失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,content);
			}
		});
	}

	// 温度校准
	function cameraTemperatureCalibration(input){
		var operator=this.operator;
		var code=this.currentCamera.code;
		var int=interfaceList.tempFix;
		var url=this.context+int.url;
		var arg=new FormData();
		arg.append("operator",operator);
		arg.append("intent",0x007);
		arg.append("sensor_code",code);
		arg.append("file",input.files[0]);
		var cameraHelper=this;
		$.ajax({
			type:"POST",
			dataType:"json",
			url:url,
			data:arg,
			processData: false,
			contentType: false,
			success:function(data){
				var isOk = keyParser.obtainVaule(data, int.status);
				var content = keyParser.obtainVaule(data, int.result);
				if(isOk){
					//alert("上传成功！");
					cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"上传成功!");
				}else{
					//alert("上传失败！");
					cameraHelper.showToast(cameraHelper.toastList.ERROR,"上传失败!");
				}
				log(TAG,"isOK:"+isOk+" content:"+content);
			},
			error:ajaxError
		});
	}

	function cameraUpdateDeviceNumber(button,value){
		var cameraHelper=this;
		cameraRequestSingleUpdate(cameraHelper,0x008,value,function (isOk,content){
			if(isOk){
				//alert("更新成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,content);
			}else{
				//alert("更新失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,content);
			}
		});
	}

	function cameraUpdateWiFiConfig(button,na,pw){
		var operator=this.operator;
		var code=this.currentCamera.code;
		var int=interfaceList.cameraManage;
		var url=this.context+int.url;
		var arg={
			"operator":operator,
			"intent":0x009,
			"sensor_code":code,
			"na":na, "pw":pw
		};
		var cameraHelper=this;
		postRequest(url,arg,function(data){
			var isOk=keyParser.obtainVaule(data,int.status);
			var content=keyParser.obtainVaule(data,int.result);
			if(isOk){
				//alert("设置成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"设置成功！");
			}else{
				cameraHelper.showToast(cameraHelper.toastList.ERROR,"设置失败！");
			}
			log(TAG,"isOK:"+isOk+" content:"+content);
			// alert("isOK:"+isOk+" content:"+content);
		});
	}

	function cameraUpdateCloudServerIP(button,value){
		var cameraHelper=this;
		cameraRequestSingleUpdate(cameraHelper,0x010,value,function (isOk,content){
			if(isOk){
				//alert("更新成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,content);
			}else{
				//alert("更新失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,content);
			}
		});
	}

	function cameraUpdateEmissivity(button,value){
		var cameraHelper=this;
		cameraRequestSingleUpdate(cameraHelper,0x011,value,function (isOk,content){
			if(isOk){
				//alert("更新成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,content);
			}else{
				//alert("更新失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,content);
			}
		});
	}

	function updatePlatformPointRegion(table,canvasHelper){
		var int=interfaceList.cameraManage;
		var url=this.context+int.url;
		var camera=this.currentCamera;
		var type=this.currentCamera.onFocusPoint.point_type;
		var platformPointId=this.currentCamera.onFocusPoint.id;
		//TODO 测试时,预设点编号恒为：0
		type=(IS_TEST)? 0:(parseInt(type)-1); //解决下标从0开始
		var format=canvasHelper.getRegionDataFix(type);
		var region=canvasHelper.getRegionJsonData();
		log(TAG,"format:"+format);
		log(TAG,"region:"+region);
		var arg={
			"operator":this.operator,
			"intent":0x012,
			"sensor_code":camera.code,
			"platform_point_id":platformPointId,
			"format":format,
			"region":region
		};
		var cameraHelper=this;
		postRequest(url,arg,function(data){
			var isOk=keyParser.obtainVaule(data,int.status);
			var content=keyParser.obtainVaule(data,int.result);
			if(isOk){
				//alert("提交成功！");
				cameraHelper.updatePlatformPoint(table);
				//TODO add called function
				$("#_ppb"+cameraHelper.currentCamera.pointIndex).click();
			    
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"提交成功！");
				log(TAG,"content:"+content);
			}else{
				//alert("提交失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,"提交失败！");
			}
		});
	}

	function pointPresentCalled() {
		var cameraHelper=this;
   	    var value=this.currentCamera.onFocusPoint.point_type;
   	    console.log("value:"+value);
		cameraRequestSingleUpdate(cameraHelper,0x013,value,function (isOk,content){
			if(isOk){
				//alert("调用成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"调用成功！");
			}else{
				//alert("调用失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,"调用失败！");
			}
		});
	}
	
	function pointPresentDelete() {
		var cameraHelper=this;
   	    var value=this.currentCamera.onFocusPoint.point_type;
   	    console.log("value:"+value);
		cameraRequestSingleUpdate(cameraHelper,0x013,value,function (isOk,content){
			if(isOk){
				//alert("调用成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"调用成功！");
			}else{
				//alert("调用失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,"调用失败！");
			}
		});
	}
	

	function cameraRequestEmpty(cameraHelper,intent,action){
		cameraRequestSingleUpdate(cameraHelper,intent,null,action);
	}

	function cameraRequestSingleUpdate(cameraHelper,intent,value,action) {
   	    var operator=cameraHelper.operator;
		var int=cameraHelper.interfaceList.cameraManage;
		var code=cameraHelper.currentCamera.code;
		var arg = {
			"operator": operator,
			"intent": intent,
			"sensor_code": code
		};
		if(value) arg["value"]=value;
		cameraControlRequest(cameraHelper,arg, function(data) {
			var isOk = keyParser.obtainVaule(data, int.status);
			var content = keyParser.obtainVaule(data, int.result);
			action(isOk,content);
			log(TAG, "cameraRequestSingleUpdate() -> isOK:" + isOk + " content:" + content);
		});
	}

	function cameraControlRequest(cameraHelper,request_arg,action){
		getRequest(cameraHelper.context+cameraHelper.interfaceList.cameraManage.url,request_arg,action);
	}
	

	function cameraCapture(button) {
		var int=this.interfaceList.cameraCapture;
   	    var url=this.context+int.url;
   	    var camera=this.currentCamera;
   	    var arg={
   	    	"station_op":camera.opclass,
			"station":camera.station,
			"building":camera.building
		};
   	    button.innerHTML="正在抓拍...";
   	    button.disabled=true;
		var cameraHelper=this;
   	    jsonRequest(url,"POST",arg,function (data) {
			var isOk = keyParser.obtainVaule(data, int.status);
			if(isOk){
				//alert("抓拍成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"抓拍成功！");
			}else{
				//alert("抓拍失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,"抓拍失败！");
			}
			button.innerHTML="抓拍";
			button.disabled=false;
		},false); // ａｊａｘ同步调用
	}
	
	/**
	 * 关闭或打开抓拍功能
	 */
	function enableCameraCapture(button) {
		var int=this.interfaceList.enableCameraCapture;
   	    var url=this.context+int.url;
   	    var camera=this.currentCamera;
   	    var arg={
   	    	"station_op":camera.opclass,
			"station":camera.station,
			"building":camera.building,
			"code":camera.code
		};
   	    button.innerHTML="进行中...";
   	    button.disabled=true;
		var cameraHelper=this;
   	    jsonRequest(url,"POST",arg,function (data) {
			var isOk = keyParser.obtainVaule(data, int.status);
			if(isOk){
				//alert("抓拍成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"操作成功！");
			}else{
				//alert("抓拍失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,"操作失败！");
			}
			button.innerHTML="开启抓拍";
			button.disabled=false;
		},false); // ａｊａｘ同步调用
	}
	
	/**
	 * 关闭或打开抓拍功能
	 */
	function closeCameraCapture(button) {
		var int=this.interfaceList.closeCameraCapture;
   	    var url=this.context+int.url;
   	    var camera=this.currentCamera;
   	    var arg={
   	    	"station_op":camera.opclass,
			"station":camera.station,
			"building":camera.building,
			"code":camera.code
		};
   	    button.innerHTML="进行中...";
   	    button.disabled=true;
		var cameraHelper=this;
   	    jsonRequest(url,"POST",arg,function (data) {
			var isOk = keyParser.obtainVaule(data, int.status);
			if(isOk){
				//alert("抓拍成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"操作成功！");
			}else{
				//alert("抓拍失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,"操作失败！");
			}
			button.innerHTML="关闭抓拍";
			button.disabled=false;
		},false); // ａｊａｘ同步调用
	}
	
	function cameraCaptureSinglePoint(button) {
		var int=this.interfaceList.cameraCaptureSinglePoint;
   	    var url=this.context+int.url;
   	    var camera=this.currentCamera;
   	    var arg={
   	    	"station_op":camera.opclass,
			"station":camera.station,
			"building":camera.building,
			"sensor" : camera.code,
			"point_type": camera.onFocusPoint.point_type
		};
   	    button.innerHTML="正在抓拍...";
   	    button.disabled=true;
		var cameraHelper=this;
   	    jsonRequest(url,"POST",arg,function (data) {
			var isOk = keyParser.obtainVaule(data, int.status);
			if(isOk){
				//alert("抓拍成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"抓拍成功！");
			}else{
				//alert("抓拍失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,"抓拍失败！");
			}
			button.innerHTML="抓拍";
			button.disabled=false;
		},false); // ａｊａｘ同步调用
	}

	function cameraCaptureDeletePoint(button) {
		var int=this.interfaceList.cameraCaptureDeletePoint;
   	    var url=this.context+int.url;
   	    var camera=this.currentCamera;
   	    var arg={
   	    	"station_op":camera.opclass,
			"station":camera.station,
			"building":camera.building,
			"sensor" : camera.code,
			"point_type": camera.onFocusPoint.point_type
		};
   	    button.innerHTML="删除中...";
   	    button.disabled=true;
		var cameraHelper=this;
   	    jsonRequest(url,"POST",arg,function (data) {
			var isOk = keyParser.obtainVaule(data, int.status);
			if(isOk){
				//alert("抓拍成功！");
				cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"删除成功！");
			}else{
				//alert("抓拍失败！");
				cameraHelper.showToast(cameraHelper.toastList.ERROR,"删除失败！");
			}
			button.innerHTML="删除";
			button.disabled=false;
		},false); // ａｊａｘ同步调用
	}
	/**
	 * 更新ｓｅｌｅｃｔ元素统一方法
	 * 
	 * @param select
	 *            元素
	 * @param info
	 *            提示信息
	 * @param context
	 *            请求上下文
	 * @param request_arg
	 *            请求参数
	 * @param request_interface
	 *            请求接口
	 */
	function updateSelect(select,info,context,request_arg,request_interface){
		var request_url=context+request_interface.url;
		var key_status=request_interface.status;
		var key_result=request_interface.result;
		var key_id=request_interface.id;
		var key_body=request_interface.body;
		if (checkItem(select,info)){
			// ａｊａｘ请求异步
			request(request_url,request_arg,function(data){
				var isOk=keyParser.obtainVaule(data,key_status);
				log(TAG,"updateSelect() -> isOk:"+isOk);
				if(isOk){
					var list=keyParser.obtainVaule(data,key_result);
					if (list){
						// 只要ｌｉｓｔ不为空，就认为更新成功了
						$.each(list,function(i,value){
							var v=keyParser.obtainVaule(value,key_id);
							var b=keyParser.obtainVaule(value,key_body);
							// log(TAG,"value:"+v+" body:"+b);
							$(select).append("<option value=\""+v+"\">"+b+"</option>");
						});
					}
				}
			});
		}
	}

	/**
	 * 检查摄像机数据状态,传入ｃａｍｅｒａ更新状态
	 * 
	 * @param camera
	 *            必须,摄像机对象
	 * @param shadow_data
	 * @param current_data
	 */
	function checkCameraDataStatus(camera,shadow_data,current_data){
		log(TAG,"shadow_data:"+shadow_data+" current_data:"+current_data);
		if(shadow_data===current_data){
			camera.setDataStatus(statusList.CAMERA_DATA_NORMAL);
			log(TAG,"camera data status normal");
		}else{
			camera.setDataStatus(statusList.CAMERA_DATA_CHANGE);
			log(TAG,"camera data status changed");
		}
		log(TAG,"checkCameraDataStatus() -> camera data status:"+camera.dataStatus);
	}

	function checkSensor(){
		return !!(this.currentCamera.code);
	}

	function checkItem(id,tag){
	   if(!id){
	   	  log(TAG,"check_id():id is null.");
		  return false;
	   }
	   var which=$(id);
	   if(!which){
		   log(TAG,"check_id():id  "+id+" is invalid.");
	       return false;
	   }
	   which.empty();
	   which.append("<option value='0'>---"+tag+"---</option>");
	   return true;
   }

	/**
	 * 默认接口请求方法,POST
	 * 
	 * @param url
	 * @param data
	 * @param action
	 */
   function request(url,data,action) {
	   postRequest(url,data,action);
   }

   function postRequest(url,data,action){
   	  jsonRequest(url,"POST",data,action,true);
   }

   function getRequest(url,data,action){
   	  jsonRequest(url,"GET",data,action,true);
   }

   function jsonRequest(url,type,data,action,isAsync){
	 $.ajax({
			    type:type,
			    dataType:"json",
			    url:url,
		        async: isAsync,
		        timeout:10000,
			    data:data,
			    success:action,
			    error:ajaxError
	});
  }

   function ajaxError(XMLHttpRequest,textStatus,errorThrown){
		log(TAG,"==============ajax error=================");
		log(TAG,"testStatus:"+textStatus+" errorThrown:"+errorThrown);
		log(TAG,XMLHttpRequest.getAllResponseHeaders());
		log(TAG,"=========================================");
   }
   function log(tag,msg){
	   	  Tool.log(tag,msg);
	}
   
};
