//cameraHelper:全局代理
/**
 * 监听每一个ｓｅｌｅｃｔ元素的状态
 * @param floor 层级
 * @param it　当前触发的ｓｅｌｅｃ元素
 * @param target　被动更新ｓｅｌｅｃｔ元素的ｉｄ
 */
function onSelectChange(floor,it,target){
    switch (floor) {
        case 0:
            cameraHelper.updateStation(target,it.value);
            break;
        case 1:
            cameraHelper.updateBuilding(target,it.value);
            break;
        case 2:
            cameraHelper.updateSensor(target,it.value);
            break;
        case 3:
            //没有下一个元素,仅接受一个参数
            cameraHelper.updateSensorCode(it.value);
            //cameraHelper.log("it.val:"+it.value+" = "+$("#add_sensor").val());
            break;
    }
    //若摄像机数据数据状态改变,则更新预设点列表
    //cameraHelper.log("onSelectClick() -> currentCameraStatus:"+cameraHelper.currentCamera.dataStatus);
    //if(cameraHelper.currentCamera.code&&cameraHelper.currentCamera.dataStatus===cameraHelper.statusList.CAMERA_DATA_CHANGE){
    if(cameraHelper.currentCamera.dataStatus===cameraHelper.statusList.CAMERA_DATA_CHANGE){
        cameraHelper.updatePlatformPoint("#platform_point"); //更新预设点列表
        //FIXME 更新抓拍图片时机待确定
        if(cameraHelper.currentCamera.building||true){
            cameraHelper.updateCaptureImageList("#capture-image-list"); //更新抓拍图片列表
        }
    }else{
        cameraHelper.log("onSelectClick() status normal");
    }
    //cameraHelper.log("onSelectClick() -> target:"+target);
    cameraHelper.log("camera:"+cameraHelper.currentCamera.toString());
}

/**
 *监听预设点列表中的每一个ｂｕｔｔｏｎ元素的状态
 * @param it　元素
 * @param index　预设点数据的索引
 */
function onPlatformPointButtonClick(it,index){
    onEmptyRegionButtonClick();
    if(it===cameraHelper.currentPlatformPointView){
        cameraHelper.currentCamera.setOnFocusPoint(-1);//没有选取预设点
        $("#warn_temp").val("");
        cameraHelper.updateCurrentPlatformPointView(null);
        // initPlatformPointPanel("#platform_point");
        $("#fresh-region").attr("disabled",true);
        $("#empty-region").attr("disabled",true);
        $("#delete-region").attr("disabled",true);
        $("#submit-region").attr("disabled",true);
        canvasHelper.updateImageCanvas(canvasHelper.defaultImageUrl);
    }else{
        cameraHelper.currentCamera.setOnFocusPoint(index);
        $("#warn_temp").val(cameraHelper.currentCamera.onFocusPoint.warn_temp);
        cameraHelper.updateCurrentPlatformPointView(it);
        //更新画布
        var jstr;//='[{"type":"0x01","sColor":"#0FF","lColor":"#F00","value":[{"x":123,"y":65},{"x":10,"y":25}]}]';
        jstr=cameraHelper.currentCamera.onFocusPoint.region;
        canvasHelper.log("onPlatformPointButtonClick -> jstr:"+jstr);
        (!jstr)?jstr="[]":true; //fix region
        var data=$.parseJSON(jstr); //直接解析JSON字符串
        canvasHelper.updateCanvasRegion(data);
        if(canvasHelper.controlMode!==canvasHelper.modeList.VIEW){
            $("#fresh-region").removeAttr("disabled");
            $("#empty-region").removeAttr("disabled");
            $("#delete-region").removeAttr("disabled");
            $("#submit-region").removeAttr("disabled");
        }
        canvasHelper.updateImageCanvas(cameraHelper.imagePath+cameraHelper.currentCamera.onFocusPoint.images);
    }
}

/**
 * 监听告警温度保存按钮
 * @param it　元素
 */
function onWarnTempSave(it){
    var point=cameraHelper.currentCamera.onFocusPoint;
    if(point&&cameraHelper.checkSensor()){
        var temp=$("#warn_temp").val();
        if(temp&&temp!=point.warn_temp){
            cameraHelper.updatePointWarnTemp(it,temp);
        }else{
            //alert("温度相同,不需要更新！");
            cameraHelper.showToast(cameraHelper.toastList.WARNING,"温度相同,不需要更新！");
        }
    }else{
        //alert("请选取一个预设点");
        cameraHelper.showToast(cameraHelper.toastList.WARNING,"请选取一个预设点!");
    }
}

/**
 * 监听摄像机方向控制按钮
 * @param it　元素
 * @param code　方向代号
 * @param isDown 按键是否压下
 */
function onCameraDirectionClick(it,code,isDown){
    if(cameraHelper.checkSensor()){
        if(isDown){
            switch (code) {
                case 0:
                    cameraHelper.cameraDirectionControl(it,cameraHelper.statusList.CAMERA_DIRECTION_CENTER);
                    break;
                case 1:
                    cameraHelper.cameraDirectionControl(it,cameraHelper.statusList.CAMERA_DIRECTION_UP);
                    break;
                case 2:
                    cameraHelper.cameraDirectionControl(it,cameraHelper.statusList.CAMERA_DIRECTION_DOWN);
                    break;
                case 3:
                    cameraHelper.cameraDirectionControl(it,cameraHelper.statusList.CAMERA_DIRECTION_LEFT);
                    break;
                case 4:
                    cameraHelper.cameraDirectionControl(it,cameraHelper.statusList.CAMERA_DIRECTION_RIGHT);
                    break;
                default:
                    console.error("unknown direction code:"+code);
                    break;
            }
        }else{
            //当按键释放时,停止运动
            cameraHelper.log("按键释放！");
            cameraHelper.cameraDirectionControl(it,cameraHelper.statusList.CAMERA_DIRECTION_STOP);
        }
    }else{
        if(!isDown){
            //alert("没有可操控摄像头！");
            cameraHelper.showToast(cameraHelper.toastList.WARNING,"没有可操控摄像头！");
        }
    }
}

/**
 * 监听其他有关摄像机操作的按钮
 * @param it　元素
 * @param flag　区分每一个元素的标志量
 */
function onButtonClick(it,flag){
    if(cameraHelper.checkSensor()){
        switch (flag) {
            case 0:
                cameraHelper.cameraFillinLightControl(it);
                break;
            case 1:
                cameraHelper.cameraReboot(it);
                break;
            case 2:
                cameraHelper.cameraReset(it);
                break;
            case 3:
                //更新红外呈现参数
                var value=$("#in-inr").val();
                if(value){
                    cameraHelper.cameraUpdateINR(it,value);
                    $("#in-inr").val("");
                }else{
                    //alert("请输入红外呈现参数！");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请输入红外呈现参数！");
                }
                break;
            case 4:
                //更新边缘呈现参数
                var value=$("#in-edr").val();
                if(value){
                    cameraHelper.cameraUpdateEDR(it,value);
                    $("#in-edr").val("");
                }else{
                    //alert("请输入边缘呈现参数！");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请输入边缘呈现参数！");
                }
                break;
            case 5:
                //保存融合参数
                var fs=$("#in-fs").val();
                var fr=$("#in-fr").val();
                var fl=$("#in-fl").val();
                var ft=$("#in-ft").val();
                if(!fs){
                    //alert("请输入融合参数Ｓ");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请输入融合参数Ｓ");
                    return;
                }
                if(!fr){
                    //alert("请输入融合参数R");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请输入融合参数R");
                    return;
                }
                if(!fl){
                    //alert("请输入融合参数L");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请输入融合参数L");
                    return;
                }
                if(!ft){
                    //alert("请输入融合参数T");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请输入融合参数T");
                    return;
                }
                cameraHelper.saveFusionConfig(it,fs,fr,fl,ft);
                $("#in-fs").val("");
                $("#in-fr").val("");
                $("#in-fl").val("");
                $("#in-ft").val("");
                break;
            case 6:
                //温度校准
                if(it.id==="in-file"){
                    cameraHelper.cameraTemperatureCalibration(it);
                }else{
                    $("#in-file").click();
                }
                break;
            case 7:
                var value=$("#in-dev").val();
                if(value){
                    cameraHelper.updateDeviceNumber(it);
                    $("#in-dev").val("");
                }else{
                    //alert("请输入设备号！");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请输入设备号！");
                }
                break;
            case 8:
                var na=$("#in-na").val();
                var pw=$("#in-pw").val();
                if(!na){
                    //alert("请输入ＷｉＦｉ名称");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请输入WIFI名称");
                    return;
                }
                if(!pw){
                    alert("请输入ＷｉＦｉ密码");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请输入WIFI密码");
                    return;
                }
                cameraHelper.setWiFi(it,na,pw);
                $("#in-na").val("");
                $("#in-pw").val("");
                break;
            case 9:
                var value=$("#in-ip").val();
                if(value){
                    cameraHelper.saveCloudServerIP(it);
                    $("#in-ip").val("");
                }else{
                    //alert("请输入云地址！");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请输入云地址！");
                }
                break;
            case 10:
                //设置辐射率
                var value=$("#sel-em").val();
                if(value){
                    cameraHelper.setEmissivity(it,value);
                    $("#sel-em").val("");
                }else {
                    //alert("请选取辐射率！");
                    cameraHelper.showToast(cameraHelper.toastList.INFO,"请选取辐射率！");
                }
                break;
        }
    }else{
        //alert("请先选择一个设备！");
        cameraHelper.showToast(cameraHelper.toastList.WARNING,"请先选择一个设备！");
    }
}

/**
 * 监听摄像机抓怕按钮
 * @param it 元素
 */
//TODO 增加进度条
function onCameraCapture(it){
    if(cameraHelper.currentCamera.building){
        cameraHelper.cameraCapture(it);
    }else{
        //alert("请选择一个设备间");
        cameraHelper.showToast(cameraHelper.toastList.WARNING,"请选择一个设备间");
    }
}

/**
 * 监听摄像机抓怕按钮
 * @param it 元素
 */
//TODO 增加进度条
function enableCameraCapture(it){
    if(cameraHelper.currentCamera.code){
        cameraHelper.enableCameraCapture(it);
    }else{
        //alert("请选择一个设备间");
        cameraHelper.showToast(cameraHelper.toastList.WARNING,"请选择一个设备");
    }
}

/**
 * 监听摄像机抓怕按钮
 * @param it 元素
 */
//TODO 增加进度条
function closeCameraCapture(it){
    if(cameraHelper.currentCamera.code){
        cameraHelper.closeCameraCapture(it);
    }else{
        //alert("请选择一个设备间");
        cameraHelper.showToast(cameraHelper.toastList.WARNING,"请选择一个设备");
    }
}


/**
 * 监听摄像机抓怕按钮
 * @param it 元素
 */
//TODO 增加进度条
function onCameraCaptureSP(it){
    if(cameraHelper.currentCamera.onFocusPoint){
        cameraHelper.cameraCaptureSinglePoint(it);
    }else{
        //alert("请选择一个设备间");
        cameraHelper.showToast(cameraHelper.toastList.WARNING,"请选择一个预设点再抓拍");
    }
}

function onSaveRegionButtonClick() {
    var isOk=canvasHelper.saveCurrentRegion();
    if(isOk){
        $("#save-region").attr("disabled",true);
        $("#undo-region").attr("disabled",true);
        $("#redo-region").attr("disabled",true);
        $("#fresh-region").removeAttr("disabled");
        $("#empty-region").removeAttr("disabled");
        $("#delete-region").removeAttr("disabled");
        $("#submit-region").removeAttr("disabled");
        cameraHelper.showToast(cameraHelper.toastList.SUCCESS,"保存成功！");
    }else{
        //alert("保存当前区域失败！");
        cameraHelper.showToast(cameraHelper.toastList.ERROR,"保存当前区域失败！");
    }
}

function onFreshButtonClick(){
    canvasHelper.freshCanvasRegion();
    $("#save-region").attr("disabled",true);
    $("#undo-region").attr("disabled",true);
}

function onRegionSelectChange(){
    if(!canvasHelper.currentRegionSaveStatus){
        //TODO 改为模态框
    	//var isSave = confirm("是否保存当前区域？");
//        if(isSave){
//            onSaveRegionButtonClick();
//        }else{
//            onFreshButtonClick();
//        }
         $("#mo-ok").attr("onclick","onSaveRegionButtonClick()");
         $("#mo-no").attr("onclick","onFreshButtonClick()");
         $("#mo-title").text("提示:");
    	 $("#mo-body").text("在切换新的图案类型前，你是否要保存当前区域？");
    	 $("#mo-ask").click();
    }
}

function onCanvasClick(){
    if(canvasHelper.controlMode===canvasHelper.modeList.VIEW){
        return cameraHelper.showToast(cameraHelper.toastList.WARNING,"请打开编辑模式！");
        //return alert("请打开编辑模式！");
    }
    if(!cameraHelper.currentCamera.onFocusPoint){
        return cameraHelper.showToast(cameraHelper.toastList.WARNING,"请选取一个预设点！");
        //return alert("请选取一个预设点！");
    }
    if(!canvasHelper.currentRegion){
        var flag=parseInt($("#region-flag").val());
        var sColor=$("#spot-color").val();
        var lColor=$("#line-color").val();
        var isOk=false;
        switch (flag) {
            case 0:
                isOk=canvasHelper.createCurrentRegion(canvasHelper.typeList.SPOT,sColor,lColor);
                break;
            case 1:
                isOk=canvasHelper.createCurrentRegion(canvasHelper.typeList.LINE,sColor,lColor);
                break;
            case 2:
                isOk=canvasHelper.createCurrentRegion(canvasHelper.typeList.SHAPE,sColor,lColor);
                break;
        }
        if(isOk){
            $("#save-region").removeAttr("disabled");
        }else{
            //alert("新建区域失败！");
            cameraHelper.showToast(cameraHelper.toastList.ERROR,"新建区域失败！");
            return;
        }
    }
    canvasHelper.updateCurrentRegion();
    $("#undo-region").removeAttr("disabled");
}

function onUndoButtonClick() {
    if(!canvasHelper.undoCurrentRegion()){
        $("#undo-region").attr("disabled",true);
    }
    $("#redo-region").removeAttr("disabled");
}

function onRedoButtonClick() {
    if(!canvasHelper.redoCurrentRegion()){
        $("#redo-region").attr("disabled",true);
    }
    $("#undo-region").removeAttr("disabled");
}

function onDeleteRegionButtonClick(){
    if(!canvasHelper.deleteRegion()){
        $("#delete-region").attr("disabled",true);
    }
    $("#recover-region").removeAttr("disabled");
    $("#undo-region").attr("disabled",true);
    $("#redo-region").attr("disabled",true);
    $("#save-region").attr("disabled",true);
}

function onRecoverRegionButtonClick(){
    if(!canvasHelper.recoverRegion()){
        $("#recover-region").attr("disabled",true);
    }
    $("#delete-region").removeAttr("disabled");
    $("#undo-region").attr("disabled",true);
    $("#redo-region").attr("disabled",true);
}

function onEmptyRegionButtonClick(){
    canvasHelper.clearAllRegion();
    $("#save-region").attr("disabled",true);
    $("#delete-region").attr("disabled",true);
    $("#recover-region").attr("disabled",true);
    $("#undo-region").attr("disabled",true);
    $("#redo-region").attr("disabled",true);
}

function onSubmitRegionButtonClick(){
	if(!cameraHelper.checkSensor()){
		return cameraHelper.showToast(cameraHelper.toastList.WARNING,"请先选择一个设备！");
	}
	$("#mo-no").removeAttr("onclick");
    if(!canvasHelper.currentRegionSaveStatus){
    	$("#mo-ok").attr("onclick","moOkSubmit(false)");
        $("#mo-title").text("提示:");
    	$("#mo-body").text("当前区域未保存，是否保存？");
    	$("#mo-ask").click();
    }else{
    	$("#mo-ok").attr("onclick","moOkSubmit(true)");
        $("#mo-title").text("提示:");
    	$("#mo-body").text("你确定要提交当前区域吗？");
    	$("#mo-ask").click();
    }
}

function moOkSubmit(isSave){
	if(!isSave){
	   onSaveRegionButtonClick();
	}
	cameraHelper.updatePlatformPointRegion("#platform_point",canvasHelper);
}

function onRegionModeChange(it) {
    var mode=parseInt($(it).val());
    switch (mode) {
        case 0:
            canvasHelper.setControlMode(canvasHelper.modeList.VIEW);
            canvasHelper.log("onRegionModeChange -> VIEW mode:"+mode);
            $("#region-flag").attr("disabled","disabled");
            $("#spot-color").attr("disabled","disabled");
            $("#line-color").attr("disabled","disabled");
            $("#fresh-region").attr("disabled",true);//还原
            $("#empty-region").attr("disabled",true); //清空区域
            $("#delete-region").attr("disabled",true);//删除区域
            $("#submit-region").attr("disabled",true); //提交区域
            $("#save-region").attr("disabled",true); //保存
            $("#delete-region").attr("disabled",true);
            $("#recover-region").attr("disabled",true); //恢复区域
            $("#undo-region").attr("disabled",true);//撤销
            $("#redo-region").attr("disabled",true); //重做
            break;
        case 1:
            canvasHelper.setControlMode(canvasHelper.modeList.EDIT);
            canvasHelper.log("onRegionModeChange -> EDIT mode:"+mode);
            $("#region-flag").removeAttr("disabled");
            $("#spot-color").removeAttr("disabled");
            $("#line-color").removeAttr("disabled");
            if(canvasHelper.regionList.length>0){
                $("#fresh-region").removeAttr("disabled");
                $("#empty-region").removeAttr("disabled");
                $("#delete-region").removeAttr("disabled");
                $("#submit-region").removeAttr("disabled");
            }
            if(canvasHelper.currentSpotCount>0){
                $("#undo-region").removeAttr("disabled");
                $("#save-region").removeAttr("disabled");
            }
            if(canvasHelper.trashSpotList.length>0){
                $("#redo-region").removeAttr("disabled");
            }
            break;
    }
}
// TODO 完成预设点调用
function onPointPresentCalledButtonClick() {
	if(!cameraHelper.checkSensor()){
		return cameraHelper.showToast(cameraHelper.toastList.WARNING,"请先选择一个设备！");
	}
    var point=cameraHelper.currentCamera.onFocusPoint;
    if(point){
    	cameraHelper.pointPresentCalled();
    }else{
    	//alert("请选取一个预设点！");
    	cameraHelper.showToast(cameraHelper.toastList.WARNING,"请选取一个预设点！");
    }
}

//TODO 完成预设点删除
function onPointPresentDeleteButtonClick(it) {
	if(cameraHelper.currentCamera.onFocusPoint){
        cameraHelper.cameraCaptureDeletePoint(it);
    }else{
        //alert("请选择一个设备间");
        cameraHelper.showToast(cameraHelper.toastList.WARNING,"请选择一个预设点再抓拍");
    }
}


