


var form;
var page=1,numbers=5;
var dataAllLength='';
var temp='',warn='',areaname='',username='',userid='',areaCity='';
var areaid='',fenbuid='',ywbid='',stationid='',buildingid='',devicetype='',machineid='',deviceid='';
 // 数据请求
$(function () {
        
        var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
        var datas = $.parseJSON(Arr);
        userid=datas.Userid;
        username=datas.Username;
        areaname=datas.Areaname;
        areaCity=datas.City;
        var fenbuname=datas.Fenbuname;
        var ywbname=datas.Ywbname;
        var usertype=datas.Usertype;  //userpower表示用户等级，0总公司用户，1工区用户，2运维班用户
        var admunUser="超级管理员";
        var stationid ='';
        if(usertype==3){
                $("#adminShow1").show();
                $("#adminShow2").show();

                // 头部
                $("#header_fenbu").html(admunUser);

                $("#missingImg").show();
                shebeiStatus_backstage();
                $("#admBlockUpdate").show();
        }else{
                // 头部
                $("#header_fenbu").html(fenbuname);
                $("#header_area").html(areaname);
        }
        


        index_headerWeather(areaCity); //城市气温和预警信息，


        var now = new Date();
        var hour = now.getHours();//得到小时
        // index_topLeft_module1Wensheng(userid,hour);//板块一，温升设备，
          
        index_topLeft_module1Gaowen(userid);//板块一，设备最高温，
        // index_topLeft_module2(userid); //测温告警统计信息信息
        index_topLeft_module2G(userid);
        index_topLeft_module3(userid); //周期测温峰值统计
        // index_topLeft_module4(userid); //地区环温与设备最高温对比
        index_topLeft_module4Week(userid);//一周设备温度统计
        index_mediaTop_right(userid,stationid); //实时检测设备列表
        // index_mediaCenter_right(userid);//本月超80℃的设备统计(24个)
        index_bottomItem_module(userid,page,numbers);// 获取重点检测设备列表

        

         
        // 头部选择  
        // top_selAll(userid);
        

        
        // 上一页
        $(".button-prev").click(function(){
                page--;
                if(page==0){
                        
                        $(this).find("img").attr("src","images/arrow_up.png");
                        page=page+1;
                        return false;
                        
                }else{
                        $(".button-next").find("img").attr("src","images/arrow_down.png");
                        index_bottomItem_module(userid,page,numbers);
                }
                
        });
        // 下一页
        $(".button-next").click(function(){
                if(page==dataAllLength){
                        $(this).find("img").attr("src","images/arrow_down2.png");
                        return false;
                }else{
                        $(".button-prev").find("img").attr("src","images/arrow_up2.png")
                        page++;
                        index_bottomItem_module(userid,page,numbers);
                }
                
                
               
        });


        // 数据请求 退出
        $("#loginout").on('click',function(){
                loginout(username);
        });
         /* 定时器  
        * 间隔1秒检测是否长时间未操作页面  
        */
        window.setInterval(toLoginPage, 1000);

        var startTime = new Date().getTime();
        var currentTime = new Date().getTime();
        var timeOut = 360 * 60 * 1000; //设置超时时间： 6小时(360分钟)
        
        /* 鼠标移动事件 */
        $(document).mouseover(function(){
                startTime = new Date().getTime(); //更新操作时间
        
        });
        
        function toLoginPage(){
                currentTime = new Date().getTime(); //更新当前时间
                if(currentTime - startTime > timeOut){ //判断是否超时
                        console.log("超时")
                        window.close();//关闭当前页
                        loginout(username);
                }
        }
        
       
        

});
// function top_selAll(userid){
        
//         var area='',manageArea='',
//                 fenbu='<span data-fenbuid="全部" data-fenbuname="全部" class="select">全部</span>',
//                 ywb='<span data-ywbid="全部" data-ywbname="全部" class="select">全部</span>',
//                 bdz='<span data-stationid="全部" data-stationname="全部"  class="select">全部</span>',
//                 sbq='<span data-buildingid="全部" data-buildingname="全部" class="select">全部</span>',
//                 machine='<span data-machineid="全部" data-machinename="全部"  class="select">全部</span>',
//                 deviceMachine='',ysd='',device='', 
//                 device_area='',
//                 device_fenbu='',
//                 device_ywb='',
//                 device_bdz='',
//                 shebei='<span class="select">全部</span>',device_sbq='';

//         $.ajax({
//                 type:'get',
//                 url:baseUrl+'UserServices/User_Services.asmx/x_getAllInforByUser',
//                 dataType:'JSON',  
//                 data:{
//                         userid:userid,
//                 },
//                 success:function(data){
                        
//                         $(".loding_bg").hide();
//                         //工区
//                         for(let item of data.Arealist){
//                                 area+=`<li data-areaid="${item[0]}" data-areaname="${item[1]}">${item[1]}</li>`;
                                
//                                 // 设备管理
//                                 manageArea+=`<span data-areaid="${item[0]}" data-areaname="${item[1]}">${item[1]}</span>`;
                        
//                                 device_area+=`<li class="li-item">
//                                                 <div class="item_left fl"><span>${item[1]}</span></div>
//                                                 <div class="item_right fr">
//                                                 <a class="area_event ac_edit edit1 layui-btn layui-btn-xs" data-areaid="${item[0]}" data-event="edit">
//                                                         <i class="layui-icon layui-icon-edit"></i>
//                                                 </a>
//                                                 <a class="area_event ac_del del1 layui-btn layui-btn-xs" data-areaid="${item[0]}" data-event="del">
//                                                         <i class="layui-icon layui-icon-delete"></i>
//                                                 </a>
//                                                 </div>
//                                         </li><div class="clear"></div>`;
//                         };
                        
//                         //分部
//                         for(let item of data.Fenbulist){
//                                 fenbu+=`<span data-fenbuid="${item[0]}" data-fenbuname="${item[1]}">${item[1]}</span>`;
                                
//                                 // 设备管理
//                                 device_fenbu+=`<li class="li-item">
//                                                 <div class="item_left fl"><span>${item[1]}</span></div>
//                                                 <div class="item_right fr">
//                                                 <a class="fenbu_event ac_edit edit2 layui-btn layui-btn-xs" data-fenbuid="${item[0]}" data-event="edit">
//                                                         <i class="layui-icon layui-icon-edit"></i>
//                                                 </a>
//                                                 <a class="fenbu_event ac_del del2 layui-btn layui-btn-xs" data-fenbuid="${item[0]}" data-event="del">
//                                                         <i class="layui-icon layui-icon-delete"></i>
//                                                 </a>
//                                                 </div>
//                                         </li><div class="clear"></div>`;
//                         };
//                         //运维班
//                         for(let item of data.Ywblist){
//                                 ywb+=`<span data-ywbid="${item[0]}" data-ywbname="${item[1]}">${item[1]}</span>`;
//                                 // 设备管理
//                                 device_ywb+=`<li class="li-item">
//                                                 <div class="item_left fl"><span>${item[1]}</span></div>
//                                                 <div class="item_right fr">
//                                                 <a class="ywb_event ac_edit edit3 layui-btn layui-btn-xs" data-ywbid="${item[0]}" data-event="edit">
//                                                         <i class="layui-icon layui-icon-edit"></i>
//                                                 </a>
//                                                 <a class="ywb_event ac_del del3 layui-btn layui-btn-xs" data-ywbid="${item[0]}" data-event="del">
//                                                         <i class="layui-icon layui-icon-delete"></i>
//                                                 </a>
//                                                 </div>
//                                         </li><div class="clear"></div>`;
                                
//                         };
//                         //变电站
//                         for(let item of data.Stationlist){
//                                 bdz+=`<span data-stationid="${item[0]}" data-stationname="${item[1]}">${item[1]}</span>`;
                                

//                                 // 设备管理
//                                 device_bdz+=`<li class="li-item">
//                                                 <div class="item_left fl"><span>${item[1]}</span></div>
//                                                 <div class="item_right fr">
//                                                 <a class="bdz_event ac_edit edit4 layui-btn layui-btn-xs" data-stationid="${item[0]}" data-event="edit">
//                                                         <i class="layui-icon layui-icon-edit"></i>
//                                                 </a>
//                                                 <a class="bdz_event ac_del del4 layui-btn layui-btn-xs" data-stationid="${item[0]}" data-event="del">
//                                                         <i class="layui-icon layui-icon-delete"></i>
//                                                 </a>
//                                                 </div>
//                                         </li><div class="clear"></div>`;
//                         };
//                         //设备区
//                         for(let item of data.Buildinglist){
//                             sbq+=`<span data-buildingid="${item[0]}" data-buildingname="${item[1]}">${item[1]}</span>`;
                                
//                             // 设备管理
//                             device_sbq+=`<li class="li-item">
//                                         <div class="item_left fl"><span>${item[1]}</span></div>
//                                         <div class="item_right fr">
//                                         <a class="sbj_event ac_edit edit5 layui-btn layui-btn-xs" data-buildingid="${item[0]}" data-event="edit">
//                                                 <i class="layui-icon layui-icon-edit"></i>
//                                         </a>
//                                         <a class="sbj_event ac_del del5 layui-btn layui-btn-xs" data-buildingid="${item[0]}" data-event="del">
//                                                 <i class="layui-icon layui-icon-delete"></i>
//                                         </a>
//                                         </div>
//                                 </li><div class="clear"></div>`;
                        
//                         };
//                         //监视设备
//                         for(let item of data.Machinelist){
//                                 machine+=`<span data-machineid="${item[0]}" data-machinename="${item[1]}">${item[1]}</span>`;
//                         };

//                         //监视设备
//                         for(let item of data.Machinelist){
//                                 deviceMachine+=`<li class="li-item">
//                                         <div class="item_left fl"  data-machineid="${item[0]}"><span>${item[1]}</span></div><div class="item_right fr">
//                                         <a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-machineid="${item[0]}" data-event="edit">
//                                                 <i class="layui-icon layui-icon-edit"></i>
//                                         </a>
//                                         <a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-machineid="${item[0]}" data-event="del">
//                                                 <i class="layui-icon layui-icon-delete"></i>
//                                         </a>
//                                         </div>
//                                         </li><div class="clear"></div>`;
//                         };
//                         //预设点
//                         for(let item of data.Ysdlist){
//                                 ysd+=`<li class="li-item">
//                                         <div class="item_left fl"  data-ysdid="${item[0]}"><span>${item[1]}</span></div><div class="item_right fr">
//                                         <a class="ysd_event ac_edit edit5 layui-btn layui-btn-xs" data-ysdid="${item[0]}" data-event="edit">
//                                                 <i class="layui-icon layui-icon-edit"></i>
//                                         </a>
//                                         <a class="ysd_event ac_del del5 layui-btn layui-btn-xs" data-ysdid="${item[0]}" data-event="del">
//                                                 <i class="layui-icon layui-icon-delete"></i>
//                                         </a>
//                                         </div>
//                                         </li><div class="clear"></div>`;
//                         };
//                         //监测设备
//                         for(let item of data.Devicelist){
//                                 shebei+=`<span data-deviceid="${item[0]}" data-devicename="${item[1]}">${item[1]}</span>`;

//                                 device+=`<li class="li-item">
//                                         <div class="item_left fl" data-deviceid="${item[0]}"><span>${item[1]}</span></div><div class="item_right fr">
//                                         <a class="shebei_event ac_edit edit5 layui-btn layui-btn-xs" data-deviceid="${item[0]}" data-event="edit">
//                                                 <i class="layui-icon layui-icon-edit"></i>
//                                         </a>
//                                         <a class="shebei_event ac_del del5 layui-btn layui-btn-xs" data-deviceid="${item[0]}" data-event="del">
//                                                 <i class="layui-icon layui-icon-delete"></i>
//                                         </a>
//                                         </div>
//                                         </li><div class="clear"></div>`;
//                         };
//                         $("#tab").html(area);
//                         $("#fenbuDD").html(fenbu);
//                         $("#ywbDD").html(ywb);
//                         $("#bdzDD").html(bdz);
//                         $("#sbqDD").html(sbq);
//                         $("#jianshiDD").html(machine);
//                         $("#status_shebeiDD").html(machine);
//                         $("#sheibeiDD").html(shebei);

//                         // // 设备管理
//                         // $("#manageArea").html(manageArea);
//                         // $("#fenbu_ulDD").html(fenbu);
//                         // $("#ywb_ulDD").html(ywb);
//                         // $("#bdz_ulDD").html(bdz);
//                         // $("#sbq_ulDD").html(sbq);

//                         // $("#jkq_ul").html(deviceMachine);
//                         // $("#ysd_ul").html(ysd);
//                         // $("#shebei_ul").html(device);

//                         // // 设备管理点击
//                         // $("#gq_ul").html(device_area);
//                         // $("#fenbu_ul").html(device_fenbu);
//                         // $("#ywb_ul").html(device_ywb);
//                         // $("#bdz_ul").html(device_bdz);
//                         // $("#sbq_ul").html(device_sbq);

                        
//                 },
//                 error:function(err){
//                         console.log(err)
//                 }

//         });
// };



// 设备管理
function top_selDeviceManage(userid,areaTem,fenbuTem,ywbTem,bdzTem,sbqTem){
        var manageArea='',
                fenbu='',
                ywb='',
                bdz='',
                sbq='',
                deviceMachine='',ysd='',device='', 
                device_area='',
                device_fenbu='',
                device_ywb='',
                device_bdz='',device_sbq='';

        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/x_getAllInforByUser',
                dataType:'JSON',  
                data:{
                        userid:userid,
                },
                success:function(data){
                        
                        $(".loding_bg").hide();
                        //工区
                        for(let item of data.Arealist){
                                
                                // 设备管理
                                manageArea+=`<span data-areaid="${item[0]}" data-areaname="${item[1]}">${item[1]}</span>`;
                        
                                device_area+=`<li class="li-item">
                                                <div  data-areaid="${item[0]}" class="item_left fl`
                                                if(item[0]==areaTem){
                                                        device_area+=` select`;
                                                }
                                                device_area+=`"><span>${item[1]}</span></div>
                                                <div class="item_right fr">
                                                <a class="area_event ac_edit edit1 layui-btn layui-btn-xs" data-areaid="${item[0]}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="area_event ac_del del1 layui-btn layui-btn-xs" data-areaid="${item[0]}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                </div>
                                        </li><div class="clear"></div>`;
                        };
                        
                        //分部
                        for(let item of data.Fenbulist){
                                fenbu+=`<span data-fenbuid="${item[0]}" data-fenbuname="${item[1]}">${item[1]}</span>`;
                                
                                // 设备管理
                                device_fenbu+=`<li class="li-item">
                                                <div  data-fenbuid="${item[0]}" class="item_left fl`
                                                if(item[0]==fenbuTem){
                                                        device_fenbu+=` select`;
                                                }
                                                device_fenbu+=`"><span>${item[1]}</span></div>
                                                <div class="item_right fr">
                                                <a class="fenbu_event ac_edit edit2 layui-btn layui-btn-xs" data-fenbuid="${item[0]}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="fenbu_event ac_del del2 layui-btn layui-btn-xs" data-fenbuid="${item[0]}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                </div>
                                        </li><div class="clear"></div>`;
                        };
                        //运维班
                        for(let item of data.Ywblist){
                                ywb+=`<span data-ywbid="${item[0]}" data-ywbname="${item[1]}">${item[1]}</span>`;
                                // 设备管理
                                device_ywb+=`<li class="li-item">
                                                <div  data-ywbid="${item[0]}" class="item_left fl`
                                                if(item[0]==ywbTem){
                                                        device_ywb+=` select`;
                                                }
                                                device_ywb+=`"><span>${item[1]}</span></div>
                                                <div class="item_right fr">
                                                <a class="ywb_event ac_edit edit3 layui-btn layui-btn-xs" data-ywbid="${item[0]}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="ywb_event ac_del del3 layui-btn layui-btn-xs" data-ywbid="${item[0]}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                </div>
                                        </li><div class="clear"></div>`;
                                
                        };
                        //变电站
                        for(let item of data.Stationlist){
                                bdz+=`<span data-stationid="${item[0]}" data-stationname="${item[1]}">${item[1]}</span>`;
                                

                                // 设备管理
                                device_bdz+=`<li class="li-item">
                                                <div  data-stationid="${item[0]}" class="item_left fl`
                                                if(item[0]==bdzTem){
                                                        device_bdz+=` select`;
                                                }
                                                device_bdz+=`"><span>${item[1]}</span></div>
                                                <div class="item_right fr">
                                                <a class="bdz_event ac_edit edit4 layui-btn layui-btn-xs" data-stationid="${item[0]}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="bdz_event ac_del del4 layui-btn layui-btn-xs" data-stationid="${item[0]}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                </div>
                                        </li><div class="clear"></div>`;
                        };
                        //设备区
                        for(let item of data.Buildinglist){
                            sbq+=`<span data-buildingid="${item[0]}" data-buildingname="${item[1]}">${item[1]}</span>`;
                                
                            // 设备管理
                            device_sbq+=`<li class="li-item">
                                        <div  data-buildingid="${item[0]}" class="item_left fl`
                                        if(item[0]==sbqTem){
                                                device_sbq+=` select`;
                                        }
                                        device_sbq+=`"><span>${item[1]}</span></div>
                                        <div class="item_right fr">
                                        <a class="sbj_event ac_edit edit5 layui-btn layui-btn-xs" data-buildingid="${item[0]}" data-event="edit">
                                                <i class="layui-icon layui-icon-edit"></i>
                                        </a>
                                        <a class="sbj_event ac_del del5 layui-btn layui-btn-xs" data-buildingid="${item[0]}" data-event="del">
                                                <i class="layui-icon layui-icon-delete"></i>
                                        </a>
                                        </div>
                                </li><div class="clear"></div>`;
                        
                        };
                        
                        //监视设备
                        for(let item of data.Machinelist){
                                deviceMachine+=`<li class="li-item">
                                        <div class="item_left fl"  data-machineid="${item[0]}"><span>${item[1]}</span></div><div class="item_right fr">
                                        <a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-machineid="${item[0]}" data-event="edit">
                                                <i class="layui-icon layui-icon-edit"></i>
                                        </a>
                                        <a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-machineid="${item[0]}" data-event="del">
                                                <i class="layui-icon layui-icon-delete"></i>
                                        </a>
                                        </div>
                                        </li><div class="clear"></div>`;
                        };
                        //预设点
                        for(let item of data.Ysdlist){
                                ysd+=`<li class="li-item">
                                        <div class="item_left fl"  data-ysdid="${item[0]}"><span>${item[1]}</span></div>
                                        <div class="upDownTZ fl"><button class="btnUp" data-ysdid="${item[0]}"></button><button class="btnDown" data-ysdid="${item[0]}"></button></div>
                                        <div class="item_right fr">
                                        <a class="ysd_event ac_edit edit5 layui-btn layui-btn-xs" data-ysdid="${item[0]}" data-event="edit">
                                                <i class="layui-icon layui-icon-edit"></i>
                                        </a>
                                        <a class="ysd_event ac_del del5 layui-btn layui-btn-xs" data-ysdid="${item[0]}" data-event="del">
                                                <i class="layui-icon layui-icon-delete"></i>
                                        </a>
                                        </div>
                                        </li><div class="clear"></div>`;
                        };
                        //监测设备
                        for(let item of data.Devicelist){
                                device+=`<li class="li-item">
                                        <div class="item_left fl" data-deviceid="${item[0]}"><span>${item[1]}</span></div><div class="item_right fr">
                                        <a class="shebei_event ac_edit edit5 layui-btn layui-btn-xs" data-deviceid="${item[0]}" data-event="edit">
                                                <i class="layui-icon layui-icon-edit"></i>
                                        </a>
                                        <a class="shebei_event ac_del del5 layui-btn layui-btn-xs" data-deviceid="${item[0]}" data-event="del">
                                                <i class="layui-icon layui-icon-delete"></i>
                                        </a>
                                        </div>
                                        </li><div class="clear"></div>`;
                        };
                        

                        // 设备管理
                        $("#manageArea").html(manageArea);
                        $("#fenbu_ulDD").html(fenbu);
                        $("#ywb_ulDD").html(ywb);
                        $("#bdz_ulDD").html(bdz);
                        $("#sbq_ulDD").html(sbq);

                        $("#jkq_ul").html(deviceMachine);
                        $("#ysd_ul").html(ysd);
                        $("#shebei_ul").html(device);

                        // 设备管理点击
                        $("#gq_ul").html(device_area);
                        $("#fenbu_ul").html(device_fenbu);
                        $("#ywb_ul").html(device_ywb);
                        $("#bdz_ul").html(device_bdz);
                        $("#sbq_ul").html(device_sbq);

                        // 实时视频修改点击
                        $("#gqEdit_ul").html(device_area);
                        $("#fenbuEdit_ul").html(device_fenbu);
                        $("#ywbEdit_ul").html(device_ywb);
                        $("#bdzEdit_ul").html(device_bdz);
                        $("#sbqEdit_ul").html(device_sbq);
                        
                },
                error:function(err){
                        console.log(err)
                }

        });
};

function top_selcewen(userid,areaid_moren,fenbuid_moren,ywbid_moren,stationid_moren){
        
        var area='',fenbu='<span data-fenbuid="全部" data-fenbuname="全部">全部</span>',
                ywb='<span data-ywbid="全部" data-ywbname="全部">全部</span>',
                bdz='<span data-stationid="全部" data-stationname="全部">全部</span>',
                sbq='<span data-buildingid="全部" data-buildingname="全部" class="select">全部</span>',
                machine='<span data-machineid="全部" data-machinename="全部"  class="select">全部</span>',
                shebei='<span class="select">全部</span>';

        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/XXX_geStationParam',
                dataType:'JSON',  
                data:{
                        userid:userid,
                        station_id:stationid_moren,
                },
                success:function(data){
                        $(".loding_bg").hide();
                        //工区
                        for(let item of data.Arealist){
                                if(item[0]!=areaid_moren){
                                        area+=`<li data-areaid="${item[0]}" data-areaname="${item[1]}">${item[1]}</li>`;
                                };
                                if(item[0]==areaid_moren){
                                        
                                        area+=`<li  class="table_active" data-areaid="${item[0]}" data-areaname="${item[1]}">${item[1]}</li>`;
                                        $(this).siblings().removeClass("table_active");
                                };
                               
                        };
                        
                        //分部
                        for(let item of data.Fenbulist){
                                if(item[0]!=fenbuid_moren){
                                        fenbu+=`<span data-fenbuid="${item[0]}" data-fenbuname="${item[1]}">${item[1]}</span>`;
                                };
                                if(item[0]==fenbuid_moren){
                                        fenbu+=`<span  class="select" data-fenbuid="${item[0]}" data-fenbuname="${item[1]}">${item[1]}</span>`;
                                };
                                
                        };
                        //运维班
                        for(let item of data.Ywblist){
                                if(item[0]!=ywbid_moren){
                                        ywb+=`<span data-ywbid="${item[0]}" data-ywbname="${item[1]}">${item[1]}</span>`;
                                };
                                if(item[0]==ywbid_moren){
                                        ywb+=`<span  class="select" data-ywbid="${item[0]}" data-ywbname="${item[1]}">${item[1]}</span>`;
                                        $(this).siblings().removeClass("select");
                                };
                               
                                
                        };
                        //变电站
                        for(let item of data.Stationlist){
                                if(item[0]!=stationid_moren){
                                        bdz+=`<span data-stationid="${item[0]}" data-stationname="${item[1]}">${item[1]}</span>`;
                                };
                                if(item[0]==stationid_moren){
                                        bdz+=`<span  class="select" data-stationid="${item[0]}" data-stationname="${item[1]}">${item[1]}</span>`;
                                        $(this).siblings().removeClass("select");
                                };
                                

                               
                        };
                        //设备区
                        for(let item of data.Buildinglist){
                            sbq+=`<span data-buildingid="${item[0]}" data-buildingname="${item[1]}">${item[1]}</span>`;
                        };
                        //监视设备
                        for(let item of data.Machinelist){
                                machine+=`<span data-machineid="${item[0]}" data-machinename="${item[1]}">${item[1]}</span>`;
                        };

                        
                        
                        $("#tabcw").html(area);
                        $("#fenbuDDcw").html(fenbu);
                        $("#ywbDDcw").html(ywb);
                        $("#bdzDDcw").html(bdz);
                        $("#sbqDDcw").html(sbq);
                        $("#jianshiDDcw").html(machine);
                        // $("#sheibeiDDcw").html(shebei);

                },
                error:function(err){
                        console.log(err)
                }

        });
};
// function top_seldevice(userid,areaid,fenbuid,ywbid,stationid,buildingid,deviceid,machineid){
        
//         var area='',fenbu='<span data-fenbuid="全部" data-fenbuname="全部">全部</span>',
//                 ywb='<span data-ywbid="全部" data-ywbname="全部">全部</span>',
//                 bdz='<span data-stationid="全部" data-stationname="全部" >全部</span>',
//                 sbq='<span data-buildingid="全部" data-buildingname="全部"">全部</span>',
//                 machine='<span data-machineid="全部" data-machinename="全部">全部</span>',
//                 shebei='<span>全部</span>';

//         $.ajax({
//                 type:'get',
//                 url:baseUrl+'UserServices/User_Services.asmx/x_getAllInforByUser',
//                 dataType:'JSON',  
//                 data:{
//                         userid:userid,
//                 },
//                 success:function(data){
                        
//                         $(".loding_bg").hide();
//                         //工区
//                         for(let item of data.Arealist){
//                                 if(item[0]!=areaid){
//                                         area+=`<li data-areaid="${item[0]}" data-areaname="${item[1]}">${item[1]}</li>`;
//                                 }
//                                 if(item[0]==areaid){
//                                         area+=`<li  class="table_active" data-areaid="${item[0]}" data-areaname="${item[1]}">${item[1]}</li>`;
//                                 };
                               
//                         };
                        
//                         //分部
//                         for(let item of data.Fenbulist){
//                                 if(item[0]!=fenbuid){
//                                         fenbu+=`<span data-fenbuid="${item[0]}" data-fenbuname="${item[1]}">${item[1]}</span>`;
//                                 };
//                                 if(item[0]==fenbuid){
//                                         fenbu+=`<span  class="select" data-fenbuid="${item[0]}" data-fenbuname="${item[1]}">${item[1]}</span>`;
//                                 };
                                
                               
//                         };
//                         //运维班
//                         for(let item of data.Ywblist){
//                                 if(item[0]!=ywbid){
//                                         ywb+=`<span data-ywbid="${item[0]}" data-ywbname="${item[1]}">${item[1]}</span>`;
//                                 };
//                                 if(item[0]==ywbid){
//                                         ywb+=`<span class="select" data-ywbid="${item[0]}" data-ywbname="${item[1]}">${item[1]}</span>`;
//                                 };
                                
//                         };
//                         //变电站
//                         for(let item of data.Stationlist){
//                                 if(item[0]!=stationid){
//                                         bdz+=`<span data-stationid="${item[0]}" data-stationname="${item[1]}">${item[1]}</span>`;
//                                 };
//                                 if(item[0]==stationid){
//                                         bdz+=`<span class="select" data-stationid="${item[0]}" data-stationname="${item[1]}">${item[1]}</span>`;
//                                 };
                               
//                         };
//                         //设备区
//                         for(let item of data.Buildinglist){
//                                 if(item[0]!=buildingid){
//                                         sbq+=`<span data-buildingid="${item[0]}" data-buildingname="${item[1]}">${item[1]}</span>`;
//                                 };
//                                 if(item[0]==buildingid){
//                                         sbq+=`<span class="select" data-buildingid="${item[0]}" data-buildingname="${item[1]}">${item[1]}</span>`;
//                                 };
                            
//                         };
//                         //监视设备
//                         for(let item of data.Machinelist){
//                                 if(item[0]!=machineid){
//                                         machine+=`<span data-machineid="${item[0]}" data-machinename="${item[1]}">${item[1]}</span>`;
//                                 };
//                                 if(item[0]==machineid){
//                                         machine+=`<span class="select" data-machineid="${item[0]}" data-machinename="${item[1]}">${item[1]}</span>`;
//                                 };
                                
//                         };
//                         //监测设备
//                         for(let item of data.Devicelist){
//                                 if(item[0]!=deviceid){
//                                         shebei+=`<span data-deviceid="${item[0]}" data-devicename="${item[1]}">${item[1]}</span>`;
//                                 };
//                                 if(item[0]==deviceid){
//                                         shebei+=`<span class="select" data-deviceid="${item[0]}" data-devicename="${item[1]}">${item[1]}</span>`;
//                                 };
                                
//                         };
//                         $("#tabdevice").html(area);
//                         $("#fenbuDDdevice").html(fenbu);
//                         $("#ywbDDdevice").html(ywb);
//                         $("#bdzDDdevice").html(bdz);
//                         $("#sbqDDdevice").html(sbq);
//                         $("#jianshiDDdevice").html(machine);
//                         $("#sheibeiDDdevice").html(shebei);

//                 },
//                 error:function(err){
//                         console.log(err)
//                 }

//         });
// }

times=function (nS){
        if(nS!=null && nS!=undefined && nS!=''){
            var now;
            if(nS.length == 10){
                now = new Date(parseInt(nS) * 1000);
            }else if(nS.length == 13){
                now = new Date(parseInt(nS));
            }
            
            var yy = now.getFullYear();     //年
            var mm = fntwo(now.getMonth() + 1,2);     //月
            var dd = fntwo(now.getDate(),2);          //日
            var hh = fntwo(now.getHours(),2);         //时
            var ii = fntwo(now.getMinutes(),2);       //分
            var ss = fntwo(now.getSeconds(),2);       //秒
            return yy+'-'+mm+'-'+dd+' '+hh+':'+ii+':'+ss;
        }else{
            return console.log("传的时间为空") 
        }
        
},
fntwo=function(num, length) {  
        return (num/Math.pow(10,length)).toFixed(length).substr(2);  
};

function loginout(username){
        layui.use(['table','layer'], function(){
                var layer=layui.layer;
                $.ajax({
                        type:'get',
                        url:baseUrl+'JXHService/LoginService/LoginServices.asmx/loginout',
                        dataType:'JSON',
                        data:{
                                username:username,
                        },
                        success:function(data){
                                if(data.State=3){
                                        window.location.href="login.html"
                                        //登出成功的提示与跳转
                                        // layer.msg(data.Msg, {
                                        //         offset: '15px'
                                        //         ,icon: 1
                                        //         ,time: 10000000
                                        // }, function(){
                                                
                                        // });
                                }else{
                                        layer.msg(data.Msg, {
                                                offset: '15px'
                                                ,icon: 1
                                                ,time: 2000
                                        });   
                                }
                        },
                        error:function(err){
                                console.log(err)
                        }
        
                });
        });
}

// 下拉框工区
function sel_areaname(userid){
        
        layui.use(['layer','form'], function(){
                var layer = layui.layer;
                var form = layui.form;
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/a_getAllarea',
                        dataType:'JSON', 
                        data: {
                                userid:userid
                        },
                        success: function (data) {
                                
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' data-areaid='"+data[i].areaid+"'  value='"+data[i].areaname+"'>"+data[i].areaname+"</option>";
                                        }
                                        //用户管理
                                        //工区
                                        $("#user_editArea1").html(optionStr); //修改
                                        $("#user_addArea1").html(optionStr); //添加
                                        //分部
                                        $("#user_editFenbu1").html(optionStr); //修改
                                        $("#user_addFenbu1").html(optionStr); //添加
                                        //运维班
                                        $("#user_editYwb1").html(optionStr); //修改
                                        $("#user_addYwb1").html(optionStr); //添加

                                        // 设备管理
                                        
                                        //分部
                                        $("#device_editFenbu1").html(optionStr); //修改
                                        $("#device_addFenbu1").html(optionStr); //添加
                                        
                                        //运维班
                                        $("#device_editywb1").html(optionStr); //修改
                                        $("#addywb1").html(optionStr); //添加

                                        //变电站
                                        $("#device_editbdz1").html(optionStr); //修改
                                        $("#addbdz1").html(optionStr); //添加
                                        //设备区
                                        $("#device_editsbj1").html(optionStr); //修改
                                        $("#device_addsbj1").html(optionStr); //添加
                                        //监控器（抓拍设备）
                                        $("#device_addjkq1").html(optionStr); //添加
                                        $("#device_editjkq1").html(optionStr); //修改
                                        //预设点
                                        $("#device_addysd1").html(optionStr); //添加
                                        $("#device_editysd1").html(optionStr); //修改
                                        //监测设备
                                        $("#device_addshebei1").html(optionStr); //添加
                                        $("#device_editshebei1").html(optionStr); //修改
                                        
                                }       
                                form.render('select');//需要渲染一下
                        }
                        
                });
        });
};
//下拉框分部
function sel_fenbuname(areaid){
        layui.use(['layer','form'], function(){
                var layer = layui.layer;
                var form = layui.form;
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/b_getfenbuByarea',
                        dataType:'JSON', 
                        data: {
                                areaid:areaid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' data-fenbuid='"+data[i].fenbuid+"' value='"+data[i].fenbuname+"'>"+data[i].fenbuname+"</option>";
                                        }
                                        //用户管理
                                        //工区
                                        $("#user_editArea2").html(optionStr);//修改 
                                        $("#user_addArea2").html(optionStr); //添加
                                        //分部
                                        $("#user_editFenbu2").html(optionStr); //修改
                                        $("#user_addFenbu2").html(optionStr); //添加
                                        //运维班
                                        $("#user_editYwb2").html(optionStr); //修改
                                        $("#user_addYwb2").html(optionStr); //添加


                                        // 设备管理

                                        //运维班
                                        $("#device_editywb2").html(optionStr); //修改
                                        $("#addywb2").html(optionStr); //添加
                                        //变电站
                                        $("#device_editbdz2").html(optionStr); //修改
                                        $("#addbdz2").html(optionStr); //添加
                                        //设备区
                                        $("#device_editsbj2").html(optionStr); //修改
                                        $("#device_addsbj2").html(optionStr); //添加
                                        //监控器（抓拍设备）
                                        $("#device_addjkq2").html(optionStr); //添加
                                        $("#device_editjkq2").html(optionStr); //修改
                                        //预设点
                                        $("#device_addysd2").html(optionStr); //添加
                                        $("#device_editysd2").html(optionStr); //添加
                                        //监测设备
                                        $("#device_addshebei2").html(optionStr); //添加
                                        $("#device_editshebei2").html(optionStr); //修改
                                }
                                form.render('select');//需要渲染一下
                        }
                });
        });
};
//下拉框运维班
function sel_ywbname(fenbuid){
        layui.use(['layer','form'], function(){
                var layer = layui.layer;
                var form = layui.form;
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/c_getywbByfenbu',
                        dataType:'JSON', 
                        data: {
                                fenbuid:fenbuid
                        },
                        success: function (data) {
                        if(data.length>=0){
                                var optionStr ='<option lable="">请选择</option>';
                                for(var i=0;i<data.length;i++){
                                        optionStr+="<option class='selectYouzhi' data-ywbid='"+data[i].ywbid+"' value='"+data[i].ywbname+"'>"+data[i].ywbname+"</option>";
                                }
                                //用户管理
                                //工区
                                $("#user_editArea3").html(optionStr); //修改 
                                $("#user_addArea3").html(optionStr); //添加
                                //分部
                                $("#user_editFenbu3").html(optionStr); //修改
                                $("#user_addFenbu3").html(optionStr); //添加
                                //运维班
                                $("#user_editYwb3").html(optionStr); //修改
                                $("#user_addYwb3").html(optionStr); //添加

                                // 设备管理
                                //变电站
                                $("#device_editbdz3").html(optionStr); //修改
                                $("#addbdz3").html(optionStr); //添加
                                //设备区
                                $("#device_editsbj3").html(optionStr); //修改
                                $("#device_addsbj3").html(optionStr); //添加
                                //监控器（抓拍设备）
                                $("#device_addjkq3").html(optionStr); //添加
                                $("#device_editjkq3").html(optionStr); //修改
                                //预设点
                                $("#device_addysd3").html(optionStr); //添加
                                $("#device_editysd3").html(optionStr); //修改
                                //监测设备
                                $("#device_addshebei3").html(optionStr); //添加
                                $("#device_editshebei3").html(optionStr); //修改

                        }
                        form.render('select');//需要渲染一下
                        }
                });
        });
};

//下拉框变电站
function sel_bdzname(ywbid){
        layui.use(['layer','form'], function(){
                var layer = layui.layer;
                var form = layui.form;
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/e_getstationByywb',
                        dataType:'JSON', 
                        data: {
                                ywbid:ywbid
                        },
                        success: function (data) {
                        if(data.length>=0){
                                var optionStr ='<option lable="">请选择</option>';
                                for(var i=0;i<data.length;i++){
                                        optionStr+="<option class='selectYouzhi' data-stationid='"+data[i].stationid+"' value='"+data[i].stationname+"'>"+data[i].stationname+"</option>";
                                }
                                
                                // 设备管理
                                //设备区
                                $("#device_editsbj4").html(optionStr); //修改
                                $("#device_addsbj4").html(optionStr); //添加
                                //监控器（抓拍设备）
                                $("#device_addjkq4").html(optionStr); //添加
                                $("#device_editjkq4").html(optionStr); //修改
                                //预设点
                                $("#device_addysd4").html(optionStr); //添加
                                $("#device_editysd4").html(optionStr); //修改
                                //监测设备
                                $("#device_addshebei4").html(optionStr); //添加
                                $("#device_editshebei4").html(optionStr); //修改

                        }
                        form.render('select');//需要渲染一下
                        }
                });
        });
};
//下拉框设备区名
function sel_sbqname(stationid){
        layui.use(['layer','form'], function(){
                var layer = layui.layer;
                var form = layui.form;
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/f_getbuildingBystation',
                        dataType:'JSON', 
                        data: {
                                stationid:stationid
                        },
                        success: function (data) {
                        if(data.length>=0){
                                var optionStr ='<option lable="">请选择</option>';
                                for(var i=0;i<data.length;i++){
                                        optionStr+="<option class='selectYouzhi' data-buildingid='"+data[i].buildingid+"' value='"+data[i].buildingname+"'>"+data[i].buildingname+"</option>";
                                }
                                
                                // 设备管理

                                //监控器（抓拍设备）
                                $("#device_addjkq5").html(optionStr); //添加
                                $("#device_editjkq5").html(optionStr); //修改
                                //预设点
                                $("#device_addysd5").html(optionStr); //添加
                                $("#device_editysd5").html(optionStr); //修改
                                //监测设备
                                $("#device_addshebei5").html(optionStr); //添加
                                $("#device_editshebei5").html(optionStr); //修改

                        }
                        form.render('select');//需要渲染一下
                        }
                });
        });
};
//下拉框监控器名
function sel_jkqname(buildingid){
        layui.use(['layer','form'], function(){
                var layer = layui.layer;
                var form = layui.form;
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/g_getmachineBybuilding',
                        dataType:'JSON', 
                        data: {
                                buildingid:buildingid
                        },
                        success: function (data) {
                        if(data.length>=0){
                                var optionStr ='<option lable="">请选择</option>';
                                for(var i=0;i<data.length;i++){
                                        optionStr+="<option class='selectYouzhi' data-machineid='"+data[i].machineid+"' value='"+data[i].machinename+"'>"+data[i].machinename+"</option>";
                                }
                                
                                // 设备管理


                                //预设点
                                $("#device_addysd6").html(optionStr); //添加
                                $("#device_editysd6").html(optionStr); //修改
                                //监测设备
                                $("#device_addshebei6").html(optionStr); //添加
                                $("#device_editshebei6").html(optionStr); //修改

                        }
                        form.render('select');//需要渲染一下
                        }
                });
        });
};
//下拉框预设点编号
function sel_ysdname(machineid){
        layui.use(['layer','form'], function(){
                var layer = layui.layer;
                var form = layui.form;
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/h_getysdBymachine',
                        dataType:'JSON', 
                        data: {
                                machineid:machineid
                        },
                        success: function (data) {
                        if(data.length>=0){
                                var optionStr ='<option lable="">请选择</option>';
                                for(var i=0;i<data.length;i++){
                                        optionStr+="<option class='selectYouzhi' data-ysdid='"+data[i].ysdid+"' value='"+data[i].ysdname+"'>"+data[i].ysdname+"</option>";
                                }
                                
                                // 设备管理


                                //监测设备
                                $("#device_addshebei7").html(optionStr); //添加
                                $("#device_editshebei7").html(optionStr); //修改

                        }
                        form.render('select');//需要渲染一下
                        }
                });
        });
};



// 天气信息传后台
//参数  city,cityTemp,windSpeed,cityhumidity,weatherInfor,alarmInfor[城市，气温，风速，湿度，阴晴，预警信息]
function index_weather(city,cityTemp,windSpeed,cityhumidity,weatherInfor,alarmInfor){
        $.ajax({
                type:'get',
                url:baseUrl+'WeatherService/WeatherServices.asmx/SendWeatherToServer',
                dataType:'JSON',  
                data:{
                        city:city,
                        cityTemp:cityTemp,
                        windSpeed:windSpeed,
                        cityhumidity:cityhumidity,
                        weatherInfor:weatherInfor,
                        alarmInfor:alarmInfor
                },
                success:function(data){
                        // console.log(data);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// admin账号下，在设备状态页面加个按钮，调用这个接口，统计设备在线不在线  直接传后台
function shebeiStatus_backstage(){
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/OfflineCount',
                dataType:'JSON',  
                data:{
                },
                success:function(data){
                //        console.log("专用");
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 城市气温和预警信息， 天气
function index_headerWeather(areaCity){
        if(areaCity==''||areaCity==undefined||areaCity==null){
                areaCity="郑州";
        }
        var html='<iframe scrolling="no" src="https://tianqiapi.com/api.php?city='+areaCity+'&style=tb&skin=pitaya&color=ffffff&paddingtop=5&paddingleft=8&fontsize=16" frameborder="0" width="500" height="30" allowtransparency="true"></iframe>';
        $("#city_wea").html(html);
        
        // $.ajax({
        //         type:'get',
        //         url:"http://192.168.1.28:8080/shebeiguanli/holographic/realtime",
        //         dataType:'JSON',  
        //         data:{
        //               l:"113.12",
        //               b:"46.1"  
        //         },
        //         success:function(data){
        //                 var html='<iframe scrolling="no" src="https://tianqiapi.com/api.php?city='+areaCity+'&style=tb&skin=pitaya&color=ffffff&paddingtop=5&paddingleft=8&fontsize=16" frameborder="0" width="350" height="30" allowtransparency="true"></iframe>'
        //                 , html1='',html2='';
        //                 if(data.status==1){
        //                         var yujing=data.content.result.hourly.description;
        //                         if(yujing!=''&&yujing!=null&&yujing!=undefined){
        //                                 html1='<img src="./images/nav_warn.png" alt="" class="nav_warn">';
        //                                 html2+=yujing;

        //                                 $("#weather_yujing").html(html2);
        //                                 $("#tips").html(html1);
        //                         }
        //                 };
        //                 $("#city_wea").html(html);
        //         },
        //         error:function(err){
        //                 console.log(err)
        //         }

        // });
};


// 温升设备，
//参数  userid,hour
// function index_topLeft_module1Wensheng(userid,hour){
//         $.ajax({
//                 type:'get',
                // url:baseUrl+'ReportServic/reportServices.asmx/getSevenRaseDevciceCount',
//                 dataType:'JSON',  
//                 data:{
//                         userid:userid,
//                         hour:hour,
//                 },
//                 success:function(data){
//                         // if(data[0].msg){

//                         // }
//                         $("#wemshengT").html(data[0].msg);
//                 },
//                 error:function(err){
//                         console.log(err)
//                 }

//         });
// };

// 设备最高温，
//参数  userid
function index_topLeft_module1Gaowen(userid){
        $.ajax({
                type:'get',
                // TableService/Infra_Red_Table_Services.asmx/getTopdevice
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getTopdevice_Three',
                dataType:'JSON',  
                data:{
                        userid:userid,
                },
                success:function(data){
                        var html='';
                                for(var i=0;i<data.length;i++){
                                        html+=`<li onclick="leftTop(`+ JSON.stringify(data[i]).replace(/"/g, '&quot;') +`)"><p class="text_bot"><span class="text_num">`+data[i].todaytop+`</span><span style="margin-top:3px;">℃</span></p>
                                                <p class="text_bot"><span>`+data[i].devicename+`</span></p>
                                        </li>`;

                                }
                        $("#shebei_gaowen").html(html);
                        

                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 获取当前用户下测温告警统计信息信息，返回<名称，数量>列表 
//参数userid
// function index_topLeft_module2(userid){
//         $.ajax({
//                 type:'get',
//                 url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getAlarm',
//                 dataType:'JSON',  
//                 data:{
//                         userid:userid,
//                 },
//                 success:function(data){
//                         var html='';
//                         var cont=[],deviceType=[];
//                         for(let item of data){
//                                 html+=`<li>
//                                         <p class="item_num">${item.count}</p>
//                                         <p class="item_text">${item.deviceType}</p>
//                                 </li>`;
//                                 cont.push(item.count);
//                                 deviceType.push(item.deviceType)
//                         }
//                         // $("#slide_ul").html(html);
//                         // moveItRight();
//                         alarmInfoTopModule1(deviceType,cont);
//                 },
//                 error:function(err){
//                         console.log(err)
//                 }

//         });
// };

function systemSetBdzCount(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getdeviceCount',
                dataType:'JSON',  
                data:{
                        userid:userid,
                },
                success:function(data){
                        var cont=[],deviceType=[];
                        for(let item of data){
                                cont.push(item.count);
                                deviceType.push(item.deviceType)
                        }
                        systemSetModule3(deviceType,cont)
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 获取当前用户下测温告警统计信息信息，返回<名称，数量>列表 
//参数userid
function index_topLeft_module2G(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/alarmCount',
                dataType:'JSON',  
                data:{
                        userid:userid,
                },
                success:function(data){
                        var cont=[],deviceType=[],cont2=[],deviceType2=[];
                        for(let item of data.Dt1){
                                cont.push(item.count);
                                deviceType.push(item.deviceType);  
                        }
                        for(let item of data.Dt2){
                                cont2.push(item.count);
                                deviceType2.push(item.deviceType);  
                        }
                        todayAlarmModule2Left(deviceType,cont);
                        alarmTypeModule2Right(deviceType2,cont2)
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 获取当前用户下周期测温峰值统计，返回<时间，温度>列表
//参数:  userid
function index_topLeft_module3(userid){
        var xdatas= ['今日','昨日','7日','30日'],
                roundDatas=[];
        var deviceid_today='',deviceid_yestoday='',deviceid_week='',deviceid_month=''
                ,timeToday='',timeYestoday='',timeWeek='',timeMonth='';
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getRoundTop',
                dataType:'JSON',  
                data:{
                        userid:userid,
                },
                success:function(data){
                        for(let item of data){
                                roundDatas.push(item.todayTop);//今日
                                roundDatas.push(item.yestodayTop);//昨日
                                roundDatas.push(item.weekTop);//本周
                                roundDatas.push(item.monthTop);//本月

                                deviceid_today=item.deviceid_today;//今日
                                deviceid_yestoday=item.deviceid_yestoday;//昨日
                                deviceid_week=item.deviceid_week;//本周
                                deviceid_month=item.deviceid_month;//本月

                                timeToday=item.TodayTime;//今日时间
                                timeYestoday=item.YesterdayTime;//昨日时间
                                timeWeek=item.WeekDayTime;//本周时间
                                timeMonth=item.MonthDayTime;//本月时间
                        }
                        left_module3(xdatas,roundDatas,deviceid_today,deviceid_yestoday,deviceid_week
                                ,deviceid_month,timeToday,timeYestoday,timeWeek,timeMonth); 
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 获取当前用户下地区环温与设备最高温对比，返回<地区，地区温度，设备最高温度>列表
//参数: userid
// function index_topLeft_module4(userid){
//         var areaWran=[],
//             deviceWran=[],
//             datacitys=[],
//             trueOrF='',temprecordid=[];
//         $.ajax({
//                 type:'get',
//                 url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getareaAnddevice',
//                 dataType:'JSON',  
//                 data:{
//                         userid:userid,
//                 },
//                 success:function(data){
//                         for(let item of data){
//                                 areaWran.push(item.citytemputer);
//                                 deviceWran.push(item.devicetopvalue);
//                                 datacitys.push(item.ywbname);
//                                 temprecordid.push(item.temprecordid);
//                         }
                        
//                         if(data.length>13){
//                                 trueOrF=true;
//                         }else{
//                                 trueOrF=false;
//                         };
                        
//                         left_module4(areaWran,deviceWran,datacitys,trueOrF,temprecordid);
//                 },
//                 error:function(err){
//                         console.log(err)
//                 }
//         });
// };

// 获取一周设备温度统计，列表
//参数: userid
function index_topLeft_module4Week(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/ZZZ_get_device_tongji_week',
                dataType:'JSON',  
                data:{
                        userid:userid,
                },
                success:function(data){
                        $("#allCount").html(data[0].allcount);
                        $("#count_80").html(data[0].count_80);
                        $("#count_90").html(data[0].count_90);
                        $("#count_100").html(data[0].count_100);
                        $("#count_120").html(data[0].count_120);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 本月超80℃的设备统计(16个)
//参数: userid
// function index_mediaCenter_right(userid){
        // $.ajax({
        //         type:'get',
        //         url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/ZZZ_get_device_80_tongji_month',
        //         dataType:'JSON',  
        //         data:{
        //                 userid:userid,
        //         },
        //         success:function(data){
        //                 var html='',htmlDetail='';
        //                 $("#total80").html(data.Tongji);
        //                 $("#totalAllDetail").html(data.Tongji);
        //                 for(let item of data.Device_tongji_single){
        //                         html+=`<div class="swiper-slide" onclick="mediaCenterInfo(`+ JSON.stringify(item).replace(/"/g, '&quot;') +`)">
        //                                 <p class="tems">${item.alarmvalue}℃</p>
        //                                 <p>${item.stationname}</p>
        //                                 <p>${item.devicename}</p>
        //                         </div>`;
        //                 };
        //                 var names= []
        //                         ,numValue=[];
                        
        //                 for(let item of data.Device_tongji_all){
        //                         names.push(item.devicetype);
        //                         numValue.push(item.count);
                                
        //                         htmlDetail+=`<li>
        //                                 <div class="nums">${item.count}</div>
        //                                 <p>${item.devicetype}</p>
        //                         </li>`;
        //                 }
        //                 $("#swiperContent").html(html);
        //                 // RightTypeBar(names,numValue); //已经不用 饼图 左侧 本月超80℃的设备统计   RightTypeBar
        //                 $("#detailUl").html(htmlDetail);
        //         },
        //         error:function(err){
        //                 console.log(err)
        //         }

        // });
// };

// 获取实时检测设备列表
//参数  userid
function index_mediaTop_right(userid,stationid){
        $("#RightModule_content").html("");
        var html='';
        var id='';
        var tem=[],
            fuhe=[],
            time=[],
            arrAll='';
        var imgs='';
        var tem='';
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getAllRounddevice',
                dataType:'JSON',  
                data:{
                        userid:userid,
                        stationid:stationid
                },
                success:function(data){
                        data.forEach( (item, i) => {
                                id=i;
                                if(item.Todaytop==''||item.Todaytop==null){
                                        tem=0;
                                }else{
                                        tem=item.Todaytop;
                                }
                                
                                html+=`<li>
                                       <div class="item_leftImg fl">`;

                                var imgs1=item.Image_mix;
                                var imgs2=item.Image_red;
                                var imgs3=item.Image_high;
                                if(imgs1!=''&&imgs1!=null&&imgs1!=undefined){
                                        imgs=imgs1;
                                        html+=`<div class="leftImg" onclick="rightTpp(`+ JSON.stringify(item).replace(/"/g, '&quot;') +`)">
                                        <img src="${imgs}" alt="">
                                        </div>`;
                                }else if(imgs2!=''&&imgs2!=null&&imgs2!=undefined){
                                        imgs=imgs2;
                                        html+=`<div class="leftImg" onclick="rightTpp(`+ JSON.stringify(item).replace(/"/g, '&quot;') +`)">
                                        <img src="${imgs}" alt="">
                                        </div>`;
                                }else if(imgs3!=''&&imgs3!=null&&imgs3!=undefined){
                                        imgs=imgs3;
                                        html+=`<div class="leftImg" onclick="rightTpp(`+ JSON.stringify(item).replace(/"/g, '&quot;') +`)">
                                        <img src="${imgs}" alt="">
                                        </div>`;
                                }else{
                                        imgs=`../images/no_pic.png`;
                                        html+=`<div class="leftImg">
                                        <img src="${imgs}" alt="">
                                        </div>`;
                                };

                                

                                html+=`<p>`;
                                
                                if(tem>=100){
                                        html+=`<span class="over100 item_tem fl">${tem}℃</span>`;
                                }
                                if(tem >= 80 && tem < 100){
                                        html+=`<span class="over80 item_tem fl">${tem}℃</span>`;
                                }
                                if(tem<80){
                                        html+=`<span class="up80 item_tem fl">${tem}℃</span>`;
                                }
                                html+=`<span class="fr">${item.Stationshortname1}</span></p>
                                        </div>
                                        <div class="item_rightData fr">
                                            <div id="Right_module${i}"style="width:100%;height: 120px;"></div>
                                            <div class="Right_name">${item.Devicename}</div>
                                        </div></li>`;
                                $("#RightModule_content").html(html);
                                
                               
                        });
                        
                        data.forEach((item,i)=>{
                                time=[],tem=[];
                                var templists=data[i].Templist;
                                for(var j=0;j<templists.length;j++){
                                        arrAll=templists[j].split(';');
                                        time.push(arrAll[0]);
                                        tem.push(arrAll[1]);
                                        
                                }
                                
                                fuhe=item.Fuhelist;
                                Right_module(time,tem,fuhe,i); 
                        });
                        

                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 获取重点检测设备列表 
// 参数  userid  page表示页码，从1开始，numbers表示每页多少条
function index_bottomItem_module(userid,page,numbers){
        var tem='';
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getAllkeyPointdevice',
                dataType:'JSON',  
                data:{
                        page:page,	
                        numbers:numbers,
                        userid:userid,
                },
                success:function(data){
                        var datas=data.Recorddt;
                        var html='';
                        var id='';
                        var temperA,
                            temperB,todaymaxid='',monthmaxid='';// x轴刻度
                        var imgs='';
                        if(datas.length>0){
                                for(var i=0;i<datas.length;i++){
                                        dataAllLength=data.Recordcount;
                                        var Times=datas[i].createtime; ///Date(158 572 227 7000)/
                                        if(datas[i].dangqian==''||datas[i].dangqian==null){
                                                tem=0;
                                        }else{
                                                tem=datas[i].dangqian;
                                        }
                                        var imgs1=datas[i].image_high;
                                        var imgs2=datas[i].image_mix;
                                        var imgs3=datas[i].image_red;

                                        html+='<li class="swiper-slide"><div class="item_leftImg fl">';
                                        if(imgs1!=''&&imgs1!=null&&imgs1!=undefined){
                                                html+='<div class="leftImg" onclick="showPhaseInfo('+ JSON.stringify(datas[i]).replace(/"/g, '&quot;') +')"><img src="'
                                                +imgs1+'" alt="">';
                                        }else if(imgs2!=''&&imgs2!=null&&imgs2!=undefined){
                                                html+='<div class="leftImg" onclick="showPhaseInfo('+ JSON.stringify(datas[i]).replace(/"/g, '&quot;') +')"><img src="'
                                                +imgs2+'" alt="">';
                                        }else if(imgs3!=''&&imgs3!=null&&imgs3!=undefined){
                                                html+='<div class="leftImg" onclick="showPhaseInfo('+ JSON.stringify(datas[i]).replace(/"/g, '&quot;') +')"><img src="'
                                                +imgs3+'" alt="">';
                                        }else{
                                                html+='<div class="leftImg"><img src="../images/no_pic.png" alt="">';
                                        }
                                        html+='<div class="sub_name"><span>'
                                                +datas[i].stationshortname1+'</span><span>'
                                                +datas[i].devicename+'</span></div></div><div class="item_text">';
                                        
                                        if(tem>=100){
                                                html+=`<p class="over100 item_tem fl">${tem}<span style="font-size:16px;">℃</span></p>`;
                                        }
                                        if(tem >= 80 && tem < 100){
                                                html+=`<p class="over80 item_tem fl">${tem}<span style="font-size:16px;">℃</span></p>`;
                                        }
                                        if(tem<80){
                                                html+=`<p class="up80 item_tem fl">${tem}<span style="font-size:16px;">℃</span></p>`;
                                        }       
                                        html+='<p class="sub_right fr"><span class="sub_time" >'
                                                +Times+'</span></p></div></div><div class="item_rightData fr" onclick="bottom_bigImg('+ JSON.stringify(datas[i]).replace(/"/g, '&quot;') +')"><div id="bottomItem_module'+i+'" style="width:100%;height: 169px;"></div></div></li>';
                                        $("#footerModule").html(html);
                                }
                                
                                for(var i=0;i<datas.length;i++){
                                        id=i;
                                        temperA=datas[i].todaymax;
                                        temperB=datas[i].monthmax;
                                        todaymaxid=datas[i].todaymaxid;
                                        monthmaxid=datas[i].monthmaxid;
                                        bottomItem_module(temperA,temperB,id,todaymaxid,monthmaxid); 
                                };
                        }
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 获取当前用户下测温告警统计信息,返回告警总数，80-100,100-120,>120
// 参数   userid
function cewenRight_module(userid){
        
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getAlarmByTemouterSection',
                dataType:'JSON',  
                data:{
                        userid:userid,
                },
                success:function(data){
                    var repair1=data[0].count_80100;
                    var repair2=data[0].count_100120;
                    var repair3=data[0].count_120;
                    alarmInfoTopModule2(repair1,repair2,repair3)
                },
                error:function(err){
                        console.log(err)
                }

        });
};

var areaname_Sel='',fenbuname_sel='',ywbname_sel='',stationname_sel='',buildingname_sel='',machinename_sel='',ysdname_sel='';
// 默认选中 监控器
function moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid){
        layui.use(['layer','form'], function(){
                var layer = layui.layer;
                var form = layui.form;
                // 工区
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/a_getAllarea',
                        dataType:'JSON', 
                        data: {
                                userid:userid
                        },
                        success: function (data) {
                                
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].areaname==areaname_Sel){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-areaid='"+data[i].areaid+"' value='"+data[i].areaname+"'>"+data[i].areaname+"</option>";
                                        }
                                        //用户管理
                                        //工区
                                        $("#user_editArea1").html(optionStr); //修改
                                        //分部
                                        $("#user_editFenbu1").html(optionStr); //修改
                                        //运维班
                                        $("#user_editYwb1").html(optionStr); //修改

                                        // 设备管理
                                        

                                        
                                        //分部
                                        $("#device_editFenbu1").html(optionStr); //修改
                                        
                                        //运维班
                                        $("#device_editywb1").html(optionStr); //修改
                                        //变电站
                                        $("#device_editbdz1").html(optionStr); //修改
                                        //设备区
                                        $("#device_editsbj1").html(optionStr); //修改
                                        //监控器（抓拍设备）
                                        $("#device_editjkq1").html(optionStr); //修改
                                        //预设点
                                        $("#device_editysd1").html(optionStr); //修改
                                        //监测设备
                                        $("#device_editshebei1").html(optionStr); //修改
                                        
                                }
                                form.render('select');//需要渲染一下  
                        }
                        
                });
                if(areaid==''||areaid==null){
                        return;
                }
                // 分部
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/b_getfenbuByarea',
                        dataType:'JSON', 
                        data: {
                                areaid:areaid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].fenbuname==fenbuname_sel){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-fenbuid='"+data[i].fenbuid+"' value='"+data[i].fenbuname+"'>"+data[i].fenbuname+"</option>";
                                        }
                                        
                                        
                                        //用户管理
                                        //工区
                                        $("#user_editArea2").html(optionStr);//修改 
                                        //分部
                                        $("#user_editFenbu2").html(optionStr); //修改
                                        //运维班
                                        $("#user_editYwb2").html(optionStr); //修改

                                        // 设备管理
                                        
                                        
                                        
                                        //运维班
                                        $("#device_editywb2").html(optionStr); //修改
                                        $("#addywb2").html(optionStr); //添加
                                        //变电站
                                        $("#device_editbdz2").html(optionStr); //修改
                                        //设备区
                                        $("#device_editsbj2").html(optionStr); //修改
                                        //监控器（抓拍设备）
                                        $("#device_editjkq2").html(optionStr); //修改
                                        //预设点
                                        $("#device_editysd2").html(optionStr); //修改
                                        //监测设备
                                        $("#device_editshebei2").html(optionStr); //修改
                                }
                                form.render('select');//需要渲染一下
                        }
                }); 
                if(fenbuid==''||fenbuid==null){
                        return;
                }
                // 运维班
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/c_getywbByfenbu',
                        dataType:'JSON', 
                        data: {
                                fenbuid:fenbuid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].ywbname==ywbname_sel){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-ywbid='"+data[i].ywbid+"' value='"+data[i].ywbname+"'>"+data[i].ywbname+"</option>";
                                        }

                                        //用户管理
                                        //工区
                                        $("#user_editArea3").html(optionStr); //修改 
                                        //分部
                                        $("#user_editFenbu3").html(optionStr); //修改
                                        //运维班
                                        $("#user_editYwb3").html(optionStr); //修改
                                        

                                        // 设备管理
                                        //变电站
                                        $("#device_editbdz3").html(optionStr); //修改
                                        //设备区
                                        $("#device_editsbj3").html(optionStr); //修改
                                        //监控器（抓拍设备）
                                        $("#device_editjkq3").html(optionStr); //修改
                                        //预设点
                                        $("#device_editysd3").html(optionStr); //修改
                                        //监测设备
                                        $("#device_editshebei3").html(optionStr); //修改

                                }
                                form.render('select');//需要渲染一下
                        }
                }); 
                if(ywbid==''||ywbid==null){
                        return;
                }
                // 变电站
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/e_getstationByywb',
                        dataType:'JSON', 
                        data: {
                                ywbid:ywbid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].stationname==stationname_sel){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-stationid='"+data[i].stationid+"' value='"+data[i].stationname+"'>"+data[i].stationname+"</option>";
                                        }
                                        // 设备管理
                                        //设备区
                                        $("#device_editsbj4").html(optionStr); //修改
                                        //监控器（抓拍设备）
                                        $("#device_editjkq4").html(optionStr); //修改
                                        //预设点
                                        $("#device_editysd4").html(optionStr); //修改
                                        //监测设备
                                        $("#device_editshebei4").html(optionStr); //修改

                                }
                                form.render('select');//需要渲染一下
                        }
                });
                if(stationid==''||stationid==null){
                        return;
                }
                // 设备区
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/f_getbuildingBystation',
                        dataType:'JSON', 
                        data: {
                                stationid:stationid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].buildingname==buildingname_sel){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-buildingid='"+data[i].buildingid+"' value='"+data[i].buildingname+"'>"+data[i].buildingname+"</option>";
                                        }
                                        // 设备管理

                                        //监控器（抓拍设备）
                                        $("#device_editjkq5").html(optionStr); //修改
                                        //预设点
                                        $("#device_editysd5").html(optionStr); //修改
                                        //监测设备
                                        $("#device_editshebei5").html(optionStr); //修改

                                }
                                form.render('select');//需要渲染一下    
                        }
                });
                if(buildingid==''||buildingid==null){
                        return;
                }
                // 监控器
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/g_getmachineBybuilding',
                        dataType:'JSON', 
                        data: {
                                buildingid:buildingid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].machinename==machinename_sel){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-machineid='"+data[i].machineid+"' value='"+data[i].machinename+"'>"+data[i].machinename+"</option>";
                                        }
                                        // 设备管理


                                        //预设点
                                        $("#device_editysd6").html(optionStr); //修改
                                        //监测设备
                                        $("#device_editshebei6").html(optionStr); //修改

                                }
                        }
                });
                if(machineid==''||machineid==null){
                        return;
                }
                // 预设点
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/h_getysdBymachine',
                        dataType:'JSON', 
                        data: {
                                machineid:machineid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].ysdname==ysdname_sel){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-ysdid='"+data[i].ysdid+"' value='"+data[i].ysdname+"'>"+data[i].ysdname+"</option>";
                                        }
                                        // 设备管理


                                        //监测设备
                                        $("#device_editshebei7").html(optionStr); //修改

                                }
                        }
                });
        });
};


//设备管理

// 工区
//请求全部工区
function device_getAreaAll(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/a_getAllarea',
                dataType:'JSON',
                data:{
                        userid:userid
                },
                success:function(data){
                        var html1='<span class="select">全部</span>',
                            html2='';

                        for(var i=0;i<data.length;i++){
                                html1+=`<span data-areaid="${data[i].areaid}" data-areaname="${data[i].areaname}">${data[i].areaname}</span>`;

                                       
                                html2+='<li class="li-item"><div class="item_left fl" data-areaid="'
                                        +data[i].areaid+
                                        '"><span>'
                                        +data[i].areaname+
                                        '</span></div><div class="item_right fr"><a class="area_event ac_edit edit1 layui-btn layui-btn-xs" data-areaid="'
                                        +data[i].areaid+
                                        '" data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="area_event ac_del del1 layui-btn layui-btn-xs" data-areaid="'
                                        +data[i].areaid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        }
                        
                        $("#area_ulDD").html(html1);
                        $("#gq_ul").html(html2);
                        $("#manageArea").html(html1);

                        $("#gqEdit_ul").html(html2);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//请求某一工区信息
//参数:
function device_getAreaNows(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/a_getareaByid',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        for(var i=0;i<data.length;i++){
                                // 修改
                                $("#device_editArea1").val(data[0].areaname);
                                $("#device_editArea2").val(data[0].manager);
                                $("#device_editArea3").val(data[0].phone);
                                $("#device_editArea4").val(data[0].city);
                                $("#device_editArea5").val(data[0].address);
                                $("#device_editArea6").val(data[0].shortname);
                        }
						console.log(data);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//修改工区
//传参(类型：字符):areaname,manager,phone,city,address,shortname,返回1[成功]，0[失败]
function device_editArea(areaid,areaname,manager,phone,city,address,shortname){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/a_modifyarea',
                dataType:'JSON',
                data:{
                        areaid:areaid,
                        areaname:areaname,
                        manager:manager,
                        phone:phone,
                        city:city,
                        address:address,
						shortname:shortname
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                },
                error:function(err){
                        console.log(err)
                }

        });
}
//添加工区
//传参(类型：字符):companyname,areaname,manager,phone,city,address,shortname,返回1[成功]，0[失败]
function device_addArea(areaname,manager,phone,city,address,shortname){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/a_addarea',
                dataType:'JSON',
                data:{
                        areaname:areaname,
                        manager:manager,
                        phone:phone,
                        city:city,
                        address:address,
						shortname:shortname
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                },
                error:function(err){
                        console.log(err)
                }

        });
}
//删除工区
//传参(类型：字符):areaname返回1[成功]，0[失败]
function device_delArea(areaid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/a_deletearea',
                dataType:'JSON',
                data:{
                        id:areaid,
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        editData(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);
                        // user_getYwbAll();
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 分部
//请求全部分部
function device_getFenbuAll(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/b_getAllfenbu',
                dataType:'JSON',
                data:{
                        userid:userid   
                },
                success:function(data){
                        var html1='<span class="select">全部</span>',
                            html2='',
                            html3='';
                        for(var i=0;i<data.length;i++){
                                html1+=`<span data-fenbuname="${data[i].fenbuname}" data-fenbuid="${data[i].fenbuid}">${data[i].fenbuname}</span>`;
                                html3+=`<span data-fenbuname="${data[i].fenbuname}" data-fenbuid="${data[i].fenbuid}">${data[i].fenbuname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-fenbuid="'
                                        +data[i].fenbuid+
                                        '><span>'
                                        +data[i].fenbuname+
                                        '</span></div><div class="item_right fr"><a class="fenbu_event ac_edit edit2 layui-btn layui-btn-xs" data-fenbuid="'
                                        +data[i].fenbuid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="fenbu_event ac_del del2 layui-btn layui-btn-xs" data-fenbuid="'
                                        +data[i].fenbuid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                        }
                        $("#fenbu_ulDD").html(html3);
                        $("#fenbu_ul").html(html2);
                        $("#fenbuEdit_ul").html(html2);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};

//请求某一分部信息
//参数 fenbuname
function device_getFenbuNows(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/b_getfenbuByid',
                dataType:'JSON',
                data:{
                        id:id    
                },
                success:function(data){
                        areaname_Sel=data[0].areaname;
                        setTimeout(function(){
                                $("#device_editFenbu1 option").each(function(){
                                        if($(this).val() ==areaname_Sel){
                                                $(this).attr('selected',true)
                                        }
                                });
                        },100);
                        fenbuname_sel='';
                        ywbname_sel='';
                        stationname_sel='';

                        var areaid=data[0].areaid;
                        var fenbuid='';
                        var ywbid='';
                        var stationid='';
                        var buildingid='';
                        var machineid='';

                        moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);

                        // moren(areaname_Sel,fenbuname_sel,ywbname_sel,stationname_sel,buildingid,machineid);

                        $("#device_editFenbu2").val(data[0].fenbuname);
                        $("#device_editFenbu3").val(data[0].manager);
                        $("#device_editFenbu4").val(data[0].phone);
                        $("#device_editFenbu5").val(data[0].address);
						$("#device_editFenbu6").val(data[0].shortname);
						console.log(data);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//修改分部
//传参(类型：字符):areaname, fenbuname, manager, phone, address,shortname,返回1[成功]，0[失败]
function device_editFenbu(areaid,fenbuid, fenbuname, manager, phone, address,shortname){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/b_modifyfenbu',
                dataType:'JSON',
                data:{
                        areaid:areaid,
                        fenbuid:fenbuid,
                        fenbuname:fenbuname,
                        manager:manager,
                        phone:phone,
                        address:address,
						shortname:shortname
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        getfenbuAll(areaid);
                },
                error:function(err){
                        console.log(err)
                }

        });
}
//添加分部
//传参(类型：字符):areaname, fenbuname, manager, phone, address,shortname【工区名称，分部名称，员工，电话，地址】,返回1[成功]，0[错误]
function device_addFenbu(areaid,fenbuname,manager,phone,address,shortname){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/b_addfenbu',
                dataType:'JSON',
                data:{
                        areaid:areaid,
                        fenbuname:fenbuname,
                        manager:manager,
                        phone:phone,
                        address:address,
						shortname:shortname
                },
                success:function(data){
                       
                        if(data[0].status==0){
                                layer.msg(data[0].msg, {icon:2,time:1500});
                        }else{
                                layer.msg(data[0].msg, {icon:1,time:1000});
                                $(".fenbu_addC").css("display","none");
                                getfenbuAll(areaid);
                        };
                },
                error:function(err){
                        console.log(err)
                }

        });
}
//删除分部
//传参(类型：字符):fenbuname[成功]，0[失败]
function device_delFenbu(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/b_deletefenbu',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 运维班 

//请求某一运维班
//参数 ywbname:
function device_getYwbNows(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/c_getywbByid',
                dataType:'JSON',
                data:{
                        id:id
                },
                success:function(data){
                        for(var i=0;i<data.length;i++){
                                areaname_Sel=data[i].areaname;
                                setTimeout(function(){
                                        $("#device_editywb1 option").each(function(){
                                                if($(this).val() ==areaname_Sel ){
                                                        $(this).attr('selected',true)
                                                }
                                        });
                                },100);
                                fenbuname_sel=data[i].fenbuname;
                                ywbname_sel='';
                                stationname_sel='';
                                var buildingid='';
                                var machineid='';

                                var areaid=data[0].areaid;
                                var fenbuid=data[0].fenbuid;
                                var ywbid='';
                                var stationid='';
                                var buildingid='';
                                var machineid='';
        
                                moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
                                // moren(areaname_Sel,fenbuname_sel,ywbname_sel,stationname_sel,buildingid,machineid);

                                $("#device_editywb3").val(data[i].ywbname);
                                $("#device_editywb4").val(data[i].manager);
                                $("#device_editywb5").val(data[i].phone);
                                $("#device_editywb6").val(data[i].address);
                                $("#device_editywb7").val(data[i].shortname);
                                
                        }
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//修改运维班
//传参(类型：字符):areaname,fenbuname,ywbname,manager,phone,address,shortname 返回1[成功]，0[失败]
function device_editywb(fenbuid,ywbid,ywbname,manager,phone,address,shortname){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/c_modifyywb',
                dataType:'JSON',
                data:{
                        fenbuid:fenbuid,
                        ywbid:ywbid,
                        ywbname:ywbname,
                        manager:manager,
                        phone:phone,
                        address:address,
						shortname:shortname
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        fenbu_getywbAll(fenbuid);
                },
                error:function(err){
                        console.log(err)
                }

        });
}
//添加运维班
//传参(类型：字符):areaname, fenbuname, ywbname, manager, phone, address,shortname【工区名称，分部名称，运维班名称，员工，电话，地址】返回1[成功]，0[失败]
function device_addywb(fenbuid,ywbname,manager,phone,address,shortname){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/c_addywb',
                dataType:'JSON',
                data:{
                        fenbuid:fenbuid,
                        ywbname:ywbname,
                        manager:manager,
                        phone:phone,
                        address:address,
						shortname:shortname
                },
                success:function(data){
                        
                        if(data[0].status==0){
                                layer.msg(data[0].msg, {icon:2,time:1500});
                        }else{
                                layer.msg(data[0].msg, {icon:1,time:1000});
                                $(".ywb_addC").css("display","none");
                                fenbu_getywbAll(fenbuid);
                        };

                },
                error:function(err){
                        console.log(err)
                }

        });
};
//删除运维班
//传参(类型：字符):ywbname返回1[成功]，0[失败]
function device_delywb(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/c_deleteywb',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 变电站 

//获取某一个变电站，返回：变电站信息
//参数 stationname:
function device_getBdzNows(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/e_getstationByid',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        for(var i=0;i<data.length;i++){
                                areaname_Sel=data[i].areaname;
                                setTimeout(function(){
                                        $("#device_editbdz1 option").each(function(){
                                                if($(this).val() ==areaname_Sel ){
                                                        $(this).attr('selected',true)
                                                }
                                        });
                                },100);
                                fenbuname_sel=data[i].fenbuname;
                                ywbname_sel=data[i].ywbname;
                                stationname_sel='';

                                var areaid=data[0].areaid;
                                var fenbuid=data[0].fenbuid;
                                var ywbid=data[0].ywbid;
                                var stationid='';
                                var buildingid='';
                                var machineid='';
        
                                moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
                                // moren(areaname_Sel,fenbuname_sel,ywbname_sel,stationname_sel,buildingid,machineid);

                                $("#device_editbdz4").val(data[i].stationname);
                                $("#device_editbdz5").val(data[i].manager);
                                $("#device_editbdz6").val(data[i].phone);
                                $("#device_editbdz7").val(data[i].stationlevel);
                                $("#device_editbdz8").val(data[i].city);
                                $("#device_editbdz9").val(data[i].address);
                                $("#device_editbdz10").val(data[i].jingdu);
                                $("#device_editbdz11").val(data[i].weidu);
                                $("#device_editbdz12").val(data[i].shortname);
                        };
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//修改变电站
//传参(类型：字符):areaname,fenbuname,ywbname,stationname,manager,phone,stationlevel,city,address,jingdu,weidu,shortname,返回1[成功]，0[失败]
function device_editbdz(ywbid,stationid,stationname,manager,phone,stationlevel,city,address,jingdu,weidu,shortname){
        
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/e_modifystation',
                dataType:'JSON',
                data:{
                        ywbid:ywbid,	
                        stationid:stationid,
                        stationname:stationname,
                        manager:manager	,
                        phone:phone,	
                        stationlevel:stationlevel,
                        city:city,
                        address:address	,
                        jingdu:jingdu,
                        weidu:weidu,
						shortname:shortname
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        ywb_getbdzAll(ywbid);
                },
                error:function(err){
                        console.log(err)
                }

        });
}
//添加变电站
//传参(类型：字符):areaname, fenbuname, ywbname, stationname, manager, phone, stationlevel, city, address, jingdu, weidu,shortname【工区名称，分部名称，运维版名称，变电站名称，员工，电话，变压等级，城市，地址，经度，纬度，短名称】
function device_addbdz(ywbid,stationname,manager,phone,stationlevel,city,address,jingdu,weidu,shortname){
        
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/e_addstation',
                dataType:'JSON',
                data:{	
                        ywbid:ywbid,
                        stationname:stationname,
                        manager:manager	,
                        phone:phone,	
                        stationlevel:stationlevel,
                        city:city,
                        address:address	,
                        jingdu:jingdu,
                        weidu:weidu,
						shortname:shortname
                        
                },
                success:function(data){
                        if(data[0].status==0){
                                layer.msg(data[0].msg, {icon:2,time:1500});
                        }else{
                                layer.msg(data[0].msg, {icon:1,time:1000});
                                $(".bdz_addC").css("display","none");
                                ywb_getbdzAll(ywbid);
                        };

                },
                error:function(err){
                        console.log(err)
                }

        });
};
//删除变电站
//传参(类型：字符):stationname返回1[成功]，0[失败]
function device_delbdz(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/e_deletestation',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        
                        // user_getYwbAll();
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 设备区 

//获取当前变电站下某一个设备区，返回：变电站信息
//参数 id
function device_getSbjNows(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/f_getbuildingByid',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
					console.log(data);
                        for(var i=0;i<data.length;i++){
                               
                                areaname_Sel=data[i].areaname;
                                setTimeout(function(){
                                        $("#device_editsbj1 option").each(function(){
                                                if($(this).val() ==areaname_Sel){
                                                        $(this).attr('selected',true)
                                                }
                                        });
                                },100);
                                fenbuname_sel=data[i].fenbuname;
                                ywbname_sel=data[i].ywbname;
                                stationname_sel=data[i].stationname;
                                $("#device_editsbj5").val(data[i].buildingname);
								$("#device_editsbj6").val(data[i].shortname);
                                $("#device_editsbj5").attr("data-id",data[i].buildingid);
                                var areaid=data[0].areaid;
                                var fenbuid=data[0].fenbuid;
                                var ywbid=data[0].ywbid;
                                var stationid=data[0].stationid;
                                var buildingid='';
                                var machineid='';
        
                                moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
                                // moren(areaname_Sel,fenbuname_sel,ywbname_sel,stationname_sel,buildingid,machineid);
                        };
                },
                error:function(err){
                        console.log(err)
                }

        });
};

//修改设备区
//传参(类型：字符):companyname,areaname,ywbname,stationname,buildingname,shortname 返回1[成功]，0[失败]
function device_editSbj(stationid,buildingname,buildingid,shortname){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/f_modifybuilding',
                dataType:'JSON',
                data:{
                        stationid:stationid,	
                        buildingname:buildingname,
                        buildingid:buildingid,
						shortname:shortname
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        bdz_getsbqAll(stationid);
                },
                error:function(err){
                        console.log(err)
                }

        });
}
//添加设备区
//传参(类型：字符):areaname, fenbuname, ywbname, stationname, buildingname,shortname【工区名称，分部名称，运维班名称，变电站名称，设备区名称，短名称】
function device_addSbj(stationid,buildingname,shortname){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/f_addbuilding',
                dataType:'JSON',
                data:{
                        stationid:stationid,	
                        buildingname:buildingname,
                        shortname:shortname
                },
                success:function(data){
                        if(data[0].status==0){
                                layer.msg(data[0].msg, {icon:2,time:1500});
                        }else{
                                layer.msg(data[0].msg, {icon:1,time:1000});
                                $(".sbq_addC").css("display","none");
                                bdz_getsbqAll(stationid);
                        };

                },
                error:function(err){
                        console.log(err)
                }

        });
};
//删除设备区
//传参(类型：字符): areaname, fenbuname, ywbname, stationname, buildingname
function device_delSbj(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/f_deletebuilding',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        
                        // user_getYwbAll();
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 红外设备(抓拍设备)


//获取某个变电站下某个设备区下某一个（抓拍设备）监控器，返回：设备单个设备信息
//参数 id
function device_getJkqNows(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/g_getmachineByid',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(res){
                        var data=res.Machine;
						console.log(data);
                        for(var i=0;i<data.length;i++){
                                areaname_Sel=data[i].areaname;
                                setTimeout(function(){
                                        $("#device_editjkq1 option").each(function(){
                                                if($(this).val() ==areaname_Sel ){
                                                        $(this).attr('selected',true)
                                                }
                                        });
                                },100);
                                fenbuname_sel=data[i].fenbuname;
                                ywbname_sel=data[i].ywbname;
                                stationname_sel=data[i].stationname;
                                buildingname_sel=data[i].buildingname;
                                

                                $("#device_editjkq6").val(data[i].machinename);
                                $("#device_editjkq7").val(data[i].machinecompany);
                                $("#device_editjkq8").val(data[i].machinemac);
                                $("#device_editjkq9").val(data[i].machinecode);
                                $("#device_editjkq10").val(data[i].currentversion);
                                
                                var time=data[i].onlinetime; ///Date(158 572 227 7000)/
                                var Times='';
                                // if(time==''||time==null){
                                //   Times='';
                                // }else{
                                //   var s1 = time.substring(6,19);
                                //   Times=times(s1);
                                // };
                                if(time==''||time==null){
                                        Times='';
                                }else{
                                        // var s1 = time.substring(6,19);
                                        // time=datas.Time;
                                        Times=time.replace(/\T/g," ");
                                }
                                $("#device_editjkq11").val(Times);
                                // $("#device_editjkq12").val(data[i].fushelv);
                                // $("#device_editjkq13").val(data[i].offsetvalue);
                                // $("#device_editjkq13").val(data[i].machineip);
                                // var fluxTypes=data[0].fluxtype;
                                // if(fluxTypes=="4G版"){
                                //         $(".fluxNumberEdit").show();
                                // }else{
                                //         $(".fluxNumberEdit").hide();
                                // }
                                $("#device_editjkq16").val(data[i].fluxNumber);
								$("#device_editjkq17").val(data[i].SceneWifi);
                                var areaid=data[0].areaid;
                                var fenbuid=data[0].fenbuid;
                                var ywbid=data[0].ywbid;
                                var stationid=data[0].stationid;
                                var buildingid=data[0].buildingid;
                                var machineid='';
        
                                moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
                                // moren(areaname_Sel,fenbuname_sel,ywbname_sel,stationname_sel,buildingname_sel);
                        
                        };
                        var selI=res.Media.Index;
                        $("#device_editjkq14 option").each(function(){
                                if($(this).val()==selI){
                                        $(this).attr('selected',true)
                                }
                        });
                        var selType=data[0].fluxtype;
                        $("#device_editjkq15 option").each(function(){
                                if($(this).val()==selType){
                                        $(this).attr('selected',true)
                                }
                        });
                },
                error:function(err){
                        console.log(err)
                }

        });
};

//修改红外设备
//传参(类型：字符):areaname,fenbuname,ywbname,stationname,buildingname,machinename,machinecompany,
//machinemac,machinecode,currentversion,onlinetime,fushelv,offsetvalue
function device_editJkq(buildingid,machineid,machinename,machinecompany,
        machinemac,machinecode,currentversion,offsetvalue,machineip,mediaIndex,fluxType,fluxNumber,SceneWifi){
        
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/g_modifymachine',
                dataType:'JSON',
                data:{
                        buildingid:buildingid,
                        machineid:machineid,
                        machinename:machinename,
                        machinecompany:machinecompany,	
                        machinemac:machinemac,
                        machinecode:machinecode,
                        currentversion:currentversion,
                        // onlinetime:onlinetime,
                        // fushelv:fushelv,
                        offsetvalue:offsetvalue,
                        machineip:machineip,
                        mediaIndex:mediaIndex,
                        fluxType:fluxType,
                        fluxNumber:fluxNumber,
						SceneWifi:SceneWifi
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        sbq_getjianshiAll(buildingid);
                },
                error:function(err){
                        console.log(err)
                }

        });
}
//添加红外设备
//传参(类型：字符):areaname,fenbuname,ywbname,stationname,buildingname,machinename:	
//machinecompany,machinemac,machinecode,currentversion,onlinetime,fushelv,offsetvalue
//【工区名称，分部名称，运维班名称，变电站名称，设备区名称，抓拍设备名称，抓拍设备厂家，mac地址，
//设备编号，安装编号，当前版本，更新版本，设备状态，上线时间，抓拍间隔，wifi名称，wifi密码，辐射率，报警阈值，补偿值，现场wifi】
function device_addJkq(buildingid,machinename,machinecompany,machinemac,machinecode,
        currentversion,offsetvalue,machineip,mediaIndex,fluxType,fluxNumber,SceneWifi){
        
        if(machinename=='请选择'){
                machinename=''
        };
        if(mediaIndex=='请选择'){
                mediaIndex=''
        };
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/g_addmachine',
                dataType:'JSON',
                data:{	
                        buildingid:buildingid,
                        machinename:machinename,
                        machinecompany:machinecompany,	
                        machinemac:machinemac,
                        machinecode:machinecode,
                        currentversion:currentversion,	
                        // onlinetime:onlinetime,	
                        // fushelv:fushelv,
                        offsetvalue:offsetvalue,
                        machineip:machineip,
                        mediaIndex:mediaIndex,
                        fluxType:fluxType,//流量类型
                        fluxNumber:fluxNumber,// 流量卡号 （可以为空）
						SceneWifi:SceneWifi//现场wifi（可以为空）
                },
                success:function(data){
                        if(data[0].status==0){
                                layer.msg(data[0].msg, {icon:2,time:1500});
                        }else{
                                layer.msg(data[0].msg, {icon:1,time:1000});
                                $(".jkq_addC").css("display","none");
                                sbq_getjianshiAll(buildingid);
                        };
                        
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//删除红外设备
//传参(类型：字符):id
function device_delJkq(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/g_deletemachine',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        
                        // user_getYwbAll();
                },
                error:function(err){
                        console.log(err)
                }

        });
};



// 预设点 

//请求 获取当前红外设备下所有预设点 
//参数  machineid
function device_getYsdJkq(machineid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_getysdBymachine',
                dataType:'JSON',
                data:{
                        machineid:machineid,
                },
                success:function(data){
                        var html='';
                        for(var i=0;i<data.length;i++){

                                html+='<li class="li-item"><div class="item_left fl" data-ysdid="'
                                        +data[i].ysdid+'"><span>'
                                        +data[i].ysdname+'</span></div><div class="upDownTZ fl"><button class="btnUp" data-ysdid="'
                                        +data[i].ysdid+'"></button><button class="btnDown" data-ysdid="'
                                        +data[i].ysdid+'"></button></div><div class="item_right fr"><a class="ysd_event ac_edit edit7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="ysd_event ac_del del7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                        }
                        $("#ysd_ul").html(html);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//获取某个预设点，返回：变电站信息
//参数 id
function device_getYsdNows(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_getysdByid',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        for(var i=0;i<data.length;i++){
                                areaname_Sel=data[i].areaname;
                                setTimeout(function(){
                                        $("#device_editysd1 option").each(function(){
                                                if($(this).val() ==areaname_Sel ){
                                                        $(this).attr('selected',true)
                                                }
                                        });
                                },100);
                                fenbuname_sel=data[i].fenbuname;
                                ywbname_sel=data[i].ywbname;
                                stationname_sel=data[i].stationname;
                                buildingname_sel=data[i].buildingname;
                                machinename_sel=data[i].machinename;
                                $("#device_editysd7").val(data[i].ysdname);

                                var areaid=data[0].areaid;
                                var fenbuid=data[0].fenbuid;
                                var ywbid=data[0].ywbid;
                                var stationid=data[0].stationid;
                                var buildingid=data[0].buildingid;
                                var machineid=data[0].machineid;
        
                                moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
                                // moren(areaname_Sel,fenbuname_sel,ywbname_sel,stationname_sel,buildingid,machineid);
                        };
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//修改预设点
//传参(类型：字符):areaname,fenbuname,ywbname,stationname,buildingname,
//machinename,ysdindex 返回1[成功]，0[失败]
function device_editYsd(machineid,ysdid,ysdname){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_modifyysd',
                dataType:'JSON',
                data:{
                        machineid:machineid,
                        ysdid:ysdid,
                        ysdindex:ysdname
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        device_getYsdJkq(machineid);
                },
                error:function(err){
                        console.log(err)
                }

        });
}
//添加预设点
//传参(类型：字符):areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdindex
//【工区名称，分部名称，运维班名称，变电站名称，设备区名称，抓拍设备名称，预设点编号】
function device_addYsd(machineid,ysdNumbers){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_addysd_OneKey',
                dataType:'JSON',
                data:{
                        machineid:machineid,
                        ysdNumbers:ysdNumbers,
                },
                success:function(data){
                        if(data[0].status==0){
                                layer.msg(data[0].msg, {icon:2,time:2000});
                        }else{
                                layer.msg(data[0].msg, {icon:1,time:2000});
                                $(".ysd_addC").css("display","none");
                                device_getYsdJkq(machineid);
                        }
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//删除预设点
//传参(类型：字符):  id返回1[成功]，0[失败]
function device_delYsd(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_deleteysd',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        
                        // user_getYwbAll();
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 监测设备(设备)
//获取当前预设点下所有设备 
//参数  ysdid
function device_getShebeiYsd(ysdid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_getdeviceByysd',
                dataType:'JSON',
                data:{
                        ysdid:ysdid, 
                },
                success:function(data){
                        var html='';
                        for(var i=0;i<data.length;i++){
                                html+='<li class="li-item"><div class="item_left fl"><span>'
                                        +data[i].devicename+'</span></div><div class="item_right fr"><a class="shebei_event ac_edit edit7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="shebei_event ac_del del7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li>';
                                
                                
                                
                        }
                        $("#shebei_ul").html(html);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//获取某个监测设备，返回：监测设备信息
//参数 id
function device_getShebeiNows(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_getdeviceByid',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
					
                        for(var i=0;i<data.length;i++){
                                areaname_Sel=data[i].areaname;
                                setTimeout(function(){
                                        $("#device_editshebei1 option").each(function(){
                                                if($(this).val() ==areaname_Sel ){
                                                        $(this).attr('selected',true)
                                                }
                                        });
                                },100);
                                fenbuname_sel=data[i].fenbuname;
                                ywbname_sel=data[i].ywbname;
                                stationname_sel=data[i].stationname;
                                buildingname_sel=data[i].buildingname;
                                machinename_sel=data[i].machinename;
                                ysdname_sel=data[i].ysdname;
                                $("#device_editshebei8").val(data[i].devicename);//设备名称
                                $("#device_editshebei10").val(data[i].offsetvalue);//告警阈值
                                $("#device_editshebei11").val(data[i].ysdtype);//预设点类型
                                $("#device_editshebei12").val(data[i].ysdlevel);//预设点等级
                                $("#device_editshebei13").val(data[i].operaterNumber);//运行编号
								$("#device_editshebei14").val(data[i].distance);//设定距离
								
                                var areaid=data[0].areaid;
                                var fenbuid=data[0].fenbuid;
                                var ywbid=data[0].ywbid;
                                var stationid=data[0].stationid;
                                var buildingid=data[0].buildingid;
                                var machineid=data[0].machineid;
                                var deviceid=data[0].deviceid;

                                moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);

                                //top_seldevice(userid,areaid,fenbuid,ywbid,stationid,buildingid,deviceid,machineid);
                        };
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//修改监测设备
//传参(类型：字符):areaname,fenbuname,ywbname,stationname,buildingname,machinename,ysdindex,distince 返回1[成功]，0[失败]
function device_editShebei(ysdid,deviceid,devicename,offsetvalue, ysdtype, ysdlevel,operaterNumber,distince){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_modifydevice',
                dataType:'JSON',
                data:{
                        ysdid:ysdid,
                        deviceid:deviceid,
                        devicename:devicename,
                        // distance:distance,//距离
                        offsetvalue:offsetvalue,
                        ysdtype:ysdtype,
                        ysdlevel:ysdlevel,
                        operaterNumber:operaterNumber,
						distince:distince
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        device_getShebeiYsd(ysdid);
                },
                error:function(err){
                        console.log(err)
                }

        });
}
//添加监测设备
//传参(类型：字符):areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdindex, devicename,
// distance, offsetvalue, ysdtype, ysdlevel,operaterNumber
//【工区名称，分部名称，运维班名称，变电站名称，设备区名称，抓拍设备名称，预设点编号，设备名称，距离，负荷，告警阈值，
//预设点类型，预设点等级,运行编号，设定距离】
function device_addShebei(ysdid,devicename,offsetvalue, ysdtype, ysdlevel,operaterNumber,distince){
        
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_adddevice',
                dataType:'JSON',
                data:{
                        ysdid:ysdid,
                        devicename:devicename,
                        offsetvalue:offsetvalue,
                        ysdtype:ysdtype,
                        ysdlevel:ysdlevel,
                        operaterNumber:operaterNumber,
						distince:distince
                },
                success:function(data){
					var str = data[0].msg.split('#')[0];
                        if(data[0].status==0){
                                layer.msg(str, {icon:1,time:1500});
                        }else{
                                layer.msg(str, {icon:1,time:1000});
                                $(".shebei_addC").css("display","none");
                                device_getShebeiYsd(ysdid);
                        }

                },
                error:function(err){
                        console.log(err)
                }

        });
};
//删除设备
//传参(类型：字符): id
function device_delShebei(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_deletedevice',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        layer.msg(data[0].msg, {time:1000});
                        
                        // user_getYwbAll();
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 用户管理
function user_getAll(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/d_getAlluser',
                dataType:'JSON',
                data:{ 
                        userid:userid
                },
                success:function(data){
                        var html='';
                        var html2='';
                        var html3='';
                        for(let item of data){
                                // 0工区用户，1分部用户，2运维班用户
                                
                                if(item.usertype==0){
                                        html+=`<li class="li-item">
                                        <div class="item_left fl" data-areaid="${item.areaid}">
                                                <span>${item.username}</span>
                                        </div>`;

                                        if(item.show==1){
                                                html+=`<div class="item_right fr">
                                                <a class="area_event ac_edit edit1 layui-btn layui-btn-xs" data-id="${item.userid}" data-areanames="${item.username}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="area_event ac_del del1 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                <button class="area_event reset_btn1" data-username="${item.username}" 
                                                        data-areaname="${item.areaname}" data-fenbuname="${item.fenbuname}" data-ywbname="${item.ywbname}" data-event="reset_pwd">重置密码</button>
                                                </div> `; 
                                        };

                                        html+=`</li>`;
                                        $("#gqUser_ul").html(html);
                                }else if(item.usertype==1){
                                        html2+=`<li class="li-item" >
                                        <div class="item_left fl" data-fenbuid="${item.fenbuid}">
                                                <span>${item.username}</span>
                                        </div>`;
                                        if(item.show==1){
                                                html2+=`<div class="item_right fr">
                                                <a class="fenbu_event ac_edit edit2 layui-btn layui-btn-xs" data-id="${item.userid}" data-areanames="${item.username}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="fenbu_event ac_del del2 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                <button class="fenbu_event reset_btn2" data-username="${item.username}" 
                                                data-areaname="${item.areaname}" data-fenbuname="${item.fenbuname}" data-ywbname="${item.ywbname}" data-event="reset_pwd">重置密码</button>
                                                </div>`;
                                        }
                                        
                                        html2+=`</li>`;
                                        $("#fenbuUser_ul").html(html2);
                                }else if(item.usertype==2){
                                        html3+=`<li class="li-item">
                                        <div class="item_left fl">
                                                <span>${item.username}</span>
                                        </div>`;
                                        if(item.show==1){
                                                html3+=`<div class="item_right fr">
                                                <a class="ywb_event ac_edit edit3 layui-btn layui-btn-xs" data-id="${item.userid}" data-areanames="${item.username}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="ywb_event ac_del del3 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                <button class="ywb_event reset_btn3" data-username="${item.username}" 
                                                data-areaname="${item.areaname}" data-fenbuname="${item.fenbuname}" data-ywbname="${item.ywbname}" data-event="reset_pwd">重置密码</button>
                                                </div>`;
                                        }
                                        html3+=`</li>`;
                                        $("#ywbUser_ul").html(html3);
                                }else if(item.usertype==3){
                                        console.log("超级管理员登录")
                                }else{
                                        console.log("无此用户")  
                                }
                        }
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 工区下的用户
function user_getareaAll(areaid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/d_getuserByarea',
                dataType:'JSON',
                data:{ 
                        areaid:areaid
                },
                success:function(data){
                        var html='';
                        var html2='';
                        var html3='';
                        for(let item of data){
                                // 0工区用户，1分部用户，2运维班用户
                                // if(item.usertype==0){
                                //         html+=`<li class="li-item">
                                //         <div class="item_left fl" data-areaname="${item.areaname}">
                                //                 <span>${item.username}</span>
                                //         </div>
                                //         <div class="item_right fr">
                                //                 <a class="area_event ac_edit edit1 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="edit">
                                //                         <i class="layui-icon layui-icon-edit"></i>
                                //                 </a>
                                //                 <a class="area_event ac_del del1 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="del">
                                //                         <i class="layui-icon layui-icon-delete"></i>
                                //                 </a>
                                //                 <button class="area_event reset_btn1" data-username="${item.username}" 
                                //                         data-areaname="${item.areaname}" data-fenbuname="${item.fenbuname}" data-ywbname="${item.ywbname}" data-event="reset_pwd">重置密码</button>
                                //         </div>
                                //         </li>`;
                                //         $("#gqUser_ul").html(html);
                                // }else 
                                if(item.usertype==1){
                                        html2+=`<li class="li-item" >
                                        <div class="item_left fl" data-fenbuid="${item.fenbuid}">
                                                <span>${item.username}</span>
                                        </div>`;
                                        if(item.show==1){
                                                html2+=`<div class="item_right fr">
                                                <a class="fenbu_event ac_edit edit2 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="fenbu_event ac_del del2 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                <button class="fenbu_event reset_btn2" data-username="${item.username}" 
                                                data-areaname="${item.areaname}" data-fenbuname="${item.fenbuname}" data-ywbname="${item.ywbname}" data-event="reset_pwd">重置密码</button>
                                                </div>`;
                                        }
                                        
                                        html2+=`</li>`;
                                        $("#fenbuUser_ul").html(html2);
                                }else if(item.usertype==2){
                                        html3+=`<li class="li-item">
                                        <div class="item_left fl">
                                                <span>${item.username}</span>
                                        </div>`;
                                        if(item.show==1){
                                                html3+=`<div class="item_right fr">
                                                <a class="ywb_event ac_edit edit3 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="ywb_event ac_del del3 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                <button class="ywb_event reset_btn3" data-username="${item.username}" 
                                                data-areaname="${item.areaname}" data-fenbuname="${item.fenbuname}" data-ywbname="${item.ywbname}" data-event="reset_pwd">重置密码</button>
                                                </div>`;
                                        }
                                        html3+=`</li>`;
                                        $("#ywbUser_ul").html(html3);
                                }else if(item.usertype==3){
                                        console.log("超级管理员登录")
                                }else{
                                        console.log("无此用户")  
                                }
                        }
               
                },
                error:function(err){
                        console.log(err)
                }

        });  
};
// 分部下的用户
function user_getfenbuAll(fenbuid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/d_getuserByfenbu',
                dataType:'JSON',
                data:{ 
                        fenbuid:fenbuid
                },
                success:function(data){
                        var html='';
                        var html2='';
                        var html3='';
                        for(let item of data){
                                // 0工区用户，1分部用户，2运维班用户
                                // if(item.usertype==0){
                                //         html+=`<li class="li-item">
                                //         <div class="item_left fl" data-areaname="${item.areaname}">
                                //                 <span>${item.username}</span>
                                //         </div>
                                //         <div class="item_right fr">
                                //                 <a class="area_event ac_edit edit1 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="edit">
                                //                         <i class="layui-icon layui-icon-edit"></i>
                                //                 </a>
                                //                 <a class="area_event ac_del del1 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="del">
                                //                         <i class="layui-icon layui-icon-delete"></i>
                                //                 </a>
                                //                 <button class="area_event reset_btn1" data-username="${item.username}" 
                                //                         data-areaname="${item.areaname}" data-fenbuname="${item.fenbuname}" data-ywbname="${item.ywbname}" data-event="reset_pwd">重置密码</button>
                                //         </div>
                                //         </li>`;
                                //         $("#gqUser_ul").html(html);
                                // }else if(item.usertype==1){
                                //         html2+=`<li class="li-item"  data-ywbname="${item.ywbname}">
                                //         <div class="item_left fl">
                                //                 <span>${item.username}</span>
                                //         </div>
                                //         <div class="item_right fr">
                                //                 <a class="fenbu_event ac_edit edit2 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="edit">
                                //                         <i class="layui-icon layui-icon-edit"></i>
                                //                 </a>
                                //                 <a class="fenbu_event ac_del del2 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="del">
                                //                         <i class="layui-icon layui-icon-delete"></i>
                                //                 </a>
                                //                 <button class="fenbu_event reset_btn2" data-username="${item.username}" 
                                //                 data-areaname="${item.areaname}" data-fenbuname="${item.fenbuname}" data-ywbname="${item.ywbname}" data-event="reset_pwd">重置密码</button>
                                //         </div>
                                //         </li>`;
                                //         $("#fenbuUser_ul").html(html2);
                                // }else 
                                if(item.usertype==2){
                                        html3+=`<li class="li-item">
                                        <div class="item_left fl">
                                                <span>${item.username}</span>
                                        </div>`;
                                        if(item.show==1){
                                                html3+=`<div class="item_right fr">
                                                <a class="ywb_event ac_edit edit3 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="ywb_event ac_del del3 layui-btn layui-btn-xs" data-id="${item.userid}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                <button class="ywb_event reset_btn3" data-username="${item.username}" 
                                                data-areaname="${item.areaname}" data-fenbuname="${item.fenbuname}" data-ywbname="${item.ywbname}" data-event="reset_pwd">重置密码</button>
                                                </div>`;
                                        }
                                        html3+=`</li>`;
                                        $("#ywbUser_ul").html(html3);
                                }else if(item.usertype==3){
                                        console.log("超级管理员登录")
                                }else{
                                        console.log("无此用户")  
                                }
                        }
                },
                error:function(err){
                        console.log(err)
                }

        });  
};
// 获取当前用户 id
function user_getOneAll(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/d_getuserByid',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        areaname_Sel=data[0].areaname;
                        setTimeout(function(){
                                $("#user_editArea1 option").each(function(){
                                        if($(this).val() ==areaname_Sel ){
                                                $(this).attr('selected',true)
                                        }
                                });
                        },100);
                        // fenbuname_sel=data[0].fenbuname;
                        // ywbname_sel=data[0].ywbname;
                        //工区
                        $("#user_editArea2").val(data[0].username);
						$("#user_editArea22").val(data[0].username);
                        $("#user_editArea3").val(data[0].password);
                        
                        if(data[0].usertype=0){
                                $("#user_editArea4").val("工区用户");   
                        }
                        $("#user_editArea5").val(data[0].city);
                        $("#user_editArea6").val(data[0].manager);
                        $("#user_editArea7").val(data[0].phone);
                        
                        
                        //分部
                        areaname_Sel=data[0].areaname;
                        setTimeout(function(){
                                $("#user_editFenbu1 option").each(function(){
                                        if($(this).val() ==areaname_Sel ){
                                                $(this).attr('selected',true)
                                        }
                                });
                        },100);
                        fenbuname_sel=data[0].fenbuname;
                        // ywbname_sel=data[0].ywbname;
                        // $("#user_editFenbu1").val(data[0].areaname);
                        // $("#user_ediFenbu2").val(data[0].fenbuname);
                        // $("#user_editFenbu3").val(data[0].ywbname);
                        $("#user_editFenbu3").val(data[0].username);
						$("#user_editFenbu32").val(data[0].username);
                        $("#user_editFenbu4").val(data[0].password);
                        if(data[0].usertype==1){
                                $("#user_editFenbu5").val("分部用户");   
                        }
                        // $("#user_editFenbu5").val(data[0].usertype);
                        $("#user_editFenbu6").val(data[0].city);
                        $("#user_editFenbu7").val(data[0].manager);
                        $("#user_editFenbu8").val(data[0].phone);


                        //运维班
                        areaname_Sel=data[0].areaname;
                        setTimeout(function(){
                                $("#user_editYwb1 option").each(function(){
                                        if($(this).val() ==areaname_Sel ){
                                                $(this).attr('selected',true)
                                        }
                                });
                        },100);
                        fenbuname_sel=data[0].fenbuname;
                        ywbname_sel=data[0].ywbname;
                        
                        $("#user_editYwb4").val(data[0].username);
						$("#user_editYwb42").val(data[0].username);
                        $("#user_editYwb5").val(data[0].password);
                        if(data[0].usertype==2){
                                $("#user_editYwb6").val("运维班用户");   
                        }
                        // $("#user_editYwb6").val(data[0].usertype);
                        $("#user_editYwb7").val(data[0].city);
                        $("#user_editYwb8").val(data[0].manager);
                        $("#user_editYwb9").val(data[0].phone);

                        var areaid=data[0].areaid;
                        var fenbuid=data[0].fenbuid;
                        var ywbid=data[0].ywbid;

                        moren(areaid,fenbuid,ywbid);
                        // moren(areaname_Sel,fenbuname_sel,ywbname_sel);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 修改
// 参数 修改用户信息 areaname, fenbuname, ywbname, username,oldusername, password, usertype, city, manager, phone
function user_geteditAll(areaname,fenbuname,ywbname,username,oldusername,password,usertype,city,manager,phone,oldusername){
        if(areaname==undefined||areaname==null){
                areaname=''
        };
        if(fenbuname==undefined||fenbuname==null){
                fenbuname=''
        };
        if(ywbname==undefined||ywbname==null){
                ywbname=''
        };
		console.log(oldusername);
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/d_modifyuser',
                dataType:'JSON',
                data:{
                        areaname:areaname,
                        fenbuname:fenbuname,
                        ywbname:ywbname,
                        username:username,
						oldusername:oldusername,
                        password:password,
                        usertype:usertype,
                        city:city,
                        manager:manager,
                        phone:phone,
                        oldusername:oldusername
                },
                success:function(data){
					console.log(data);
                        layer.msg(data[0].msg, {icon: 1,time:500})
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 删除
function user_getdel(id){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/d_deleteuser',
                dataType:'JSON',
                data:{
                        id:id,
                },
                success:function(data){
                        layer.msg(data[0].msg, {icon: 1,time:500})
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};

//重置密码   公司 、工区、运维班
//传参(类型：字符):areaname,fenbuname,ywbname,username,oldpassword,newpassword1,newpassword2【旧密码，新密码，重复新密码】  返回1表示成功，返回2表示新密码两次不匹配，返回3表示旧密码不正确，返回0表示没有此用户
function user_resetywb(areaname,fenbuname,ywbname,username,oldpassword,newpassword1,newpassword2){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/d_changepassword',
                dataType:'JSON',
                data:{
                        areaname:areaname,
                        fenbuname:fenbuname,
                        ywbname:ywbname,
                        username:username,
                        oldpass:oldpassword,
                        newpass:newpassword1,
                        newpassrepeat:newpassword2,
                },
                success:function(data){
                        // var username=username;
                        // var oldpassword=oldpassword;
                        // var newpassword1=newpassword1;
                        // var newpassword2=newpassword2;
                        if(username==''||oldpassword==''||newpassword1==''||newpassword2==''){
                                layer.msg("请输入", {icon: 2,time:500}) 
                        }else{
                                layer.msg(data[0].msg, {time:500})
                                // if(data==0){
                                //         layer.msg("没有此用户", {icon: 2,time:500})
                                // }else if(data==1){
                                //         layer.msg("修改成功", {icon: 1,time:500})
                                // }else if(data==2){
                                //         layer.msg("新密码两次不匹配", {icon: 2,time:500})
                                // }else if(data==3){
                                //         layer.msg("旧密码不正确", {icon: 2,time:500})
                                // }else{
                                //         layer.msg("请重新输入", {icon: 2,time:500}) 
                                // }
                        }
                        
                        


                },
                error:function(err){
                        console.log(err)
                }

        });
};

//添加
// areaname, fenbuname, ywbname, username, password, usertype, city, manager, phone
//【工区名称，分部名称，运维班名称，用户名，密码，用户类型，城市，员工，电话】
function user_getaddAll(areaname,fenbuname,ywbname,username,password,usertype,city,manager,phone){
        if(areaname=='请选择'){
                areaname=''
        };
        if(fenbuname=='请选择'){
                fenbuname=''
        };
        if(ywbname=='请选择'){
                ywbname=''
        };
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/d_adduser',
                dataType:'JSON',
                data:{
                        areaname:areaname,
                        fenbuname:fenbuname,
                        ywbname:ywbname,
                        username:username,
                        password:password,
                        usertype:usertype,
                        city:city,
                        manager:manager,
                        phone:phone
                },
                success:function(data){
                        alert(data[0].msg);
                        // layer.msg(data[0].msg, {icon:1,time:1000});
                        // var ysdid='';
                        // var vals=$("#device_addshebei7").val();
                        // $("#device_addshebei7 option").each(function(){
                        //         if($(this).val() ==vals){
                        //                 ysdid= $(this).attr("data-ysdid");
                        //         }
                        // });
                        // if(!ysdid){
                        //         setTimeout(function(){
                        //         shebeiAll(userid);
                        //         },500);
                        // }else{
                        //         setTimeout(function(){
                        //         device_getShebeiYsd(ysdid);
                        //         },500);
                        // };
                        // $(".user_tanchuaddWorkArea").css("display","none");
                },
                error:function(err){
                        console.log(err)
                }

        });
};


// 头部选择

// 工区
function getareaAll(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/a_getAllarea',
                dataType:'JSON',
                data:{
                        userid:userid
                },
                success:function(data){
                        var html='';
                        
                        for(let item of data){
                                if(item.areaname==areaname){
                                        html+=`<li class="table_active" data-areaname="${item.areaname}">${item.areaname}</li>`;
                                }else{
                                        html+=`<li data-areaid="${data[i].areaid}" data-areaname="${item.areaname}">${item.areaname}</li>`;
                                }
                                
                        }
                        $("#tab").html(html);
                        // $("#tab").find("li:first-child").addClass("table_active");
                },
                error:function(err){
                        console.log(err)
                }

        });
};


// 默认全部
//参数：工区(areaname)
//工区下的所有分部
function getfenbuAll(areaid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/b_getfenbuByarea',
                dataType:'JSON',
                data:{
                        areaid:areaid
                },
                success:function(data){
                        var html='<span data-fenbuid="全部" data-fenbuname="全部" class="select">全部</span>';
                        var html1='';
                        var html2='';
                        for(var i=0;i<data.length;i++){
                                html+='<span data-fenbuid="'+data[i].fenbuid+'" data-fenbuname="'+data[i].fenbuname+'">'+data[i].fenbuname+'</span>';
                                html1+='<span data-fenbuid="'+data[i].fenbuid+'" data-fenbuname="'+data[i].fenbuname+'">'+data[i].fenbuname+'</span>';
                                html2+='<li class="li-item"><div class="item_left fl" data-fenbuid="'
                                        +data[i].fenbuid+
                                        '"><span>'
                                        +data[i].fenbuname+
                                        '</span></div><div class="item_right fr"><a class="fenbu_event ac_edit edit2 layui-btn layui-btn-xs" data-fenbuid="'
                                        +data[i].fenbuid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="fenbu_event ac_del del2 layui-btn layui-btn-xs" data-fenbuid="'
                                        +data[i].fenbuid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div><div class="clear"></div>';
                                
                        }
                        $("#fenbuDD").html(html);
                        $("#fenbuDDcw").html(html);
                        $("#fenbuDDdevice").html(html);
                        $("#fenbu_ulDD").html(html1);
                        $("#fenbu_ul").html(html2);
                        $("#fenbuEdit_ul").html(html2);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//工区下的所有运维班
function getywbAll_area(areaid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/c_getywbByarea',
                dataType:'JSON',
                data:{
                        areaid:areaid
                },
                success:function(data){
                        var html='<span data-ywbid="全部" data-ywbname="全部" class="select">全部</span>';
                        var html2='';
                        var html3='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-ywbname="${data[i].ywbname}" data-ywbid="${data[i].ywbid}">${data[i].ywbname}</span>`;
                                html3+=`<span data-ywbname="${data[i].ywbname}" data-ywbid="${data[i].ywbid}">${data[i].ywbname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-ywbid="'
                                        +data[i].ywbid+
                                        '"><span>'
                                        +data[i].ywbname+'</span></div><div class="item_right fr"><a class="ywb_event ac_edit edit3 layui-btn layui-btn-xs" data-ywbid="'
                                        +data[i].ywbid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="ywb_event ac_del del3 layui-btn layui-btn-xs" data-ywbid="'
                                        +data[i].ywbid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        }
                        $("#ywbDD").html(html);
                        $("#ywbDDcw").html(html);
                        $("#ywbDDdevice").html(html);
                        $("#ywb_ulDD").html(html3);
                        $("#ywb_ul").html(html2);
                        $("#ywbEdit_ul").html(html2);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//工区下的所有变电站
function getbdzAll_area(areaid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/e_getstationByarea',
                dataType:'JSON',
                data:{
                        areaid:areaid
                },
                success:function(data){
                        var html='<span data-stationid="全部" data-stationname="全部" class="select">全部</span>';
                        var html2='';
                        var html3='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-stationname="${data[i].stationname}" data-stationid="${data[i].stationid}">${data[i].stationname}</span>`;
                                html3+=`<span data-stationname="${data[i].stationname}" data-stationid="${data[i].stationid}">${data[i].stationname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-stationid="'
                                        +data[i].stationid+
                                        '"><span>'
                                        +data[i].stationname+'</span></div><div class="item_right fr"><a class="bdz_event ac_edit edit4 layui-btn layui-btn-xs" data-stationid="'
                                        +data[i].stationid+
                                        '" data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="bdz_event ac_del del4 layui-btn layui-btn-xs" data-stationid="'
                                        +data[i].stationid+
                                        '"data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        }
                        $("#bdzDD").html(html);
                        $("#bdzDDcw").html(html);
                        $("#bdzDDdevice").html(html);
                        $("#bdz_ulDD").html(html3);
                        $("#bdz_ul").html(html2);
                        $("#bdzEdit_ul").html(html2);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//工区下的所有设备区
function getsbqAll_area(areaid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/f_getbuildingByarea',
                dataType:'JSON',
                data:{
                        areaid:areaid
                },
                success:function(data){
                        var html='<span data-buildingid="全部" data-buildingname="全部" class="select">全部</span>';
                        var html2='';
                        var html3='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-buildingid="${data[i].buildingid}" data-buildingname="${data[i].buildingname}">${data[i].buildingname}</span>`;
                                html3+=`<span data-buildingid="${data[i].buildingid}" data-buildingname="${data[i].buildingname}">${data[i].buildingname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-buildingid="'
                                        +data[i].buildingid +
                                        '"><span>'
                                        +data[i].buildingname+
                                        '</span></div><div class="item_right fr"><a class="sbj_event ac_edit edit5 layui-btn layui-btn-xs" data-buildingid="'
                                        +data[i].buildingid +
                                        '" data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="sbj_event ac_del del5 layui-btn layui-btn-xs" data-buildingid="'
                                        +data[i].buildingid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        }
                        $("#sbqDD").html(html);
                        $("#sbqDDcw").html(html);
                        $("#sbqDDdevice").html(html);
                        
                        $("#sbq_ulDD").html(html3);
                        $("#sbq_ul").html(html2);
                        $("#sbqEdit_ul").html(html2);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//工区下的所有监视设备(抓拍设备)
function getmachineAll_area(areaid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/g_getmachineByarea',
                dataType:'JSON',
                data:{
                        areaid:areaid
                },
                success:function(data){
                        var html='<span data-machineid="全部" data-machinename="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+='<span data-machineid="'+data[i].machineid+'" data-machinename="'+data[i].machinename+'">'+data[i].machinename+'</span>';
                                html1+='<li class="li-item" ><div class="item_left fl" data-machineid="'
                                        +data[i].machineid+'"><span>'
                                        +data[i].machinename+'</span></div><div class="item_right fr"><a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        }
                        $("#jianshiDD").html(html);
                        $("#status_shebeiDD").html(html);
                        $("#jianshiDDdevice").html(html);
                        
                        $("#jkq_ul").html(html1);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//工区下的预设点
function getysdAll_area(areaid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_getysdByarea',
                dataType:'JSON',
                data:{
                        areaid:areaid
                },
                success:function(data){
                        
                        var html='';
                        for(var i=0;i<data.length;i++){

                                html+='<li class="li-item"><div class="item_left fl" data-ysdid="'
                                        +data[i].ysdid+'"><span>'
                                        +data[i].ysdname+'</span></div><div class="upDownTZ fl"><button class="btnUp" data-ysdid="'
                                        +data[i].ysdid+'"></button><button class="btnDown" data-ysdid="'
                                        +data[i].ysdid+'"></button></div><div class="item_right fr"><a class="ysd_event ac_edit edit7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="ysd_event ac_del del7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                        }
                        $("#ysd_ul").html(html);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//工区下的所有设备
function getshebeiAll_area(areaid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_getdeviceByarea',
                dataType:'JSON',
                data:{
                        areaid:areaid
                },
                success:function(data){
                        var html='<span data-deviceid="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-deviceid="${data[i].deviceid}">${data[i].devicename}</span>`;
                                html1+='<li class="li-item"><div class="item_left fl"><span>'
                                        +data[i].devicename+'</span></div><div class="item_right fr"><a class="shebei_event ac_edit edit7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="shebei_event ac_del del7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        };
                        $("#sheibeiDD").html(html);
                        $("#sheibeiDDdevice").html(html);
                        
                        $("#shebei_ul").html(html1);
                        
                },
                error:function(err){
                        console.log(err)
                }

        });
};

//点击分部
// 所有运维班
function getywbAll(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/c_getAllywb',
                dataType:'JSON',
                data:{
                        userid:userid
                },
                success:function(data){
                        
                        var html='<span data-ywbid="全部" data-ywbname="全部" class="select">全部</span>',
                            html2='',html3='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-ywbname="${data[i].ywbname}" data-ywbid="${data[i].ywbid}">${data[i].ywbname}</span>`;
                                html3+=`<span data-ywbname="${data[i].ywbname}" data-ywbid="${data[i].ywbid}">${data[i].ywbname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-ywbid="'
                                        +data[i].ywbid+
                                        '"><span>'
                                        +data[i].ywbname+'</span></div><div class="item_right fr"><a class="ywb_event ac_edit edit3 layui-btn layui-btn-xs" data-ywbid="'
                                        +data[i].ywbid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="ywb_event ac_del del3 layui-btn layui-btn-xs" data-ywbid="'
                                        +data[i].ywbid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        };
                        $("#ywbDD").html(html);
                        $("#ywbDDcw").html(html);
                        $("#ywbDDdevice").html(html);
                        
                        $("#ywb_ulDD").html(html3);
                        $("#ywb_ul").html(html2);
                        $("#ywbEdit_ul").html(html2);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//  参数fenbuid:
//当前分部下的所有运维班
function fenbu_getywbAll(fenbuid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/c_getywbByfenbu',
                dataType:'JSON',
                data:{
                        fenbuid:fenbuid,
                },
                success:function(data){
                        var html='<span data-ywbid="全部" data-ywbname="全部" class="select">全部</span>',
                            html2='',html3='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-ywbname="${data[i].ywbname}" data-ywbid="${data[i].ywbid}">${data[i].ywbname}</span>`;
                                html3+=`<span data-ywbname="${data[i].ywbname}" data-ywbid="${data[i].ywbid}">${data[i].ywbname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-ywbid="'
                                        +data[i].ywbid+
                                        '"><span>'
                                        +data[i].ywbname+'</span></div><div class="item_right fr"><a class="ywb_event ac_edit edit3 layui-btn layui-btn-xs" data-ywbid="'
                                        +data[i].ywbid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="ywb_event ac_del del3 layui-btn layui-btn-xs" data-ywbid="'
                                        +data[i].ywbid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        };
                        $("#ywbDD").html(html);
                        $("#ywbDDcw").html(html);
                        $("#ywbDDdevice").html(html);
                        
                        $("#ywb_ulDD").html(html3);
                        $("#ywb_ul").html(html2);
                        $("#ywbEdit_ul").html(html2);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//分部下的所有变电站
function fenbu_getbdzAll(fenbuid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/e_getstationByfenbu',
                dataType:'JSON',
                data:{
                        fenbuid:fenbuid
                },
                success:function(data){
                       
                        var html1='<span data-stationid="全部" data-stationname="全部" class="select">全部</span>',
                            html2='',html3='';
                        for(var i=0;i<data.length;i++){
                                html1+=`<span data-stationname="${data[i].stationname}" data-stationid="${data[i].stationid}">${data[i].stationname}</span>`;
                                html3+=`<span data-stationname="${data[i].stationname}" data-stationid="${data[i].stationid}">${data[i].stationname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-stationid="'
                                        +data[i].stationid+
                                        '"><span>'
                                        +data[i].stationname+'</span></div><div class="item_right fr"><a class="bdz_event ac_edit edit4 layui-btn layui-btn-xs" data-stationid="'
                                        +data[i].stationid+
                                        '" data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="bdz_event ac_del del4 layui-btn layui-btn-xs" data-stationid="'
                                        +data[i].stationid+
                                        '"data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        };
                        $("#bdzDD").html(html1);
                        $("#bdzDDcw").html(html1);
                        $("#bdzDDdevice").html(html1);
                        
                        $("#bdz_ulDD").html(html3);
                        $("#bdz_ul").html(html2);
                        $("#bdzEdit_ul").html(html2);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//分部下的所有设备区
function fenbu_getsbqAll(fenbuid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/f_getbuildingByfenbu',
                dataType:'JSON',
                data:{
                        fenbuid:fenbuid
                },
                success:function(data){
                       
                        var html='<span data-buildingid="全部" data-buildingname="全部" class="select">全部</span>',
                            html2='',html3='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-buildingid="${data[i].buildingid}" data-buildingname="${data[i].buildingname}">${data[i].buildingname}</span>`;
                                html3+=`<span data-buildingid="${data[i].buildingid}" data-buildingname="${data[i].buildingname}">${data[i].buildingname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-buildingid="'
                                        +data[i].buildingid +
                                        '"><span>'
                                        +data[i].buildingname+
                                        '</span></div><div class="item_right fr"><a class="sbj_event ac_edit edit5 layui-btn layui-btn-xs" data-buildingid="'
                                        +data[i].buildingid +
                                        '" data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="sbj_event ac_del del5 layui-btn layui-btn-xs" data-buildingid="'
                                        +data[i].buildingid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        };
                        $("#sbqDD").html(html);
                        $("#sbqDDcw").html(html);
                        $("#sbqDDdevice").html(html);
                        
                        $("#sbq_ulDD").html(html3);
                        $("#sbq_ul").html(html2);
                        $("#sbqEdit_ul").html(html2);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//分部下的所有监视设备(抓拍设备)
function fenbu_getmachineAll(fenbuid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/g_getmachineByfenbu',
                dataType:'JSON',
                data:{
                        fenbuid:fenbuid
                },
                success:function(data){
                        var html='<span data-machineid="全部" data-machinename="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+='<span data-machineid="'+data[i].machineid+'" data-machinename="'+data[i].machinename+'">'+data[i].machinename+'</span>';
                                html1+='<li class="li-item" ><div class="item_left fl" data-machineid="'
                                        +data[i].machineid+'"><span>'
                                        +data[i].machinename+'</span></div><div class="item_right fr"><a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';     
                        };

                        $("#jianshiDD").html(html);
                        $("#jianshiDDcw").html(html);
                        $("#jianshiDDdevice").html(html);
                        $("#status_shebeiDD").html(html);
                        $("#jkq_ul").html(html1);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//分部下的预设点
function fenbu_getysdAll(fenbuid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_getysdByfenbu',
                dataType:'JSON',
                data:{
                        fenbuid:fenbuid
                },
                success:function(data){
                        
                        var html='';
                        for(var i=0;i<data.length;i++){

                                html+='<li class="li-item"><div class="item_left fl" data-ysdid="'
                                        +data[i].ysdid+'"><span>'
                                        +data[i].ysdname+'</span></div><div class="upDownTZ fl"><button class="btnUp" data-ysdid="'
                                        +data[i].ysdid+'"></button><button class="btnDown" data-ysdid="'
                                        +data[i].ysdid+'"></button></div><div class="item_right fr"><a class="ysd_event ac_edit edit7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="ysd_event ac_del del7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                        }
                        $("#ysd_ul").html(html);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//分部下的所有设备
function fenbu_getshebeiAll(fenbuid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_getdeviceByfenbu',
                dataType:'JSON',
                data:{
                        fenbuid:fenbuid
                },
                success:function(data){
                        var html='<span data-deviceid="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-deviceid="${data[i].deviceid}">${data[i].devicename}</span>`;
                                html1+='<li class="li-item"><div class="item_left fl"><span>'
                                        +data[i].devicename+'</span></div><div class="item_right fr"><a class="shebei_event ac_edit edit7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="shebei_event ac_del del7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                                
                                
                        };
                        $("#sheibeiDD").html(html);
                        $("#sheibeiDDdevice").html(html);
                        
                        $("#shebei_ul").html(html1);
                },
                error:function(err){
                        console.log(err)
                }

        });
};


// 点击运维班
// 所有变电站
function getbdzAll(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/e_getAllstation',
                dataType:'JSON',
                data:{
                        userid:userid
                },
                success:function(data){
                        
                        var html1='<span data-stationid="全部" data-stationname="全部" class="select">全部</span>',
                            html2='',html3='';
                        for(var i=0;i<data.length;i++){
                                html1+=`<span data-stationname="${data[i].stationname}" data-stationid="${data[i].stationid}">${data[i].stationname}</span>`;
                                html3+=`<span data-stationname="${data[i].stationname}" data-stationid="${data[i].stationid}">${data[i].stationname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-stationid="'
                                        +data[i].stationid+
                                        '"><span>'
                                        +data[i].stationname+'</span></div><div class="item_right fr"><a class="bdz_event ac_edit edit4 layui-btn layui-btn-xs" data-stationid="'
                                        +data[i].stationid+
                                        '" data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="bdz_event ac_del del4 layui-btn layui-btn-xs" data-stationid="'
                                        +data[i].stationid+
                                        '"data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        };
                        $("#bdzDD").html(html1);
                        $("#bdzDDcw").html(html1);
                        $("#bdzDDdevice").html(html1);
                        
                        $("#bdz_ulDD").html(html3);
                        $("#bdz_ul").html(html2);
                        $("#bdzEdit_ul").html(html2);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 参数 运维班（ywbid）
//当前运维班下的所有变电站
function ywb_getbdzAll(ywbid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/e_getstationByywb',
                dataType:'JSON',
                data:{
                        ywbid:ywbid
                },
                success:function(data){
                        
                        var html1='<span data-stationid="全部" data-stationname="全部" class="select">全部</span>',
                            html2='',html3='';
                        for(var i=0;i<data.length;i++){
                                html1+=`<span data-stationname="${data[i].stationname}" data-stationid="${data[i].stationid}">${data[i].stationname}</span>`;
                                html3+=`<span data-stationname="${data[i].stationname}" data-stationid="${data[i].stationid}">${data[i].stationname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-stationid="'
                                        +data[i].stationid+
                                        '"><span>'
                                        +data[i].stationname+'</span></div><div class="item_right fr"><a class="bdz_event ac_edit edit4 layui-btn layui-btn-xs" data-stationid="'
                                        +data[i].stationid+
                                        '" data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="bdz_event ac_del del4 layui-btn layui-btn-xs" data-stationid="'
                                        +data[i].stationid+
                                        '"data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        };
                        $("#bdzDDcw").html(html1);
                        $("#bdzDD").html(html1);
                        $("#bdzDDdevice").html(html1);
                        
                        $("#bdz_ulDD").html(html3);
                        $("#bdz_ul").html(html2);
                        $("#bdzEdit_ul").html(html2);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//运维班下的所有设备区
function ywb_getsbqAll(ywbid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/f_getbuildingByywb',
                dataType:'JSON',
                data:{
                        ywbid:ywbid
                },
                success:function(data){
                        
                        var html1='<span data-buildingid="全部" data-buildingname="全部" class="select">全部</span>',
                            html2='',html3='';
                        for(var i=0;i<data.length;i++){
                                html1+=`<span data-buildingid="${data[i].buildingid}" data-buildingname="${data[i].buildingname}">${data[i].buildingname}</span>`;
                                html3+=`<span data-buildingid="${data[i].buildingid}" data-buildingname="${data[i].buildingname}">${data[i].buildingname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-buildingid="'
                                        +data[i].buildingid +
                                        '"><span>'
                                        +data[i].buildingname+
                                        '</span></div><div class="item_right fr"><a class="sbj_event ac_edit edit5 layui-btn layui-btn-xs" data-buildingid="'
                                        +data[i].buildingid +
                                        '" data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="sbj_event ac_del del5 layui-btn layui-btn-xs" data-buildingid="'
                                        +data[i].buildingid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        };
                        $("#sbqDD").html(html1);
                        $("#sbqDDcw").html(html1);
                        $("#sbqDDdevice").html(html1);
                        
                        $("#sbq_ulDD").html(html3);
                        $("#sbq_ul").html(html2);
                        $("#sbqEdit_ul").html(html2);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//运维班下的所有监视设备(抓拍设备)
function ywb_getmachineAll(ywbid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/g_getmachineByywb',
                dataType:'JSON',
                data:{
                        ywbid:ywbid
                },
                success:function(data){
                        var html='<span data-machineid="全部" data-machinename="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+='<span data-machineid="'+data[i].machineid+'" data-machinename="'+data[i].machinename+'">'+data[i].machinename+'</span>';
                                html1+='<li class="li-item" ><div class="item_left fl" data-machineid="'
                                        +data[i].machineid+'"><span>'
                                        +data[i].machinename+'</span></div><div class="item_right fr"><a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';     
                        };
                        $("#jianshiDD").html(html);
                        $("#jianshiDDcw").html(html);
                        $("#jianshiDDdevice").html(html);
                        $("#status_shebeiDD").html(html);
                        $("#jkq_ul").html(html1);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//运维班下的预设点
function ywb_getysdAll(ywbid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_getysdByywb',
                dataType:'JSON',
                data:{
                        ywbid:ywbid
                },
                success:function(data){
                        
                        var html='';
                        for(var i=0;i<data.length;i++){

                                html+='<li class="li-item"><div class="item_left fl" data-ysdid="'
                                        +data[i].ysdid+'"><span>'
                                        +data[i].ysdname+'</span></div><div class="upDownTZ fl"><button class="btnUp" data-ysdid="'
                                        +data[i].ysdid+'"></button><button class="btnDown" data-ysdid="'
                                        +data[i].ysdid+'"></button></div><div class="item_right fr"><a class="ysd_event ac_edit edit7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="ysd_event ac_del del7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                        }
                        $("#ysd_ul").html(html);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//运维班下的所有设备
function ywb_getshebeiAll(ywbid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_getdeviceByywb',
                dataType:'JSON',
                data:{
                        ywbid:ywbid
                },
                success:function(data){
                        var html='<span data-deviceid="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-deviceid="${data[i].deviceid}">${data[i].devicename}</span>`;
                                html1+='<li class="li-item"><div class="item_left fl"><span>'
                                        +data[i].devicename+'</span></div><div class="item_right fr"><a class="shebei_event ac_edit edit7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="shebei_event ac_del del7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                                
                                
                        };
                        $("#sheibeiDD").html(html);
                        $("#sheibeiDDdevice").html(html);
                        
                        $("#shebei_ul").html(html1);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};



// 点击变电站
// 所有设备区
function getsbqAll(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/f_getAllbuilding',
                dataType:'JSON',
                data:{
                        userid:userid
                },
                success:function(data){
                       
                        var html1='<span data-buildingid="全部" data-buildingname="全部" class="select">全部</span>',
                            html2='',html3='';
                        for(var i=0;i<data.length;i++){
                                html1+=`<span data-buildingid="${data[i].buildingid}" data-buildingname="${data[i].buildingname}">${data[i].buildingname}</span>`;
                                html3+=`<span data-buildingid="${data[i].buildingid}" data-buildingname="${data[i].buildingname}">${data[i].buildingname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-buildingid="'
                                        +data[i].buildingid +
                                        '"><span>'
                                        +data[i].buildingname+
                                        '</span></div><div class="item_right fr"><a class="sbj_event ac_edit edit5 layui-btn layui-btn-xs" data-buildingid="'
                                        +data[i].buildingid +
                                        '" data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="sbj_event ac_del del5 layui-btn layui-btn-xs" data-buildingid="'
                                        +data[i].buildingid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        };
                        $("#sbqDD").html(html1);
                        $("#sbqDDcw").html(html1);
                        $("#sbqDDdevice").html(html1);
                        
                        $("#sbq_ulDD").html(html3);
                        $("#sbq_ul").html(html2);
                        $("#sbqEdit_ul").html(html2);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//参数 变电站(stationid)
//当前变电站下的所有设备区 
function bdz_getsbqAll(stationid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/f_getbuildingBystation',
                dataType:'JSON',
                data:{
                        stationid:stationid,
                },
                success:function(data){
                        
                        var html1='<span data-buildingid="全部" data-buildingname="全部" class="select">全部</span>',
                            html2='',html3='';
                        for(var i=0;i<data.length;i++){
                                html1+=`<span data-buildingid="${data[i].buildingid}" data-buildingname="${data[i].buildingname}">${data[i].buildingname}</span>`;
                                html3+=`<span data-buildingid="${data[i].buildingid}" data-buildingname="${data[i].buildingname}">${data[i].buildingname}</span>`;
                                html2+='<li class="li-item"><div class="item_left fl" data-buildingid="'
                                        +data[i].buildingid +
                                        '"><span>'
                                        +data[i].buildingname+
                                        '</span></div><div class="item_right fr"><a class="sbj_event ac_edit edit5 layui-btn layui-btn-xs" data-buildingid="'
                                        +data[i].buildingid +
                                        '" data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="sbj_event ac_del del5 layui-btn layui-btn-xs" data-buildingid="'
                                        +data[i].buildingid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        
                        };
                        $("#sbqDD").html(html1);
                        $("#sbqDDcw").html(html1);
                        $("#sbqDDdevice").html(html1);
                        
                        $("#sbq_ulDD").html(html3);
                        $("#sbq_ul").html(html2);
                        $("#sbqEdit_ul").html(html2);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//变电站下的所有监视设备(抓拍设备)
function bdz_getmachineAll(stationid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/g_getmachineBystation',
                dataType:'JSON',
                data:{
                        stationid:stationid
                },
                success:function(data){
                        var html='<span data-machineid="全部" data-machinename="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+='<span data-machineid="'+data[i].machineid+'" data-machinename="'+data[i].machinename+'">'+data[i].machinename+'</span>';
                                html1+='<li class="li-item" ><div class="item_left fl" data-machineid="'
                                        +data[i].machineid+'"><span>'
                                        +data[i].machinename+'</span></div><div class="item_right fr"><a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';     
                        };
                        $("#jianshiDD").html(html);
                        $("#jianshiDDcw").html(html);
                        $("#jianshiDDdevice").html(html);
                        $("#status_shebeiDD").html(html);
                        $("#jkq_ul").html(html1);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//变电站下的预设点
function bdz_getysdAll(stationid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_getysdBystation',
                dataType:'JSON',
                data:{
                        stationid:stationid
                },
                success:function(data){
                        
                        var html='';
                        for(var i=0;i<data.length;i++){

                                html+='<li class="li-item"><div class="item_left fl" data-ysdid="'
                                        +data[i].ysdid+'"><span>'
                                        +data[i].ysdname+'</span></div><div class="upDownTZ fl"><button class="btnUp" data-ysdid="'
                                        +data[i].ysdid+'"></button><button class="btnDown" data-ysdid="'
                                        +data[i].ysdid+'"></button></div><div class="item_right fr"><a class="ysd_event ac_edit edit7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="ysd_event ac_del del7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                        }
                        $("#ysd_ul").html(html);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//变电站下的所有设备
function bdz_getshebeiAll(stationid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_getdeviceBystation',
                dataType:'JSON',
                data:{
                        stationid:stationid
                },
                success:function(data){
                        var html='<span data-deviceid="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-deviceid="${data[i].deviceid}">${data[i].devicename}</span>`;
                                html1+='<li class="li-item"><div class="item_left fl"><span>'
                                        +data[i].devicename+'</span></div><div class="item_right fr"><a class="shebei_event ac_edit edit7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="shebei_event ac_del del7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                                
                                
                        };
                        $("#sheibeiDD").html(html);
                        $("#sheibeiDDdevice").html(html);
                        
                        $("#shebei_ul").html(html1);
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 点击设备区
// 参数  
//所有设备类型
function shebeiType(){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/j_getdevicetype',
                dataType:'JSON',
                data:{
                       
                },
                success:function(data){
                        var html='<span data-devicetype="全部" class="select">全部</span>';
                        for(let item of data){
                                html+=`<span data-devicetype="${item.devicetype}" >
                                        ${item.devicetype}
                                        </span>`;
                        }
                        
                        $("#sbTypeDD").html(html);
                        $("#sbTypeDDcw").html(html);

                        var optionStr ='<option value="">请选择</option>';
                        for(var i=0;i<data.length;i++){
                                optionStr+="<option class='selectYouzhi' data-devicetype='"+data[i].devicetype+"' value='"+data[i].devicetype+"'>"+data[i].devicetype+"</option>";
                        }
                        $("#device_addshebei11").html(optionStr);
                        $("#device_editshebei11").html(optionStr);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 所有监视设备 (抓拍设备)
function getjianshiAll(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/g_getAllmachine',
                dataType:'JSON',
                data:{
                        userid:userid
                },
                success:function(data){
                        var html='<span data-machineid="全部" data-machinename="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-machineid="${data[i].machineid}" data-machinename="${data[i].machinename}">${data[i].machinename}</span>`;
                                html1+='<li class="li-item"><div class="item_left fl" data-machineid="'
                                        +data[i].machineid+'"><span>'
                                        +data[i].machinename+'</span></div><div class="item_right fr"><a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                        };
                        $("#jianshiDD").html(html);
                        $("#jianshiDDcw").html(html);
                        $("#jianshiDDdevice").html(html);
                        $("#status_shebeiDD").html(html);
                        $("#jkq_ul").html(html1);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//当前设备区下的所有监视设备 (抓拍设备)
function sbq_getjianshiAll(buildingid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/g_getmachineBybuilding',
                dataType:'JSON',
                data:{
                        buildingid:buildingid,
                },
                success:function(data){
                        var html='<span data-machineid="全部" data-machinename="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-machineid="${data[i].machineid}" data-stationname="${data[i].stationname}" data-machinename="${data[i].machinename}">${data[i].machinename}</span>`;
                                
                                html1+='<li class="li-item" ><div class="item_left fl" data-machineid="'
                                        +data[i].machineid+'"><span>'
                                        +data[i].machinename+'</span></div><div class="item_right fr"><a class="jkq_event ac_edit edit5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="jkq_event ac_del del5 layui-btn layui-btn-xs" data-machineid="'
                                        +data[i].machineid+
                                        '"data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';     
                        };
                        $("#jianshiDD").html(html);
                        $("#jianshiDDcw").html(html);
                        $("#jianshiDDdevice").html(html);
                        $("#status_shebeiDD").html(html);
                        $("#jkq_ul").html(html1);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//设备区下的预设点
function sbq_getysdAll(buildingid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_getysdBybuilding',
                dataType:'JSON',
                data:{
                        buildingid:buildingid,
                },
                success:function(data){
                        
                        var html='';
                        for(var i=0;i<data.length;i++){

                                html+='<li class="li-item"><div class="item_left fl" data-ysdid="'
                                        +data[i].ysdid+'"><span>'
                                        +data[i].ysdname+'</span></div><div class="upDownTZ fl"><button class="btnUp" data-ysdid="'
                                        +data[i].ysdid+'"></button><button class="btnDown" data-ysdid="'
                                        +data[i].ysdid+'"></button></div><div class="item_right fr"><a class="ysd_event ac_edit edit7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="ysd_event ac_del del7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                        }
                        $("#ysd_ul").html(html);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
//设备区下的所有设备
function sbq_getshebeiAll(buildingid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_getdeviceBybuildingid',
                dataType:'JSON',
                data:{
                        buildingid:buildingid
                },
                success:function(data){
                        var html='<span data-deviceid="全部" class="select">全部</span>';
                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-deviceid="${data[i].deviceid}">${data[i].devicename}</span>`;
                                html1+='<li class="li-item"><div class="item_left fl"><span>'
                                        +data[i].devicename+'</span></div><div class="item_right fr"><a class="shebei_event ac_edit edit7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="shebei_event ac_del del7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                        };
                        $("#sheibeiDD").html(html);
                        $("#sheibeiDDdevice").html(html);
                        
                        $("#shebei_ul").html(html1);
                },
                error:function(err){
                        console.log(err)
                }

        });
};

//点击监控器
//监控器下的所有设备
function jkq_getshebeiAll(machineid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_getdeviceBymachine',
                dataType:'JSON',
                data:{
                        machineid:machineid
                },
                success:function(data){
                        var html='<span data-machineid="全部" data-machinename="全部" class="select">全部</span>',html1='';
                        
                        for(var i=0;i<data.length;i++){
                                html+=`<span data-deviceid="${data[i].deviceid}">${data[i].devicename}</span>`;
                                html1+='<li class="li-item"><div class="item_left fl"><span>'
                                        +data[i].devicename+'</span></div><div class="item_right fr"><a class="shebei_event ac_edit edit7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="shebei_event ac_del del7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                        }
                        $("#shebei_ul").html(html1);
                        
                        $("#sheibeiDD").html(html);
                        $("#sheibeiDDdevice").html(html);
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 所有预设点
function getysdAll(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/h_getAllysd',
                dataType:'JSON',
                data:{
                        userid:userid
                },
                success:function(data){
                        var html='';
                        for(var i=0;i<data.length;i++){

                                html+='<li class="li-item"><div class="item_left fl" data-ysdid="'
                                        +data[i].ysdid+'"><span>'
                                        +data[i].ysdname+'</span></div><div class="upDownTZ fl"><button class="btnUp" data-ysdid="'
                                        +data[i].ysdid+'"></button><button class="btnDown" data-ysdid="'
                                        +data[i].ysdid+'"></button></div><div class="item_right fr"><a class="ysd_event ac_edit edit7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="ysd_event ac_del del7 layui-btn layui-btn-xs" data-ysdid="'
                                        +data[i].ysdid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li>';
                        }
                        $("#ysd_ul").html(html);
                        
                },
                error:function(err){
                        console.log(err)
                }

        });
};



// 告警状态
function gaojingstatus(){
        var html=`<span data-is="全部" class="select">全部</span>
        <span data-is="0">已确认</span>
        <span data-is="1">未确认</span>`;

        $("#gaojingDD").html(html);
}


//设备状态页面：当前设备区 下的所有监视类型
function status_shebeiType(){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/l_getAllmachineType',
                dataType:'JSON',
                data:{
                       
                },
                success:function(data){
                        var html='<span data-machinetype="全部" class="select">全部</span>';
                        for(let item of data){
                                html+=`<span data-stationname="${item.stationname}" data-buildingname="${item.buildingname}" data-machinetype="${item.machinetype}">
                                        ${item.machinetype}
                                        </span>`;
                        }
                        
                        $("#status_sbTypeDD").html(html);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 监视设备状态
function machineStatus(){
        var html=`<span data-online="全部" class="select">全部</span>
        <span data-online="1">在线</span>
        <span data-online="0">失联</span>
        <span data-online="2">拆除</span>`;

        $("#status_machineDD").html(html);
};


//历史图像页面, 所有设备
function shebeiAll(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/i_getAlldevice',
                dataType:'JSON',
                data:{
                        userid:userid
                },
                success:function(data){
                        var html='<span data-deviceid="全部" class="select">全部</span>';
                        for(let item of data){
                                html+=`<span data-deviceid="${item.deviceid}">
                                        ${item.devicename}
                                        </span>`;
                        }
                        
                        $("#sheibeiDD").html(html);

                        var html1='';
                        for(var i=0;i<data.length;i++){
                                html1+='<li class="li-item"><div class="item_left fl"><span>'
                                        +data[i].devicename+'</span></div><div class="item_right fr"><a class="shebei_event ac_edit edit7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '"data-event="edit"><i class="layui-icon layui-icon-edit"></i></a><a class="shebei_event ac_del del7 layui-btn layui-btn-xs" data-deviceid="'
                                        +data[i].deviceid+
                                        '" data-event="del"><i class="layui-icon layui-icon-delete"></i></a></div></li><div class="clear"></div>';
                                
                                
                                
                        }
                        $("#shebei_ul").html(html1);
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 添加修改红外设备推流
function device_tl(){
        $.ajax({
                type:'get',
                url:baseUrl+'ConfigTool/ConfigService.asmx/getMediaAddressInfo',
                dataType:'JSON',
                data:{
                },
                success:function(data){
                        var optionStr ='<option lable="">请选择</option>';
                        for(var i=0;i<data.length;i++){
                                optionStr+="<option class='selectYouzhi' value='"+data[i].Value+"'>"+data[i].Name+"</option>";
                        }
                        
                        $("#device_addjkq14").html(optionStr);//添加
                        $("#device_editjkq14").html(optionStr);//修改
                },
                error:function(err){
                        console.log(err)
                }

        });
};

//设备管理页面：添加、修改   预设点类型下拉框
function machine_ysdType(machineid){
        $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/getUnaddYsd',
                dataType:'JSON',
                data:{
                        machineid:machineid
                },
                success:function(data){
                        var optionStr ='<option lable="">请选择</option>';
                        for(var i=0;i<data.length;i++){
                                optionStr+="<option class='selectYouzhi' ";
                                if(data[i].ysdname==g){
                                        optionStr+="selected";
                                }
                                optionStr+=" value='"+data[i]+"'>"+data[i]+"</option>";
                        }
                        
                        $("#device_addysd7").html(optionStr);//添加
                        $("#device_editysd7").html(optionStr);//修改
               
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 添加app管理
// 参数 versionNo,versionNote,downloadUrl,versionTarget
function add_app(formData){
        $.ajax({
                type:'post',
                url:baseUrl+'AppVersionService/AppversionService.asmx/Addapp',
                dataType:'JSON',
                data:formData,
                async: false,
                processData : false, // 使数据不做处理
                contentType : false, // 不要设置Content-Type请求头
                success:function(data){
                        //刷新
                        location.reload("#test_app");
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 告警列表单个
// 参数 id,fuhe,human,time
function edit_oneAlarem(id,fuhe,human,time){
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/App_MensureAlarm',
                dataType:'JSON',
                data:{
                        id:id,
                        fuhe:fuhe,
                        human:human,
                        time:time
                },
                success:function(data){
                        layui.use(['table','layer'], function(){
                                var layer = layui.layer;
                                var table = layui.table;
                                layer.msg(data[0].msg,{
                                        offset: '15px'
                                        ,time: 500
                                });
                                table.reload('test');
                        });
                        
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 告警列表批量
// 参数 id,fuhe,human,time  sationid,
function edit_MoreAlarem(id,human,time){
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/MenureAlarm',
                dataType:'JSON',
                data:{
                        userid:userid,
                        sationid:'',
                        idlist:id,
                        human:human,
                        time:time
                },
                success:function(data){
                        layui.use(['table','layer'], function(){
                                var layer = layui.layer;
                                var table = layui.table;
                                layer.msg(data[0].msg,{
                                        offset: '15px'
                                        ,time: 500
                                });
                                table.reload('test');
                        });
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 批量设备更新
function updataDevice(targetList,programName,programSize){
        $.ajax({
                type:'get',
                url:baseUrl+'ConfigTool/ConfigService.asmx/update_program_multi',
                dataType:'JSON',
                data:{
                        targetList:JSON.stringify(targetList),
                        programName:programName,
                        programSize:programSize
                },
                success:function(data){
                        layui.use(['table','layer'], function(){
                                var layer = layui.layer;
                                var table = layui.table;
                                layer.msg(data[0].msg,{
                                        offset: '15px'
                                        ,time: 500
                                });
                                table.reload('test_stu');
                        });
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 批量更新ftp
function updataFtp(targetList,Cloud_addr,ftp_addr){
        $.ajax({
                type:'get',
                url:baseUrl+'ConfigTool/ConfigService.asmx/update_CloudAddr_multi',
                dataType:'JSON',
                data:{
                        targetList:JSON.stringify(targetList),
                        Cloud_addr:Cloud_addr,
                        ftp_addr:ftp_addr
                },
                success:function(data){
                        layui.use(['table','layer'], function(){
                                var layer = layui.layer;
                                var table = layui.table;
                                layer.msg(data[0].msg,{
                                        offset: '15px'
                                        ,time: 500
                                });
                                table.reload('test_stu');
                        });
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 告警阈值修改
function edit_SetTemAlarem(id,tem,human){
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/App_ModifyOffsetValue',
                dataType:'JSON',
                data:{
                        deviceid:id,
                        offsetvalue:tem,
                        offsethuman:human,
                },
                success:function(data){
                        layui.use(['table','layer'], function(){
                                var layer = layui.layer;
                                var table = layui.table;
                                layer.msg(data[0].msg,{
                                        offset: '15px'
                                        ,time: 500
                                });
                                $(".temSet_tanchu").hide(); 
                                table.reload('test');
                        });
                },
                error:function(err){
                        console.log(err)
                }

        });
};

// 告警列表  温度对比 柱形图  变电站设备类型统计
function  alarmInfoTopModule1(XdeviceType,count){
  
        var dom = document.getElementById("alarmInfoTopModule1");
        if(!dom){
          return;
        }else{
            var myChart=echarts.init(dom);
            option = {
                tooltip: {
                  trigger: 'axis',
                  textStyle:{
                    color: '#fff'//字体颜色
                  },
                //   formatter(params){
                //     const item = params[0];
                //     return `<span style="color:#00ffd2;">温度：${item.value}℃</span><br/>
                //             <span style="color:#00ffd2;">${item.name}</span>`;
                //   }
                },
                grid: {
                  top:'22%',
                  right: '10%',
                  bottom:'25%'
                },
                
                xAxis: [
                  {
                    type: 'category',
                    interval:0,
                    axisTick: {
                      show:false
                    },
                    axisLine: {
                      show: true,
                      lineStyle: {
                        color: 'rgba(255,255,255,.4)'
                      }
                    },
                    axisLabel: {
                        rotate:20,
                        textStyle: {
                            //这个地方颜色是支持回调函数的这种的，如果是一种颜色则可以写成： color :'#1089E7'  
                            color : "#fff",
                            fontSize:10
                        }
                    },
                    data: XdeviceType
                  }
                ],
                yAxis: [//多y轴时，用数组加对象的方式来实现
                  {       
                    show:false,          
                    type: 'value',
                    name: '',
                    interval:1,
                    axisTick:{       //y轴刻度线
                      show:false
                    },
                    axisLine: {
                      show:false,
                    },
                    
                  }
                ],
                series: [
                  
                  {
                    name:'',
                    type:'bar',
                    barWidth: 10,
                    smooth:true,
                    symbol: 'circle',     //设定为实心点
                    symbolSize: 30,   //设定实心点的大小
                    data:count,
                    lineStyle:{
                      normal:{
                        width:10
                      }
                    },
                    label: {
                            show: true, //开启显示
                            position: 'top', //在上方显示
                            textStyle: { //数值样式
                                  color : "#fff",
                                  fontSize: 10,
                            },
                            
                    },
                    itemStyle: {
                        color : "#00FFD2",
                    }        
                  }
                ]
            };
            myChart.setOption(option);
      
        }    
      
};
function setAllItemR1(userid){
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getmachineNumbers',
                dataType:'JSON',
                data:{
                        userid:userid
                },
                success:function(data){
                        $("#itemR1").html(data[0].allcount);
                        var repair1=data[0].onlinecount;
                        var repair2=data[0].offlinecount;
                        deviceStatusTopModule1(repair1,repair2);
                },
                error:function(err){
                        console.log(err)
                }

        });
};
// 系统设置  温度对比 柱形图  变电站设备类型统计
function  systemSetModule3(XdeviceType,count){
        var dom = document.getElementById("systemSetModule3");
        if(!dom){
          return;
        }else{
            var myChart=echarts.init(dom);
            option = {
                tooltip: {
                  trigger: 'axis',
                  textStyle:{
                    color: '#fff'//字体颜色
                  },
                //   formatter(params){
                //     const item = params[0];
                //     return `<span style="color:#00ffd2;">数量：${item.value}℃</span><br/>
                //             <span style="color:#00ffd2;">${item.name}</span>`;
                //   }
                },
                grid: {
                  top:'22%',
                  right: '5%',
                  bottom:'25%'
                },
                
                xAxis: [
                  {
                    type: 'category',
                    axisTick: {
                      show:false
                    },
                    axisLine: {
                      show: true,
                      lineStyle: {
                        color: 'rgba(255,255,255,.4)'
                      }
                    },
                    axisLabel: {
                        interval:0,
                        rotate:30,
                        textStyle: {
                            //这个地方颜色是支持回调函数的这种的，如果是一种颜色则可以写成： color :'#1089E7'  
                            color : "#fff",
                            fontSize:10
                        }
                    },
                    data: XdeviceType
                  }
                ],
                yAxis: [//多y轴时，用数组加对象的方式来实现
                  {       
                    show:false,          
                    type: 'value',
                    name: '',
                    interval:1,
                    axisTick:{       //y轴刻度线
                      show:false
                    },
                    axisLine: {
                      show:false,
                    },
                    
                  }
                ],
                series: [
                  
                  {
                    name:'',
                    type:'bar',
                    barWidth: 10,
                    smooth:true,
                    symbol: 'circle',     //设定为实心点
                    symbolSize: 30,   //设定实心点的大小
                    data:count,
                    lineStyle:{
                      normal:{
                        width:10
                      }
                    },
                    label: {
                            show: true, //开启显示
                            position: 'top', //在上方显示
                            textStyle: { //数值样式
                                  color : "#fff",
                                  fontSize: 10,
                            },
                            
                    },
                    itemStyle: {
                        color : "#00FFD2",
                    }        
                  }
                ]
            };
            myChart.setOption(option);
      
        }    
      
};
// 饼图 设备状态 在线失联统计 
function deviceStatusTopModule1(repair1,repair2){
        var dom = document.getElementById("deviceStatusModule1");
        var total=parseInt(repair1)+parseInt(repair2);
        if(!dom){
            return;
        }else{
            var myChart=echarts.init(dom);
        
            option = {
                title: {
                    text:total,
                    subtext:'总计',
                    x: '45%',
                    y: 'center',
                    top:"25%",
                    itemGap:0,
                    textStyle: {
                        color: '#fff',
                        fontWeight:"normal",
                        fontSize:14
                    },
                    subtextStyle:{
                        color: '#fff',
                        fontSize:10
                    }
                },
                tooltip: {
                    trigger: 'item',
                },
                legend: {
                    orient: 'vertical',
                    left: 'right',
                    top: 'top',
                    data: ["在线","失联"],
                    textStyle: {
                        color: '#f0f0f0',
                        fontSize: '12'
                    },
                    itemWidth: 10,
                    itemHeight: 6,
                    itemGap: 2,
                },
                color: ['#00FFD2','#FF5E5E'],
                series: [{
                    name: '',
                    type: 'pie',
                    radius: ['45%', '55%'],
                    center: ['50%', '45%'],
                    label: {
                      show: false
                      // textStyle: {
                      //     color: "#ffffff",
                      //     fontSize: 14,
                      // }
                    },
                    labelLine: {
                      show: false
                    },
                    data: [
                        {
                            name: "在线",
                            value: repair1
                        },
                        {
                            name: "失联",
                            value: repair2
                        }
                    ]
                }]
            };
            if (option && typeof option === "object") {
                myChart.setOption(option, true);
            }
            
        }
};


