//getPosition()函数引起，已解决!!!
//const OFFSET_BUG_X=0;//-5; 
//const OFFSET_BUG_Y=0;//-85;

/**
 * 最小点定义
 * @param x　左上为原点的横坐标
 * @param y　左上为原点的纵坐标
 * @constructor
 */
Spot=function(x,y){
   const DEFAULT_R=5; //默认最小点半径
   const DEFAULT_COLOR="#000";
   //const DEFAULT_TEXT_COLOR="#000";
   const DEFAULT_TEXT_OFFSET_X=5; //默认文本偏移量横坐标 x
   const DEFAULT_TEXT_OFFSET_Y=12; //默认文本偏移量纵坐标 y
   const DEFAULT_TEXT_STYLE="8pt Georgia";
   this.x=x;
   this.y=y;
   this.r=null;
   this.color=null;
   this.text=null;
   this.textStyle=null;
   this.setX=function(x){
      this.x=x;
   };
   this.setY=function(y){
      this.y=y;
   };
   this.setColor=function(color){
      this.color=color;
   };
   this.setText=function(text){
      this.text=text;
   };
   this.drawSelf=function(context){
	  context.fillStyle=(this.color)? this.color:DEFAULT_COLOR;
	  context.beginPath();
	  context.arc(this.x,this.y,(this.r)? this.r:DEFAULT_R,Math.PI*2,0,true);
	  context.closePath();
	  context.fill();
	  context.font=(this.textStyle)? this.textStyle:DEFAULT_TEXT_STYLE;
	  //context.fillStyle=DEFAULT_TEXT_COLOR;
	  //是否显示坐标
	  // context.fillText((this.text)? this.text:this.x+":"+this.y,this.x-DEFAULT_TEXT_OFFSET_X,this.y-DEFAULT_TEXT_OFFSET_Y);
   };
};
/**
 * 基本区域定义
 * @param regionType　区域类型:spot,line,shape
 * @constructor
 */
Region=function(regionType){
    this.regionWidth=0;
    this.regionHeight=0;
    this.regionType=regionType; //区域类型
    this.sColor="#000"; //默认点集可选颜色
    this.lColor="#000"; //默认线集可选颜色
    this.spotList=new Array(); //区域点列表
    this.setRegionWidth=function (regionWidth) {
        this.regionWidth=regionWidth;
    };
    this.setRegionHeight=function (regionHeight) {
        this.regionHeight=regionHeight;
    };
    this.setRegionType=function (regionType) {
        this.regionType=regionType;
    };
    this.setSColor=function (sColor) {
        this.sColor=sColor;
    };
    this.setLColor=function (lColor) {
        this.lColor=lColor;
    };
    this.pushSpot=function (spot) {
        if(spot instanceof Spot){
            this.spotList.push(spot);
        }else{
            throw "Region.pushSpot:it isn't a Spot Object.";
        }
    };
    this.popSpot=function () {
        return this.spotList.pop();
    };
    this.doEmpty=function (){
        this.spotList.splice(0,this.spotList.length);  //清空区域点列表
    };
};
/**
 *管理画布所有状态
 * @constructor
 */
CanvasHelper=function(){
   const TAG="CanvasHelper";
   const typeList={
        SPOT:0x00,
        LINE:0x01,
        SHAPE:0x02
   };
   const modeList={
       VIEW:0x00,
       EDIT:0x01
   };

   const regionList=new Array();
   const trashSpotList=new Array(); //回撤spot使用
   const trashRegionList=new Array(); //回撤region使用

   const DEFAULT_STROKE_STYLE="#000";
   const DEFAULT_FILL_STYLE="#FFF";
   const DEFAULT_LINE_WIDTH=3;

   this.canvasContainer=null;
   this.bgCanvas=null;
   this.canvas=null;
   this.context=null;
   this.oPos=null;
   this.label=null;

   this.bgImage=new Image(); //背景图
   this.defaultImageUrl=null;

   this.typeList=typeList;
   this.modeList=modeList;
   this.regionList=regionList;
   this.trashSpotList=trashSpotList;
   this.trashRegionList=trashRegionList;

   this.firstSpot=null;
   this.lastSpot=null;
   this.currentSpotCount=0;
   this.currentRegion=null;

   this.init=initEveryThing;
   this.drawSpot=drawSpot;
   this.linkSpot=strokeLink;
   // this.linkShape=fillLink;
   this.createCurrentRegion=createCurrentRegion;
   this.saveCurrentRegion=saveCurrentRegion;
   this.updateCurrentRegion=updateCurrentRegion;
   this.undoCurrentRegion=undoCurrentRegion;
   this.redoCurrentRegion=redoCurrentRegion;
   this.updateCanvasRegion=updateCanvasRegion;
   this.freshCanvasRegion=freshCanvasRegion;
   this.deleteRegion=deleteRegion;
   this.recoverRegion=recoverRegion;
   this.clearAllRegion=clearAllRegion;
   this.getRegionJsonData=getRegionData;
   this.getRegionDataFix=getRegionDataFix;
   this.log=function (msg) {
        log(TAG,msg);
   };
   this.setControlMode=function (mode) {
       switch (mode) {
           case this.modeList.VIEW:
           case this.modeList.EDIT:
              this.controlMode=mode;
              break;
           default:throw "setControlMode -> unknown mode:"+mode;
       }
   };
   this.setFirstSpot=function (spot) {
        this.firstSpot=spot;
   };
   this.setLastSpot=function (spot) {
        this.lastSpot=spot;
   };
   this.setCurrentSpotCount=function (count) {
        this.currentSpotCount=count;
   };
   this.setCurrentRegion=function (region) {
        this.currentRegion=region;
   };
   this.setCurrentRegionSaveStatus=function(status){
        this.currentRegionSaveStatus=status;
   };
   this.updateImageCanvas=function (imageUrl) {
        baseUpdateImageCanvas(this,imageUrl,this.defaultImageUrl);
   };
   this.drawTextOnBgCanvas=function(text){
        var canvas=this.bgCanvas;
        var context=canvas.getContext("2d");
        context.font="16px bold 黑体";
        context.textAlign="center";
        context.textBaseline="middle";
        context.fillStyle="#F00";
        context.clearRect(0,0,canvas.width,canvas.height); //清空画布
        context.fillText(text,canvas.width/2,canvas.height/2);
   };
   this.drawImageOnBgCanvas=function(image){
        var canvas=this.bgCanvas;
        var context=canvas.getContext("2d");
        context.clearRect(0,0,canvas.width,canvas.height);
        context.drawImage(image,0,0,canvas.width,canvas.height);
   };

   function initEveryThing(canvasContainerId,bgCanvasId,canvasId,saveRegionId,undoId,redoId,recoverRegionId,labelId,
                           freshRegionId,emptyRegionId,submitRegionId,deleteRegionId,defaultImageUrl){
        var canvasHelper=this;
        canvasHelper.canvasContainer=document.querySelector(canvasContainerId);
        canvasHelper.bgCanvas=document.querySelector(bgCanvasId);
        canvasHelper.canvas=document.querySelector(canvasId);
	    canvasHelper.label=document.querySelector(labelId);
        canvasHelper.context=canvasHelper.canvas.getContext("2d");

	    window.onresize=adjustImageCanvas(canvasHelper);
	    
        $(canvasHelper.canvasContainer).resize(function(){
        	 adjustImageCanvas(canvasHelper);
        });

//        $(document).scroll(function(){
//        	 adjustImageCanvas(canvasHelper);
//        });
        
        canvasHelper.oPos=getPosition(canvasHelper);
        canvasHelper.controlMode=modeList.VIEW;
        canvasHelper.setCurrentRegionSaveStatus(true);
	    canvasHelper.label.innerHTML="X:0 Y:0";

        document.querySelector(saveRegionId).disabled=true;
        document.querySelector(undoId).disabled=true;
        document.querySelector(redoId).disabled=true;
        document.querySelector(recoverRegionId).disabled=true;
        document.querySelector(freshRegionId).disabled=true;
        document.querySelector(emptyRegionId).disabled=true;
        document.querySelector(submitRegionId).disabled=true;
        document.querySelector(deleteRegionId).disabled=true;

        canvasHelper.bgImage.onload=function(){
              if(canvasHelper.bgImage.src){
                  canvasHelper.drawImageOnBgCanvas(canvasHelper.bgImage);
              }else{
                  canvasHelper.drawTextOnBgCanvas("图片异常,加载失败！");
              }
        };

       canvasHelper.defaultImageUrl=defaultImageUrl;
       canvasHelper.updateImageCanvas(defaultImageUrl); //初始化默认背景
   }

    function baseUpdateImageCanvas(canvasHelper,imageUrl,defaultImageUrl){
       if(canvasHelper){
           canvasHelper.drawTextOnBgCanvas("正在玩命加载中,请稍后...");
           log(TAG,"updateImageCanvas -> imageUrl:"+imageUrl);
           log(TAG,"updateImageCanvas -> defaultImageUrl:"+defaultImageUrl);
           if(canvasHelper.bgImage){
               canvasHelper.bgImage.src=(imageUrl)?imageUrl:defaultImageUrl;
           }else{
               throw "canvasHelper.bgImage is null!";
           }
       }
    }

    /**
     * 调整图片画布尺寸
     * @param canvasHelper
     */
   function adjustImageCanvas(canvasHelper){
      canvasHelper.bgCanvas.width=canvasHelper.canvasContainer.offsetWidth-2;
      canvasHelper.bgCanvas.height=canvasHelper.canvasContainer.offsetHeight-2;
      log(TAG,"adjustImageCanvas -> bgCanvas.width:"+canvasHelper.bgCanvas.width+
          " bgCanvas.height:"+canvasHelper.bgCanvas.height);
      canvasHelper.updateImageCanvas(canvasHelper.bgImage.src); //render image again
      adapt(canvasHelper);
   }

   function adapt(canvasHelper){
       canvasHelper.canvas.width=canvasHelper.bgCanvas.width;
       canvasHelper.canvas.height=canvasHelper.bgCanvas.height;
       log(TAG,"adapt -> canvasHelper.context.canvas.width:"+ canvasHelper.context.canvas.width);
       log(TAG,"adapt -> canvasHelper.context.canvas.height:"+ canvasHelper.context.canvas.height);
       canvasHelper.freshCanvasRegion();
   }

   function drawSpot(region,spot){
       var canvasHelper=this;
       if(region&&spot){
           var context=canvasHelper.context;
           var cw=canvasHelper.canvas.width;
           var ch=canvasHelper.canvas.height;
           
           var fx=(region.regionWidth>0)? cw/region.regionWidth:1; //横向偏移率
           var fy=(region.regionHeight>0)? ch/region.regionHeight:1; //纵向偏移率
           log(TAG,"drawSpot -> fx:"+fx+" fy:"+fy);
           
           //var tspot=Object.assign({},spot);
           
           var rx=spot.x*fx;
           var ry=spot.y*fy;
           
           //兼容IE
           var tspot=new Spot(rx,ry);
           tspot.setColor(spot.color);
           tspot.setText("x:"+Math.round(rx)+" y:"+Math.round(ry));
           
           log(TAG,"spot -> x:"+spot.x+" y:"+spot.y);
           
           log(TAG,"tspot -> x:"+tspot.x+" y:"+tspot.y);
      
           tspot.drawSelf(context);
       }
   }

   function strokeLink(region,spotA,spotB) {
       baseStrokeLink(this,region,spotA,spotB,DEFAULT_STROKE_STYLE,DEFAULT_LINE_WIDTH);
   }

   function fillLink(spotA,spotB,spotC) {
        basefillLink(this.context,spotA,spotB,spotC,DEFAULT_FILL_STYLE);
   }

    /**
     * 连接两个最小点
     * @param canvasHelper 画布上下文
     * @param region 区域
     * @param spotA　起始点
     * @param spotB　结束点
     * @param strokeStyle　连线样式
     * @param lineWidth　连线宽度
     */
    function baseStrokeLink(canvasHelper,region,spotA,spotB,strokeStyle,lineWidth){
        if(canvasHelper&&region&&spotA&&spotB){
            var ctx=canvasHelper.context;
            var fx=(region.regionWidth>0)? ctx.canvas.width/region.regionWidth:1;
            var fy=(region.regionHeight>0)? ctx.canvas.height/region.regionHeight:1;
            ctx.strokeStyle=strokeStyle;
            ctx.lineWidth=lineWidth;
            ctx.beginPath();
            ctx.moveTo(spotA.x*fx,spotA.y*fy);
            ctx.lineTo(spotB.x*fx,spotB.y*fy);
            ctx.stroke();
            ctx.closePath();
            //spotA.drawSelf(ctx);
            canvasHelper.drawSpot(region,spotA); //重绘起始点,掩盖连线痕迹
        }
    }

    /**
     * 填充三个最小点组成的区域
     * @param context　画布上下文
     * @param spotA　端点A
     * @param spotB　端点B
     * @param spotC  端点C
     * @param fillStyle 填充样式
     */
   function basefillLink(context,spotA,spotB,spotC,fillStyle){
       if(spotA&&spotB&&spotC){
          var ctx=context;
	      ctx.fillStyle=fillStyle;
          ctx.beginPath();
          ctx.moveTo(spotA.x,spotA.y);
	      ctx.lineTo(spotB.x,spotB.y);
	      ctx.lineTo(spotC.x,spotC.y);
          ctx.closePath();	 
	      ctx.fill();
       } 
   }

    /**
     * 根据鼠标位置自动锁定画布坐标
     * @param dom　元素
     * @returns {{x: number, y: number}} 二维坐标值
     */
    function getPosition(canvasHelper){    
    	var oPos = { x : 0, y : 0 };
    	var dom=canvasHelper.canvas;
	    var label=canvasHelper.label;
        bindEvent(dom,"mousemove", function( ev ){
            var oEvent = ev || event, x, y;
            if ( oEvent.pageX || oEvent.pageY ){
                x = oEvent.pageX - document.body.scrollLeft;
                y = oEvent.pageY - document.body.scrollTop;
                log(TAG,"oEvent -> pageX:"+oEvent.pageX+" pageY:"+oEvent.pageY);
                log(TAG,"pageX -> body.scrollLeft:"+document.body.scrollLeft);
                log(TAG,"pageY -> body.scrollTop:"+document.body.scrollTop);
            }else {
                x = oEvent.clientX;
                y = oEvent.clientY;
                log(TAG,"oEvent -> clientX:"+oEvent.clientX+" clientY:"+oEvent.clientY);
                log(TAG,"clientX -> body.scrollLeft:"+document.body.scrollLeft);
                log(TAG,"clientY -> body.scrollTop:"+document.body.scrollTop);
            }

            var rect=dom.getBoundingClientRect();
            //log(TAG,"getPosition -> x:"+x+" y:"+y);
            //log(TAG,"getPosition -> left:"+rect.left+
            //		              " top:"+rect.top);
            x -= rect.left;
            y -= rect.top;
            oPos.x = x;
            oPos.y = y;
	        label.innerHTML="X:"+oPos.x+" Y:"+oPos.y;
        } );
	    bindEvent(dom,"mouseout",function(ev){
            label.innerHTML="X:0 Y:0";
	    });
        return oPos;
   }

    /**
     * 绑定事件,兼容常规浏览器
     * @param obj　元素
     * @param event　事件
     * @param fn　动作
     */
   function bindEvent(obj,event,fn) {
        if (obj.attachEvent) { //ie
            obj.attachEvent('on' + event, function () {
                fn.call(obj);
            });
        } else {
            //chrome&ff
            obj.addEventListener(event,fn,false);
        }
   }

    /**
     * 将当前绘制区域保存到区域列表
     * @returns {boolean}　保存状态
     */
   function saveCurrentRegion(){
       var canvasHelper=this;
       var region=canvasHelper.currentRegion;
       if(region){
           if(region.regionType==canvasHelper.typeList.SHAPE){
               baseStrokeLink(canvasHelper,region,canvasHelper.lastSpot,canvasHelper.firstSpot,region.lColor,DEFAULT_LINE_WIDTH);
               //canvasHelper.firstSpot.drawSelf(canvasHelper.context);
               canvasHelper.drawSpot(region,canvasHelper.firstSpot);//掩盖连接痕迹
           }
           canvasHelper.regionList.push(region);
           canvasHelper.setCurrentRegion(null);
           canvasHelper.setCurrentRegionSaveStatus(true);
           canvasHelper.trashSpotList.length=0;
           log(TAG,"saveCurrentRegion -> currentRegion is ok!");
           return true;
       }else{
           canvasHelper.setCurrentRegionSaveStatus(true);
           log(TAG,"saveCurrentRegion -> currentRegion is empty");
           return false;
       }
   }

    /**
     * 创建一个新的绘制区域
     * @param regionType　区域类型
     * @param spotColor　点集颜色
     * @param lineColor　线集颜色
     * @returns {boolean} 创建状态
     */
   function createCurrentRegion(regionType,spotColor,lineColor){
       var canvasHelper=this;
       var region=obtainRegion(canvasHelper,regionType);
       if(region){
           region.setRegionWidth(canvasHelper.context.canvas.width); //设定区域宽度为画布宽度
           region.setRegionHeight(canvasHelper.context.canvas.height); //设定区域高度为画布高度
           region.setSColor(spotColor);
           region.setLColor(lineColor);
           canvasHelper.setFirstSpot(null);
           canvasHelper.setLastSpot(null);
           canvasHelper.setCurrentSpotCount(0);
           canvasHelper.setCurrentRegion(region);
           return true;
       }else{
           return false;
       }
   }

   function obtainRegion(canvasHelper,regionType){
       log(TAG,"obtainRegion:regionType:"+regionType);
       var region=null;
       switch (regionType) {
           case canvasHelper.typeList.SPOT:
           case canvasHelper.typeList.LINE:
           case canvasHelper.typeList.SHAPE:
               region=new Region(regionType);
               break;
           default:throw "obtainRegion:unknown type:"+regionType;
       }
       return region;
   }

   function updateCurrentRegion(){
       var canvasHelper=this;
       var sx=canvasHelper.oPos.x;
       var sy=canvasHelper.oPos.y;
       log(TAG,"updateCurrentRegion -> sx:"+sx+" sy:"+sy);
       baseUpdateCurrentRegion(canvasHelper,new Spot(sx,sy));
   }

   function baseUpdateCurrentRegion(canvasHelper,tmpSpot){
       var region=canvasHelper.currentRegion;
       var type=region.regionType;
       var count=canvasHelper.currentSpotCount;
       if(region){
           if(!tmpSpot) {
               log(TAG,"updateCurrentRegion -> tmpSpot is empty.");
               return;
           }
           tmpSpot.setColor(region.sColor);
           switch (type) {
               case canvasHelper.typeList.SPOT:
                   canvasHelper.drawSpot(region,tmpSpot);
                   break;
               case canvasHelper.typeList.LINE:
               case canvasHelper.typeList.SHAPE:
                   if(count==1){
                         baseStrokeLink(canvasHelper,region,canvasHelper.lastSpot,tmpSpot,region.lColor,DEFAULT_LINE_WIDTH);
                         canvasHelper.setFirstSpot(canvasHelper.lastSpot);
                     }
                     if(count>1){
                         baseStrokeLink(canvasHelper,region,canvasHelper.lastSpot,tmpSpot,region.lColor,DEFAULT_LINE_WIDTH);
                     }
                     canvasHelper.drawSpot(region,tmpSpot);
                     canvasHelper.setLastSpot(tmpSpot);
                     break;
             }
             canvasHelper.setCurrentRegionSaveStatus(false);
             canvasHelper.currentRegion.pushSpot(tmpSpot);
             canvasHelper.setCurrentSpotCount(count+1);
         }else{
             canvasHelper.setCurrentRegionSaveStatus(true);
             log(TAG,"updateCurrentRegion -> currentRegion is empty.");
         }
   }

    function undoCurrentRegion(){
       var canvasHelper=this;
       var count=canvasHelper.currentSpotCount;
       if(count>0){
           canvasHelper.trashSpotList.push(canvasHelper.currentRegion.popSpot());
           var region=canvasHelper.currentRegion;
           canvasHelper.regionList.push(region);
           baseRenderRegionList(canvasHelper,canvasHelper.regionList.length-1);
           canvasHelper.regionList.pop();
           if(count<=1){
               canvasHelper.setCurrentSpotCount(0);
               canvasHelper.setFirstSpot(null);
               canvasHelper.setLastSpot(null);
               canvasHelper.setCurrentRegionSaveStatus(true);
               return false;
           }else{
               canvasHelper.setCurrentSpotCount(count-1);
               canvasHelper.setLastSpot(region[region.length-1]);
               canvasHelper.setCurrentRegionSaveStatus(false);
               return true;
           }
       }else{
           return false;
       }
    }

    function redoCurrentRegion(){
         var canvasHelper=this;
         if(canvasHelper.trashSpotList.length>0){
             baseUpdateCurrentRegion(canvasHelper,canvasHelper.trashSpotList.pop());
         }
         return !(canvasHelper.trashSpotList.length<=0);
    }

    function deleteRegion() {
        var canvasHelper=this;
        return stashRegionBetweenList(canvasHelper,canvasHelper.trashRegionList,canvasHelper.regionList);
    }

    function recoverRegion() {
        var canvasHelper=this;
        return stashRegionBetweenList(canvasHelper,canvasHelper.regionList,canvasHelper.trashRegionList);
    }

    function clearAllRegion(){
       var canvasHelper=this;
       canvasHelper.regionList.length=0;
       canvasHelper.trashRegionList.length=0;
       canvasHelper.freshCanvasRegion();
    }

    function stashRegionBetweenList(canvasHelper,listA,listB){
        if(listB.length>0) {
            listA.push(listB.pop());
        }
        canvasHelper.freshCanvasRegion();
        return !(listB.length<=0);
    }

    /**
     * 更新画布,处理大量数据时该过程可能有延迟,耗时操作
     * @param data　区域数据
     */
    function updateCanvasRegion(data) {
        parseRegionData(this,data);
        renderRegionList(this);
    }

    function freshCanvasRegion() {
        var canvasHelper=this;
        renderRegionList(canvasHelper);
        canvasHelper.setCurrentSpotCount(0);
        canvasHelper.setFirstSpot(null);
        canvasHelper.setLastSpot(null);
        canvasHelper.setCurrentRegion(null);
        canvasHelper.setCurrentRegionSaveStatus(true);
        canvasHelper.trashSpotList.length=0;
    }

    function renderRegionList(canvasHelper){
        baseRenderRegionList(canvasHelper,canvasHelper.regionList.length);
    }

    /**
     * 渲染区域
     */
    function baseRenderRegionList(canvasHelper,regionRealLength){
       canvasHelper.context.clearRect(0,0,canvasHelper.canvas.width,canvasHelper.canvas.height); //清空画布
       for(var i=0;i<canvasHelper.regionList.length;i++){
           var region=canvasHelper.regionList[i];
           var isLink=false;
           var isSeal=false;
           switch (region.regionType) {
               case canvasHelper.typeList.SPOT:
                   break;
               case canvasHelper.typeList.LINE:
                   isLink=true;
                   break;
               case canvasHelper.typeList.SHAPE:
                   isLink=true;
                   isSeal=true;
                   break;
           }
           var rspot=null;
           var fspot=null;
           var tspot=null;
           var spotList=region.spotList;
           for(var j=0;j<spotList.length;j++){
               tspot=spotList[j];
               if(isLink&&rspot){
                   baseStrokeLink(canvasHelper,region,rspot,tspot,region.lColor,DEFAULT_LINE_WIDTH);
               }
               if(j==0){
                   fspot=tspot;
               }
               //tspot.drawSelf(canvasHelper.context);
               canvasHelper.drawSpot(region,tspot);
               rspot=tspot;
           }
           if(i<regionRealLength){
               if(isSeal&&spotList.length>=3){
                   baseStrokeLink(canvasHelper,region,tspot,fspot,region.lColor,DEFAULT_LINE_WIDTH);
                   //fspot.drawSelf(canvasHelper.context);
                   canvasHelper.drawSpot(region,fspot);
               }
           }
       }
    }

    // TODO 生成区域数据String格式,可以放在后台实现
    function getRegionDataFix(type){
        var pointType=type;
        var canvasHelper=this;
        var dx=640;
        var dy=480;
        var data="";
        var count=0;
        for(var i=0;i<canvasHelper.regionList.length;i++){
            var region=canvasHelper.regionList[i];
            var fx=(region.regionWidth>0)? dx/region.regionWidth:1; //横向偏移率
            var fy=(region.regionHeight>0)? dy/region.regionHeight:1; //纵向偏移率
            log(TAG,"getRegionDataFix -> fx:"+fx+" fy:"+fy);
            var spotList=region.spotList;
            var rx=0;
            var ry=0;
            switch (region.regionType){
                 case canvasHelper.typeList.SPOT:
                     for(var j=0;j<spotList.length;j++){
                         rx=Math.round(spotList[j].x*fx);
                         ry=Math.round(spotList[j].y*fy);
                         rx=(rx>dx)?dx:rx;
                         rx=(rx<0)?0:rx;
                         ry=(ry>dy)?dy:ry;
                         ry=(ry<0)?0:ry;
                         log(TAG,"SPOT rx:"+rx+" ry:"+ry);
                         data+="d,2/"+rx+","+ry+"/2,0/:";
                         count++;
                     }
                     break;
                 case canvasHelper.typeList.LINE:
                 case canvasHelper.typeList.SHAPE:
                     data+=(region.regionType===canvasHelper.typeList.LINE)? "l,":"p,";
                     data+=spotList.length+"/";
                     for(var q=0;q<spotList.length;q++){
                         rx=Math.round(spotList[q].x*fx);
                         ry=Math.round(spotList[q].y*fy);
                         rx=(rx>dx)?dx:rx;
                         rx=(rx<0)?0:rx;
                         ry=(ry>dy)?dy:ry;
                         ry=(ry<0)?0:ry;
                         log(TAG,"LINE/SHAPE rx:"+rx+" ry:"+ry);
                         data+=rx+","+ry+"/";
                     }
                     data+=":";
                     count++;
                     break;
            }

        }
        data=dx+","+dy+":"+pointType+","+count+":"+data;
        log(TAG,"getRegionDataFix -> data:"+data);
        return data;
    }

    // TODO 生成区域数据JSON格式
    function getRegionData(){
        var canvasHelper=this;
        var data=[];
        for(var i=0;i<canvasHelper.regionList.length;i++){
            var region=canvasHelper.regionList[i];
            var obj={
                type:region.regionType, //字段type
                width:region.regionWidth, //字段width
                height:region.regionHeight, //字段height
                sColor:region.sColor, //字段sColor
                lColor:region.lColor, //字段lColor
                value:[] //字段value
            };
            for(var j=0;j<region.spotList.length;j++){
                var spot=region.spotList[j];
                obj.value.push({
                       x:spot.x, //字段x
                       y:spot.y  //字段y
                });
            }
            data.push(obj);
        }
        return JSON.stringify(data);
    }

    // TODO 解析区域数据
   function parseRegionData(canvasHelper,data){
       if(data){
           for(var i=0;i<data.length;i++){
               var item=data[i];
               var type=parseInt(item.type); //字段type
               var region=obtainRegion(canvasHelper,type);
	       if(region){
	               region.setRegionWidth(item.width); //字段width
	               region.setRegionHeight(item.height); //字段height
                   region.setSColor(item.sColor); //字段sColor
                   region.setLColor(item.lColor); //字段lColor
                   var slist=item.value; //字段value
                   if(slist){
                       for(var j=0;j<slist.length;j++){
                           var value=slist[j];
                           var x=value.x; //字段x
                           var y=value.y;  //字段y
                           var tspot=new Spot(x,y);
                           tspot.setColor(region.sColor);
                           log(TAG,"parseRegionData-> i:"+i+" j:"+j+" x:"+x+" y:"+y);
                           region.pushSpot(tspot);
                       }
                       canvasHelper.regionList.push(region); //放入区域列表

                   }else{
                       throw "parseRegionData:valid value:"+value;
                   }
               }
           }
           log(TAG,"parseRegionData:regionList.length:"+regionList.length);
       }
   }

    //FIXME 需要加载Tool类
    function log(tag,msg){
        Tool.log(tag,msg);
    }
}
