const HeartbeatHelper = (function(w) {
	function init() {
             var ws = new WebSocket("ws://117.159.7.31:3138");
             ws.onopen = function(){
		 // TODO do something
				 ws.send("ping")
					 }
					 ws.onmessage = function(r) {
					if(HeartbeatHelper.isNotify) {
				   if(HeartbeatHelper.notify){
						  var data = JSON.parse(r.data);
					  HeartbeatHelper.notify(data)
		//		      console.log("interval: " + HeartbeatHelper.interval)
					  setTimeout(function() {
						   ws.send("ping")
					  }, HeartbeatHelper.interval);
					   } 
				}
					 }
					 ws.onclose = function(e) {
				 // TODO do something
					 }
					 ws.onerror = function(e) {
				 // TODO do something
					 }
			}
			var hb = {
				notify: null,
				isNotify: false,
				interval: 1000,
				hids: [],
				fresh: function(callback, interval) {
					if(!this.isNotify) {
						this.isNotify = true;
						this.notify = callback;
					// 最小间隔1s
					this.interval = Math.max(interval, 1000);
					}
				},
				monitor: function(hid) {
					if(!this.hids.includes(hid)) {
					this.hids.push(hid)
					}
				}
			};
				w.addEventListener("load", init, false); 
				return Object.create(hb);
		})(window);


// 每隔5秒, 刷新心跳数据
HeartbeatHelper.fresh(function(data) {
	var l = HeartbeatHelper.hids.length;
	if(l > 0) {
	   for(var i = 0; i < l; i++) {
	       var h = HeartbeatHelper.hids[i]
               var e = document.getElementById(h); 
	       if(e) {
	          e.innerHTML = "<span class='red'>无</span>"
	       }
	   }

	   var s = data["size"]
	   var d = data["data"]
	   for(var i = 0; i < s; i++) {
	       var h = "hid_" + d[i]["mac"]
               var e = document.getElementById(h); 
	       if(e) {
	          e.innerHTML = "<span class='green'>有</span>"
	       }
	   }
	}
}, 5000);
