

var moves='';
var Newtime='';
var LiLength='';
$(function () {
        
        $("#tips ").on('click',".nav_warn",function(){
                $(".popop1").toggle();
        });
        //时间自动更新
        $("#btn-time .Time").html(getFormatDate());
                setInterval(function() {
                        $("#btn-time .Time").html(getFormatDate());
        }, 1000);

        var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
        var datas = $.parseJSON(Arr);
        var userid=datas.Userid;

        // WarnPushMsg(userid);
        var date = new Date();
        var year = date.getFullYear();
        var month = date.getMonth()+1;
        var day = date.getDate();
        var hour = date.getHours();
        var minute = date.getMinutes();
        var second = date.getSeconds();
        var alltime=  year+'-'+month+'-'+day+' '+hour+':'+minute+':'+second;
        WarnPushMsg(userid,alltime);
        


        //APP更新管理
        //测温告警循环横向滚动
        // moveItRight();

        $(".close_img").on("click","img",function(){
                $(".box_imgBig").hide();
                $(".box_imgBigBottom").hide();
        });

        // 高温告警关闭
        // $("#rightLunbo").on("click",".swiper-slide",function(){
        //         var recordid=$(this).attr('data-recordid');
        //         left_module3_bigImg(recordid);
        // });
        
        //设备状态
        layui.use(['table','layer',"form"], function(){
                var layer = layui.layer;
                var form = layui.form;
                var table = layui.table;

                 // 地图列表
                 $("#mapListPopup").on('click',"#title1",function(){
                        var stationid=$(this).attr("data-stationid");
                        var url="tem_ment.html?stationid="+stationid;
                        Util.popFullScreen3(100,100,url);
                });
                // 温升跳转
                $(".wensheng_tiaozhuang").on('click',function(){
                        Util.popFullScreen3(100,100,"area_device.html");
                });

                // // 设备管理
                // $(".system_set").on('click',function(){
                //         Util.popFullScreen3(100,100,"system_set.html");
                // });
                $(".botSystemSet").on('click',function(){
                        Util.popFullScreen3(100,100,"system_set.html");
                });
                // 用户管理
                $(".user_manage").on('click',function(){
                        Util.popFullScreen3(100,100,"user_manage.html");
                });
                // APP更新管理
                $(".App_updata").on('click',function(){
                        Util.popFullScreen3(100,100,"App_updata.html");
                });
               
                // 测温告警
                $(".alarm_tiaozhuang").on('click',function(){
                        Util.popFullScreen3(100,100,"alarm_info.html");
                });
                // 周期测温峰值统计
                $(".highTemCount").on('click',function(){
                        Util.popFullScreen3(100,100,"highTemCount.html");
                });
                // 一周设备温度统计
                $(".oneWeekDetail").on('click',function(){
                        Util.popFullScreen3(100,100,"oneWeekDetail.html");
                });
                // 本月超80℃的设备统计
                $(".over80MonthDevice").on('click',function(){
                        Util.popFullScreen3(100,100,"over80MonthDevice.html");
                });
                // 查看本月报告
                $("#month_repo").on("click",function(){
                        $("#monthsExports").show();
                        // var url = "alarm_reportBZ.html?userid="+userid;
                        // Util.popFullScreen2('',1200,900,url);
                        
                });
                // 实时最高温
                $(".gaowen_tiaozhuang").on("click",function(){
                        Util.popFullScreen3(100,100,"realHighTem.html");
                        
                });

                
        });
        

        $("body .cancel").on("click",function(){
                $(".temperature_alem").hide();
                
        });

});


//测温告警循环左右滚动
// var syTimer=''
// function moveItRight() {
        
//         if (syTimer != null) {
//             clearInterval(syTimer);
//         }
//         var oUl = document.getElementById("slide_ul");
//         if(oUl != null){
//             var lis = oUl.getElementsByTagName('li');
//             var lisTotalWidth = 0;
//             var resetWidth = 0;
//             for (var i = 0; i < lis.length; i++) {
//                 lisTotalWidth += (lis[i].offsetWidth+30);
//             }
//             for (var i = 1; i <= lis.length / 4; i++) {
//                 resetWidth += (lis[i].offsetWidth+30);
//             }
//             oUl.style.width = lisTotalWidth + 'px';
//             var left = 0;
//             syTimer = setInterval(function() {
//                 left -= 1;
//                 if (left <= -resetWidth) {
//                     left = 0;
//                 }
//                 oUl.style.left = left + 'px';
//             }, 100)
//             $("#slide_ul").hover(function() {
//                 clearInterval(syTimer);
//             }, function() {
//                 clearInterval(syTimer);
//                 syTimer = setInterval(function() {
//                     left -= 1;
//                     if (left <= -resetWidth) {
//                         left = 0;
//                     }
//                     oUl.style.left = left + 'px';
//                 }, 100);
//             })
//         }
// }


// 设备最高温 左边上方 点击查看大图
function leftTop(datas){
        $(".box_imgBigLeftTop").show();  
        var html='',html2='';
        var tem='';
        var Times='';
        var time=datas.createtime; ///Date(158 572 227 7000)/
        if(time==''||time==null){
                Times='';
        }else{
                if(time.indexOf("T")!=-1){
                        Times=(datas.createtime).replace(/\T/g," ");
                }else{
                        var s1 = time.substring(6,19);
                        Times=times(s1);
                }
                

        }
        // if(time==''||time==null){
        //         Times='';
        // }else{
        //         Times=datas.createtime;

        // }
        if(datas.todaytop==''||datas.todaytop==null){
                tem=0;
        }else{
                tem=datas.todaytop;
        }
        
        var pics=[datas.image_mix,datas.image_high,datas.image_red];
        for(let item of pics){
                html+= `<div class="swiper-slide">
                        <img src="${item}" alt="图片">
                </div>`;
        }
        $("#lunbo_leftTopAll").html(html);

        if(tem>=100){
                html2+=`<div class="over100 tem fl">${tem}<span>℃</span></div>`;
        }
        if(tem >= 80 && tem < 100){
                html2+=`<div class="over80 tem fl">${tem}<span>℃</span></div>`;
        }
        if(tem<80){
                html2+=`<div class="up80 tem fl">${tem}<span>℃</span></div>`;
        }
        html2+=`<div class="fr">
                        <p>  
                                <span>${datas.devicename}</span>
                        </p>
                        <p class="time">(<span>${datas.machinename} ${datas.machinecode}</span>) <span> ${Times}</span></p>
                </div>`;
        $("#leftTopText").html(html2);

};
// 实时监测 右边 点击查看大图
function rightTpp(datas){
        $(".box_imgBigLeftTop").show();  
        var html='',html2='';
        var tem='';
        var Times='';
        var machinename=datas.machinename;
        if(!machinename){
                machinename='';
        }
        var time=datas.Time; ///Date(158 572 227 7000)/
        if(time==''||time==null){
                Times='';
        }else{
                // var s1 = time.substring(6,19);
                // time=datas.Time;
                Times=(datas.Time).replace(/\T/g," ");
        }
        if(datas.Todaytop==''||datas.Todaytop==null){
                tem=0;
        }else{
                tem=datas.Todaytop;
        }
        var pics=[datas.Image_mix,datas.Image_high,datas.Image_red,];
        for(let item of pics){
                html+= `<div class="swiper-slide">
                        <img src="${item}" alt="图片">
                </div>`;
        }
        $("#lunbo_leftTopAll").html(html);

        if(tem>=100){
                html2+=`<div class="over100 tem fl">${tem}<span>℃</span></div>`;
        }
        if(tem >= 80 && tem < 100){
                html2+=`<div class="over80 tem fl">${tem}<span>℃</span></div>`;
        }
        if(tem<80){
                html2+=`<div class="up80 tem fl">${tem}<span>℃</span></div>`;
        }
        html2+=`<div class="fr">
                        <p>
                                <span>${datas.Devicename}</span>
                        </p>
                        <p class="time">(<span>${machinename} ${datas.Machinecode}</span>) <span>${Times}</span></p>
                </div>`;
                
                // <span>${datas.Buildingname}</span> 
        $("#leftTopText").html(html2);

};
// 底部重点监测 点击查看大图
function showPhaseInfo(datas){
        $(".box_imgBigLeftTop").show(); 
        var html='',html2='';
        var tem='';
        var machinename=datas.machinename;
        if(!machinename){
                machinename='';
        }
        if(datas.dangqian==''||datas.dangqian==null){
                tem=0;
        }else{
                tem=datas.dangqian;
        }
        
        var Times=datas.createtime; ///Date(158 572 227 7000)/
        var pics=[datas.image_high,datas.image_mix,datas.image_red,];
        for(let item of pics){
                html+= `<div class="swiper-slide">
                        <img src="${item}" alt="图片">
                </div>`;
        }
        $("#lunbo_leftTopAll").html(html);
        if(tem>=100){
                html2+=`<div class="over100 tem fl">${tem}<span>℃</span></div>`;
        }
        if(tem >= 80 && tem < 100){
                html2+=`<div class="over80 tem fl">${tem}<span>℃</span></div>`;
        }
        if(tem<80){
                html2+=`<div class="up80 tem fl">${tem}<span>℃</span></div>`;
        }
        html2+=`<div class="fr">
                        <p><span>${datas.devicename}</span></p>
                        <p class="time">(<span>${machinename} ${datas.machinecode}</span>) <span>${Times}</span></p>
                </div>`;
        $("#leftTopText").html(html2);

};


//时间
function getFormatDate() {
        var nowDate = new Date();
        var year = nowDate.getFullYear();
        var month = nowDate.getMonth() + 1 < 10 ? "0" + (nowDate.getMonth() + 1)
                : nowDate.getMonth() + 1;
        var date = nowDate.getDate() < 10 ? "0" + nowDate.getDate() : nowDate
                .getDate();
        var hour = nowDate.getHours() < 10 ? "0" + nowDate.getHours() : nowDate
                .getHours();
        var minute = nowDate.getMinutes() < 10 ? "0" + nowDate.getMinutes()
                : nowDate.getMinutes();
        var second = nowDate.getSeconds() < 10 ? "0" + nowDate.getSeconds()
                : nowDate.getSeconds();
        return year + "-" + month + "-" + date + " " + hour + ":" + minute + ":"
                + second;
};
// 周期测温峰值统计 柱形图
function  left_module3(xdatas,roundDatas,deviceid_today,deviceid_yestoday,deviceid_week,deviceid_month,timeToday,timeYestoday,timeWeek,timeMonth){
        
        var recordid='',hisTime='';
        var dom = document.getElementById("module3");
        if(!dom){
                return;
        }
        var myChart=echarts.init(dom);
        var myColor = ['#00ffd2','#fffc9f','#ffcc00','#ff5e5e'];
 
	option = {
		
		tooltip: {
                        show:false,
			trigger: 'axis',
			textStyle:{
				color: '#fff'//字体颜色
			},
		},
		grid: {
			right: '5%',
			bottom:'27%'
		},
		
		xAxis: [
			{
                                type: 'category',
				axisTick: {
					show:false
				},
				axisLine: {
					show: true,
					lineStyle: {
						color: 'rgba(255,255,255,.4)'
					}
				},
				axisLabel: {
					textStyle: {
                                                //这个地方颜色是支持回调函数的这种的，如果是一种颜色则可以写成： color :'#1089E7'  
                                                color : function(value, index) {　　//value, index这是传入的两个参数
                                                        var num = myColor.length;　　//得到myColor颜色数组的长度
                                                        return myColor[index % num];  　　//返回颜色数组中的一个对应的颜色值
                                                },
                                                fontSize:16
					}
				},
				data:xdatas
			}
		],
		yAxis: [//多y轴时，用数组加对象的方式来实现
			{       
                                show:false,
				type: 'value',
				name: '温度°C',
				axisTick:{       //y轴刻度线
					show:false
				},
				axisLine: {
					show:false,
				},
				
			}
		],
		series: [
			{
                                name: '',
                                type: "pictorialBar",
                                symbolSize: [30, 3],
                                symbolOffset: [0, -1],
                                symbolPosition: "end",
                                label: {
                                    normal: {
                                        show: true,
                                        position: "top",
                                        formatter: "{c}°C",
                                        fontSize: 14,
                                    }
                                },
                                data: roundDatas,
                                itemStyle: {
                                    color:function(params) {
                                            var colorList=myColor;
                                            return colorList[params.dataIndex]
                                    }
                                }    
                              },
			{
                                name:'温度',
                                type:'bar',
                                barWidth: 30,
				smooth:true,
				symbol: 'circle',     //设定为实心点
				symbolSize: 30,   //设定实心点的大小
				data:roundDatas,
				lineStyle:{
					normal:{
						width:10
					}
                                },
                                // label: {
                                //         show: true, //开启显示
                                //         position: 'top', //在上方显示
                                //         textStyle: { //数值样式
                                //                 color: myColor,
                                //                 fontSize: 16,
                                //         }
                                // },
                                itemStyle: {
                                        color:function(params) {
                                                // build a color map as your need.
                                                // var colorList = ['rgba(0,255,210,0.2)','rgba(255,252,159,0.5)','rgba(255,252,159,0.5)','rgba(255,94,94,0.5)'];
                                                var colorList = ['rgba(0,255,210,0.5)','rgba(255,252,159,0.5)','rgba(255,252,159,0.5)','rgba(255,94,94,0.5)'];
                                                // var colorList=myColor;
                                                return colorList[params.dataIndex]
                                        },
                                }        
			}
		]
	};
 
        myChart.setOption(option);

        myChart.on('click', function (params) {
                //查看大图s 周期峰值统计 左边
                if(params.name=="今日"){
                        recordid=deviceid_today;
                        hisTime=timeToday;
                }else if(params.name=="昨日"){
                        recordid=deviceid_yestoday;
                        hisTime=timeYestoday;
                }else if(params.name=="7日"){
                        recordid=deviceid_week;
                        hisTime=timeWeek;
                }else if(params.name=="30日"){
                        recordid=deviceid_month;
                        hisTime=timeMonth;
                }else{
                        recordid='';
                        hisTime='';
                }
               left_module3_bigImg(recordid,hisTime);
        });
        $(".close_img").on("click","img",function(){
                $(".box_imgBigLeft_module3").hide();
        });

};
// 地区环温与设备高温对比 柱形折线图
function  left_module4(areaWran,deviceWran,xdatas,trues,temprecordid){
        var recordid='';
        var dom = document.getElementById("module4");
        
        if(!dom){
                return;
        }
        var myChart=echarts.init(dom);
        option = {
        
                tooltip: {
                        trigger: 'axis',
                        textStyle:{
                        color: '#fff'//字体颜色
                        },
                },
                grid: {
                        right: '5%',
                        bottom:'30%'
                },
                dataZoom: [//给x轴设置滚动条
                {
                        start:0,//默认为0
                        end: 80,//默认为100
                        type: 'slider',
                        show: trues,
                        xAxisIndex: [0],
                        handleSize: 0,//滑动条的 左右2个滑动条的大小
                        height: 10,//组件高度
                        left: '10%', //左边的距离
                        right: '10%',//右边的距离
                        bottom: 5,//下边的距离
                        borderColor: "#000",
                        fillerColor: '#269cdb',
                        borderRadius:5,
                        backgroundColor: '#33384b',//两边未选中的滑动条区域的颜色
                        showDataShadow: false,//是否显示数据阴影 默认auto
                        showDetail: false,//即拖拽时候是否显示详细数值信息 默认true
                        realtime:true, //是否实时更新
                        filterMode: 'filter',
                        },
                        //下面这个属性是里面拖到
                {
                        type: 'inside',
                        show: trues,
                        xAxisIndex: [0],
                        start: 0,//默认为1
                        end: 1,//默认为100
                },
                ],  
                legend: {
                        data:['地区气温', '设备高温'],
                        textStyle:{
                        color: '#fff'//字体颜色
                        },
                        right: '5%',
                        top:'20',
                        itemWidth: 18,
                        itemHeight: 8,
                        itemGap: 20,
                },
                xAxis: [
                        {
                        type: 'category',
                        interval:1,
                        data: xdatas,
                        axisTick: {
                                show: false,
                        },
                        
                        axisLabel : {//坐标轴刻度标签的相关设置。
                                textStyle: {
                                        fontSize: 12,
                                        color: 'rgba(255,255,255,0.8)'
                                },
                                interval: 0,
                                rotate:'30',
                                formatter: function (value) {   //关键代码
                                        var res = value
                                        if (res.length >2) {
                                                res = res.substring(0, 2) + '..'
                                        }
                                        return res
                                        },
                                
                                
                        },
                
                        axisLine: {
                                lineStyle: {
                                        color: 'rgba(255,255,255,0.8)'
                                }
                        },
                        
                        },
                        
                ],
                yAxis: [
                        {
                        type: 'value',
                        // scale: true,
                        name: '',
                        axisTick: {
                                show: false,
                        },
                        axisLabel: {
                                textStyle: {
                                        fontSize: 10,
                                        color: 'rgba(255,255,255,0.8)'
                                }
                        },
                        axisLine: {
                                show: false,
                        },
                        splitLine :{    //网格线
                                lineStyle:{
                                        type:'dashed'    //设置网格线类型 dotted：虚线   solid:实线
                                        ,color: ['#315070']
                                },
                                show:true //隐藏或显示
                        }
                        },
                        
                        
                ],
                series: [
                
                        {
                                name:'地区气温',
                                type:'line',
                                color:"#ffcd34",
                                normal:{
                                        color:"#CD5C5C"
                                },
                                data:areaWran
                        },
                        {
                                name:'设备高温',
                                type:'bar',
                                barWidth: 10,
                                color:"#00ffd2",
                                data:deviceWran
                        }
                ]
        };
        
        myChart.setOption(option);
        myChart.on('click', eConsole);
        function eConsole(param) {
                if (typeof param.dataIndex == 'undefined') {
                        return;
                };
                for(var i=0;i<temprecordid.length;i++){
                        if (param.dataIndex ==i) {
                                recordid=temprecordid[i];
                                left_module3_bigImg(recordid);
                        }
                };
        }
                
        $(".close_img").on("click","img",function(){
                $(".swiper_big_Leftmodule4").hide();
        });
        
};
// 实时监测设备趋势
function Right_module(todayTime,tem,fuhe,id){
        var dom = document.getElementById("Right_module"+id);
        if(!dom){
                return;
        }
        var myChart=echarts.init(dom);
        option = {
                
                tooltip: {
                    trigger: 'axis',
                    formatter(params){
                        const item = params[0];
                        return `时间：${item.name}:00<br/>
                                温度：${item.value}℃`;
                    }
                },
                
                legend: {
                        data:['温度(℃)', '负荷(A)'],
                        textStyle:{
                            color: '#fff'//字体颜色
                        },
                        right: '5%',
                        top:'2',
                        itemWidth: 18,
                        itemHeight: 8,
                        itemGap: 10,
                },
                grid: {
                    top:'30%',
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                
                xAxis: {
                    type: 'category',
                    interval:1,
                    data: todayTime,
                    axisTick: {
                        show: false,
                        },
                        axisLabel: {
                                textStyle: {
                                        fontSize: 12,
                                        color: 'rgba(255,255,255,0.8)'
                                },
                        },
                        axisLine: {
                                lineStyle: {
                                        color: 'rgba(255,255,255,0.8)'
                                }
                        },
                },
                yAxis: {
                    type: 'value',
                //     min:0,
                //     max:120,
                    axisTick: {
                        show: false,
                        },
                        axisLabel: {
                                textStyle: {
                                        fontSize: 10,
                                        color: 'rgba(255,255,255,0.8)'
                                },
                        },
                        axisLine: {
                                show: false,
                        },
                        splitLine :{    //网格线
                                lineStyle:{
                                    type:'dashed'    //设置网格线类型 dotted：虚线   solid:实线
                                    ,color: ['#315070']
                                },
                                show:true //隐藏或显示
                        }
                },
                series: [
                        
                    {
                        name:'温度(℃)',
                        color:'#00ffd2',
                        smooth: true,
                        type:'line',
                        data:tem
                    },
                    {
                        name:'负荷(A)',
                        color:'#ffcc00',
                        smooth: true,
                        type:'line',
                        data:fuhe
                    },
                    
                ]
            };
            myChart.setOption(option);
};


// 底部重点监测设备跟踪 柱形图
function  bottomItem_module(a,b,id,todaymaxid,monthmaxid){
        // var recordid='';
        var dom = document.getElementById("bottomItem_module"+id);
        if(!dom){
                return;
        }
        var myChart=echarts.init(dom);
        var myColor =[ '#fffc9f','#ffcc00' ]
        option = {
                tooltip: {
                        show:false,
                        trigger: 'axis',
                        formatter(params){
                                const item = params[0];
                                return `温度：${item.value}℃`;
                        },
                        textStyle:{
                                color: '#fff'//字体颜色
                        },
                        // axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        //         type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                        // }
                },
                grid: {
                        top:'30%',
                        right: '5%',
                        bottom:'25%'
                },
                
                xAxis: [
                        {
                                type: 'category',
                                interval:1,
                                axisTick: {
                                        show:false
                                },
                                axisLine: {
                                        show: true,
                                        lineStyle: {
                                                color: 'rgba(255,255,255,.4)'
                                        }
                                },
                                axisLabel: {
                                        textStyle: {
                                                //这个地方颜色是支持回调函数的这种的，如果是一种颜色则可以写成： color :'#1089E7'  
                                                color : function(value, index) {　　//value, index这是传入的两个参数
                                                        var num = myColor.length;　　//得到myColor颜色数组的长度
                                                        return myColor[index % num];  　　//返回颜色数组中的一个对应的颜色值
                                                },
                                                fontSize:10
                                        },
                                },
                                data: ['今日最高','30日最高']
                        }
                ],
                yAxis: [//多y轴时，用数组加对象的方式来实现
                        {       
                                show:false,
                                type: 'value',
                                name: '温度°C',
                                axisTick:{       //y轴刻度线
                                        show:false
                                },
                                axisLine: {
                                        show:false,
                                },
                                
                        }
                ],
                series: [
                        
                        {
                                name:'',
                                type:'bar',
                                barWidth: 15,
                                smooth:true,
                                symbol: 'circle',     //设定为实心点
                                symbolSize: 30,   //设定实心点的大小
                                data:[a,b],
                                lineStyle:{
                                        normal:{
                                                width:10
                                        }
                                },
                                color:function(params) {
                                        // build a color map as your need.
                                        var colorList = myColor;
                                        return colorList[params.dataIndex]
                                },
                                label: {
                                        normal: {
                                                show: true,
                                                position: "top",
                                                formatter: "{c}°C",
                                                color: myColor,
                                                fontSize: 12,
                                        }
                                },
                                        
                        }
                ]
        };

        myChart.setOption(option);
};

//高温警告 弹出框
//获取当前用户下所有告警推送信息 userpower表示用户等级：0总公司用户，1工区用户，2运维班用户
function WarnPushMsg(userid,newesttime){
        layui.use(['layer','form'], function(){
                var layer = layui.layer;
                $.ajax({
                        type:'get',
                        url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getAlarmPush',
                        dataType:'JSON',  
                        data:{
                                userid:userid,
                                newesttime:newesttime
                        },
                        success:function(data){
                                var  content='';
                                Newtime=data.Newesttime;
                                LiLength=data.Dt.length;
                                for(let item of data.Dt){
                                        if(item.isread==1){
                                                $(".WarnPushMsg_tanchu").show();
                                                var Times=item.createtime; 
                                                content+=`<li class="temperature_alem">
                                                        <div class="alarm">
                                                                <div class="title">超出设定温度告警</div>
                                                                <div class="alarm_content">
                                                                        <div class="alarmImg_icon fl">
                                                                                <img src="../images/alarm/Give an alarm.png" alt="">
                                                                        </div>
                                                                        <div class="fr">
                                                                                <p class="p1"><span>${item.ywbname}</span><span>${item.stationname}</span></p>
                                                                                <p class="p2"><span>${item.buildingname}</span><span>${item.machinename}</span><span>${item.ysdname}</span></p>
                                                                                <p class="p2"><span>${item.devicename}</span></p>
                                                                                <p class="p3">当前温度<span>${item.alarmvalue}</span>℃</p>
                                                                                <p class="p7"><span class="ysz_tem">超预设值${item.overvalue}℃</span></p>
                                                                                <p class="p4">请工作人员现场确认情况</p>
                                                                                <p class="p5">${Times}</p>
                                                                        </div>
                                                                </div>
                                                                <button class="buttn_push" data-id="${item.id}"><img src="../images/alarm/cancel.png">我知道了</button></div></li>`;
                                                $("#WarnPushMsg").html(content);
                                        }else{
                                                $(".WarnPushMsg_tanchu").hide(); 
                                        }
                                }
                                
                        },
                        error:function(err){
                                console.log(err)
                        }
                
                });
        });
        setTimeout(function () { 
                WarnPushMsg(userid,Newtime);
        },20000)    
};


$("#WarnPushMsg").on("click",'.buttn_push',function(){
        var alarmid=$(this).attr("data-id");
        var _this=this;
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/App_SetRead',
                dataType:'JSON',  
                data:{
                        alarmid:alarmid,
                },
                success:function(data){
                        LiLength--;
                        if(LiLength>0){
                                $(_this).parent().parent().addClass("displayNone");
                        }else{
                                $(".WarnPushMsg_tanchu").hide();    
                        }
                        
                },
                error:function(err){
                        console.log(err)
                }

        });
});

//周期测温峰值统计 点击查看大图 柱形图
//获取峰值统计中温度对应的图片，传值recordid（历史图像id）
function left_module3_bigImg(recordid,hisTime){
        if(hisTime==''||hisTime==null||hisTime==undefined){
                var hisTime='';
        }
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/WebgetRoundImageBuid',
                dataType:'JSON',  
                data:{
                        recordid:recordid,
                        Time:hisTime
                },
                success:function(data){
                        if(recordid!=''){
                                $(".box_imgBigLeftTop").show();
                                $(".box_imgBigHistoryImg").show(); 
                                $(".box_imgBigWeek").show();    
                                var html='',html2='';
                                var tem='';
                                var time=data[0].createtime; ///Date(158 572 227 7000)/
                                var Times='';
                                if(time==''||time==null){
                                        Times='';
                                }else{
                                        Times=data[0].createtime;
                                }
                                if(data[0].valuemax==''||data[0].valuemax==null){
                                        tem=0;
                                }else{
                                        tem=data[0].valuemax;
                                }
                                var machinename=data[0].machinename;
                                if(!machinename){
                                        machinename='';
                                }
                                var pics=[data[0].imageurl1,data[0].imageurl2,data[0].imageurl3];
                                for(let item of pics){
                                        html+= `<div class="swiper-slide">
                                                <img src="${item}" alt="图片">
                                        </div>`;
                                };
                                $("#lunbo_leftTopAll").html(html);
                                $("#lunbo_HistoryImg").html(html);
                                if(tem>=100){
                                        html2+=`<div class="over100 tem fl">${tem}<span>℃</span></div>`;
                                }
                                if(tem >= 80 && tem < 100){
                                        html2+=`<div class="over80 tem fl">${tem}<span>℃</span></div>`;
                                }
                                if(tem<80){
                                        html2+=`<div class="up80 tem fl">${tem}<span>℃</span></div>`;
                                }
                                html2+=`<div class="fr">
                                                <p>
                                                        <span>${data[0].devicename}</span>
                                                </p>
                                                <p class="time">(<span>${machinename} ${data[0].machinecode}</span>)<span>${Times}</span></p>
                                        </div>`;
                                $("#leftTopText").html(html2);
                                $("#HistoryImgText").html(html2);
                        }
                },
                error:function(err){
                        console.log(err)
                }
        
        });
};

//周期测温峰值统计 二级页面 折线图
function hightTem(listStations,stationName,todayTem,yesterdayTem,weekTem,monthTem) {
        if((stationName==''||stationName==null)||(todayTem==''||todayTem==null)||(yesterdayTem==''||yesterdayTem==null)
                ||(weekTem==''||weekTem==null)||(monthTem==''||monthTem==null)){
                
                stationName='';
                todayTem='';
                yesterdayTem='';
                weekTem='';
                monthTem='';
        }
        var dom = document.getElementById("higtTem");
        if(!dom){
        return;
        }else{
            var myChart=echarts.init(dom);
            option = {
                title:{
                        show:false,
                        text:'',
                        x:'center',
                        y:'top',
                        textAlign:'center',
                        textStyle:{
                                //文字颜色
                                color:'#00fcff',
                                fontWeight:'400',
                                //字体大小
                        　　　　 fontSize:18,
                                
                        }
                },
                tooltip: {
                    trigger: 'axis',
                    
                },
                
                legend: {
                        data:['今日', '昨日', '7日', '30天'],
                        textStyle:{
                            color: '#fff'//字体颜色
                        },
                        right: '5%',
                        top:'2',
                        itemWidth: 18,
                        itemHeight: 8,
                        itemGap: 10,
                },
            
                grid: {
                    top:'10%',
                    left: '3%',
                    right: '3%',
                    bottom: '0',
                    containLabel: true
                },
                
                xAxis: {
                    type: 'category',
                    interval:1,
                    data:stationName,
                    axisTick: {
                        show: false,
                    },
                    axisLabel: {
                            textStyle: {
                                    fontSize: 12,
                                    color: 'rgba(255,255,255,0.8)'
                            },
                            interval:0,
                            rotate:40 //文字倾斜
                    },
                    axisLine: {
                            lineStyle: {
                                    color: '#315070'
                            }
                    },
                },
                yAxis: {
                    type: 'value',
                    name:'温度℃',
                    nameTextStyle:{
                    color:'#fff',
                    fontSize:14
                    },
                    axisTick: {
                        show: false,
                        },
                        axisLabel: {
                        textStyle: {
                            fontSize: 12,
                            color: 'rgba(255,255,255,0.8)'
                        },
                        },
                        axisLine: {
                            show: false,
                        },
                        splitLine :{    //网格线
                            lineStyle:{
                                type:'dashed'    //设置网格线类型 dotted：虚线   solid:实线
                                ,color: ['#315070']
                            },
                            show:true //隐藏或显示
                        }
                },
                series: [
                    {
                        name:'今日',
                        color:'#00FFD2',
                        smooth: false,//折线是否平滑
                        type:'line',
                        data:todayTem,
                    },
                    {
                        name:'昨日',
                        color:'#fff',
                        smooth: false,//折线是否平滑
                        type:'line',
                        data:yesterdayTem
                    },
                    {
                        name:'7日',
                        color:'#FFFC9F',
                        smooth: false,//折线是否平滑
                        type:'line',
                        data:weekTem
                    },
                    {
                        name:'30天',
                        color:'#FF5E5E',
                        smooth: false,//折线是否平滑
                        type:'line',
                        data:monthTem
                    }
                    
                ]
            };
            myChart.setOption(option);
                myChart.on('click', function (params) {
                        //查看大图s 周期峰值统计 左边
                        var stationid='';
                        if (typeof params.dataIndex == 'undefined') {
                                return;
                        };
                        if(listStations!=''&&listStations!=null){
                                for(var i=0;i<listStations.length;i++){
                                        if (params.dataIndex ==i) {
                                                stationid=listStations[i];
                                                hightTem_bigImg(stationid);
                                        }
                                };
                        }
                        
                });
                $(".close_img").on("click","img",function(){
                        $(".box_imgBigLeft_module3").hide();
                });
        }
    
};
// 周期测温峰值 二级页面 点击出现图
function hightTem_bigImg(stationid){
        $.ajax({
                type:'get',
                url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getStation_image_TYWMH',
                dataType:'JSON',  
                data:{
                        stationid:stationid,
                },
                success:function(data){
                        var html='';
                        if(data.length>0){
                                html+='<h2>'+data[0].stationname+'</h2>';
                                for(let item of data){
                                        var tem=item.topvalue;
                                        html+= `<li>`;
                                        if(item.image_red!=''&&item.image_red!=null&&item.image_red!=undefined){
                                                html+= `<div class="pics"><img src="${item.image_red}" alt=""></div>`;
                                        }else{
                                                html+= `<div class="pics">
                                                <img src="../images/no_pic.png" alt="图片"></div>`; 
                                        }
                                        html+= `<div class="textP">
                                        <div class="tem fl">`;
                                                if(tem>=100){
                                                        html+=`<p class="over100 wendu fl">${tem}<span>℃</span></p>`;
                                                }
                                                if(tem >= 80 && tem < 100){
                                                        html+=`<p class="over80 wendu fl">${tem}<span>℃</span></p>`;
                                                }
                                                if(tem<80){
                                                        html+=`<p class="up80 wendu fl">${tem}<span>℃</span></p>`;
                                                }
                                        html+= `<p>${item.date}</p>
                                        </div>
                                        <div class="stName fr">
                                                <p><span>${item.devicename}</span></p>
                                                <p class="time">(<span>${item.machinename} ${item.machinecode}</span>) ${item.createtime}</p>
                                        </div>
                                        <div class="clear"></div>
                                        </div>
                                        <div class="clear"></div>
                                </li>`;
                                };
                        }else{
                                html+='<img src="../images/no_pic.png">'
                        }
                        $(".bigPics").html(html);
                },
                error:function(err){
                        console.log(err)
                }
        
        });
};

function bottom_bigImg(datas){
        $(".box_imgBigBottomItem").show();
        var html='',html2='<div class="zuo">';
        var tem='';
        var time=datas.todaymax_time; ///Date(158 572 227 7000)/
        var Times='';
        var machinename=datas.machinename;
        if(!machinename){
                machinename='';
        }
        if(time==''||time==null){
                Times='';
        }else{
                Times=datas.todaymax_time;
        }
        if(datas.todaymax==''||datas.todaymax==null){
                tem=0;
        }else{
                tem=datas.todaymax;
        }
        if(datas.today_image!=''&&datas.today_image!=null&&datas.today_image!=undefined){
                html+= `<div class="swiper-slide">
                <img src="`+datas.today_image+`" alt="图片"></div>`;
        }else{
                html+= `<div class="swiper-slide">
                <img src="../images/no_pic.png" alt="图片"></div>`; 
        }
        // html+= `<div class="swiper-slide">
        //         <img src="`+datas.today_image+`" alt="图片">
        // </div>`;
        $("#bottomAllPic").html(html);
        
        if(tem>=100){
                html2+=`<div class="over100 tem fl">${tem}<span>℃</span></div>`;
        }
        if(tem >= 80 && tem < 100){
                html2+=`<div class="over80 tem fl">${tem}<span>℃</span></div>`;
        }
        if(tem<80){
                html2+=`<div class="up80 tem fl">${tem}<span>℃</span></div>`;
        }
        html2+=`<p>今日最高</p></div><div class="fr">
                        <p>
                                <span>${datas.devicename}</span>
                        </p>
                        <p class="time">(<span>${machinename} ${datas.machinecode}</span>) <span>${Times}</span></p></div>`;
        $("#bottomTextItem").html(html2);


        var html3='',html4='<div class="zuo">';
        var tem2='';
        var time2=datas.monthmax_time; ///Date(158 572 227 7000)/
        var Times2='';
        if(time2==''||time2==null){
                Times2='';
        }else{
                Times2=datas.monthmax_time;
        }
        if(datas.monthmax==''||datas.monthmax==null){
                tem2=0;
        }else{
                tem2=datas.monthmax;
        }

        if(datas.month_image!=''&&datas.month_image!=null&&datas.month_image!=undefined){
                html3+= `<div class="swiper-slide">
                <img src="`+datas.month_image+`" alt="图片"></div>`;
        }else{
                html3+= `<div class="swiper-slide">
                <img src="../images/no_pic.png" alt="图片"></div>`; 
        }
        // html3+= `<div class="swiper-slide">
        //         <img src="`+datas.month_image+`" alt="图片"></div>`;
        $("#bottomAllPic2").html(html3);
        
        if(tem2>=100){
                html4+=`<div class="over100 tem fl">${tem2}<span>℃</span></div>`;
        }
        if(tem2 >= 80 && tem2 < 100){
                html4+=`<div class="over80 tem fl">${tem2}<span>℃</span></div>`;
        }
        if(tem2<80){
                html4+=`<div class="up80 tem fl">${tem2}<span>℃</span></div>`;
        }
        html4+=`<p>30日最高</p></div><div class="fr">
                        <p> 
                                <span>${datas.devicename}</span>
                        </p>
                        <p class="time">(<span>${datas.machinecode}</span>) <span>${Times2}</span></p></div>`;
        $("#bottomTextItem2").html(html4);
                
};
// 告警列表  温度对比 柱形图  变电站设备类型统计
function  todayAlarmModule2Left(XdeviceType,count){
        var colors=['#f16159','#00FFD2'];
        var dom = document.getElementById("todayAlarmModule2");
        if(!dom){
                return;
        }else{
            var myChart=echarts.init(dom);
            option = {
                tooltip: {
                        show:false,
                        trigger: 'axis',
                        textStyle:{
                        color: '#fff'//字体颜色
                        },
                //   formatter(params){
                //     const item = params[0];
                //     return `<span style="color:#00ffd2;">温度：${item.value}℃</span><br/>
                //             <span style="color:#00ffd2;">${item.name}</span>`;
                //   }
                },
                grid: {
                  top:'28%',
                  right: '10%',
                  left:"30%",
                  bottom:'32%'
                },
                
                xAxis: [
                  {
                    type: 'category',
                    interval:0,
                    axisTick: {
                      show:false
                    },
                    axisLine: {
                      show: true,
                      lineStyle: {
                        color: 'rgba(255,255,255,.4)'
                      }
                    },
                    axisLabel: {
                        // rotate:20,
                        textStyle: {
                            //这个地方颜色是支持回调函数的这种的，如果是一种颜色则可以写成： color :'#1089E7'  
                            color : "#fff",
                            fontSize:10
                        }
                    },
                    data: XdeviceType
                  }
                ],
                yAxis: [//多y轴时，用数组加对象的方式来实现
                  {       
                    show:false,          
                    type: 'value',
                    name: '',
                    interval:1,
                    axisTick:{       //y轴刻度线
                      show:false
                    },
                    axisLine: {
                      show:false,
                    },
                    
                  }
                ],
                
                series: [
                  
                  {
                    name:'',
                    type:'bar',
                    barWidth: 10,
                    smooth:true,
                    symbol: 'circle',     //设定为实心点
                    symbolSize: 30,   //设定实心点的大小
                    data:count,
                    lineStyle:{
                      normal:{
                        width:10
                      }
                    },
                    label: {
                            show: true, //开启显示
                            position: 'top', //在上方显示
                            textStyle: { //数值样式
                                  color : "#fff",
                                  fontSize: 10,
                            },
                            
                    },
                    itemStyle: {
                        color:function(params) {
                                var colorList=colors;
                                return colorList[params.dataIndex]
                        }
                    } , 
                        
                  }
                ]
            };
            myChart.setOption(option);
      
        }    
      
};
//饼图 左侧 本月超80℃的设备统计   RightTypeBar
//饼图 告警列表 设备类型统计    
// function alarmTypeModule2Right(names,numValue){ 
//         var datas=[];
//         var colors=['#00ffd2','#fffc9f','#2e9095','#fc6357','#ffcc00','#fff','#8672ee','#f87b23'];
//         for(var i = 0;i<names.length;i++){
//                 datas.push({ 
//                         name: names[i],
//                         value: numValue[i],
//                 });
//          };
//         // var dom = document.getElementById("moduleRight80");
//         var dom = document.getElementById("alarmTypeModule2");
//         if(!dom){
//             return;
//         }else{
//                 var myChart=echarts.init(dom);
//                 option = {
//                         title: {
//                                 show:false,
//                                 subtext: '单位：次',
//                                 left: 'left',
//                                 textStyle: {
//                                         color: '#fff',
//                                         fontSize: '12'
//                                 },
//                         },
//                         tooltip: {
//                                 trigger: 'item',
//                                 formatter: '{b} : {c} ({d}%)',
//                                 color:"#fff"
//                         },
//                         legend: {
//                                 orient: 'vertical',
//                                 x: 'right',
//                                 y: 'center',
//                                 top:0,
//                                 align: 'left',
//                                 data: names,
//                                 textStyle: {
//                                         color: '#fff',
//                                         fontSize: '10'
//                                 },
//                                 itemWidth: 6,
//                                 itemHeight: 4,
//                                 itemGap:0, //上下间距
//                         },
//                         // color:["#eb6877","#5687fe","#fbc235","#3de7c9"],
//                         series:  [
//                                 {
//                                     name: '',
//                                     type: 'pie',
//                                     radius: '50%',
//                                     center: ['20%', '50%'],
//                                     color:colors,
//                                     data:datas,
//                                     label: {
//                                         normal: {
//                                                 show:false,
                                            
//                                         }
//                                     },
//                                 }
//                             ]
//                 };
//                 myChart.setOption(option);
//         }
        
// };
function alarmTypeModule2Right(names,numValue){
        var dom = document.getElementById("alarmTypeModule2");
        var total=0;
        for(var i=0;i<numValue.length;i++){
                total+=parseInt(numValue[i]);
        }
        var datas=[];
        var colors=['#00ffd2','#fffc9f','#2e9095','#fc6357','#ffcc00','#fff','#8672ee','#f87b23'];
        for(var i = 0;i<names.length;i++){
                datas.push({ 
                        name: names[i],
                        value: numValue[i],
                });
        };
        if(!dom){
            return;
        }else{
            var myChart=echarts.init(dom);
        
            option = {
                title: {
                    text:total,
                //     subtext:'总计',
                    x: '14%',
                    y: 'center',
                    top:"28%",
                    itemGap:0,
                    textStyle: {
                        color: '#fff',
                        fontWeight:"normal",
                        fontSize:16
                    },
                    subtextStyle:{
                        color: '#fff',
                    }
                },
                tooltip: {
                    trigger: 'item',
                },
                legend: {
                        orient: 'vertical',
                        x: 'right',
                        y: 'center',
                        top:0,
                        align: 'left',
                        data: names,
                        textStyle: {
                                color: '#fff',
                                fontSize: '10',
                                
                        },
                        itemWidth: 6,
                        itemHeight: 4,
                        itemGap:0, //上下间距
                },
                color:colors,
                series: [{
                    name: '',
                    type: 'pie',
                    radius: ['50%', '62%'],
                    center: ['20%', '50%'],
                    label: {
                      show: false
                      // textStyle: {
                      //     color: "#ffffff",
                      //     fontSize: 14,
                      // }
                    },
                    labelLine: {
                      show: false
                    },
                    data: datas
                }]
            };
            if (option && typeof option === "object") {
                myChart.setOption(option, true);
            }
            
        }
};
// 右侧 本月超80℃的设备统计 点击查看大图
function mediaCenterInfo(datas){
        $(".box_imgBigLeftTop").show(); 
        var html='',html2='';
        var tem='';
        var machinename=datas.machinename;
        if(!machinename){
                machinename='';
        }
        if(datas.alarmvalue==''||datas.alarmvalue==null){
                tem=0;
        }else{
                tem=datas.alarmvalue;
        }
        var Times=datas.createtime; ///Date(158 572 227 7000)/
        var pics=[datas.image_high,datas.image_mix,datas.image_red];
        for(let item of pics){
                html+= `<div class="swiper-slide">
                        <img src="${item}" alt="图片">
                </div>`;
        }
        $("#lunbo_leftTopAll").html(html);
        if(tem>=100){
                html2+=`<div class="over100 tem fl">${tem}<span>℃</span></div>`;
        }
        if(tem >= 80 && tem < 100){
                html2+=`<div class="over80 tem fl">${tem}<span>℃</span></div>`;
        }
        if(tem<80){
                html2+=`<div class="up80 tem fl">${tem}<span>℃</span></div>`;
        }
        html2+=`<div class="fr">
                        <p><span>${datas.devicename}</span></p>
                        <p class="time">(<span>${machinename} ${datas.machinecode}</span>) <span>${Times}</span></p>
                </div>`;
        $("#leftTopText").html(html2);

};

function qx(){
        $("#monthsExports").hide();
}
function workReportSave(){
        $("#monthsExports").hide();
        var timeAll=$('#monthsExportsDate').val();
        var tiemArr=timeAll.split("~");
        var startDate=tiemArr[0];
        var endDate=tiemArr[1];
        var url = "alarm_reportBZ.html?userid="+userid+'&&startDate='+startDate+'&&endDate='+endDate;
        Util.popFullScreen2('',1200,900,url);
}
