var userid='';
$(document).ready(function () {
    layui.use(['table','layer',"form"], function(){
        var layer = layui.layer;
        var form = layui.form;
        var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
        var datas = $.parseJSON(Arr);
        userid=datas.Userid;

        // 用户管理
        user_getAll(userid);//工区用户
        
        
        
      
        $("#gqUser_ul").on("click",'.item_left',function(){
            
            $("#fenbuUser_ul").empty();
            $("#ywbUser_ul").empty();
            $(this).addClass("active").parent().siblings().find(".item_left").removeClass("active");
            var areaid=$(this).attr("data-areaid");
            user_getareaAll(areaid);//分部用户
            user_sel(areaid,0);
            sel_fenbuname(areaid);
        });
        $("#fenbuUser_ul").on("click",'.item_left',function(){
            $(this).addClass("active").parent().siblings().find(".item_left").removeClass("active");
            var fenbuid=$(this).attr("data-fenbuid");
            user_getfenbuAll(fenbuid);//运维班用户
            user_sel(fenbuid,1);
            sel_ywbname(fenbuid);
        });

        // 工区添加
        $("#user_addArea1").on("change",function(){
          var areaid=$("#user_addArea1 option:selected").attr("data-areaid");
          sel_fenbuname(areaid);
        });
        // 工区修改
        $("#user_editArea1").on("change",function(){
          var areaid=$("#user_editArea1 option:selected").attr("data-areaid");
          sel_fenbuname(areaid);
        });
        
        


        // 分部添加
        $("#user_addFenbu1").on("change",function(){
          var areaid=$("#user_addFenbu1 option:selected").attr("data-areaid");
          sel_fenbuname(areaid);
        });
        $("#user_addFenbu2").on("change",function(){
          var fenbuid=$("#user_addFenbu2 option:selected").attr("data-fenbuid");
          sel_ywbname(fenbuid);
        });
        
        // 分部修改
        $("#user_editFenbu1").on("change",function(){
          var areaid=$("#user_editFenbu1 option:selected").attr("data-areaid");
          sel_fenbuname(areaid);
        });
        $("#user_editFenbu2").on("change",function(){
          var fenbuid=$("#user_editFenbu2 option:selected").attr("data-fenbuid");
          sel_ywbname(fenbuid);
        });
        

        // 运维班添加
        $("#user_addYwb1").on("change",function(){
          var areaid=$("#user_addYwb1 option:selected").attr("data-areaid");
          sel_fenbuname(areaid);
        });
        $("#user_addYwb2").on("change",function(){
          var fenbuid=$("#user_addYwb2 option:selected").attr("data-fenbuid");
          sel_ywbname(fenbuid);
        });
        
        // 运维班修改
        $("#user_editYwb1").on("change",function(){
          var areaid=$("#user_editYwb1 option:selected").attr("data-areaid");
          sel_fenbuname(areaid);
        });
        $("#user_editYwb2").on("change",function(){
          var fenbuid=$("#user_editYwb2 option:selected").attr("data-fenbuid");
          sel_ywbname(fenbuid);
        });
        
        
      //工区  修改、删除、重置、添加 的事件
        var oldusernameArea=''
      var active_area = {
          edit: function(id){
              $(".user_tanchuWorkArea").show();
              // $("#user_editArea1").html(" ");
              // $("#user_editArea2").html(" ");
              // $("#user_editArea3").html(" ");
              sel_areaname(userid);
              user_getOneAll(id);
              oldusernameArea=$(this).attr("data-areanames"); // 工区
          },
          del: function(id){
                  layer.confirm('确认删除', {
                          title: false,
                          closeBtn: 0, //不显示关闭按钮
                          id: 'del1', //设定一个id，防止重复弹出
                          btn: ['确认', '取消'],
                          area: ['478px', '172px'],},
                          function (index) {
                            user_getdel(id)
                            //刷新
                            location.reload();
                            layer.close(index);
                          },function (index) {//cancel回调
                              layer.close(index);
                  }); 
          },
          reset_pwd:function(id,username_area,areaname_area,fenbuname_area,ywbname_area){
            $("#user_resetArea1").val(username_area);
              layer.open({
                  type: 1
                  ,title: false //不显示标题栏
                  ,closeBtn: false
                  ,area: ['523px','468px']
                  ,shade: 0.8
                  ,id: 'user_resect1' //设定一个id，防止重复弹出
                  ,btn: ['确认', '取消']
                  ,btnAlign: 'c'
                  ,moveType: 1 //拖拽模式，0或者1
                  ,content: $(".reset_pwd1").show()
                  ,yes: function(index){
                    var oldpassword=$("#user_resetArea2").val();
                    var newpassword1=$("#user_resetArea3").val();
                    var newpassword2=$("#user_resetArea4").val();
                    user_resetywb(areaname_area,fenbuname_area,ywbname_area,username_area,oldpassword,newpassword1,newpassword2)
                    layer.close(index);
                    //刷新
                    location.reload();
                  },btn2:function(){
                    $(".reset_pwd1").hide();
                    //刷新
                    location.reload();
                  }
            });
          },
          

      };
      $('#gqUser_ul').on('click',".area_event", function(){
              var type = $(this).data('event');
              var id_area=$(this).attr("data-id"); //id
              var username_area=$(this).attr("data-username"); //用户名
              var areaname_area=$(this).attr("data-areaname"); // 工区
              var fenbuname_area=$(this).attr("data-fenbuname"); //分部
              var ywbname_area=$(this).attr("data-ywbname"); //分部
              
              active_area[type] ? active_area[type].call(this,id_area,username_area,areaname_area,fenbuname_area,ywbname_area) : '';  //传参
      });
      // 修改工区确定
      $(".user_tanchuWorkArea .btn0").click(function(){
          var areaname=$("#user_editArea1").val();
          var fenbuname='';
          var ywbname='';
          var username=$("#user_editArea2").val();
		  var oldusername=$("#user_editArea22").val();
          var password=$("#user_editArea3").val();
          var usertype=$("#user_editArea4").val();
          var city=$("#user_editArea5").val();
          var manager=$("#user_editArea6").val();
          var phone=$("#user_editArea7").val();
          if(usertype=="工区用户"){
            var usertypeval=0;
          }
          user_geteditAll(areaname,fenbuname,ywbname,username,oldusername,password,usertypeval,city,manager,phone,oldusernameArea);
          location.reload();
          $(".user_tanchuWorkArea").css("display","none");
      })
      // 修改工区取消
      $(".user_tanchuWorkArea .btn1").click(function(){
          $(".user_tanchuWorkArea").css("display","none");
      });
      //添加工区
      $(".add_btn1").on('click',function(){
            $(".user_tanchuaddWorkArea").show();
            sel_areaname(userid);
      });
      // 确定
      $(".user_tanchuaddWorkArea .btn0").click(function(){
            var areaname=$("#user_addArea1").val();
            var fenbuname='';
            var ywbname='';
            var username=$("#user_addArea2").val();
            var password=$("#user_addArea3").val();
            var usertype=$("#user_addArea4").val();
            var city=$("#user_addArea5").val();
            var manager=$("#user_addArea6").val();
            var phone=$("#user_addArea7").val();
            if(usertype=="工区用户"){
              var usertypeval=0;
            }
            user_getaddAll(areaname,fenbuname,ywbname,username,password,usertypeval,city,manager,phone);
            $(".user_tanchuaddWorkArea").css("display","none");
            location.reload();
      });
      // 取消
      $(".user_tanchuaddWorkArea .btn1").click(function(){
        $(".user_tanchuaddWorkArea").css("display","none");
      });
    


      //分部用户  修改、删除、重置、添加 的事件
      var oldusernameFenbu='';
      var active_fenbu = {
        edit: function(id){
          $(".user_tanchueditFenbu").show();
          sel_areaname(userid);
          user_getOneAll(id);
          oldusernameFenbu=$(this).attr("data-areanames"); // 分部
        },
        del: function(id){
                layer.confirm('确认删除', {
                        title: false,
                        closeBtn: 0, //不显示关闭按钮
                        id: 'del2', //设定一个id，防止重复弹出
                        btn: ['确认', '取消'],
                        area: ['478px', '172px'],},
                        function (index) {
                              user_getdel(id)
                              //刷新
                              location.reload();
                              layer.close(index);
                        },function (index) {//cancel回调
                              layer.close(index);
                }); 
        },
        reset_pwd:function(id,username_fenbu,areaname_fenbu,fenbuname_fenbu,ywbname_fenbu){
            $("#user_resetfenbu1").val(username_fenbu);
            layer.open({
                type: 1
                ,title: false //不显示标题栏
                ,closeBtn: false
                ,area: ['523px','468px']
                ,shade: 0.8
                ,id: 'user_resect1' //设定一个id，防止重复弹出
                ,btn: ['确认', '取消']
                ,btnAlign: 'c'
                ,moveType: 1 //拖拽模式，0或者1
                ,content: $(".reset_pwd2").show()
                ,yes: function(index){
                  // var username=fenbuname_fenbu;
                  var oldpassword=$("#user_resetfenbu2").val();
                  var newpassword1=$("#user_resetfenbu3").val();
                  var newpassword2=$("#user_resetfenbu4").val();
                  user_resetywb(areaname_fenbu,fenbuname_fenbu,ywbname_fenbu,username_fenbu,oldpassword,newpassword1,newpassword2);
                  // layer.close(index);
                  //刷新
                  // location.reload();
                },btn2:function(){
                  $(".reset_pwd2").hide();
                  //刷新
                  location.reload();
                }
          });
        },
        

      };
      $('#fenbuUser_ul').on('click',".fenbu_event", function(){
              var type = $(this).data('event');
              var id_fenbu=$(this).attr("data-id"); //id
              var username_fenbu=$(this).attr("data-username"); //用户名
              var areaname_fenbu=$(this).attr("data-areaname"); // 工区
              var fenbuname_fenbu=$(this).attr("data-fenbuname"); //分部
              var ywbname_fenbu=$(this).attr("data-ywbname"); //分部
              active_fenbu[type] ? active_fenbu[type].call(this,id_fenbu,username_fenbu,areaname_fenbu,fenbuname_fenbu,ywbname_fenbu) : '';  //传参
      });
      
      //添加分部
      $(".add_btn2").on('click',function(){
            $(".user_tanchuaddFenbu").show();
            sel_areaname(userid);
            var areaname_add=ua;
            setTimeout(function(){
              $("#user_addFenbu1 option").each(function(){
                      if($(this).val() ==areaname_add){
                              $(this).attr('selected',true)
                      }
              });
          },100);
          
            var areaid=uaid;
            manage_moren(areaid);
      });
      // 确定
      $(".user_tanchuaddFenbu .btn0").click(function(){
            var areaname=$("#user_addFenbu1").val();
            var fenbuname=$("#user_addFenbu2").val();
            var ywbname='';
            var username=$("#user_addFenbu3").val();
            var password=$("#user_addFenbu4").val();
            var usertype=$("#user_addFenbu5").val();
            var city=$("#user_addFenbu6").val();
            var manager=$("#user_addFenbu7").val();
            var phone=$("#user_addFenbu8").val();
            if(usertype=="分部用户"){
              var usertypeval=1;
            }
            user_getaddAll(areaname,fenbuname,ywbname,username,password,usertypeval,city,manager,phone)
            $(".user_tanchuaddFenbu").css("display","none");
            location.reload();

            
      });
      // 取消
      $(".user_tanchuaddFenbu .btn1").click(function(){
        $(".user_tanchuaddFenbu").css("display","none");
      });

      // 修改分部确定
      $(".user_tanchueditFenbu .btn0").click(function(){
        var areaname=$("#user_editFenbu1").val();
        var fenbuname=$("#user_editFenbu2").val();
        var ywbname='';
        var username=$("#user_editFenbu3").val();
		var oldusername=$("#user_editFenbu32").val();
        var password=$("#user_editFenbu4").val();
        var usertype=$("#user_editFenbu5").val();
        var city=$("#user_editFenbu6").val();
        var manager=$("#user_editFenbu7").val();
        var phone=$("#user_editFenbu8").val();
        if(usertype=="分部用户"){
          var usertypeval=1;
        }
        user_geteditAll(areaname,fenbuname,ywbname,username,oldusername,password,usertypeval,city,manager,phone,oldusernameFenbu);
        $(".user_tanchueditFenbu").css("display","none");
        location.reload();
      })
      // 修改分部取消
      $(".user_tanchueditFenbu .btn1").click(function(){
          $(".user_tanchueditFenbu").css("display","none");
      });







      //运维班  修改、删除、重置、添加 的事件
        var oldusernameYwb='';
        var active_ywb = {
              edit: function(id){
                $(".user_tanchueditYwb").show();
                sel_areaname(userid);
                user_getOneAll(id);
                oldusernameYwb=$(this).attr("data-areanames"); // 工区
              },
              del: function(id){
                      layer.confirm('确认删除', {
                              title: false,
                              closeBtn: 0, //不显示关闭按钮
                              id: 'del3', //设定一个id，防止重复弹出
                              btn: ['确认', '取消'],
                              area: ['478px', '172px'],},
                              function (index) {
                                  user_getdel(id)
                                  //刷新
                                  location.reload();
                                  layer.close(index);
                              },function (index) {//cancel回调
                                      layer.close(index);
                      }); 
              },
              reset_pwd:function(id,username_ywb,areaname_ywb,fenbuname_ywb,ywbname_ywb){
                $("#user_resetywb1").val(username_ywb);
                  layer.open({
                      type: 1
                      ,title: false //不显示标题栏
                      ,closeBtn: false
                      ,area: ['523px','468px']
                      ,shade: 0.8
                      ,id: 'user_resect3' //设定一个id，防止重复弹出
                      ,btn: ['确认', '取消']
                      ,btnAlign: 'c'
                      ,moveType: 1 //拖拽模式，0或者1
                      ,content: $(".reset_pwd3").show()
                      ,yes: function(index){
                        var oldpassword=$("#user_resetywb2").val();
                        var newpassword1=$("#user_resetywb3").val();
                        var newpassword2=$("#user_resetywb4").val();
                        user_resetywb(areaname_ywb,fenbuname_ywb,ywbname_ywb,username_ywb,oldpassword,newpassword1,newpassword2)
                        layer.close(index);
                        //刷新
                        location.reload();
                      },btn2:function(){
                        $(".reset_pwd3").hide();
                        //刷新
                        location.reload();
                      }
                });
              },
            
    
        };
        $('#ywbUser_ul').on('click',".ywb_event", function(){
                var type = $(this).data('event');
                var id_ywb=$(this).attr("data-id"); //运维班id
                var username_ywb=$(this).attr("data-username"); //用户名
                var areaname_ywb=$(this).attr("data-areaname"); // 工区
                var fenbuname_ywb=$(this).attr("data-fenbuname"); //分部
                var ywbname_ywb=$(this).attr("data-ywbname"); //运维班
                active_ywb[type] ? active_ywb[type].call(this,id_ywb,username_ywb,areaname_ywb,fenbuname_ywb,ywbname_ywb) : '';  //传参
        });


      //添加运维班用户
      $(".add_btn3").on('click',function(){
          $(".user_tanchuaddYwb").show();
          sel_areaname(userid);
          var areaname_add=ua;
          var fenbuname_add=ub;
          setTimeout(function(){
            $("#user_addYwb1 option").each(function(){
                    if($(this).val() ==areaname_add){
                            $(this).attr('selected',true)
                    }
            });
          },100);
          $("#user_addYwb2 option").each(function(){
              if($(this).val() ==fenbuname_add){
                      $(this).attr('selected',true)
              }
          });
            var areaid=uaid;
            manage_moren(areaid);
      });
      // 确定
      $(".user_tanchuaddYwb .btn0").click(function(){
            var areaname=$("#user_addYwb1").val();
            var fenbuname=$("#user_addYwb2").val();
            var ywbname=$("#user_addYwb3").val();
            var username=$("#user_addYwb4").val();
            var password=$("#user_addYwb5").val();
            var usertype=$("#user_addYwb6").val();
            if(usertype=="运维班用户"){
              var usertypeval=2;
            }
            var city=$("#user_addYwb7").val();
            var manager=$("#user_addYwb8").val();
            var phone=$("#user_addYwb9").val();
            user_getaddAll(areaname,fenbuname,ywbname,username,password,usertypeval,city,manager,phone)
            $(".user_tanchuaddYwb").css("display","none");
            location.reload();

            
      });
      // 取消
      $(".user_tanchuaddYwb .btn1").click(function(){
        $(".user_tanchuaddYwb").css("display","none");
      });
        
      // 修改运维班确定
      $(".user_tanchueditYwb .btn0").click(function(){
        var areaname=$("#user_editYwb1").val();
        var fenbuname=$("#user_editYwb2").val();
        var ywbname=$("#user_editYwb3").val();
        var username=$("#user_editYwb4").val();
		var oldusername=$("#user_editYwb42").val();
        var password=$("#user_editYwb5").val();
        var usertype=$("#user_editYwb6").val();
        var city=$("#user_editYwb7").val();
        var manager=$("#user_editYwb8").val();
        var phone=$("#user_editYwb9").val();
        if(usertype=="运维班用户"){
          var usertypeval=2;
        }
        user_geteditAll(areaname,fenbuname,ywbname,username,oldusername,password,usertypeval,city,manager,phone,oldusernameYwb);
        location.reload();
        $(".user_tanchueditYwb").css("display","none");
      })
      // 修改运维班取消
      $(".user_tanchueditYwb .btn1").click(function(){
          $(".user_tanchueditYwb").css("display","none");
      }); 
        
    });


      
   
});




// 默认选中 监控器
function manage_moren(areaid){
  layui.use(['layer','form'], function(){
        var layer = layui.layer;
        var form = layui.form;
        // 工区
        $.ajax({
                type: 'GET',
                url: baseUrl + 'UserServices/User_Services.asmx/a_getAllarea',
                dataType:'JSON', 
                data: {
                        userid:userid 
                },
                success: function (data) {
                        if(data.length>=0){
                                var optionStr ='<option lable="">请选择</option>';
                                for(var i=0;i<data.length;i++){
                                        optionStr+="<option class='selectYouzhi' ";
                                        if(data[i].areaname==ua){
                                                optionStr+="selected";
                                        }
                                        optionStr+=" data-areaid='"+data[i].areaid+"' value='"+data[i].areaname+"'>"+data[i].areaname+"</option>";
                                }
                                // 用户管理
                                //分部
                                $("#user_addFenbu1").html(optionStr); //添加
                                //运维班
                                $("#user_addYwb1").html(optionStr); //添加
                                
                        } 
                }
                
        });
        if(areaid==''||areaid==null){
                return;
        }
        // 分部
        $.ajax({
                type: 'GET',
                url: baseUrl + 'UserServices/User_Services.asmx/b_getfenbuByarea',
                dataType:'JSON', 
                data: {
                        areaid:areaid
                },
                success: function (data) {
                        if(data.length>=0){
                                var optionStr ='<option lable="">请选择</option>';
                                for(var i=0;i<data.length;i++){
                                        optionStr+="<option class='selectYouzhi' ";
                                        if(data[i].fenbuname==ub){
                                                optionStr+="selected";
                                        }
                                        optionStr+=" data-fenbuid='"+data[i].fenbuid+"' value='"+data[i].fenbuname+"'>"+data[i].fenbuname+"</option>";
                                }
                                // 用户管理
                                //运维班
                                $("#user_addYwb2").html(optionStr); //添加
                        }
                }
        }); 
  });
}
// 添加 type=0,1,2,3,4,5,6 0表示工区id，1表示分部id
function user_sel(id,type){
    $.ajax({
      type: 'GET',
      url: baseUrl + 'UserServices/User_Services.asmx/XXX_getXiedaiParam',
      dataType:'JSON', 
      data: {
        id:id,
        type:type
      },
      success: function (data) {
              ua=data[0].areaname;
              ub=data[0].fenbuname;
              uaid=data[0].areaid;
              ubid=data[0].fenbuid;
      }
      
  });
};

