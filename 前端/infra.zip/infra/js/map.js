
        var ywbname='';
        
            
        var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
        var datas = $.parseJSON(Arr);
        userid=datas.Userid;
        stationmap(userid);
        var stationidNowOne='';
        var map = new AMap.Map('container', {
            // center: [113.660949, 34.737946], //中心,
            resizeEnable: true,
            zoom: 11,
        });


        var markerList =[];
        var l; var b;
        var content0='',content1='',content2='',content3='',path=[],pathItem=[];
        
        
        function stationmap(userid){
            $(".loding_bg").show();
            $.ajax({
                type:'get',
                url:baseUrl+'UserServices/User_Services.asmx/e_getstationByUserid',
                dataType:'JSON',
                data:{
                    userid:userid
                },
                success:function(data){
                            $(".loding_bg").hide();
                            for(let item of data){
                                l = item.jingdu;
                                b= item.weidu; 
                                if(l!=''||b!=''){
                                    path.push([JSON.parse(l),JSON.parse(b)]);
                                }
                                var pathItem=[];
                                for(var i=0;i<path.length;i++){
                                    pathItem.push(path[i]);
                                }
                                var polyline=new AMap.Polyline({
                                    map: map,
                                    path:pathItem,     
                                    strokeColor:"#fff",
                                    strokeOpacity:0,
                                    strokeWeight:0,
                                })
                                // 计算区域面积
                                // 创建点
                                var marker = new AMap.Marker({
                                    map: map,
                                    position: [113.660949, 34.737946], //中心,
                                });
                            
                                map.setFitView();
                                

                                if(l!=''||b!=''){
                                    // TODO 用content 可替换默认的点标记图标，
                                    if(item.topvalue >= 80 && item.topvalue < 100){
                                        var content1=`<div class="map_list  map_listUp_big80" data-stationid="${item.stationid}" data-alarmcount="${item.alarmcount}" data-stationname="${item.stationshortname1}">`;
                                            if(item.alarmcount==0){

                                            }else{
                                                content1+=`<p class="layui-badge">${item.alarmcount}</p>`;
                                            }
                                            content1+=`<div class="marker-route1 marker-marker-bus-from fl">`
                                            if(item.stationshortname1==null||item.stationshortname1==undefined||item.stationshortname1==''){
                                                content1+=`<span class="bdz_name">${item.stationname}</span>`
                                            }else{
                                                content1+=`<span class="bdz_name">${item.stationshortname1}</span>`
                                            } 
                                            content1+=`</div><div class="marker-route2 marker-route2Now marker-marker-bus-from fl">
                                                <p class="textTips fl">当前<br />最高</p>
                                                <p class="temp fr">${item.topvalue}<span>°C</span></p>
                                            </div>
                                            <div class="marker-route2 marker-route3Today marker-marker-bus-from fr">
                                                <p class="textTips fl">今日<br />最高</p>
                                                <p class="temp fr">${item.todaytop}<span>°C</span></p>
                                            </div>
                                        </div>`; 
                                        var marker = new AMap.Marker({ position: new AMap.LngLat(l,b),  // TODO 经纬度对象
                                            title: '郑州' ,content:content1
                                        }); 
                                        //添加绑定事件
                                        // TODO 将创建的点标记添加到点标记集合：
                                        markerList.push(marker);
                                        map.add(markerList);
                                    }
                                    if(item.topvalue>=100){
                                        var content2=`<div class="map_list  map_list100_big" data-stationid="${item.stationid}" data-alarmcount="${item.alarmcount}" data-stationname="${item.stationshortname1}">`;
                                        if(item.alarmcount==0){

                                        }else{
                                            content2+=`<p class="layui-badge">${item.alarmcount}</p>`;
                                        }
                                        content2+=`<div class="marker-route1 marker-marker-bus-from fl">`
                                        if(item.stationshortname1==null||item.stationshortname1==undefined||item.stationshortname1==''){
                                            content2+=`<span class="bdz_name">${item.stationname}</span>`
                                        }else{
                                            content2+=`<span class="bdz_name">${item.stationshortname1}</span>`
                                        } 
                                        content2+=`</div><div class="marker-route2 marker-route2Now marker-marker-bus-from fl">
                                                <p class="textTips fl">当前<br />最高</p>
                                                <p class="temp fr">${item.topvalue}<span>°C</span></p>
                                            </div>
                                            <div class="marker-route2 marker-route3Today marker-marker-bus-from fr">
                                                <p class="textTips fl">今日<br />最高</p>
                                                <p class="temp fr">${item.todaytop}<span>°C</span></p>
                                            </div>
                                        </div>`;
                                        var marker = new AMap.Marker({ position: new AMap.LngLat(l,b),
                                            title: '郑州' ,content:content2
                                        }); 
                                        
                                        markerList.push(marker);
                                        map.add(markerList);
                                    
                                    }
                                    if(item.topvalue<80){
                                        var content3=`<div class="map_list  map_listDown_big80" data-stationid="${item.stationid}" data-alarmcount="${item.alarmcount}" data-stationname="${item.stationshortname1}"> `;
                                        if(item.alarmcount==0){

                                        }else{
                                            content3+=`<p class="layui-badge">${item.alarmcount}</p>`;
                                        }
                                        content3+=`<div class="marker-route1 marker-marker-bus-from fl">`
                                        if(item.stationshortname1==null||item.stationshortname1==undefined||item.stationshortname1==''){
                                            content3+=`<span class="bdz_name">${item.stationname}</span>`
                                        }else{
                                            content3+=`<span class="bdz_name">${item.stationshortname1}</span>`
                                        } 
                                        content3+=`</div><div class="marker-route2 marker-route2Now marker-marker-bus-from fl">
                                                <p class="textTips fl">当前<br />最高</p>
                                                <p class="temp fr">${item.topvalue}<span>°C</span></p>
                                            </div>
                                            <div class="marker-route2 marker-route3Today marker-marker-bus-from fr">
                                                <p class="textTips fl">今日<br />最高</p>
                                                <p class="temp fr">${item.todaytop}<span>°C</span></p>
                                            </div>
                                        </div>`;
                                        var marker = new AMap.Marker({ position: new AMap.LngLat(l,b),
                                            title: '郑州' ,content:content3
                                        }); 
                                        
                                        markerList.push(marker);
                                        map.add(markerList);
                                    }
                                }
                        }
                       
                },
                error:function(err){
                        console.log(err)
                }
    
            });
        }
        

        // 点击某一个边框变大
        // $('.contaion').on('click', ".amap-marker",function () {
        //     $(this).find(".map_listUp80").addClass('map_listUp_big80').removeClass('map_listUp80');
        //     $(this).siblings().find(".map_listUp_big80").removeClass('map_listUp_big80').addClass('map_listUp80');
        //     $(this).css("z-index",999);
        //     $(this).siblings().css("z-index",100);
        // });
        // 地图右侧弹出框
        $(".contaion").on("click",".map_list",function(){
            $(".mapList_Popup").show();
            var stationid =$(this).attr("data-stationid");
            stationidNowOne =$(this).attr("data-stationid");
            var alarmcount =$(this).attr("data-alarmcount");
            var stationname=$(this).attr("data-stationname");
            index_mediaTop_right(userid,stationid); //实时检测设备列表
            layui.use(['carousel', 'form'], function(){
                var carousel = layui.carousel;
                $.ajax({
                    type:'get',
                    url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/l_getAlarmStation',
                    dataType:'JSON',  
                    data:{
                        stationid:stationid
                    },
                    success:function(res){
                        var html=``;
                        //当前全站最高
                        var dataNow=res.DeviceToplist;
                        // 今日全站最高
                        var data=res.Devicelist;
                        if(dataNow.length>0||data.length>0){
                            if(dataNow.length>0){
                                html+=`<div class="close mapdiv1_ri"></div><div class="contentPop"><div class="Ul_img"><h2>`+dataNow[0].stationname+`</h2><ul>`;
                            }else if(data.length>0){
                                html+=`<div class="close mapdiv1_ri"></div><div class="contentPop"><div class="Ul_img"><h2>`+data[0].stationname+`</h2><ul>`;
                            }else{
                                html+=``;
                            }
                            
                            if(dataNow.length>0){
                                for(var i=0;i<dataNow.length;i++){
                                    var Times;
                                    var time=dataNow[i].createtime; ///Date(158 572 227 7000)/
                                    if(time==''||time==null){
                                        Times=''
                                    }else{
                                        Times=dataNow[i].createtime;
                                    }
                                    var machinename=dataNow[i].machinename;
                                    if(!machinename){
                                            machinename='';
                                    }
                                    var pics=[dataNow[i].imageurl1,dataNow[i].imageurl2,dataNow[i].imageurl3];
                                    
                                    html+='<li><div class="mapdiv2"><div class="swiper_bg"><div class="layui-carousel" id="swiper1"><div carousel-item>'
                                        for(var j=0;j<pics.length;j++){
                                            html+='<div><img width="290px" height="210px" src="'
                                            +pics[j]+'" alt=""></div>';
                                        } 
                                        html+='</div></div></div><div class="mapdiv3"><div class="tem fl">';

                                        var tem=dataNow[i].value;
                                            if(tem>=100){
                                                html+=`<p class="over100 wendu fl">${tem}<span>℃</span></p>`;
                                            }
                                            if(tem >= 80 && tem < 100){
                                                html+=`<p class="over80 wendu fl">${tem}<span>℃</span></p>`;
                                            }
                                            if(tem<80){
                                                html+=`<p class="up80 wendu fl">${tem}<span>℃</span></p>`;
                                            };

                                        html+='<p>'+dataNow[i].note+
                                        '</p></div><div class="stName fr"><p><span>'
                                            +dataNow[i].devicename+
                                            '</span></p><p class="time">(<span>'
                                            +machinename+
                                            ''+dataNow[i].machinecode+
                                            '</span>) <span>'
                                            +Times+
                                            '</span></p></div></div></div></li>';
            
                                };
                            }
                            if(data.length>0){
                                for(var i=0;i<data.length;i++){
                                    var Times;
                                    var time=data[i].createtime; ///Date(158 572 227 7000)/
                                    if(time==''||time==null){
                                        Times=''
                                    }else{
                                        Times=data[i].createtime;
                                    }
                                    var machinename=data[i].machinename;
                                    if(!machinename){
                                            machinename='';
                                    }
                                    var pics=[data[i].imageurl1,data[i].imageurl2,data[i].imageurl3];
                                    
                                    html+='<li><div class="mapdiv2"><div class="swiper_bg"><div class="layui-carousel" id="swiper2"><div carousel-item>'
                                        for(var j=0;j<pics.length;j++){
                                            html+='<div><img width="290px" height="210px" src="'
                                            +pics[j]+'" alt=""></div>';
                                        } 
                                        html+='</div></div></div><div class="mapdiv3"><div class="tem fl">';

                                        var tem=data[i].value;
                                            if(tem>=100){
                                                html+=`<p class="over100 wendu fl">${tem}<span>℃</span></p>`;
                                            }
                                            if(tem >= 80 && tem < 100){
                                                html+=`<p class="over80 wendu fl">${tem}<span>℃</span></p>`;
                                            }
                                            if(tem<80){
                                                html+=`<p class="up80 wendu fl">${tem}<span>℃</span></p>`;
                                            };

                                        html+='<p>'+data[i].note+
                                        '</p></div><div class="stName fr"><p><span>'
                                            +data[i].devicename+
                                            '</span></p><p class="time">(<span>'
                                            +machinename+
                                            ''+data[i].machinecode+
                                            '</span>) <span>'
                                            +Times+
                                            '</span></p></div></div></div></li>';
            
                                };
                            }
                            html+=`</ul></div><div class="mapdivbot2">
                                <div id="see_device" class="mapdivbot2_le mapdivbot2D fl" data-stationid=`+stationid+`><img src="./images/map/creamIcon.png" alt=""> <span>查看所有设备</span> </div>
                                <div id="see_alarlm" class="mapdivbot2_ri mapdivbot2D fr" data-stationid=`+stationid+`><img src="./images/map/alarmIcon.png" alt=""><span>查看告警`;
                            if(alarmcount>0){
                                html+=`<i class="layui-badge">`+alarmcount+`</i>`;
                            }
                            html+=`</span> </div>
                            </div></div>`;
                        }
                            
                        $("#mapListPopup").html(html);
                        //改变下时间间隔、动画类型、高度
                        for(var i=0;i<dataNow.length;i++){
                            var ins = carousel.render({
                                elem: '#swiper1'
                                ,interval: 2000
                                ,arrow: 'always'
                                ,width:'340px'
                                ,height:'307px'
                                ,arrow: 'always' //始终显示箭头
                            });
                            ins.reload({elem: '#swiper1'});//重置轮播图
                        }
                        //改变下时间间隔、动画类型、高度
                        for(var i=0;i<data.length;i++){
                            var ins = carousel.render({
                                elem: '#swiper2'
                                ,interval: 2000
                                ,arrow: 'always'
                                ,width:'340px'
                                ,height:'307px'
                                ,arrow: 'always' //始终显示箭头
                            });
                            ins.reload({elem: '#swiper2'});//重置轮播图
                        }
                        
                    },
                    error:function(err){
                            console.log(err)
                    }
        
                });
            });
        });
        // 点击 地图弹出框关闭
        $("#mapListPopup").on("click",'.mapdiv1_ri',function(){
            $(".mapList_Popup").hide();
        });

        $(".contaion").on("click","#see_device",function(){
            var stationid=$(this).attr("data-stationid");
            layui.use(['table','layer',"form"], function(){
                var url="tem_ment.html?stationid="+stationid;
                Util.popFullScreen3(100,100,url);
            });
            
        });
        $(".contaion").on("click","#see_alarlm",function(){
            var stationid=$(this).attr("data-stationid");
			console.log(stationid);
            layui.use(['table','layer',"form"], function(){
                var url="alarm_info.html?stationid="+stationid;
                Util.popFullScreen3(100,100,url);
            });
        });
        // 实时监测设备趋势 跳转测温查看
        $(".nowInfoSee").on('click',function(){
            var url="tem_ment.html?stationid="+stationidNowOne;
            Util.popFullScreen3(100,100,url);
        });
        
