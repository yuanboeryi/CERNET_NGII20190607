
var _that='',_thatNo='',deviceidAbnormal='',machineid='',deviceidNormal='';
var xsSelAb=0; //异常
var xsSelNo=0; //正常
var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
var datas = $.parseJSON(Arr);
var userid=datas.Userid;
var deviceid='',devicename='';//设备id 设备名字
var deviceidHisImg='';//判断是否是下一个
var errorClose = 0;	//是否错误关闭巡视页面，0为正常关闭，1为错误关闭
layui.use(['layer','jquery','table'], function() {
    var layer = layui.layer;
    var $ = layui.$;
    var table = layui.table;
    abnormalType();
	
	//关闭当前的巡视页面
	$(".close_btn").on('click',function(){
		if(errorClose == 1){
			var index = layer.confirm('您还没有点击结束巡视，是否继续巡视？', {
				title:false,
				closeBtn: 0,
				btn: ['继续','结束'] //按钮
			}, function(){
				layer.close(index);
			}, function(){
				layer.close(index);
				 $(".patrolEnd").show();
				 errorClose = 2;
			});
		}else{
			var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
			parent.layer.close(index); //再执行关闭
		}
	});
	
    // 录入正常
    $("#xunShiContentImgs").on("click","#deviceidLi .botBtnItem1",function(){
        _thatNo=this;
        $(_thatNo).find(".normal").show()
        $(_thatNo).find(".botBtnItemNormal1").hide();
        if(xsSelAb==1){
            //异常
            $(_that).find(".abnormal").hide()
            $(_that).find(".botBtnItemAbnormal1").show();
        }
        xsSelNo=1;
        deviceidNormal=$(_thatNo).attr("data-deviceid")
        normalEntry(deviceidNormal);
    });

   // 点击录入异常
   $("#xunShiContentImgs").on("click","#deviceidLi .botBtnItem2",function(){
       _that=this;
       $(".abnormalEntry").show();
       if(xsSelNo==1){
           //正常
           $(_thatNo).find(".normal").hide()
           $(_thatNo).find(".botBtnItemNormal1").show();
       }
       var deviceidAbnormal=$(_that).attr("data-deviceid");
		abnormalDescription();
   	
		areaid = $(this).attr("areaid");
		fenbuid = $(this).attr("fenbuid");
		ywbid = $(this).attr("ywbid");
		stationid = $(this).attr("stationid");
		machineid = $(this).attr("machineid");
		deviceid = $(this).attr("data-deviceid");
		devicename = $(this).attr("deviceName");
		input_abnormalImg(userid,areaid,fenbuid,ywbid,stationid,machineid,deviceid);
   });
	//录入异常点击选中
	$("#abnormalEntry2").on("click","span",function(){
		$(this).toggleClass("abnormalEntry2").siblings().removeClass("abnormalEntry2");
	})
   // 录入异常确定
   $(".abnormalEntry .btn0").click(function(){
       var typeid=$("#abnormalEntry2 .abnormalEntry2").attr("data-description");
       if(typeid==undefined){
           layer.msg("请选择");
           return;
       }
		$("#abnormalImg").html('');
		var machineid = $("#xunShiContentImgs .bottom_btn1").attr("data-machineid");
		abnormalEntry(deviceid,typeid,machineid);
	   
	   errorClose = 1;	//错误关闭
   });
	// 录入异常取消
	$(".abnormalEntry .btn1").click(function(){
	    if(xsSelAb!=1){
	        $(_that).find(".abnormal").hide()
	        $(_that).find(".botBtnItemAbnormal1").show();
	    }
	    if(xsSelNo==1){
	        $(_thatNo).find(".normal").show()
	        $(_thatNo).find(".botBtnItemNormal1").hide();
	    }
	    $(".abnormalEntry").css("display","none");
		var deleteOrShow = 0;
		echo_abnormalImg(deleteOrShow);
	});
	//点击录入异常里的 录入异常图片 按钮
	$("#abnormalImg_btn").click(function(){
		var typeid=$("#abnormalEntry2 .abnormalEntry2").attr("data-description");
		if(typeid==undefined){
		    layer.msg("请选择异常描述！");
		    return;
		}
		$("#input_abnormalImg").show();
	})
	//点击录入异常图片按钮 点击图片是否选中
	$('#input_abnormalImg').on("click",'ul',function(){
		$(this).find(".selImg").toggle();
		$(this).find(".noselImg").toggle();
	})
	//点击录入异常图片里的 确定按钮
	$("#input_abnormalImg").on("click",".btns .btn0",function(){
	
		var recordid = '';
		var length = $("#input_abnormalImg_concent ul").length;
		for(var i=0;i<length;i++){
			var a = $("#input_abnormalImg_concent ul:eq("+i+")").find(".noselImg").css('display');
			if(a == 'none'){
				var id = $("#input_abnormalImg_concent ul:eq("+i+")").attr("recordid");
				recordid+=id+",";
			}
		}
		//选中后点击确认
		$.ajax({
			type:'post',
			url:baseUrl+"UserServices/User_Services.asmx/save_ImageDeviceException",
			dataType:"JSON",
			data:{
				userid:userid,
				recordid:recordid,
				deviceid:deviceid,
				devicename:devicename
			},
			success:function(data){
				layer.msg(data.msg,{
				    offset: '15px'
				    ,icon: 1
				    ,time: 500
				});
				//录入的图片回显  1代表回显
				var deleteOrShow = 1;
				echo_abnormalImg(deleteOrShow);
				$("#input_abnormalImg").hide();
				$("#input_abnormalImg_concent").find(".selImg").hide();
				$("#input_abnormalImg_concent").find(".noselImg").show();
			},
			error:function(err){
				console.log(err);
			}
		})
	})
	//点击录入异常图片的里的 取消按钮
	$("#input_abnormalImg").on("click",".edit .btns .btn1",function(){
		$("#input_abnormalImg").hide();
		$("#input_abnormalImg_concent").find(".selImg").hide();
		$("#input_abnormalImg_concent").find(".noselImg").show();
	})
	// 设备下线
	$("#xunShiContentImgs").on('click','.device_offline',function(){
		 var machineid=$(this).attr("data-machineid");
		 // isopen=0,表示下线，isopen=1上线
		 var isopen = 0;
		device_offline(machineid,isopen);
	})
	
    //点击底部 全部正常
    $("#xunShiContentImgs").on("click",".bottom_btn2",function(){
        machineid=$(this).parent().attr("data-machineid");
        allNormal(machineid);
        
    });
    //点击底部 结束巡视
    $("#xunShiContentImgs").on("click",".bottom_btn3",function(){
        $(".patrolEnd").show();
    });
    // 结束巡视确定
    $(".patrolEnd .btn0").click(function(){
        var patrolEnd1=$("#patrolEnd").val();
        saveDevicePatorl(patrolEnd1);
        $(".patrolEnd").css("display","none");
		if(errorClose == 2){	//errorClose为2时，是点击关闭跳转到的结束巡视页面，确认后直接关闭开始巡视页面
			var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
			parent.layer.close(index); //再执行关闭
		}
		errorClose = 0;	//错误关闭，0为正常关闭
    });
    // 结束巡视取消
    $(".patrolEnd .btn1").click(function(){
        $(".patrolEnd").css("display","none");
		errorClose = 1;	
    });

    //点击有异常的机器查看异常
    $("#errorSee").on('click',function(){
        Util.popFullScreen3(100,100,"seeAbnormal.html");
    });
    // 巡视记录
    $("#tourRecord").on('click',function(){
        Util.popFullScreen3(100,100,"tourRecord.html");
    });

    // 修改异常类型
    $("#errorType").on('click',function(){
        $(".editAbnormal").show();
    });
    // 修改异常类型确定
    $(".editAbnormal .btn0").click(function(){
        var abnormal1=$("#abnormal1").val(); //异常类型名称
        var abnormal2=$("#abnormal2").val(); //异常描述id
        var abnormal3=$("#abnormal3").val(); //异常描述
        if(abnormal1==''||abnormal1=="请选择"){
            layer.msg("请选择");
            return false;
        }
        abnormalTypeEdit(abnormal1,abnormal2,abnormal3);
        $(".editAbnormal").css("display","none");
    });
    // 修改异常类型取消
    $(".editAbnormal .btn1").click(function(){
        $(".editAbnormal").css("display","none");
    });
	//点击右侧24小时历史图像的 删除 按钮
	$('#item-del1').click(function(){
		$('#hoursHisImgs li .popWindow').attr('style','display: block');
		$('.popWindow .noselImg').show();
		$('.popWindow .selImg').hide();
	})
	//点击右侧24小时历史图像的 完成 按钮 并删除选中内容
	$('#item-del2').click(function(){
		itemDel();
		$('#hoursHisImgs .popWindow').attr('style','display: none');
	})
	//点击右侧24小时历史图像的删除按钮后 再点击图片是否选中
	$('#hoursHisImgs').on("click",'ul',function(){
		$(this).find(".selImg").toggle();
		$(this).find(".noselImg").toggle();
	})
    // 上一个设备
    $("#xunShiContentImgs").on("click",".bottom_btn0",function(){
        var indexnumber=$(this).attr("data-indexnumber");
        var lastDevice=$(this).attr("data-lastDevice");
        var lastDeviceTip=0;
        //lastDevice==1 最后一个，提示最后一个;indexnumber下标
        if(lastDevice==1){
            if(indexnumber==0){
                nextdevice=parseInt(nextdevice);
                lastDeviceTip=1;
            }else{
                nextdevice=parseInt(nextdevice)-1;
            }
            
        }else{
            if(indexnumber==0){
                nextdevice=parseInt(nextdevice);
                lastDeviceTip=1;
            }else{
                nextdevice=parseInt(nextdevice)-1;
            }
        }
        // 开始巡视
        realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);
    });
    
    // 下一个设备
    $("#xunShiContentImgs").on("click",".bottom_btn1",function(){
    	var nextdevice = $(this).attr("data-nextdevice");
        var lastDevice=$(this).attr("data-lastDevice");
		//lastDevice==1 最后一个，提示最后一个;nextdevice下标
		
		machineid = '';
    	stationid = $(this).attr('stationid');//变电站id
        if(lastDevice==1){
            nextdevice=0;
				
			stationid = $(this).attr('nextstationid');
			// 开始巡视
			top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
			realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);
			
        }else{
            nextdevice=parseInt(nextdevice)+1;
			// 开始巡视
			realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);
        }
		
    		
		
    });
    
    //异常操作
    table.on('tool(testSeeAbnormal)', function(obj){
        if(obj.event === 'del'){	//删除
            var id=obj.data.id;
            layer.confirm('确认删除', {
                  title: false,
                  closeBtn: 0, //不显示关闭按钮
                  btn: ['确认', '取消'],
                  area: ['478px', '172px'],
            },function(index){
                  $.ajax({
                        type:'POST',
                        url:baseUrl+'UserServices/User_Services.asmx/deleteDeviceException',
                        dataType:'JSON',
                        data:{id:id},
                        success:function(data){
                            layer.msg(data.msg,{
                                offset: '15px'
                                ,time: 500
                                ,type:1
                            });
                          layer.close(index);
                          table.reload('testSeeAbnormal');
                        },
                        error:function(err){
                            console.log(err)
                        }
        
                  });
          },function (index) {//cancel回调
              layer.close(index);
          });
        }if(obj.event === 'mod'){	//添加修改
			var maintainId = obj.data.maintainId;
			var deviceExceptionId = obj.data.id;
			maintain_operate(maintainId,deviceExceptionId);
			
		}
    });

    //巡视记录 查看、删除
    table.on('tool(tourRecordTable)', function(obj){
        if(obj.event === 'edit'){
            var areaid=obj.data.areaid;
            var fenbuid=obj.data.fenbuid;
            var ywbid=obj.data.ywbid;
            var stationid=obj.data.stationid;
            var urls="seeAbnormal.html?areaid="+areaid+"&&fenbuid="+fenbuid+"&&ywbid="+ywbid+"&&stationid="+stationid;
            Util.popFullScreen3(100,100,urls);
        }
        if(obj.event === 'del'){
            var id=obj.data.patrolid;
            layer.confirm('确认删除', {
                  title: false,
                  closeBtn: 0, //不显示关闭按钮
                  btn: ['确认', '取消'],
                  area: ['478px', '172px'],
            },function(index){
                  $.ajax({
                        type:'POST',
                        url:baseUrl+'UserServices/User_Services.asmx/deleteDevicePatorl',
                        dataType:'JSON',
                        data:{patrolid:id},
                        success:function(data){
                            if(data.falg==true){
                                layer.msg(data.msg,{
                                    offset: '15px'
                                    ,time: 500
                                    ,type:1
                                });
                                table.reload('tourRecordTable');
                            }else{
                                layer.msg(data.msg,{
                                    offset: '15px'
                                    ,time: 500
                                    ,type:2
                                });
                            }
                            layer.close(index);
                        },
                        error:function(err){
                            console.log(err)
                        }
        
                  });
          },function (index) {//cancel回调
              layer.close(index);
          });
        }
    });
    // 异常类型统计
    $.ajax({
        type:'get',
        url:baseUrl+'UserServices/User_Services.asmx/findDeviceExceptionTypeByCount',
        dataType:'JSON',
        data:{
        },
        success:function(data){
            var XdeviceType=[],count=[];
            for(var i=0;i<data.typelist.length;i++){
                XdeviceType.push(data.typelist[i].typename);
                count.push(data.typelist[i].count); 
            }
            seeAbnormalPai1(XdeviceType,count);
        },
        error:function(err){
                console.log(err)
        }

    });
    // 异常状态统计
    $.ajax({
        type:'get',
        url:baseUrl+'UserServices/User_Services.asmx/findDeviceExceptionStatusByCount',
        dataType:'JSON',
        data:{
        },
        success:function(data){
            var repairData=data.typelist;
            seeAbnormalPai2(repairData);
        },
        error:function(err){
                console.log(err)
        }

    });
    
});

// 录入正常
function normalEntry(deviceidNormal){
    $.ajax({
        type:'get',
        url:baseUrl+'UserServices/User_Services.asmx/updateNormal  ',
        dataType:'JSON',
        data:{
            userid:userid,
            deviceid:deviceidNormal,
        },
        success:function(data){
            layui.use(['table','layer'], function(){
                var layer = layui.layer;
                if(data.falg==true){
                    layer.msg(data.msg,{
                        offset: '15px'
                        ,time: 500
                        ,type:1
                    });
                    $(_that).find(".normal").show()
                    $(_that).find(".botBtnItemnormal1").hide();
                    xsSelAb=1;
                    var areaid=$("#tabAll .table_active").attr("data-areaid");
                    var fenbuid=$("#fenbuDDAll .select").attr("data-fenbuid");
                    var ywbid=$("#ywbDDAll .select").attr("data-ywbid");
                    var stationid=$("#bdzDDAll .select").attr("data-stationid");
                    var buildingid=$("#sbqDDAll .select").attr("data-buildingid");
                    var machineid=$("#hwsbDDAll .select").attr("data-machineid");
                    var nextdevice=$("#xunShiContentImgs .bottom_btn1").attr("data-nextdevice");
                    // areaid==''||fenbuid==''||ywbid==''||stationid==''||machineid==''||
                    if(nextdevice==''||nextdevice==null||nextdevice==undefined){
                        nextdevice=0;
                    }
					console.log(nextdevice);
                    // 开始巡视
                    realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);
                }else{
                    layer.msg(data.msg,{
                        offset: '15px'
                        ,time: 500
                        ,type:2
                    });
                }
                
            });
            
        },
        error:function(err){
            alert("网络错误，请联系技术人员")
        }

    });
};
// 异常录入
function abnormalEntry(deviceidAbnormal,typeid,machineid){
    $.ajax({
        type:'get',
        url:baseUrl+'UserServices/User_Services.asmx/saveDeviceException',
        dataType:'JSON',
        data:{
            userid:userid,
            deviceid:deviceidAbnormal,
            typeid:typeid,
        },
        success:function(data){
            layui.use(['table','layer'], function(){
                var layer = layui.layer;
                if(data.falg==true){
                    layer.msg(data.msg,{
                        offset: '15px'
                        ,time: 500
                        ,type:1
                    });
                    $(".abnormalEntry").css("display","none");
                    $(_that).find(".abnormal").show()
                    $(_that).find(".botBtnItemAbnormal1").hide();
                    xsSelAb=1;
                    var areaid=$("#tabAll .table_active").attr("data-areaid");
                    var fenbuid=$("#fenbuDDAll .select").attr("data-fenbuid");
                    var ywbid=$("#ywbDDAll .select").attr("data-ywbid");
                    var stationid=$("#bdzDDAll .select").attr("data-stationid");
                    var buildingid=$("#sbqDDAll .select").attr("data-buildingid");
                    var machineid=$("#hwsbDDAll .select").attr("data-machineid");
                    var nextdevice=$("#xunShiContentImgs .bottom_btn1").attr("data-nextdevice");
                    if(nextdevice==''||nextdevice==null||nextdevice==undefined){
                        nextdevice=0;
                    }
					console.log(nextdevice);
                    // 开始巡视
                    realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);
                }else{
                    layer.msg(data.msg,{
                        offset: '15px'
                        ,time: 500
                        ,type:2
                    });
                }
                
            });
            
        },
        error:function(err){
            alert("网络错误，请联系技术人员")
        }

    });
};


//开始巡视--全部正常
function allNormal(machineid){
    $.ajax({
            type:'get',
            url:baseUrl+'UserServices/User_Services.asmx/updateDevicePatrolStatus',
            dataType:'JSON',
            data:{
                userid:userid,
                machineid:machineid
            },
            success:function(data){
                    layui.use(['table','layer'], function(){
                            var layer = layui.layer;
                            if(data.falg==true){
                                layer.msg(data.msg,{
                                    offset: '15px'
                                    ,time: 500
                                    ,type:1
                                });
                                var areaid=$("#tabAll .table_active").attr("data-areaid");
                                var fenbuid=$("#fenbuDDAll .select").attr("data-fenbuid");
                                var ywbid=$("#ywbDDAll .select").attr("data-ywbid");
                                var stationid=$("#bdzDDAll .select").attr("data-stationid");
                                var buildingid=$("#sbqDDAll .select").attr("data-buildingid");
                                var machineid=$("#hwsbDDAll .select").attr("data-machineid");
                                var nextdevice=$("#hwsbDDAll .select").attr("data-index");
                                // areaid==''||fenbuid==''||ywbid==''||stationid==''||machineid==''||
                                if(nextdevice==''||nextdevice==null||nextdevice==undefined){
                                    nextdevice=0;
                                }
                                // 开始巡视
                                realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);
                            }else{
                                layer.msg(data.msg,{
                                    offset: '15px'
                                    ,time: 500
                                    ,type:2
                                });
                            }
                            
                        });
            },
            error:function(err){
                    console.log(err)
            }

    });
};
// 结束巡视
function saveDevicePatorl(inspector){
	$(".loding_bg").show();
    $.ajax({
        type:'get',
        url:baseUrl+'UserServices/User_Services.asmx/saveDevicePatorl',
        dataType:'JSON',
        data:{
            userid:	userid,
            inspector:inspector
        },
        success:function(data){
            layui.use(['table','layer'], function(){
                var layer = layui.layer;
                if(data.falg==true){
                    layer.msg(data.msg,{
                        offset: '15px'
                        ,time: 500
                        ,type:1
                    });
					var stationid= $(this).attr('stationid');
					var buildingid = $(this).attr('buildingid');
					
					console.log(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);
					console.log(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);
					// 开始巡视
					realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);
					//共用头部
					top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);
					
                }else{
                    layer.msg(data.msg,{
                        offset: '15px'
                        ,time: 500
                        ,type:2
                    });
                }
                
            });
            
        },
        error:function(err){
            alert("网络错误，请联系技术人员")
        }

    });
}

//开始巡视--异常查看--异常类型
function abnormalType(){
    $.ajax({
            type:'get',
            url:baseUrl+'UserServices/User_Services.asmx/findDeviceExceptionType',
            dataType:'JSON',
            data:{

            },
            success:function(data){
                // var spantr ='<span>全部</span>';
                var optionStr ='<option value="">请选择</option>';
                for(var i=0;i<data.length;i++){
                        // spantr+="<span data-typeName='"+data[i].typename+"'>"+data[i].typename+"</span>";
                        optionStr+="<option value='"+data[i].typename+"'>"+data[i].typename+"</option>";
                }
                // $("#typenameDDAll").html(spantr);//异常类型
                $("#abnormalEntry1").html(optionStr);
                $("#abnormal1").html(optionStr);
            },
            error:function(err){
                    console.log(err)
            }

    });
};
//开始巡视-- 异常描述
function abnormalDescription(){
    $.ajax({
            type:'post',
            url:baseUrl+'UserServices/User_Services.asmx/findDeviceExceptionType',
            dataType:'JSON',
            data:{
                    // typename:typename
            },
            success:function(data){
                    var spantr ='';
                    var optionStr ='<option value="">请选择</option>';
                    for(var i=0;i<data.length;i++){
                            spantr+="<span data-description='"+data[i].exceptiontypeid+"'>"+data[i].description+"</span>";
                            optionStr+="<option value='"+data[i].exceptiontypeid+"'>"+data[i].description+"</option>";
                    }
                    $("#descriptionDDAll").html(spantr);//异常描述
                    $("#abnormalEntry2").html(spantr);//异常描述
                    $("#abnormal2").html(optionStr);
           
            },
            error:function(err){
                    console.log(err)
            }

    });
};
// 修改异常类型
function abnormalTypeEdit(typename,typeId,description){
    $.ajax({
        type:'get',
        url:baseUrl+'UserServices/User_Services.asmx/updateDeviceExceptionType',
        dataType:'JSON',
        data:{
            id:	typeId,  //异常描述id
            description:description, //异常描述
            // typename:typename  //异常类型名称
        },
        success:function(data){
            layui.use(['table','layer'], function(){
                var layer = layui.layer;
                if(data.falg){
                    layer.msg(data.msg,{
                        offset: '15px'
                        ,time: 500
                        ,type:1
                    });
                }else{
                    layer.msg(data.msg,{
                        offset: '15px'
                        ,time: 500
                        ,type:2
                    });
                }
                
            });
            
        },
        error:function(err){
            alert("网络错误，请联系技术人员")
        }

    });
}

// 柱图 异常统计类型  
function  seeAbnormalPai1(XdeviceType,count){
    var dom = document.getElementById("seeAbnormalPai1");
    if(!dom){
      return;
    }else{
        var myChart=echarts.init(dom);
        option = {
            tooltip: {
              trigger: 'axis',
              textStyle:{
                color: '#fff'//字体颜色
              },
              formatter(params){
                const item = params[0];
                return `<span style="color:#00ffd2;">温度：${item.value}℃</span><br/>
                        <span style="color:#00ffd2;">${item.name}</span>`;
              }
            },
            grid: {
              top:'22%',
              right: '10%',
              bottom:'25%'
            },
            
            xAxis: [
              {
                type: 'category',
                interval:0,
                axisTick: {
                  show:false
                },
                axisLine: {
                  show: true,
                  lineStyle: {
                    color: 'rgba(255,255,255,.4)'
                  }
                },
                axisLabel: {
                    rotate:20,
                    textStyle: {
                        //这个地方颜色是支持回调函数的这种的，如果是一种颜色则可以写成： color :'#1089E7'  
                        color : "#fff",
                        fontSize:10
                    }
                },
                data: XdeviceType
              }
            ],
            yAxis: [//多y轴时，用数组加对象的方式来实现
              {       
                show:false,          
                type: 'value',
                name: '温度°C',
                interval:1,
                axisTick:{       //y轴刻度线
                  show:false
                },
                axisLine: {
                  show:false,
                },
                
              }
            ],
            series: [
              
              {
                name:'温度',
                type:'bar',
                barWidth: 10,
                smooth:true,
                symbol: 'circle',     //设定为实心点
                symbolSize: 30,   //设定实心点的大小
                data:count,
                lineStyle:{
                  normal:{
                    width:10
                  }
                },
                label: {
                        show: true, //开启显示
                        position: 'top', //在上方显示
                        textStyle: { //数值样式
                              color : "#fff",
                              fontSize: 10,
                        },
                        
                },
                itemStyle: {
                    color : "#00FFD2",
                }        
              }
            ]
        };
        myChart.setOption(option);
  
    }    
  
};

// 饼图  设备状态 未消除,已消除 统计 
function seeAbnormalPai2(dataAll){
    var dom = document.getElementById("seeAbnormalPai2");
    var seriesData=[];
    var dataLegend=[];
    var total=0;
    for(var i=0;i<dataAll.length;i++){
        dataLegend.push(dataAll[i].typename)
        seriesData.push({
            name: dataAll[i].typename,
            value: dataAll[i].count
        });
        total+=parseInt(dataAll[i].count);
    }
    // var total=parseInt(repair1)+parseInt(repair2);
    if(!dom){
        return;
    }else{
        var myChart=echarts.init(dom);
    
        option = {
            title: {
                text:total,
                subtext:'总计',
                x: '45%',
                y: 'center',
                top:"25%",
                itemGap:0,
                textStyle: {
                    color: '#fff',
                    fontWeight:"normal",
                    fontSize:14
                },
                subtextStyle:{
                    color: '#fff',
                    fontSize:10
                }
            },
            tooltip: {
                trigger: 'item',
            },
            legend: {
                orient: 'vertical',
                left: 'right',
                top: 'top',
                data:dataLegend,
                textStyle: {
                    color: '#f0f0f0',
                    fontSize: '12'
                },
                itemWidth: 10,
                itemHeight: 6,
                itemGap: 2,
            },
            color: ['#FF5E5E','#00FFD2'],
            series: [{
                name: '',
                type: 'pie',
                radius: ['45%', '55%'],
                center: ['50%', '45%'],
                label: {
                  show: false
                  // textStyle: {
                  //     color: "#ffffff",
                  //     fontSize: 14,
                  // }
                },
                labelLine: {
                  show: false
                },
                data: seriesData
            }]
        };
        if (option && typeof option === "object") {
            myChart.setOption(option, true);
        }
        
    }
};
//24小时历史图像 删除图片
function itemDel(){
	var ids = [];
	var TimeArray = [];
	var length = $("#hoursHisImgs ul").length;
	for(var i=0;i<length;i++){
		var a = $("#hoursHisImgs ul:eq("+i+")").find(".noselImg").css('display');
		if(a == 'none'){
			var id = $("#hoursHisImgs ul:eq("+i+")").attr("recordid");
			var time = $("#hoursHisImgs ul:eq("+i+")").attr("createtime");
			ids.push(id);
			TimeArray.push(time);
		}
	}
	
	console.log(ids);
	console.log(TimeArray);
	
	$.ajax({
		type:'get',
		url:baseUrl+"TableService/Infra_Red_Table_Services.asmx/deleteImageByIds",
		dataType:"JSON",
		data:{
			ids:JSON.stringify(ids),
			TimeArray:JSON.stringify(TimeArray)
		},
		success:function(data){
			layer.msg(data.msg,{
			    offset: '15px'
			    ,icon: 2
			    ,time: 500
			});
		},
		error:function(err){
			console.log(err);
		}
	})
}
// 设备下线
function device_offline(machineid,isopen){
	$.ajax({
		type:'get',
		url:baseUrl+"TableService/Infra_Red_Table_Services.asmx/setopenMachine",
		dataType:"JSON",
		data:{
			machineid:machineid,
			isopen:isopen
		},
		success:function(data){
			layer.msg(data[0].msg,{
			    offset: '15px'
			    ,icon: 1
			    ,time: 500
			});
			
			var areaid=$("#tabAll .table_active").attr("data-areaid");
			var fenbuid=$("#fenbuDDAll .select").attr("data-fenbuid");
			var ywbid=$("#ywbDDAll .select").attr("data-ywbid");
			var stationid=$("#bdzDDAll .select").attr("data-stationid");
			var buildingid=$("#sbqDDAll .select").attr("data-buildingid");
			var machineid=$("#hwsbDDAll .select").attr("data-machineid");
			var nextdevice=$("#hwsbDDAll .select").attr("data-index");
			if(nextdevice==''||nextdevice==null||nextdevice==undefined){
			    nextdevice=0;
			}
			// 开始巡视
			realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);
		},
		error:function(err){
			console.log(err);
		}
	})
}
//点击录入异常里的 录入异常图片 查看24小时历史图像
function input_abnormalImg(userid, areaid, fenbuid, ywbid, stationid,machineid,deviceid){
	if(deviceid==undefined){
		deviceid='';
	}
	$.ajax({
		type:'get',
		url:baseUrl+'UserServices/User_Services.asmx/findImageByDevieid',
		dataType:'JSON',
		data:{
			deviceid:deviceid,
			userid:userid,
			areaid:areaid,
			fenbuid:fenbuid,
			ywbid:ywbid,
			stationid:stationid,
			machineid:machineid
		},
		success:function(data){
			var html='';
			var image0='',image1='',image2='';
			if(data.length>0){
				for(let item of data){
					html+=`<ul recordid="`+item.recordid+`">`;
					image0=item.image0;
					image1=item.image1;
					image2=item.image2;
					if(image0==''&&image0==null&&image0==undefined){
						image0='../images/no_pic.png';;
					};
					if(image1==''&&image1==null&&image1==undefined){
						image1='../images/no_pic.png';
					};
					if(image2==''&&image2==null&&image2==undefined){
						image2='../images/no_pic.png';
					};
					var tem=item.valuemax;
					var time=item.createtime; ///Date(158 572 227 7000)/
					var Times='';
					if(time==''||time==null){
						Times='';
					}else{
						Times=(item.createtime).replace(/\T/g," ");
						
					}
					var imgsArr=[image0,image1,image2];
					for(let itemImg of imgsArr){
						html+=`<li>
								<div class="item_bg">
									<div class="top_pic"><img src="${itemImg}" alt=""/></div>
									<div class="bot-text">`;
										if(tem>=100){
											html+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
										}
										if(tem >= 80 && tem < 100){
											html+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
										}
										if(tem<80){
											html+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
										}
										html+=`<div class="botText_right fr">
													<p>${item.devicename}</p>
													<p class="time">${Times}</p>
												</div>
									</div>
								</div>
								<div class="popWindow">
									<i class="noselImg"></i>
									<i style="display:none;" class="selImg"></i>
								</div>
							</li>`;
					}
					html+=`</ul>`;
					
				}
			}else{
				html+=`<p class="noDateP">暂无数据</p>`;
			}
			$("#input_abnormalImg_concent").html(html);
		},
		error:function(err){
			alert("网络错误，请联系技术人员");
		}

	});
}
//点击异常查看页面 表格的维修按钮
function maintain_operate(maintainId,deviceExceptionId){
	var index = layer.open({
	  type: 1,
	  title: false,
	  closeBtn: 0, //不显示关闭按钮
	  shadeClose: true,
	   area: ['500px', '500px'],
	  content: `<div id="repair">
					<h1>维修状态</h1>
					<div style='display: none;'><label>维修人</label><input type="text" id="repair1" placeholder="请输入维修人"></div>
					<div style='display: none;'><label>维修方法</label><input type="text" id="repair2" placeholder="请输入维修方法"></div>
					<div style='display: none;'><label>维修状态</label><select name="repair3" id="repair3">
						<option value="0">无状态</option>
						<option value="1">已解决</option>
						<option value="2">未解决</option>
					</select></div>
					<div><label>维修时间</label><input type="text" class="layui-input" id="repair4"></div>
					<div class="btn">
						<button class="btn1" type="button">修改</button>
						<button class="btn2" type="button">添加</button>
						<button class="btn3" type="button">取消</button>
					</div>
				</div>`
	});
	
	layui.use(['laydate','table'], function(){
		var laydate = layui.laydate;
		var table = layui.table;
		//执行一个laydate实例
		laydate.render({
			elem: '#repair4' //指定元素
			,type: 'datetime'
		});
	  
		if(maintainId==null||maintainId==''||maintainId==undefined){
			$('#repair1').parent().show();
			$('#repair2').parent().show();
			$('#repair .btn2').show();
			$('#repair h1').html('添加维修设备');
		}else{
			$('#repair3').parent().show();
			$('#repair .btn1').show();
			$('#repair h1').html('修改维修设备');
			$.ajax({
				type:'POST',
				url:baseUrl+'UserServices/User_Services.asmx/getDeviceMaintain',
				dataType:'JSON',
				data:{
					maintainId:maintainId,
				},
				success:function(data){
					if(data.falg == true){
						$('#repair3').val(data.maintainModel.maintainStatus);
						var createtime = data.maintainModel.createtime;
						var time = createtime.split('T')[0] +' '+ createtime.split('T')[1];
						$('#repair4').val(time);
					}
				},
				error:function(err){
					console.log(err)
				}
					
			});
		}
		$('#repair').on('click','.btn1',function(){	//修改
			var maintainStatus = $('#repair3').val();
			var maintainTime  = $('#repair4').val();
			
			if(maintainStatus==''||maintainStatus==undefined||maintainTime==''||maintainTime==undefined){
				layer.msg('请完善信息',{
					offset: '15px'
					,time: 500
					,type:1
				});
				return;
			}
			$.ajax({
				type:'get',
				url:baseUrl+'UserServices/User_Services.asmx/updateMaintainStatus',
				dataType:'JSON',
				data:{
					maintainId:maintainId,
					maintainStatus:maintainStatus,
					maintainTime:maintainTime
				},
				success:function(data){
					layer.msg(data.msg,{
						offset: '15px'
						,time: 500
						,type:1
					});
					if(data.falg == true){
						layer.close(index);
						table.reload('testSeeAbnormal');
					}
				},
				error:function(err){
					console.log(err)
				}
					
			});
		})
		$('#repair').on('click','.btn2',function(){	//添加
			var maintainPerson = $('#repair1').val();
			var maintainMethod = $('#repair2').val();
			var maintainTime =$('#repair4').val();
			
			if(maintainPerson==''||maintainPerson==undefined||maintainMethod==''||maintainMethod==undefined||maintainTime==''||maintainTime==undefined){
				layer.msg('请完善信息',{
					offset: '15px'
					,time: 500
					,type:1
				});
				return;
			}
			$.ajax({
				type:'get',
				url:baseUrl+'UserServices/User_Services.asmx/saveMaintain',
				dataType:'JSON',
				data:{
					deviceExceptionId:deviceExceptionId,
					maintainPerson:maintainPerson,
					maintainMethod:maintainMethod,
					maintainTime:maintainTime
				},
				success:function(data){
					layer.msg(data.msg,{
						offset: '15px'
						,time: 500
						,type:1
					});
					if(data.falg == true){
						layer.close(index);
						table.reload('testSeeAbnormal');
					}
				},
				error:function(err){
					console.log(err)
				}
			});
		})
		$('#repair').on('click','.btn3',function(){	//取消
			layer.close(index);
		})
	});
}		
	
//录入异常图片后 是否回显 deleteOrShow为1是回显，为0是删除
	function echo_abnormalImg(deleteOrShow){
		$.ajax({
			type:'get',
			url:baseUrl+"UserServices/User_Services.asmx/Echo",
			dataType:"JSON",
			data:{
				userid:userid,
				deleteOrShow:deleteOrShow
			},
			success:function(data){
				var html='';
				var image0='',image1='',image2='';
				if(data.length>0){
				    for(let item of data){
				        html+=`<ul>`;
				        image0=item.image0;
				        image1=item.image1;
				        image2=item.image2;
				        if(image0==''&&image0==null&&image0==undefined){
				            image0='../images/no_pic.png';;
				        };
				        if(image1==''&&image1==null&&image1==undefined){
				            image1='../images/no_pic.png';
				        };
				        if(image2==''&&image2==null&&image2==undefined){
				            image2='../images/no_pic.png';
				        };
				        var tem=item.valuemax;
				        var time=item.createtime;
				        var Times='';
				        if(time==''||time==null){
				            Times='';
				        }else{
				            Times=(item.createtime).replace(/\T/g," ");
				            
				        }
				        var imgsArr=[image0,image1,image2];
				        for(let itemImg of imgsArr){
				            html+=`<li>
				                    <div class="item_bg">
				                        <div class="top_pic"><img src="${itemImg}" alt=""/></div>
				                        <div class="bot-text">`;
				                            if(tem>=100){
				                                html+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
				                            }
				                            if(tem >= 80 && tem < 100){
				                                html+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
				                            }
				                            if(tem<80){
				                                html+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
				                            }
				                            html+=`<div class="botText_right fr">
				                                        <p>${item.devicename}</p>
				                                        <p class="time">${Times}</p>
				                                    </div>
				                        </div>
				                    </div>
				                </li>`;
				        }
				        html+=`</ul>`;
				    }
				}
				$("#abnormalImg").html(html);
			},
			error:function(err){
				console.log(err);
			}
		})
	}