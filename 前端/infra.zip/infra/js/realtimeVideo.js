 // 数据请求
 var machinemac='';
 var hasVideos='';
 var ysdidArea='';
 var ysdIndexArea='';
 var setYsdindex='';
 var machineid='';
 var ysdidModify='';
 var areaDeviceid='';
 var ysdnameZp='',machineidZp='';
 var sx=0;
 var ysdDo=0;
 var deviceid='',ysdnameA='';
 var onShow=0;
 var machineidSet='';
 var ysdnameBj='';
 var areaId='',fenbuId='',ywbId='',stationId='',buildingId='',machineId='';
 layui.use(['table','layer','form'], function(){
    var layer=layui.layer;
    var form=layui.form;
    $(function () {
        var deviceidA=Util.getUrlParam('deviceid');
        var machineidA=Util.getUrlParam('machineid');
        if(deviceidA==undefined||deviceidA==null){
            deviceidA='';
        };
        if(machineidA==undefined||machineidA==null){
            machineidA='';
        }
        connectMqttServer(machineidA);
        getdeviceConfigInfor(onShow,deviceidA,machineidA,ysdnameA);
        

        // $("#deleteCanvas").attr("disabled",true);//删除区域
        // $("#deleteCanvas").addClass("notCup");
        // $("#tijiao").attr("disabled",true); //提交区域
        // $("#tijiao").addClass("notCup");
        // $("#save").attr("disabled",true); //保存
        // $("#save").addClass("notCup");
        function getdeviceConfigInfor(onShow,deviceidD,machineid,ysdname){
            $.ajax({
                type:'get',
                url:baseUrl+'ConfigTool/ConfigService.asmx/getdevice_config_infor',
                dataType:'JSON',
                data:{
                    deviceID:deviceidD,
                    width:675,
                    height:480,
                    machineid:machineid,
                    ysdname:ysdname
                },
                success:function(data){
                    if(data.falg){
                    
                        if(onShow==1){
                            var can = document.getElementById("canvas");
                            var ctx = can.getContext('2d');
                            var canSave = document.getElementById("canvasSave");
                            var ctxSave = canSave.getContext('2d');
                            ctx.clearRect(0, 0, can.width, can.height);
                            ctxSave.clearRect(0, 0, canSave.width, canSave.height);
                        }
                        sessionStorage.datas = JSON.stringify(data);
                        // data.Msg
                        areaId=data.Areaid;
                        fenbuId=data.Fenbuid;
                        ywbId=data.Ywbid;
                        stationId=data.Stationid;
                        buildingId=data.Buildingid;
                        machineId=data.Machineid;

                        deviceid=data.Deviceid;
                        machinemac=data.Machinemac;
                        ysdidArea=data.Ysdid;
                        ysdIndexArea=data.Ysdindex;
                        hasVideos=data.Video.HasVideo;
                        if(hasVideos==3){
                            // 红外高清视频
                            $("#video1").show();
                            $("#video2").show();
                            new window.FlvJsPlayer({
                                id: 'video1',
                                isLive: false,
                                playsinline: true,
                                url: data.Video.Ir[0],
                                autoplay: true,
                                height: 480,
                                width: 675,
                            });
                            new window.FlvJsPlayer({
                                id: 'video2',
                                isLive: false,
                                playsinline: true,
                                url: data.Video.High[0],
                                autoplay: true,
                                height: 480,
                                width: 675
                            });
                            // 图片
                            $(".hwImg").hide();
                            $(".gqImg").hide();
                            // $(".donghua").css({
                            //     'right':'17px',
                            // })
                        }else if(hasVideos==1){
                            // 红外视频
                            $("#video1").show();
                            new window.FlvJsPlayer({
                                id: 'video1',
                                isLive: false,
                                playsinline: true,
                                url: data.Video.Ir[0],
                                autoplay: true,
                                height: 480,
                                width: 675,
                            });
                            $("#video2").hide();
            
                            //图片
                            $(".hwImg").hide();
                            $(".gqImg").show();
                            $(".left_kjgPic img").attr("src",data.Image1);
                        }else if(hasVideos==2){
                            picShow(machinemac,ysdIndexArea);
                            // 可见光视频
                            $("#video2").show();
                            new window.FlvJsPlayer({
                                id: 'video2',
                                isLive: false,
                                playsinline: true,
                                url: data.Video.High[0],
                                autoplay: true,
                                height: 480,
                                width: 675
                            });
                            $("#video1").hide();
                            //图片
                            $(".hwImg").show();
                            $(".gqImg").hide();
                            $(".left_hwPic img").attr("src",data.Image2);
                        }else{
                            picShow(machinemac,ysdIndexArea);
                            $("#video1").hide();
                            $("#video2").hide();
            
                            // 红外高清图片
                            $(".hwImg").show();
                            $(".gqImg").show();
                            $(".left_kjgPic img").attr("src",data.Image1);
                            $(".left_hwPic img").attr("src",data.Image2);
                        }
                        
                        // 管理员设备
                        $("#getMacAddress").val(data.Machinemac);
                        $("#getMachinename").val(data.Machinename); 
                        $("#areaSet").val(data.Areaname);
                        $("#ywbSet").val(data.Ywbname);
                        $("#bdzSet").val(data.Stationname);
                        $("#sbqSet").val(data.Buildingname);

                        $("#getConnectDevice").val(data.Machineip);
                        $("#wifiname").val(data.Wifiname);
                        $("#wifipass").val(data.Wifipass);
                        $("#getCloudAddress").val(data.Cloudaddr);
                        $("#getFusheLv").val(data.Fushelv);
                        $("#getMachineCode").val(data.Machinecode);
                        $("#getUploadFile").val(data.Filepath);
                        $("#param_S").val(data.Rong_S);
                        $("#param_R").val(data.Rong_R);
                        $("#param_L").val(data.Rong_L);
                        $("#param_T").val(data.Rong_T);
                        $("#getHongwaiParam").val(data.Hongwai_cx);
                        $("#getBianyuanParam").val(data.Bianyuan_cx);
                        $("#getAlarmvalue").val(data.Alarmvalue);
                        $("#getShouwangPoint").val(data.Point_ysd_index);

                        
                        // 抓拍周期
                        var catchSpan=data.Catch_span;
                        $("#getCatchspan option").each(function(){
                            if($(this).val() ==catchSpan){
                                $(this).attr('selected',true)
                            }
                        });
                        // 巡视周期
                        var xunshiSpan=data.Xunshi_span;
                        $("#getxunshi option").each(function(){
                            if($(this).val() ==xunshiSpan){
                                $(this).attr('selected',true)
                            }
                        });
                        form.render('select');
                        
                        // 抓拍
                        ysdnameZp=data.Ysdname;
                        machineid=data.Machineid;
                        machineidZp=data.Machineid;
                        if(machineidZp==''||machineidZp==null||machineidZp==undefined){
                            machineidZp='';
                        }else{
                            machineidZp=data.Machineid;
                        }
                        if(ysdnameZp==''||ysdnameZp==null||ysdnameZp==undefined){
                            ysdnameZp='';
                        }else{
                            ysdnameZp=data.Ysdname;
                        }
                        capture(machineidZp,ysdnameZp);
                        
                        //预设点
                        machineidSet=data.Machineid;
                        ysdnameBj=data.Ysdname;
                        if(ysdnameBj==''||ysdnameBj==null||ysdnameBj==undefined){
                            ysdnameBj='';
                        }
                        ysdAllVideo(machineid,ysdnameBj);
                    }else{
                        var can = document.getElementById("canvas");
                        var ctx = can.getContext('2d');
                        var canSave = document.getElementById("canvasSave");
                        var ctxSave = canSave.getContext('2d');
                        ctx.clearRect(0, 0, can.width, can.height);
                        ctxSave.clearRect(0, 0, canSave.width, canSave.height);
                        $("#video1").hide();
                        $("#video2").hide();
                        // 红外高清图片
                        $(".hwImg").show();
                        $(".gqImg").show();
                        $(".left_kjgPic img").attr("src","../images/no_pic.png");
                        $(".left_hwPic img").attr("src","../images/no_pic.png");
                        $("#getConnectDevice").val('');
                        $("#wifiname").val('');
                        $("#wifipass").val('');
                        $("#getCloudAddress").val('');
                        $("#getFusheLv").val('');
                        $("#getMachineCode").val('');
                        $("#getUploadFile").val('');
                        $("#param_S").val('');
                        $("#param_R").val('');
                        $("#param_L").val('');
                        $("#param_T").val('');
                        $("#getHongwaiParam").val('');
                        $("#getBianyuanParam").val('');
                        $("#getAlarmvalue").val('');
                        $("#getShouwangPoint").val('');
                        $("#getCatchspan").val('');
                        $("#getxunshi").val('');
                        //预设点
                        ysdnameBj=data.Ysdname;
                        if(ysdnameBj==''||ysdnameBj==null||ysdnameBj==undefined){
                            ysdnameBj='';
                        }
                        ysdAllVideo(machineid,ysdnameBj);
                    }
                },
                error:function(err){
                        console.log(err)
                }
        
            });
        }
		//点击历史太阳轨迹
		$("#historySun").click(function(){
			$('#historySun_bg').attr("style","display: blick;");
			historySun();
		})
		
		//关闭历史太阳轨迹的页面
		$(".historySun_btn").click(function(){
			$('#historySun_bg').attr("style","display: none;")
		})
		$("#historySun_del_btn1").click(function(){
			$('#historySun_ul .popWindow').attr("style","display: inline-block;")
		})
		$("#historySun_del_btn2").click(function(){
			$('#historySun_ul .popWindow').attr("style","display: none;")
		})
		//点击历史太阳轨迹的页面的内容，出现删除模样
		var arrsImgId=[],arrsImgTime=[];
		var recordid='',imgTime='';
		$('#historySun_ul').on("click",".popWindow",function(){
		    $(this).find(".selImg").toggle();
		    $(this).find(".noselImg").toggle();
		    if($(this).find(".noselImg").css("display")=='none'){
		        recordid=$(this).attr("data-deviceid");
		        imgTime=$(this).attr("data-imgTime");
		        arrsImgId[arrsImgId.length]=recordid;
		        arrsImgTime[arrsImgTime.length]=imgTime;
		    }else{
		        recordid=$(this).attr("data-deviceid");
		        imgTime=$(this).attr("data-imgTime");
		        for(var i=0;i<arrsImgId.length;i++){
		            if(arrsImgId[i]==recordid){
		                arrsImgId = $.grep(arrsImgId, function(value) {
		                    return value != recordid;
		                });
						break;
		            }
		        };
		        for(var j=0;j<arrsImgTime.length;j++){
		            if(arrsImgTime[i]==arrsImgId){
		                arrsImgTime = $.grep(arrsImgTime, function(value) {
		                    return value != imgTime;
		                });
						break;
		            }
		        }
		    }
		});
		
		//点击历史太阳轨迹的页面完成按钮
		$('#historySun_del_btn2').click(function(){
			var recordids = arrsImgId.toString();
			console.log(recordids);
			$.ajax({
				type:'get',
				url:baseUrl+'UserServices/User_Services.asmx/deleteImageSun',
				dataType:'JSON',
				data:{
					recordids:recordids
				},
				success:function(data){
					console.log(data);
					layer.msg(data.msg,{
					    offset: '15px'
					    ,icon: 1
					    ,time: 500
					});
					document.location.reload();
					historySun();
				},
				error:function(err){
					console.log(err);
				}
			})
		})
		//点开历史太阳轨迹的页面调用接口，获得数据
		function historySun(){
			$.ajax({
				type:'post',
				url:baseUrl+'UserServices/User_Services.asmx/findImageSunByDeviceid',
				dataType:'JSON',
				data:{
					deviceid:deviceid
				},
				success:function(data){
					var html ='';
					for(var i=0;i<data.length;i++){
						var s1 = data[i].createtime.substring(6,19);
						var Times = times(s1);
						
						html += '<li>';
						html += '<div class="historySun_box">';
						html += '<div class="historySun_img">';
						html += '<img src="'+data[i].image0+'" data-recordid="'+data[i].recordid+'">';
						html += '</div>';
						html += '<div class="historySun_text">';
						html += '<div class="historySun_text_left">';
						html += data[i].valuemax;
						html += '<span>℃</span>';
						html += '</div>';
						html += '<div class="historySun_text_right">';
						html += '<p>'+data[i].devicename+'</p>';
						html += '<p class="time">'+Times+'</p>';
						html += '</div>';
						html += '</div>';
						html += '</div>';
						html += '<div style="display:none;" class="popWindow" data-recordid='+data[i].recordid+' data-imgTime='+Times+'>';
						html += '<i class="noselImg" style="display:block;"></i>';
						html += '<i class="selImg" style="display:none;"></i>';
						html += '</div>';
						html += '</li>';
						
						html += '<li>';
						html += '<div class="historySun_box">';
						html += '<div class="historySun_img">';
						html += '<img src="'+data[i].image1+'" data-recordid="'+data[i].recordid+'">';
						html += '</div>';
						html += '<div class="historySun_text">';
						html += '<div class="historySun_text_left">';
						html += data[i].valuemax;
						html += '<span>℃</span>';
						html += '</div>';
						html += '<div class="historySun_text_right">';
						html += '<p>'+data[i].devicename+'</p>';
						html += '<p class="time">'+Times+'</p>';
						html += '</div>';
						html += '</div>';
						html += '</div>';
						html += '<div style="display:none;" class="popWindow" data-recordid='+data[i].recordid+' data-imgTime='+Times+'>';
						html += '<i class="noselImg" style="display:block;"></i>';
						html += '<i class="selImg" style="display:none;"></i>';
						html += '</div>';
						html += '</li>';
					};
				$("#historySun_ul").html(html);	
				
				},
				error:function(err){
					console.log(err);
				}
			})
		}
		
        setTimeout(() => {
			
			
			
                $("#setAreaInfo").on("click", () => {
                    
                    // var areaid=$("#areaSet").val(); 
                    var url="tem_videosEdit.html?areaid="+areaId
                    +"&&fenbuid="+fenbuId+"&&ywbid="+ywbId
                    +"&&stationid="+stationId+"&&buildingid="+buildingId+"&&machineid="+machineId;
                    Util.popFullScreen3(100,100,url);
                    
                });
                // 连接设备,传值ip
                $("#setConnectDevice").on("click", () => {
                    var ip=$("#getConnectDevice").val();
                    connectDevice(ip);
                });
                // 设置WiFi
                $("#setWifi").on("click", () => {
                    var wifiname=$("#wifiname").val();
                    var wifipass=$("#wifipass").val();
                    setWifi(machinemac,deviceid,wifiname,wifipass)
                });
                // 设置设备云地址
                $("#setCloudAddress").on("click", () => {
                    var addr=$("#getCloudAddress").val();
                    setCloudAddress(machinemac,deviceid,addr);
                });
                // 辐射率设定
                $("#setFusheLv").on("click", () => {
                    var fushelv=$("#getFusheLv").val();
                    setFusheLv(machinemac,deviceid,fushelv);
                });
				// 红外设备名字保存
				$("#setMachineName").on("click", () => {
				    var name=$("#getMachinename").val();
				    setMachineName(machinemac,deviceid,name);
				});
                // 设备编号设定
                $("#setMachineCode").on("click", () => {
                    var code=$("#getMachineCode").val();
                    setMachineCode(machinemac,deviceid,code);
                });
                // 校准参数上传
                $("#setUploadFile").on("click", () => {
                    var filepath=$("#getUploadFile").val();
                    uploadFile(machinemac,deviceid,filepath);
                });
                // 融合参数设置
                $("#setRongHe").on("click", () => {
                    var param_S=$("#param_S").val();
                    var param_R=$("#param_R").val();
                    var param_L=$("#param_L").val();
                    var param_T=$("#param_T").val();
                    setRongHe(machinemac,deviceid,param_S,param_R,param_L,param_T);
                });
                // 设定红外呈现参数
                $("#setHongwaiParam").on("click", () => {
                    var param=$("#getHongwaiParam").val();
                    setHongwaiParam(deviceid,param);
                });
                // 边缘呈现参数设定（更新）
                $("#setBianyuanParam").on("click", () => {
                    var param=$("#getBianyuanParam").val();
                    setBianyuanParam(deviceid,param);
                });
                // 告警温度设定（保存）
                $("#setAlarmvalue").on("click", () => {
                    var alarmvalue=$("#getAlarmvalue").val();
                    setAlarmvalue(deviceid,alarmvalue);
                });
                // 守望点设定
                $("#setShouwangPoint").on("click", () => {
                    var values=$("#getShouwangPoint").val();
                    setShouwangPoint(deviceid,values);
                });
                // 抓拍间隔设定【分钟】
                $("#setCatchSpan").on("click", () => {
                    var catchspan=$("#getCatchspan").val();
                    var value_Xun=$("#getxunshi").val();
                    setCatchSpan(deviceid,catchspan,value_Xun);
                });
                // 巡视周期设定【分钟】
                $("#setXunshi").on("click", () => {
                    var catchspan=$("#getCatchspan").val();
                    var xunshi=$("#getxunshi").val();
                    setXunshi(deviceid,catchspan,xunshi);
                });
                //暂时没有接口
                
				//一键抓拍
				$("#catchPicAll").on("click", () => {
					catchPicAll(machinemac);
				})
                // 抓拍
                $("#catchPic").on("click", () => {
                    catchPic(machinemac);
                });
                // 刷新
                $("#Refresh").on("click", () => {
                    sx=1;
                    capture(machineidZp,ysdnameZp,sx)
                    // capture(machineid,sx);
                });
                var flse=false;
                $(".stopStar").on("click",()=>{
                    $(".handle_start").show();
                    $(".handle_stop").hide();
                    goStop(); 
                    // if(flse){
                    //     $(".handle_stop").show();
                    //     $(".handle_start").hide();
                    //     goStop(); 
                    //     flse=false;
                    // }else{
                    //     $(".handle_start").show();
                    //     $(".handle_stop").hide();
                    //     goStart();
                    //     flse=true;
                    // }
                });
                // 一键清除预设点
                $("#clearYsdVideos").on("click",function(){
                    clearYsdAll(machinemac,deviceid);
                });
                // 添加预设点
                $(".addYsdVideos").on("click",function(){
                    $(".ysdAdd_tanchu").show();
                });
                // 添加预设点 确定
                $(".ysdAdd_tanchu .btn0").on("click", () => {
                    var addysdNames=$("#addysdNames").val();
                    var addysdDistance=$("#addysdDistance").val();
                    $(".ysdAdd_tanchu").css("display","none");
                    var addTrue=1;
                    setYsd(deviceid,addysdNames,addysdDistance,addTrue,machineid);
                });
                // 添加预设点 取消
                $(".ysdAdd_tanchu .btn1").click(function(){
                    $(".ysdAdd_tanchu").css("display","none");
                });

                // 调用预设点
                $("#ysdAllVideoUl").on("click","li #runningYsd", function(){
                    var ysdindex=$(this).attr("data-ysdindex");
                    var machineid=$(this).attr("data-machineid");
                    var ysdname=$(this).attr("data-ysdname");
                    if(machineid==null||machineid==undefined||machineid==''||machineid=='null'){
                        machineid=''
                    }
                    if(ysdname==null||ysdname==undefined||ysdname==''||ysdname=="null"){
                        ysdname='';
                    }
                    if(ysdindex=="null"||ysdindex==null||ysdindex==undefined){
                        ysdindex='';
                    }
                    // runningYsd(deviceid,ysdindex,machineid,ysdname);
                    var index = layer.msg("调用中，请稍等",{time:'-1'});
                    $.ajax({
                        type:'get',
                        url:baseUrl+'ConfigTool/ConfigService.asmx/do_ysd',
                        dataType:'JSON',
                        data:{
                            machinemac:machinemac,
                            deviceID:deviceid,
                            value:ysdindex  //预设点编号
                        },
                        success:function(data){
                            layer.close(index);
                            // layer.msg(data[0].msg, {time: 1000}); 
                            var deviceidDy='';
                            var onShow=1;
                            if(data[0].falg==false){
                                layer.msg(data[0].msg, {time: 1000}); 
                                return;
                            }else{
                                getdeviceConfigInfor(onShow,deviceidDy,machineid,ysdname);
                            }
                        },
                        error:function(err){
                            alert("网络错误,请联系技术人员");
                        }

                    });
                });
                // 设定预设点
                $("#ysdAllVideoUl").on("click"," li #setYsd", function(){
                    $(".ysdDistance_tanchu").show();
                    setYsdindex=$(this).attr("data-ysdindex");
                    var setYsddistance=$(this).attr("data-distance");
                    // machineidSet=$(this).attr("data-machineid");
                    
                    if(setYsddistance=="null"){
                        setYsddistance='';
                    }
                    if(setYsdindex=="null"||setYsdindex==null||setYsdindex==undefined){
                        setYsdindex='';
                    }
                    // if(machineidSet=="null"||machineidSet==null||machineidSet==undefined){
                    //     machineidSet='';
                    // }
                    $("#ysdDistance").val(setYsddistance);
                });
                // 设定预设点 确定
                $(".ysdDistance_tanchu .btn0").on("click", function(){
                    var distance=$("#ysdDistance").val();
                    if(distance==''){
                        layer.msg("请输入",{icon:5,time:2000,anim: 6});
                        return;
                    }
                    $(".ysdDistance_tanchu").css("display","none");
                    var addTrue=0;
                    setYsd(deviceid,setYsdindex,distance,addTrue,machineidSet);
                    

                });
                    // 设定预设点 取消
                $(".ysdDistance_tanchu .btn1").click(function(){
                    $(".ysdDistance_tanchu").css("display","none");
                });
                // 添加电力设备
                $("#ysdAllVideoUl").on("click","li .add_device",function(){
                    //添加设备
                    $(".deviceAdd_tanchu").show();
                    ysdidArea=$(this).attr("data-ysdid");
                    if(ysdidArea=="null"||ysdidArea==null||ysdidArea==undefined){
                        ysdidArea='';
                    }
                });
                // 添加电力设备 确定
                $(".deviceAdd_tanchu .btn0").on("click", () => {
                    var operaterNumber=$("#operaterNumber").val();//运行编号
                    var devicename=$("#deviceBuwei").val();//监控部位
                    if(operaterNumber==''||devicename==''){
                        layer.msg("请输入");
                        return;
                    }
                    $(".deviceAdd_tanchu").css("display","none");
                    addDevice(ysdidArea,devicename,operaterNumber,deviceid);
                    ysdDeviceVideo(ysdidArea);//刷新
                });
                // 添加电力设备 取消
                $(".deviceAdd_tanchu .btn1").click(function(){
                    $(".deviceAdd_tanchu").css("display","none");
                });
                // 删除预设点
                $("#ysdAllVideoUl").on("click","li #deleteYsd", function(){
                    var ysdindex=$(this).attr("data-ysdindex");
                    var machineidDel=$(this).attr("data-machineid");
                    if(machineidDel==null||machineidDel==undefined||machineidDel==''||machineidDel=='null'){
                        machineidDel=''
                    }
                    if(ysdindex=="null"||ysdindex==null||ysdindex==undefined){
                        ysdindex='';
                    }
                    deleteYsd(machinemac,deviceid,ysdindex,machineidDel);
                });
                // 删除区域
                $("#ysdAllVideoUl").on("click","li #ysdDevice #deleteAreaDevice", function(){
                    var areaDeviceid=$(this).attr("data-deviceid");
                    if(areaDeviceid=="null"||areaDeviceid==null||areaDeviceid==undefined){
                        areaDeviceid='';
                    }
                    delShebeiBw(areaDeviceid);
                    var ysdid=$(this).attr("data-ysdindex");
                    if(ysdid=="null"||ysdid==null||ysdid==undefined){
                        ysdid='';
                    }
                    ysdDeviceVideo(ysdid);//刷新
                });
                // 重命名
                $("#ysdAllVideoUl").on("click","li #ysdDevice #modifyAreaDevice", function(){
                    $(".modifyDeviceName_tanchu").show();
                    var deviceNameModify=$(this).attr("data-devicename");
                    if(deviceNameModify=="null"||deviceNameModify==null||deviceNameModify==undefined){
                        deviceNameModify='';
                    }
                    $("#deviceName").val(deviceNameModify)
                    ysdidModify=$(this).attr("data-ysdindex");
                    areaDeviceid=$(this).attr("data-deviceid");
                    if(ysdidModify=="null"||ysdidModify==null||ysdidModify==undefined){
                        ysdidModify='';
                    }
                });
                // 重命名 确定
                $(".modifyDeviceName_tanchu .btn0").on("click", () => {
                    var deviceName=$("#deviceName").val();//新名字
                    if(deviceName==''){
                        layer.msg("请输入");
                        return;
                    }
                    $(".modifyDeviceName_tanchu").css("display","none");
                    modifyDeviceName(areaDeviceid,deviceName,ysdidModify);
                    
                    
                });
                // 重命名 取消
                $(".modifyDeviceName_tanchu .btn1").click(function(){
                    $(".modifyDeviceName_tanchu").css("display","none");
                }); 
                
                $("#tijiao").on("click",function () {
                    
                    submissionArea(deviceid,ysdIndexArea,coordinate);
                });
                
        }, 1000);
    });
});

function picShow(machinemac,ysdIndexArea){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/getRectbyYsd',
        dataType:'JSON',
        traditional : true,
        data:{
            machinemac:machinemac,
            ysdindex:ysdIndexArea,
            width:675,
            height:480
        },
        success:function(data){
            var pointlist=[];
            if(!data[0].msg){
                for(var i=0;i<data.length;i++){
                    pointlist.push(JSON.parse(data[i].pointlist));
                };
                
                var optionStr ='<option lable="">请选择</option>';
                for(var i=0;i<pointlist.length;i++){
                    // var nums='零一二三四五六七八九'.charAt(i+1);
                    var grids=JSON.stringify(pointlist[i])
                    optionStr+="<option class='selectYouzhi' data-index="+(i+1)+"  value='"+grids+"'>区域"+(i+1)+"</option>";
                }
                $("#areas").html(optionStr); //区域

                var can = document.getElementById("canvas");
                var ctx = can.getContext('2d');
                var canSave = document.getElementById("canvasSave");
                var ctxSave = canSave.getContext('2d');
                ctx.strokeStyle = 'rgba(255,0,0,1)';//线条颜色
                ctx.lineWidth = 2;//线条粗细
                ctxSave.strokeStyle = 'rgba(255,0,0,1)';//线条颜色
                ctxSave.lineWidth = 2;//线条粗细
                if (pointlist.length > 0) {
                    for(var i = 0; i < pointlist.length; i++){
                            /*开始绘制*/
                            ctxSave.beginPath();
                            ctxSave.moveTo (pointlist[i][0].x, pointlist[i][0].y);
                        for (var j = 0; j < pointlist[i].length; j++){
                            ctxSave.lineTo(pointlist[i][j].x, pointlist[i][j].y);
                            ctxSave.fillStyle = 'rgba(255,0,0,0.01)';//填充颜色
                            ctxSave.fill();//填充
                            ctxSave.stroke();//绘制
                        }
                        ctxSave.closePath();
                    }
                }
            }
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};

// http://116.255.207.148:8080/ConfigTool/ConfigService.asmx?op=X_connectMqttServer
function connectMqttServer(machineId){
    $(".loding_bg").show();
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/X_connectMqttServer',
        dataType:'JSON',
        traditional : true,
        data:{
            MachineId:machineId
        },
        success:function(data){
            if(data[0].msg=="连接成功"){

                $(".loding_bg").hide();
                layer.msg(data[0].msg, {
                    offset: '15px'
                    ,icon:1
                    ,time: 1000
                });
            }else{
                alert(data[0].msg)
                // layer.msg(data[0].msg, {
                //     offset: '15px'
                //     ,icon: 2
                //     ,time: 1000
                // });
            }
            
                
        },
        error:function(err){
                console.log(err)
        }

    });
};
// 接口描述：
// 上传坐标区域
// deviceid,rectindex,rectname,pointlist 设备id 区域编号，区域名称，坐标数组
function submissionArea(deviceid,ysdindex,pointlist){
    var rectindex=1;
    var rectname=1;
    // var deviceid=Util.getUrlParam('deviceid');
    // "01966a446b874a5496bcc943c1e80470"
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/upLoadRect',
        dataType:'JSON',
        traditional : true,
        data:{
            deviceID:deviceid,
            ysdindex:ysdindex,
            rectindex:rectindex,
            rectname:rectname,
            pointlist:JSON.stringify(pointlist),
            machinemac:machinemac,
            width:675,
            height:480
        },
        success:function(data){
            layer.msg(data[0].msg, {
                offset: '15px'
                ,icon: 1
                ,time: 1000
            });
            
                
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};

// 接口描述：设置缩略图
function setSuoLue(){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/setSuoLue',
        dataType:'JSON',
        data:{
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：重启设备
function reBoot(){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/rebootDevice',
        dataType:'JSON',
        data:{
            machinemac:machinemac
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：恢复出厂
function recorvery(){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/SystemRecovery',
        dataType:'JSON',
        data:{
            machinemac:machinemac
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：调用预设点
function runningYsd(deviceID,ysdindex,machineid,ysdname){
    var index = layer.msg("调用中，请稍等",{time:'-1'});
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/do_ysd',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            value:ysdindex  //预设点编号
        },
        success:function(data){
            layer.close(index);
            layer.msg(data[0].msg, {time: 1000}); 
            getdeviceConfigInfor(deviceID,machineid,ysdname);
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述: 添加电力设备
function addDevice(ysdid,devicename,operaterNumber,deviceID){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/saveDeviceByYsd',
        dataType:'JSON',
        data:{
            ysdid:ysdid,	
            deviceName:devicename,
            operaterNumber:operaterNumber,
            deviceID:deviceID
        },
        success:function(data){
            // data.Msg
            if(data[0].msg=="添加成功"){
                layer.msg(data[0].msg, {
                    offset: '15px'
                    ,icon: 1
                    ,time: 1000
                });
            }else{
                layer.msg(data[0].msg, {
                    offset: '15px'
                    ,icon: 2
                    ,time: 1000
                });
            }
            
                
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：设定预设点 
function setYsd(deviceid,ysdindex,distance,addTrue,machineidSet){
    
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/addysd',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceid,	
            ysdindex:ysdindex,	
            distance:distance
        },
        success:function(data){
            var str = data[0].msg.split(" ")[0];
            if(data[0].falg==true){
                layer.msg(str, {
                    // offset: '15px',
                    icon: 1
                    ,time: 1000
                });
            }else{
                layer.msg(str, {
                    offset: '15px'
                    ,icon: 2
                    ,time: 1000
                });
            }
           
            if(addTrue==0){ //设定
                ysdAllVideo(machineidSet,ysdnameBj);
            }
            
                
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：删除预设点
function deleteYsd(machinemac,deviceID,ysdindex,machineid){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/clearysd',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            ysdindex:ysdindex
        },
        success:function(data){
            if(data[0].falg){
                layer.msg(data[0].msg, {
                    offset: '15px'
                    ,icon: 1
                    ,time: 1000
                });
                ysdAllVideo(machineid,ysdnameBj);
            }else{
                layer.msg(data[0].msg, {
                    offset: '15px'
                    ,icon: 2
                    ,time: 1000
                });
            }  
        },
        error:function(err){
			console.log(err);
                alert("网络错误,请联系技术人员");
        }

    });
};

// clearYsdAll
// 接口描述：一键删除所有预设点
function clearYsdAll(machinemac,deviceID){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/clearAllysd',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID
        },
        success:function(data){
            // data.Msg
            if(data[0].falg){
                layer.msg(data[0].msg, {
                    offset: '15px'
                    ,icon: 1
                    ,time: 1000
                });
                ysdAllVideo(machineidSet,ysdnameBj)
            }else{
                layer.msg(data[0].msg, {
                    offset: '15px'
                    ,icon: 2
                    ,time: 1000
                });
            }  
        },
        error:function(err){
                alert("网络错误,请联系技术人员");
        }

    });
};
//删除区域
//传参(类型：字符): id
function delShebeiBw(id){
    $.ajax({
            type:'get',
            url:baseUrl+'UserServices/User_Services.asmx/i_deletedevice',
            dataType:'JSON',
            data:{
                    id:id,
            },
            success:function(data){
                layer.msg(data[0].msg, {time:1000});
            },
            error:function(err){
                alert("网络错误,请联系技术人员");
            }

    });
};

// 接口描述：一键抓拍
function catchPicAll(machinemac){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/akeytosnap',
        dataType:'JSON',
        data:{
            machinemac:machinemac
        },
        success:function(data){
			console.log(data);
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};

// 接口描述：抓拍
function catchPic(machinemac){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/catch_picture',
        dataType:'JSON',
        data:{
            machinemac:machinemac
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};


// 接口描述：连接TCP设备，参数：ip（设备ip，设备端口）
function connectDevice(ip){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/a_Connect',
        dataType:'JSON',
        data:{
            ip:ip,
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：设置WiFi
function setWifi(machinemac,deviceID,wifiname,wifipass){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/b_setWifi',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            wifiname:wifiname,
            wifipass:wifipass
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：设置设备云地址，参数：cloudAddr
function setCloudAddress(machinemac,deviceID,addr){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/c_setCloudAddr',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            Cloud_addr:'',
            ftp_addr:addr
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：辐射率设定
function setFusheLv(machinemac,deviceID,fushelv){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/d_setFusheLv',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            value:fushelv
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：更改红外设备名字保存
function setMachineName(machinemac,deviceID,name){
    $.ajax({
        type:'get',
        url:baseUrl+'UserServices/User_Services.asmx/modifyMachinenameByMachineid',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            // machineid:deviceID,
            machinename:name
        },
        success:function(data){
            layer.msg(data.msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：设备编号设定
function setMachineCode(machinemac,deviceID,code){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/e_setDeviceCode',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            value:code
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：校准参数上传
function uploadFile(machinemac,deviceID,filepath){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/f_upLoadFile',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            value:filepath
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：融合参数设置
function setRongHe(machinemac,deviceID,param_S,param_R,param_L,param_T){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/g_setRonghe',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            rong_S:param_S	
            ,rong_R:param_R
            ,rong_L:param_L	
            ,rong_T:param_T
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：设定红外呈现参数
function setHongwaiParam(deviceID,param){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/h_set_infraParam',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            value:param
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：更新边缘呈现参数
function setBianyuanParam(deviceID,param){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/i_set_edgeParam',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            value:param
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：告警温度设定
function setAlarmvalue(deviceID,alarmvalue){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/j_setAlarmvalue',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            value:alarmvalue
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：守望点设定
function setShouwangPoint(deviceID,values){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/k_setPointIndex',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            value:values
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：抓拍间隔设定【分钟】
function setCatchSpan(deviceID,catchspan,value_Xun){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/l_setCatchSpan',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            value_Catch:catchspan,
            value_Xun:value_Xun
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};

// 接口描述：巡视周期设定【分钟】m_setXunshiSpan
function setXunshi(deviceID,catchspan,value_Xun){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/l_setCatchSpan',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            deviceID:deviceID,
            value_Catch:catchspan,
            value_Xun:value_Xun
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};

//申明全局变量
var timeStart, timeEnd, time,timeValue=0;
//获取此刻时间
function getTimeNow() {
    var now = new Date();
    return now.getTime();
};
//鼠标按下时触发
function holdDown(nums) {
    //获取鼠标按下时的时间
    timeStart = getTimeNow();
}
function holdUp(nums) {
    //setInterval会每100毫秒执行一次，也就是每100毫秒获取一次时间
    time = setInterval(function () {
        timeEnd = getTimeNow();
        //如果此时检测到的时间与第一次获取的时间差有1000毫秒
        if (timeEnd - timeStart > 1000) {
            //便不再继续重复此函数 （clearInterval取消周期性执行）
            clearInterval(time);
            timeValue=1;
            if(nums==1){
                // 上
                goUp(timeValue);
            }else if(nums==2){
				//左
				goLeft(timeValue);
                // 右
                // goright(timeValue);
            }else if(nums==3){
                //下
                goDown(timeValue);
            }else if(nums==4){
                //左
                // goLeft(timeValue);
				// 右
				goright(timeValue);
            }else{
                alert("未点击手柄")
            }
        }else{
            clearInterval(time);
            timeValue=0;
            if(nums==1){
                // 上
                goUp(timeValue);
            }else if(nums==2){
				//左
				goLeft(timeValue);
                // 右
                // goright(timeValue);
            }else if(nums==3){
                //下
                goDown(timeValue);
            }else if(nums==4){
				// 右
				goright(timeValue);
                //左
                // goLeft(timeValue);
            }else{
                alert("未点击手柄")
            }
        }
    }, 100);
}
// 接口描述：手柄上
function goUp(timeValue){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/goUp',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            timeValue:timeValue
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};

 


// 接口描述：手柄停止
function goStop(){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/goStop',
        dataType:'JSON',
        data:{
            machinemac:machinemac
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：手柄右
function goright(timeValue){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/goright',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            timeValue:timeValue
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：手柄下
function goDown(timeValue){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/goDown',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            timeValue:timeValue
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};
// 接口描述：手柄左
function goLeft(timeValue){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/goLeft',
        dataType:'JSON',
        data:{
            machinemac:machinemac,
            timeValue:timeValue
        },
        success:function(data){
            layer.msg(data[0].msg, {time:1000});
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};


// 抓拍
function capture(machineid,ysdname,sx){
    if(ysdname==null||ysdname==undefined||ysdname==''||ysdname=="null"){
        var ysdname='';
    }
    if(machineid==null||machineid==undefined||machineid==''||machineid=="null"){
        var machineid='';
    }
    // if(sx==1){
    //     var index = layer.msg("刷新中，请稍等",{time:'-1'});
    // }
    var index = layer.msg("刷新中，请稍等",{time:'-1'});
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/getHistoryImagebymachine',
        dataType:'JSON',
        data:{
            machineid:machineid,
            ysdname:ysdname
        },
        success:function(data){
            layer.close(index);
            var htmlCapture='';
            var Times='';
            // var captureLists=data.Imagelist;
            if(data!=''&&data!=null&&data.length>0){
                for(let item of data){
                    var time=item.createtime; // /Date(158 572 227 7000)/
                    if(time==''||time==null){
                        Times=''
                    }else{
                            var s1 = time.substring(6,19);
                            Times=times(s1);
                    }
                    htmlCapture+=`<li onclick="left_module3_bigImg(`+ JSON.stringify(item.recordid).replace(/"/g, '&quot;') +`)">
                        <div class="pic">
                            <img src="${item.image1}" alt="" class="img1">
                            <img src="${item.image0}" alt="" class="img2">
                        </div>
                        <p class="text">${Times}</p>
                    </li>`;
                }
                
            }
            $("#captureUl").html(htmlCapture);
        },
        error:function(err){
                console.log(err)
        }

    });
};
$("#captureUl").on("click","li",function(){

});
// 预设点
function ysdAllVideo(machineid,ysdnameBj){
    if(machineid=="" ||machineid==null||machineid==undefined||machineid=="null"){
        machineid='';
    }
    if(ysdnameBj=="" ||ysdnameBj==null||ysdnameBj==undefined||ysdnameBj=="null"){
        ysdnameBj='';
    }
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/getYsdinforBymachine',
        dataType:'JSON',
        data:{
            machineid:machineid,
            doysdname:ysdnameBj
        },
        success:function(data){
            var htmlYsd='';
            var  ysdids='',distances='';
            if(data!=''&&data!=null){
                data.forEach( ( item, i )=>{
                    htmlYsd+=`<li class="layui-nav-item layui-nav-itemed">`;
                    if(item.show==1){
                        htmlYsd+=`<img src="../images/selJB.png" class="likeYsdname layui-icon" /> `;
                    }else{
                        htmlYsd+=``;
                    }
                    if(item.ysdid!=null){
                        ysdids=item.ysdid;
                    }else{
                        ysdids='';
                    }
                    if(item.distance!=null){
                        distances=item.distance;
                    }else{
                        distances='';
                    }
                    
                    htmlYsd+=`<a href="javaScript:void(0);">
                            <div class="name fl" id="deviceAll" data-ysdid="${ysdids}">${item.ysdname}</div>
                            <div class="operate fr">
                                <span class="on1" id="runningYsd" data-ysdindex="${i}" data-machineid="${item.machineid}" data-ysdname="${item.ysdname}">调用</span> |
                                <span class="on2" id="setYsd" data-machineid="${item.machineid}" data-ysdindex="${i}" data-distance="${distances}">设定</span> |
                                <span class="add_device" data-machineid="${item.machineid}" data-ysdid="${ysdids}">添加设备</span> |
                                <span class="on3" data-machineid="${item.machineid}" id="deleteYsd" data-ysdindex="${i}">删除</span>
                            </div>
                        </a>
                        <dl class="layui-nav-child" id="ysdDevice" style="display:none;"></dl>
                    </li>`;
                })
                $("#ysdAllVideoUl").html(htmlYsd);
            };
        },
        error:function(err){
                console.log(err)
        }

    });
};
$("#ysdAllVideoUl").on("click","li a #deviceAll",function(){
    $("#ysdAllVideoUl #ysdDevice").html('');
    $(this).parent().parent().find("#ysdDevice").show();
    $(this).parent().parent().siblings().find("#ysdDevice").hide();
    var ysdid=$(this).attr("data-ysdid");
    ysdDeviceVideo(ysdid);
})
// 预设点下的区域
function ysdDeviceVideo(ysdid){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/getdeviceBuysd',
        dataType:'JSON',
        data:{
            ysdid:ysdid
        },
        success:function(data){
            var htmlDevice='';
            // var captureLists=data.Imagelist;
            if(data!=''&&data!=null){
                data.forEach( ( item, i )=>{
                    htmlDevice+=`<dd>
                        <span class="fl"> 区域${i+1}：${item.devicename}</span>
                        <div class="fr">
                            <span id="modifyAreaDevice" data-devicename=${item.devicename} data-deviceid=${item.deviceid} data-ysdindex=${item.ysdindex}>重命名</span> |
                            <span id="deleteAreaDevice" data-deviceid=${item.deviceid} data-ysdindex=${item.ysdindex}>删除</span>
                        </div>
                    </dd>`;
                });
                
            }else{
                htmlDevice+=`<dd>暂无区域
                </dd>`;
            }
            $("#ysdAllVideoUl #ysdDevice").html(htmlDevice);
        },
        error:function(err){
                console.log(err)
        }

    });
}
// 接口描述：重命名
function modifyDeviceName(deviceId,deviceName,ysdidModify){
    $.ajax({
        type:'get',
        url:baseUrl+'ConfigTool/ConfigService.asmx/modifyDeviceNamed',
        dataType:'JSON',
        data:{
            deviceID:deviceId,
            deviceName:deviceName
        },
        success:function(data){
            if(data[0].msg=="修改成功"){
                layer.msg(data[0].msg, {
                    icon: 1
                    ,time: 1000
                });
                ysdDeviceVideo(ysdidModify);//刷新
            }else{
                layer.msg(data[0].msg, {
                    icon: 2
                    ,time: 1000
                });
            }
            
        },
        error:function(err){
            alert("网络错误,请联系技术人员");
        }

    });
};

function onRegionModeChange(mode) {
    switch (mode) {
        case 0:
            $("#deleteCanvas").attr("disabled",true);//删除区域
            $("#deleteCanvas").addClass("notCup");
            $("#tijiao").attr("disabled",true); //提交区域
            $("#tijiao").addClass("notCup");
            $("#save").attr("disabled",true); //保存
            $("#save").addClass("notCup");
            if(hasVideos!=3&&hasVideos!=2){
                var res = sessionStorage.datas;//取出首页请求的时候保存的数据
                var datas = $.parseJSON(res);
                var ysdIndexArea=datas.Ysdname;
                var machinemac=datas.Machinemac;
                // picShow(ysdidarea);
                picShow(machinemac,ysdIndexArea);
            }
           
            break;
        case 1:
            $("#deleteCanvas").removeAttr("disabled");//删除区域
            $("#deleteCanvas").removeClass("notCup");
            $("#tijiao").removeAttr("disabled"); //提交区域
            $("#tijiao").removeClass("notCup");
            $("#save").removeAttr("disabled"); //保存
            $("#save").removeClass("notCup");
            // var can = document.getElementById("canvas");
            // var ctx = can.getContext('2d');
            // var canSave = document.getElementById("canvasSave");
            // var ctxSave = canSave.getContext('2d');
            // ctx.clearRect(0, 0, can.width, can.height);
            // ctxSave.clearRect(0, 0, canSave.width, canSave.height);
            // var pointArr = [];
            
            break;
    }
}

/*清空选区*/
$('#deleteCanvas').click(function () {
        var areasGrid=$("#areas").val();
        var rectindex='';
        if(areasGrid==''||areasGrid==null||areasGrid==undefined||areasGrid=="请选择"){
            var can = document.getElementById("canvas");
            var ctx = can.getContext('2d');
            var canSave = document.getElementById("canvasSave");
            var ctxSave = canSave.getContext('2d');
            ctx.clearRect(0, 0, can.width, can.height);
            ctxSave.clearRect(0, 0, canSave.width, canSave.height);
            var pointArr = [];
            // rectindex=1;
            // var deviceid=Util.getUrlParam('deviceid');
            $.ajax({
                type:'get',
                url:baseUrl+'ConfigTool/ConfigService.asmx/removeAllRect',
                dataType:'JSON',
                traditional : true,
                data:{
                    ysdindex:ysdIndexArea,
                    machinemac:machinemac
                    // ,deviceID:deviceid,
                },
                success:function(data){
                    layer.msg(data[0].msg, {
                        offset: '15px'
                        ,icon: 1
                        ,time: 1000
                    });
                },
                error:function(err){
                        console.log(err)
                }

            });
        
        }else{
            // var deviceid=Util.getUrlParam('deviceid');
            // $("#areas").attr("data-index")
            // rectindex=1;
            $.ajax({
                type:'get',
                url:baseUrl+'ConfigTool/ConfigService.asmx/removeRect',
                dataType:'JSON',
                traditional : true,
                data:{
                    machinemac:machinemac,
                    ysdindex:ysdIndexArea,
                    pointlist:areasGrid
                    // deviceID:deviceid,
                },
                success:function(data){
                    layer.msg(data[0].msg, {
                        offset: '15px'
                        ,icon: 1
                        ,time: 1000
                    });
                    var can = document.getElementById("canvas");
                    var ctx = can.getContext('2d');
                    var canSave = document.getElementById("canvasSave");
                    var ctxSave = canSave.getContext('2d');
                    ctx.clearRect(0, 0, can.width, can.height);
                    ctxSave.clearRect(0, 0, canSave.width, canSave.height);
                    picShow(machinemac,ysdIndexArea); 
                },
                error:function(err){
                        console.log(err)
                }

            });
        }
});

