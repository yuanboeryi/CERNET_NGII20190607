var unSelected = "rgba(255, 255, 255, 0.6);";
var selected = "#fff";
var userid='';
var dianliId='';
var targetList=[];
var areaidEdit='',fenbuidEdit='',ywbidEdit='',stationidEdit='',hongwaiId='',ysdidEdit='';
$(document).ready(function () {
    var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
    var datas = $.parseJSON(Arr);
    userid=datas.Userid;
    $("select").css("color", unSelected);
    $("option").css("color", selected);
    
    $("select").change(function () {
        var selItem = $(this).val();
        if (selItem == $(this).find('option:first').val()) {
            $(this).css("color", unSelected);
        } else {
            $(this).css("color", selected);
        }
    });
    layui.use(['table','layer',"form","upload"], function(){
        var layer = layui.layer;
        var form = layui.form;
        var table = layui.table;
		var upload = layui.upload;
		
		//台账统计
		$(".account_statistics").on("click",function(){
			var url = 'account_statistics.html?id='+ userid;
			Util.popFullScreen2('',1200,900,url);
		})
		//失联统计
		$(".device_statistics").on('click',function(){
			var url = 'lostContact_statistics.html';
			Util.popFullScreen2('',1200,900,url);
		})
		//关闭 查看失联统计
		$(".editAbnormal .btn0").click(function(){
			$(".editAbnormal").hide();
		})
        //设备状态
        $(".device_status").on('click',function(){
            Util.popFullScreen3(100,100,"device_status.html");
        });
        //设备管理
        $(".device_manage").on('click',function(){
            Util.popFullScreen3(100,100,"device_manage.html");
        });
        // 导出
        $(".export").on('click',function(){
            $.ajax({
                type:'get',
                url:baseUrl+'ReportServic/reportServices.asmx/ExportDeviceToExcel',
                dataType:'JSON',  
                data:{
                    userid:userid
                },
                success:function(data){
                    layer.msg(data[0].msg, {time:500});
                    window.location.href = data[0].msg;
                },
                error:function(err){
                        console.log(err)
                }

            });
        });
        

        //监听工具条  系统设置 实时监测 、重点监测、启用
        table.on('tool(test_set)', function(obj){
            var data = obj.data;
            let event = obj.event;
            // 实时监测
            if (event == "viewRoundpoint"){
                var deviceid=data.deviceid;//设备id
                //设定或者取消该设备为实时监测设备 
                //isround=1表示实时监测，isround=0表示非实时监测
                var isrounds=data.isroundpoint;
                if(isrounds==1){
                        var isround=0;
                }else{
                        var isround=1;
                }
                $.ajax({
                    type:'get',
                    url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/setrounddevice',
                    dataType:'JSON',
                    data:{
                        deviceid:deviceid,
                        isround:isround

                    },
                    success:function(data){
                        layer.msg(data[0].msg,{
                                icon : 1,
                                time : 1000
                        });
                        table.reload("test_set");

                    },
                    error:function(err){
                        console.log(err)
                    }

                });
            };
            // 重点监测
            if (event == "viewKeypoint"){
                var stationid=data.stationid;//变电站id
                var deviceid=data.deviceid;//设备id
                //设定或者取消该设备为重点监测设备 
                //iskey=1表示重点监测,iskey=0表示非重点监测
                var iskeys=data.iskeypoint;
                    if(iskeys==1){
                    var iskey=0;
                }else{
                    var iskey=1;
                }
                $.ajax({
                    type:'get',
                    url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/setkeypointdevice',
                    dataType:'JSON',
                    data:{
                        deviceid:deviceid,
                        stationid:stationid,
                        iskey:iskey

                    },
                    success:function(data){

                        layer.msg(data[0].msg,{
                        icon : 1,
                        time : 1000
                        });
                        table.reload("test_set");

                    },
                    error:function(err){
                        console.log(err)
                    }

                });
            };
            // 启用
            if(event == "viewOpen"){
                var deviceid=data.deviceid;//设备id
                //设定或者取消该设备为启用设备 
                //启用或禁用设备 isopen=1表示启用，isopen=0表示禁用
                var isopens=data.isopen;
                if(isopens==1){
                    var isopen=0;
                }else{
                    var isopen=1;
                }
                $.ajax({
                    type:'get',
                    url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/setopendevice',
                    dataType:'JSON',
                    data:{
                        deviceid:deviceid,
                        isopen:isopen

                    },
                    success:function(data){

                        layer.msg(data[0].msg,{
                        icon : 1,
                        time : 1000
                        });
                        table.reload("test_set");

                    },
                    error:function(err){
                        console.log(err)
                    }

                });
            }
        });

        var machineid='';
        //设备状态
        table.on('tool(test_stu)', function(obj){
            var data = obj.data;
            let event = obj.event;
            console.log(data)
            if(event === 'edit'){
                //修改    巡视抓拍设置
                $(".zhuapai_tanchu").show();
                machineid=data.machineid;
                //巡视周期
                $("#xunshizhouqi option").each(function(){
                    if($(this).val()==data.newversion){
                            $(this).attr('selected',true)
                    }
                });
                //z抓拍周期
                $("#zhuapaizhouqi option").each(function(){
                    if($(this).val()==data.imagecatchspan){
                            $(this).attr('selected',true)
                    }
                });
                $("#editStu_devices1").val(data.machinecode);//编号
                $("#editStu_devices2").val(data.machinemac);//mac地址
                // $("#editStu_devices3").val(data.fluxtype);//流量类型
                $("#editStu_devices3 option").each(function(){
                    if($(this).val()==data.fluxtype){
                            $(this).attr('selected',true)
                    }
                });
                $("#editStu_devices4").val(data.fluxNumber);//流量卡号
				$("#editStu_devices5").val(data.SceneWifi);//现场wifi
                form.render('select');//需要渲染一下
            };
             // 更换
            // if(event === 'upDate'){
            //     machineid=data.machineid;
            //     $(".updateCode_tanchu").show();
            // };
            // // 拆除
            // if(event === 'del'){
            //     layer.confirm('确认拆除', {
            //         title: false,
            //         closeBtn: 0, //不显示关闭按钮
            //         btn: ['确认', '取消'],
            //         area: ['478px', '172px'],
            //   },function(index){
            //     var machinemac="";
            //     var machinecode="";
            //     var machineid=data.machineid;
            //     updateDeviceMac(machineid,machinemac,machinecode,index);
            // },function (index) {//cancel回调
            //     layer.close(index);
            // });
            // };
            // 在线下线
            if (event == "onOffLine"){
                var machineId=data.machineid;//设备id
                //设定或者取消
                //isline=1表示上线,isline=0表示下线
                var islines=data.isOpen;
                    if(islines==1){
                    var isline=0;
                }else{
                    var isline=1;
                }
                $.ajax({
                    type:'get',
                    url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/setopenMachine',
                    dataType:'JSON',
                    data:{
                        machineId:machineId,
                        isopen:isline
                    },
                    success:function(data){
                        layer.msg(data[0].msg,{time:500});
                        table.reload("test_stu");
                    },
                    error:function(err){
                        console.log(err)
                    }

                });
            };


        });
		//点击修改弹框的 拆除 按钮
		$(".zhuapai_tanchu").on("click",".offline",function(){
			$("#editStu_devices1").val('');
			$("#editStu_devices2").val('');
		});
        //巡视抓拍设置确定
        $(".zhuapai_editSet .btn0").click(function(){
            var xunshiSpan=$("#xunshizhouqi").val();
            var catchSpan=$("#zhuapaizhouqi").val();
            var machinecode=$("#editStu_devices1").val();
            var machinemac=$("#editStu_devices2").val();
            var fluxType=$("#editStu_devices3").val();
            var fluxNumber=$("#editStu_devices4").val();
			var SceneWifi=$("#editStu_devices5").val();
            catchSpan_xunshiSpan(machineid,catchSpan,xunshiSpan,machinemac,machinecode,fluxType,fluxNumber,SceneWifi)
            $(".zhuapai_tanchu").css("display","none");
            table.reload("test_stu");
        });
        //巡视抓拍设置取消
        $(".zhuapai_editSet .btn1").click(function(){
            $(".zhuapai_tanchu").css("display","none");
        });
        //更换设置确定
        $(".updateCode_tanchu .btn0").click(function(){
            var machinecode=$("#Updete_devices1").val();
            var machinemac=$("#Updete_devices2").val();
            var index='';
            if(machinecode==''||machinemac==''){
                alert("请输入");
                return;
            }
            updateDeviceMac(machineid,machinemac,machinecode,index);
            $(".updateCode_tanchu").css("display","none");
            table.reload("test_stu");
        });
        //更换设置取消
        $(".updateCode_tanchu .btn1").click(function(){
            $(".updateCode_tanchu").css("display","none");
        });
        




        var active = {
            getCheckDevice: function(){
                // 确认所选
                var checkStatus = table.checkStatus('test_stu')
                ,checkData = checkStatus.data; //得到选中的数据
                var obj = {};
                var machinemac='';
                var deviceID='';
                for(var i = 0; i < checkData.length; i++){
                    machinemac= checkData[i].machinemac;
                    deviceID= checkData[i].machineid;
                    obj = {machinemac: machinemac,deviceID:deviceID};
                    targetList.push(obj);
                }
                if(checkData.length === 0){
                    return alert('请选择更新设备');
                };
                if(checkData.length === 1){
                    // 单个确认告警确定
                    $(".updataDevice_tanchu").css("display","block");
                }else{
                    $(".updataDevice_tanchu").css("display","block");
                }
            },
            getCheckFtp: function(){
                // 确认所选
                var checkStatus = table.checkStatus('test_stu')
                ,checkData = checkStatus.data; //得到选中的数据
                var obj = {};
                var machinemac='';
                var deviceID='';
                for(var i = 0; i < checkData.length; i++){
                    machinemac= checkData[i].machinemac;
                    deviceID= checkData[i].machineid;
                    obj = {machinemac: machinemac,deviceID:deviceID};
                    targetList.push(obj);
                }
                if(checkData.length === 0){
                    return alert('请选择更新Ftp');
                };
                if(checkData.length === 1){
                    // 单个确认告警确定
                    $(".updataFtp_tanchu").css("display","block");
                }else{
                    $(".updataFtp_tanchu").css("display","block");
                }
            }
        };
        $('.layui-btn.btn-top').on('click', function(){
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });
        // 设备更新确定
        $(".updataDevice_tanchu .btn0").click(function(){
            var programName=$("#edit_devices1").val();
            var programSize=$("#edit_devices2").val();
            updataDevice(targetList,programName,programSize);
            $(".updataDevice_tanchu").css("display","none");
            //刷新
            // location.reload("#test_app");
        })
        // 设备更新取消
        $(".updataDevice_tanchu .btn1").click(function(){
            $(".updataDevice_tanchu").css("display","none");
        });

        // ftp更新确定
        $(".updataFtp_tanchu .btn0").click(function(){
            var Cloud_addr=$("#edit_Ftp1").val();
            var ftp_addr=$("#edit_Ftp2").val();
            updataFtp(targetList,Cloud_addr,ftp_addr);
            $(".updataFtp_tanchu").css("display","none");
            //刷新
            // location.reload("#test_app");
        })
        // ftp更新取消
        $(".updataFtp_tanchu .btn1").click(function(){
            $(".updataFtp_tanchu").css("display","none");
        });



        //第三个   app更新实例
        table.render({
            elem: '#test_app'
            ,height: 800
            ,url: baseUrl+'AppVersionService/AppversionService.asmx/getAppList' //数据接口
            ,parseData:function(res){
                return{
                    "code":0
                    ,"mag":0
                    ,"count":res.count
                    ,"data":res.dt
                }
            }
            ,cols: [[ //表头
                {type:'checkbox', width:'5%'}
                ,{field: '', title: '序号', width:'10%',sort: true,type:'numbers'}
                ,{field: 'version_no', title: '版本号',width:'10%'}
                ,{field: 'version_note', title: '更新说明', width:'20%'} 
                ,{field: 'download_url', title: '下载地址', width:'20%',templet: function(res){
                        return '<a href="'+res.download_url+'">'+ "点击下载" +'</a>'
                }}
                ,{field: 'createtime', title: '发布日期', width:'20%',templet: function(res){
                    var Times='';
                    var time=res.createtime;
					
                    if(res.createtime==null||res.createtime==''){
                        Times='';
                    }else{
                        var s2 = time.substring(0,10);
						s2 += " " + time.substring(11);
                        Times = s2;
                    }
                    return Times;
                }}
                ,{field: 'isopen', title: '启用', width:'15%',templet:function(data){
                    if(data.isopen==1){
                        //启用
                      var isopen="<span class='ls'><i class='right layui-icon layui-icon-ok'></i></span>"
                    }else{
                      var isopen="<span class='hs'><i class='error layui-icon layui-icon-close'></i></span>"
                    }
                    return isopen
                },event: 'appisopenEvent'}
            ]]
            ,page: true //开启分页
        });
        //监听工具条  启用
        table.on('tool(test_app)', function(obj){
            var data = obj.data;
            let event = obj.event;
            
            // 启用
            if(event == "appisopenEvent"){
                var id=data.id;//设备id
                //启用或者禁用版本号，
                //id，isopen【id=版本id，isopen=0或者1,0表示禁用，1表示启用】
                var isopens=data.isopen;
                if(isopens==1){
                    var isopen=0;
                }else if(isopens==0){
                    var isopen=1;
                }else{
                    return;
                }
                $.ajax({
                    type:'get',
                    url:baseUrl+'AppVersionService/AppversionService.asmx/setIsopen',
                    dataType:'JSON',
                    data:{
                        id:id,
                        isopen:isopen
                    },
                    success:function(data){

                        layer.msg(data[0].msg,{
                            icon : 1,
                            time : 1000
                        });
                        table.reload("test_app");
                    },
                    error:function(err){
                        console.log(err)
                    }

                });
            }
        });
        // app 添加应用
        $(".add_appBtn").on('click',function(){
            $(".add_appC").show();
        });
        // 添加app确定
        $(".add_appC .btn0").click(function(){
            var versionNo=$("#add_app1").val();
            var UpdateMsg=$("#add_app2").val();
            var targetPlaform=$("#add_app3").val();
			var fileBase= $('#add_app4')[0].files[0];
			
			var formData = new FormData();
			
			formData.append("versionNo", versionNo);
			formData.append("UpdateMsg", UpdateMsg);
			formData.append("targetPlaform", targetPlaform);
			formData.append("fileBase",$('#add_app4')[0].files[0]);
				
   //          var fileBase=$("#add_app4").val();
            if(versionNo == '' || UpdateMsg == '' || targetPlaform =='' || fileBase == ''){
				alert("参数不能为空"); 
			}else{
                add_app(formData);
                $(".add_appC").css("display","none");
			}
            
        })
        // 添加app取消
        $(".add_appC .btn1").click(function(){
            $(".add_appC").css("display","none");
        });
        
        

        // 设备管理
        
        //下拉框填充
        // 运维班添加/修改
        //运维班
        $("#addywb1").on("change",function(){
            var areaid=$("#addywb1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_editywb1").on("change",function(){
            var areaid=$("#device_editywb1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });

        // 变电站添加/修改
        $("#addbdz1").on("change",function(){
            var areaid=$("#addbdz1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_editbdz1").on("change",function(){
            var areaid=$("#device_editbdz1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#addbdz2").on("change",function(){
            var fenbuid=$("#addbdz2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        $("#device_editbdz2").on("change",function(){
            var fenbuid=$("#device_editbdz2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });

        
        // 设备区添加/修改

        $("#device_addsbj1").on("change",function(){
            var areaid=$("#device_addsbj1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_editsbj1").on("change",function(){
            var areaid=$("#device_editsbj1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_addsbj2").on("change",function(){
            var fenbuid=$("#device_addsbj2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        $("#device_editsbj2").on("change",function(){
            var fenbuid=$("#device_editsbj2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        $("#device_addsbj3").on("change",function(){
            var ywbid=$("#device_addsbj3 option:selected").attr("data-ywbid");
            sel_bdzname(ywbid);
        });
        $("#device_editsbj3").on("change",function(){
            var ywbid=$("#device_editsbj3 option:selected").attr("data-ywbid");
            sel_bdzname(ywbid);
        });
        

        // 监控器（抓拍设备）添加\修改
        //分部
        $("#device_addjkq1").on("change",function(){
            var areaid=$("#device_addjkq1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_editjkq1").on("change",function(){
            var areaid=$("#device_editjkq1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        //运维班
        $("#device_addjkq2").on("change",function(){
            var fenbuid=$("#device_addjkq2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        $("#device_editjkq2").on("change",function(){
            var fenbuid=$("#device_editjkq2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        //变电站
        $("#device_addjkq3").on("change",function(){
            var ywbid=$("#device_addjkq3 option:selected").attr("data-ywbid");
            sel_bdzname(ywbid);
        });
        $("#device_editjkq3").on("change",function(){
            var ywbid=$("#device_editjkq3 option:selected").attr("data-ywbid");
            sel_bdzname(ywbid);
        });
        //设备区
        $("#device_addjkq4").on("change",function(){
            var stationid=$("#device_addjkq4 option:selected").attr("data-stationid");
            sel_sbqname(stationid)
        });
        $("#device_editjkq4").on("change",function(){
            var stationid=$("#device_editjkq4 option:selected").attr("data-stationid");
            sel_sbqname(stationid)
        });

        // 预设点添加\修改
        //分部
        $("#device_addysd1").on("change",function(){
            var areaid=$("#device_addysd1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_editysd1").on("change",function(){
            var areaid=$("#device_editysd1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        //运维班
        $("#device_addysd2").on("change",function(){
            var fenbuid=$("#device_addysd2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        $("#device_editysd2").on("change",function(){
            var fenbuid=$("#device_editysd2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        //变电站
        $("#device_addysd3").on("change",function(){
            var ywbid=$("#device_addysd3 option:selected").attr("data-ywbid");
            sel_bdzname(ywbid);
        });
        $("#device_editysd3").on("change",function(){
            var ywbid=$("#device_editysd3 option:selected").attr("data-ywbid");
            sel_bdzname(ywbid);
        });
        //设备区
        $("#device_addysd4").on("change",function(){
            var stationid=$("#device_addysd4 option:selected").attr("data-stationid");
            sel_sbqname(stationid)
        });
        $("#device_editysd4").on("change",function(){
            var stationid=$("#device_editysd4 option:selected").attr("data-stationid");
            sel_sbqname(stationid)
        });
        //监控器
        $("#device_addysd5").on("change",function(){
            var buildingid=$("#device_addysd5 option:selected").attr("data-buildingid");
            sel_jkqname(buildingid)
        });
        $("#device_editysd5").on("change",function(){
            var buildingid=$("#device_editysd5 option:selected").attr("data-buildingid");
            sel_jkqname(buildingid)
        });
        // 预设点类型
        $("#device_addysd6").on("change",function(){
            var machineid=$("#device_addysd6 option:selected").attr("data-machineid");
            machine_ysdType(machineid);
        });
        $("#device_editysd6").on("change",function(){
            var machineid=$("#device_editysd6 option:selected").attr("data-machineid");
            machine_ysdType(machineid);
        });
        
        // 监测设备添加\修改
        //分部
        $("#device_addshebei1").on("change",function(){
            var areaid=$("#device_addshebei1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_editshebei1").on("change",function(){
            var areaid=$("#device_editshebei1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        //运维班
        $("#device_addshebei2").on("change",function(){
            var fenbuid=$("#device_addshebei2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        $("#device_editshebei2").on("change",function(){
            var fenbuid=$("#device_editshebei2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        //变电站
        $("#device_addshebei3").on("change",function(){
            var ywbid=$("#device_addshebei3 option:selected").attr("data-ywbid");
            sel_bdzname(ywbid);
        });
        $("#device_editshebei3").on("change",function(){
            var ywbid=$("#device_editshebei3 option:selected").attr("data-ywbid");
            sel_bdzname(ywbid);
        });
        //设备区
        $("#device_addshebei4").on("change",function(){
            var stationid=$("#device_addshebei4 option:selected").attr("data-stationid");
            sel_sbqname(stationid)
        });
        $("#device_editshebei4").on("change",function(){
            var stationid=$("#device_editshebei4 option:selected").attr("data-stationid");
            sel_sbqname(stationid)
        });
        //监控器
        $("#device_addshebei5").on("change",function(){
            var buildingid=$("#device_addshebei5 option:selected").attr("data-buildingid");
            sel_jkqname(buildingid)
        });
        $("#device_editshebei5").on("change",function(){
            var buildingid=$("#device_editshebei5 option:selected").attr("data-buildingid");
            sel_jkqname(buildingid)
        });
        //预设点编号（名称）
        $("#device_addshebei6").on("change",function(){
            var machineid=$("#device_addshebei6 option:selected").attr("data-machineid");
            sel_ysdname(machineid)
        });
        $("#device_editshebei6").on("change",function(){
            var machineid=$("#device_editshebei6 option:selected").attr("data-machineid");
            sel_ysdname(machineid)
        });

      //工区  修改、删除、添加 的事件

        var active_area = {
            edit: function(areaid){
                $(".area_edit").show();
                device_getAreaNows(areaid); //当前工区信息
            },
            del: function(areaid){
                layer.confirm('确认删除', {
                    title: false,
                    closeBtn: 0, //不显示关闭按钮
                    id: 'del1', //设定一个id，防止重复弹出
                    btn: ['确认', '取消'],
                    area: ['478px', '172px'],},
                    function (index) {
                        device_delArea(areaid);
                        setTimeout(function(){
                            device_getAreaAll(userid);
                        },500);
                        layer.close(index);
                    },function (index) {//cancel回调
                        layer.close(index);
                }); 
            }
        };
        $('#gq_ul').on('click',".area_event", function(){
            var type = $(this).data('event');
            areaidEdit=$(this).attr("data-areaid"); //工区名字
            active_area[type] ? active_area[type].call(this,areaidEdit) : '';  //传参
        });
        //添加工区
        $(".add_btn1").on('click',function(){
            $(".area_add").show();
        });
        
        // 添加工区确定
        $(".area_add .btn0").click(function(){
            var areaname=$("#add_area1").val();
            var manager=$("#add_area2").val();
            var phone=$("#add_area3").val();
            var city=$("#add_area4").val();
            var address=$("#add_area5").val();
			var shortname=$("#add_area6").val();
            device_addArea(areaname,manager,phone,city,address,shortname);
            setTimeout(function(){
                device_getAreaAll(userid);
            },500);
            $(".area_add").css("display","none");
        })
        // 添加工区取消
        $(".area_add .btn1").click(function(){
            $(".area_add").css("display","none");
        });
        // 修改工区确定
        $(".area_edit .btn0").click(function(){
            var areaname=$("#device_editArea1").val();
            var manager=$("#device_editArea2").val();
            var phone=$("#device_editArea3").val();
            var city=$("#device_editArea4").val();
            var address=$("#device_editArea5").val();
			var shortname=$("#device_editArea6").val();
            device_editArea(areaidEdit,areaname,manager,phone,city,address,shortname)
            $(".area_edit").css("display","none");
        })
        // 修改工区取消
        $(".area_edit .btn1").click(function(){
            $(".area_edit").css("display","none");
        });



        //分部  修改、删除、添加 的事件
        var active_fb = {
            edit: function(fenbuid){
                device_getFenbuNows(fenbuid); //当前分部信息
                $(".fenbu_editC").show();
                sel_areaname(userid);
            },
            del: function(fenbuid){
                layer.confirm('确认删除', {
                title: false,
                closeBtn: 0, //不显示关闭按钮
                id: 'del2', //设定一个id，防止重复弹出
                btn: ['确认', '取消'],
                area: ['478px', '172px'],},
                function (index) {
                    device_delFenbu(fenbuid);
                    if($("#manageArea .select").text()=="全部"){
                        setTimeout(function(){
                            device_getFenbuAll(userid);
                        },500);
                    }else{
                        var areaid=$("#manageArea .select").attr("data-areaid");
                        setTimeout(function(){
                            getfenbuAll(areaid);
                        },500);
                    };
                    layer.close(index);
                },function (index) {//cancel回调
                        layer.close(index);
                }); 
            }
        };
        $('#fenbu_ul').on('click',".fenbu_event", function(){
            var type = $(this).data('event');
            fenbuidEdit=$(this).attr("data-fenbuid"); //分部名字
            active_fb[type] ? active_fb[type].call(this,fenbuidEdit) : '';  //传参
        });
        //添加分部
        $(".add_btn2").on('click',function(){
            $(".fenbu_addC").show();
        });
        // 添加分部确定
        $(".fenbu_addC .btn0").click(function(){
            var areaid=$("#device_addFenbu1 option:selected").attr("data-areaid");
            var fenbuname=$("#device_addFenbu2").val();
            var manager=$("#device_addFenbu3").val();
            var phone=$("#device_addFenbu4").val();
            var address=$("#device_addFenbu5").val();
			var shortname=$("#device_addFenbu6").val();
            if(!areaid){
                areaid='';
            }
            device_addFenbu(areaid,fenbuname,manager,phone,address,shortname);
            
        })
        // 添加分部取消
        $(".fenbu_addC .btn1").click(function(){
            $(".fenbu_addC").css("display","none");
        });
        // 修改分部确定
        $(".fenbu_editC .btn0").click(function(){
            var areaid=$("#device_editFenbu1 option:selected").attr("data-areaid");
            // var areaname=$("#device_editFenbu1").val();
            var fenbuname=$("#device_editFenbu2").val();
            var manager=$("#device_editFenbu3").val();
            var phone=$("#device_editFenbu4").val();
            var address=$("#device_editFenbu5").val();
			var shortname=$("#device_editFenbu6").val();
            if(!areaid){
                areaid='';
            }
            device_editFenbu(areaid,fenbuidEdit,fenbuname, manager, phone, address,shortname)
            $(".fenbu_editC").css("display","none");
        })
        // 修改分部取消
        $(".fenbu_editC .btn1").click(function(){
            $(".fenbu_editC").css("display","none");
        });



      //运维班  修改、删除、添加 的事件
        var active_ywb = {
            edit: function(ywbid){
                device_getYwbNows(ywbid);
                $(".ywb_editC").show();
                sel_areaname(userid);
            },
            del: function(ywbid){
                layer.confirm('确认删除', {
                    title: false,
                    closeBtn: 0, //不显示关闭按钮
                    id: 'del3', //设定一个id，防止重复弹出
                    btn: ['确认', '取消'],
                    area: ['478px', '172px'],},
                    function (index) {
                        device_delywb(ywbid);
                        if($("#fenbu_ulDD .select").text()=="全部"){
                            setTimeout(function(){
                                getywbAll(userid);
                            },500);
                        }else{
                            var fenbuid=$("#fenbu_ulDD .select").attr("data-fenbuid");
                            setTimeout(function(){
                                fenbu_getywbAll(fenbuid);
                            },500);
                        };
                        layer.close(index);
                    },function (index) {//cancel回调
                            layer.close(index);
                }); 
            },

        };
        $('#ywb_ul').on('click',".ywb_event", function(){
            var type = $(this).data('event');
            ywbidEdit=$(this).attr("data-ywbid"); //运维班名字
            active_ywb[type] ? active_ywb[type].call(this,ywbidEdit) : '';  //传参
        });
        //添加运维班
        $(".add_btn3").on('click',function(){
            $(".ywb_addC").show();
        });
        // 添加运维班确定
        $(".ywb_addC .btn0").click(function(){
            // var areaname=$("#addywb1").val();
            // var fenbuname=$("#addywb2").val();
            var fenbuid=$("#addywb2 option:selected").attr("data-fenbuid");
            var ywbname=$("#addywb3").val();
            var manager=$("#addywb4").val();
            var phone=$("#addywb5").val();
            var address=$("#addywb6").val();
			var shortname=$("#addywb7").val();
            if(!fenbuid){
                fenbuid='';
            }
            device_addywb(fenbuid,ywbname,manager,phone,address,shortname);
        })
        // 添加运维班取消
        $(".ywb_addC .btn1").click(function(){
            $(".ywb_addC").css("display","none");
        });
        // 修改运维班确定
        $(".ywb_editC .btn0").click(function(){
            var fenbuid=$("#device_editywb2 option:selected").attr("data-fenbuid");
            var ywbname=$("#device_editywb3").val();
            var manager=$("#device_editywb4").val();
            var phone=$("#device_editywb5").val();
            var address=$("#device_editywb6").val();
			var shortname=$("#device_editywb7").val();
            if(!fenbuid){
                fenbuid='';
            }
            device_editywb(fenbuid,ywbidEdit,ywbname,manager,phone,address,shortname)
            $(".ywb_editC").css("display","none");
        })
        // 修改运维班取消
        $(".ywb_editC .btn1").click(function(){
            $(".ywb_editC").css("display","none");
        });


        //变电站  修改、删除、添加 的事件
        var active_bdz = {
            edit: function(stationid){
                device_getBdzNows(stationid);
                $(".bdz_editC").show();
                sel_areaname(userid);
            },
            del: function(stationid){
                layer.confirm('确认删除', {
                title: false,
                closeBtn: 0, //不显示关闭按钮
                id: 'del4', //设定一个id，防止重复弹出
                btn: ['确认', '取消'],
                area: ['478px', '172px'],},
                function (index) {
                        device_delbdz(stationid);
                        if($("#ywb_ulDD .select").text()=="全部"){
                            setTimeout(function(){
                                getbdzAll(userid);
                            },500);
                        }else{
                            var ywbid=$("#ywb_ulDD .select").attr("data-ywbid");
                            setTimeout(function(){
                                ywb_getbdzAll(ywbid);
                            },500);
                        };
                        layer.close(index);
                },function (index) {//cancel回调
                        layer.close(index);
                }); 
            },

        };
        $('#bdz_ul').on('click',".bdz_event", function(){
            var type = $(this).data('event');
            stationidEdit=$(this).attr("data-stationid"); //运维班名字
            active_bdz[type] ? active_bdz[type].call(this,stationidEdit) : '';  //传参
        });
        //添加变电站
        $(".add_btn4").on('click',function(){
            $(".bdz_addC").show();
            
        });
        // 添加变电站确定
        $(".bdz_addC .btn0").click(function(){
            // var areaname=$("#addbdz1").val();
            // var fenbuname=$("#addbdz2").val();
            // var ywbname=$("#addbdz3").val();
            var ywbid=$("#addbdz3 option:selected").attr("data-ywbid");
            var stationname=$("#addbdz4").val();
            var manager=$("#addbdz5").val();
            var phone=$("#addbdz6").val();
            var stationlevel=$("#addbdz7").val();
            var city=$("#addbdz8").val();
            var address=$("#addbdz9").val();
            var jingdu=$("#addbdz10").val();
            var weidu=$("#addbdz11").val();
			var shortname=$("#addbdz12").val();
            if(!ywbid){
                ywbid='';
            }
            device_addbdz(ywbid,stationname,manager,phone,stationlevel,city,address,jingdu,weidu,shortname);
            
            
        })
        // 添加变电站取消
        $(".bdz_addC .btn1").click(function(){
            $(".bdz_addC").css("display","none");
        });
        // 修改变电站确定
        $(".bdz_editC .btn0").click(function(){
            var ywbid=$("#device_editbdz3 option:selected").attr("data-ywbid");
            var stationname=$("#device_editbdz4").val();
            var manager=$("#device_editbdz5").val();
            var phone=$("#device_editbdz6").val();
            var stationlevel=$("#device_editbdz7").val();
            var city=$("#device_editbdz8").val();
            var address=$("#device_editbdz9").val();
            var jingdu=$("#device_editbdz10").val();
            var weidu=$("#device_editbdz11").val();
			var shortname=$("#device_editbdz12").val();
            if(!ywbid){
                ywbid='';
            }
            device_editbdz(ywbid,stationidEdit,stationname,manager,phone,stationlevel,city,address,jingdu,weidu,shortname)
            $(".bdz_editC").css("display","none");
        })
        // 修改变电站取消
        $(".bdz_editC .btn1").click(function(){
            $(".bdz_editC").css("display","none");
        });


        //设备区  修改、删除、添加 的事件
        var active_sbj = {
            edit: function(buildingid){
                device_getSbjNows(buildingid)
                $(".sbq_editC").show();
                sel_areaname(userid);
            },
            del: function(buildingid){
                layer.confirm('确认删除', {
                title: false,
                closeBtn: 0, //不显示关闭按钮
                id: 'del5', //设定一个id，防止重复弹出
                btn: ['确认', '取消'],
                area: ['478px', '172px'],},
                function (index) {
                        device_delSbj(buildingid);
                        if($("#bdz_ulDD .select").text()=="全部"){
                            setTimeout(function(){
                                getsbqAll(userid);
                            },500);
                        }else{
                            var stationid=$("#bdz_ulDD .select").attr("data-stationid");
                            setTimeout(function(){
                                bdz_getsbqAll(stationid);
                            },500);
                        };
                        layer.close(index);
                },function (index) {//cancel回调
                        layer.close(index);
                }); 
            },

        };
        $('#sbq_ul').on('click',".sbj_event", function(){
            var type = $(this).data('event');
            var buildingid=$(this).attr("data-buildingid"); //设备区名字
            active_sbj[type] ? active_sbj[type].call(this,buildingid) : '';  //传参
        });
        //添加设备区
        $(".add_btn5").on('click',function(){
            $(".sbq_addC").show();
            
            
        });
        
        // 添加设备区确定
        $(".sbq_addC .btn0").click(function(){
            // var areaname=$("#device_addsbj1").val();
            // var fenbuname=$("#device_addsbj2").val();
            // var ywbname=$("#device_addsbj3").val();
            var stationid=$("#device_addsbj4 option:selected").attr("data-stationid");;
            var buildingname=$("#device_addsbj5").val();
			var shortname=$("#device_addsbj6").val();
            if(!stationid){
                stationid='';
            }
            device_addSbj(stationid,buildingname,shortname)
            
        })
        // 添加设备区取消
        $(".sbq_addC .btn1").click(function(){
            $(".sbq_addC").css("display","none");
        });
        // 修改设备区确定
        $(".sbq_editC .btn0").click(function(){
            // var areaname=$("#device_editsbj1").val();
            // var fenbuname=$("#device_editsbj2").val();
            // var ywbname=$("#device_editsbj3").val();
            var stationid=$("#device_editsbj4 option:selected").attr("data-stationid");
            var buildingname=$("#device_editsbj5").val();
			var shortname=$("#device_editsbj6").val();
            var buildingid=$("#device_editsbj5").attr("data-id");
            if(!stationid){
                stationid='';
            }
            device_editSbj(stationid,buildingname,buildingid,shortname);
            $(".sbq_editC").css("display","none");
            
        })
        // 修改设备区取消
        $(".sbq_editC .btn1").click(function(){
            $(".sbq_editC").css("display","none");
        });

        //红外设备  修改、删除、添加 的事件
        var active_jkq = {
            edit: function(machineid){
                device_tl();//推流
                setTimeout(function(){
                    device_getJkqNows(machineid)
                },500);
                
                $(".jkq_editC").show();
                sel_areaname(userid);
                
            },
            del: function(machineid){
                layer.confirm('确认删除', {
                title: false,
                closeBtn: 0, //不显示关闭按钮
                id: 'del6', //设定一个id，防止重复弹出
                btn: ['确认', '取消'],
                area: ['478px', '172px'],},
                function (index) {
                    device_delJkq(machineid);
                    if($("#sbq_ulDD .select").text()=="全部"){
                        setTimeout(function(){
                            getjianshiAll(userid);
                        },500);
                    }else{
                        var buildingid=$("#sbq_ulDD .select").attr("data-buildingid");
                        setTimeout(function(){
                            sbq_getjianshiAll(buildingid);
                        },500);
                    };
                    layer.close(index);
                },function (index) {//cancel回调
                        layer.close(index);
                }); 
            },

        };
        $('#jkq_ul').on('click',".jkq_event", function(){
            var type = $(this).data('event');
            var machineid=$(this).attr("data-machineid"); //红外设备id
            hongwaiId=$(this).attr("data-machineid"); //红外设备id
            active_jkq[type] ? active_jkq[type].call(this,machineid) : '';  //传参
        });
        //添加红外设备
        $(".add_btn6").on('click',function(){
            $(".jkq_addC").show();
            sel_areaname(userid);
            device_tl();//推流
            var areaname_add=a;
            var fenbuname_add=b;
            var ywbname_add=c;
            var stationname_add=d;
            var buildingname_add=e;
            setTimeout(function(){
                $("#device_addjkq1 option").each(function(){
                        if($(this).val() ==areaname_add){
                                $(this).attr('selected',true)
                        }
                });
            },100);
            $("#device_addjkq2 option").each(function(){
                if($(this).val() ==fenbuname_add){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addjkq3 option").each(function(){
                if($(this).val() ==ywbname_add ){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addjkq4 option").each(function(){
                if($(this).val() ==stationname_add){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addjkq5 option").each(function(){
                if($(this).val() ==buildingname_add){
                        $(this).attr('selected',true)
                }
            });

            var areaid=aid;
            var fenbuid=bid;
            var ywbid=cid;
            var stationid=did;
            var buildingid=eid;
            // var machineid=fid;
            manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
        });
        // 流量卡号   编辑和添加
        // $("#device_addjkq15").on("change",function(){
        //     var fluxType=$("#device_addjkq15").val();
        //     if(fluxType=="4G版"){
        //         $(".fluxNumberAdd").show();
        //     }else{
        //         $(".fluxNumberAdd").hide();
        //     }
        // });
        // $("#device_editjkq15").on("change",function(){
        //     var fluxType=$("#device_editjkq15").val();
        //     if(fluxType=="4G版"){
        //         $(".fluxNumberEdit").show();
        //     }else{
        //         $(".fluxNumberEdit").hide();
        //     }
        // });
        // 添加红外设备确定
        $(".jkq_addC .btn0").click(function(){
            // var areaname=$("#device_addjkq1").val();
            // var fenbuname=$("#device_addjkq2").val();
            // var ywbname=$("#device_addjkq3").val();
            // var stationname=$("#device_addjkq4").val();
            // var buildingname=$("#device_addjkq5").val();
            var buildingid=$("#device_addjkq5 option:selected").attr("data-buildingid");
            var machinename=$("#device_addjkq6").val();
            var machinecompany=$("#device_addjkq7").val();
            var machinemac=$("#device_addjkq8").val();
            var machinecode=$("#device_addjkq9").val();
            var currentversion=$("#device_addjkq10").val();
            // var onlinetime=$("#device_addjkq11").val();
            // var fushelv=$("#device_addjkq12").val();
            var offsetvalue=0; //温度
            // var offsetvalue=$("#device_addjkq13").val();
            var machineip='';
            var mediaIndex=$("#device_addjkq14").val();
            var fluxType=$("#device_addjkq15").val();
            var fluxNumber=$("#device_addjkq16").val();
			var SceneWifi=$("#device_addjkq17").val();
            if(!buildingid){
                buildingid='';
            }
            device_addJkq(buildingid,machinename,machinecompany,machinemac,machinecode,currentversion,offsetvalue,machineip,mediaIndex,fluxType,fluxNumber,SceneWifi);
            
        })
        // 添加红外设备取消
        $(".jkq_addC .btn1").click(function(){
            $(".jkq_addC").css("display","none");
        });
        // 修改红外设备确定
        $(".jkq_editC .btn0").click(function(){
            // var areaname=$("#device_editjkq1").val();
            // var fenbuname=$("#device_editjkq2").val();
            // var ywbname=$("#device_editjkq3").val();
            // var stationname=$("#device_editjkq4").val();
            // var buildingname=$("#device_editjkq5").val();
            var buildingid=$("#device_editjkq5 option:selected").attr("data-buildingid");
            var machinename=$("#device_editjkq6").val();
            var machinecompany=$("#device_editjkq7").val();
            var machinemac=$("#device_editjkq8").val();
            var machinecode=$("#device_editjkq9").val();
            var currentversion=$("#device_editjkq10").val();
            // var onlinetime=$("#device_editjkq11").val();
            // var fushelv=$("#device_editjkq12").val();
            var offsetvalue=0;//$("#device_editjkq13").val()
            var machineip='';
            var mediaIndex=$("#device_editjkq14").val();
            var fluxType=$("#device_editjkq15").val();
            var fluxNumber=$("#device_editjkq16").val();
			var SceneWifi=$("#device_editjkq17").val();
            if(!buildingid){
                buildingid='';
            }
            device_editJkq(buildingid,hongwaiId,machinename,machinecompany,
                machinemac,machinecode,currentversion,offsetvalue,machineip,mediaIndex,fluxType,fluxNumber,SceneWifi);
            $(".jkq_editC").css("display","none");
        })
        // 修改红外设备取消
        $(".jkq_editC .btn1").click(function(){
            $(".jkq_editC").css("display","none");
        });

        //预设点  修改、删除、添加 的事件
        var active_ysd = {
            edit: function(ysdid){
                device_getYsdNows(ysdid)
                $(".ysd_editC").show();
                sel_areaname(userid);
            },
            del: function(ysdid){
                layer.confirm('确认删除', {
                title: false,
                closeBtn: 0, //不显示关闭按钮
                id: 'del7', //设定一个id，防止重复弹出
                btn: ['确认', '取消'],
                area: ['478px', '172px'],},
                function (index) {
                        device_delYsd(ysdid);
                        var machineid=$("#jkq_ul .active").attr("data-machineid");
                        if(!machineid){
                            setTimeout(function(){
                                getysdAll(userid);
                            },500);
                        }else{
                            setTimeout(function(){
                                device_getYsdJkq(machineid);
                            },500);
                        };
                        
                        layer.close(index);
                        
                },function (index) {//cancel回调
                        layer.close(index);
                }); 
            },

        };
        $('#ysd_ul').on('click',".ysd_event", function(){
            var type = $(this).data('event');
            ysdidEdit=$(this).attr("data-ysdid"); //预设点id
            active_ysd[type] ? active_ysd[type].call(this,ysdidEdit) : '';  //传参
        });
        //添加预设点用户
        $(".add_btn7").on('click',function(){
            $(".ysd_addC").show();
            sel_areaname(userid);
            var areaname_add=a;
            var fenbuname_add=b;
            var ywbname_add=c;
            var stationname_add=d;
            var buildingname_add=e;
            var machinename_add=f;
            var machineid=fid;
            setTimeout(function(){
                $("#device_addysd1 option").each(function(){
                        if($(this).val() ==areaname_add ){
                                $(this).attr('selected',true)
                        }
                });
            },100);
            $("#device_addysd2 option").each(function(){
                if($(this).val() ==fenbuname_add ){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addysd3 option").each(function(){
                if($(this).val() ==ywbname_add ){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addysd4 option").each(function(){
                if($(this).val() ==stationname_add ){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addysd5 option").each(function(){
                if($(this).val() ==buildingname_add ){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addysd6 option").each(function(){
                if($(this).val() == machinename_add ){
                        $(this).attr('selected',true)
                }
            });
            machine_ysdType(machineid);
            var areaid=aid;
            var fenbuid=bid;
            var ywbid=cid;
            var stationid=did;
            var buildingid=eid;
            var machineid=fid;
            manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
        });
        // 添加预设点确定
        $(".ysd_addC .btn0").click(function(){
            // var areaname=$("#device_addysd1").val();
            // var fenbuname=$("#device_addysd2").val();
            // var ywbname=$("#device_addysd3").val();
            // var stationname=$("#device_addysd4").val();
            // var buildingname=$("#device_addysd5").val();
            var machineid=$("#device_addysd6 option:selected").attr("data-machineid");;
            var ysdNumbers=$("#device_addysd7").val();
            // var mode = $('input[name="nums"]:checked').val();
            if(!machineid){
                machineid='';
            }
            device_addYsd(machineid,ysdNumbers);
        });
        
        // 添加预设点取消
        $(".ysd_addC .btn1").click(function(){
            $(".ysd_addC").css("display","none");
        });
        // 修改预设点确定
        $(".ysd_editC .btn0").click(function(){
            // var areaname=$("#device_editysd1").val();
            // var fenbuname=$("#device_editysd2").val();
            // var ywbname=$("#device_editysd3").val();
            // var stationname=$("#device_editysd4").val();
            // var buildingname=$("#device_editysd5").val();
            // var machinename=$("#device_editysd6").val();
            var machineid=$("#device_editysd6 option:selected").attr("data-machineid");
            var ysdname=$("#device_editysd7").val();
            if(!machineid){
                machineid='';
            }
            device_editYsd(machineid,ysdidEdit,ysdname);
            
            $(".ysd_editC").css("display","none");
        })
        // 修改预设点取消
        $(".ysd_editC .btn1").click(function(){
            $(".ysd_editC").css("display","none");
        });


        //监测设备  修改、删除、添加 的事件
        var active_shebei = {
            edit: function(deviceid){
                device_getShebeiNows(deviceid);
                $(".shebei_editC").show();
                sel_areaname(userid);
            },
            del: function(deviceid){
                layer.confirm('确认删除', {
                title: false,
                closeBtn: 0, //不显示关闭按钮
                id: 'del7', //设定一个id，防止重复弹出
                btn: ['确认', '取消'],
                area: ['478px', '172px'],},
                function (index) {
                    device_delShebei(deviceid);
                    var ysdid=$("#ysd_ul .active").attr("data-ysdid");
                    if(!ysdid){
                        setTimeout(function(){
                            shebeiAll(userid);
                        },500);
                    }else{
                        setTimeout(function(){
                            device_getShebeiYsd(ysdid);
                        },500);
                    };
                    layer.close(index);
                },function (index) {//cancel回调
                        layer.close(index);
                }); 
            },

        };
        $('#shebei_ul').on('click',".shebei_event", function(){
            var type = $(this).data('event');
            var deviceid=$(this).attr("data-deviceid"); //设备id
            dianliId=$(this).attr("data-deviceid");
            active_shebei[type] ? active_shebei[type].call(this,deviceid) : '';  //传参
        });
        //添加监测设备
        $(".add_btn8").on('click',function(){
            // $("#device_addshebei1").empty();
            $(".shebei_addC").show();
            sel_areaname(userid);
            var areaname_add=a;
            var fenbuname_add=b;
            var ywbname_add=c;
            var stationname_add=d;
            var buildingname_add=e;
            var machinename_add=f;
            var devicename_add=g;
            setTimeout(function(){
                $("#device_addshebei1 option").each(function(){
                        if($(this).val() ==areaname_add){
                                $(this).attr('selected',true)
                        }
                });
            },100);
            $("#device_addshebei2 option").each(function(){
                if($(this).val() ==fenbuname_add){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addshebei3 option").each(function(){
                if($(this).val() ==ywbname_add){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addshebei4 option").each(function(){
                if($(this).val() ==stationname_add){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addshebei5 option").each(function(){
                if($(this).val() ==buildingname_add ){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addshebei6 option").each(function(){
                if($(this).val() == machinename_add){
                        $(this).attr('selected',true)
                }
            });
            $("#device_addshebei7 option").each(function(){
                if($(this).val() == devicename_add){
                        $(this).attr('selected',true)
                }
            });

            var areaid=aid;
            var fenbuid=bid;
            var ywbid=cid;
            var stationid=did;
            var buildingid=eid;
            var machineid=fid;
            manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
        });
        // 添加监测设备确定
        $(".shebei_addC .btn0").click(function(){
            // var areaname=$("#device_addshebei1").val();
            // var fenbuname=$("#device_addshebei2").val();
            // var ywbname=$("#device_addshebei3").val();
            // var stationname=$("#device_addshebei4").val();
            // var buildingname=$("#device_addshebei5").val();
            // var machinename=$("#device_addshebei6").val();
            var ysdid=$("#device_addshebei7 option:selected").attr("data-ysdid");
            var devicename=$("#device_addshebei8").val();
            // var distance=$("#device_addshebei9").val();
            var offsetvalue=$("#device_addshebei10").val();
            var ysdtype=$("#device_addshebei11").val();
            var ysdlevel=$("#device_addshebei12").val();
            var operaterNumber=$("#device_addshebei13").val();
			var distince=$("#device_addshebei14").val();
            if(!ysdid){
                ysdid='';
            }
			if(ysdid=='' || ysdid==undefined || devicename=="" || devicename==undefined ||ysdtype == ''||ysdtype == undefined || ysdlevel=='' || ysdlevel==undefined){
				layer.msg("请完善信息！")
				return;
			}
            device_addShebei(ysdid,devicename,offsetvalue, ysdtype, ysdlevel,operaterNumber,distince);
        })
        // 添加监测设备取消
        $(".shebei_addC .btn1").click(function(){
            $(".shebei_addC").css("display","none");
        });
        // 修改监测设备确定
        $(".shebei_editC .btn0").click(function(){
            // var areaname=$("#device_editshebei1").val();
            // var fenbuname=$("#device_editshebei2").val();
            // var ywbname=$("#device_editshebei3").val();
            // var stationname=$("#device_editshebei4").val();
            // var buildingname=$("#device_editshebei5").val();
            // var machinename=$("#device_editshebei6").val();
            // var ysdname=$("#device_editshebei7").val();
            var ysdid=$("#device_editshebei7 option:selected").attr("data-ysdid");
            var devicename=$("#device_editshebei8").val();
            // var distance=$("#device_editshebei9").val();
            // var fuhe=$("#device_editshebei10").val();
            var offsetvalue=$("#device_editshebei10").val();
            var ysdtype=$("#device_editshebei11").val();
            var ysdlevel=$("#device_editshebei12").val();
            var operaterNumber=$("#device_editshebei13").val();
			var distince=$("#device_editshebei14").val();
            if(!ysdid){
                ysdid='';
            }
			if(ysdid=='' || ysdid==undefined || devicename=="" || devicename==undefined ||ysdtype == ''||ysdtype == undefined || ysdlevel=='' || ysdlevel==undefined){
				layer.msg("请完善信息！")
				return;
			}
            device_editShebei(ysdid,dianliId,devicename,offsetvalue, ysdtype, ysdlevel,operaterNumber,distince);
            $(".shebei_editC").css("display","none");
        })
        // 修改监测设备取消
        $(".shebei_editC .btn1").click(function(){
            $(".shebei_editC").css("display","none");
        });

    });
});

// 修改
function catchSpan_xunshiSpan(machineid,catchSpan,xunshiSpan,machinemac,machinecode,fluxType,fluxNumber,SceneWifi){
    // if(xunshiSpan==''||catchSpan==''){
    //     alert("请选择");
    //     return;
    // }
    $.ajax({
        type:'get',
        url:baseUrl+'UserServices/User_Services.asmx/modifyMachine',
        dataType:'JSON',
        data:{
                machineid:machineid,
                catchSpan:catchSpan,
                xunshiSpan:xunshiSpan,
                machinemac:machinemac,
                machinecode:machinecode,
                fluxType:fluxType,
                fluxNumber:fluxNumber,
				SceneWifi,SceneWifi
        },
        success:function(data){
            if(data.falg){
                // alert(data.msg);
                layer.msg(data.msg,{
                    icon: 1,
                    offset: '15px'
                    ,time: 500
                });
            }else{
                 layer.msg(data.msg,{
                        icon:2,
                        offset: '15px'
                        ,time: 500
                });
            }
            
        },
        error:function(err){
                console.log(err)
        }

    });
}
// 抓拍巡视周期设置y_setMachinetime
// 更换  拆除
function updateDeviceMac(machineid,machinemac,machinecode,index){
    $.ajax({
        type:'get',
        url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/updateDeviceMac',
        dataType:'JSON',
        data:{
                machineid:machineid,
                machinemac:machinemac,
                machinecode:machinecode,
        },
        success:function(data){
            layui.use(['table','layer'], function(){
                var layer = layui.layer;
                var table = layui.table;
                // layer.msg(data[0].msg,{
                //         offset: '15px'
                //         ,time: 500
                // });
                layer.close(index);
                $(".updateCode_tanchu").hide(); 
                table.reload('test_stu');
            });
       
        },
        error:function(err){
                console.log(err)
        }

    });
}

