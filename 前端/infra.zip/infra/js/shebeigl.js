var userid='';
var areaname='', fenbuname="",ywbname='',stationname='',buildingname='',machinename='',ysdname='',devicename=''
  ,areaid='',fenbuid='',ywbid='',stationid='',buildingid='',machineid='',ysdid='',deviceid='';
  $(document).ready(function () {
        
        $(".loding_bg").show();
        layui.use(['table','layer'], function(){
              var layer = layui.layer;
              var table = layui.table;
              var $ = layui.jquery
              ,element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块
              var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
              var datas = $.parseJSON(Arr);
              areaname=datas.Areaname;
              areaid=datas.Areaid;
              userid=datas.Userid;
          });
          shebeiType();
  });
            
 

// 工区
$("#manageArea").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        areaid=$(this).attr("data-areaid");
        if($(this).text()=="全部"){
                device_getAreaAll(userid);
                device_getFenbuAll(userid);
                getywbAll(userid);
                getbdzAll(userid);
                getsbqAll(userid);
                getjianshiAll(userid);
                getysdAll(userid);
                shebeiAll(userid);
        }else{
                manage_sel(areaid,0);
                getfenbuAll(areaid);//工区下的分部
                getywbAll_area(areaid);//工区下的运维班
                getbdzAll_area(areaid);//工区下的变电站
                getsbqAll_area(areaid);//工区下的设备区
                getmachineAll_area(areaid);//工区下的所有监视设备(抓拍设备)
                getysdAll_area(areaid);//工区下的预设点
                getshebeiAll_area(areaid);//工区下的所有设备
        }
      
      
});

  // 点击分部
$("#fenbu_ulDD").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        fenbuid=$(this).attr("data-fenbuid");
      

        if($(this).text()=="全部"){
                device_getFenbuAll(userid)
                getywbAll(userid);
                getbdzAll(userid);
                getsbqAll(userid);
                getjianshiAll(userid);
                getysdAll(userid);
                shebeiAll(userid);
        }else{
                manage_sel(fenbuid,1);
                fenbu_getywbAll(fenbuid);//分部下的所有运维班
                fenbu_getbdzAll(fenbuid);//分部下的所有变电站
                fenbu_getsbqAll(fenbuid);//分部下的所有设备区
                fenbu_getmachineAll(fenbuid);//分部下的所有监视设备(抓拍设备)
                fenbu_getysdAll(fenbuid);//分部下的预设点
                fenbu_getshebeiAll(fenbuid);//分部下的所有设备
        }
});

//点击运维班  变电站、变化
$("#ywb_ulDD").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        ywbid=$(this).attr("data-ywbid");
        if($(this).text()=="全部"){
                getywbAll(userid);
                getbdzAll(userid);
                getsbqAll(userid);
                getjianshiAll(userid);
                getysdAll(userid);
                shebeiAll(userid);
        }else{
                manage_sel(ywbid,2);
                ywb_getbdzAll(ywbid);//运维班下的所有变电站
                ywb_getsbqAll(ywbid);//运维班下的所有设备区
                ywb_getmachineAll(ywbid);//运维班下的所有监视设备(抓拍设备)
                ywb_getysdAll(ywbid);//运维班下的预设点
                ywb_getshebeiAll(ywbid);//运维班下的所有设备
        }
});


//点击变电站  设备区 变化
$("#bdz_ulDD").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        stationid=$(this).attr("data-stationid");
        if($(this).text()=="全部"){
                getbdzAll(userid);
                getsbqAll(userid);
                getjianshiAll(userid);
                getysdAll(userid);
                shebeiAll(userid);
        }else{
                manage_sel(stationid,3);
                bdz_getsbqAll(stationid);//变电站下的所有设备区
                bdz_getmachineAll(stationid);//变电站下的所有监视设备(抓拍设备)
                bdz_getysdAll(stationid);//运维班下的预设点
                bdz_getshebeiAll(stationid);//变电站下的所有设备
        }
});

// 设备区下的监控器
$("#sbq_ulDD").on("click","span",function(){
        $(this).addClass("select").siblings().removeClass("select");
        buildingid=$(this).attr("data-buildingid");
        if($(this).text()=="全部"){
                getsbqAll(userid);
                getjianshiAll(userid);
                getysdAll(userid);
                shebeiAll(userid);
        }else{
                manage_sel(buildingid,4);
                sbq_getjianshiAll(buildingid);//当前设备区下的所有监视设备 (抓拍设备)
                sbq_getysdAll(buildingid);//设备区下的预设点
                sbq_getshebeiAll(buildingid)//设备区下的所有设备
        }
});


// 监控器下的预设点
$("#jkq_ul").on("click","li .item_left",function(){
      $(this).addClass("active").parent().siblings().find(".item_left").removeClass("active");
      machineid=$(this).attr("data-machineid");
      manage_sel(machineid,5);
      device_getYsdJkq(machineid);//监控器下的预设点
      jkq_getshebeiAll(machineid);//监控器下的所有设备
});

// 预设点下的监测设备
$("#ysd_ul").on("click","li .item_left",function(){
      $(this).addClass("active").parent().siblings().find(".item_left").removeClass("active");
      ysdid=$(this).attr("data-ysdid");
      manage_sel(ysdid,6);
      device_getShebeiYsd(ysdid);
});
// 上
$("#ysd_ul").on("click","li .upDownTZ .btnUp",function(){
        ysdid=$(this).attr("data-ysdid");
        $.ajax({
                type: 'GET',
                url: baseUrl + 'UserServices/User_Services.asmx/h_change_ysd',
                dataType:'JSON', 
                data: {
                        ysdid:ysdid,
                        up_or_down:0 
                },
                success: function (data) {
                        layer.msg(data[0].msg, {time:1000}); 
                }
                
        });
});
// 下
$("#ysd_ul").on("click","li .upDownTZ .btnDown",function(){
        ysdid=$(this).attr("data-ysdid");
        $.ajax({
                type: 'GET',
                url: baseUrl + 'UserServices/User_Services.asmx/h_change_ysd',
                dataType:'JSON', 
                data: {
                        ysdid:ysdid,
                        up_or_down:1 
                },
                success: function (data) {
                        layer.msg(data[0].msg, {time:1000});
                }
                
        });
});

// 点击左边biaji 按钮弹出列表
//工区
$("#area_biaji").click(function(){
  $(".area_lists").show();
});
//分部
$("#fenbu_biaji").click(function(){
        $(".fenbu_lists").show();
        sel_areaname(userid);
        var areaname_add=a;
        $("#device_addFenbu1 option").each(function(){
                if($(this).val()==areaname_add){
                $(this).attr('selected',true)
                };
        });
        var areaid=aid;
        manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
});
//运维班
$("#ywb_biaji").click(function(){
        $(".ywb_lists").show();
        sel_areaname(userid);
        var areaname_add=a;
        var fenbuname_add=b;
        $("#addywb1 option").each(function(){
                if($(this).val() ==areaname_add ){
                        $(this).attr('selected',true)
                }
        });
        $("#addywb2 option").each(function(){
                if($(this).val() ==fenbuname_add ){
                        $(this).attr('selected',true)
                }
        });
        var areaid=aid;
        var fenbuid=bid;
        manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
});
//变电站
$("#bdz_biaji").click(function(){
        $(".bdz_lists").show();
        sel_areaname(userid);
        var areaname_add=a;
        var fenbuname_add=b;
        var ywbname_add=c;
        $("#addbdz1 option").each(function(){
                if($(this).val()==areaname_add){
                        $(this).attr('selected',true)
                }
        });
        $("#addbdz2 option").each(function(){
                if($(this).val()==fenbuname_add){
                        $(this).attr('selected',true)
                }
        });
        $("#addbdz3 option").each(function(){
                if($(this).val()==ywbname_add){
                        $(this).attr('selected',true)
                }
        });
        var areaid=aid;
        var fenbuid=bid;
        var ywbid=cid;
        manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
});
//设备区
$("#sbq_biaji").click(function(){
        $(".sbq_lists").show();
        sel_areaname(userid);
        var areaname_add=a;
        var fenbuname_add=b;
        var ywbname_add=c;
        var stationname_add=d;
        $("#device_addsbj1 option").each(function(){
                if($(this).val() ==areaname_add ){
                        $(this).attr('selected',true)
                }
        });
        $("#device_addsbj2 option").each(function(){
        if($(this).val() ==fenbuname_add ){
                $(this).attr('selected',true)
        }
        });
        $("#device_addsbj3 option").each(function(){
        if($(this).val() ==ywbname_add ){
                $(this).attr('selected',true)
        }
        });
        $("#device_addsbj4 option").each(function(){
        if($(this).val() ==stationname_add){
                $(this).attr('selected',true)
        }
        });
        var areaid=aid;
        var fenbuid=bid;
        var ywbid=cid;
        var stationid=did;
        manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
});         
    



// 默认选中 监控器
function manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid){
        layui.use(['layer','form'], function(){
                var layer = layui.layer;
                var form = layui.form;
                // 工区
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/a_getAllarea',
                        dataType:'JSON', 
                        data: {
                                userid:userid 
                        },
                        success: function (data) {
                                
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].areaname==a){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-areaid='"+data[i].areaid+"' value='"+data[i].areaname+"'>"+data[i].areaname+"</option>";
                                        }
                                        // 设备管理
                                        //分部
                                        $("#device_addFenbu1").html(optionStr); //添加
                                        
                                        //运维班
                                        $("#addywb1").html(optionStr); //添加
                                        //变电站
                                        $("#addbdz1").html(optionStr); //添加
                                        //设备区
                                        $("#device_addsbj1").html(optionStr); //添加
                                        //监控器（抓拍设备）
                                        $("#device_addjkq1").html(optionStr); //添加
                                        //预设点
                                        $("#device_addysd1").html(optionStr); //添加
                                        //监测设备
                                        $("#device_addshebei1").html(optionStr); //添加
                                        
                                }
                                form.render('select');//需要渲染一下  
                        }
                        
                });
                if(areaid==''||areaid==null){
                        return;
                }
                // 分部
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/b_getfenbuByarea',
                        dataType:'JSON', 
                        data: {
                                areaid:areaid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].fenbuname==b){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-fenbuid='"+data[i].fenbuid+"' value='"+data[i].fenbuname+"'>"+data[i].fenbuname+"</option>";
                                        }
                                        // 设备管理
                                        //运维班
                                        $("#addywb2").html(optionStr); //添加
                                        //变电站
                                        $("#addbdz2").html(optionStr); //添加
                                        //设备区
                                        $("#device_addsbj2").html(optionStr); //添加
                                        //监控器（抓拍设备）
                                        $("#device_addjkq2").html(optionStr); //添加
                                        //预设点
                                        $("#device_addysd2").html(optionStr); //添加
                                        //监测设备
                                        $("#device_addshebei2").html(optionStr); //添加
                                }
                                form.render('select');//需要渲染一下
                        }
                }); 
                if(fenbuid==''||fenbuid==null){
                        return;
                }
                // 运维班
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/c_getywbByfenbu',
                        dataType:'JSON', 
                        data: {
                                fenbuid:fenbuid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].ywbname==c){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-ywbid='"+data[i].ywbid+"' value='"+data[i].ywbname+"'>"+data[i].ywbname+"</option>";
                                        }
                                        //变电站
                                        $("#addbdz3").html(optionStr); //添加
                                        //设备区
                                        $("#device_addsbj3").html(optionStr); //添加
                                        //监控器（抓拍设备）
                                        $("#device_addjkq3").html(optionStr); //添加
                                        //预设点
                                        $("#device_addysd3").html(optionStr); //添加
                                        //监测设备
                                        $("#device_addshebei3").html(optionStr); //添加

                                }
                                form.render('select');//需要渲染一下
                        }
                }); 
                if(ywbid==''||ywbid==null){
                        return;
                }
                // 变电站
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/e_getstationByywb',
                        dataType:'JSON', 
                        data: {
                                ywbid:ywbid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].stationname==d){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-stationid='"+data[i].stationid+"' value='"+data[i].stationname+"'>"+data[i].stationname+"</option>";
                                        }
                                        // 设备管理
                                        //设备区
                                        $("#device_addsbj4").html(optionStr); //添加
                                        //监控器（抓拍设备）
                                        $("#device_addjkq4").html(optionStr); //添加
                                        //预设点
                                        $("#device_addysd4").html(optionStr); //添加
                                        //监测设备
                                        $("#device_addshebei4").html(optionStr); //添加

                                }
                                form.render('select');//需要渲染一下
                        }
                });
                if(stationid==''||stationid==null){
                        return;
                }
                // 设备区
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/f_getbuildingBystation',
                        dataType:'JSON', 
                        data: {
                                stationid:stationid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].buildingname==e){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-buildingid='"+data[i].buildingid+"' value='"+data[i].buildingname+"'>"+data[i].buildingname+"</option>";
                                        }
                                        // 设备管理

                                        //监控器（抓拍设备）
                                        $("#device_addjkq5").html(optionStr); //添加
                                        //预设点
                                        $("#device_addysd5").html(optionStr); //添加
                                        //监测设备
                                        $("#device_addshebei5").html(optionStr); //添加

                                }
                                form.render('select');//需要渲染一下    
                        }
                });
                if(buildingid==''||buildingid==null){
                        return;
                }
                // 监控器
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/g_getmachineBybuilding',
                        dataType:'JSON', 
                        data: {
                                buildingid:buildingid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].machinename==f){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-machineid='"+data[i].machineid+"' value='"+data[i].machinename+"'>"+data[i].machinename+"</option>";
                                        }
                                        // 设备管理

                                        //预设点
                                        $("#device_addysd6").html(optionStr); //添加
                                        //监测设备
                                        $("#device_addshebei6").html(optionStr); //添加

                                }
                        }
                });
                if(machineid==''||machineid==null){
                        return;
                }
                // 预设点
                $.ajax({
                        type: 'GET',
                        url: baseUrl + 'UserServices/User_Services.asmx/h_getysdBymachine',
                        dataType:'JSON', 
                        data: {
                                machineid:machineid
                        },
                        success: function (data) {
                                if(data.length>=0){
                                        var optionStr ='<option lable="">请选择</option>';
                                        for(var i=0;i<data.length;i++){
                                                optionStr+="<option class='selectYouzhi' ";
                                                if(data[i].ysdname==g){
                                                        optionStr+="selected";
                                                }
                                                optionStr+=" data-ysdid='"+data[i].ysdid+"' value='"+data[i].ysdname+"'>"+data[i].ysdname+"</option>";
                                        }
                                        // 设备管理

                                         //监测设备
                                         $("#device_addshebei7").html(optionStr); //添加

                                }
                        }
                });

                // $.ajax({
                //         type:'get',
                //         url:baseUrl+'UserServices/User_Services.asmx/getUnaddYsd',
                //         dataType:'JSON',
                //         data:{
                //                 machineid:machineid
                //         },
                //         success:function(data){
                //                 var html='<span data-machinetype="全部" class="select">全部</span>';
                //                 for(let item of data){
                //                         html+=`<span data-stationname="${item.stationname}" data-buildingname="${item.buildingname}" data-machinetype="${item.machinetype}">
                //                                 ${item.machinetype}
                //                                 </span>`;
                //                 }
                                
                //                 $("#device_addysd7").html(html);//添加
                //                 $("#device_editysd7").html(html);//修改
                       
                //         },
                //         error:function(err){
                //                 console.log(err)
                //         }
        
                // });

        });
}
            
// 添加 type=0,1,2,3,4,5,6 0表示工区id，1表示分部id
function manage_sel(id,type){
    $.ajax({
      type: 'GET',
      url: baseUrl + 'UserServices/User_Services.asmx/XXX_getXiedaiParam',
      dataType:'JSON', 
      data: {
        id:id,
        type:type
      },
      success: function (data) {
              a=data[0].areaname;
              b=data[0].fenbuname;
              c=data[0].ywbname;
              d=data[0].stationname;
              e=data[0].buildingname;
              f=data[0].machinename;
              g=data[0].ysdname;

              aid=data[0].areaid;
              bid=data[0].fenbuid;
              cid=data[0].ywbid;
              did=data[0].stationid;
              eid=data[0].buildingid;
              fid=data[0].machineid;
      }
      
  });
};
           

      
