var userid='';
var areaidEdit='',fenbuidEdit='';
$(document).ready(function () {
    layui.use(['table','layer',"form"], function(){
        var layer = layui.layer;
        var form = layui.form;
        var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
        var datas = $.parseJSON(Arr);
        userid=datas.Userid;
        var areaidT=Util.getUrlParam('areaid');
        var fenbuidT=Util.getUrlParam('fenbuid');
        var ywbidT=Util.getUrlParam('ywbid');
        var stationidT=Util.getUrlParam('stationid');
        var buildingidT=Util.getUrlParam('buildingid');
        var machineidT=Util.getUrlParam('machineid');
        
        var areaid='',fenbuid='',ywbid='',stationid='',buildingid='',devicetype='',machineid='',deviceid='';
        // 修改
        // top_selDeviceManage(userid,areaidT,fenbuidT,ywbidT,stationidT,buildingidT);
        // getfenbuAll(areaidT);
        // fenbu_getywbAll(fenbuidT);
        // ywb_getbdzAll(ywbidT);
        // bdz_getsbqAll(stationidT);//变电站下的所有设备区
        editData(areaidT,fenbuidT,ywbidT,stationidT,buildingidT,devicetype,machineid,deviceid);
        $("#gqEdit_ul").on("click",'li .item_left',function(){
            $(this).addClass("select").parent().siblings().find(".item_left").removeClass("select");
            areaid=$(this).attr("data-areaid");
            fenbuid='',ywbid='',stationid='',buildingid='',devicetype='',machineid='',deviceid='';
            manage_sel(areaid,0);
            getfenbuAll(areaid);//工区下的分部
            getywbAll_area(areaid);//工区下的运维班
            getbdzAll_area(areaid);//工区下的变电站
            getsbqAll_area(areaid);//工区下的设备区
            getmachineAll_area(areaid);//工区下的所有监视设备(抓拍设备)
            getysdAll_area(areaid);//工区下的预设点
            getshebeiAll_area(areaid);//工区下的所有设备
        });
        $("#fenbuEdit_ul").on("click",'li .item_left',function(){
            $(this).addClass("select").parent().siblings().find(".item_left").removeClass("select");
            fenbuid=$(this).attr("data-fenbuid");
            ywbid='',stationid='',buildingid='',devicetype='',machineid='',deviceid='';
            manage_sel(fenbuid,1);
            fenbu_getywbAll(fenbuid);//分部下的所有运维班
            fenbu_getbdzAll(fenbuid);//分部下的所有变电站
            fenbu_getsbqAll(fenbuid);//分部下的所有设备区
            fenbu_getmachineAll(fenbuid);//分部下的所有监视设备(抓拍设备)
            fenbu_getysdAll(fenbuid);//分部下的预设点
            fenbu_getshebeiAll(fenbuid);//分部下的所有设备
        });
        $("#ywbEdit_ul").on("click",'li .item_left',function(){
            $(this).addClass("select").parent().siblings().find(".item_left").removeClass("select");
            ywbid=$(this).attr("data-ywbid");
            stationid='',buildingid='',devicetype='',machineid='',deviceid='';
            manage_sel(ywbid,2);
            ywb_getbdzAll(ywbid);//运维班下的所有变电站
            ywb_getsbqAll(ywbid);//运维班下的所有设备区
            ywb_getmachineAll(ywbid);//运维班下的所有监视设备(抓拍设备)
            ywb_getysdAll(ywbid);//运维班下的预设点
            ywb_getshebeiAll(ywbid);//运维班下的所有设备
        });
        $("#bdzEdit_ul").on("click",'li .item_left',function(){
            $(this).addClass("select").parent().siblings().find(".item_left").removeClass("select");
            stationid=$(this).attr("data-stationid");
            buildingid='',devicetype='',machineid='',deviceid='';
            manage_sel(stationid,3);
            bdz_getsbqAll(stationid);//变电站下的所有设备区
            bdz_getmachineAll(stationid);//变电站下的所有监视设备(抓拍设备)
            bdz_getysdAll(stationid);//运维班下的预设点
            bdz_getshebeiAll(stationid);//变电站下的所有设备
        });
        $("#sbqEdit_ul").on("click",'li .item_left',function(){
            $(this).addClass("select").parent().siblings().find(".item_left").removeClass("select");
            buildingid=$(this).attr("data-buildingid");
            devicetype='',machineid='',deviceid='';
            manage_sel(buildingid,4);
            sbq_getjianshiAll(buildingid);//当前设备区下的所有监视设备 (抓拍设备)
            sbq_getysdAll(buildingid);//设备区下的预设点
            sbq_getshebeiAll(buildingid)//设备区下的所有设备
        });
        
        
        //下拉框填充
        // 运维班添加/修改
       
        //运维班
        $("#addywb1").on("change",function(){
            var areaid=$("#addywb1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_editywb1").on("change",function(){
            var areaid=$("#device_editywb1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });

        // 变电站添加/修改
        $("#addbdz1").on("change",function(){
            var areaid=$("#addbdz1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_editbdz1").on("change",function(){
            var areaid=$("#device_editbdz1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#addbdz2").on("change",function(){
            var fenbuid=$("#addbdz2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        $("#device_editbdz2").on("change",function(){
            var fenbuid=$("#device_editbdz2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });

        
        // 设备区添加/修改

        $("#device_addsbj1").on("change",function(){
            var areaid=$("#device_addsbj1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_editsbj1").on("change",function(){
            var areaid=$("#device_editsbj1 option:selected").attr("data-areaid");
            sel_fenbuname(areaid);
        });
        $("#device_addsbj2").on("change",function(){
            var fenbuid=$("#device_addsbj2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        $("#device_editsbj2").on("change",function(){
            var fenbuid=$("#device_editsbj2 option:selected").attr("data-fenbuid");
            sel_ywbname(fenbuid);
        });
        $("#device_addsbj3").on("change",function(){
            var ywbid=$("#device_addsbj3 option:selected").attr("data-ywbid");
            sel_bdzname(ywbid);
        });
        $("#device_editsbj3").on("change",function(){
            var ywbid=$("#device_editsbj3 option:selected").attr("data-ywbid");
            sel_bdzname(ywbid);
        });

        //工区  修改、删除、添加 的事件

        var active_area = {
            edit: function(areaid){
                $(".area_edit").show();
                device_getAreaNows(areaid); //当前工区信息
            },
            del: function(areaid){
                layer.confirm('确认删除', {
                    title: false,
                    closeBtn: 0, //不显示关闭按钮
                    id: 'del1', //设定一个id，防止重复弹出
                    btn: ['确认', '取消'],
                    area: ['478px', '172px'],},
                    function (index) {
                        device_delArea(areaid);
                        setTimeout(function(){
                            device_getAreaAll(userid);
                        },500);
                        layer.close(index);
                    },function (index) {//cancel回调
                        layer.close(index);
                }); 
            }
        };
        $('#gqEdit_ul').on('click',".area_event", function(){
            var type = $(this).data('event');
            areaidEdit=$(this).attr("data-areaid"); //工区名字
            active_area[type] ? active_area[type].call(this,areaidEdit) : '';  //传参
        });
        //添加工区
        $(".add_btn1").on('click',function(){
            $(".area_add").show();
        });
        
        // 添加工区确定
        $(".area_add .btn0").click(function(){
            var areaname=$("#add_area1").val();
            var manager=$("#add_area2").val();
            var phone=$("#add_area3").val();
            var city=$("#add_area4").val();
            var address=$("#add_area5").val();
            device_addArea(areaname,manager,phone,city,address);
            setTimeout(function(){
                device_getAreaAll(userid);
            },500);
            $(".area_add").css("display","none");
        })
        // 添加工区取消
        $(".area_add .btn1").click(function(){
            $(".area_add").css("display","none");
        });
        // 修改工区确定
        $(".area_edit .btn0").click(function(){
            var areaname=$("#device_editArea1").val();
            var manager=$("#device_editArea2").val();
            var phone=$("#device_editArea3").val();
            var city=$("#device_editArea4").val();
            var address=$("#device_editArea5").val();
            device_editArea(areaidEdit,areaname,manager,phone,city,address)
            $(".area_edit").css("display","none");
        })
        // 修改工区取消
        $(".area_edit .btn1").click(function(){
            $(".area_edit").css("display","none");
        });



        //分部  修改、删除、添加 的事件
        var active_fb = {
            edit: function(fenbuid){
                device_getFenbuNows(fenbuid); //当前分部信息
                $(".fenbu_editC").show();
                sel_areaname(userid);
            },
            del: function(fenbuid){
                layer.confirm('确认删除', {
                title: false,
                closeBtn: 0, //不显示关闭按钮
                id: 'del2', //设定一个id，防止重复弹出
                btn: ['确认', '取消'],
                area: ['478px', '172px'],},
                function (index) {
                    device_delFenbu(fenbuid);
                    var areaid=$("#gqEdit_ul .select").attr("data-areaid");
                    setTimeout(function(){
                        getfenbuAll(areaid);
                    },500);
                    layer.close(index);
                },function (index) {//cancel回调
                        layer.close(index);
                }); 
            }
        };
        $('#fenbuEdit_ul').on('click',".fenbu_event", function(){
            var type = $(this).data('event');
            fenbuidEdit=$(this).attr("data-fenbuid"); //分部名字
            active_fb[type] ? active_fb[type].call(this,fenbuidEdit) : '';  //传参
        });
        //添加分部
        $(".add_btn2").on('click',function(){
            $(".fenbu_addC").show();
            sel_areaname(userid);
            var areaname_add=a;
            $("#device_addFenbu1 option").each(function(){
                    if($(this).val()==areaname_add){
                    $(this).attr('selected',true)
                    };
            });
            var areaid=aid;
            manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
        });
        // 添加分部确定
        $(".fenbu_addC .btn0").click(function(){
            var areaid=$("#device_addFenbu1 option:selected").attr("data-areaid");
            var fenbuname=$("#device_addFenbu2").val();
            var manager=$("#device_addFenbu3").val();
            var phone=$("#device_addFenbu4").val();
            var address=$("#device_addFenbu5").val();
            if(!areaid){
                areaid='';
            }
            device_addFenbu(areaid,fenbuname,manager,phone,address);
            
        })
        // 添加分部取消
        $(".fenbu_addC .btn1").click(function(){
            $(".fenbu_addC").css("display","none");
        });
        // 修改分部确定
        $(".fenbu_editC .btn0").click(function(){
            var areaid=$("#device_editFenbu1 option:selected").attr("data-areaid");
            // var areaname=$("#device_editFenbu1").val();
            var fenbuname=$("#device_editFenbu2").val();
            var manager=$("#device_editFenbu3").val();
            var phone=$("#device_editFenbu4").val();
            var address=$("#device_editFenbu5").val();
            if(!areaid){
                areaid='';
            }
            device_editFenbu(areaid,fenbuidEdit,fenbuname, manager, phone, address)
            $(".fenbu_editC").css("display","none");
        })
        // 修改分部取消
        $(".fenbu_editC .btn1").click(function(){
            $(".fenbu_editC").css("display","none");
        });



      //运维班  修改、删除、添加 的事件
        var active_ywb = {
            edit: function(ywbid){
                device_getYwbNows(ywbid);
                $(".ywb_editC").show();
                sel_areaname(userid);
            },
            del: function(ywbid){
                layer.confirm('确认删除', {
                    title: false,
                    closeBtn: 0, //不显示关闭按钮
                    id: 'del3', //设定一个id，防止重复弹出
                    btn: ['确认', '取消'],
                    area: ['478px', '172px'],},
                    function (index) {
                        device_delywb(ywbid);
                        var fenbuid=$("#fenbuEdit_ul .select").attr("data-fenbuid");
                        setTimeout(function(){
                            fenbu_getywbAll(fenbuid);
                        },500);
                        layer.close(index);
                    },function (index) {//cancel回调
                            layer.close(index);
                }); 
            },

        };
        $('#ywbEdit_ul').on('click',".ywb_event", function(){
            var type = $(this).data('event');
            ywbidEdit=$(this).attr("data-ywbid"); //运维班名字
            active_ywb[type] ? active_ywb[type].call(this,ywbidEdit) : '';  //传参
        });
        //添加运维班
        $(".add_btn3").on('click',function(){
            $(".ywb_addC").show();
            sel_areaname(userid);
            var areaname_add=a;
            var fenbuname_add=b;
            $("#addywb1 option").each(function(){
                    if($(this).val() ==areaname_add ){
                            $(this).attr('selected',true)
                    }
            });
            $("#addywb2 option").each(function(){
                    if($(this).val() ==fenbuname_add ){
                            $(this).attr('selected',true)
                    }
            });
            var areaid=aid;
            var fenbuid=bid;
            manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
        });
        // 添加运维班确定
        $(".ywb_addC .btn0").click(function(){
            // var areaname=$("#addywb1").val();
            // var fenbuname=$("#addywb2").val();
            var fenbuid=$("#addywb2 option:selected").attr("data-fenbuid");
            var ywbname=$("#addywb3").val();
            var manager=$("#addywb4").val();
            var phone=$("#addywb5").val();
            var address=$("#addywb6").val();
            if(!fenbuid){
                fenbuid='';
            }
            device_addywb(fenbuid,ywbname,manager,phone,address);
        })
        // 添加运维班取消
        $(".ywb_addC .btn1").click(function(){
            $(".ywb_addC").css("display","none");
        });
        // 修改运维班确定
        $(".ywb_editC .btn0").click(function(){
            var fenbuid=$("#device_editywb2 option:selected").attr("data-fenbuid");
            var ywbname=$("#device_editywb3").val();
            var manager=$("#device_editywb4").val();
            var phone=$("#device_editywb5").val();
            var address=$("#device_editywb6").val();
            if(!fenbuid){
                fenbuid='';
            }
            device_editywb(fenbuid,ywbidEdit,ywbname,manager,phone,address)
            $(".ywb_editC").css("display","none");
        })
        // 修改运维班取消
        $(".ywb_editC .btn1").click(function(){
            $(".ywb_editC").css("display","none");
        });


        //变电站  修改、删除、添加 的事件
        var active_bdz = {
            edit: function(stationid){
                device_getBdzNows(stationid);
                $(".bdz_editC").show();
                sel_areaname(userid);
            },
            del: function(stationid){
                layer.confirm('确认删除', {
                title: false,
                closeBtn: 0, //不显示关闭按钮
                id: 'del4', //设定一个id，防止重复弹出
                btn: ['确认', '取消'],
                area: ['478px', '172px'],},
                function (index) {
                        device_delbdz(stationid);
                        var ywbid=$("#ywbEdit_ul .select").attr("data-ywbid");
                        setTimeout(function(){
                            ywb_getbdzAll(ywbid);
                        },500);
                        layer.close(index);
                },function (index) {//cancel回调
                        layer.close(index);
                }); 
            },

        };
        $('#bdzEdit_ul').on('click',".bdz_event", function(){
            var type = $(this).data('event');
            stationidEdit=$(this).attr("data-stationid"); //运维班名字
            active_bdz[type] ? active_bdz[type].call(this,stationidEdit) : '';  //传参
        });
        //添加变电站
        $(".add_btn4").on('click',function(){
            $(".bdz_addC").show();
            sel_areaname(userid);
            var areaname_add=a;
            var fenbuname_add=b;
            var ywbname_add=c;
            $("#addbdz1 option").each(function(){
                    if($(this).val()==areaname_add){
                            $(this).attr('selected',true)
                    }
            });
            $("#addbdz2 option").each(function(){
                    if($(this).val()==fenbuname_add){
                            $(this).attr('selected',true)
                    }
            });
            $("#addbdz3 option").each(function(){
                    if($(this).val()==ywbname_add){
                            $(this).attr('selected',true)
                    }
            });
            var areaid=aid;
            var fenbuid=bid;
            var ywbid=cid;
            manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
        });
        // 添加变电站确定
        $(".bdz_addC .btn0").click(function(){
            // var areaname=$("#addbdz1").val();
            // var fenbuname=$("#addbdz2").val();
            // var ywbname=$("#addbdz3").val();
            var ywbid=$("#addbdz3 option:selected").attr("data-ywbid");
            var stationname=$("#addbdz4").val();
            var manager=$("#addbdz5").val();
            var phone=$("#addbdz6").val();
            var stationlevel=$("#addbdz7").val();
            var city=$("#addbdz8").val();
            var address=$("#addbdz9").val();
            var jingdu=$("#addbdz10").val();
            var weidu=$("#addbdz11").val();
            if(!ywbid){
                ywbid='';
            }
            device_addbdz(ywbid,stationname,manager,phone,stationlevel,city,address,jingdu,weidu);
            
            
        })
        // 添加变电站取消
        $(".bdz_addC .btn1").click(function(){
            $(".bdz_addC").css("display","none");
        });
        // 修改变电站确定
        $(".bdz_editC .btn0").click(function(){
            var ywbid=$("#device_editbdz3 option:selected").attr("data-ywbid");
            var stationname=$("#device_editbdz4").val();
            var manager=$("#device_editbdz5").val();
            var phone=$("#device_editbdz6").val();
            var stationlevel=$("#device_editbdz7").val();
            var city=$("#device_editbdz8").val();
            var address=$("#device_editbdz9").val();
            var jingdu=$("#device_editbdz10").val();
            var weidu=$("#device_editbdz11").val();
            if(!ywbid){
                ywbid='';
            }
            device_editbdz(ywbid,stationidEdit,stationname,manager,phone,stationlevel,city,address,jingdu,weidu)
            $(".bdz_editC").css("display","none");
        })
        // 修改变电站取消
        $(".bdz_editC .btn1").click(function(){
            $(".bdz_editC").css("display","none");
        });


        //设备区  修改、删除、添加 的事件
        var active_sbj = {
            edit: function(buildingid){
                device_getSbjNows(buildingid)
                $(".sbq_editC").show();
                sel_areaname(userid);
            },
            del: function(buildingid){
                layer.confirm('确认删除', {
                title: false,
                closeBtn: 0, //不显示关闭按钮
                id: 'del5', //设定一个id，防止重复弹出
                btn: ['确认', '取消'],
                area: ['478px', '172px'],},
                function (index) {
                        device_delSbj(buildingid);
                        var stationid=$("#bdzEdit_ul .select").attr("data-stationid");
                        setTimeout(function(){
                            bdz_getsbqAll(stationid);
                        },500);
                        layer.close(index);
                },function (index) {//cancel回调
                        layer.close(index);
                }); 
            },

        };
        $('#sbqEdit_ul').on('click',".sbj_event", function(){
            var type = $(this).data('event');
            var buildingid=$(this).attr("data-buildingid"); //设备区名字
            active_sbj[type] ? active_sbj[type].call(this,buildingid) : '';  //传参
        });
        //添加设备区
        $(".add_btn5").on('click',function(){
            $(".sbq_addC").show();
            sel_areaname(userid);
            var areaname_add=a;
            var fenbuname_add=b;
            var ywbname_add=c;
            var stationname_add=d;
            $("#device_addsbj1 option").each(function(){
                    if($(this).val() ==areaname_add ){
                            $(this).attr('selected',true)
                    }
            });
            $("#device_addsbj2 option").each(function(){
            if($(this).val() ==fenbuname_add ){
                    $(this).attr('selected',true)
            }
            });
            $("#device_addsbj3 option").each(function(){
            if($(this).val() ==ywbname_add ){
                    $(this).attr('selected',true)
            }
            });
            $("#device_addsbj4 option").each(function(){
            if($(this).val() ==stationname_add){
                    $(this).attr('selected',true)
            }
            });
            var areaid=aid;
            var fenbuid=bid;
            var ywbid=cid;
            var stationid=did;
            manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid);
            
        });
        
        // 添加设备区确定
        $(".sbq_addC .btn0").click(function(){
            // var areaname=$("#device_addsbj1").val();
            // var fenbuname=$("#device_addsbj2").val();
            // var ywbname=$("#device_addsbj3").val();
            var stationid=$("#device_addsbj4 option:selected").attr("data-stationid");;
            var buildingname=$("#device_addsbj5").val();
            if(!stationid){
                stationid='';
            }
            device_addSbj(stationid,buildingname)
            
        })
        // 添加设备区取消
        $(".sbq_addC .btn1").click(function(){
            $(".sbq_addC").css("display","none");
        });
        // 修改设备区确定
        $(".sbq_editC .btn0").click(function(){
            // var areaname=$("#device_editsbj1").val();
            // var fenbuname=$("#device_editsbj2").val();
            // var ywbname=$("#device_editsbj3").val();
            var stationid=$("#device_editsbj4 option:selected").attr("data-stationid");
            var buildingname=$("#device_editsbj5").val();
            var buildingid=$("#device_editsbj5").attr("data-id");
            if(!stationid){
                stationid='';
            }
            device_editSbj(stationid,buildingname,buildingid);
            $(".sbq_editC").css("display","none");
            
        })
        // 修改设备区取消
        $(".sbq_editC .btn1").click(function(){
            $(".sbq_editC").css("display","none");
        });
        
        // 保存
        $("#saves").click(function(){
            // $(".sbq_editC").css("display","none");
            var buildingid=$("#sbqEdit_ul .select").attr("data-buildingid"); //设备区名字
            if(!buildingid){
                buildingid='';
            }
            $.ajax({
                type: 'GET',
                url: baseUrl + 'UserServices/User_Services.asmx/modifyBasicInformationByMachineid',
                dataType:'JSON', 
                data: {
                    buildingid:buildingid,
                    machineid:machineidT  
                },
                success: function (data) {
                    if(data.falg){
                        layer.msg(data.msg, {
                            offset: '15px'
                            ,icon: 1
                            ,time: 1000
                        });
                    }else{
                        layer.msg(data.msg, {
                                offset: '15px'
                                ,icon: 2
                                ,time: 1000
                        });
                    }
                }
            });
        });
        

    });


      
   
});


// 
function editData(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid){
            
  var area='',
          fenbu='',
          ywb='',
          bdz='',
          sbq='';
          if(areaid==undefined||areaid=="全部"){
              var areaid='';
          }
          if(fenbuid==undefined||fenbuid=="全部"){
              var fenbuid='';
          }
          if(ywbid==undefined||ywbid=="全部"){
              var ywbid='';
          }
          if(stationid==undefined||stationid=="全部"){
              var stationid='';
          }
          if(buildingid==undefined||buildingid=="全部"){
              var buildingid='';
          }
          if(devicetype==undefined ||devicetype=="全部"){
              var devicetype='';
          }
          if(deviceid==undefined ||deviceid=="全部"){
              var deviceid='';
          }
          if(machineid==undefined ||machineid=="全部"){
              var machineid='';
          }
          
          $.ajax({
                  type:'get',
                  url:baseUrl+'UserServices/User_Services.asmx/thermometryConditions',
                  dataType:'JSON',  
                  data:{
                          userid:userid,
                          areaid:areaid,
                          fenbuid:fenbuid,
                          ywbid:ywbid,
                          stationid:stationid,
                          buildingid:buildingid,
                          devicetype:devicetype,
                          machineid:machineid,
                          deviceid:deviceid
                  },
                  success:function(data){
                          
                          $(".loding_bg").hide();
                          //工区
                          for(let item of data.Arealist){
                            area+=`<li class="li-item">
                                    <div data-areaid="${item.Id}" class="item_left fl`
                                    if(item.Show==1){
                                       area+=` select`;
                                    }
                                    area+=`"><span>${item.Name}</span></div>
                                    <div class="item_right fr">
                                      <a class="area_event ac_edit edit1 layui-btn layui-btn-xs" data-areaid="${item.Id}" data-event="edit">
                                        <i class="layui-icon layui-icon-edit"></i>
                                      </a>
                                      <a class="area_event ac_del del1 layui-btn layui-btn-xs" data-areaid="${item.Id}" data-event="del">
                                        <i class="layui-icon layui-icon-delete"></i>
                                      </a>
                                    </div>
                                  </li>
                                  <div class="clear"></div>`;
                          };
                          
                          //分部
                          for(let item of data.Fenbulist){
                            fenbu+=`<li class="li-item">
                                      <div data-fenbuid="${item.Id}" class="item_left fl`
                                      if(item.Show==1){
                                        fenbu+=` select`;
                                      }
                                      fenbu+=`"><span>${item.Name}</span></div>
                                      <div class="item_right fr">
                                        <a class="fenbu_event ac_edit edit2 layui-btn layui-btn-xs" data-fenbuid="${item.Id}" data-event="edit">
                                          <i class="layui-icon layui-icon-edit"></i>
                                        </a>
                                        <a class="fenbu_event ac_del del2 layui-btn layui-btn-xs" data-fenbuid="${item.Id}" data-event="del">
                                          <i class="layui-icon layui-icon-delete"></i>
                                        </a>
                                      </div>
                                  </li>
                                  <div class="clear"></div>`;
                          };
                          //运维班
                          for(let item of data.Ywblist){
                            ywb+=`<li class="li-item">
                                    <div data-ywbid="${item.Id}" class="item_left fl`
                                    if(item.Show==1){
                                      ywb+=` select`;
                                    }
                                    ywb+=`"><span>${item.Name}</span></div>
                                    <div class="item_right fr">
                                      <a class="ywb_event ac_edit edit3 layui-btn layui-btn-xs" data-ywbid="${item.Id}" data-event="edit">
                                        <i class="layui-icon layui-icon-edit"></i>
                                      </a>
                                      <a class="ywb_event ac_del del3 layui-btn layui-btn-xs" data-ywbid="${item.Id}" data-event="del">
                                        <i class="layui-icon layui-icon-delete"></i>
                                      </a>
                                    </div>
                                  </li>
                                  <div class="clear"></div>`;
                              
                          };
                          //变电站
                          for(let item of data.Stationlist){
                            bdz+=`<li class="li-item">
                                    <div data-stationid="${item.Id}" class="item_left fl`
                                    if(item.Show==1){
                                      bdz+=` select`;
                                    }
                                    bdz+=`"><span>${item.Name}</span></div>
                                    <div class="item_right fr">
                                      <a class="bdz_event ac_edit edit4 layui-btn layui-btn-xs" data-stationid="${item.Id}" data-event="edit">
                                        <i class="layui-icon layui-icon-edit"></i>
                                      </a>
                                      <a class="bdz_event ac_del del4 layui-btn layui-btn-xs" data-stationid="${item.Id}" data-event="del">
                                        <i class="layui-icon layui-icon-delete"></i>
                                      </a>
                                    </div>
                                  </li>
                                  <div class="clear"></div>`;
                              
                              
                          };
                          //设备区
                          for(let item of data.Buildinglist){
                            sbq+=`<li class="li-item">
                                    <div data-buildingid="${item.Id}" class="item_left fl`
                                    if(item.Show==1){
                                      sbq+=` select`;
                                    }
                                    sbq+=`"><span>${item.Name}</span></div>
                                    <div class="item_right fr">
                                      <a class="sbj_event ac_edit edit5 layui-btn layui-btn-xs" data-buildingid="${item.Id}" data-event="edit">
                                        <i class="layui-icon layui-icon-edit"></i>
                                      </a>
                                      <a class="sbj_event ac_del del5 layui-btn layui-btn-xs" data-buildingid="${item.Id}" data-event="del">
                                        <i class="layui-icon layui-icon-delete"></i>
                                      </a>
                                    </div>
                                  </li>
                                  <div class="clear"></div>`;
                              
                          };
                          
                          $("#gqEdit_ul").html(area);
                          $("#fenbuEdit_ul").html(fenbu);
                          $("#ywbEdit_ul").html(ywb);
                          $("#bdzEdit_ul").html(bdz);
                          $("#sbqEdit_ul").html(sbq);
                  },
                  error:function(err){
                          console.log(err)
                  }
  
          });
};

// 默认选中 监控器
function manage_moren(areaid,fenbuid,ywbid,stationid,buildingid,machineid){
    layui.use(['layer','form'], function(){
            var layer = layui.layer;
            var form = layui.form;
            // 工区
            $.ajax({
                    type: 'GET',
                    url: baseUrl + 'UserServices/User_Services.asmx/a_getAllarea',
                    dataType:'JSON', 
                    data: {
                            userid:userid 
                    },
                    success: function (data) {
                            
                            if(data.length>=0){
                                    var optionStr ='<option lable="">请选择</option>';
                                    for(var i=0;i<data.length;i++){
                                            optionStr+="<option class='selectYouzhi' ";
                                            if(data[i].areaname==a){
                                                    optionStr+="selected";
                                            }
                                            optionStr+=" data-areaid='"+data[i].areaid+"' value='"+data[i].areaname+"'>"+data[i].areaname+"</option>";
                                    }
                                    // 设备管理
                                    //分部
                                    $("#device_addFenbu1").html(optionStr); //添加
                                    
                                    //运维班
                                    $("#addywb1").html(optionStr); //添加
                                    //变电站
                                    $("#addbdz1").html(optionStr); //添加
                                    //设备区
                                    $("#device_addsbj1").html(optionStr); //添加
                                    //监控器（抓拍设备）
                                    $("#device_addjkq1").html(optionStr); //添加
                                    //预设点
                                    $("#device_addysd1").html(optionStr); //添加
                                    //监测设备
                                    $("#device_addshebei1").html(optionStr); //添加
                                    
                            }
                            form.render('select');//需要渲染一下  
                    }
                    
            });
            if(areaid==''||areaid==null){
                    return;
            }
            // 分部
            $.ajax({
                    type: 'GET',
                    url: baseUrl + 'UserServices/User_Services.asmx/b_getfenbuByarea',
                    dataType:'JSON', 
                    data: {
                            areaid:areaid
                    },
                    success: function (data) {
                            if(data.length>=0){
                                    var optionStr ='<option lable="">请选择</option>';
                                    for(var i=0;i<data.length;i++){
                                            optionStr+="<option class='selectYouzhi' ";
                                            if(data[i].fenbuname==b){
                                                    optionStr+="selected";
                                            }
                                            optionStr+=" data-fenbuid='"+data[i].fenbuid+"' value='"+data[i].fenbuname+"'>"+data[i].fenbuname+"</option>";
                                    }
                                    // 设备管理
                                    //运维班
                                    $("#addywb2").html(optionStr); //添加
                                    //变电站
                                    $("#addbdz2").html(optionStr); //添加
                                    //设备区
                                    $("#device_addsbj2").html(optionStr); //添加
                                    //监控器（抓拍设备）
                                    $("#device_addjkq2").html(optionStr); //添加
                                    //预设点
                                    $("#device_addysd2").html(optionStr); //添加
                                    //监测设备
                                    $("#device_addshebei2").html(optionStr); //添加
                            }
                            form.render('select');//需要渲染一下
                    }
            }); 
            if(fenbuid==''||fenbuid==null){
                    return;
            }
            // 运维班
            $.ajax({
                    type: 'GET',
                    url: baseUrl + 'UserServices/User_Services.asmx/c_getywbByfenbu',
                    dataType:'JSON', 
                    data: {
                            fenbuid:fenbuid
                    },
                    success: function (data) {
                            if(data.length>=0){
                                    var optionStr ='<option lable="">请选择</option>';
                                    for(var i=0;i<data.length;i++){
                                            optionStr+="<option class='selectYouzhi' ";
                                            if(data[i].ywbname==c){
                                                    optionStr+="selected";
                                            }
                                            optionStr+=" data-ywbid='"+data[i].ywbid+"' value='"+data[i].ywbname+"'>"+data[i].ywbname+"</option>";
                                    }
                                    //变电站
                                    $("#addbdz3").html(optionStr); //添加
                                    //设备区
                                    $("#device_addsbj3").html(optionStr); //添加
                                    //监控器（抓拍设备）
                                    $("#device_addjkq3").html(optionStr); //添加
                                    //预设点
                                    $("#device_addysd3").html(optionStr); //添加
                                    //监测设备
                                    $("#device_addshebei3").html(optionStr); //添加

                            }
                            form.render('select');//需要渲染一下
                    }
            }); 
            if(ywbid==''||ywbid==null){
                    return;
            }
            // 变电站
            $.ajax({
                    type: 'GET',
                    url: baseUrl + 'UserServices/User_Services.asmx/e_getstationByywb',
                    dataType:'JSON', 
                    data: {
                            ywbid:ywbid
                    },
                    success: function (data) {
                            if(data.length>=0){
                                    
                                    var optionStr ='<option lable="">请选择</option>';
                                    for(var i=0;i<data.length;i++){
                                            optionStr+="<option class='selectYouzhi' ";
                                            if(data[i].stationname==d){
                                                    optionStr+="selected";
                                            }
                                            optionStr+=" data-stationid='"+data[i].stationid+"' value='"+data[i].stationname+"'>"+data[i].stationname+"</option>";
                                    }
                                    // 设备管理
                                    //设备区
                                    $("#device_addsbj4").html(optionStr); //添加
                                    //监控器（抓拍设备）
                                    $("#device_addjkq4").html(optionStr); //添加
                                    //预设点
                                    $("#device_addysd4").html(optionStr); //添加
                                    //监测设备
                                    $("#device_addshebei4").html(optionStr); //添加

                            }
                            form.render('select');//需要渲染一下
                    }
            });
            if(stationid==''||stationid==null){
                    return;
            }
            // 设备区
            $.ajax({
                    type: 'GET',
                    url: baseUrl + 'UserServices/User_Services.asmx/f_getbuildingBystation',
                    dataType:'JSON', 
                    data: {
                            stationid:stationid
                    },
                    success: function (data) {
                            if(data.length>=0){
                                    var optionStr ='<option lable="">请选择</option>';
                                    for(var i=0;i<data.length;i++){
                                            optionStr+="<option class='selectYouzhi' ";
                                            if(data[i].buildingname==e){
                                                    optionStr+="selected";
                                            }
                                            optionStr+=" data-buildingid='"+data[i].buildingid+"' value='"+data[i].buildingname+"'>"+data[i].buildingname+"</option>";
                                    }
                                    // 设备管理

                                    //监控器（抓拍设备）
                                    $("#device_addjkq5").html(optionStr); //添加
                                    //预设点
                                    $("#device_addysd5").html(optionStr); //添加
                                    //监测设备
                                    $("#device_addshebei5").html(optionStr); //添加

                            }
                            form.render('select');//需要渲染一下    
                    }
            });
            if(buildingid==''||buildingid==null){
                    return;
            }
            
    });
}
// 添加 type=0,1,2,3,4,5,6 0表示工区id，1表示分部id
function manage_sel(id,type){
    $.ajax({
      type: 'GET',
      url: baseUrl + 'UserServices/User_Services.asmx/XXX_getXiedaiParam',
      dataType:'JSON', 
      data: {
        id:id,
        type:type
      },
      success: function (data) {
              a=data[0].areaname;
              b=data[0].fenbuname;
              c=data[0].ywbname;
              d=data[0].stationname;
              e=data[0].buildingname;
              f=data[0].machinename;
              g=data[0].ysdname;

              aid=data[0].areaid;
              bid=data[0].fenbuid;
              cid=data[0].ywbid;
              did=data[0].stationid;
              eid=data[0].buildingid;
              fid=data[0].machineid;
      }
      
  });
};

