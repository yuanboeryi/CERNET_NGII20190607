
$(document).ready(function () {
    
    layui.use(['table','layer'], function(){
        var layer = layui.layer;
        var table = layui.table;
        var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
        var datas = $.parseJSON(Arr);
        var userid=datas.Userid;
        
        // 缺图检查
        $("#missingImg").on('click',function(){
          // var deviceid=$(this).attr("data-deviceid");
          var url="missingImgs.html?userid="+userid;
          Util.popFullScreen3(100,100,url);
        });

        // 测温图库跳转历史图库
        $("#cewenTipHisImg").on('click',function(){
            var url="tem_historyImg.html";
            Util.popFullScreen3(100,100,url);
        });

        // 测温详情 // tem_mentDetail.html
        $("#contentImgs").on('click','#deviceidLi',function(){
              var machineid=$(this).attr("data-machineid");
              var deviceid=$(this).attr("data-deviceid");
              var likeYsdname=$(this).attr("data-ysdName");
              if(machineid==''||machineid==null||machineid==undefined){
                machineid='';
              }
              if(deviceid==''||deviceid==null||deviceid==undefined){
                deviceid='';
              }
              if(likeYsdname==''||likeYsdname==null||likeYsdname==undefined){
                likeYsdname='';
              }
              sessionStorage.setItem('likeYsdname', likeYsdname);  //储存预设点名字
              
              var url="tem_mentDetail.html?deviceid="+deviceid+"&&machineid="+machineid;
              Util.popFullScreen3(100,100,url);
        });
        $("#contentImgs").on('click','.item-title .tips',function(){
          $(this).parent().find(".tipsPop").toggle();
        });

         //监听工具条
        table.on('tool(table_Gj)', function(obj){
          var data = obj.data;
          //查看报告
          if(obj.event === 'report'){
            var id=obj.data.id;
            var url = "alarm_report.html?id="+id;
            Util.popFullScreen2('',1200,900,url);
          } else if(obj.event === 'del'){
              var id=obj.data.id;
              layer.confirm('确认删除行', {
                    title: false,
                    closeBtn: 0, //不显示关闭按钮
                    btn: ['确认', '取消'],
                    area: ['478px', '172px'],
              },function(index){
                    $.ajax({
                        type:'POST',
                        url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/DeleteAlarm',
                        dataType:'JSON',
                        data:{
                          idlist:id
                        },
                        success:function(data){
                          layer.msg(data[0].msg,{
                            offset: '15px'
                            ,time: 500
                          });
                          layer.close(index);
                          table.reload('table_Gj');
                        },
                        error:function(err){
                            console.log(err)
                        }
                    });
                    
            },function (index) {//cancel回调
                layer.close(index);
            });
          }
        });   
        //查看大图s 
        // $("#containerUl li").on('click', function () {
        //     $(".box_imgBig").show();
        // });
        $(".close_img").on("click","img",function(){
              $(".box_imgBig").hide();
        });
        
    });
    var fale='';
    // 曲线图页面里  曲线图表格和折线图切换 temInfo_MoreData.html
    $(".header p").on("click",function(){
          $(this).addClass("active").siblings().removeClass("active");
          // fale=0;
          if(fale==1){
            $("#broken_table").show();
            $("#broken_line").hide();
            fale=0;
          }else{
            $("#broken_line").show();
            $("#broken_table").hide();
            fale=1;
          }
     });
      
});

// 详情
function temDetail(deviceid,machineid){
  if(deviceid==''||deviceid==null||deviceid==undefined){
    deviceid='';
  }
  if(machineid==''||machineid==null||machineid==undefined){
    machineid='';
  }
	//设备今日、本周、本月、历史最高温统计以及对应得设备当前图片信息
	$.ajax({
		type:'get',
		url:baseUrl+'ReportServic/reportServices.asmx/getDeviceReport_Max',
		dataType:'JSON',
		data:{
			machineid:machineid,
			deviceid:deviceid
		},
		success:function(data){
			var html='',html2='',
			time1=[],
			tem1=[],tem2=[],tem3=[],tem4=[],tem5=[],
			arrAll1='',arrAll2='',arrAll3='',arrAll4='',arrAll5=''
			,arrAll30=[],tem30=[],time30=[],date30=[];
			// if(data.Falg){
			  
			// }else{
			//   layer.msg(data.Msg);
			//   // layer.msg(data.msg)
			// }
			if(data[0].Falg){
			    // 图片
			    var imgs=[data[0].Image1,data[0].Image2,data[0].Image3];
			    for(let item of imgs){
			        html+=`<div class="item_bg swiper-slide">
			                <div class="top_pic">
			                    <img src="${item}" alt="">
			                </div>
			            </div>`;
			    }
			    $("#pics").html(html);
			    // 内容
			    var Times='';
			    var tem=data[0].Dangqian;
			    if(tem==''||tem==null||tem==undefined){
			      tem=''
			    }else{
			        tem=data[0].Dangqian;
			    }
			    var time=data[0].Alarmtime; // /Date(158 572 227 7000)/
			    if(time==''||time==null){
			            Times=''
			    }else{
			            // Times=data[0].Alarmtime;
			            Times=(data[0].Alarmtime).replace(/\T/g," ");
			    }
			    
			    if(tem>=100){
			        html2+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
			    }
			    if(tem >= 80 && tem < 100){
			        html2+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
			    }
			    if(tem<80){
			        html2+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
			    }
			    html2+=`<div class="botText_right fr">
			            <p>${data[0].Devicename}</p>
			            <p class="time">(${data[0].Machinename} ${data[0].Machinecode}) ${Times}</p>
			        </div>`;
				$("#text").html(html2);
				
				
				//底部柱形图
				var day1=data[0].Dangqian,
				    day2=data[0].Today,
				    day3=data[0].Week,
				    day4=data[0].Month,
				    day5=data[0].History;
				if(data[0].Dangqian==''||data[0].Dangqian==null){
				  day1=0;
				}
				if(data[0].Today==''||data[0].Today==null){
				  day2=0;
				}
				if(data[0].Week==''||data[0].Week==null){
				  day3=0;
				}
				if(data[0].Month==''||data[0].Month==null){
				  day4=0;
				}
				if(data[0].History==''||data[0].History==null){
				  day5=0;
				}
				var todayTem=[day1,day2,day3,day4,day5];
				var Todaymaxid=data[0].Todaymaxid,//今日
				    Weekmaxid =data[0].Weekmaxid,
				    Monthmaxid=data[0].Monthmaxid, 
				    Historymaxid=data[0].Historymaxid;
				right_module3(todayTem,Todaymaxid,Weekmaxid,Monthmaxid,Historymaxid);
				
				
				// 跳转
				    //更多数据分析 第二个温度echart  折线图点击  temInfo_MoreData.html
				  $("#dataFenx").on('click',function(){
				    // var deviceid=Util.getUrlParam('deviceid');
				    var deviceid=data[0].Deviceid;
				    var url="temInfo_MoreData.html?deviceid="+deviceid;
				    Util.popFullScreen3(100,100,url);
				});
				
				//实时视频
				$("#tem-videos").on('click',function(){
				    // var deviceid=Util.getUrlParam('deviceid');
				    var deviceid=data[0].Deviceid,machineid=data[0].Machineid;
				    var url="tem_videos.html?machineid="+machineid+'&deviceid='+deviceid;
				    Util.popFullScreen3(100,100,url);
				});
				
				//历史图像
				$("#tem-historyImg").on('click',function(){
				    // var deviceid=Util.getUrlParam('deviceid');
				    var deviceid=data[0].Deviceid;
				    var url="tem_historyImg.html?deviceid="+deviceid;
				    Util.popFullScreen3(100,100,url);
				});
				//历史告警
				$("#tem-historyGaojing").on('click',function(){
				    // var deviceid=Util.getUrlParam('deviceid');
				    var deviceid=data[0].Deviceid;
				    var url="tem_historyGaojing.html?deviceid="+deviceid;
				    Util.popFullScreen3(100,100,url);
				});
				//24小时内高温变化趋势 固定时间点温度对比echart  折线图点击  temInfo_Time.html
				$("#TimedataFenx").on('click',function(){
				  // var deviceid=Util.getUrlParam('deviceid');
				  var deviceid=data[0].Deviceid;
				  var url="temInfo_Time.html?deviceid="+deviceid;
				  Util.popFullScreen3(100,100,url);
				});
			}
		},
		error:function(err){
			console.log(err);
		}
		
	})
	
	//30天温度统计
	$.ajax({
		type:'get',
		url:baseUrl+'ReportServic/reportServices.asmx/getDeviceReport_30Day',
		dataType:'JSON',
		data:{
			machineid:machineid,
			deviceid:deviceid
		},
		success:function(data){
			var arrAll30=[],tem30=[],time30=[],date30=[];
			
				// 30天内温度变化趋势 折线图
				var templists30=data[0].Templist_30;
				for(var j=0;j<templists30.length;j++){
				    arrAll30=templists30[j].split(';');
				    date30.push(arrAll30[0]);
				    time30.push(arrAll30[1]);
				    tem30.push(arrAll30[2]);
				};
				right_module2(date30,time30,tem30);
		},
		error:function(err){
			console.log(err);
		}
	}) 
	
	//24小时温度统计
	$.ajax({
		type:'get',
		url:baseUrl+'ReportServic/reportServices.asmx/getDeviceReport_24Hour_web',
		dataType:'JSON',
		data:{
			machineid:machineid,
			deviceid:deviceid
		},
		success:function(data){
			var time1=[],
				tem1=[],tem2=[],tem3=[],tem4=[],tem5=[],
				arrAll1='',arrAll2='',arrAll3='',arrAll4='',arrAll5='';
			
				//24折线图
				var Data1=(data[0].Date1).substring(5),
					Data2=(data[0].Date2).substring(5),
					Data3=(data[0].Date3).substring(5),
					Data4=(data[0].Date4).substring(5),
					Data5=(data[0].Date5).substring(5);
					// Data1==''?0:Data1;
					// Data2==''?0:Data2;
					// Data3==''?0:Data3;
					// Data4==''?0:Data4;
					// Data5==''?0:Data5;
				var DataTem=[Data1,Data2,Data3,Data4,Data5];
				var templists1=data[0].Templist_241;
				var templists2=data[0].Templist_242;
				var templists3=data[0].Templist_243;
				var templists4=data[0].Templist_244;
				var templists5=data[0].Templist_245;
				for(var j=0;j<templists1.length;j++){
						arrAll1=templists1[j].split(';');
						time1.push(arrAll1[0]+":00");
						tem1.push(arrAll1[1]);
				};
				for(var j=0;j<templists2.length;j++){
						arrAll2=templists2[j].split(';');
						
						tem2.push(arrAll2[1]);
				};
				for(var j=0;j<templists3.length;j++){
						arrAll3=templists3[j].split(';');
						tem3.push(arrAll3[1]);
				};
				for(var j=0;j<templists4.length;j++){
						arrAll4=templists4[j].split(';');
						tem4.push(arrAll4[1]);
				};
				for(var j=0;j<templists5.length;j++){
						arrAll5=templists5[j].split(';');
						tem5.push(arrAll5[1]);
				};
				right_module1(DataTem,time1,tem1,tem2,tem3,tem4,tem5);
		},
		error:function(err){
			console.log(err);
		}
	})
	$(".loding_bg").hide();
	
  // //全部数据合并的接口
  // $.ajax({
  //     type:'get',
  //     url:baseUrl+'ReportServic/reportServices.asmx/getDevicereport_device_web',
  //     dataType:'JSON',  
  //     data:{
  //         machineid:machineid,
  //         deviceid:deviceid
  //     },
  //     success:function(data){
  //             $(".loding_bg").hide();
  //             var html='',html2='',
  //             time1=[],
  //             tem1=[],tem2=[],tem3=[],tem4=[],tem5=[],
  //             arrAll1='',arrAll2='',arrAll3='',arrAll4='',arrAll5=''
  //             ,arrAll30=[],tem30=[],time30=[],date30=[];
  //             // if(data.Falg){
                
  //             // }else{
  //             //   layer.msg(data.Msg);
  //             //   // layer.msg(data.msg)
  //             // }
  //             if(data[0].Falg){
  //                 // 图片
  //                 // var imgs=[data[0].Image1,data[0].Image2,data[0].Image3];
  //                 // for(let item of imgs){
  //                 //     html+=`<div class="item_bg swiper-slide">
  //                 //             <div class="top_pic">
  //                 //                 <img src="${item}" alt="">
  //                 //             </div>
  //                 //         </div>`;
  //                 // }
  //                 // $("#pics").html(html);
  //                 // // 内容
  //                 // var Times='';
  //                 // var tem=data[0].Dangqian;
  //                 // if(tem==''||tem==null||tem==undefined){
  //                 //   tem=''
  //                 // }else{
  //                 //     tem=data[0].Dangqian;
  //                 // }
  //                 // var time=data[0].Alarmtime; // /Date(158 572 227 7000)/
  //                 // if(time==''||time==null){
  //                 //         Times=''
  //                 // }else{
  //                 //         // Times=data[0].Alarmtime;
  //                 //         Times=(data[0].Alarmtime).replace(/\T/g," ");
  //                 // }
                  
  //                 // if(tem>=100){
  //                 //     html2+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
  //                 // }
  //                 // if(tem >= 80 && tem < 100){
  //                 //     html2+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
  //                 // }
  //                 // if(tem<80){
  //                 //     html2+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
  //                 // }
  //                 // html2+=`<div class="botText_right fr">
  //                 //         <p>${data[0].Devicename}</p>
  //                 //         <p class="time">(${data[0].Machinename} ${data[0].Machinecode}) ${Times}</p>
  //                 //     </div>`;


  //                 // //24折线图
  //                 // var Data1=(data[0].Date1).substring(5),
  //                 //     Data2=(data[0].Date2).substring(5),
  //                 //     Data3=(data[0].Date3).substring(5),
  //                 //     Data4=(data[0].Date4).substring(5),
  //                 //     Data5=(data[0].Date5).substring(5);
  //                 //     // Data1==''?0:Data1;
  //                 //     // Data2==''?0:Data2;
  //                 //     // Data3==''?0:Data3;
  //                 //     // Data4==''?0:Data4;
  //                 //     // Data5==''?0:Data5;
  //                 // var DataTem=[Data1,Data2,Data3,Data4,Data5];
  //                 // var templists1=data[0].Templist_241;
  //                 // var templists2=data[0].Templist_242;
  //                 // var templists3=data[0].Templist_243;
  //                 // var templists4=data[0].Templist_244;
  //                 // var templists5=data[0].Templist_245;
  //                 // for(var j=0;j<templists1.length;j++){
  //                 //         arrAll1=templists1[j].split(';');
  //                 //         time1.push(arrAll1[0]+":00");
  //                 //         tem1.push(arrAll1[1]);
  //                 // };
  //                 // for(var j=0;j<templists2.length;j++){
  //                 //         arrAll2=templists2[j].split(';');
                          
  //                 //         tem2.push(arrAll2[1]);
  //                 // };
  //                 // for(var j=0;j<templists3.length;j++){
  //                 //         arrAll3=templists3[j].split(';');
  //                 //         tem3.push(arrAll3[1]);
  //                 // };
  //                 // for(var j=0;j<templists4.length;j++){
  //                 //         arrAll4=templists4[j].split(';');
  //                 //         tem4.push(arrAll4[1]);
  //                 // };
  //                 // for(var j=0;j<templists5.length;j++){
  //                 //         arrAll5=templists5[j].split(';');
  //                 //         tem5.push(arrAll5[1]);
  //                 // };
  //                 // right_module1(DataTem,time1,tem1,tem2,tem3,tem4,tem5); 

  //                 // // 30天内温度变化趋势 折线图
  //                 // var templists30=data[0].Templist_30;
  //                 // for(var j=0;j<templists30.length;j++){
  //                 //     arrAll30=templists30[j].split(';');
  //                 //     date30.push(arrAll30[0]);
  //                 //     time30.push(arrAll30[1]);
  //                 //     tem30.push(arrAll30[2]);
                      
  //                 // };
  //                 // right_module2(date30,time30,tem30);
  //                 //底部柱形图
  //                 var day1=data[0].Dangqian,
  //                     day2=data[0].Today,
  //                     day3=data[0].Week,
  //                     day4=data[0].Month,
  //                     day5=data[0].History;
  //                 if(data[0].Dangqian==''||data[0].Dangqian==null){
  //                   day1=0;
  //                 }
  //                 if(data[0].Today==''||data[0].Today==null){
  //                   day2=0;
  //                 }
  //                 if(data[0].Week==''||data[0].Week==null){
  //                   day3=0;
  //                 }
  //                 if(data[0].Month==''||data[0].Month==null){
  //                   day4=0;
  //                 }
  //                 if(data[0].History==''||data[0].History==null){
  //                   day5=0;
  //                 }
  //                 var todayTem=[day1,day2,day3,day4,day5];
  //                 var Todaymaxid=data[0].Todaymaxid,//今日
  //                     Weekmaxid =data[0].Weekmaxid,
  //                     Monthmaxid=data[0].Monthmaxid, 
  //                     Historymaxid=data[0].Historymaxid;
  //                 right_module3(todayTem,Todaymaxid,Weekmaxid,Monthmaxid,Historymaxid);
  //             // }
  //               $("#text").html(html2);
  //           }else{
  //             // layer.msg(data.Msg);
  //           }

              // // 跳转
              //     //更多数据分析 第二个温度echart  折线图点击  temInfo_MoreData.html
              //   $("#dataFenx").on('click',function(){
              //     // var deviceid=Util.getUrlParam('deviceid');
              //     var deviceid=data[0].Deviceid;
              //     var url="temInfo_MoreData.html?deviceid="+deviceid;
              //     Util.popFullScreen3(100,100,url);
              // });

              // //实时视频
              // $("#tem-videos").on('click',function(){
              //     // var deviceid=Util.getUrlParam('deviceid');
              //     var deviceid=data[0].Deviceid,machineid=data[0].Machineid;
              //     var url="tem_videos.html?machineid="+machineid+'&deviceid='+deviceid;
              //     Util.popFullScreen3(100,100,url);
              // });

              // //历史图像
              // $("#tem-historyImg").on('click',function(){
              //     // var deviceid=Util.getUrlParam('deviceid');
              //     var deviceid=data[0].Deviceid;
              //     var url="tem_historyImg.html?deviceid="+deviceid;
              //     Util.popFullScreen3(100,100,url);
              // });
              // //历史告警
              // $("#tem-historyGaojing").on('click',function(){
              //     // var deviceid=Util.getUrlParam('deviceid');
              //     var deviceid=data[0].Deviceid;
              //     var url="tem_historyGaojing.html?deviceid="+deviceid;
              //     Util.popFullScreen3(100,100,url);
              // });
              // //24小时内高温变化趋势 固定时间点温度对比echart  折线图点击  temInfo_Time.html
              // $("#TimedataFenx").on('click',function(){
              //   // var deviceid=Util.getUrlParam('deviceid');
              //   var deviceid=data[0].Deviceid;
              //   var url="temInfo_Time.html?deviceid="+deviceid;
              //   Util.popFullScreen3(100,100,url);
              // });


  //     },
  //     error:function(err){
  //             console.log(err)
  //     }

  // });


};


// 历史图像详情
function tem_historyImg(deviceid){
  if(deviceid==''||deviceid==null||deviceid==undefined){
    deviceid='';
  }
  $.ajax({
      type:'get',
      url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/Y_getDeviceHistoryImage',
      dataType:'JSON',  
      data:{
          deviceid:deviceid
      },
      success:function(data){
              var html='';
              
              // 内容
              var Times='';
              for(let item of data){
                  var tem=item.temputer;
                  var imgs='';
                  var imgs1=item.image_high;
                  var imgs2=item.image_mix;
                  var imgs3=item.image_red;
                  if(imgs1!=''&&imgs1!=null&&imgs1!=undefined){
                    imgs=imgs1;
                  }else if(imgs2!=''&&imgs2!=null&&imgs2!=undefined){
                    imgs=imgs2;
                  }else if(imgs3!=''&&imgs3!=null&&imgs3!=undefined){
                    imgs=imgs3;
                  }else{
                    imgs=`../images/no_pic.png`;
                  }
                  var Times=data[0].createtime; // 
                  if(Times==''||Times==null){
                          Times=''
                  }else{
                    Times=data[0].createtime; 
                  }
                  
                  
                  html+=`<li data-deviceid="${item.deviceid}" id="deviceidLi" onclick="historyImgBigImg(`+ JSON.stringify(data[0]).replace(/"/g, '&quot;') +`)">
                          <div class="item_bg">
                              <div class="top_pic"><img src="${imgs}" alt=""></div><div class="bot-text">`;
                            if(tem>=100){
                                html+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
                            }
                            if(tem >= 80 && tem < 100){
                                html+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
                            }
                            if(tem<80){
                                html+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
                            }
                            html+= `<div class="botText_right fr">
                                    <p>${item.machinename}(${item.devicename})</p>
                                    <p class="time">${Times}</p>
                                </div>
                            </div>
                        </div>
                        
                    </li>`;
                 
              }
              $("#containerUl").html(html);


              // 折线图

      },
      error:function(err){
              console.log(err)
      }

  });


};



// 历史图像点击查看大图
// function historyImgBigImg(datas){
//       $(".box_imgBigHistoryImg").show();  
//       var html='',html2='';
//       var Times=datas.createtime; // 
//       var machinename=datas.machinename;
//       if(!machinename){
//               machinename='';
//       }
//       var pics=[datas.image_mix,datas.image_high,datas.image_red,];
//       for(let item of pics){
//               html+= `<div class="swiper-slide">
//                       <img src="${item}" alt="图片">
//               </div>`;
//       }
//       $("#lunbo_HistoryImg").html(html);

//       if(datas.temputer){
//         var tem=datas.temputer;
//       }else{
//         var tem=datas.todaytop;
//       }
      
//       if(tem>=100){
//           html2+=`<div class="over100 tem fl">${tem}<span>℃</span></div>`;
//       }
//       if(tem >= 80 && tem < 100){
//           html2+=`<div class="over80 tem fl">${tem}<span>℃</span></div>`;
//       }
//       if(tem<80){
//           html2+=`<div class="up80 tem fl">${tem}<span>℃</span></div>`;
//       }
//       html2+=`<div class="fr">
//                       <p>${datas.devicename}</p>
//                       <p class="time">(${machinename} ${datas.machinecode}) ${Times}</p>
//               </div>`;
//       $("#HistoryImgText").html(html2);

// };




// 固定时间点温度对比详情
//获取某个设备选中日期和时间点的温度曲线：传值：requestDateList=deviceid;2020-05-14,2020-05-18;4,5,8
function temInfo_time(deviceid,statrTiem,endTime,allTime){
  if(deviceid==''||deviceid==null||deviceid==undefined){
    deviceid='';
  }
  // var alldata='01f7c4bc58cf4ef49accbfb6b992310f;2020-05-14,2020-05-18;4,5,8'
  var alldata=deviceid+';'+statrTiem+','+endTime+';'+allTime
  
  
  $.ajax({
      type:'get',
      url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/Z_getDeviceTemplistByTimeSpan',
      dataType:'JSON',  
      data:{
          requestDateList:alldata
      },
      success:function(data){
              $(".loding_bg").hide();
              var tem1=[];
              if(data.Falg){
                var name=data.Machinename+' ( '+data.Devicename+')';
                $("#name").html(name);
                var date1=data.Datelist;
                var Wendulist=data.Wendulist;
                for(var j=0;j<Wendulist.length;j++){
                        tem1.push(Wendulist[j]);
                };
                // 折线图
                // var tiemArr=[];
                var tiemArr=data.Timelist;
                // var ii='';
                // if(allTime=="全部"){
                //   console.log(1111)
                //   for(var i=0;i<24;i++){
                //     if(i<10){
                //       ii="0"+i;
                //     }else{
                //       ii=i;
                //     }
                //     tiemArr.push(ii+":00");
                //   }
                // }else{
                //   console.log(2222)
                //   var time=allTime.split(",");
                //   for(var i=0;i<time.length;i++){
                //     tiemArr.push(time[i]+":00");
                //   }
                // }
                tem_Time(tiemArr,date1,tem1);
              }else{
                layer.msg(data.Msg);
                // layer.msg(data.msg)
              }
      },
      error:function(err){
              console.log(err)
      }

  });


};



// 24小时内高温变化趋势 折线图
function  right_module1(allData,time,tem1,tem2,tem3,tem4,tem5){
    var dom = document.getElementById("TemModule1");
    if(!dom){
      return;
    }else{
        var myChart=echarts.init(dom);
        
        option = {
                
                tooltip: {
                    trigger: 'axis',
                    textStyle:{
                      color: '#fff'//字体颜色
                    },
                    formatter(params){
                      var html=''
                      for(var i=0;i<params.length;i++){
                        html+= `${params[i].marker}
                        <span style="color:#fff;">${params[i].seriesName} ${params[i].name}</span>
                        <span style="color:#ffcc00;">温度：${params[i].value}℃</span><br/>`;
                      }
                      return html;
                    }
                },
                
                legend: {
                        data:allData,
                        textStyle:{
                            color: '#fff'//字体颜色
                        },
                        right: '5%',
                        top:'2',
                        itemWidth: 18,
                        itemHeight: 8,
                        itemGap: 10,
                },
                grid: {
                    top:'30%',
                    left: '0',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                
                xAxis: {
                    type: 'category',
                    interval:1,
                    data: time,
                    axisTick: {
                        show: false,
                        },
                        axisLabel: {
                                textStyle: {
                                        fontSize: 12,
                                        color: 'rgba(255,255,255,0.8)'
                                },
                        },
                        axisLine: {
                                lineStyle: {
                                        color: '#315070'
                                }
                        },
                },
                yAxis: {
                    type: 'value',
                    name:'温度℃',
                    nameTextStyle:{
                      color:'#fff',
                      fontSize:14
                    },
                    axisTick: {
                        show: false,
                        },
                        axisLabel: {
                                textStyle: {
                                        fontSize: 12,
                                        color: 'rgba(255,255,255,0.8)'
                                },
                        },
                        axisLine: {
                                show: false,
                        },
                        splitLine :{    //网格线
                                lineStyle:{
                                    type:'dashed'    //设置网格线类型 dotted：虚线   solid:实线
                                    ,color: ['#315070']
                                },
                                show:true //隐藏或显示
                        }
                },
                series: [
                  
                    {
                        name:allData[0],
                        color:'#00ffd2',
                        smooth: false,//折线是否平滑
                        type:'line',
                        data:tem1
                    },
                    {
                        name:allData[1],
                        color:'#ffcc00',
                        smooth: false,//折线是否平滑
                        type:'line',
                        data:tem2
                    },
                    {
                      name:allData[2],
                      color:'#ff5e5e',
                      smooth: false,//折线是否平滑
                      type:'line',
                      data:tem3
                  },
                  {
                      name:allData[3],
                      color:'#fff',
                      smooth: false,//折线是否平滑
                      type:'line',
                      data:tem4
                  },{
                    name:allData[4],
                    color:'#00ffff',
                    smooth: false,//折线是否平滑
                    type:'line',
                    data:tem5
                },
                    
                ]
        };
        myChart.setOption(option);
    }
};

// 30天内温度变化趋势 折线图
function  right_module2(date30,time30,tem30){
  var dom = document.getElementById("TemModule2");
  if(!dom){
    return;
  }else{
      var myChart=echarts.init(dom);
      option = {
         
          tooltip: {
              trigger: 'axis',
              textStyle:{
                  color: '#fff'//字体颜色
              },
              formatter(params){
                // console.log(params);
                const item = params[0];
                return `<span style="color:#ffcc00;">温度：${item.value}℃</span><br/>
                        <span style="color:#fff;">日期：${item.name}</span>`;
              }
          },
          legend: {
              data:['当前设备温度统计'],
              textStyle:{
                  color: '#fff'//字体颜色
              },
              right: '5%',
              top:'2',
              itemWidth: 18,
              itemHeight: 8,
              itemGap: 10,
              // icon: 'roundRect',
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom:'3%',
            containLabel: true
          },
          
          xAxis: [
              {
                  type: 'category',
                  data:date30,
                  interval:1,
                  axisTick: {
                          show: false,
                  },
                  axisLabel: {
                          textStyle: {
                                  fontSize: 12,
                                  color: '#fff'
                          }
                  },
                  axisLine: {
                          lineStyle: {
                              type:'dashed'   //设置网格线类型 dotted：虚线   solid:实线
                              ,color: ['#315070']
                          }
                  },
                  
              },
              
          ],
          yAxis: [
              {
                  type: 'value',
                  name:'温度℃',
                  nameTextStyle:{
                    color:'#fff',
                    fontSize:14
                  },
                  axisTick: {
                      show: false,
                  },
                  axisLabel: {
                      textStyle: {
                          fontSize: 14,
                          color: 'rgba(255,255,255,0.8)'
                      }
                  },
                  axisLine: {
                      show: false,
                  },
                  splitLine :{    //网格线
                          lineStyle:{
                              type:'dashed'    //设置网格线类型 dotted：虚线   solid:实线
                              ,color: ['#315070']
                          },
                          show:true //隐藏或显示
                  }
              },
              
              
          ],
          series: [
              
              {
                  name:'当前设备温度统计',
                  type:'line',
                  smooth: true,//折线是否平滑
                  barWidth: 20,
                  color:"#ffcc00",
                  data:tem30,
                  areaStyle:{
                    normal:{
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ 

                            offset: 0,
                                color: 'rgba(255,204,0,0.39)'
                            }, {
                            offset: .34,
                                color: 'rgba(255,204,0,0.25)'
                            },{
                            offset: 1,
                                color: 'rgba(255,204,0,0.00)'
                            }])


                    },//区域颜色渐变
                },

              }
          ]
      };
      
      myChart.setOption(option);
  }   
  
};

// 温度对比 柱形图
function  right_module3(todayTem,Todaymaxid,Weekmaxid,Monthmaxid,Historymaxid){
    var recordid='';
    var dom = document.getElementById("TemModule3");
    if(!dom){
      return;
    }else{
        var myChart=echarts.init(dom);
        var myColor = ['#00fcff','#00ffd2','#fffc9f','#ffcc00','#ff5e5e'];
    
        option = {
            tooltip: {
              trigger: 'axis',
              textStyle:{
                color: '#fff'//字体颜色
              },
              formatter(params){
                const item = params[0];
                return `<span style="color:#00ffd2;">温度：${item.value}℃</span><br/>
                        <span style="color:#00ffd2;">${item.name}</span>`;
              }
            },
            grid: {
              top:'15%',
              right: '5%',
              bottom:'20%'
            },
            
            xAxis: [
              {
                type: 'category',
                interval:1,
                axisTick: {
                  show:false
                },
                axisLine: {
                  show: true,
                  lineStyle: {
                    color: 'rgba(255,255,255,.4)'
                  }
                },
                axisLabel: {
                  textStyle: {
                      //这个地方颜色是支持回调函数的这种的，如果是一种颜色则可以写成： color :'#1089E7'  
                      color : "#00ffd2",
                      fontSize:12
                  }
                },
                data: ['当前温度','今日最高','本周最高','本月最高','历史最高']
              }
            ],
            yAxis: [//多y轴时，用数组加对象的方式来实现
              {       
                show:false,          
                type: 'value',
                name: '温度°C',
                interval:1,
                axisTick:{       //y轴刻度线
                  show:false
                },
                axisLine: {
                  show:false,
                },
                
              }
            ],
            series: [
              
              {
                name:'温度',
                type:'bar',
                barWidth: 20,
                smooth:true,
                symbol: 'circle',     //设定为实心点
                symbolSize: 30,   //设定实心点的大小
                data:todayTem,
                lineStyle:{
                  normal:{
                    width:10
                  }
                },
                label: {
                        show: true, //开启显示
                        position: 'top', //在上方显示
                        textStyle: { //数值样式
                              color : "#00ffd2",
                              fontSize: 14,
                        },
                        
                },
                itemStyle: {
                    color : "#0A767C",
                }        
              }
            ]
        };
        myChart.setOption(option);

        myChart.on('click', function (params) {
          console.log(params.name)
              //查看大图s 周期峰值统计 左边
              if(params.name=="当前温度"){
                  console.log("当前温度左侧就是");
              }else if(params.name=="今日最高"){
                      recordid=Todaymaxid;
                      right_module3_bigImg(recordid);
              }else if(params.name=="本周最高"){
                      recordid=Weekmaxid;
                      right_module3_bigImg(recordid);
              }else if(params.name=="本月最高"){
                      recordid=Monthmaxid;
                      right_module3_bigImg(recordid);
              }else if(params.name=="历史最高"){
                      recordid=Historymaxid;
                      right_module3_bigImg(recordid);
              }else{
                      console.log("error");
              }
              
        });
        $(".close_img").on("click","img",function(){
                $(".box_imgBigRight_module3").hide();
        });
    }    
  
};
//获取温度对应的图片，传值recordid（历史图像id）
function  right_module3_bigImg(recordid){
  $.ajax({
          type:'get',
          url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getRoundImageBuid',
          dataType:'JSON',  
          data:{
                  recordid:recordid,
          },
          success:function(data){
                  $(".box_imgBigRight_module3").show();
                  var html='',html2='';
                  var tem='';
                  var time=data[0].createtime; ///Date(158 572 227 7000)/
                  var Times='';
                  if(time==''||time==null){
                          Times='';
                  }else{
                          Times=data[0].createtime;
                  }
                  if(data[0].valuemax==''||data[0].valuemax==null){
                          tem=0;
                  }else{
                          tem=data[0].valuemax;
                  }
                  var machinename=data[0].machinename;
                  if(!machinename){
                          machinename='';
                  }
                  var pics=[data[0].imageurl1,data[0].imageurl2,data[0].imageurl3];
                  for(let item of pics){
                          html+= `<div class="swiper-slide">
                                  <img src="${item}" alt="图片">
                          </div>`;
                  };
                  $("#lunbo_leftTopAllmodule3").html(html);

                  if(tem>=100){
                          html2+=`<div class="over100 tem fl">${tem}<span>℃</span></div>`;
                  }
                  if(tem >= 80 && tem < 100){
                          html2+=`<div class="over80 tem fl">${tem}<span>℃</span></div>`;
                  }
                  if(tem<80){
                          html2+=`<div class="up80 tem fl">${tem}<span>℃</span></div>`;
                  }
                  html2+=`<div class="fr">
                                  <p>
                                          <span>${data[0].devicename}</span>
                                  </p>
                                  <p class="time">(<span>${machinename} ${data[0].machinecode}</span>) ${Times}</p>
                          </div>`;
                  $("#leftTopTextmodule3").html(html2);
          },
          error:function(err){
                  console.log(err)
          }
  
  });
};


//设备测温自定义趋势查询（right_module2 的点击更多数据）的折线图
function tem_MoreData(time,maxtem,mintem,avgvtem) {
    if((maxtem==''||maxtem==null)||(mintem==''||mintem==null)||(avgvtem==''||avgvtem==null)){
      maxtem='';
      mintem='';
      avgvtem='';
    }
    var dom = document.getElementById("tem_MoreDatas");
    if(!dom){
      return;
    }else{
        var myChart=echarts.init(dom);
        option = {
            title:{
                text:'设备测温自定义趋势查询',
                x:'center',
                y:'top',
                textAlign:'center',
                textStyle:{
                    //文字颜色
                    color:'#00fcff',
                    fontWeight:'400',
                    //字体大小
            　　　　 fontSize:18,
                    
                }
            },
            tooltip: {
                trigger: 'axis',
                
            },
            
            legend: {
                    data:['最大值', '最小值', '平均值'],
                    textStyle:{
                        color: '#fff'//字体颜色
                    },
                    right: '5%',
                    top:'2',
                    itemWidth: 18,
                    itemHeight: 8,
                    itemGap: 10,
            },
        
            grid: {
                top:'10%',
                left: '3%',
                right: '3%',
                bottom: '0',
                containLabel: true
            },
            
            xAxis: {
                type: 'category',
                interval:1,
                data:time,
                axisTick: {
                    show: false,
                },
                axisLabel: {
                        textStyle: {
                                fontSize: 12,
                                color: 'rgba(255,255,255,0.8)'
                        },
                        interval:0,
                        rotate:40 //文字倾斜
                },
                axisLine: {
                        lineStyle: {
                                color: '#315070'
                        }
                },
            },
            yAxis: {
                type: 'value',
                name:'温度℃',
                nameTextStyle:{
                  color:'#fff',
                  fontSize:14
                },
                axisTick: {
                    show: false,
                    },
                    axisLabel: {
                      textStyle: {
                          fontSize: 12,
                          color: 'rgba(255,255,255,0.8)'
                      },
                    },
                    axisLine: {
                        show: false,
                    },
                    splitLine :{    //网格线
                        lineStyle:{
                            type:'dashed'    //设置网格线类型 dotted：虚线   solid:实线
                            ,color: ['#315070']
                        },
                        show:true //隐藏或显示
                    }
            },
            series: [
                {
                    name:'最大值',
                    color:'#ff5e5e',
                    smooth: false,//折线是否平滑
                    type:'line',
                    data:maxtem
                },
                {
                    name:'最小值',
                    color:'#00fcff',
                    smooth: false,//折线是否平滑
                    type:'line',
                    data:mintem
                },
                {
                  name:'平均值',
                  color:'#ffcc00',
                  smooth: false,//折线是否平滑
                  type:'line',
                  data:avgvtem
              }
                
            ]
        };
        myChart.setOption(option);
    }
  
};

//固定时间点温度对比（right_module1 的点击更多数据）的折线图
function tem_Time(tiemArr,date1,tem1) {
    var colors=['#00ffd2','#a42d00','#bb5500','#ffbb66','#ffcc22','#ee7700','#99ff99','#99ffff','#d1bbff','#9f88ff','#5555ff','#e93eff',
    '#ffff00','#00dd00','#009fcc','#00aa88','#008888','#003377','#8c0044','#770077','#0066ff','#007799','#55aa00','#ffbb00']
    var series=[];
    for(var i = 0;i<tiemArr.length;i++){
        series.push({
          name: tiemArr[i],
          color:colors[i],
          smooth: false,//折线是否平滑
            type: 'line',
            data: tem1[i]
        });
     };
    var trues=false;
  var dom = document.getElementById("tem_Time");
  if(!dom){
    return;
  }else{
      var myChart=echarts.init(dom);
      option = {
          title:{
              show:false,
              text:'',
              x:'center',
              y:'top',
              textAlign:'center',
              textStyle:{
                  //文字颜色
                  color:'#00fcff',
                  fontWeight:'400',
                  //字体大小
          　　　　 fontSize:18,
                  
              }
          },
          tooltip: {
              trigger: 'axis',
              
          },
          
          legend: {
                  data:tiemArr,
                  textStyle:{
                      color: '#fff',//字体颜色
                  },
                  right: '5%',
                  top:'2',
                  bottom:'10%',
                  itemWidth: 18,
                  itemHeight: 8,
                  itemGap: 10,
          },
          grid: {
              top:'10%',
              left: '3%',
              right: '3%',
              bottom: '0',
              containLabel: true
          },
          dataZoom: [//给x轴设置滚动条
            {
                    start:0,//默认为0
                    end: 80,//默认为100
                    type: 'slider',
                    show: trues,
                    xAxisIndex: [0],
                    handleSize: 0,//滑动条的 左右2个滑动条的大小
                    height: 10,//组件高度
                    left: '10%', //左边的距离
                    right: '10%',//右边的距离
                    bottom: 0,//下边的距离
                    borderColor: "#000",
                    fillerColor: '#269cdb',
                    borderRadius:5,
                    backgroundColor: '#33384b',//两边未选中的滑动条区域的颜色
                    showDataShadow: false,//是否显示数据阴影 默认auto
                    showDetail: false,//即拖拽时候是否显示详细数值信息 默认true
                    realtime:true, //是否实时更新
                    filterMode: 'filter',
              },
                    //下面这个属性是里面拖到
            {
                    type: 'inside',
                    show: trues,
                    xAxisIndex: [0],
                    start: 0,//默认为1
                    end: 1,//默认为100
            },
          ], 
          xAxis: {
              type: 'category',
              interval:1,
              data:date1,
              axisTick: {
                  show: false,
              },
              axisLabel: {
                      textStyle: {
                              fontSize: 16,
                              color: 'rgba(255,255,255,0.8)'
                      },
                      interval:1,
                      // rotate:40 //文字倾斜
              },
              axisLine: {
                      lineStyle: {
                              color: '#315070'
                      }
              },
          },
          yAxis: {
              type: 'value',
              name:'温度℃',
              nameTextStyle:{
                color:'#fff',
                fontSize:14
              },
              axisTick: {
                  show: false,
                  },
                  axisLabel: {
                    textStyle: {
                        fontSize: 12,
                        color: 'rgba(255,255,255,0.8)'
                    },
                  },
                  axisLine: {
                      show: false,
                  },
                  splitLine :{    //网格线
                      lineStyle:{
                          type:'dashed'    //设置网格线类型 dotted：虚线   solid:实线
                          ,color: ['#315070']
                      },
                      show:true //隐藏或显示
                  }
          },
          series: series
      };
      myChart.setOption(option);
      
      
  }
};


// 实时温度
function tem_table(deviceid){
  if(deviceid==''||deviceid==null||deviceid==undefined){
    deviceid='';
  }
  $.ajax({
          type:'get',
          url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getdeviceTempToday',
          dataType:'JSON',  
          data:{
            deviceid:deviceid,
          },
          success:function(data){
                  var html='';
                  for(let item of data){
                          html+=`<tr>
                              <td style="width:60%">${item.createtime}</td>
                              <td style="width:40%">${item.value}℃</td>
                          </tr>`;
                  }
                  $("#tem_table").html(html);
          },
          error:function(err){
                  console.log(err)
          }

  });
}



