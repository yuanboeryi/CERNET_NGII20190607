
var userid='';
var usertype='';
var order=1,orderI=1;
var areaname='', fenbuname="",ywbname='',stationname='',buildingname='',devicetype=''
    ,machinename='',isok='',machinetype='',isonline=''
    ,areaid='',fenbuid='',ywbid='',stationid='',buildingid='',machineid='',isalarm='',deviceid=''
    ,page=1,limit=12,allpage='',allpage2='',timeSpan='';
var staralarm='',endalarm='';
var devicetype='',areaid='',fenbuid='',ywbid='',stationid='',buildingid='',machineid='',isalarm='',deviceid='';
var starttime='',endtime='';
    $(document).ready(function () {
		stationid = Util.getUrlParam('stationid');
		gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        layui.use(['table','layer'], function(){
            var layer = layui.layer;
            var table = layui.table;
            var $ = layui.jquery
            ,element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块
            var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
            var datas = $.parseJSON(Arr);
            userid=datas.Userid;
            areaname=datas.Areaname;
            areaid=datas.Areaid;
            usertype=datas.Usertype;
        });
   
    });
   
    // 共用头部选择
    // 工区
    $("#tabAll").on("click",'li',function(){
        $(this).addClass("table_active").siblings().removeClass("table_active");
        areaid=$(this).attr("data-areaid");
        fenbuid='',ywbid='',stationid='',buildingid='',machineid='',deviceid='',devicetype='';
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        top_selCw(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
        
    });
    // 分部
    $("#fenbuDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        ywbid='',stationid='',buildingid='',machineid='',deviceid='',devicetype='';
        fenbuid=$(this).attr("data-fenbuid");
		gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        top_selCw(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
    });
    // 运维班
    $("#ywbDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        stationid='',buildingid='',machineid='',deviceid='',devicetype='';
        ywbid=$(this).attr("data-ywbid");
		gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        top_selCw(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
    });
    // 变电站
    $("#bdzDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        buildingid='',machineid='',deviceid='',devicetype='';
        stationid=$(this).attr("data-stationid");
		gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        top_selCw(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
    });
    // 设备区
    $("#sbqDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        machineid='',deviceid='',devicetype='';
        buildingid=$(this).attr("data-buildingid");
		gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        top_selCw(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
    });
    // 设备类型
    $("#sbTypeDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
		devicetype=$(this).attr("data-typename");
		deviceid='',isok='';
		gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        top_selCw(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
    });
	// 电力设备
	$("#sheibeiDDAll").on("click",'span',function(){
		$(this).addClass("select").siblings().removeClass("select");
		isok='';
		deviceid=$(this).attr("data-deviceid");
		gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
		top_selCw(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
		tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
	});
    // 红外设备
    $("#hwsbDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        deviceid='',devicetype='';
        machineid=$(this).attr("data-machineid");
        top_selCw(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
    });
	// 降序 时间
	$(".gaojing_table").on('click',"#sort_bottomTimeI",function(){
	    $(this).addClass("sort_botSel");
	    orderI=1;
	    gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm);
	});
	// 降序 温度
	$(".gaojing_table").on('click',"#sort_bottomWdI",function(){
	    $(this).addClass("sort_botSel");
	    orderI=0;
	    gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm);
	});
	$(".xia_rightItems").on('click',".item",function(){
	    staralarm=$(this).attr("data-min");
	    endalarm=$(this).attr("data-max");
	    gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm);
	});
	//点击告警状态
	$("#gaojingDD").on("click",'span',function(){
	    $(this).addClass("select").siblings().removeClass("select");
	    isok=$(this).attr("data-is");
	    areaid=$("#tabAll .table_active").attr("data-areaid");
	    fenbuid=$("#fenbuDDAll .select").attr("data-fenbuid");
	    ywbid=$("#ywbDDAll .select").attr("data-ywbid");
	    stationid=$("#bdzDDAll .select").attr("data-stationid");
	    buildingid=$("#sbqDDAll .select").attr("data-buildingid");
	    devicetype=$("#sbTypeDDAll .select").attr("data-typename");
	    deviceid=$("#sheibeiDDAll .select").attr("data-deviceid");
	    gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
	    tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);// 历史告警
	});
	// 历史告警 降序 时间
	$(".content-item").on('click',"#sort_bottomTime",function(){
	    $(this).addClass("sort_botSel");
	    order=1;
	    tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);
	});
	// 历史告警降序 温度
	$(".content-item").on('click',"#sort_bottomWd",function(){
	    $(this).addClass("sort_botSel");
	    order=0;
	    tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);
	});
	// 历史告警
	function tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok) {
	    if(areaid==undefined ){
	        var areaid='';
	    };
	    if(fenbuid==undefined ){
	        var fenbuid='';
	    };
	    if(ywbid==undefined){
	        var ywbid='';
	    };
	    if(stationid==undefined){
	        var stationid='';
	    };
	    if(buildingid==undefined){
	        var buildingid='';
	    };
	    if(devicetype==undefined){
	        var devicetype='';
	    };
	    if(deviceid==undefined){
	        var deviceid='';
	    };
	    if(isok==undefined){
	        var isok='';
	    };
	    var staralarm='';
	    var endalarm='';
	    layui.use(['table','layer'], function(){
	        var layer = layui.layer;
	        var table = layui.table;
	        table.render({
	        elem: '#table_Gj'
	        ,height:650
	        ,where:{
	            order:order,
	            userid:userid,
	            areaid:areaid,
	            fenbuid:fenbuid,
	            ywbid:ywbid,
	            stationid:stationid,
	            buildingid:buildingid,
	            devicetype:devicetype,
	            deviceid:deviceid,
	            isok:isok,
	            staralarm:staralarm,
	            endalarm:endalarm
	        }
	        ,url:baseUrl+"UserServices/User_Services.asmx/l_getAlarmByUnit" //数据接口
	        ,parseData:function(res){
	            return{
	                "code":0
	                ,"mag":0
	                ,"count":res.Recordcount
	                ,"data":res.Recorddt
	            }
	        }
	        ,cols: [[ //表头
	            {field: 'areaname', title: '工区', width:'10%'}
	            ,{field: 'fenbuname', title: '分部', width:'10%'}
	            ,{field: 'ywbname', title: '班组',width:'10%'}
	            ,{field: 'stationname', title: '变电站', width:'10%'} 
	            ,{field: 'buildingname', title: '设备区', width:'10%'}
	            ,{field: 'devicename', title: '电力设备', width:'10%'}
	            ,{field: 'createtime', title: '<span  id="sort_bottomTime">告警时间<i class="sort_bottomTime sort_bottom"></i></span>',templet:function(data){
	            var time=data.createtime; ///Date(158 572 227 7000)/
	            var Times='';
	            if(time==''||time==null){
	                Times='';
	            }else{
	                Times=(data.createtime).replace(/\T/g," ");
	            }
	            
	            return Times;
	            }, width:'10%'}
	            ,{field: 'alarmvalue', title: '<span  id="sort_bottomWd">告警温度<i class="sort_bottom"></i></span>', width:'8%'}
	            ,{field: 'isalarm', title: '告警状态', width:'10%',templet:function(data){
	                if(data.isok==0){
	                var isalarm="<p class='green'><span></span>已确认</p>"
	                }else{
	                var isalarm="<p class='red'><span></span>未确认</p>"
	                }
	                return isalarm
	            },}
	            ,{field: '', title: '报告', width:'6%',toolbar: '#report'}
	            ,{field: '', title: '操作', width:'6%',toolbar: '#operate'}
	        ]]
	        ,page: true //开启分页
	        ,limits: [10,20,30]  //一页选择显示3,5或10条数据
	        ,limit: 10  //一页显示10条数据
	        });
	    });
	};
    // 头部
    function top_selCw(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid){
        
        var area='',
                fenbu='<span data-fenbuid="">全部</span>',
                ywb='<span data-ywbid="">全部</span>',
                bdz='<span data-stationid="">全部</span>',
                sbq='<span data-buildingid="">全部</span>',
                sbType='<span data-typename="">全部</span>',
                machine='',
                ysd='',
                shebei='<span data-deviceid="">全部</span>';
                if(areaid==undefined||areaid=="全部"){
                    var areaid='';
                }
                if(fenbuid==undefined||fenbuid=="全部"){
                    var fenbuid='';
                }
                if(ywbid==undefined||ywbid=="全部"){
                    var ywbid='';
                }
                if(stationid==undefined||stationid=="全部"){
                    var stationid='';
                }
                if(buildingid==undefined||buildingid=="全部"){
                    var buildingid='';
                }
                if(devicetype==undefined ||devicetype=="全部"){
                    var devicetype='';
                }
                if(deviceid==undefined ||deviceid=="全部"){
                    var deviceid='';
                }
                if(machineid==undefined ||machineid=="全部"){
                    var machineid='';
                }
                
                $.ajax({
                        type:'get',
                        url:baseUrl+'UserServices/User_Services.asmx/thermometryConditions',
                        dataType:'JSON',  
                        data:{
                                userid:userid,
                                areaid:areaid,
                                fenbuid:fenbuid,
                                ywbid:ywbid,
                                stationid:stationid,
                                buildingid:buildingid,
                                devicetype:devicetype,
                                machineid:machineid,
                                deviceid:deviceid
                        },
                        success:function(data){
                                
                                // $(".loding_bg").hide();
                                //工区
                                for(let item of data.Arealist){
                                    area+=`<li data-areaid="${item.Id}" data-areaname="${item.Name}"`;
                                    if(item.Show==1){
                                        area+=` class="table_active"`;
                                    }
                                    area+=`>${item.Name}</li>`;
                                };
                                
                                //分部
                                for(let item of data.Fenbulist){
                                    fenbu+=`<span data-fenbuid="${item.Id}" data-fenbuname="${item.Name}"`;
                                    if(item.Show==1){
                                        fenbu+=` class="select"`;
                                    }
                                    fenbu+=`>${item.Name}</span>`;
                                };
                                //运维班
                                for(let item of data.Ywblist){
                                    ywb+=`<span data-ywbid="${item.Id}" data-ywbname="${item.Name}"`;
                                    if(item.Show==1){
                                        ywb+=` class="select"`;
                                    }
                                    ywb+=`>${item.Name}</span>`;
                                };
                                //变电站
                                for(let item of data.Stationlist){
                                    bdz+=`<span data-stationid="${item.Id}" data-stationname="${item.Name}"`;
                                    if(item.Show==1){
                                        bdz+=` class="select"`;
                                    }
                                    bdz+=`>${item.Name}</span>`;
                                };
                                //设备区
                                for(let item of data.Buildinglist){
                                    sbq+=`<span data-buildingid="${item.Id}" data-buildingname="${item.Name}"`;
                                    if(item.Show==1){
                                        sbq+=` class="select"`;
                                    }
                                    sbq+=`>${item.Name}</span>`;
                                };
                                //设备类型
                                for(let item of data.Devicetypelist){
                                    sbType+=`<span data-typeid="${item.Id}" data-typename="${item.Name}"`;
                                    if(item.Show==1){
                                        sbType+=` class="select"`;
                                    }
                                    sbType+=`>${item.Name}</span>`;
                                };
                                //红外设备
                                data.Machinelist.forEach( ( item, i ) => {
                                    machine+=`<span data-index="${i}" data-machineid="${item.Id}" data-machinename="${item.Name}"`;
                                    if(item.Show==1){
                                        machine+=` class="select"`;
                                    }
                                    machine+=`>${item.Name}</span>`;
                                })
                                // for(let item of data.Machinelist){
                                //     machine+=`<span data-index="${item}" data-machineid="${item.Id}" data-machinename="${item.Name}"`;
                                //     if(item.Show==1){
                                //         machine+=` class="select"`;
                                //     }
                                //     machine+=`>${item.Name}</span>`;
                                // };
                                //预设点
                                for(let item of data.Ysdlist){
                                        ysd+=`<li class="li-item">
                                                <div class="item_left fl"  data-ysdid="${item[0]}"><span>${item[1]}</span></div><div class="item_right fr">
                                                <a class="ysd_event ac_edit edit5 layui-btn layui-btn-xs" data-ysdid="${item[0]}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="ysd_event ac_del del5 layui-btn layui-btn-xs" data-ysdid="${item[0]}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                </div>
                                                </li><div class="clear"></div>`;
                                };
                                //电力设备
                                for(let item of data.Devicelist){
                                    shebei+=`<span data-deviceid="${item.Id}" data-devicename="${item.Name}"`;
                                    if(item.Show==1){
                                        shebei+=` class="select"`;
                                    }
                                    shebei+=`>${item.Name}</span>`;
                                };
                                $("#tabAll").html(area);
                                $("#fenbuDDAll").html(fenbu);
                                $("#ywbDDAll").html(ywb);
                                $("#bdzDDAll").html(bdz);
                                $("#sbqDDAll").html(sbq);
                                $("#sbTypeDDAll").html(sbType);
                                $("#hwsbDDAll").html(machine);
                                // $("#status_shebeiDDAll").html(machine);
                                $("#sheibeiDDAll").html(shebei);
                        },
                        error:function(err){
                                console.log(err)
                        }
        
                });
    };
	// 告警
	function gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm) {
	    if(areaid==undefined||areaid==null||areaid==0 ){
	      var areaid='';
	    };
	    if(fenbuid==undefined ){
	        var fenbuid='';
	    };
	    if(ywbid==undefined){
	        var ywbid='';
	    };
	    if(stationid==undefined){
	        var stationid='';
	    };
	    if(buildingid==undefined){
	        var buildingid='';
	    };
	    if(devicetype==undefined){
	        var devicetype='';
	    };
	    if(deviceid==undefined){
	        var deviceid='';
	    };
	    if(isok==undefined){
	        var isok='';
	    };
	    
	    layui.use(['table','layer'], function(){
	      var layer = layui.layer;
	      var table = layui.table;
	      table.render({
	        elem: '#test'
	        ,height:615
	        // ,width:800
	        ,where:{
	            order:orderI,
	            userid:userid,
	            areaid:areaid,
	            fenbuid:fenbuid,
	            ywbid:ywbid,
	            stationid:stationid,
	            buildingid:buildingid,
	            devicetype:devicetype,
	            deviceid:deviceid,
	            isok:isok,
	            staralarm:staralarm,
	            endalarm:endalarm
	        }
	        ,url:baseUrl+"UserServices/User_Services.asmx/l_getAlarmByUnit" //数据接口
	        ,parseData:function(res){
	          return{
	              "code":0
	              ,"mag":0
	              ,"count":res.Recordcount
	              ,"data":res.Recorddt
	          }
	        }
	        ,cols: [[ //表头
	          {type:'checkbox', width:'50'}
	          ,{field: 'areaname', title: '工区', width:'120'}
	          ,{field: 'fenbuname', title: '分部', width:'110'}
	          ,{field: 'ywbname', title: '班组',width:'110'}
	          ,{field: 'stationname', title: '变电站', width:'110'} 
	          ,{field: 'buildingname', title: '设备区', width:'150'}
	          ,{field: 'devicename', title: '电力设备', width:'150'}
			  ,{field: 'machinecode', title: '设备编号', width:'110'}
	          ,{field: 'createtime', title: '<span  id="sort_bottomTimeI">告警时间<i class="sort_bottomTime sort_bottom"></i></span>',templet:function(data){
	                var time=data.createtime; ///Date(158 572 227 7000)/
	                var Times=''
	                if(time==''||time==null){
	                  Times='';
	                }else{
	                  Times=(data.createtime).replace(/\T/g," ");
	                }
	                
	                return Times;
	            }, width:'9%'}
	          ,{field: 'alarmvalue', title: '<span  id="sort_bottomWdI">告警温度<i class="sort_bottom"></i></span>', width:'7%'}
	          ,{field: 'offsetvalue', title: '告警阈值', width:'6%'}
	          ,{field: 'offsethuman', title: '设定人', width:'5%'}
	          ,{field: 'isalarm', title: '告警状态', width:'6%',templet:function(data){
	              if(data.isok==0){
	                var isalarm="<p class='green'><span></span>已确认</p>"
	              }else{
	                var isalarm="<p class='red'><span></span>未确认</p>"
	              }
	              return isalarm
	          },}
	          ,{field: 'fuhe', title: '负荷', width:'4%'}
	          ,{field: 'mensurehuman', title: '确认人', width:'5%'}
	          ,{field: 'mensuretime', title: '确认时间', width:'9%',templet:function(data){
	              var time=data.mensuretime; ///Date(158 572 227 7000)/
	              var Times=''
	              if(time==''||time==null){
	                Times='';
	              }else{
	                Times=(data.mensuretime).replace(/\T/g," ");
	              }
	              return Times;
	          },}
	          ,{fixed: 'right',field: '', title: '报告', width:'4%',toolbar: '#report'}
	          ,{fixed: 'right',field: '', title: '操作', width:'4%',toolbar: '#operate'},
			  ,{fixed: 'right',field: '', title: '', width:'4%',toolbar: '#realVideo'}
	        ]]
	        ,page: true //开启分页
	        ,limits: [10,20,30]  //一页选择显示3,5或10条数据
	        ,limit: 10  //一页显示10条数据
	      });
	    });
	}	
	
    // 测温查看
    function tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime){
        $(".loding_bg").show();
        var html='';
        var area='',fenbu='',ywb='',bdz='',sbq='',machine='';
        var imgs='';
        if(areaid==undefined ){
            var areaid='';
        }
        if(fenbuid==undefined){
            var fenbuid='';
        }
        if(ywbid==undefined){
          var ywbid='';
        }
        if(stationid==undefined){
            var stationid='';
        }
        if(buildingid==undefined){
            var buildingid='';
        }
        if(devicetype==undefined){
            var devicetype='';
        }
        if(machineid==undefined){
            var machineid='';
        }
        if(isalarm==undefined){
            var isalarm='';
        }
        // var timeAll=$('#Time_datasTe').val();
        // if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
        //     var tiemArr=timeAll.split("~");
        //     starttime=tiemArr[0];
        //     endtime=tiemArr[1];
        // }
        var urls="TableService/Infra_Red_Table_Services.asmx/WebX_getImageListBystation";
        $.ajax({
            type:'get',
            url:baseUrl+urls,
            dataType:'JSON',  
            data:{
                userid:userid,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
                devicetype:devicetype,
                machineid:machineid,
                isalarm:isalarm,
                StartTime:'',
                EndTime:''
            },
            success:function(data){
                var html='';
            //   ${item.Machinename} 后面<div class="tem-videos" id="tem-videos"><span>实时视频</span></div>
                if(data.Json.length>0){       
                    for(let item of data.Json){
                        var  machinenameArr=(item.Machinename).split("#");
                        var  machinename=machinenameArr[0];
                        var machinenameTips=machinenameArr[1];
						var machinestate = machinenameTips.split("-");
                        html+=`
                            <div class="content-item">
                            <div class="item-title">
                                <p class="fl"  id="deviceidLi" data-machineid="${item.Machineid}" data-ysdName="" style="cursor: pointer;">
                                    <img src="images/temC.png" alt="">
                                    <span>${machinename}</span>
                                </p>`;
								if("失联"==machinestate[2]){//红色
									html+=`<img src="../images/nav_warn.png" alt="" class="tips">`;
								}else{//蓝色
									html+=`<img src="../images/Frame.png" alt="" class="tips">`;
								}                              														
							html+=`<p class="tipsPop" style="display:none;">${machinenameTips}</p>
						</div>
						<ul class="item-container">`;
					
                        for(let item2 of item.Imagedt){
                            var imgs1=item2.image_high;
                            var imgs2=item2.image_red;
                            var imgs3=item2.image_mix;
                            html+=`<li>`;
                            if(imgs1!=''&&imgs1!=null&&imgs1!=undefined){
                                imgs=imgs1;
                            }else if(imgs2!=''&&imgs2!=null&&imgs2!=undefined){
                                imgs=imgs2;
                            }else if(imgs3!=''&&imgs3!=null&&imgs3!=undefined){
                                imgs=imgs3;
                            }else{
                                imgs=`../images/no_pic.png`;
                            }

                            var tem=item2.todaytop;
                            var time=item2.createtime; ///Date(158 572 227 7000)/
                            var Times='';
                            if(time==''||time==null){
                            Times='';
                            }else{
                                Times=(item2.createtime).replace(/\T/g," ");
                                
                            }
                            html+=`<div class="item_bg">
                                    <div class="top_pic"><img src="${imgs}" alt="" data-deviceid="${item2.deviceid}" data-ysdName="${item2.ysdname}" id="deviceidLi"/></div><div class="bot-text">`;
                                if(tem>=100){
                                    html+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                if(tem >= 80 && tem < 100){
                                    html+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                if(tem<80){
                                    html+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                        // <div class="botText_left fl">${} <span>℃</span></div>
                                html+=`<div class="botText_right fr">
                                            <p>${item2.devicename}</p>
                                            <p class="time">${Times}</p>
                                        </div>
                                    </div>
                                </div>
                                
                            </li>`;
                        }
                                
                        html+=`</ul>
                        </div> `;
                    
                    };
                }else{
                    html+="<div class='no_datasLI'><p>暂无数据</p></div>"
                }
                $("#contentImgs").html(html);
                $(".loding_bg").hide();
            },
            error:function(err){
                    console.log(err)
            }

        });  
    };
	