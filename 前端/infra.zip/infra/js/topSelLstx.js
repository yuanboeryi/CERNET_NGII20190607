// var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
// var datas = $.parseJSON(Arr);
// var userid=datas.Userid;
var userid='';
var usertype='';
var order=1,orderI=1;
var areaname='', fenbuname="",ywbname='',stationname='',buildingname='',devicetype=''
    ,machinename='',isok='',machinetype='',isonline=''
    ,areaid='',fenbuid='',ywbid='',stationid='',buildingid='',machineid='',isalarm='',deviceid=''
    ,page=1,limit=12,allpage='',allpage2='',timeSpan='';
var startDate='';
var endDate='';
var staralarm='',endalarm='';
var statrTiem='',endTime='',StartTime='',EndTime='';
var starttime='',endtime='',conclusionXs='',typename='',description='',statusSeeAbnormal='',lastDevice=0;//nextdevice=0
var deviceidHisImgId = '';
    $(document).ready(function () {

        layui.use(['table','layer'], function(){
            var layer = layui.layer;
            var table = layui.table;
            var $ = layui.jquery
            ,element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块
            var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
            var datas = $.parseJSON(Arr);
            userid=datas.Userid;
            areaname=datas.Areaname;
            areaid=datas.Areaid;
            usertype=datas.Usertype;
        });
   
    });
   
    // 历史图像头部
    // 工区
    $("#tabAll").on("click",'li',function(){
        $(this).addClass("table_active").siblings().removeClass("table_active");
        $("#typenameDDAll span").removeClass("select");
        $("#descriptionDDAll span").removeClass("select");
        $("#statusDDAll span").removeClass("select");
        areaid=$(this).attr("data-areaid");
        fenbuid='',ywbid='',stationid='',buildingid='',machineid='',deviceid='',devicetype='',
        typename='',description='',statusSeeAbnormal='',nextdevice=0,isok='',isonline='';
        top_SelLstx(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//历史图像头部
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像分页
    });
    // 分部
    $("#fenbuDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        $("#typenameDDAll span").removeClass("select");
        $("#descriptionDDAll span").removeClass("select");
        $("#statusDDAll span").removeClass("select");
        ywbid='',stationid='',buildingid='',machineid='',deviceid='',devicetype='',
        typename='',description='',statusSeeAbnormal='',nextdevice=0,isok='',isonline='';
        fenbuid=$(this).attr("data-fenbuid");
        top_SelLstx(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//历史图像头部
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像分页
    });
    // 运维班
    $("#ywbDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        $("#typenameDDAll span").removeClass("select");
        $("#descriptionDDAll span").removeClass("select");
        $("#statusDDAll span").removeClass("select");
        stationid='',buildingid='',machineid='',deviceid='',devicetype='',
        typename='',description='',statusSeeAbnormal='',nextdevice=0,isok='',isonline='';
        ywbid=$(this).attr("data-ywbid");
        top_SelLstx(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//历史图像头部
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像分页
    });
    // 变电站
    $("#bdzDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        $("#typenameDDAll span").removeClass("select");
        $("#descriptionDDAll span").removeClass("select");
        $("#statusDDAll span").removeClass("select");
        buildingid='',machineid='',deviceid='',devicetype='',
        typename='',description='',statusSeeAbnormal='',nextdevice=0,isok='',isonline='';
        stationid=$(this).attr("data-stationid");
        top_SelLstx(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//历史图像头部
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像分页
    });
    // 设备区
    $("#sbqDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        machineid='',deviceid='',devicetype='',nextdevice=0,isok='';
        buildingid=$(this).attr("data-buildingid");
        top_SelLstx(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//历史图像头部
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);//历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);//历史图像分页
    });
    // 红外设备
    $("#hwsbDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        deviceid='',devicetype='';
        machineid=$(this).attr("data-machineid");
        top_SelLstx(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//历史图像头部
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);//历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);//历史图像分页
    });
    // 电力设备
    $("#sheibeiDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        isok='';
        deviceid=$(this).attr("data-deviceid");
        top_SelLstx(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//历史图像头部
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像分页
    });
    // 可见光，红外切换
    $("#realTourImg").on("click",'li',function(){
        $(this).addClass("active").siblings().removeClass("active");
        $(this).find(".layui-icon").show();
        $(this).siblings().find(".layui-icon").hide();
        // nextdevice=0;
        imgType=$(this).attr("data-imgtype");
        areaid=$("#tabAll .table_active").attr("data-areaid");
        fenbuid=$("#fenbuDDAll .select").attr("data-fenbuid");
        ywbid=$("#ywbDDAll .select").attr("data-ywbid");
        stationid=$("#bdzDDAll .select").attr("data-stationid");
        buildingid=$("#sbqDDAll .select").attr("data-buildingid");
        machineid=$("#hwsbDDAll .select").attr("data-machineid");
        devicetype=$("#sbTypeDDAll .select").attr("data-typename");
        deviceid=$("#sheibeiDDAll .select").attr("data-deviceid");
        top_SelLstx(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
		// 历史图像
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);
		// 历史图像分页
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);
    });
    // 历史图像头部头部
    function top_SelLstx(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid){
        var area='',
                fenbu='<span data-fenbuid="">全部</span>',
                ywb='<span data-ywbid="">全部</span>',
                bdz='<span data-stationid="">全部</span>',
                sbq='<span data-buildingid="">全部</span>',
                machine='<span data-typename="">全部</span>',
                shebei='<span data-deviceid="">全部</span>';
                if(areaid==undefined||areaid=="全部"){
                    var areaid='';
                }
                if(fenbuid==undefined||fenbuid=="全部"){
                    var fenbuid='';
                }
                if(ywbid==undefined||ywbid=="全部"){
                    var ywbid='';
                }
                if(stationid==undefined||stationid=="全部"){
                    var stationid='';
                }
                if(buildingid==undefined||buildingid=="全部"){
                    var buildingid='';
                }
                if(devicetype==undefined ||devicetype=="全部"){
                    var devicetype='';
                }
                if(deviceid==undefined ||deviceid=="全部"){
                    var deviceid='';
                }
                if(machineid==undefined ||machineid=="全部"){
                    var machineid='';
                }
                
                $.ajax({
                        type:'get',
                        url:baseUrl+'UserServices/User_Services.asmx/queryConditions',
                        dataType:'JSON',  
                        data:{
                                userid:userid,
                                areaid:areaid,
                                fenbuid:fenbuid,
                                ywbid:ywbid,
                                stationid:stationid,
                                buildingid:buildingid,
                                devicetype:devicetype,
                                machineid:machineid,
                                deviceid:deviceid
                        },
                        success:function(data){
                                //工区
                                for(let item of data.Arealist){
                                    area+=`<li data-areaid="${item.Id}" data-areaname="${item.Name}"`;
                                    if(item.Show==1){
                                        area+=` class="table_active"`;
                                    }
                                    area+=`>${item.Name}</li>`;
                                };
                                
                                //分部
                                for(let item of data.Fenbulist){
                                    fenbu+=`<span data-fenbuid="${item.Id}" data-fenbuname="${item.Name}"`;
                                    if(item.Show==1){
                                        fenbu+=` class="select"`;
                                    }
                                    fenbu+=`>${item.Name}</span>`;
                                };
                                //运维班
                                for(let item of data.Ywblist){
                                    ywb+=`<span data-ywbid="${item.Id}" data-ywbname="${item.Name}"`;
                                    if(item.Show==1){
                                        ywb+=` class="select"`;
                                    }
                                    ywb+=`>${item.Name}</span>`;
                                };
                                //变电站
                                for(let item of data.Stationlist){
                                    bdz+=`<span data-stationid="${item.Id}" data-stationname="${item.Name}"`;
                                    if(item.Show==1){
                                        bdz+=` class="select"`;
                                    }
                                    bdz+=`>${item.Name}</span>`;
                                };
                                //设备区
                                for(let item of data.Buildinglist){
                                    sbq+=`<span data-buildingid="${item.Id}" data-buildingname="${item.Name}"`;
                                    if(item.Show==1){
                                        sbq+=` class="select"`;
                                    }
                                    sbq+=`>${item.Name}</span>`;
                                };
                                //红外设备
                                data.Machinelist.forEach( ( item, i ) => {
                                    machine+=`<span data-index="${i}" data-machineid="${item.Id}" data-machinename="${item.Name}"`;
                                    if(item.Show==1){
                                        machine+=` class="select"`;
                                    }
                                    machine+=`>${item.Name}</span>`;
                                })
                                //电力设备
                                for(let item of data.Devicelist){
                                    shebei+=`<span data-deviceid="${item.Id}" data-devicename="${item.Name}"`;
                                    if(item.Show==1){
                                        shebei+=` class="select"`;
                                    }
                                    shebei+=`>${item.Name}</span>`;
                                };
                                $("#tabAll").html(area);
                                $("#fenbuDDAll").html(fenbu);
                                $("#ywbDDAll").html(ywb);
                                $("#bdzDDAll").html(bdz);
                                $("#sbqDDAll").html(sbq);
                                $("#hwsbDDAll").html(machine);
                                $("#sheibeiDDAll").html(shebei);
                        },
                        error:function(err){
                                console.log(err)
                        }
        
                });
    };
    // 历史图像  
    function tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType) {
        
        if(areaid==undefined ){
            var areaid='';
        };
        if(fenbuid==undefined ){
            var fenbuid='';
        };
        if(ywbid==undefined){
            var ywbid='';
        };
        if(stationid==undefined){
            var stationid='';
        };
        if(buildingid==undefined){
            var buildingid='';
        };
        if(devicetype==undefined){
            var devicetype='';
        };
        if(machineid==undefined){
            var machineid='';
        }
        if(deviceid==undefined){
            var deviceid='';
        };
        if(isok==undefined){
            var isok='';
        };
        if(isok==undefined){
            var isok='';
        };
        if(startDate==undefined){
            var startDate='';
        };
        if(endDate==undefined){
            var endDate='';
        };
        $.ajax({
            type:'get',
            url:baseUrl+"UserServices/User_Services.asmx/l_getDeviceImageByUnit",
            dataType:'JSON',  
            data:{
                userid:userid,
                page:page,
                limit:limit,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
                devicetype:devicetype,
                machineid:machineid,
                deviceid:deviceid,
                isok:isok,
                startDate:startDate,
                endDate:endDate,
                isimagered:imgType
            },
            success:function(data){
                var allpage=data.Recordcount;
                var html='';
                var imgs='';
                var datas=data.Recorddt;
                if(allpage!=0){
                    for(let item of datas){
                        var tem=item.todaytop;
                        var imgs1=item.image;
                        
                        if(imgs1!=''&&imgs1!=null&&imgs1!=undefined){
                            imgs=imgs1;
                        }else{
                            imgs=`../images/no_pic.png`;
                        }

                        var Times=item.createtime; // 
                        
                        html+=`<li id="deviceidLi">
                                <div class="item_bg">
                                
                                    <div class="top_pic"   data-deviceid="${item.deviceid}" onclick="left_module3_bigImg(`+ JSON.stringify(item.recordid).replace(/"/g, '&quot;') +`,`+ JSON.stringify(Times).replace(/"/g, '&quot;') +`)">
                                        <img src="${imgs}" alt="">
                                    </div><div class="bot-text">`;
                                if(tem>=100){
                                    html+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                if(tem >= 80 && tem < 100){
                                    html+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                if(tem<80){
                                    html+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                html+= `<div class="botText_right fr">
                                        <p>${item.devicename}</p>
                                        <p class="time">${Times}</p>
                                    </div>
                                </div>
                            </div>
                            <div id="popWindow" class="popWindow"  style="display:none;"  data-recordid="${item.recordid}" data-imgTime="${Times}">
                                <i class="noselImg" style="display:block;"></i>
                                <i class="selImg" style="display:none;"></i>
                            </div>
                        </li>`;
                    };
                }
                $("#containerUl").html(html);
                $(".loding_all").hide();      
            },
            error:function(err){
                    console.log(err)
            }

        });
    
    };
    // 历史图像 分页
    function fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType){
        $(".loding_all").show();
        if(areaid==undefined ){
            var areaid='';
        };
        if(fenbuid==undefined ){
            var fenbuid='';
        };
        if(ywbid==undefined){
            var ywbid='';
        };
        if(stationid==undefined){
            var stationid='';
        };
        if(buildingid==undefined){
            var buildingid='';
        };
        if(devicetype==undefined){
            var devicetype='';
        };
        if(machineid==undefined){
            var machineid='';
        };
        if(deviceid==undefined){
            var deviceid='';
        };
        if(isok==undefined){
            var isok='';
        };
        layui.use(['laydate','laypage', 'layer'], function(){
            var laydate = layui.laydate,
                laypage = layui.laypage
                ,layer = layui.layer;
            var page = 1; //每页
            var limit = 12; //每页显示的条数
            
            $.ajax({
                type:'post',
                url:baseUrl+'UserServices/User_Services.asmx/l_getDeviceImageByUnit',
                data:{
                    userid:userid,
                    page:page,
                    limit:limit,
                    areaid:areaid,
                    fenbuid:fenbuid,
                    ywbid:ywbid,
                    stationid:stationid,
                    buildingid:buildingid,
                    devicetype:devicetype,
                    machineid:machineid,
                    deviceid:deviceid,
                    isok:isok,
                    startDate:startDate,
                    endDate:endDate,
                    isimagered:imgType
                },
                dataType:'json',
                success:function(json){
                    // $(".loding_all").hide();
                    laypage.render({
                        elem: 'pagesImg',
                        count: json.Recordcount,
                        limit:12,
                        layout: [ 'count','prev', 'page', 'next','limit', 'limits'],
                        limits: [12,24,36], //一页选择显示3,5或10条数据
                        jump: function (obj) {
                            page=obj.curr;
                            limit=obj.limits[0];
                            // 历史图像
                            tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType)
                        }
                    });
                }
            });
        });
    };