
var userid='';
var usertype='';
var order=1,orderI=1;
var areaname='', fenbuname="",ywbname='',stationname='',buildingname='',devicetype=''
    ,machinename='',isok='',machinetype='',isonline=''
    ,areaid='',fenbuid='',ywbid='',stationid='',buildingid='',machineid='',isalarm='',deviceid=''
    ,page=1,limit=12,allpage='',allpage2='',timeSpan='';
var startDate='';
var endDate='';
var staralarm='',endalarm='';
var statrTiem='',endTime='',StartTime='',EndTime='';
var starttime='',endtime='',conclusionXs='',typename='',description='',statusSeeAbnormal='',lastDevice=0; //,nextdevice=0
    $(document).ready(function () {

        layui.use(['table','layer'], function(){
            var layer = layui.layer;
            var table = layui.table;
            var $ = layui.jquery
            ,element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块
            var Arr = sessionStorage.arr;//取出首页请求的时候保存的数据
            var datas = $.parseJSON(Arr);
            userid=datas.Userid;
            areaname=datas.Areaname;
            areaid=datas.Areaid;
            usertype=datas.Usertype;
            gaojingstatus();//告警状态
            machineStatus();//红外设备状态
        });
   
    });
   
    // 共用头部选择
    // 工区
    $("#tabAll").on("click",'li',function(){
        $(this).addClass("table_active").siblings().removeClass("table_active");
        // $("#typenameDDAll span").removeClass("select");
        $("#descriptionDDAll span").removeClass("select");
        $("#statusDDAll span").removeClass("select");
        // $("#realTourImg li:first-child").addClass("active").siblings().removeClass("active");
        // $("#realTourImg li:first-child").find("i").show();
        // $("#realTourImg li:first-child").siblings().find("i").hide();
        areaid=$(this).attr("data-areaid");
        fenbuid='',ywbid='',stationid='',buildingid='',machineid='',deviceid='',devicetype='',
        typename='',description='',statusSeeAbnormal='',nextdevice=0,isok='',isonline='';
        gaojingstatus();//告警状态
        machineStatus();//红外设备状态
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);// 开始巡视
        testSeeAbnormalTable(areaid,fenbuid,ywbid,stationid,buildingid,machineid,starttime,endtime,description,statusSeeAbnormal);// 异常查看
        tourRecordTable(areaid,fenbuid,ywbid,stationid,starttime,endtime,conclusionXs);// 巡视记录
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        ws_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid);//温升告警记录
        hightTemTotal(areaid,fenbuid,ywbid,stationid);// 周期测温峰值统计
        system_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isok);// 系统设置
        status_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isonline);// 设备状态

        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
        missingImg(areaid,fenbuid,ywbid,stationid);// 缺图检查
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像分页
        tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);// 历史告警

        // 本月超80℃的设备统计
        // over80_deviceCount(areaid,fenbuid,ywbid,stationid,buildingid);
    });
    // 分部
    $("#fenbuDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        // $("#typenameDDAll span").removeClass("select");
        $("#descriptionDDAll span").removeClass("select");
        $("#statusDDAll span").removeClass("select");
        ywbid='',stationid='',buildingid='',machineid='',deviceid='',devicetype='',
        typename='',description='',statusSeeAbnormal='',nextdevice=0,isok='',isonline='';
        gaojingstatus();//告警状态
        machineStatus();//红外设备状态
        fenbuid=$(this).attr("data-fenbuid");
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);// 开始巡视
        testSeeAbnormalTable(areaid,fenbuid,ywbid,stationid,buildingid,machineid,starttime,endtime,typename,description,statusSeeAbnormal);// 异常查看
        tourRecordTable(areaid,fenbuid,ywbid,stationid,starttime,endtime,conclusionXs);// 巡视记录
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        ws_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid);//温升告警记录
        hightTemTotal(areaid,fenbuid,ywbid,stationid);// 周期测温峰值统计
        system_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isok);// 系统设置
        status_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isonline);// 设备状态
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
        missingImg(areaid,fenbuid,ywbid,stationid);// 缺图检查
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像分页
        tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);// 历史告警

        // 本月超80℃的设备统计
        // over80_deviceCount(areaid,fenbuid,ywbid,stationid,buildingid);
    });
    // 运维班
    $("#ywbDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        // $("#typenameDDAll span").removeClass("select");
        $("#descriptionDDAll span").removeClass("select");
        $("#statusDDAll span").removeClass("select");
        stationid='',buildingid='',machineid='',deviceid='',devicetype='',
        typename='',description='',statusSeeAbnormal='',nextdevice=0,isok='',isonline='';
        gaojingstatus();//告警状态
        machineStatus();//红外设备状态
        ywbid=$(this).attr("data-ywbid");
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);// 开始巡视
        testSeeAbnormalTable(areaid,fenbuid,ywbid,stationid,buildingid,machineid,starttime,endtime,typename,description,statusSeeAbnormal);// 异常查看
        tourRecordTable(areaid,fenbuid,ywbid,stationid,starttime,endtime,conclusionXs);// 巡视记录
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        ws_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid);//温升告警记录
        hightTemTotal(areaid,fenbuid,ywbid,stationid);// 周期测温峰值统计
        system_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isok);// 系统设置
        status_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isonline);// 设备状态
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
        missingImg(areaid,fenbuid,ywbid,stationid);// 缺图检查
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像分页
        tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);// 历史告警

        // 本月超80℃的设备统计
        // over80_deviceCount(areaid,fenbuid,ywbid,stationid,buildingid);
    });
    // 变电站
    $("#bdzDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        // $("#typenameDDAll span").removeClass("select");
        $("#descriptionDDAll span").removeClass("select");
        $("#statusDDAll span").removeClass("select");
        buildingid='',machineid='',deviceid='',devicetype='',
        typename='',description='',statusSeeAbnormal='',nextdevice=0,isok='',isonline='';
        gaojingstatus();//告警状态
        machineStatus();//红外设备状态
        stationid=$(this).attr("data-stationid");
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);// 开始巡视
        testSeeAbnormalTable(areaid,fenbuid,ywbid,stationid,buildingid,machineid,starttime,endtime,description,statusSeeAbnormal);// 异常查看
        tourRecordTable(areaid,fenbuid,ywbid,stationid,starttime,endtime,conclusionXs);// 巡视记录
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        ws_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid);//温升告警记录
        hightTemTotal(areaid,fenbuid,ywbid,stationid);// 周期测温峰值统计
        system_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isok);// 系统设置
        status_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isonline);// 设备状态
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
        missingImg(areaid,fenbuid,ywbid,stationid);// 缺图检查
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像分页
        tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);// 历史告警
        
        // 本月超80℃的设备统计
        // over80_deviceCount(areaid,fenbuid,ywbid,stationid,buildingid);
    });
    // 设备区
    $("#sbqDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        machineid='',deviceid='',devicetype='',nextdevice=0,isok='';
        gaojingstatus();
        buildingid=$(this).attr("data-buildingid");
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        // realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);// 开始巡视
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        ws_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid);//温升告警记录
        system_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isok);// 系统设置

        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
		 testSeeAbnormalTable(areaid,fenbuid,ywbid,stationid,buildingid,machineid,starttime,endtime,description,statusSeeAbnormal);// 异常查看
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);//历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);//历史图像分页
        tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);// 历史告警

        // 本月超80℃的设备统计
        // over80_deviceCount(areaid,fenbuid,ywbid,stationid,buildingid);
    });
    // 设备类型
    $("#sbTypeDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        devicetype=$(this).attr("data-typename");
        deviceid='',isok='';
        gaojingstatus();
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        ws_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid);//温升告警记录
        
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
        
        tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);// 历史告警
    });
    // 红外设备
    $("#hwsbDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        deviceid='',devicetype='';
        machineid=$(this).attr("data-machineid");
        // nextdevice=$(this).attr("data-index");
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        // realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);// 开始巡视
        tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime);// 测温查看
        system_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isok);// 系统设置
		 testSeeAbnormalTable(areaid,fenbuid,ywbid,stationid,buildingid,machineid,starttime,endtime,description,statusSeeAbnormal);// 异常查看
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);//历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);//历史图像分页
    });
    // 电力设备
    $("#sheibeiDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        isok='';
        gaojingstatus();
        deviceid=$(this).attr("data-deviceid");
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        ws_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid);//温升告警记录

        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }
        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);// 历史图像分页
        tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);// 历史告警
        //更多数据分析
        var timeSpanAll=$('#testTime').val();
        if(timeSpanAll!=''&&timeSpanAll!=null&&timeSpanAll!=undefined){
            var tiemArr=timeSpanAll.split("~");
            statrTiem=tiemArr[0];
            endTime=tiemArr[1];
            timeSpan=statrTiem+','+endTime;
        }else{
            timeSpan='';
        }
        search_moreDate(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,timeSpan);
        moreDate_zhexian(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,timeSpan);
    });
    //点击告警状态
    $("#gaojingDD").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        isok=$(this).attr("data-is");
        areaid=$("#tabAll .table_active").attr("data-areaid");
        fenbuid=$("#fenbuDDAll .select").attr("data-fenbuid");
        ywbid=$("#ywbDDAll .select").attr("data-ywbid");
        stationid=$("#bdzDDAll .select").attr("data-stationid");
        buildingid=$("#sbqDDAll .select").attr("data-buildingid");
        devicetype=$("#sbTypeDDAll .select").attr("data-typename");
        deviceid=$("#sheibeiDDAll .select").attr("data-deviceid");
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm)//告警
        tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);// 历史告警
    });
    // 异常类型：
    // $("#typenameDDAll").on("click",'span',function(){
    //     $(this).addClass("select").siblings().removeClass("select");
    //     $("#descriptionDDAll span").removeClass("select");
    //     $("#statusDDAll span").removeClass("select");
    //     typename=$(this).attr("data-typeName");
    //     description='',statusSeeAbnormal='';
    //     abnormalDescription(typename);
    //     top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
    //     // 异常查看
    //     testSeeAbnormalTable(areaid,fenbuid,ywbid,stationid,starttime,endtime,typename,description,statusSeeAbnormal);
    // });
    // 异常描述
    $("#descriptionDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        $("#statusDDAll span").removeClass("select");
        description=$(this).attr("data-description");
        statusSeeAbnormal='';
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        // 异常查看
        testSeeAbnormalTable(areaid,fenbuid,ywbid,stationid,buildingid,machineid,starttime,endtime,description,statusSeeAbnormal);
    });
    // 异常状态
    $("#statusDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        statusSeeAbnormal=$(this).attr("data-status");
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        // 异常查看
        testSeeAbnormalTable(areaid,fenbuid,ywbid,stationid,buildingid,machineid,starttime,endtime,description,statusSeeAbnormal);
    });
    // 巡视结论：
    $("#jielunDDAll").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        conclusionXs=$(this).attr("data-conclusion");
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);//共用头部
        // 异常查看
        tourRecordTable(areaid,fenbuid,ywbid,stationid,starttime,endtime,conclusionXs);
    });

    // 可见光，红外切换
    $("#realTourImg").on("click",'li',function(){
        $(this).addClass("active").siblings().removeClass("active");
        $(this).find(".layui-icon").show();
        $(this).siblings().find(".layui-icon").hide();
        // nextdevice=0;
        imgType=$(this).attr("data-imgtype");
        areaid=$("#tabAll .table_active").attr("data-areaid");
        fenbuid=$("#fenbuDDAll .select").attr("data-fenbuid");
        ywbid=$("#ywbDDAll .select").attr("data-ywbid");
        stationid=$("#bdzDDAll .select").attr("data-stationid");
        buildingid=$("#sbqDDAll .select").attr("data-buildingid");
        machineid=$("#hwsbDDAll .select").attr("data-machineid");
        devicetype=$("#sbTypeDDAll .select").attr("data-typename");
        deviceid=$("#sheibeiDDAll .select").attr("data-deviceid");
        top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid);
        // 历史图像
        var timeAll=$('#Time_datas').val();
        if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
            var tiemArr=timeAll.split("~");
            startDate=tiemArr[0];
            endDate=tiemArr[1];
        }

        tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);//
        fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType);

        // 开始巡视
        realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice);
    });
    //点击红外状态
    $("#status_machineDD").on("click",'span',function(){
        $(this).addClass("select").siblings().removeClass("select");
        areaid=$("#tabAll .table_active").attr("data-areaid");
        fenbuid=$("#fenbuDDAll .select").attr("data-fenbuid");
        ywbid=$("#ywbDDAll .select").attr("data-ywbid");
        stationid=$("#bdzDDAll .select").attr("data-stationid");
        buildingid=$("#sbqDDAll .select").attr("data-buildingid");
        machineid=$("#hwsbDDAll .select").attr("data-machineid");
        devicetype=$("#sbTypeDDAll .select").attr("data-typename");
        isonline=$(this).attr("data-online");
        status_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isonline);// 设备状态
    }); 
    // 共用头部
    function top_selAllCs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid){
        
        var area='',
                fenbu='<span data-fenbuid="">全部</span>',
                ywb='<span data-ywbid="">全部</span>',
                bdz='<span data-stationid="">全部</span>',
                sbq='<span data-buildingid="">全部</span>',
                sbType='<span data-typename="">全部</span>',
                machine='',
                ysd='',
                shebei='<span data-deviceid="">全部</span>';
                if(areaid==undefined||areaid=="全部"){
                    var areaid='';
                }
                if(fenbuid==undefined||fenbuid=="全部"){
                    var fenbuid='';
                }
                if(ywbid==undefined||ywbid=="全部"){
                    var ywbid='';
                }
                if(stationid==undefined||stationid=="全部"){
                    var stationid='';
                }
                if(buildingid==undefined||buildingid=="全部"){
                    var buildingid='';
                }
                if(devicetype==undefined ||devicetype=="全部"){
                    var devicetype='';
                }
                if(deviceid==undefined ||deviceid=="全部"){
                    var deviceid='';
                }
                if(machineid==undefined ||machineid=="全部"){
                    var machineid='';
                }
                
                $.ajax({
                        type:'get',
                        url:baseUrl+'UserServices/User_Services.asmx/thermometryConditions',
                        dataType:'JSON',  
                        data:{
                                userid:userid,
                                areaid:areaid,
                                fenbuid:fenbuid,
                                ywbid:ywbid,
                                stationid:stationid,
                                buildingid:buildingid,
                                devicetype:devicetype,
                                machineid:machineid,
                                deviceid:deviceid
                        },
                        success:function(data){
                                
                                //工区
                                for(let item of data.Arealist){
                                    area+=`<li data-areaid="${item.Id}" data-areaname="${item.Name}"`;
                                    if(item.Show==1){
                                        area+=` class="table_active"`;
                                    }
                                    area+=`>${item.Name}</li>`;
                                };
                                
                                //分部
                                for(let item of data.Fenbulist){
                                    fenbu+=`<span data-fenbuid="${item.Id}" data-fenbuname="${item.Name}"`;
                                    if(item.Show==1){
                                        fenbu+=` class="select"`;
                                    }
                                    fenbu+=`>${item.Name}</span>`;
                                };
                                //运维班
                                for(let item of data.Ywblist){
                                    ywb+=`<span data-ywbid="${item.Id}" data-ywbname="${item.Name}"`;
                                    if(item.Show==1){
                                        ywb+=` class="select"`;
                                    }
                                    ywb+=`>${item.Name}</span>`;
                                };
                                //变电站
                                for(let item of data.Stationlist){
                                    bdz+=`<span data-stationid="${item.Id}" data-stationname="${item.Name}"`;
                                    if(item.Show==1){
                                        bdz+=` class="select"`;
                                    }
                                    bdz+=`>${item.Name}</span>`;
                                };
                                //设备区
                                for(let item of data.Buildinglist){
                                    sbq+=`<span data-buildingid="${item.Id}" data-buildingname="${item.Name}"`;
                                    if(item.Show==1){
                                        sbq+=` class="select"`;
                                    }
                                    sbq+=`>${item.Name}</span>`;
                                };
                                //设备类型
                                for(let item of data.Devicetypelist){
                                    sbType+=`<span data-typeid="${item.Id}" data-typename="${item.Name}"`;
                                    if(item.Show==1){
                                        sbType+=` class="select"`;
                                    }
                                    sbType+=`>${item.Name}</span>`;
                                };
                                //红外设备
                                data.Machinelist.forEach( ( item, i ) => {
                                    machine+=`<span data-index="${i}" data-machineid="${item.Id}" data-machinename="${item.Name}"`;
                                    if(item.Show==1){
                                        machine+=` class="select"`;
                                    }
                                    machine+=`>${item.Name}</span>`;
                                })
                                // for(let item of data.Machinelist){
                                //     machine+=`<span data-index="${item}" data-machineid="${item.Id}" data-machinename="${item.Name}"`;
                                //     if(item.Show==1){
                                //         machine+=` class="select"`;
                                //     }
                                //     machine+=`>${item.Name}</span>`;
                                // };
                                //预设点
                                for(let item of data.Ysdlist){
                                        ysd+=`<li class="li-item">
                                                <div class="item_left fl"  data-ysdid="${item[0]}"><span>${item[1]}</span></div><div class="item_right fr">
                                                <a class="ysd_event ac_edit edit5 layui-btn layui-btn-xs" data-ysdid="${item[0]}" data-event="edit">
                                                        <i class="layui-icon layui-icon-edit"></i>
                                                </a>
                                                <a class="ysd_event ac_del del5 layui-btn layui-btn-xs" data-ysdid="${item[0]}" data-event="del">
                                                        <i class="layui-icon layui-icon-delete"></i>
                                                </a>
                                                </div>
                                                </li><div class="clear"></div>`;
                                };
                                //电力设备
                                for(let item of data.Devicelist){
                                    shebei+=`<span data-deviceid="${item.Id}" data-devicename="${item.Name}"`;
                                    if(item.Show==1){
                                        shebei+=` class="select"`;
                                    }
                                    shebei+=`>${item.Name}</span>`;
                                };
                                $("#tabAll").html(area);
                                $("#fenbuDDAll").html(fenbu);
                                $("#ywbDDAll").html(ywb);
                                $("#bdzDDAll").html(bdz);
                                $("#sbqDDAll").html(sbq);
                                $("#sbTypeDDAll").html(sbType);
                                $("#hwsbDDAll").html(machine);
                                // $("#status_shebeiDDAll").html(machine);
                                $("#sheibeiDDAll").html(shebei);
								
                                // $(".loding_bg").hide();
                        },
                        error:function(err){
                                console.log(err)
                        }
        
                });
    };

    // 开始巡视     firstIn==0首次进入开始巡视页面，高亮上边选择
    function realHighImgs(imgType,areaid,fenbuid,ywbid,stationid,buildingid,machineid,nextdevice,firstIn){
        $(".loding_bg").show();
        if(areaid==undefined||areaid=="全部"){
            var areaid='';
        }
        if(fenbuid==undefined||fenbuid=="全部"){
            var fenbuid='';
        }
        if(ywbid==undefined||ywbid=="全部"){
            var ywbid='';
        }
        if(stationid==undefined||stationid=="全部"){
            var stationid='';
        }
        if(buildingid==undefined||buildingid=="全部"){
            var buildingid='';
        }
        if(machineid==undefined ||machineid=="全部"){
            var machineid='';
        }
        
        var urls="UserServices/User_Services.asmx/s_patrol";
        $.ajax({
            type:'get',
            url:baseUrl+urls,
            dataType:'JSON',  
            data:{
                userid:userid,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
                machineid:machineid,
                nextdevice:nextdevice,
                imagetype:imgType
            },
            success:function(data){
				var areaidXs=data.areaid;
				var fenbuidXs=data.fenbuid;
				var ywbidXs=data.ywbid;
				var stationidXs=data.stationid;
				var buildingidXs=data.buildingid;
				var machineidXs=data.machineid;
				if(data.Imagedt[0].deviceid != undefined){
					var deviceidXs = data.Imagedt[0].deviceid;
				}else{
					var deviceidXs = '';
				}
				
				hisHoursImg(userid,areaidXs,fenbuidXs,ywbidXs,stationidXs,machineidXs,deviceidXs);//24小时图片
                if(firstIn==0){
                    top_selAllCs(areaidXs,fenbuidXs,ywbidXs,stationidXs,buildingidXs,devicetype,machineidXs,deviceid);
                }
                var html='';
                if(lastDevice==1){
                    html+=`<p class="noDateP">暂无数据</p>`;
                }else{
                    if(data.Imagedt.length>0){
                        html+=`<div class="content-item">
                            <div class="item-title">
                                <img src="images/temC.png" alt="">
                                <span>${data.machinename}</span>
                                <button data-machineid='${data.machineid}' class='device_offline' type="button">下线</button>
                            </div>
                            
                            <ul class="item-container">`;
                        
                            for(let item of data.Imagedt){
                                html+=`<li data-deviceid="${item.deviceid}" data-machineid="${item.machineid}" data-ysdName="${item.ysdname}" id="deviceidLi">`;
                                var imgs1=item.image;
                                if(imgs1!=''&&imgs1!=null&&imgs1!=undefined){
                                    html+=`<div class="item_bg">
                                    <div class='item_cont' deviceid=`+item.deviceid+`>
                                        <div class="top_pic"><img src="${imgs1}" alt=""/></div>`;

                                }else{
                                    html+=`<div class="item_bg">
                                    <div>
                                        <div class="top_pic"><img src="../images/no_pic.png" alt=""/></div>`;
                                }
                                var tem=item.todaytop;
                                var time=item.createtime; ///Date(158 572 227 7000)/
                                var Times='';
                                if(time==''||time==null){
                                    Times='';
                                }else{
                                    Times=(item.createtime).replace(/\T/g," ");
                                    
                                }
                                html+=`<div class="bot-text">`;
                                                if(tem>=100){
                                                    html+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
                                                }
                                                if(tem >= 80 && tem < 100){
                                                    html+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
                                                }
                                                if(tem<80){
                                                    html+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
                                                }
                                                // <div class="botText_left fl">${} <span>℃</span></div>
                                                html+=`<div class="botText_right fr">
                                                            <p>${item.devicename}</p>
                                                            <p class="time">${Times}</p>
                                                        </div>
                                                </div>
                                        </div>
                                        <div class="botBtn">`;
                                            if(item.patrolStatus==0||item.patrolStatus==null){
                                                html+=`<div class="botBtnItem1 botBtnItem" data-deviceid="${item.deviceid}">
                                                    <p class="botBtnItemNormal1" style="display:none;"><img src="../images/xunshiIcon/normal2.png" alt=""/><span>正常</span></p>
                                                    <p class="normal"><img src="../images/xunshiIcon/normal1.png" alt=""/><span>正常</span></p>
                                                </div>
                                                <div class="botBtnItem2 botBtnItem" deviceName="${item.devicename}" data-deviceid="${item.deviceid}"  machineid='`+data.machineid+`' areaid='`+data.areaid+`' fenbuid='`+data.fenbuid+`' ywbid='`+data.ywbid+`' stationid='`+data.stationid+`'>
                                                    <p class="botBtnItemAbnormal1"><img src="../images/xunshiIcon/abnormal2.png" alt=""/><span>异常</span></p>
                                                    <p class="abnormal" style="display:none;"><img src="../images/xunshiIcon/abnormal1.png" alt=""/><span>异常</span></p>
                                                </div>`;
                                            }else{
                                                if(item.patrolStatus==2){
                                                  html+=`<div class="botBtnItem1 botBtnItem" data-deviceid="${item.deviceid}">
                                                      <p class="botBtnItemNormal1"><img src="../images/xunshiIcon/normal2.png" alt=""/><span>正常</span></p>
                                                      <p class="normal"  style="display:none;"><img src="../images/xunshiIcon/normal1.png" alt=""/><span>正常</span></p>
                                                  </div>
                                                  <div class="botBtnItem2 botBtnItem" deviceName="${item.devicename}" data-deviceid="${item.deviceid}"  machineid='`+data.machineid+`' areaid='`+data.areaid+`' fenbuid='`+data.fenbuid+`' ywbid='`+data.ywbid+`' stationid='`+data.stationid+`'>
                                                      <p class="botBtnItemAbnormal1"  style="display:none;"><img src="../images/xunshiIcon/abnormal2.png" alt=""/><span>异常</span></p>
                                                      <p class="abnormal"><img src="../images/xunshiIcon/abnormal1.png" alt=""/><span>异常</span></p>
                                                  </div>`;
                                                }
                                                if(item.patrolStatus==1){
                                                   html+=`<div class="botBtnItem1 botBtnItem" data-deviceid="${item.deviceid}">
                                                       <p class="botBtnItemNormal1"style="display:none;"><img src="../images/xunshiIcon/normal2.png" alt=""/><span>正常</span></p>
                                                       <p class="normal"><img src="../images/xunshiIcon/normal1.png" alt=""/><span>正常</span></p>
                                                   </div>
                                                   <div class="botBtnItem2 botBtnItem" deviceName="${item.devicename}" data-deviceid="${item.deviceid}"  machineid='`+data.machineid+`' areaid='`+data.areaid+`' fenbuid='`+data.fenbuid+`' ywbid='`+data.ywbid+`' stationid='`+data.stationid+`'>
                                                       <p class="botBtnItemAbnormal1"><img src="../images/xunshiIcon/abnormal2.png" alt=""/><span>异常</span></p>
                                                       <p class="abnormal"  style="display:none;"><img src="../images/xunshiIcon/abnormal1.png" alt=""/><span>异常</span></p>
                                                   </div>`;
                                                }
                                            }
                                        html+=`</div>
                                    </div>
                                    
                                </li>`;
                            }
                            
                            
                        html+=`</ul>
                        </div> `;
                    }else{
                        html+=`<p class="noDateP">暂无数据</p>`;
                    }
                }
               html+=` <div class="bottom_btn">
                   <div class="bottom_btn1" stationid='`+data.stationid+`' nextstationid='`+data.nextstationid+`' data-nextdevice="`+nextdevice+`" data-lastDevice="`+data.isLast+`" data-machineid="`+data.machineid+`">下一个设备<i class="layui-icon  layui-icon-right"></i> </div>
                   <div class="bottom_btn3"  buildingid ='`+data.buildingid+`' stationid='`+data.stationid+`'>结束巡视</div>
               </div>`;
                $("#xunShiContentImgs").html(html);
				$(".loding_bg").hide();
				$('#xunShiContentImgs').on('click','.item_cont',function(){
					var deviceid = $(this).attr('deviceid')
					hisHoursImg(userid,areaidXs,fenbuidXs,ywbidXs,stationidXs,machineidXs,deviceid);//24小时图片
				})
            },
            error:function(err){
                alert("网络错误，请联系技术人员！")
            }
        });
    };
    // //点击图片 查看24小时历史图像
    function hisHoursImg(userid,areaid,fenbuid,ywbid,stationid,machineid,deviceid){
        $.ajax({
            type:'get',
            url:baseUrl+'UserServices/User_Services.asmx/findImageByDevieid',
            dataType:'JSON',
            data:{
                userid:userid,
				areaid:areaid,
				fenbuid:fenbuid,
				ywbid: ywbid,
				stationid:stationid,
				machineid:machineid,
                deviceid:deviceid
            },
            success:function(data){
                var html='';
                var image0='',image1='',image2='';
                if(data.length>0){
                    for(let item of data){
                        html+=`<ul class="item_ImgItem" createtime="`+item.createtime+`" recordid="`+item.recordid+`">`;
                        image0=item.image0;
                        image1=item.image1;
                        image2=item.image2;
                        if(image0==''&&image0==null&&image0==undefined){
                            image0='../images/no_pic.png';;
                        };
                        if(image1==''&&image1==null&&image1==undefined){
                            image1='../images/no_pic.png';
                        };
                        if(image2==''&&image2==null&&image2==undefined){
                            image2='../images/no_pic.png';
                        };
                        var tem=item.valuemax;
                        var time=item.createtime; ///Date(158 572 227 7000)/
                        var Times='';
                        if(time==''||time==null){
                            Times='';
                        }else{
                            Times=(item.createtime).replace(/\T/g," ");
                            
                        }
                        var imgsArr=[image0,image1,image2];
                        for(let itemImg of imgsArr){
                            html+=`<li data-deviceid="${item.deviceid}">
                                    <div class="item_bg">
                                        <div class="top_pic"><img src="${itemImg}" alt=""/></div>
                                        <div class="bot-text">`;
                                            if(tem>=100){
                                                html+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
                                            }
                                            if(tem >= 80 && tem < 100){
                                                html+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
                                            }
                                            if(tem<80){
                                                html+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
                                            }
                                            html+=`<div class="botText_right fr">
                                                        <p>${item.devicename}</p>
                                                        <p class="time">${Times}</p>
                                                    </div>
                                        </div>
                                    </div>
									<div style="display:none;" class="popWindow">
										<i class="noselImg"></i>
										<i class="selImg"></i>
									</div>
                                </li>`;
                        }
                        html+=`</ul>`;
						
                    }
                }else{
                    html+=`<p class="noDateP">暂无数据</p>`;
                }
                    
                $("#hoursHisImgs").html(html);
            },
            error:function(err){
                alert("网络错误，请联系技术人员")
            }

        });
    }
    // 异常查看
    function testSeeAbnormalTable(areaid,fenbuid,ywbid,stationid,buildingid,machineid,starttime,endtime,description,statusSeeAbnormal) {
        if(areaid==undefined||areaid=="全部"){
        var areaid='';
        }
        if(fenbuid==undefined ||areaid=="全部"){
            var fenbuid='';
        }
        if(ywbid==undefined||areaid=="全部"){
            var ywbid='';
        }
        if(stationid==undefined||areaid=="全部"){
            var stationid='';
        }
        
        layui.use(['table','layer'], function(){
            var layer = layui.layer;
            var table = layui.table;
            table.render({
                elem: '#testSeeAbnormal'
                ,height:670
                ,where:{
                    userid:userid,
                    areaid:areaid,
                    fenbuid:fenbuid,
                    ywbid:ywbid,
                    stationid:stationid,
					buildingid:buildingid,
					machineid:machineid,
                    starttime:starttime,
                    endtime:endtime,
                    // typename:typename,
                    typeid:description,
                    status:statusSeeAbnormal
                }
                ,url: baseUrl+"UserServices/User_Services.asmx/findDeviceException" //数据接口
                ,parseData:function(res){
                return{
                    "code":0
                    ,"mag":0
                    ,"count":res.count
                    ,"data":res.exceptionlist
                }
                }
                ,cols: [[ //表头
                // {type:'checkbox', width:'2%'},
                {field: 'createtime', title: '巡视时间',templet:function(data){
                    var Times='';
                    var times='';
                    times=data.createtime;
                    if(times==''||times==null){
                        Times='';
                    }else{
                        Times=(data.createtime).replace(/\T/g," ");
                    }
                    return Times;
                    }, width:'9%'}
                ,{field: 'discoverer', title: '发现人', width:'6%'}
                ,{field: 'areaname', title: '工区', width:'6%'}
                ,{field: 'fenbuname', title: '分部', width:'6%'}
                ,{field: 'stationname', title: '巡视站点',width:'6%'}
				,{field: 'buildingname', title: '设备区', width:'9%'}
                ,{field: 'machinename', title: '红外设备', width:'6%'}
				 ,{field: 'machinemac', title: 'mac地址', width:'6%'}
                ,{field: 'machinecode', title: '设备编号', width:'6%'}
                ,{field: 'devicename', title: '电力设备', width:'9%'}
				,{field: 'maintainStatus', title: '维修状态',templet:function(data){
					var wxState='';
					var state = data.maintainStatus;
					if(state==1){
					    wxState +='<p class="green"><span></span>已解决</p>';
					}if(state==2){
					    wxState+='<p class="red"><span></span>未解决</p>';
					}
					return wxState;
				},width:'9%'}
                ,{field: 'conclusion', title: '异常状态',templet:function(data){
                    var yCStatus='';
                    var conclusionZY=data.status;
                    if(conclusionZY=='0'){
                        yCStatus='<p class="green"><span></span>已消除</p>';
                    }else{
                        yCStatus='<p class="red"><span></span>未消除</p>';
                    }
                    return yCStatus;
                }, width:'9%'}
                ,{field: 'description', title: '异常描述', width:'9%'}
                ,{field: 'catchtime', title: '抓拍时间',templet:function(data){
                    var Times='';
                    var times='';
                    times=data.catchtime;
                    if(times==''||times==null){
                        Times='';
                    }else{
                        Times=(data.catchtime).replace(/\T/g," ");
                    }
                    return Times;
                    }, width:'9%'}
                ,{field: '', title: '图片',templet:function(data){
                    var imgs1=data.image_mix;
                    var imgs2=data.image_red;
                    var imgs3=data.image_high;
                    
                    if(imgs1!=''&&imgs1!=null&&imgs1!=undefined){
                        var html=`<img onclick="leftTop(`+ JSON.stringify(data).replace(/"/g, '&quot;') +`)" src="`+imgs1+`" style="height:50px;max-width:70px;">`;
                    }else if(imgs2!=''&&imgs2!=null&&imgs2!=undefined){
                        var html=`<img onclick="leftTop(`+ JSON.stringify(data).replace(/"/g, '&quot;') +`)" src="`+imgs2+`" style="height:50px;max-width:70px;">`;
                    }else if(imgs3!=''&&imgs3!=null&&imgs3!=undefined){
                        var html=`<img onclick="leftTop(`+ JSON.stringify(data).replace(/"/g, '&quot;') +`)" src="`+imgs3+`" style="height:50px;max-width:70px;">`;
                    }else{
                        var html='<img src="../images/no_picTable.png" style="height:50px;max-width:70px;">';
                    }
                    return html;
                }, width:'7%'}
                ,{field: '', title: '操作', width:'8%',toolbar: '#operate',fixed: 'right'}
                ]]
                ,page: true //开启分页
                ,limits: [11,22,33]  //一页选择显示3,5或10条数据
                ,limit: 11  //一页显示10条数据
            });
        });
    };
    // 巡视记录
    function tourRecordTable(areaid,fenbuid,ywbid,stationid,starttime,endtime,conclusion) {
        if(areaid==undefined ){
        var areaid='';
        }
        if(fenbuid==undefined ){
            var fenbuid='';
        }
        if(ywbid==undefined){
            var ywbid='';
        }
        if(stationid==undefined){
            var stationid='';
        }
        if(starttime==undefined){
            var starttime='';
        }
        if(endtime==undefined){
            var endtime='';
        }
        layui.use(['table','layer'], function(){
            var layer = layui.layer;
            var table = layui.table;
            table.render({
                elem: '#tourRecordTable'
                ,height:715
                ,where:{
                    userid:userid,
                    areaid:areaid,
                    fenbuid:fenbuid,
                    ywbid:ywbid,
                    stationid:stationid,
                    starttime:starttime,
                    endtime:endtime,
                    inspector:'',
                    conclusion:conclusion
                }
                ,url: baseUrl+"UserServices/User_Services.asmx/findDevicePatorl" //数据接口
                ,parseData:function(res){
                    return{
                        "code":0
                        ,"mag":0
                        ,"count":res.count
                        ,"data":res.patrollist
                    }
                }
                ,cols: [[ //表头
                // {type:'checkbox', width:'2%'},
                {field: 'createtime', title: '巡视时间',templet:function(data){
                    var Times='';
                    var times='';
                    times=data.createtime;
                    if(times==''||times==null){
                        Times='';
                    }else{
                        Times=(data.createtime).replace(/\T/g," ");
                    }
                    return Times;
                    }, width:'10%'}
                ,{field: 'inspector', title: '人员', width:'10%'}
                ,{field: 'areaname', title: '工区', width:'10%'}
                ,{field: 'fenbuname', title: '分部', width:'10%'}
                ,{field: 'ywbname', title: '运维班', width:'10%'}
                ,{field: 'stationname', title: '巡视站点',width:'10%'}
                ,{field: 'conclusion', title: '结论',templet:function(data){
                    var retuConclusion='';
                    var conclusionZY=data.conclusion;
                    if(conclusionZY=='正常'){
                        retuConclusion='<p class="green"><span></span>正常</p>';
                    }else{
                        retuConclusion='<p class="red"><span></span>异常</p>';
                    }
                    return retuConclusion;
                    }, width:'10%'}
                ,{field: 'exceptionnumber', title: '异常数量', width:'10%'}
                ,{field: 'patrolnumber', title: '巡视设备数量', width:'10%'}
                ,{field: 'conclusion', title: '操作', width:'10%',toolbar: '#operate'}
                ]]
                ,page: true //开启分页
                ,limits: [12,24,36]  //一页选择显示3,5或10条数据
                ,limit: 12  //一页显示10条数据
            });
        });
        
    
    };
    // 降序 时间
    $(".gaojing_table").on('click',"#sort_bottomTimeI",function(){
        $(this).addClass("sort_botSel");
        orderI=1;
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm);
    });
    // 降序 温度
    $(".gaojing_table").on('click',"#sort_bottomWdI",function(){
        $(this).addClass("sort_botSel");
        orderI=0;
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm);
    });
    $(".xia_rightItems").on('click',".item",function(){
        staralarm=$(this).attr("data-min");
        endalarm=$(this).attr("data-max");
        gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm);
    });
    // 告警
    function gaojing(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok,staralarm,endalarm) {
        if(areaid==undefined||areaid==null||areaid==0 ){
          var areaid='';
        };
        if(fenbuid==undefined ){
            var fenbuid='';
        };
        if(ywbid==undefined){
            var ywbid='';
        };
        if(stationid==undefined){
            var stationid='';
        };
        if(buildingid==undefined){
            var buildingid='';
        };
        if(devicetype==undefined){
            var devicetype='';
        };
        if(deviceid==undefined){
            var deviceid='';
        };
        if(isok==undefined){
            var isok='';
        };
        
        layui.use(['table','layer'], function(){
          var layer = layui.layer;
          var table = layui.table;
          table.render({
            elem: '#test'
            ,height:615
            // ,width:800
            ,where:{
                order:orderI,
                userid:userid,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
                devicetype:devicetype,
                deviceid:deviceid,
                isok:isok,
                staralarm:staralarm,
                endalarm:endalarm
            }
            ,url:baseUrl+"UserServices/User_Services.asmx/l_getAlarmByUnit" //数据接口
            ,parseData:function(res){
              return{
                  "code":0
                  ,"mag":0
                  ,"count":res.Recordcount
                  ,"data":res.Recorddt
              }
            }
            ,cols: [[ //表头
              {type:'checkbox', width:'50'}
              ,{field: 'areaname', title: '工区', width:'120'}
              ,{field: 'fenbuname', title: '分部', width:'110'}
              ,{field: 'ywbname', title: '班组',width:'110'}
              ,{field: 'stationname', title: '变电站', width:'110'} 
              ,{field: 'buildingname', title: '设备区', width:'150'}
              ,{field: 'devicename', title: '电力设备', width:'180'}
              ,{field: 'createtime', title: '<span  id="sort_bottomTimeI">告警时间<i class="sort_bottomTime sort_bottom"></i></span>',templet:function(data){
                    var time=data.createtime; ///Date(158 572 227 7000)/
                    var Times=''
                    if(time==''||time==null){
                      Times='';
                    }else{
                      Times=(data.createtime).replace(/\T/g," ");
                    }
                    
                    return Times;
                }, width:'9%'}
              ,{field: 'alarmvalue', title: '<span  id="sort_bottomWdI">告警温度<i class="sort_bottom"></i></span>', width:'7%'}
              ,{field: 'offsetvalue', title: '告警阈值', width:'6%'}
              ,{field: 'offsethuman', title: '设定人', width:'5%'}
              ,{field: 'isalarm', title: '告警状态', width:'6%',templet:function(data){
                  if(data.isok==0){
                    var isalarm="<p class='green'><span></span>已确认</p>"
                  }else{
                    var isalarm="<p class='red'><span></span>未确认</p>"
                  }
                  return isalarm
              },}
              ,{field: 'fuhe', title: '负荷', width:'4%'}
              ,{field: 'mensurehuman', title: '确认人', width:'5%'}
              ,{field: 'mensuretime', title: '确认时间', width:'9%',templet:function(data){
                  var time=data.mensuretime; ///Date(158 572 227 7000)/
                  var Times=''
                  if(time==''||time==null){
                    Times='';
                  }else{
                    Times=(data.mensuretime).replace(/\T/g," ");
                  }
                  return Times;
              },}
              ,{fixed: 'right',field: '', title: '报告', width:'4%',toolbar: '#report'}
              ,{fixed: 'right',field: '', title: '操作', width:'4%',toolbar: '#operate'},
			  ,{fixed: 'right',field: '', title: '', width:'4%',toolbar: '#realVideo'}
            ]]
            ,page: true //开启分页
            ,limits: [10,20,30]  //一页选择显示3,5或10条数据
            ,limit: 10  //一页显示10条数据
          });
        });
        
      
    };
    // 温升告警记录
    function ws_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid) {
        if(areaid==undefined){
          var areaid='';
        };
        if(fenbuid==undefined ){
            var fenbuid='';
        };
        if(ywbid==undefined){
            var ywbid='';
        };
        if(stationid==undefined){
            var stationid='';
        };
        if(buildingid==undefined){
            var buildingid='';
        };
        if(devicetype==undefined){
            var devicetype='';
        };
        if(deviceid==undefined){
            var deviceid='';
        };
        layui.use(['table','layer'], function(){
          var layer = layui.layer;
          var table = layui.table;
          table.render({
            elem: '#table_ws'
            ,height:660
            ,where:{
                userid:userid,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
                devicetype:devicetype,
                deviceid:deviceid
            }
            ,url: baseUrl+"ReportServic/reportServices.asmx/getRaseOver20" //数据接口
            ,parseData:function(res){
              return{
                  "code":0
                  ,"mag":0
                  ,"count":res.Recordcount
                  ,"data":res.Recordlist
              }
            }
            ,cols: [[ //表头
              {field: 'createtime', title: '告警时间', width:'10%',templet:function(data){
                var time=data.createtime; ///Date(158 572 227 7000)/
                var Times='';
                if(time==''||time==null){
                  Times='';
                }else{
                  Times=(data.createtime).replace(/\T/g," ");
                }
                
                return Times;
              },}
              ,{field: 'areaname', title: '工区', width:'10%'}
              ,{field: 'fenbuname', title: '分部', width:'10%'}
              ,{field: 'ywbname', title: '班组',width:'10%'}
              ,{field: 'stationname', title: '变电站', width:'10%'} 
              ,{field: 'buildingname', title: '设备区', width:'10%'}
              ,{field: 'devicename', title: '设备', width:'10%'}
              ,{field: 'lasttemp', title: '上次温度', width:'10%'}
              ,{field: 'nowtemp', title: '当前温度', width:'10%'}
              ,{field: 'overtemp', title: '告警温度', width:'10%'}
            ]]
            ,page: true //开启分页
            ,limits: [11,22,33]  //一页选择显示3,5或10条数据
            ,limit: 11  //一页显示10条数据
          });
        });
        
      
    };
    // 周期测温峰值
    function hightTemTotal(areaid,fenbuid,ywbid,stationid){
        $(".loding_all").show();
        $.ajax({
          type:'get',
          url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/getStation_TYWMH',
          dataType:'JSON',  
          data:{
              userid:userid,
              areaid:areaid,
              fenbuid:fenbuid,
              ywbid:ywbid,
              stationid:stationid
          },
          success:function(data){
              $(".loding_all").hide();
              var listStations=data.Stationidlist;
              var stationName=data.Stationlist;
              var todayTem=data.Todaylist;
              var yesterdayTem=data.Yestodaylist;
              var weekTem=data.Weeklist;
              var monthTem=data.Monthlist;
              hightTem(listStations,stationName,todayTem,yesterdayTem,weekTem,monthTem);
              hightTem_bigImg(listStations[0]);
          },
          error:function(err){
                  console.log(err)
          }

        });
        
    };
    // 系统设置
    function system_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isok) {
        if(areaid==undefined ){
          var areaid='';
        }
        if(fenbuid==undefined ){
            var fenbuid='';
        }
        if(ywbid==undefined){
            var ywbid='';
        }
        if(stationid==undefined){
            var stationid='';
        }
        if(buildingid==undefined){
            var buildingid='';
        }
        if(devicetype==undefined){
            var devicetype='';
        }
        if(machineid==undefined){
            var machineid='';
        }
        if(isok==undefined){
            var isok='';
        }
        layui.use(['table','layer'], function(){
          var layer = layui.layer;
          var table = layui.table;
          table.render({
            elem: '#test_set'
            ,height:615
            ,where:{
              userid:userid,
              areaid:areaid,
              fenbuid:fenbuid,
              ywbid:ywbid,
              stationid:stationid,
              buildingid:buildingid,
              devicetype:devicetype,
              machineid:machineid,
              isok:isok,
            }
            ,url: baseUrl+"UserServices/User_Services.asmx/l_getdeviceByUnit" //数据接口
            ,parseData:function(res){
              return{
                  "code":0
                  ,"mag":0
                  ,"count":res.Recordcount
                  ,"data":res.Recorddt
              }
            }
            ,cols: [[ //表头
              {type:'checkbox', width:'3%'}
              ,{field: 'areaname', title: '工区', width:'10%'}
              ,{field: 'fenbuname', title: '分部', width:'10%'}
              ,{field: 'ywbname', title: '班组',width:'9%'}
              ,{field: 'stationname', title: '变电站', width:'9%'} 
              ,{field: 'buildingname', title: '设备区', width:'10%'}
              ,{field: 'machinename', title: '红外设备', width:'10%'}
              ,{field: 'devicename', title: '电力设备', width:'15%'}
              ,{field: 'onlinetime', title: '安装时间', width:'9%',templet:function(data){
                  var time=data.onlinetime; ///Date(158 572 227 7000)/
                  var  Times='';
                  if(time==''||time==null){
                    Times='';
                  }else{
                    Times=(data.onlinetime).replace(/\T/g," ");
                  }
                  
                  return Times;
              },}
              ,{field: 'isroundpoint', title: '实时监测', width:'5%',templet:function(data){
                if(data.isroundpoint==1){
                  var isroundpoint="<span class='ls'><i class='right layui-icon layui-icon-ok'></i></span>"
                }else{
                  var isroundpoint="<span class='hs'><i class='error layui-icon layui-icon-close'></i></span>"
                }
                return isroundpoint
              },event: 'viewRoundpoint'}
              ,{field: 'iskeypoint', title: '重点监测', width:'5%',templet:function(data){
                if(data.iskeypoint==1){
                  var iskeypoint="<span class='ls'><i class='right layui-icon layui-icon-ok'></i></span>"
                }else{
                  var iskeypoint="<span class='hs'><i class='error layui-icon layui-icon-close'></i></span>"
                }
                return iskeypoint
              },event: 'viewKeypoint'}
              ,{field: 'isopen', title: '启用', width:'5%',templet:function(data){
                if(data.isopen==1){
                  var isopen="<span class='ls'><i class='right layui-icon layui-icon-ok'></i></span>"
                }else{
                  var isopen="<span class='hs'><i class='error layui-icon layui-icon-close'></i></span>"
                }
                return isopen
              },event: 'viewOpen'}
              
            ]]
            ,page: true //开启分页
            ,limits: [10,20,30]  //一页选择显示3,5或10条数据
            ,limit: 10  //一页显示10条数据
          });
        });
        
      
    };
    
    // 设备状态
    function status_table(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isonline) {
        if(areaid==undefined||areaid==null||areaid==0 ){
            var areaid='';
        };
        if(fenbuid==undefined ){
            var fenbuid='';
        };
        if(ywbid==undefined){
            var ywbid='';
        };
        if(stationid==undefined){
            var stationid='';
        };
        if(buildingid==undefined){
            var buildingid='';
        };
        if(devicetype==undefined){
            var devicetype='';
        }
        if(machineid==undefined){
            var machineid='';
        }
        if(isonline==undefined){
            var isonline='';
        }
        layui.use(['table','layer'], function(){
          var layer = layui.layer;
          var table = layui.table;
          table.render({
            elem: '#test_stu'
            ,height:715
            ,where:{
              userid:userid,
              areaid:areaid,
              fenbuid:fenbuid,
              ywbid:ywbid,
              stationid:stationid,
              buildingid:buildingid,
              machinetype:devicetype,
              machineid:machineid,
              isonline:isonline
            }
            ,url: baseUrl+"UserServices/User_Services.asmx/l_getmachineByUnit" //数据接口
            ,parseData:function(res){
              return{
                  "code":0
                  ,"mag":0
                  ,"count":res.Recordcount
                  ,"data":res.Recorddt
              }
            }
            ,cols: [[ //表头
              {type:'checkbox', width:'50'}
              ,{field: 'areaname', title: '工区', width:'120'}
              ,{field: 'fenbuname', title: '分部', width:'120'}
              ,{field: 'ywbname', title: '班组',width:'110'}
              ,{field: 'stationname', title: '变电站', width:'110'} 
              ,{field: 'buildingname', title: '设备区', width:'150'}
              ,{field: 'machinename', title: '设备', width:'80'}
              ,{field: 'IsHeart', title: '心跳', width: '60', templet: function (data) {
                  var hid = "hid_" + data.machinemac
				  // console.log('获取数据========='+hid)
                  HeartbeatHelper.monitor(hid)
				  // console.log('查询之后========='+hid)
                  var heartstate = "<p id='" + hid + "'><span class='yello'>刷新中...</span></p>"
				  // console.log('heartstate======='+heartstate)
                  return heartstate
              },}
              ,{field: 'machinestate', title: '状态', width:'80',templet:function(data){
                if(data.machinestate=='在线'){
                  var machinestate="<p class='green'><span></span>在线</p>"
                }else if(data.machinestate=='失联'){
                  var machinestate="<p class='red'><span></span>失联</p>"
                }else{
                  var machinestate="<p class='yello'><span></span>拆除</p>"
                }
                return machinestate
              },}
              ,{field: 'machinecode', title: '编号', width:'80'}
              ,{field: 'machinemac', title: 'mac地址', width:'110'}
              // ,{field: 'fushelv', title: '辐射率', width:'5%'}
              ,{field: 'createtime', title: '更新时间',templet:function(data){
                  var Times='';
                  var times='';
                  times=data.createtime;
                  if(times==''||times==null){
                    Times='';
                  }else{
                    Times=(data.createtime).replace(/\T/g," ");
                  }
                  return Times;
                }, width:'9%'}
              ,{field: 'imagecatchspan', title: '抓拍周期', width:'6%',templet:function(data){
                    var imagecatchspan='';
                    if(data.imagecatchspan==null||data.imagecatchspan==''){
                      imagecatchspan=0+"min";
                    }else{
                      imagecatchspan=(data.imagecatchspan)+"min";
                    }
                    return imagecatchspan;
              },}
              ,{field: 'newversion', title: '巡视周期', width:'6%',templet:function(data){
                  var newversion='';
                  if(data.newversion==null||data.newversion==''){
                    newversion=0+"min";
                  }else{
                    newversion=(data.newversion)+"min";
                  }
                  return newversion;
              },}            
              ,{field: 'piflirversion', title: '版本号', width:'10%'}
			  ,{field: 'fluxtype', title: '流量类型', width:'5%'}
			  ,{field: 'fluxNumber', title: '流量卡号', width:'10%'}
              ,{field: 'machinecompany', title: '厂家', width:'5%'}
              ,{fixed: 'right',field: '', title: '操作', width:'5%',toolbar: '#operate'}
            ]]
            ,page: true //开启分页
            ,limits: [12,24,36]  //一页选择显示3,5或10条数据
            ,limit: 12  //一页显示10条数据
          });
        });
        
      
    };

    // 开始巡视里的 测温查看
    function tem_mentImgs(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,isalarm,starttime,endtime){
        $(".loding_bg").show();
        var html='';
        var area='',fenbu='',ywb='',bdz='',sbq='',machine='';
        var imgs='';
        if(areaid==undefined ){
            var areaid='';
        }
        if(fenbuid==undefined){
            var fenbuid='';
        }
        if(ywbid==undefined){
          var ywbid='';
        }
        if(stationid==undefined){
            var stationid='';
        }
        if(buildingid==undefined){
            var buildingid='';
        }
        if(devicetype==undefined){
            var devicetype='';
        }
        if(machineid==undefined){
            var machineid='';
        }
        if(isalarm==undefined){
            var isalarm='';
        }
        // var timeAll=$('#Time_datasTe').val();
        // if(timeAll!=''&&timeAll!=null&&timeAll!=undefined){
        //     var tiemArr=timeAll.split("~");
        //     starttime=tiemArr[0];
        //     endtime=tiemArr[1];
        // }
        var urls="TableService/Infra_Red_Table_Services.asmx/WebX_getImageListBystation";
        $.ajax({
            type:'get',
            url:baseUrl+urls,
            dataType:'JSON',  
            data:{
                userid:userid,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
                devicetype:devicetype,
                machineid:machineid,
                isalarm:isalarm,
                StartTime:'',
                EndTime:''
            },
            success:function(data){
                var html='';
            //   ${item.Machinename} 后面<div class="tem-videos" id="tem-videos"><span>实时视频</span></div>
                if(data.Json.length>0){       
                    for(let item of data.Json){
                        html+=`
                            <div class="content-item">
                            <div class="item-title" id="deviceidLi" data-machineid="${item.Machineid}" data-ysdName="" style="cursor: pointer;">
                                <img src="images/temC.png" alt="">
                                <span>${item.Machinename}</span>
                                
                            </div>
                            <ul class="item-container">`;
                        
                        for(let item2 of item.Imagedt){
                            var imgs1=item2.image_high;
                            var imgs2=item2.image_red;
                            var imgs3=item2.image_mix;
                            html+=`<li>`;
                            if(imgs1!=''&&imgs1!=null&&imgs1!=undefined){
                                imgs=imgs1;
                            }else if(imgs2!=''&&imgs2!=null&&imgs2!=undefined){
                                imgs=imgs2;
                            }else if(imgs3!=''&&imgs3!=null&&imgs3!=undefined){
                                imgs=imgs3;
                            }else{
                                imgs=`../images/no_pic.png`;
                            }

                            var tem=item2.todaytop;
                            var time=item2.createtime; ///Date(158 572 227 7000)/
                            var Times='';
                            if(time==''||time==null){
                            Times='';
                            }else{
                                Times=(item2.createtime).replace(/\T/g," ");
                                
                            }
                            html+=`<div class="item_bg">
                                    <div class="top_pic"><img src="${imgs}" alt="" data-deviceid="${item2.deviceid}" data-ysdName="${item2.ysdname}" id="deviceidLi"/></div><div class="bot-text">`;
                                if(tem>=100){
                                    html+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                if(tem >= 80 && tem < 100){
                                    html+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                if(tem<80){
                                    html+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                        // <div class="botText_left fl">${} <span>℃</span></div>
                                html+=`<div class="botText_right fr">
                                            <p>${item2.devicename}</p>
                                            <p class="time">${Times}</p>
                                        </div>
                                    </div>
                                </div>
                                
                            </li>`;
                        }
                                
                        html+=`</ul>
                        </div> `;
                    
                    };
                }else{
                    html+="<div class='no_datasLI'><p>暂无数据</p></div>"
                }
                $("#contentImgs").html(html);
                // $(".loding_bg").hide();
            },
            error:function(err){
                    console.log(err)
            }

        });  
    };
    //缺图检查
    function missingImg(areaid,fenbuid,ywbid,stationid){
        $(".loding_all").show();
        $.ajax({
                type:'get',
                url:baseUrl+'quetuservice/quetuServices.asmx/getQuetu',
                dataType:'JSON',  
                data:{
                        userid:userid,
                        areaid:areaid,
                        fenbuid:fenbuid,
                        ywbid:ywbid,
                        stationid:stationid,
                },
                success:function(data){
                    $(".loding_all").hide();
                    $("#total").html(data.Quetunote2);
                    $("#missingImgsExport").attr("href",data.DownLoadUrl);
                    var listItem='';
                    var html='';
                    var lists=data.Quetu;
                    if(lists.length>0){
                        for(var i=0;i<lists.length;i++){
                            html+=`<div class="content-item">
                                    <div class="item-title"><img src="images/temC.png" alt="">`
                                        +lists[i].Device_title+`</div><table class="item-container" id="missingImgTable"><tbody>`;
                            listItem=lists[i].Quetulist;
                            for(var j=0;j<lists[i].Quetulist.length;j++){
                                html+=`<tr>
                                                <td>`+listItem[j].Quetudate+`</td>`;
                                                for(var k=0;k<listItem[j].Quetutime.length;k++){
                                                    if(listItem[j].Quetutime[k]!='-'){
                                                        html+=`<td>`+listItem[j].Quetutime[k]+`</td>`;
                                                    }else{
                                                        html+=`<td class='notime'>`+listItem[j].Quetutime[k]+`</td>`;
                                                    }
                                                    
                                                }
                                html+=`</tr>`;
                            }
                            html+=`</tbody></table></div>`;
                        };
                    }else{
                        html+="<div class='no_datasLI'><p>暂无数据</p></div>"
                    }
                    $("#missingImgs_content").html(html);
                    
                },
                error:function(err){
                        console.log(err)
                }
        })
        
    };
    // 历史图像  
    function tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType) {
        
        if(areaid==undefined ){
            var areaid='';
        };
        if(fenbuid==undefined ){
            var fenbuid='';
        };
        if(ywbid==undefined){
            var ywbid='';
        };
        if(stationid==undefined){
            var stationid='';
        };
        if(buildingid==undefined){
            var buildingid='';
        };
        if(devicetype==undefined){
            var devicetype='';
        };
        if(machineid==undefined){
            var machineid='';
        }
        if(deviceid==undefined){
            var deviceid='';
        };
        if(isok==undefined){
            var isok='';
        };
        if(isok==undefined){
            var isok='';
        };
        if(startDate==undefined){
            var startDate='';
        };
        if(endDate==undefined){
            var endDate='';
        };
        $.ajax({
            type:'get',
            url:baseUrl+"UserServices/User_Services.asmx/l_getDeviceImageByUnit",
            dataType:'JSON',  
            data:{
                userid:userid,
                page:page,
                limit:limit,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
                devicetype:devicetype,
                machineid:machineid,
                deviceid:deviceid,
                isok:isok,
                startDate:startDate,
                endDate:endDate,
                isimagered:imgType
            },
            success:function(data){
                var allpage=data.Recordcount;
                var html='';
                var imgs='';
                var datas=data.Recorddt;
                if(allpage!=0){
                    for(let item of datas){
                        var tem=item.todaytop;
                        var imgs1=item.image;
                        
                        if(imgs1!=''&&imgs1!=null&&imgs1!=undefined){
                            imgs=imgs1;
                        }else{
                            imgs=`../images/no_pic.png`;
                        }

                        var Times=item.createtime; // 
                        
                        html+=`<li id="deviceidLi">
                                <div class="item_bg">
                                
                                    <div class="top_pic"   data-deviceid="${item.deviceid}" onclick="left_module3_bigImg(`+ JSON.stringify(item.recordid).replace(/"/g, '&quot;') +`,`+ JSON.stringify(Times).replace(/"/g, '&quot;') +`)">
                                        <img src="${imgs}" alt="">
                                    </div><div class="bot-text">`;
                                if(tem>=100){
                                    html+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                if(tem >= 80 && tem < 100){
                                    html+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                if(tem<80){
                                    html+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
                                }
                                html+= `<div class="botText_right fr">
                                        <p>${item.devicename}</p>
                                        <p class="time">${Times}</p>
                                    </div>
                                </div>
                            </div>
                            <div id="popWindow" class="popWindow"  style="display:none;"  data-recordid="${item.recordid}" data-imgTime="${Times}">
                                <i class="noselImg" style="display:block;"></i>
                                <i class="selImg" style="display:none;"></i>
                            </div>
                        </li>`;
                    };
                }
                $("#containerUl").html(html);
                $(".loding_all").hide();      
            },
            error:function(err){
                    console.log(err)
            }

        });
    
    };
    // 历史图像 分页
    function fenyeImg(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType){
        $(".loding_all").show();
        if(areaid==undefined ){
            var areaid='';
        };
        if(fenbuid==undefined ){
            var fenbuid='';
        };
        if(ywbid==undefined){
            var ywbid='';
        };
        if(stationid==undefined){
            var stationid='';
        };
        if(buildingid==undefined){
            var buildingid='';
        };
        if(devicetype==undefined){
            var devicetype='';
        };
        if(machineid==undefined){
            var machineid='';
        };
        if(deviceid==undefined){
            var deviceid='';
        };
        if(isok==undefined){
            var isok='';
        };
        layui.use(['laydate','laypage', 'layer'], function(){
            var laydate = layui.laydate,
                laypage = layui.laypage
                ,layer = layui.layer;
            var page = 1; //每页
            var limit = 12; //每页显示的条数
            
            $.ajax({
                type:'post',
                url:baseUrl+'UserServices/User_Services.asmx/l_getDeviceImageByUnit',
                data:{
                    userid:userid,
                    page:page,
                    limit:limit,
                    areaid:areaid,
                    fenbuid:fenbuid,
                    ywbid:ywbid,
                    stationid:stationid,
                    buildingid:buildingid,
                    devicetype:devicetype,
                    machineid:machineid,
                    deviceid:deviceid,
                    isok:isok,
                    startDate:startDate,
                    endDate:endDate,
                    isimagered:imgType
                },
                dataType:'json',
                success:function(json){
                    // $(".loding_all").hide();
                    laypage.render({
                        elem: 'pagesImg',
                        count: json.Recordcount,
                        limit:12,
                        layout: [ 'count','prev', 'page', 'next','limit', 'limits'],
                        limits: [12,24,36], //一页选择显示3,5或10条数据
                        jump: function (obj) {
                            page=obj.curr;
                            limit=obj.limits[0];
                            // 历史图像
                            tem_hisImg(page,limit,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,isok,startDate,endDate,imgType)
                        }
                    });
                }
            });
        });
    };
    // 历史告警 降序 时间
    $(".content-item").on('click',"#sort_bottomTime",function(){
        $(this).addClass("sort_botSel");
        order=1;
        tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);
    });
    // 历史告警降序 温度
    $(".content-item").on('click',"#sort_bottomWd",function(){
        $(this).addClass("sort_botSel");
        order=0;
        tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok);
    });
    // 历史告警
    function tem_hisGJ(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,isok) {
        if(areaid==undefined ){
            var areaid='';
        };
        if(fenbuid==undefined ){
            var fenbuid='';
        };
        if(ywbid==undefined){
            var ywbid='';
        };
        if(stationid==undefined){
            var stationid='';
        };
        if(buildingid==undefined){
            var buildingid='';
        };
        if(devicetype==undefined){
            var devicetype='';
        };
        if(deviceid==undefined){
            var deviceid='';
        };
        if(isok==undefined){
            var isok='';
        };
        var staralarm='';
        var endalarm='';
        layui.use(['table','layer'], function(){
            var layer = layui.layer;
            var table = layui.table;
            table.render({
            elem: '#table_Gj'
            ,height:650
            ,where:{
                order:order,
                userid:userid,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
                devicetype:devicetype,
                deviceid:deviceid,
                isok:isok,
                staralarm:staralarm,
                endalarm:endalarm
            }
            ,url:baseUrl+"UserServices/User_Services.asmx/l_getAlarmByUnit" //数据接口
            ,parseData:function(res){
                return{
                    "code":0
                    ,"mag":0
                    ,"count":res.Recordcount
                    ,"data":res.Recorddt
                }
            }
            ,cols: [[ //表头
                {field: 'areaname', title: '工区', width:'10%'}
                ,{field: 'fenbuname', title: '分部', width:'10%'}
                ,{field: 'ywbname', title: '班组',width:'10%'}
                ,{field: 'stationname', title: '变电站', width:'10%'} 
                ,{field: 'buildingname', title: '设备区', width:'10%'}
                ,{field: 'devicename', title: '电力设备', width:'10%'}
                ,{field: 'createtime', title: '<span  id="sort_bottomTime">告警时间<i class="sort_bottomTime sort_bottom"></i></span>',templet:function(data){
                var time=data.createtime; ///Date(158 572 227 7000)/
                var Times='';
                if(time==''||time==null){
                    Times='';
                }else{
                    Times=(data.createtime).replace(/\T/g," ");
                }
                
                return Times;
                }, width:'10%'}
                ,{field: 'alarmvalue', title: '<span  id="sort_bottomWd">告警温度<i class="sort_bottom"></i></span>', width:'8%'}
                ,{field: 'isalarm', title: '告警状态', width:'10%',templet:function(data){
                    if(data.isok==0){
                    var isalarm="<p class='green'><span></span>已确认</p>"
                    }else{
                    var isalarm="<p class='red'><span></span>未确认</p>"
                    }
                    return isalarm
                },}
                ,{field: '', title: '报告', width:'6%',toolbar: '#report'}
                ,{field: '', title: '操作', width:'6%',toolbar: '#operate'}
            ]]
            ,page: true //开启分页
            ,limits: [10,20,30]  //一页选择显示3,5或10条数据
            ,limit: 10  //一页显示10条数据
            });
        });
            
        
        
    
    };
    //更多数据分析 temInfo_MoreData.html  表格
    function search_moreDate(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,timeSpan){
        if(areaid==undefined ){
        var areaid='';
        };
        if(fenbuid==undefined ){
            var fenbuid='';
        };
        if(ywbid==undefined){
            var ywbid='';
        };
        if(stationid==undefined){
            var stationid='';
        };
        if(buildingid==undefined){
            var buildingid='';
        };
        if(devicetype==undefined){
            var devicetype='';
        };
        if(machineid==undefined){
            var machineid='';
        };
        if(deviceid==undefined){
            var deviceid='';
        };
        if(timeSpan==undefined){
            var timeSpan='';
        };
        layui.use(['table','layer'], function(){
            var layer = layui.layer;
            var table = layui.table;
        
            table.render({
            elem: '#TemMoreData'
            ,height: 630
            ,url: baseUrl+'TableService/Infra_Red_Table_Services.asmx/Z_getDeviceTempRecordByTimeSpan' //数据接口
            ,page: true //开启分页
            ,where:{
                userid:userid,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
                devicetype:devicetype,
                machineid:machineid,
                deviceid:deviceid,
                timeSpan:timeSpan,
            }
            ,parseData:function(res){
                return{
                    "code":0
                    ,"mag":0
                    ,"count":res.Recordcount
                    ,"data":res.Recorddt
                }
            }
            ,cols: [[ //表头
                {field: 'areaname', title: '工区', width:'8%'}
                ,{field: 'areaname', title: '分部',width:'10%'}
                ,{field: 'ywbname', title: '班组', width:'10%'} 
                ,{field: 'stationname', title: '变电站', width:'8%'}
                ,{field: 'buildingname', title: '设备区', width:'10%'}
                ,{field: 'devicetype', title: '设备类型', width:'10%'}
                ,{field: 'devicename', title: '电力设备', width:'10%'}
                ,{field: 'createtime', title: '时间', width:'10%'}
                ,{field: 'maxvalue', title: '最高温度', width:'8%'}
                ,{field: 'minvalue', title: '最低温度', width:'8%'}
                ,{field: 'avgvalue', title: '平均温度', width:'8%'}
            ]]
            ,page: true
            });
        });
    };
    //更多数据分析 temInfo_MoreData.html  折线
    function moreDate_zhexian(areaid,fenbuid,ywbid,stationid,buildingid,devicetype,machineid,deviceid,timeSpan){
        
        if(areaid==undefined ){
            var areaid='';
        };
        if(fenbuid==undefined ){
            var fenbuid='';
        };
        if(ywbid==undefined){
            var ywbid='';
        };
        if(stationid==undefined){
            var stationid='';
        };
        if(buildingid==undefined){
            var buildingid='';
        };
        if(devicetype==undefined){
            var devicetype='';
        };
        if(machineid==undefined){
            var machineid='';
        };
        if(deviceid==undefined){
            var deviceid='';
        };
        if(timeSpan==undefined){
            var timeSpan='';
        };
        var time=[],maxtem=[],mintem=[],avgvtem=[];
        $.ajax({
            type:'get',
            url:baseUrl+'TableService/Infra_Red_Table_Services.asmx/Z_getDeviceTempRecordByTimeSpan', //数据接口,
            dataType:'JSON',
            data:{
                page:1,
                limit:30,
                userid:userid,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
                devicetype:devicetype,
                machineid:machineid,
                deviceid:deviceid,
                timeSpan:timeSpan,
            },
            success:function(data){
                if(data.Recorddt==null||data.Recorddt==''||data.Recorddt==undefined){
                    tem_MoreData(time,maxtem,mintem,avgvtem);
                }else{
                    for(let item of data.Recorddt){
                        time.push(item.createtime);
                        maxtem.push(item.maxvalue);
                        mintem.push(item.minvalue);
                        avgvtem.push(item.avgvalue);
                    
                    }
                    tem_MoreData(time,maxtem,mintem,avgvtem);
                }  
            },
            error:function(err){
                    console.log(err)
            }

        });
    };
    

    // 暂不用
    // 本月超80℃的设备统计
    function over80_deviceCount(areaid,fenbuid,ywbid,stationid,buildingid){
        $(".loding_bg").show();
        var html='';
        var imgs='';
        if(areaid==undefined ){
            var areaid='';
        }
        if(fenbuid==undefined){
            var fenbuid='';
        }
        if(ywbid==undefined){
          var ywbid='';
        }
        if(stationid==undefined){
            var stationid='';
        }
        if(buildingid==undefined){
            var buildingid='';
        }
        
        var urls="TableService/Infra_Red_Table_Services.asmx/ZZZ_get_device_80_tongji_month_detial";
        $.ajax({
            type:'get',
            url:baseUrl+urls,
            dataType:'JSON',  
            data:{
                userid:userid,
                areaid:areaid,
                fenbuid:fenbuid,
                ywbid:ywbid,
                stationid:stationid,
                buildingid:buildingid,
            },
            success:function(data){
                  if(data==''){
                    html+=`<p style="margin-top:150px">暂无数据</p>`
                  }else{
                    for(let item of data){
                        html+=`<div class="content-item">
                            <div class="item-title">
                                <img src="images/temC.png" alt="">
                                <span>${item.Station_building}</span>
                            </div>
                            <ul class="item-container">`;
                        for(let item2 of item.Devicelist){
                            var imgs1=item2.image_high;
                            var imgs2=item2.image_red;
                            var imgs3=item2.image_mix;
                            if(imgs1!=''&&imgs1!=null&&imgs1!=undefined){
                              imgs=imgs1;
                              html+=`<li onclick="mediaCenterInfo(`+ JSON.stringify(item2).replace(/"/g, '&quot;') +`)">`;

                            }else if(imgs2!=''&&imgs2!=null&&imgs2!=undefined){
                              imgs=imgs2;
                              html+=`<li onclick="mediaCenterInfo(`+ JSON.stringify(item2).replace(/"/g, '&quot;') +`)">`;
                            }else if(imgs3!=''&&imgs3!=null&&imgs3!=undefined){
                              imgs=imgs3;
                              html+=`<li onclick="mediaCenterInfo(`+ JSON.stringify(item2).replace(/"/g, '&quot;') +`)">`;
                            }else{
                              imgs=`../images/no_pic.png`;
                              html+=`<li data-deviceid="${item2.deviceid}">`;
                            }

                            var tem=item2.alarmvalue;
                            var time=item2.createtime; ///Date(158 572 227 7000)/
                            var Times='';
                            if(time==''||time==null){
                              Times='';
                            }else{
                                Times=(item2.createtime).replace(/\T/g," ");
                                
                            }
                            html+=`<div class="item_bg">
                                      <div class="top_pic"><img src="${imgs}" alt=""/></div><div class="bot-text">`;
                                  if(tem>=100){
                                      html+=`<div class="over100 botText_left fl">${tem}<span>℃</span></div>`;
                                  }
                                  if(tem >= 80 && tem < 100){
                                      html+=`<div class="over80 botText_left fl">${tem}<span>℃</span></div>`;
                                  }
                                  if(tem<80){
                                      html+=`<div class="up80 botText_left fl">${tem}<span>℃</span></div>`;
                                  }
                                        // <div class="botText_left fl">${} <span>℃</span></div>
                                  html+=`<div class="botText_right fr">
                                            <p>${item2.devicename}</p>
                                            <p class="time">${Times}</p>
                                        </div>
                                    </div>
                                </div>
                            </li>`;
                        }
                                
                        html+=`</ul></div> `;
                    };
                  }
                  $("#contentImgs").html(html);
                  $(".loding_bg").hide();
            },
            error:function(err){
                    console.log(err)
            }

        });

        
    };