var Util = {};
(function(util) {

	/**
	 * 格式化时间
	 * 
	 * @param time
	 * @param format
	 * @returns {*|string}
	 */
	util.formatTime = function(time, format) {
		format = format || 'yyyy-MM-dd hh:mm:ss';
		if (typeof time != 'undefined' && time == 0) {
			return '';
		}
		var oDate = time ? new Date(time * 1000) : new Date();
		var o = {
			"M+" : oDate.getMonth() + 1,
			"d+" : oDate.getDate(),
			"h+" : oDate.getHours(),
			"m+" : oDate.getMinutes(),
			"s+" : oDate.getSeconds(),
			"q+" : Math.floor((oDate.getMonth() + 3) / 3),
			"S" : (Array(3).join(0) + oDate.getMilliseconds()).slice(-3)
		};

		if (/(y+)/.test(format)) {
			format = format.replace(RegExp.$1, (oDate.getFullYear() + "")
					.substr(4 - RegExp.$1.length));
		}
		for ( var k in o) {
			if (new RegExp("(" + k + ")").test(format)) {
				format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k]
						: ("00" + o[k]).substr(("" + o[k]).length));
			}
		}
		return format;
	};

	/**
	 * 获取时间戳,以秒计数
	 * 
	 * @param date
	 * @returns {number}
	 */
	util.getSeconds = function(date) {
		if (typeof (date) === 'string' && date == '') {
			return 0;
		} else if (typeof (date) == 'undefined') {
			date = new Date();
		} else {
			var arr = date.replace(/ |:/g, '-').split('-');
			date = new Date(arr[0], arr[1] - 1, arr[2], arr[3], arr[4], arr[5]);
		}
		return Date.parse(date) / 1000;
	};

	util.ajax = function(options) {
		var _util = this;
		var ajaxOptions = $.extend({
			loadingShow : true,
			trigger : {
				loading : true
			},
			type : 'POST',
			dataType : "html",
			timeout : 30000
		}, options);

		// 请求 url 拼接
		if (ajaxOptions.url === undefined && ajaxOptions.c) {
			ajaxOptions.url = API_URL + '?c=' + ajaxOptions.c;
		}

		// 是否显示加载等待图，默认显示
		var loadingIndex;
		if (ajaxOptions.loadingShow) {
			loadingIndex = _util.loadingShow();
		}

		ajaxOptions.success = function(data) {
			var obj;
			try {
				obj = typeof data == 'string' ? eval('(' + data + ')') : data;
				if (!obj['success'] && obj['datas'] == -11) {
					var arr = top.location.pathname.split('/');
					if (arr[1] == 'user') {
						top.location.href = '/user/login.shtml';
					} else {
						top.location.href = '/' + arr[1] + '/login.php';
					}
				}
			} catch (e) {
				this.trigger.loading = false;
				_util.setFormEnabled(ajaxOptions.trigger);
				Util.showMsg(e.message);
				if (typeof options.error == 'function') {
					options.error(e);
				}
				return;
			}
			if (typeof obj == 'object' && !obj.success) {
				this.trigger.loading = false;
				_util.setFormEnabled(ajaxOptions.trigger);
			}
			if (typeof options.success == 'function') {
				options.success(obj);
			}
		};
		ajaxOptions.complete = function() {
			_util.loadingHide(loadingIndex);
			if (typeof options.complete == 'function') {
				options.complete();
			}
		};
		ajaxOptions.error = function(e) {
			this.trigger.loading = false;
			_util.setFormEnabled(ajaxOptions.trigger);
			_util.showMsg('网络异常');
			if (typeof options.error == 'function') {
				options.error(e);
			}
		};
		ajaxOptions.trigger.loading = true;
		// options.trigger 为请求触发对象，如果loading为true, 表示上一次提交尚未结束，这一次提交不允许进行
		_util.setFormDisabled(ajaxOptions.trigger);
		$.ajax(ajaxOptions);
	};
	util.setFormDisabled = function($form) {
		if (this.isFormTag($form)) {
			$form.find(':submit').attr('disabled', true);
		}
	};
	util.setFormEnabled = function($form) {
		if (this.isFormTag($form) && $form.find(':submit').length > 0) {
			$form.find(':submit').removeAttr('disabled');
		}
	};

	util.isFormTag = function($form) {
		return $form instanceof jQuery
				&& $form[0].tagName.toLowerCase() === 'form';
	};

	util.loadingShow = function() {
		var layerIndex = 0;
		if (typeof layer != 'undefined') {
			layerIndex = layer.load(1);
		}
		return layerIndex;
	};

	util.loadingHide = function(layerIndex) {
		if (layerIndex && typeof layer != 'undefined') {
			layer.close(layerIndex);
		}
	};

	/**
	 * 初始化查詢日期, 开始和结束日期联动
	 * 
	 * @param {string}
	 *            dateFmt 日期格式 默认 'yyyy-MM-dd HH:mm:ss'
	 * @param {string}
	 *            max
	 * @param {string}
	 *            min
	 */
	util.initSearchDate = function(dateFmt, max, min) {
		var $start = $('#start'), $end = $('#end');

		var $startHidden = $('input[type=hidden][for=start]'), $endHidden = $('input[type=hidden][for=end]');
		if ($startHidden.val() != '') {
			startFormat();
		}
		if ($startHidden.val() != '') {
			endFormat();
		}

		dateFmt = dateFmt || 'yyyy-MM-dd HH:mm:ss';
		var start_options = {
			errDealMode : 1,
			dateFmt : dateFmt,
			readOnly : true,
			onpicked : function() {
				startFormat();
			},
			oncleared : function() {
				startFormat();
			}
		};
		var end_options = {
			errDealMode : 1,
			dateFmt : dateFmt,
			readOnly : true,
			onpicked : function() {
				endFormat();
			},
			oncleared : function() {
				endFormat();
			}
		};
		if (typeof max != 'undefined' && max) {
			end_options.maxDate = max;
		}
		if (typeof min != 'undefined' && min) {
			start_options.minDate = min;
		}

		$start.on('focus', function() {
			start_options.maxDate = ($end.val() == '' && max) ? max
					: '#F{$dp.$D(\'end\')}';
			WdatePicker(start_options);
		});
		$end.on('focus', function() {
			end_options.minDate = ($start.val() == '' && min) ? min
					: '#F{$dp.$D(\'start\', {s:1})}';
			WdatePicker(end_options);
		});
		$start.change(function() {
			startFormat();
		});
		$end.change(function() {
			endFormat();
		});

		function startFormat() {
			if ($startHidden.length > 0) {
				$startHidden.val(Util.getSeconds($start.val()));
			}
		}

		function endFormat() {
			if ($endHidden.length > 0) {
				$endHidden.val(Util.getSeconds($end.val()));
			}
		}

	};

	/**
	 * 显示提示信息
	 * 
	 * @param {string}
	 *            msg 信息展示
	 * @param {string}
	 *            type 信息展示类型 error|success
	 * @param {int}
	 *            time 信息展示时间
	 * @param fn
	 *            回调函数
	 */
	util.showMsg = function(msg, type, time, fn) {
		var $notice = $('.tishi, #tishi');
		if (!msg) {
			if ($notice.length > 0) {
				$notice.slideUp();
				return true;
			}
		} else {
			if (typeof (layer) != 'undefined') {
				time = time || 2000;
				var iconType = '';
				type = type || 'error';
				if (type == 'error') {
					iconType = 5;
				} else if (type == 'success') {
					iconType = 6;
				}
				layer.msg(msg, {
					icon : iconType,
					time : time
				}, fn);
			} else if ($notice.length > 0) {
				$notice.slideDown();
				$notice.html(msg);
			}
		}
	};

	/**
	 * 获取URL里面的参数的值
	 * 
	 * @param name
	 *            URL里面的参数
	 * @returns {null}
	 */
	util.getUrlParam = function(name) {
		var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); // 构造一个含有目标参数的正则表达式对象
		var r = window.location.search.substr(1).match(reg); // 匹配目标参数
		if (r != null) {
			return decodeURIComponent(r[2]);
		}
		return null; // 返回参数值
	}

	/**
	 * 在当前页面全屏弹出新的页面
	 * 
	 * @param title
	 *            弹出页面的标题
	 * @param url
	 *            弹出页面的网址
	 */
	util.popFullScreen1 = function( w, h, contents,id) {
		var index = layer.open({
			type : 1,
			title: false, //不显示标题栏
			closeBtn: false,
			btn: "我知道了",
			id:id,
			shade : [ 0.8, '#000' ],
			area : [ w + 'px', h + 'px' ],
			content : contents,
			cancel : function() {
				
			},
			end : function() {
				
			}
		});
	}
	util.popFullScreen2 = function(title, w, h, url) {
		var index = layer.open({
			type : 2,
			title : title,
			maxmin : false,
			shadeClose : true,
			shade : [ 0.8, '#000' ],
			area : [ w + 'px', h + 'px' ],
			content : url,
			cancel : function() {
				// $('#' + nowShowPage).click();
			},
			end : function() {
				// $('#' + nowShowPage).click();
			}
		});
	}
	util.popFullScreen3 = function(w, h, url) {
		var index = layer.open({
			type : 2,
			title : false,
			maxmin : false,
			shadeClose : true,
			shade : [ 0.8, '#000' ],
			area : [ w + '%', h + '%' ],
			content : url,
			closeBtn:0,
			cancel : function() {
				// $('#' + nowShowPage).click();
			},
			end : function() {
				//$('#' + nowShowPage).click();
			}
		});
	};
	util.popFullScreen4 = function(w, h, url) {
		var index = layer.open({
			type : 1,
			title : false,
			closeBtn: false,
			shadeClose : true,
			shade : [ 0.8, '#000' ],
			area : [ w + 'px', h + 'px' ],
			btn: ['确认', '取消'],
            btnAlign: 'c',
			content : $(url).show(),
			// yes : function() {
			// 	$('#' + nowShowPage).click();
			// },
			// btn2 : function() {
			// 	$('#' + nowShowPage).click();
			// }
		});
	};
	util.popFullScreen5 = function(w, h, url) {
		var index = layer.open({
			type : 2,
			title : false,
			maxmin : false,
			shadeClose : true,
			shade : [ 0.8, '#000' ],
			area : [ w + '%', h + '%' ],
			content : url,
			cancel : function() {
				// $('#' + nowShowPage).click();
			},
			end : function() {
				//$('#' + nowShowPage).click();
			}
		});
	};
	
	/**
	 * get_second 时间秒数差
	 */
	util.computingTime = function(get_second) {
		var hour = Math.floor(get_second / 3600);
		var minute = Math.floor((get_second % 3600) / 60);
		var second = Math.floor(get_second % 60);
		var h = hour < 10 ? "0" + hour : hour;// 计算小时
		var m = minute < 10 ? "0" + minute : minute;// 计算分钟
		var s = second < 10 ? "0" + second : second;// 计算秒杀
		return h + '：' + m + '：' + s;
	};
	/**
	 * //删除
	 */
	util.confirm_no = function(object, id, url, Id) {
		var param = {};
		var key = Id;
		param[key] = id;
		layer.confirm("确定要删除该条数据么？", function(index) {
			layer.close(index);
			Util.ajax({
				url : url,
				data : param,
				trigger : $(object),
				success : function(obj) {
					if (obj.succ) {
						Util.showMsg(obj.message || '成功', 'success', 2000,
								function() {
									gTable.$table.dataTable().fnPageChange(
											gTable.page());
								});
					} else {
						Util.showMsg(obj.message || '失败');
					}
				}
			});
		})
	}
	/**
	 * //商户启用复用
	 */
	util.modifyStatus = function(obj, merchantId, status, url, Id) {
		var s = status == '1' ? '废弃' : '启用';
		var param = {
			status : s == '启用' ? '废弃' : '启用'
		};
		var key = Id;
		param[key] = merchantId;
		var s = status == '1' ? '废弃' : '启用';
		layer.confirm('确认要' + s + '吗？', function(index) {
			layer.close(index);
			Util.ajax({
				url : url,
				data : param,
				success : function(obj) {
					if (obj.succ) {
						layer.msg(obj.errorMsg);
						gTable.$table.dataTable().fnPageChange(gTable.page());
					} else {
						layer.msg(obj.errorMsg);
					}
				}
			});
		});
	}
	/**
	 * //上传图片
	 */
	util.upload = function(id) {
		var fileObj = document.getElementById(id).files[0];
		var url = "http://webpay.51sspay.com/fileUpload/upload.do";
		var form = new FormData();
		form.append("file", fileObj);
		var xhr = new XMLHttpRequest();
		xhr.open("post", url, true);
		xhr.onload = function() {
			if (xhr.responseText !== '' || xhr.responseText !== null) {
				var json = eval('(' + xhr.responseText + ')');
				$("#" + "up_" + id).val(json.imgId);
			}
			;
		};
		xhr.send(form);
	}
	/**
	 * //异步显示类目
	 */
	util.itemSelect = function(id, url, prov, city, dist) {
		$(id).citySelect({
			url : url,
			prov : prov,// 省份
			city : city, // 城市
			dist : dist, // 区县
			nodata : "none" // 当子集无数据时，隐藏select
		});
	}
})(Util);

times=function (nS){
	if(nS!=null && nS!=undefined && nS!=''){
		var now;
		if(nS.length == 10){
			now = new Date(parseInt(nS) * 1000);
		}else if(nS.length == 13){
			now = new Date(parseInt(nS));
		}
		
		var yy = now.getFullYear();      //年
		var mm = fntwo(now.getMonth() + 1,2);     //月
		var dd = fntwo(now.getDate(),2);          //日
		var hh = fntwo(now.getHours(),2);         //时
		var ii = fntwo(now.getMinutes(),2);       //分
		var ss = fntwo(now.getSeconds(),2);       //秒
		return yy+'-'+mm+'-'+dd+' '+hh+':'+ii+':'+ss;
	}else{
		return console.log("传的时间为空") 
	}
	
},
fntwo=function(num, length) {  
	return (num/Math.pow(10,length)).toFixed(length).substr(2);  
};
