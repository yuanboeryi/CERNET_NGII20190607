﻿using System;
using System.Data;
using System.Collections.Generic;
using Maticsoft.Common;
using Maticsoft.Model;
using System.Text;
namespace Maticsoft.BLL
{
	/// <summary>
	/// 表名：device_infor 设备表
	/// </summary>
	public partial class device_infor
	{
		private readonly Maticsoft.DAL.device_infor dal=new Maticsoft.DAL.device_infor();
		public device_infor()
		{}
		#region  BasicMethod
		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(string deviceid)
		{
			return dal.Exists(deviceid);
		}



		/// <summary>
		/// 
		/// </summary>
		public string getMediaIndexByMachineId(string mid)
		{
			return dal.getMediaIndexByMachineId(mid);
		}

		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(Maticsoft.Model.device_infor model)
		{
			return dal.Add(model);
		}

		public bool UpdatePresetTemp(Maticsoft.Model.device_infor model)
		{
			return dal.UpdatePresetTemp(model);
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Maticsoft.Model.device_infor model)
		{
			return dal.Update(model);
		}


        public bool Update_every_value(string deviceid)
        {
            return dal.Update_every_value(deviceid);
        }


        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateBuilding(string id,string name,string idnew)
        {
            return dal.UpdateBuilding( id, name,idnew);
        }

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateMediaIndex(string macid, string index)
		{
			return dal.UpdateMediaIndex(macid, index);
		}

		public bool UpdateOperaterNumber(string operaterNumber, string deviceid)
		{
			return dal.UpdateOperaterNumber(operaterNumber, deviceid);
		}
		public bool UpdateDeviceName(string devicename, string deviceid)
		{
			return dal.UpdateDeviceName(devicename, deviceid);
		}
			public bool UpdateBuilding1(string id, string name, string idnew,string machineid)
        {
            return dal.UpdateBuilding1(id, name, idnew,machineid);
        }
    
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool modifyAlarmValue(string id, string value,string manager)
        {
            return dal.modifyAlarmValue(id, value,manager);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateYsdindex(string id,string value)
        {
            return dal.UpdateAYsdindex(id,value);
        }
        public bool UpdateMachineid(string id, string value)
        {
            return dal.UpdateMachineid(id, value);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Updatemenusre(string id)
        {
            return dal.Updatemenusre(id);
        }
       
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateAlarm(string id,string value,string today)
        {
            return dal.UpdateAlarm(id,value,today);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateHistory(string id, string yestoday,string week,string month,string history,string todaymax,string monthmax,string id1,string id2,string id3,string id4,string id5)
        {
            return dal.UpdateHistory(id, yestoday,week,month,history,todaymax,monthmax,id1,id2,id3,id4,id5);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateHistorytodaymax(string id, string todaymax,  string id1)
        {
            return dal.UpdateHistorytodaymax(id,todaymax, id1);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateImage(string id, string imagename1,string imagename2,string imagename3,DateTime dt,string templist)
        {
            return dal.UpdateImage(id, imagename1,imagename2,imagename3,dt,templist);
        }
          /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateRound(string id, string value)
        {
            return dal.UpdateRound(id,value);
        }
		public bool UpdatePatrolStatus(string id, string patrolStatus)
		{
			return dal.UpdatePatrolStatus(id, patrolStatus);
		}
		public bool UpdateTemporary(string id, string patrolStatus,string temporary)
		{
			return dal.UpdateTemporary(id, patrolStatus, temporary);
		}
		public bool UpdateIsopen(string id, string value)
        {
            return dal.UpdateIsopen(id, value);
        }
        public bool UpdateKeyPoint(string id,string stationid,string iskey)
        {
            return dal.UpdateKeyPoint(id, stationid, iskey);
        }
		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(string deviceid)
		{
			
			return dal.Delete(deviceid);
		}
        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool DeleteAlarm(string deviceid)
        {

            return dal.DeleteAlarm(deviceid);
        }
		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool DeleteList(string deviceidlist )
		{
			return dal.DeleteList(deviceidlist );
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.device_infor GetModel(string deviceid)
		{
			
			return dal.GetModel(deviceid);
		}

		public Maticsoft.Model.device_infor GetModelByMachineid(string machineid, string ysdname)
		{
			return GetModelByMachine(machineid, ysdname);
		}


		public Maticsoft.Model.device_infor GetModelByYsdid(string ysdid)
		{
			return dal.GetModelByYsdid(ysdid);
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.device_infor GetModelByMachine(string machineid,string ysdname)
        {

            return dal.GetModelByMachine(machineid,ysdname);
        }

		public Maticsoft.Model.device_infor GetModelByName(string devicename, string ysdname)
		{

			return dal.GetModelByName(devicename, ysdname);
		}

		/// <summary>
		/// 得到一个对象实体，从缓存中
		/// </summary>
		public Maticsoft.Model.device_infor GetModelByCache(string deviceid)
		{
			
			string CacheKey = "device_inforModel-" + deviceid;
			object objModel = Maticsoft.Common.DataCache.GetCache(CacheKey);
			if (objModel == null)
			{
				try
				{
					objModel = dal.GetModel(deviceid);
					if (objModel != null)
					{
						int ModelCache = Maticsoft.Common.ConfigHelper.GetConfigInt("ModelCache");
						Maticsoft.Common.DataCache.SetCache(CacheKey, objModel, DateTime.Now.AddMinutes(ModelCache), TimeSpan.Zero);
					}
				}
				catch{}
			}
			return (Maticsoft.Model.device_infor)objModel;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			return dal.GetList(strWhere);
		}
     
		/// <summary>
		/// 获得数据列表
		/// </summary>
		public List<Maticsoft.Model.device_infor> GetModelList(string strWhere)
		{
			DataSet ds = dal.GetList(strWhere);
			return DataTableToList(ds.Tables[0]);
		}
		/// <summary>
		/// 获得数据列表
		/// </summary>
		public List<Maticsoft.Model.device_infor> DataTableToList(DataTable dt)
		{
			List<Maticsoft.Model.device_infor> modelList = new List<Maticsoft.Model.device_infor>();
			int rowsCount = dt.Rows.Count;
			if (rowsCount > 0)
			{
				Maticsoft.Model.device_infor model;
				for (int n = 0; n < rowsCount; n++)
				{
					model = dal.DataRowToModel(dt.Rows[n]);
					if (model != null)
					{
						modelList.Add(model);
					}
				}
			}
			return modelList;
		}

		public void maybeSyncImage(string devid, string red, string mix, string high, DateTime ctime)
        {
			if (devid != null)
			{
				Maticsoft.Model.device_infor device = GetModel(devid);
				if (device != null)
				{
					bool isSync = false;
					bool isAlways = true;

					if (device.image_red == null || "".Equals(device.image_red) || isAlways)
					{
						device.image_red = red;
						isSync = true;
					}

					if (device.image_high == null || "".Equals(device.image_high) || isAlways)
					{
						device.image_high = high;
						isSync = true;
					}

					if (device.image_mix == null || "".Equals(device.image_mix) || isAlways)
					{
						device.image_mix = mix;
						isSync = true;
					}

					if (device.createtime == null || "".Equals(device.createtime) || isAlways)
					{
						device.createtime = ctime;
						isSync = true;
					}

					if (isSync)
                    {
						Update(device);
					}
				}
			}
			
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetAllList()
		{
			return GetList("");
		}
        public DataSet GetAlarmTongji(string userpower)
        {
            return dal.GetAlarmTongji(userpower);
        }
        public DataSet GetDeviceTongji(string userpower)
        {
            return dal.GetDeviceTongji(userpower);
        }
        public DataSet GetLevelTongji(string userpower)
        {
            return dal.GetLevelTongji(userpower);
        }
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			return dal.GetRecordCount(strWhere);
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			return dal.GetListByPage( strWhere,  orderby,  startIndex,  endIndex);
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		//public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		//{
			//return dal.GetList(PageSize,PageIndex,strWhere);
		//}

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

