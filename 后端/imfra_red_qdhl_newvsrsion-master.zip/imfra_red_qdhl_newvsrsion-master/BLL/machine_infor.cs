﻿using System;
using System.Data;
using System.Collections.Generic;
using Maticsoft.Common;
using Maticsoft.Model;
namespace Maticsoft.BLL
{
	/// <summary>
	/// machine_infor
	/// </summary>
	public partial class machine_infor
	{
		private readonly Maticsoft.DAL.machine_infor dal=new Maticsoft.DAL.machine_infor();
		public machine_infor()
		{}
		#region  BasicMethod
		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(string machineid)
		{
			return dal.Exists(machineid);
		}

		public bool UpdateMediaIndex(string macid, string index)
		{
			return dal.UpdateMediaIndex(macid, index);
		}

		public string getMediaIndexByMachineId(string mid)
		{
			return dal.getMediaIndexByMachineId(mid);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(Maticsoft.Model.machine_infor model)
		{
			return dal.Add(model);
		}


		/// <summary>
		/// 获取machinecode
		/// </summary>
		public string getMachineIdByCode(string code)
		{
			return dal.getMachineIdByCode(code);
		}

		public string getMacByCode(string code)
		{
			return dal.getMacByCode(code);
		}

		public string getMachineIdByMac(string mac)
		{
			return dal.getMachineIdByMac(mac);
		}

		public Maticsoft.Model.machine_infor getModelByMac(string mac)
		{

			string machineid = getMachineIdByMac(mac);
			if(machineid !=null)
            {
				return dal.GetModel(machineid);
            } else
            {
				return null;
            }
		}

		public bool updateVersionById(string machineid, string piFlirVersion, string piVideoVersion)
		{
			if (machineid != null)
			{
				return dal.UpdateVersion(machineid, piFlirVersion, piVideoVersion);
			}
			else
			{
				return false;
			}
		}

		public bool updateVersionByMac(string mac, string piFlirVersion, string piVideoVersion)
        {
			string machineid = getMachineIdByMac(mac);
			return updateVersionById(machineid, piFlirVersion, piVideoVersion);
        }

		public bool UpdateArgs(Maticsoft.Model.machine_infor model)
		{
			return dal.UpdateArgs(model);
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Maticsoft.Model.machine_infor model)
		{
			return dal.Update(model);
		}
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Updatetime(string machineid,string time)
        {
            return dal.Updatetime(machineid,time);
        }
        public bool UpdateBuilding(string id, string name,string idnew,string machineid)
        {
            return dal.UpdateBuilding(id, name,idnew,machineid);
        }
        public bool UpdateBuilding1(string id, string name, string idnew)
        {
            return dal.UpdateBuilding1(id, name, idnew);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateMachineState(string id,string state,string isonline,string runtime)
        {
            return dal.UpdateMachineState(id,state,isonline,runtime);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateMachineMac(string id, string mac, string code)
        {
            return dal.UpdateMachineMac(id, mac, code);
        }
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateWifi(string mac, string ssid, string password)
		{
			return dal.UpdateWifi(mac, ssid, password);
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateInterval(string mac, string capinterv, string insinterv )
		{
			return dal.UpdateInterval(mac, capinterv, insinterv);
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateFusion(string mac, string fusion)
		{
			return dal.UpdateFusion(mac, fusion);
		}

		public bool UpdateRonghe(string mac, string rong_S, string rong_R, string rong_L, string rong_T)
		{
			return dal.UpdateRonghe(mac, rong_S, rong_R, rong_L, rong_T);
		}
		

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateCloudAddress(string mac, string address)
		{
			return dal.UpdateCloudAddress(mac, address);
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateCode(string mac, string code)
		{
			return dal.UpdateCode(mac, code);
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateSpan(string id,string time1,string time2)
        {
            return dal.UpdateSpan(id,time1,time2);
        }
		/// <summary>
		/// 更新一条数据
		/// </summary>

		public bool ModifyYsdCount(string machineid, int number)
		{
			return dal.ModifyYsdCount(machineid, number);
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateYsdCount(string id, string count)
        {
            return dal.UpdateYsdCount(id, count);
        }
		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(string machineid)
		{
			
			return dal.Delete(machineid);
		}
		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool DeleteList(string machineidlist )
		{
			return dal.DeleteList(machineidlist );
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.machine_infor GetModel(string machineid)
		{
			
			return dal.GetModel(machineid);
		}
        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.machine_infor GetModelbymac(string machinemac)
        {

            return dal.GetModelBymac(machinemac);
        }


		/// <summary>
		/// 得到一个对象实体，从缓存中
		/// </summary>
		public Maticsoft.Model.machine_infor GetModelByCache(string machineid)
		{
			
			string CacheKey = "machine_inforModel-" + machineid;
			object objModel = Maticsoft.Common.DataCache.GetCache(CacheKey);
			if (objModel == null)
			{
				try
				{
					objModel = dal.GetModel(machineid);
					if (objModel != null)
					{
						int ModelCache = Maticsoft.Common.ConfigHelper.GetConfigInt("ModelCache");
						Maticsoft.Common.DataCache.SetCache(CacheKey, objModel, DateTime.Now.AddMinutes(ModelCache), TimeSpan.Zero);
					}
				}
				catch{}
			}
			return (Maticsoft.Model.machine_infor)objModel;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			return dal.GetList(strWhere);
		}
		/// <summary>
		/// 获得数据列表
		/// </summary>
		public List<Maticsoft.Model.machine_infor> GetModelList(string strWhere)
		{
			DataSet ds = dal.GetList(strWhere);
			return DataTableToList(ds.Tables[0]);
		}
		/// <summary>
		/// 获得数据列表
		/// </summary>
		public List<Maticsoft.Model.machine_infor> DataTableToList(DataTable dt)
		{
			List<Maticsoft.Model.machine_infor> modelList = new List<Maticsoft.Model.machine_infor>();
			int rowsCount = dt.Rows.Count;
			if (rowsCount > 0)
			{
				Maticsoft.Model.machine_infor model;
				for (int n = 0; n < rowsCount; n++)
				{
					model = dal.DataRowToModel(dt.Rows[n]);
					if (model != null)
					{
						modelList.Add(model);
					}
				}
			}
			return modelList;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetAllList()
		{
			return GetList("");
		}

		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			return dal.GetRecordCount(strWhere);
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			return dal.GetListByPage( strWhere,  orderby,  startIndex,  endIndex);
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		//public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		//{
			//return dal.GetList(PageSize,PageIndex,strWhere);
		//}

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

