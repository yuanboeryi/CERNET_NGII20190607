﻿using Maticsoft.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maticsoft.BLL
{



    /// <summary>
    /// 调度方法
    /// </summary>
    public class timerserver_infor
    {
        public void CreateNewTable()
        {
            timerserverDAL timerserver = new timerserverDAL();
            timerserver.CreateTable();
            
        }

    }
}
