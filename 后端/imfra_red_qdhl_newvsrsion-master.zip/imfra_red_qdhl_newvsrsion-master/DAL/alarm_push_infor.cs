﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:alarm_push_infor
    /// </summary>
    public partial class alarm_push_infor
    {
        public alarm_push_infor()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string id)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from alarm_push_infor");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255)			};
            parameters[0].Value = id;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.alarm_push_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into alarm_push_infor(");
            strSql.Append("id,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdid,ysdname,deviceid,devicename,devicetype,alarmvalue,isok,ysdtype,overvalue,createtime,image_url,isread,fuhe,mensurehuman,report_device_id,mensuretime)");
            strSql.Append(" values (");
            strSql.Append("@id,@areaid,@areaname,@fenbuid,@fenbuname,@ywbid,@ywbname,@stationid,@stationname,@buildingid,@buildingname,@machineid,@machinename,@ysdid,@ysdname,@deviceid,@devicename,@devicetype,@alarmvalue,@isok,@ysdtype,@overvalue,@createtime,@image_url,@isread,@fuhe,@mensurehuman,@report_device_id,@mensuretime)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinename", MySqlDbType.VarChar,50),
					new MySqlParameter("@ysdid", MySqlDbType.VarChar,50),
					new MySqlParameter("@ysdname", MySqlDbType.VarChar,50),
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,50),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,50),
					new MySqlParameter("@devicetype", MySqlDbType.VarChar,50),
					new MySqlParameter("@alarmvalue", MySqlDbType.VarChar,50),
					new MySqlParameter("@isok", MySqlDbType.VarChar,50),
					new MySqlParameter("@ysdtype", MySqlDbType.VarChar,50),
					new MySqlParameter("@overvalue", MySqlDbType.VarChar,50),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@image_url", MySqlDbType.VarChar,255),
					new MySqlParameter("@isread", MySqlDbType.VarChar,10),
					new MySqlParameter("@fuhe", MySqlDbType.VarChar,50),
					new MySqlParameter("@mensurehuman", MySqlDbType.VarChar,50),
					new MySqlParameter("@report_device_id", MySqlDbType.VarChar,50),
					new MySqlParameter("@mensuretime", MySqlDbType.DateTime)};
            parameters[0].Value = model.id;
            parameters[1].Value = model.areaid;
            parameters[2].Value = model.areaname;
            parameters[3].Value = model.fenbuid;
            parameters[4].Value = model.fenbuname;
            parameters[5].Value = model.ywbid;
            parameters[6].Value = model.ywbname;
            parameters[7].Value = model.stationid;
            parameters[8].Value = model.stationname;
            parameters[9].Value = model.buildingid;
            parameters[10].Value = model.buildingname;
            parameters[11].Value = model.machineid;
            parameters[12].Value = model.machinename;
            parameters[13].Value = model.ysdid;
            parameters[14].Value = model.ysdname;
            parameters[15].Value = model.deviceid;
            parameters[16].Value = model.devicename;
            parameters[17].Value = model.devicetype;
            parameters[18].Value = model.alarmvalue;
            parameters[19].Value = model.isok;
            parameters[20].Value = model.ysdtype;
            parameters[21].Value = model.overvalue;
            parameters[22].Value = model.createtime;
            parameters[23].Value = model.image_url;
            parameters[24].Value = model.isread;
            parameters[25].Value = model.fuhe;
            parameters[26].Value = model.mensurehuman;
            parameters[27].Value = model.report_device_id;
            parameters[28].Value = model.mensuretime;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.alarm_push_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update alarm_push_infor set ");
            strSql.Append("areaid=@areaid,");
            strSql.Append("areaname=@areaname,");
            strSql.Append("fenbuid=@fenbuid,");
            strSql.Append("fenbuname=@fenbuname,");
            strSql.Append("ywbid=@ywbid,");
            strSql.Append("ywbname=@ywbname,");
            strSql.Append("stationid=@stationid,");
            strSql.Append("stationname=@stationname,");
            strSql.Append("buildingid=@buildingid,");
            strSql.Append("buildingname=@buildingname,");
            strSql.Append("machineid=@machineid,");
            strSql.Append("machinename=@machinename,");
            strSql.Append("ysdid=@ysdid,");
            strSql.Append("ysdname=@ysdname,");
            strSql.Append("deviceid=@deviceid,");
            strSql.Append("devicename=@devicename,");
            strSql.Append("devicetype=@devicetype,");
            strSql.Append("alarmvalue=@alarmvalue,");
            strSql.Append("isok=@isok,");
            strSql.Append("ysdtype=@ysdtype,");
            strSql.Append("overvalue=@overvalue,");
            strSql.Append("createtime=@createtime,");
            strSql.Append("image_url=@image_url,");
            strSql.Append("isread=@isread,");
            strSql.Append("fuhe=@fuhe,");
            strSql.Append("mensurehuman=@mensurehuman,");
            strSql.Append("report_device_id=@report_device_id,");
            strSql.Append("mensuretime=@mensuretime");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinename", MySqlDbType.VarChar,50),
					new MySqlParameter("@ysdid", MySqlDbType.VarChar,50),
					new MySqlParameter("@ysdname", MySqlDbType.VarChar,50),
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,50),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,50),
					new MySqlParameter("@devicetype", MySqlDbType.VarChar,50),
					new MySqlParameter("@alarmvalue", MySqlDbType.VarChar,50),
					new MySqlParameter("@isok", MySqlDbType.VarChar,50),
					new MySqlParameter("@ysdtype", MySqlDbType.VarChar,50),
					new MySqlParameter("@overvalue", MySqlDbType.VarChar,50),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@image_url", MySqlDbType.VarChar,255),
					new MySqlParameter("@isread", MySqlDbType.VarChar,10),
					new MySqlParameter("@fuhe", MySqlDbType.VarChar,50),
					new MySqlParameter("@mensurehuman", MySqlDbType.VarChar,50),
					new MySqlParameter("@report_device_id", MySqlDbType.VarChar,50),
					new MySqlParameter("@mensuretime", MySqlDbType.DateTime),
					new MySqlParameter("@id", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.areaid;
            parameters[1].Value = model.areaname;
            parameters[2].Value = model.fenbuid;
            parameters[3].Value = model.fenbuname;
            parameters[4].Value = model.ywbid;
            parameters[5].Value = model.ywbname;
            parameters[6].Value = model.stationid;
            parameters[7].Value = model.stationname;
            parameters[8].Value = model.buildingid;
            parameters[9].Value = model.buildingname;
            parameters[10].Value = model.machineid;
            parameters[11].Value = model.machinename;
            parameters[12].Value = model.ysdid;
            parameters[13].Value = model.ysdname;
            parameters[14].Value = model.deviceid;
            parameters[15].Value = model.devicename;
            parameters[16].Value = model.devicetype;
            parameters[17].Value = model.alarmvalue;
            parameters[18].Value = model.isok;
            parameters[19].Value = model.ysdtype;
            parameters[20].Value = model.overvalue;
            parameters[21].Value = model.createtime;
            parameters[22].Value = model.image_url;
            parameters[23].Value = model.isread;
            parameters[24].Value = model.fuhe;
            parameters[25].Value = model.mensurehuman;
            parameters[26].Value = model.report_device_id;
            parameters[27].Value = model.mensuretime;
            parameters[28].Value = model.id;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
             /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateReportid(string alarmid,string reportid)
        {
            string isread = "0";
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update alarm_push_infor set ");

            strSql.Append("report_device_id='" + reportid + "'");
            strSql.Append(" where id='"+alarmid+"' ");
            

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateMensure(string id, string fuhe, string human, string time)
        {
            string isok = "0";
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update alarm_push_infor set ");

            strSql.Append("fuhe='" + fuhe + "',mensurehuman='" + human + "',mensuretime='" + time + "',isok='" + isok + "'");
            strSql.Append(" where id='" + id + "' ");


            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Updatemenusre(string id, string infor, string human, string time)
        {
            if (infor != "all")
            {
                string s = "0";
                StringBuilder strSql = new StringBuilder();
                strSql.Append("update alarm_push_infor set ");

                strSql.Append("mensurehuman='" + human + "',mensuretime='" + time + "',isok='" + s + "'");

                strSql.Append(" where id='" + id + "'");


                int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
                if (rows > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            if (infor == "all")
            {
                string s = "0";
                string s1 = "1";
                StringBuilder strSql = new StringBuilder();
                strSql.Append("update alarm_push_infor set ");

                strSql.Append("mensurehuman='" + human + "',mensuretime='" + time + "',isok='" + s + "'");

                strSql.Append(" where " + id);

                int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
                if (rows > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            return true;

        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateIsread(string id)
        {
            string isread = "0";
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update alarm_push_infor set ");

            strSql.Append("isread='" + isread + "'");
            strSql.Append(" where id='"+id+"' ");
            

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string id)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from alarm_push_infor ");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255)			};
            parameters[0].Value = id;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string idlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from alarm_push_infor ");
            strSql.Append(" where id in (" + idlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.alarm_push_infor GetModel(string id)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select id,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdid,ysdname,deviceid,devicename,devicetype,alarmvalue,isok,ysdtype,overvalue,createtime,image_url,isread,fuhe,mensurehuman,report_device_id,mensuretime from alarm_push_infor ");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255)			};
            parameters[0].Value = id;

            Maticsoft.Model.alarm_push_infor model = new Maticsoft.Model.alarm_push_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.alarm_push_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.alarm_push_infor model = new Maticsoft.Model.alarm_push_infor();
            if (row != null)
            {
                if (row["id"] != null)
                {
                    model.id = row["id"].ToString();
                }
                if (row["areaid"] != null)
                {
                    model.areaid = row["areaid"].ToString();
                }
                if (row["areaname"] != null)
                {
                    model.areaname = row["areaname"].ToString();
                }
                if (row["fenbuid"] != null)
                {
                    model.fenbuid = row["fenbuid"].ToString();
                }
                if (row["fenbuname"] != null)
                {
                    model.fenbuname = row["fenbuname"].ToString();
                }
                if (row["ywbid"] != null)
                {
                    model.ywbid = row["ywbid"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
                if (row["stationid"] != null)
                {
                    model.stationid = row["stationid"].ToString();
                }
                if (row["stationname"] != null)
                {
                    model.stationname = row["stationname"].ToString();
                }
                if (row["buildingid"] != null)
                {
                    model.buildingid = row["buildingid"].ToString();
                }
                if (row["buildingname"] != null)
                {
                    model.buildingname = row["buildingname"].ToString();
                }
                if (row["machineid"] != null)
                {
                    model.machineid = row["machineid"].ToString();
                }
                if (row["machinename"] != null)
                {
                    model.machinename = row["machinename"].ToString();
                }
                if (row["ysdid"] != null)
                {
                    model.ysdid = row["ysdid"].ToString();
                }
                if (row["ysdname"] != null)
                {
                    model.ysdname = row["ysdname"].ToString();
                }
                if (row["deviceid"] != null)
                {
                    model.deviceid = row["deviceid"].ToString();
                }
                if (row["devicename"] != null)
                {
                    model.devicename = row["devicename"].ToString();
                }
                if (row["devicetype"] != null)
                {
                    model.devicetype = row["devicetype"].ToString();
                }
                if (row["alarmvalue"] != null)
                {
                    model.alarmvalue = row["alarmvalue"].ToString();
                }
                if (row["isok"] != null)
                {
                    model.isok = row["isok"].ToString();
                }
                if (row["ysdtype"] != null)
                {
                    model.ysdtype = row["ysdtype"].ToString();
                }
                if (row["overvalue"] != null)
                {
                    model.overvalue = row["overvalue"].ToString();
                }
                if (row["createtime"] != null && row["createtime"].ToString() != "")
                {
                    model.createtime = DateTime.Parse(row["createtime"].ToString());
                }
                if (row["image_url"] != null)
                {
                    model.image_url = row["image_url"].ToString();
                }
                if (row["isread"] != null)
                {
                    model.isread = row["isread"].ToString();
                }
                if (row["fuhe"] != null)
                {
                    model.fuhe = row["fuhe"].ToString();
                }
                if (row["mensurehuman"] != null)
                {
                    model.mensurehuman = row["mensurehuman"].ToString();
                }
                if (row["report_device_id"] != null)
                {
                    model.report_device_id = row["report_device_id"].ToString();
                }
                if (row["mensuretime"] != null && row["mensuretime"].ToString() != "")
                {
                    model.mensuretime = DateTime.Parse(row["mensuretime"].ToString());
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select id,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdid,ysdname,deviceid,devicename,devicetype,alarmvalue,isok,ysdtype,overvalue,createtime,image_url,isread,fuhe,mensurehuman,report_device_id,mensuretime,IsPush ");
            strSql.Append(" FROM alarm_push_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public int GetListCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(id) ");
            strSql.Append(" FROM alarm_push_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperMySQL.GetSingle(strSql.ToString());
             if (obj == null)
             {
                 return 0;
             }
             else
             {
                 return Convert.ToInt32(obj);
             }
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetAlarmTongji(string userpower)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select devicename as devicename,COUNT(devicename) devicecount from alarm_push_infor  GROUP by devicename having count(devicename)>=1 Order by devicename  ");//WHERE areaname='"+userpower+"'


            return DbHelperMySQL.Query(strSql.ToString());
        }
      
        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM alarm_push_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.id desc");
            }
            strSql.Append(")AS Row, T.*  from alarm_push_infor T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        ///  更新是否已经推送
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public bool UpdateIsPush(string Id)
        {
            string IsPush = "1";
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update alarm_push_infor set ");

            strSql.Append("IsPush='" + IsPush + "'");
            strSql.Append(" where id='" + Id + "' ");


            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "alarm_push_infor";
            parameters[1].Value = "id";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

