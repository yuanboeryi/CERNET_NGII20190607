﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
	/// <summary>
	/// 数据访问类:device_exception_infor
	/// </summary>
	public partial class device_exception_infor
	{
		public device_exception_infor()
		{ }
		#region  BasicMethod

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(string id)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("select count(1) from device_exception_infor");
			strSql.Append(" where id=@id ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255)          };
			parameters[0].Value = id;

			return DbHelperMySQL.Exists(strSql.ToString(), parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(Maticsoft.Model.device_exception_infor model)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("insert into device_exception_infor(");
			strSql.Append("id,deviceid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,machinecode,ysdname,ysdindex,devicename,image_red,image_high,image_mix,createtime,operaterNumber,discoverer,typename,catchtime,description,patrolid,status,exceptiontypeid,temperature)");
			strSql.Append(" values (");
			strSql.Append("@id,@deviceid,@areaid,@areaname,@fenbuid,@fenbuname,@ywbid,@ywbname,@stationid,@stationname,@buildingid,@buildingname,@machineid,@machinename,@machinecode,@ysdname,@ysdindex,@devicename,@image_red,@image_high,@image_mix,@createtime,@operaterNumber,@discoverer,@typename,@catchtime,@description,@patrolid,@status,@exceptiontypeid,@temperature)");
			MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinecode", MySqlDbType.VarChar,255),
					new MySqlParameter("@ysdname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ysdindex", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_red", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_high", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_mix", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@operaterNumber", MySqlDbType.VarChar,255),
					new MySqlParameter("@discoverer", MySqlDbType.VarChar,255),
					new MySqlParameter("@typename", MySqlDbType.VarChar,255),
					new MySqlParameter("@catchtime", MySqlDbType.DateTime),
					new MySqlParameter("@description", MySqlDbType.VarChar,255),
					new MySqlParameter("@patrolid", MySqlDbType.VarChar,255),
					new MySqlParameter("@status", MySqlDbType.VarChar,255),
					new MySqlParameter("@exceptiontypeid", MySqlDbType.VarChar,255),
					new MySqlParameter("@temperature", MySqlDbType.VarChar,255)};
			parameters[0].Value = model.id;
			parameters[1].Value = model.deviceid;
			parameters[2].Value = model.areaid;
			parameters[3].Value = model.areaname;
			parameters[4].Value = model.fenbuid;
			parameters[5].Value = model.fenbuname;
			parameters[6].Value = model.ywbid;
			parameters[7].Value = model.ywbname;
			parameters[8].Value = model.stationid;
			parameters[9].Value = model.stationname;
			parameters[10].Value = model.buildingid;
			parameters[11].Value = model.buildingname;
			parameters[12].Value = model.machineid;
			parameters[13].Value = model.machinename;
			parameters[14].Value = model.machinecode;
			parameters[15].Value = model.ysdname;
			parameters[16].Value = model.ysdindex;
			parameters[17].Value = model.devicename;
			parameters[18].Value = model.image_red;
			parameters[19].Value = model.image_high;
			parameters[20].Value = model.image_mix;
			parameters[21].Value = model.createtime;
			parameters[22].Value = model.operaterNumber;
			parameters[23].Value = model.discoverer;
			parameters[24].Value = model.typename;
			parameters[25].Value = model.catchtime;
			parameters[26].Value = model.description;
			parameters[27].Value = model.patrolid;
			parameters[28].Value = model.status;
			parameters[29].Value = model.exceptiontypeid;
			parameters[30].Value = model.temperature;

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Maticsoft.Model.device_exception_infor model)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update device_exception_infor set ");
			strSql.Append("deviceid=@deviceid,");
			strSql.Append("areaid=@areaid,");
			strSql.Append("areaname=@areaname,");
			strSql.Append("fenbuid=@fenbuid,");
			strSql.Append("fenbuname=@fenbuname,");
			strSql.Append("ywbid=@ywbid,");
			strSql.Append("ywbname=@ywbname,");
			strSql.Append("stationid=@stationid,");
			strSql.Append("stationname=@stationname,");
			strSql.Append("buildingid=@buildingid,");
			strSql.Append("buildingname=@buildingname,");
			strSql.Append("machineid=@machineid,");
			strSql.Append("machinename=@machinename,");
			strSql.Append("machinecode=@machinecode,");
			strSql.Append("ysdname=@ysdname,");
			strSql.Append("ysdindex=@ysdindex,");
			strSql.Append("devicename=@devicename,");
			strSql.Append("image_red=@image_red,");
			strSql.Append("image_high=@image_high,");
			strSql.Append("image_mix=@image_mix,");
			strSql.Append("createtime=@createtime,");
			strSql.Append("operaterNumber=@operaterNumber,");
			strSql.Append("discoverer=@discoverer,");
			strSql.Append("typename=@typename,");
			strSql.Append("catchtime=@catchtime,");
			strSql.Append("description=@description,");
			strSql.Append("patrolid=@patrolid,");
			strSql.Append("status=@status,");
			strSql.Append("exceptiontypeid=@exceptiontypeid,");
			strSql.Append("temperature=@temperature");
			strSql.Append(" where id=@id ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinecode", MySqlDbType.VarChar,255),
					new MySqlParameter("@ysdname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ysdindex", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_red", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_high", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_mix", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@operaterNumber", MySqlDbType.VarChar,255),
					new MySqlParameter("@discoverer", MySqlDbType.VarChar,255),
					new MySqlParameter("@typename", MySqlDbType.VarChar,255),
					new MySqlParameter("@catchtime", MySqlDbType.DateTime),
					new MySqlParameter("@description", MySqlDbType.VarChar,255),
					new MySqlParameter("@patrolid", MySqlDbType.VarChar,255),
					new MySqlParameter("@status", MySqlDbType.VarChar,255),
					new MySqlParameter("@exceptiontypeid", MySqlDbType.VarChar,255),
					new MySqlParameter("@temperature", MySqlDbType.VarChar,255),
					new MySqlParameter("@id", MySqlDbType.VarChar,255)};
			parameters[0].Value = model.deviceid;
			parameters[1].Value = model.areaid;
			parameters[2].Value = model.areaname;
			parameters[3].Value = model.fenbuid;
			parameters[4].Value = model.fenbuname;
			parameters[5].Value = model.ywbid;
			parameters[6].Value = model.ywbname;
			parameters[7].Value = model.stationid;
			parameters[8].Value = model.stationname;
			parameters[9].Value = model.buildingid;
			parameters[10].Value = model.buildingname;
			parameters[11].Value = model.machineid;
			parameters[12].Value = model.machinename;
			parameters[13].Value = model.machinecode;
			parameters[14].Value = model.ysdname;
			parameters[15].Value = model.ysdindex;
			parameters[16].Value = model.devicename;
			parameters[17].Value = model.image_red;
			parameters[18].Value = model.image_high;
			parameters[19].Value = model.image_mix;
			parameters[20].Value = model.createtime;
			parameters[21].Value = model.operaterNumber;
			parameters[22].Value = model.discoverer;
			parameters[23].Value = model.typename;
			parameters[24].Value = model.catchtime;
			parameters[25].Value = model.description;
			parameters[26].Value = model.patrolid;
			parameters[27].Value = model.status;
			parameters[28].Value = model.exceptiontypeid;
			parameters[29].Value = model.temperature;
			parameters[30].Value = model.id;

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(string id)
		{

			StringBuilder strSql = new StringBuilder();
			strSql.Append("delete from device_exception_infor ");
			strSql.Append(" where id=@id ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255)          };
			parameters[0].Value = id;

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string idlist)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("delete from device_exception_infor ");
			strSql.Append(" where id in (" + idlist + ")  ");
			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.device_exception_infor GetModel(string id)
		{

			StringBuilder strSql = new StringBuilder();
			strSql.Append("select id,deviceid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,machinecode,ysdname,ysdindex,devicename,image_red,image_high,image_mix,createtime,operaterNumber,discoverer,typename,catchtime,description,patrolid,status,exceptiontypeid,temperature  from device_exception_infor ");
			strSql.Append(" where id=@id ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255)          };
			parameters[0].Value = id;

			Maticsoft.Model.device_exception_infor model = new Maticsoft.Model.device_exception_infor();
			DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
			if (ds.Tables[0].Rows.Count > 0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.device_exception_infor DataRowToModel(DataRow row)
		{
			Maticsoft.Model.device_exception_infor model = new Maticsoft.Model.device_exception_infor();
			if (row != null)
			{
				if (row["id"] != null)
				{
					model.id = row["id"].ToString();
				}
				if (row["deviceid"] != null)
				{
					model.deviceid = row["deviceid"].ToString();
				}
				if (row["areaid"] != null)
				{
					model.areaid = row["areaid"].ToString();
				}
				if (row["areaname"] != null)
				{
					model.areaname = row["areaname"].ToString();
				}
				if (row["fenbuid"] != null)
				{
					model.fenbuid = row["fenbuid"].ToString();
				}
				if (row["fenbuname"] != null)
				{
					model.fenbuname = row["fenbuname"].ToString();
				}
				if (row["ywbid"] != null)
				{
					model.ywbid = row["ywbid"].ToString();
				}
				if (row["ywbname"] != null)
				{
					model.ywbname = row["ywbname"].ToString();
				}
				if (row["stationid"] != null)
				{
					model.stationid = row["stationid"].ToString();
				}
				if (row["stationname"] != null)
				{
					model.stationname = row["stationname"].ToString();
				}
				if (row["buildingid"] != null)
				{
					model.buildingid = row["buildingid"].ToString();
				}
				if (row["buildingname"] != null)
				{
					model.buildingname = row["buildingname"].ToString();
				}
				if (row["machineid"] != null)
				{
					model.machineid = row["machineid"].ToString();
				}
				if (row["machinename"] != null)
				{
					model.machinename = row["machinename"].ToString();
				}
				if (row["machinecode"] != null)
				{
					model.machinecode = row["machinecode"].ToString();
				}
				if (row["ysdname"] != null)
				{
					model.ysdname = row["ysdname"].ToString();
				}
				if (row["ysdindex"] != null)
				{
					model.ysdindex = row["ysdindex"].ToString();
				}
				if (row["devicename"] != null)
				{
					model.devicename = row["devicename"].ToString();
				}
				if (row["image_red"] != null)
				{
					model.image_red = row["image_red"].ToString();
				}
				if (row["image_high"] != null)
				{
					model.image_high = row["image_high"].ToString();
				}
				if (row["image_mix"] != null)
				{
					model.image_mix = row["image_mix"].ToString();
				}
				if (row["createtime"] != null && row["createtime"].ToString() != "")
				{
					model.createtime = DateTime.Parse(row["createtime"].ToString());
				}
				if (row["operaterNumber"] != null)
				{
					model.operaterNumber = row["operaterNumber"].ToString();
				}
				if (row["discoverer"] != null)
				{
					model.discoverer = row["discoverer"].ToString();
				}
				if (row["typename"] != null)
				{
					model.typename = row["typename"].ToString();
				}
				if (row["catchtime"] != null && row["catchtime"].ToString() != "")
				{
					model.catchtime = DateTime.Parse(row["catchtime"].ToString());
				}
				if (row["description"] != null)
				{
					model.description = row["description"].ToString();
				}
				if (row["patrolid"] != null)
				{
					model.patrolid = row["patrolid"].ToString();
				}
				if (row["status"] != null)
				{
					model.status = row["status"].ToString();
				}
				if (row["exceptiontypeid"] != null)
				{
					model.exceptiontypeid = row["exceptiontypeid"].ToString();
				}
				if (row["temperature"] != null)
				{
					model.temperature = row["temperature"].ToString();
				}
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("select id,deviceid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,machinecode,ysdname,ysdindex,devicename,image_red,image_high,image_mix,createtime,operaterNumber,discoverer,typename,catchtime,description,patrolid,status,exceptiontypeid,temperature ");
			strSql.Append(" FROM device_exception_infor ");
			if (strWhere.Trim() != "")
			{
				strSql.Append(" where " + strWhere);
			}
			return DbHelperMySQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("select count(1) FROM device_exception_infor ");
			if (strWhere.Trim() != "")
			{
				strSql.Append(" where " + strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby);
			}
			else
			{
				strSql.Append("order by T.id desc");
			}
			strSql.Append(")AS Row, T.*  from device_exception_infor T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperMySQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			MySqlParameter[] parameters = {
					new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
					new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
					new MySqlParameter("@PageSize", MySqlDbType.Int32),
					new MySqlParameter("@PageIndex", MySqlDbType.Int32),
					new MySqlParameter("@IsReCount", MySqlDbType.Bit),
					new MySqlParameter("@OrderType", MySqlDbType.Bit),
					new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
					};
			parameters[0].Value = "device_exception_infor";
			parameters[1].Value = "id";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

