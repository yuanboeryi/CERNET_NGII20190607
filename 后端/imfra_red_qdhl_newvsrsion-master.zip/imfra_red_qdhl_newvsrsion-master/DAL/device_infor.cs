﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
	/// <summary>
	/// 数据访问类:device_infor
	/// </summary>
	public partial class device_infor
	{
		public device_infor()
		{}
		#region  BasicMethod

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(string deviceid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from device_infor");
			strSql.Append(" where deviceid=@deviceid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,255)			};
			parameters[0].Value = deviceid;

			return DbHelperMySQL.Exists(strSql.ToString(),parameters);
		}


        /// <summary>
        /// 
        /// </summary>
        public string getMediaIndexByMachineId(string mid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select mediaindex from device_infor ");
            strSql.Append(" where machineid=@mid ");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@mid", MySqlDbType.VarChar, 50)};
            parameters[0].Value = mid;

            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return ds.Tables[0].Rows[0]["mediaindex"].ToString();
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.device_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into device_infor(");
            strSql.Append("deviceid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdname,ysdindex,devicename,iskeypoint,isroundpoint,isopen,distance,fuhe,offsethuman,offsetvalue,ysdtype,ysdlevel,isok,isalarm,yestodaytop,todaytop,weektop,monthtop,historytop,image_red,image_high,image_mix,createtime,templist,fuhelist,orderindex,todaymaxid,yestodaymaxid,weekmaxid,monthmaxid,historymaxid,todaymax,monthmax,operaterNumber,ppmax,ppmin,ppavg,ppcnt,pptime,patrolStatus,multiArea,multiAreaTemperature,temporary)");
            strSql.Append(" values (");
            strSql.Append("@deviceid,@areaid,@areaname,@fenbuid,@fenbuname,@ywbid,@ywbname,@stationid,@stationname,@buildingid,@buildingname,@machineid,@machinename,@ysdname,@ysdindex,@devicename,@iskeypoint,@isroundpoint,@isopen,@distance,@fuhe,@offsethuman,@offsetvalue,@ysdtype,@ysdlevel,@isok,@isalarm,@yestodaytop,@todaytop,@weektop,@monthtop,@historytop,@image_red,@image_high,@image_mix,@createtime,@templist,@fuhelist,@orderindex,@todaymaxid,@yestodaymaxid,@weekmaxid,@monthmaxid,@historymaxid,@todaymax,@monthmax,@operaterNumber,@ppmax,@ppmin,@ppavg,@ppcnt,@pptime,@patrolStatus,@multiArea,@multiAreaTemperature,@temporary)");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@deviceid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdindex", MySqlDbType.VarChar,255),
                    new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
                    new MySqlParameter("@iskeypoint", MySqlDbType.VarChar,255),
                    new MySqlParameter("@isroundpoint", MySqlDbType.VarChar,255),
                    new MySqlParameter("@isopen", MySqlDbType.VarChar,255),
                    new MySqlParameter("@distance", MySqlDbType.Double),
                    new MySqlParameter("@fuhe", MySqlDbType.VarChar,255),
                    new MySqlParameter("@offsethuman", MySqlDbType.VarChar,255),
                    new MySqlParameter("@offsetvalue", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdtype", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdlevel", MySqlDbType.VarChar,255),
                    new MySqlParameter("@isok", MySqlDbType.VarChar,255),
                    new MySqlParameter("@isalarm", MySqlDbType.VarChar,255),
                    new MySqlParameter("@yestodaytop", MySqlDbType.VarChar,255),
                    new MySqlParameter("@todaytop", MySqlDbType.VarChar,255),
                    new MySqlParameter("@weektop", MySqlDbType.VarChar,255),
                    new MySqlParameter("@monthtop", MySqlDbType.VarChar,255),
                    new MySqlParameter("@historytop", MySqlDbType.VarChar,255),
                    new MySqlParameter("@image_red", MySqlDbType.VarChar,255),
                    new MySqlParameter("@image_high", MySqlDbType.VarChar,255),
                    new MySqlParameter("@image_mix", MySqlDbType.VarChar,255),
                    new MySqlParameter("@createtime", MySqlDbType.DateTime),
                    new MySqlParameter("@templist", MySqlDbType.VarChar,255),
                    new MySqlParameter("@fuhelist", MySqlDbType.VarChar,255),
                    new MySqlParameter("@orderindex", MySqlDbType.Double),
                    new MySqlParameter("@todaymaxid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@yestodaymaxid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@weekmaxid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@monthmaxid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@historymaxid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@todaymax", MySqlDbType.VarChar,10),
                    new MySqlParameter("@monthmax", MySqlDbType.VarChar,10),
                    new MySqlParameter("@operaterNumber", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@ppmax", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@ppmin", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@ppavg", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@ppcnt", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@pptime", MySqlDbType.DateTime),
                    new MySqlParameter("@patrolStatus", MySqlDbType.VarChar, 50),
                    new MySqlParameter("@multiArea", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@multiAreaTemperature", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@temporary", MySqlDbType.VarChar, 50)};
            parameters[0].Value = model.deviceid;
            parameters[1].Value = model.areaid;
            parameters[2].Value = model.areaname;
            parameters[3].Value = model.fenbuid;
            parameters[4].Value = model.fenbuname;
            parameters[5].Value = model.ywbid;
            parameters[6].Value = model.ywbname;
            parameters[7].Value = model.stationid;
            parameters[8].Value = model.stationname;
            parameters[9].Value = model.buildingid;
            parameters[10].Value = model.buildingname;
            parameters[11].Value = model.machineid;
            parameters[12].Value = model.machinename;
            parameters[13].Value = model.ysdname;
            parameters[14].Value = model.ysdindex;
            parameters[15].Value = model.devicename;
            parameters[16].Value = model.iskeypoint;
            parameters[17].Value = model.isroundpoint;
            parameters[18].Value = model.isopen;
            parameters[19].Value = model.distance;
            parameters[20].Value = model.fuhe;
            parameters[21].Value = model.offsethuman;
            parameters[22].Value = model.offsetvalue;
            parameters[23].Value = model.ysdtype;
            parameters[24].Value = model.ysdlevel;
            parameters[25].Value = model.isok;
            parameters[26].Value = model.isalarm;
            parameters[27].Value = model.yestodaytop;
            parameters[28].Value = model.todaytop;
            parameters[29].Value = model.weektop;
            parameters[30].Value = model.monthtop;
            parameters[31].Value = model.historytop;
            parameters[32].Value = model.image_red;
            parameters[33].Value = model.image_high;
            parameters[34].Value = model.image_mix;
            parameters[35].Value = model.createtime;
            parameters[36].Value = model.templist;
            parameters[37].Value = model.fuhelist;
            parameters[38].Value = model.orderindex;
            parameters[39].Value = model.todaymaxid;
            parameters[40].Value = model.yestodaymaxid;
            parameters[41].Value = model.weekmaxid;
            parameters[42].Value = model.monthmaxid;
            parameters[43].Value = model.historymaxid;
            parameters[44].Value = model.todaymax;
            parameters[45].Value = model.monthmax;
            parameters[46].Value = model.operaterNumber;
            parameters[47].Value = model.ppmax;
            parameters[48].Value = model.ppmin;
            parameters[49].Value = model.ppavg;
            parameters[50].Value = model.ppcnt;
            parameters[51].Value = model.pptime;
            parameters[52].Value = model.patrolStatus;
            parameters[53].Value = model.multiArea;
            parameters[54].Value = model.multiAreaTemperature;
            parameters[55].Value = model.temporary;
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool UpdatePresetTemp(Maticsoft.Model.device_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("ppmax=@ppmax,");
            strSql.Append("ppmin=@ppmin,");
            strSql.Append("ppavg=@ppavg,");
            strSql.Append("ppcnt=@ppcnt,");
            strSql.Append("pptime=@pptime ");
            strSql.Append("where machineid=@machineid and ysdname=@ysdname");

            MySqlParameter[] parameters = {
                     new MySqlParameter("@ppmax", MySqlDbType.VarChar, 255),
                     new MySqlParameter("@ppmin", MySqlDbType.VarChar, 255),
                     new MySqlParameter("@ppavg", MySqlDbType.VarChar, 255),
                     new MySqlParameter("@ppcnt", MySqlDbType.VarChar, 255),
                     new MySqlParameter("@pptime", MySqlDbType.DateTime),
                     new MySqlParameter("@machineid", MySqlDbType.VarChar, 50),
                     new MySqlParameter("@ysdname", MySqlDbType.VarChar, 50),
            };

            parameters[0].Value = model.ppmax;
            parameters[1].Value = model.ppmin;
            parameters[2].Value = model.ppavg;
            parameters[3].Value = model.ppcnt;
            parameters[4].Value = model.pptime;
            parameters[5].Value = model.machineid;
            parameters[6].Value = model.ysdname;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);

            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 更新一条数据
        /// </summary>
        /// 

        //public bool Update(Maticsoft.Model.device_infor model)
        //{
        //    StringBuilder strSql = new StringBuilder();
        //    strSql.Append("update device_infor set ");
        //    strSql.Append("areaid=@areaid,");
        //    strSql.Append("areaname=@areaname,");
        //    strSql.Append("fenbuid=@fenbuid,");
        //    strSql.Append("fenbuname=@fenbuname,");
        //    strSql.Append("ywbid=@ywbid,");
        //    strSql.Append("ywbname=@ywbname,");
        //    strSql.Append("stationid=@stationid,");
        //    strSql.Append("stationname=@stationname,");
        //    strSql.Append("buildingid=@buildingid,");
        //    strSql.Append("buildingname=@buildingname,");
        //    strSql.Append("machineid=@machineid,");
        //    strSql.Append("machinename=@machinename,");
        //    strSql.Append("ysdname=@ysdname,");
        //    strSql.Append("ysdindex=@ysdindex,");
        //    strSql.Append("devicename=@devicename,");
        //    strSql.Append("iskeypoint=@iskeypoint,");
        //    strSql.Append("isroundpoint=@isroundpoint,");
        //    strSql.Append("isopen=@isopen,");
        //    strSql.Append("distance=@distance,");
        //    strSql.Append("fuhe=@fuhe,");
        //    strSql.Append("offsethuman=@offsethuman,");
        //    strSql.Append("offsetvalue=@offsetvalue,");
        //    strSql.Append("ysdtype=@ysdtype,");
        //    strSql.Append("ysdlevel=@ysdlevel,");
        //    strSql.Append("isok=@isok,");
        //    strSql.Append("isalarm=@isalarm,");
        //    strSql.Append("yestodaytop=@yestodaytop,");
        //    strSql.Append("todaytop=@todaytop,");
        //    strSql.Append("weektop=@weektop,");
        //    strSql.Append("monthtop=@monthtop,");
        //    strSql.Append("historytop=@historytop,");
        //    strSql.Append("image_red=@image_red,");
        //    strSql.Append("image_high=@image_high,");
        //    strSql.Append("image_mix=@image_mix,");
        //    strSql.Append("createtime=@createtime,");
        //    strSql.Append("templist=@templist,");
        //    strSql.Append("fuhelist=@fuhelist,");
        //    strSql.Append("orderindex=@orderindex,");
        //    strSql.Append("todaymaxid=@todaymaxid,");
        //    strSql.Append("yestodaymaxid=@yestodaymaxid,");
        //    strSql.Append("weekmaxid=@weekmaxid,");
        //    strSql.Append("monthmaxid=@monthmaxid,");
        //    strSql.Append("historymaxid=@historymaxid,");
        //    strSql.Append("todaymax=@todaymax,");
        //    strSql.Append("monthmax=@monthmax,");
        //    strSql.Append("mediaindex=@mediaindex,");
        //    strSql.Append("operaterNumber=@operaterNumber");
        //    strSql.Append(" where deviceid=@deviceid ");
        //    MySqlParameter[] parameters = {
        //            new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@ysdname", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@ysdindex", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@iskeypoint", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@isroundpoint", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@isopen", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@distance", MySqlDbType.Double),
        //            new MySqlParameter("@fuhe", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@offsethuman", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@offsetvalue", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@ysdtype", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@ysdlevel", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@isok", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@isalarm", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@yestodaytop", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@todaytop", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@weektop", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@monthtop", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@historytop", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@image_red", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@image_high", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@image_mix", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@createtime", MySqlDbType.DateTime),
        //            new MySqlParameter("@templist", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@fuhelist", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@orderindex", MySqlDbType.Double),
        //            new MySqlParameter("@todaymaxid", MySqlDbType.VarChar,50),
        //            new MySqlParameter("@yestodaymaxid", MySqlDbType.VarChar,50),
        //            new MySqlParameter("@weekmaxid", MySqlDbType.VarChar,50),
        //            new MySqlParameter("@monthmaxid", MySqlDbType.VarChar,50),
        //            new MySqlParameter("@historymaxid", MySqlDbType.VarChar,50),
        //            new MySqlParameter("@todaymax", MySqlDbType.VarChar,10),
        //            new MySqlParameter("@monthmax", MySqlDbType.VarChar,10),
        //            new MySqlParameter("@mediaindex", MySqlDbType.Int32,11),
        //            new MySqlParameter("@operaterNumber", MySqlDbType.VarChar,255),
        //            new MySqlParameter("@deviceid", MySqlDbType.VarChar,255)};
        //    parameters[0].Value = model.areaid;
        //    parameters[1].Value = model.areaname;
        //    parameters[2].Value = model.fenbuid;
        //    parameters[3].Value = model.fenbuname;
        //    parameters[4].Value = model.ywbid;
        //    parameters[5].Value = model.ywbname;
        //    parameters[6].Value = model.stationid;
        //    parameters[7].Value = model.stationname;
        //    parameters[8].Value = model.buildingid;
        //    parameters[9].Value = model.buildingname;
        //    parameters[10].Value = model.machineid;
        //    parameters[11].Value = model.machinename;
        //    parameters[12].Value = model.ysdname;
        //    parameters[13].Value = model.ysdindex;
        //    parameters[14].Value = model.devicename;
        //    parameters[15].Value = model.iskeypoint;
        //    parameters[16].Value = model.isroundpoint;
        //    parameters[17].Value = model.isopen;
        //    parameters[18].Value = model.distance;
        //    parameters[19].Value = model.fuhe;
        //    parameters[20].Value = model.offsethuman;
        //    parameters[21].Value = model.offsetvalue;
        //    parameters[22].Value = model.ysdtype;
        //    parameters[23].Value = model.ysdlevel;
        //    parameters[24].Value = model.isok;
        //    parameters[25].Value = model.isalarm;
        //    parameters[26].Value = model.yestodaytop;
        //    parameters[27].Value = model.todaytop;
        //    parameters[28].Value = model.weektop;
        //    parameters[29].Value = model.monthtop;
        //    parameters[30].Value = model.historytop;
        //    parameters[31].Value = model.image_red;
        //    parameters[32].Value = model.image_high;
        //    parameters[33].Value = model.image_mix;
        //    parameters[34].Value = model.createtime;
        //    parameters[35].Value = model.templist;
        //    parameters[36].Value = model.fuhelist;
        //    parameters[37].Value = model.orderindex;
        //    parameters[38].Value = model.todaymaxid;
        //    parameters[39].Value = model.yestodaymaxid;
        //    parameters[40].Value = model.weekmaxid;
        //    parameters[41].Value = model.monthmaxid;
        //    parameters[42].Value = model.historymaxid;
        //    parameters[43].Value = model.todaymax;
        //    parameters[44].Value = model.monthmax;
        //    parameters[45].Value = model.mediaindex;
        //    parameters[46].Value = model.operaterNumber;
        //    parameters[47].Value = model.deviceid;

        //    int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
        //    if (rows > 0)
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}
        /// <summary>
        /// 更新一条数据
        /// </summary>
        //public bool Update(Maticsoft.Model.device_infor model)
        //      {
        //          StringBuilder strSql = new StringBuilder();
        //          strSql.Append("update device_infor set ");
        //          strSql.Append("areaid=@areaid,");
        //          strSql.Append("areaname=@areaname,");
        //          strSql.Append("fenbuid=@fenbuid,");
        //          strSql.Append("fenbuname=@fenbuname,");
        //          strSql.Append("ywbid=@ywbid,");
        //          strSql.Append("ywbname=@ywbname,");
        //          strSql.Append("stationid=@stationid,");
        //          strSql.Append("stationname=@stationname,");
        //          strSql.Append("buildingid=@buildingid,");
        //          strSql.Append("buildingname=@buildingname,");
        //          strSql.Append("machineid=@machineid,");
        //          strSql.Append("machinename=@machinename,");
        //          strSql.Append("ysdname=@ysdname,");
        //          strSql.Append("ysdindex=@ysdindex,");
        //          strSql.Append("devicename=@devicename,");
        //          strSql.Append("iskeypoint=@iskeypoint,");
        //          strSql.Append("isroundpoint=@isroundpoint,");
        //          strSql.Append("isopen=@isopen,");
        //          strSql.Append("distance=@distance,");
        //          strSql.Append("fuhe=@fuhe,");
        //          strSql.Append("offsethuman=@offsethuman,");
        //          strSql.Append("offsetvalue=@offsetvalue,");
        //          strSql.Append("ysdtype=@ysdtype,");
        //          strSql.Append("ysdlevel=@ysdlevel,");
        //          strSql.Append("isok=@isok,");
        //          strSql.Append("isalarm=@isalarm,");
        //          strSql.Append("yestodaytop=@yestodaytop,");
        //          strSql.Append("todaytop=@todaytop,");
        //          strSql.Append("weektop=@weektop,");
        //          strSql.Append("monthtop=@monthtop,");
        //          strSql.Append("historytop=@historytop,");
        //          strSql.Append("image_red=@image_red,");
        //          strSql.Append("image_high=@image_high,");
        //          strSql.Append("image_mix=@image_mix,");
        //          strSql.Append("createtime=@createtime,");
        //          strSql.Append("templist=@templist,");
        //          strSql.Append("fuhelist=@fuhelist,");
        //          strSql.Append("orderindex=@orderindex,");
        //          strSql.Append("todaymaxid=@todaymaxid,");
        //          strSql.Append("yestodaymaxid=@yestodaymaxid,");
        //          strSql.Append("weekmaxid=@weekmaxid,");
        //          strSql.Append("monthmaxid=@monthmaxid,");
        //          strSql.Append("historymaxid=@historymaxid,");
        //          strSql.Append("todaymax=@todaymax,");
        //          strSql.Append("monthmax=@monthmax,");
        //          strSql.Append("mediaindex=@mediaindex,");
        //          strSql.Append("operaterNumber=@operaterNumber,");
        //          strSql.Append("ppmax=@ppmax,");
        //          strSql.Append("ppmin=@ppmin,");
        //          strSql.Append("ppavg=@ppavg,");
        //          strSql.Append("ppcnt=@ppcnt,");
        //          strSql.Append("pptime=@pptime");
        //          strSql.Append("patrolStatus=@patrolStatus");
        //          strSql.Append(" where deviceid=@deviceid ");
        //          MySqlParameter[] parameters = {
        //                  new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@ysdname", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@ysdindex", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@iskeypoint", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@isroundpoint", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@isopen", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@distance", MySqlDbType.Double),
        //                  new MySqlParameter("@fuhe", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@offsethuman", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@offsetvalue", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@ysdtype", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@ysdlevel", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@isok", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@isalarm", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@yestodaytop", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@todaytop", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@weektop", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@monthtop", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@historytop", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@image_red", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@image_high", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@image_mix", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@createtime", MySqlDbType.DateTime),
        //                  new MySqlParameter("@templist", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@fuhelist", MySqlDbType.VarChar,255),
        //                  new MySqlParameter("@orderindex", MySqlDbType.Double),
        //                  new MySqlParameter("@todaymaxid", MySqlDbType.VarChar,50),
        //                  new MySqlParameter("@yestodaymaxid", MySqlDbType.VarChar,50),
        //                  new MySqlParameter("@weekmaxid", MySqlDbType.VarChar,50),
        //                  new MySqlParameter("@monthmaxid", MySqlDbType.VarChar,50),
        //                  new MySqlParameter("@historymaxid", MySqlDbType.VarChar,50),
        //                  new MySqlParameter("@todaymax", MySqlDbType.VarChar,10),
        //                  new MySqlParameter("@monthmax", MySqlDbType.VarChar,10),
        //                  new MySqlParameter("@mediaindex", MySqlDbType.Int32,11),
        //                  new MySqlParameter("@operaterNumber", MySqlDbType.VarChar,255),
        //                   new MySqlParameter("@ppmax", MySqlDbType.VarChar, 255),
        //                   new MySqlParameter("@ppmin", MySqlDbType.VarChar, 255),
        //                   new MySqlParameter("@ppavg", MySqlDbType.VarChar, 255),
        //                   new MySqlParameter("@ppcnt", MySqlDbType.VarChar, 255),
        //                   new MySqlParameter("@pptime", MySqlDbType.DateTime),
        //                   new MySqlParameter("@patrolStatus", MySqlDbType.DateTime),
        //                  new MySqlParameter("@deviceid", MySqlDbType.VarChar,255)};
        //          parameters[0].Value = model.areaid;
        //          parameters[1].Value = model.areaname;
        //          parameters[2].Value = model.fenbuid;
        //          parameters[3].Value = model.fenbuname;
        //          parameters[4].Value = model.ywbid;
        //          parameters[5].Value = model.ywbname;
        //          parameters[6].Value = model.stationid;
        //          parameters[7].Value = model.stationname;
        //          parameters[8].Value = model.buildingid;
        //          parameters[9].Value = model.buildingname;
        //          parameters[10].Value = model.machineid;
        //          parameters[11].Value = model.machinename;
        //          parameters[12].Value = model.ysdname;
        //          parameters[13].Value = model.ysdindex;
        //          parameters[14].Value = model.devicename;
        //          parameters[15].Value = model.iskeypoint;
        //          parameters[16].Value = model.isroundpoint;
        //          parameters[17].Value = model.isopen;
        //          parameters[18].Value = model.distance;
        //          parameters[19].Value = model.fuhe;
        //          parameters[20].Value = model.offsethuman;
        //          parameters[21].Value = model.offsetvalue;
        //          parameters[22].Value = model.ysdtype;
        //          parameters[23].Value = model.ysdlevel;
        //          parameters[24].Value = model.isok;
        //          parameters[25].Value = model.isalarm;
        //          parameters[26].Value = model.yestodaytop;
        //          parameters[27].Value = model.todaytop;
        //          parameters[28].Value = model.weektop;
        //          parameters[29].Value = model.monthtop;
        //          parameters[30].Value = model.historytop;
        //          parameters[31].Value = model.image_red;
        //          parameters[32].Value = model.image_high;
        //          parameters[33].Value = model.image_mix;
        //          parameters[34].Value = model.createtime;
        //          parameters[35].Value = model.templist;
        //          parameters[36].Value = model.fuhelist;
        //          parameters[37].Value = model.orderindex;
        //          parameters[38].Value = model.todaymaxid;
        //          parameters[39].Value = model.yestodaymaxid;
        //          parameters[40].Value = model.weekmaxid;
        //          parameters[41].Value = model.monthmaxid;
        //          parameters[42].Value = model.historymaxid;
        //          parameters[43].Value = model.todaymax;
        //          parameters[44].Value = model.monthmax;
        //          parameters[45].Value = model.mediaindex;
        //          parameters[46].Value = model.operaterNumber;

        //          parameters[47].Value = model.ppmax;
        //          parameters[48].Value = model.ppmin;
        //          parameters[49].Value = model.ppavg;
        //          parameters[50].Value = model.ppcnt;
        //          parameters[51].Value = model.pptime;

        //          parameters[52].Value = model.patrolStatus;

        //          parameters[53].Value = model.deviceid;

        //          int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
        //          if (rows > 0)
        //          {
        //              return true;
        //          }
        //          else
        //          {
        //              return false;
        //          }
        //      }

        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.device_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("areaid=@areaid,");
            strSql.Append("areaname=@areaname,");
            strSql.Append("fenbuid=@fenbuid,");
            strSql.Append("fenbuname=@fenbuname,");
            strSql.Append("ywbid=@ywbid,");
            strSql.Append("ywbname=@ywbname,");
            strSql.Append("stationid=@stationid,");
            strSql.Append("stationname=@stationname,");
            strSql.Append("buildingid=@buildingid,");
            strSql.Append("buildingname=@buildingname,");
            strSql.Append("machineid=@machineid,");
            strSql.Append("machinename=@machinename,");
            strSql.Append("ysdname=@ysdname,");
            strSql.Append("ysdindex=@ysdindex,");
            strSql.Append("devicename=@devicename,");
            strSql.Append("iskeypoint=@iskeypoint,");
            strSql.Append("isroundpoint=@isroundpoint,");
            strSql.Append("isopen=@isopen,");
            strSql.Append("distance=@distance,");
            strSql.Append("fuhe=@fuhe,");
            strSql.Append("offsethuman=@offsethuman,");
            strSql.Append("offsetvalue=@offsetvalue,");
            strSql.Append("ysdtype=@ysdtype,");
            strSql.Append("ysdlevel=@ysdlevel,");
            strSql.Append("isok=@isok,");
            strSql.Append("isalarm=@isalarm,");
            strSql.Append("yestodaytop=@yestodaytop,");
            strSql.Append("todaytop=@todaytop,");
            strSql.Append("weektop=@weektop,");
            strSql.Append("monthtop=@monthtop,");
            strSql.Append("historytop=@historytop,");
            strSql.Append("image_red=@image_red,");
            strSql.Append("image_high=@image_high,");
            strSql.Append("image_mix=@image_mix,");
            strSql.Append("createtime=@createtime,");
            strSql.Append("templist=@templist,");
            strSql.Append("fuhelist=@fuhelist,");
            strSql.Append("orderindex=@orderindex,");
            strSql.Append("todaymaxid=@todaymaxid,");
            strSql.Append("yestodaymaxid=@yestodaymaxid,");
            strSql.Append("weekmaxid=@weekmaxid,");
            strSql.Append("monthmaxid=@monthmaxid,");
            strSql.Append("historymaxid=@historymaxid,");
            strSql.Append("todaymax=@todaymax,");
            strSql.Append("monthmax=@monthmax,");
            strSql.Append("mediaindex=@mediaindex,");
            strSql.Append("operaterNumber=@operaterNumber,");
            strSql.Append("ppmax=@ppmax,");
            strSql.Append("ppmin=@ppmin,");
            strSql.Append("ppavg=@ppavg,");
            strSql.Append("ppcnt=@ppcnt,");
            strSql.Append("pptime=@pptime,");
            strSql.Append("patrolStatus=@patrolStatus,");
            strSql.Append("multiArea=@multiArea,");
            strSql.Append("multiAreaTemperature=@multiAreaTemperature,");
            strSql.Append("temporary=@temporary");
            strSql.Append(" where deviceid=@deviceid ");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdname", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdindex", MySqlDbType.VarChar,255),
                    new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
                    new MySqlParameter("@iskeypoint", MySqlDbType.VarChar,255),
                    new MySqlParameter("@isroundpoint", MySqlDbType.VarChar,255),
                    new MySqlParameter("@isopen", MySqlDbType.VarChar,255),
                    new MySqlParameter("@distance", MySqlDbType.Double),
                    new MySqlParameter("@fuhe", MySqlDbType.VarChar,255),
                    new MySqlParameter("@offsethuman", MySqlDbType.VarChar,255),
                    new MySqlParameter("@offsetvalue", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdtype", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdlevel", MySqlDbType.VarChar,255),
                    new MySqlParameter("@isok", MySqlDbType.VarChar,255),
                    new MySqlParameter("@isalarm", MySqlDbType.VarChar,255),
                    new MySqlParameter("@yestodaytop", MySqlDbType.VarChar,255),
                    new MySqlParameter("@todaytop", MySqlDbType.VarChar,255),
                    new MySqlParameter("@weektop", MySqlDbType.VarChar,255),
                    new MySqlParameter("@monthtop", MySqlDbType.VarChar,255),
                    new MySqlParameter("@historytop", MySqlDbType.VarChar,255),
                    new MySqlParameter("@image_red", MySqlDbType.VarChar,255),
                    new MySqlParameter("@image_high", MySqlDbType.VarChar,255),
                    new MySqlParameter("@image_mix", MySqlDbType.VarChar,255),
                    new MySqlParameter("@createtime", MySqlDbType.DateTime),
                    new MySqlParameter("@templist", MySqlDbType.VarChar,255),
                    new MySqlParameter("@fuhelist", MySqlDbType.VarChar,255),
                    new MySqlParameter("@orderindex", MySqlDbType.Double),
                    new MySqlParameter("@todaymaxid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@yestodaymaxid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@weekmaxid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@monthmaxid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@historymaxid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@todaymax", MySqlDbType.VarChar,10),
                    new MySqlParameter("@monthmax", MySqlDbType.VarChar,10),
                    new MySqlParameter("@mediaindex", MySqlDbType.Int32,10),
                    new MySqlParameter("@operaterNumber", MySqlDbType.VarChar,50),
                    new MySqlParameter("@ppmax", MySqlDbType.VarChar,50),
                    new MySqlParameter("@ppmin", MySqlDbType.VarChar,50),
                    new MySqlParameter("@ppavg", MySqlDbType.VarChar,50),
                    new MySqlParameter("@ppcnt", MySqlDbType.VarChar,50),
                    new MySqlParameter("@pptime", MySqlDbType.DateTime),
                    new MySqlParameter("@patrolStatus", MySqlDbType.VarChar,20),
                    new MySqlParameter("@multiArea", MySqlDbType.VarChar,255),
                    new MySqlParameter("@multiAreaTemperature", MySqlDbType.VarChar,255),
                    new MySqlParameter("@temporary", MySqlDbType.VarChar,50),
                    new MySqlParameter("@deviceid", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.areaid;
            parameters[1].Value = model.areaname;
            parameters[2].Value = model.fenbuid;
            parameters[3].Value = model.fenbuname;
            parameters[4].Value = model.ywbid;
            parameters[5].Value = model.ywbname;
            parameters[6].Value = model.stationid;
            parameters[7].Value = model.stationname;
            parameters[8].Value = model.buildingid;
            parameters[9].Value = model.buildingname;
            parameters[10].Value = model.machineid;
            parameters[11].Value = model.machinename;
            parameters[12].Value = model.ysdname;
            parameters[13].Value = model.ysdindex;
            parameters[14].Value = model.devicename;
            parameters[15].Value = model.iskeypoint;
            parameters[16].Value = model.isroundpoint;
            parameters[17].Value = model.isopen;
            parameters[18].Value = model.distance;
            parameters[19].Value = model.fuhe;
            parameters[20].Value = model.offsethuman;
            parameters[21].Value = model.offsetvalue;
            parameters[22].Value = model.ysdtype;
            parameters[23].Value = model.ysdlevel;
            parameters[24].Value = model.isok;
            parameters[25].Value = model.isalarm;
            parameters[26].Value = model.yestodaytop;
            parameters[27].Value = model.todaytop;
            parameters[28].Value = model.weektop;
            parameters[29].Value = model.monthtop;
            parameters[30].Value = model.historytop;
            parameters[31].Value = model.image_red;
            parameters[32].Value = model.image_high;
            parameters[33].Value = model.image_mix;
            parameters[34].Value = model.createtime;
            parameters[35].Value = model.templist;
            parameters[36].Value = model.fuhelist;
            parameters[37].Value = model.orderindex;
            parameters[38].Value = model.todaymaxid;
            parameters[39].Value = model.yestodaymaxid;
            parameters[40].Value = model.weekmaxid;
            parameters[41].Value = model.monthmaxid;
            parameters[42].Value = model.historymaxid;
            parameters[43].Value = model.todaymax;
            parameters[44].Value = model.monthmax;
            parameters[45].Value = model.mediaindex;
            parameters[46].Value = model.operaterNumber;
            parameters[47].Value = model.ppmax;
            parameters[48].Value = model.ppmin;
            parameters[49].Value = model.ppavg;
            parameters[50].Value = model.ppcnt;
            parameters[51].Value = model.pptime;
            parameters[52].Value = model.patrolStatus;
            parameters[53].Value = model.multiArea;
            parameters[54].Value = model.multiAreaTemperature;
            parameters[55].Value = model.temporary;
            parameters[56].Value = model.deviceid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }



        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Updatemenusre(string id)
		{
            if(id!="")
            {
                string s = "0";
                StringBuilder strSql = new StringBuilder();
                strSql.Append("update device_infor set ");

                strSql.Append("isok='" + s + "'");

                strSql.Append(" where deviceid='" + id + "'");


                int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
                if (rows > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                string s = "0";
                StringBuilder strSql = new StringBuilder();
                strSql.Append("update device_infor set ");

                strSql.Append("isok='" + s + "'");

                strSql.Append(" where 1=1");

                int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
                if (rows > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
           
		}

        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateMediaIndex(string macid, string index)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("mediaindex="+ index);
            strSql.Append(" where machineid='" + macid + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());

            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool UpdateOperaterNumber(string operaterNumber, string deviceid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("operaterNumber= '" + operaterNumber + "' ");
            strSql.Append(" where deviceid='" + deviceid + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());

            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool UpdateDeviceName(string devicename, string deviceid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("devicename='" + devicename + "' ");
            strSql.Append(" where deviceid='" + deviceid + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());

            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateBuilding(string id, string name,string idnew)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("buildingname='" + name + "',buildingid='"+idnew+"'");
            strSql.Append(" where buildingid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());


            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update_every_value(string deviceid)
        {
            string value = "0.0";
            StringBuilder strSql = new StringBuilder();
            //strSql.Append("update device_infor set ");
            //strSql.Append("todaytop='" + value + "',yestodaytop='"+ value +"',weektop='" + value + "',monthtop='"+value+"',historytop='"+value+"',todaymax='"+value+"',monthmax='"+value+"'");
            //strSql.Append(" where deviceid='"+deviceid+"'");


            strSql.Append("update device_infor set ");
            strSql.Append("todaytop='" + value + "',yestodaytop='" + value + "',weektop='" + value + "',monthtop='" + value + 
                "',historytop='" + value + "',todaymax='" + value + "',monthmax='" + value + "'");
            strSql.Append(" where deviceid='" + deviceid + "'");

            int rows = DbHelperSQL.ExecuteSql(strSql.ToString());
            
            if(rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            

        }

        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateBuilding1(string id, string name, string idnew,string machineid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("buildingname='" + name + "',buildingid='" + idnew + "'");
            strSql.Append(" where machineid='" + machineid + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());


            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateAYsdindex(string id, string value)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("ysdindex='"+value+"'");
            strSql.Append(" where deviceid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());


            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
       
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool modifyAlarmValue(string id, string value,string manager)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("offsetvalue='" + value + "',offsethuman='"+manager+"'");
            strSql.Append(" where deviceid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());


            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateMachineid(string id, string value)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("machineid='" + value + "'");
            strSql.Append(" where deviceid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());


            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateAlarm(string id, string value, string today)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.Append("update device_infor set ");
            strSql.Append("isalarm='" + value + "',todaytop='"+today+"'");
            strSql.Append(" where deviceid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());

         
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool UpdateHistory(string id, string yestoday, string week, string month, string history, string todaymax, string monthmax,string todayid,string yestodayid,string weekid,string monthid,string historyid)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.Append("update device_infor set ");
            strSql.Append("yestodaytop='" + yestoday + "',weektop='" + week + "',monthtop='"+month+"',historytop='"+history+"',todaymax='"+todaymax+"',monthmax='"+monthmax+"',todaymaxid='"+todayid+"',yestodaymaxid='"+yestodayid+"',weekmaxid='"+weekid+"',monthmaxid='"+monthid+"',historymaxid='"+historyid+"'");
            strSql.Append(" where deviceid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());


            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool UpdateHistorytodaymax(string id,string todaymax, string todayid)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.Append("update device_infor set ");
            strSql.Append("todaymax='" + todaymax + "',todaymaxid='" + todayid + "'");
            strSql.Append(" where deviceid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());


            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateImage(string id, string imagename1,string imagename2,string imagename3,DateTime dt,string templist)
        {
            StringBuilder strSql = new StringBuilder();
           
            strSql.Append("update device_infor set ");
            if(imagename1=="")
                strSql.Append("image_red='" + imagename2 + "',image_mix='" + imagename3 + "',createtime='" + dt.ToString() + "',templist='" + templist + "'");

            else
                strSql.Append("image_high='" + imagename1 + "',image_red='" + imagename2 + "',image_mix='" + imagename3 + "',createtime='" + dt.ToString() + "',templist='" + templist + "'");
           
            strSql.Append(" where deviceid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());


            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
           /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateKeyPoint(string id, string stationid, string value)
        {
            string iskey="0";
            StringBuilder strSql = new StringBuilder();
            //strSql.Append("update device_infor set ");
            //strSql.Append("iskeypoint='" + iskey + "'");
            //strSql.Append(" where stationid='"+stationid+"' ");
            //int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());

            //strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("iskeypoint='" + value + "'");
            strSql.Append(" where deviceid='"+id+"' and stationid='" + stationid + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateRound(string id, string value)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("isroundpoint='"+value+"'");
            strSql.Append(" where deviceid='"+id+"' ");

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdatePatrolStatus(string id, string patrolStatus)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("patrolStatus='" + patrolStatus + "'");
            strSql.Append(" where deviceid='" + id + "' ");

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateTemporary(string id, string patrolStatus, string temporary)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("patrolStatus='" + patrolStatus + "',temporary='"+ temporary + "'");
            strSql.Append(" where deviceid='" + id + "' ");

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateIsopen(string id, string value)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_infor set ");
            strSql.Append("isopen='" + value + "'");
            strSql.Append(" where deviceid='" + id + "' ");

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool DeleteAlarm(string deviceid)
        {
            if(deviceid=="")
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("delete from device_infor ");
                strSql.Append(" where 1=1 ");
               
                int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
                if (rows > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("delete from device_infor ");
                strSql.Append(" where deviceid=@deviceid ");
                MySqlParameter[] parameters = {
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,255)			};
                parameters[0].Value = deviceid;

                int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
                if (rows > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
         
        }
		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(string deviceid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from device_infor ");
			strSql.Append(" where deviceid=@deviceid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,255)			};
			parameters[0].Value = deviceid;

			int rows=DbHelperMySQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string deviceidlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from device_infor ");
			strSql.Append(" where deviceid in ("+deviceidlist + ")  ");
			int rows=DbHelperMySQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.device_infor GetModel(string deviceid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select deviceid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdname,ysdindex,devicename,iskeypoint,isroundpoint,isopen,distance,fuhe,offsethuman,offsetvalue,ysdtype,ysdlevel,isok,isalarm,yestodaytop,todaytop,weektop,monthtop,historytop,image_red,image_high,image_mix,createtime,templist,fuhelist,orderindex,todaymaxid,yestodaymaxid,weekmaxid,monthmaxid,historymaxid,todaymax,monthmax,mediaindex,operaterNumber,ppmax,ppmin,ppavg,ppcnt,pptime,patrolStatus,multiArea,multiAreaTemperature,temporary  from device_infor ");
            strSql.Append(" where deviceid=@deviceid ");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@deviceid", MySqlDbType.VarChar,255)            };
            parameters[0].Value = deviceid;

            Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }

     //   public Maticsoft.Model.device_infor GetModel(string deviceid)
     //   {

     //       StringBuilder strSql = new StringBuilder();
     //       strSql.Append("select deviceid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdname,ysdindex,devicename,iskeypoint,isroundpoint,isopen,distance,fuhe,offsethuman,offsetvalue,ysdtype,ysdlevel,isok,isalarm,yestodaytop,todaytop,weektop,monthtop,historytop,image_red,image_high,image_mix,createtime,templist,fuhelist,orderindex,todaymaxid,yestodaymaxid,weekmaxid,monthmaxid,historymaxid,todaymax,monthmax,mediaindex,operaterNumber from device_infor ");
     //       strSql.Append(" where deviceid=@deviceid ");
     //       MySqlParameter[] parameters = {
					//new MySqlParameter("@deviceid", MySqlDbType.VarChar,255)			};
     //       parameters[0].Value = deviceid;

     //       Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
     //       DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
     //       if (ds.Tables[0].Rows.Count > 0)
     //       {
     //           return DataRowToModel(ds.Tables[0].Rows[0]);
     //       }
     //       else
     //       {
     //           return null;
     //       }
     //   }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.device_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
            if (row != null)
            {
                if (row["deviceid"] != null)
                {
                    model.deviceid = row["deviceid"].ToString();
                }
                if (row["areaid"] != null)
                {
                    model.areaid = row["areaid"].ToString();
                }
                if (row["areaname"] != null)
                {
                    model.areaname = row["areaname"].ToString();
                }
                if (row["fenbuid"] != null)
                {
                    model.fenbuid = row["fenbuid"].ToString();
                }
                if (row["fenbuname"] != null)
                {
                    model.fenbuname = row["fenbuname"].ToString();
                }
                if (row["ywbid"] != null)
                {
                    model.ywbid = row["ywbid"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
                if (row["stationid"] != null)
                {
                    model.stationid = row["stationid"].ToString();
                }
                if (row["stationname"] != null)
                {
                    model.stationname = row["stationname"].ToString();
                }
                if (row["buildingid"] != null)
                {
                    model.buildingid = row["buildingid"].ToString();
                }
                if (row["buildingname"] != null)
                {
                    model.buildingname = row["buildingname"].ToString();
                }
                if (row["machineid"] != null)
                {
                    model.machineid = row["machineid"].ToString();
                }
                if (row["machinename"] != null)
                {
                    model.machinename = row["machinename"].ToString();
                }
                if (row["ysdname"] != null)
                {
                    model.ysdname = row["ysdname"].ToString();
                }
                if (row["ysdindex"] != null)
                {
                    model.ysdindex = row["ysdindex"].ToString();
                }
                if (row["devicename"] != null)
                {
                    model.devicename = row["devicename"].ToString();
                }
                if (row["iskeypoint"] != null)
                {
                    model.iskeypoint = row["iskeypoint"].ToString();
                }
                if (row["isroundpoint"] != null)
                {
                    model.isroundpoint = row["isroundpoint"].ToString();
                }
                if (row["isopen"] != null)
                {
                    model.isopen = row["isopen"].ToString();
                }
                if(row["distance"] != null && row["distance"].ToString() != "")
                {
                    model.distance = Convert.ToDouble(row["distance"].ToString());
                }
                if (row["fuhe"] != null)
                {
                    model.fuhe = row["fuhe"].ToString();
                }
                if (row["offsethuman"] != null)
                {
                    model.offsethuman = row["offsethuman"].ToString();
                }
                if (row["offsetvalue"] != null)
                {
                    model.offsetvalue = row["offsetvalue"].ToString();
                }
                if (row["ysdtype"] != null)
                {
                    model.ysdtype = row["ysdtype"].ToString();
                }
                if (row["ysdlevel"] != null)
                {
                    model.ysdlevel = row["ysdlevel"].ToString();
                }
                if (row["isok"] != null)
                {
                    model.isok = row["isok"].ToString();
                }
                if (row["isalarm"] != null)
                {
                    model.isalarm = row["isalarm"].ToString();
                }
                if (row["yestodaytop"] != null)
                {
                    model.yestodaytop = row["yestodaytop"].ToString();
                }
                if (row["todaytop"] != null)
                {
                    model.todaytop = row["todaytop"].ToString();
                }
                if (row["weektop"] != null)
                {
                    model.weektop = row["weektop"].ToString();
                }
                if (row["monthtop"] != null)
                {
                    model.monthtop = row["monthtop"].ToString();
                }
                if (row["historytop"] != null)
                {
                    model.historytop = row["historytop"].ToString();
                }
                if (row["image_red"] != null)
                {
                    model.image_red = row["image_red"].ToString();
                }
                if (row["image_high"] != null)
                {
                    model.image_high = row["image_high"].ToString();
                }
                if (row["image_mix"] != null)
                {
                    model.image_mix = row["image_mix"].ToString();
                }
                if (row["createtime"] != null && row["createtime"].ToString() != "")
                {
                    model.createtime = DateTime.Parse(row["createtime"].ToString());
                }
                if (row["templist"] != null)
                {
                    model.templist = row["templist"].ToString();
                }
                if (row["fuhelist"] != null)
                {
                    model.fuhelist = row["fuhelist"].ToString();
                }
                if (row["orderindex"] != null && row["orderindex"].ToString() != "")
                {
                    model.orderindex = Convert.ToDouble(row["orderindex"].ToString());
                }
                if (row["todaymaxid"] != null)
                {
                    model.todaymaxid = row["todaymaxid"].ToString();
                }
                if (row["yestodaymaxid"] != null)
                {
                    model.yestodaymaxid = row["yestodaymaxid"].ToString();
                }
                if (row["weekmaxid"] != null)
                {
                    model.weekmaxid = row["weekmaxid"].ToString();
                }
                if (row["monthmaxid"] != null)
                {
                    model.monthmaxid = row["monthmaxid"].ToString();
                }
                if (row["historymaxid"] != null)
                {
                    model.historymaxid = row["historymaxid"].ToString();
                }
                if (row["todaymax"] != null)
                {
                    model.todaymax = row["todaymax"].ToString();
                }
                if (row["monthmax"] != null)
                {
                    model.monthmax = row["monthmax"].ToString();
                }
                if (row["mediaindex"] != null)
                {
                    model.mediaindex = Convert.ToInt32(row["mediaindex"]);
                }
                if (row["operaterNumber"] != null)
                {
                    model.operaterNumber = row["operaterNumber"].ToString();
                }
                if (row["patrolStatus"] != null)
                {
                    model.patrolStatus = row["patrolStatus"].ToString();
                }
                if (row["ppmax"] != null)
                {
                    model.ppmax = row["ppmax"].ToString();
                }
                if (row["ppmin"] != null)
                {
                    model.ppmin = row["ppmin"].ToString();
                }
                if (row["ppavg"] != null)
                {
                    model.ppavg = row["ppavg"].ToString();
                }
                if (row["ppcnt"] != null)
                {
                    model.ppcnt = row["ppcnt"].ToString();
                }
                if (row["pptime"] != null && row["pptime"].ToString() != "")
                {
                    model.pptime = DateTime.Parse(row["pptime"].ToString());
                }
                if (row["multiArea"] != null)
                {
                    model.multiArea = row["multiArea"].ToString();
                }
                if (row["multiAreaTemperature"] != null)
                {
                    model.multiAreaTemperature = row["multiAreaTemperature"].ToString();
                }
                if (row["temporary"] != null)
                {
                    model.temporary = row["temporary"].ToString();
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {

            StringBuilder strSql = new StringBuilder();
            //strSql.Append("select deviceid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdname,ysdindex,devicename,iskeypoint,isroundpoint,isopen,distance,fuhe,offsethuman,offsetvalue,ysdtype,ysdlevel,isok,isalarm,yestodaytop,todaytop,weektop,monthtop,historytop,image_red,image_high,image_mix,createtime,templist,fuhelist,orderindex,todaymaxid,yestodaymaxid,weekmaxid,monthmaxid,historymaxid,todaymax,monthmax,mediaindex ");
            strSql.Append("select * ");
            strSql.Append("from device_infor ");

            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.device_infor GetModelByYsdid(string ysdid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select deviceid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdname,ysdindex,devicename,iskeypoint,isroundpoint,isopen,distance,fuhe,offsethuman,offsetvalue,ysdtype,ysdlevel,isok,isalarm,yestodaytop,todaytop,weektop,monthtop,historytop,image_red,image_high,image_mix,createtime,templist,fuhelist,orderindex,todaymaxid,yestodaymaxid,weekmaxid,monthmaxid,historymaxid,todaymax,monthmax,mediaindex,operaterNumber,ppmax,ppmin,ppavg,ppcnt,pptime,patrolStatus,multiArea,multiAreaTemperature,temporary  from device_infor ");
            strSql.Append(" where ysdindex=@ysdid");
            MySqlParameter[] parameters = {
					new MySqlParameter("@ysdid", MySqlDbType.VarChar,255),
            };
            parameters[0].Value = ysdid;

            Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }

        public Maticsoft.Model.device_infor GetModelByMachine(string machineid, string ysdname)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select deviceid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdname,ysdindex,devicename,iskeypoint,isroundpoint,isopen,distance,fuhe,offsethuman,offsetvalue,ysdtype,ysdlevel,isok,isalarm,yestodaytop,todaytop,weektop,monthtop,historytop,image_red,image_high,image_mix,createtime,templist,fuhelist,orderindex,todaymaxid,yestodaymaxid,weekmaxid,monthmaxid,historymaxid,todaymax,monthmax,mediaindex,operaterNumber,ppmax,ppmin,ppavg,ppcnt,pptime,patrolStatus,multiArea,multiAreaTemperature,temporary  from device_infor ");
            strSql.Append(" where machineid=@machineid and ysdname=@ysdname ");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdname", MySqlDbType.VarChar,255)};
            parameters[0].Value = machineid;
            parameters[1].Value = ysdname;

            Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }

        public Maticsoft.Model.device_infor GetModelByName(string devicename, string ysdname)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * from device_infor ");
            strSql.Append(" where devicename=@devicename and ysdname=@ysdname ");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdname", MySqlDbType.VarChar,255)};
            parameters[0].Value = devicename;
            parameters[1].Value = ysdname;

            Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetAlarmTongji(string userpower)
        {
            string isalarm = "1";
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ysdtype as devicename,COUNT(ysdtype) devicecount from device_infor  where  "+userpower+"   GROUP by ysdtype having count(ysdtype)>0  Order by ysdtype  ");//WHERE areaname='"+userpower+"'
            return DbHelperMySQL.Query(strSql.ToString());
        }
        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetDeviceTongji(string userpower)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ysdtype as deviceType,COUNT(ysdtype) devicecount from device_infor  where  " + userpower + "    GROUP by ysdtype having count(ysdtype)>0  Order by ysdtype  ");//WHERE areaname='"+userpower+"'
            return DbHelperMySQL.Query(strSql.ToString());
        }
        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetLevelTongji(string userpower)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ysdlevel as deviceLevel,COUNT(ysdlevel) devicecount from device_infor   where  " + userpower + "   GROUP by ysdlevel having count(ysdlevel)>0  Order by ysdlevel  ");//WHERE areaname='"+userpower+"'
            return DbHelperMySQL.Query(strSql.ToString());
        }
		

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM device_infor ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.deviceid desc");
			}
			strSql.Append(")AS Row, T.*  from device_infor T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperMySQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			MySqlParameter[] parameters = {
					new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
					new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
					new MySqlParameter("@PageSize", MySqlDbType.Int32),
					new MySqlParameter("@PageIndex", MySqlDbType.Int32),
					new MySqlParameter("@IsReCount", MySqlDbType.Bit),
					new MySqlParameter("@OrderType", MySqlDbType.Bit),
					new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
					};
			parameters[0].Value = "device_infor";
			parameters[1].Value = "deviceid";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

