﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
	/// <summary>
	/// 数据访问类:device_patrol_infor
	/// </summary>
	public partial class device_patrol_infor
	{
		public device_patrol_infor()
		{ }
		#region  BasicMethod

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(string patrolid)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("select count(1) from device_patrol_infor");
			strSql.Append(" where patrolid=@patrolid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@patrolid", MySqlDbType.VarChar,50)         };
			parameters[0].Value = patrolid;

			return DbHelperMySQL.Exists(strSql.ToString(), parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(Maticsoft.Model.device_patrol_infor model)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("insert into device_patrol_infor(");
			strSql.Append("patrolid,createtime,inspector,conclusion,exceptionnumber,patrolnumber,stationid,stationname,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname)");
			strSql.Append(" values (");
			strSql.Append("@patrolid,@createtime,@inspector,@conclusion,@exceptionnumber,@patrolnumber,@stationid,@stationname,@areaid,@areaname,@fenbuid,@fenbuname,@ywbid,@ywbname)");
			MySqlParameter[] parameters = {
					new MySqlParameter("@patrolid", MySqlDbType.VarChar,50),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@inspector", MySqlDbType.VarChar,50),
					new MySqlParameter("@conclusion", MySqlDbType.VarChar,50),
					new MySqlParameter("@exceptionnumber", MySqlDbType.Int32,11),
					new MySqlParameter("@patrolnumber", MySqlDbType.Int32,11),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,50),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,50),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,50),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,50)};
			parameters[0].Value = model.patrolid;
			parameters[1].Value = model.createtime;
			parameters[2].Value = model.inspector;
			parameters[3].Value = model.conclusion;
			parameters[4].Value = model.exceptionnumber;
			parameters[5].Value = model.patrolnumber;
			parameters[6].Value = model.stationid;
			parameters[7].Value = model.stationname;
			parameters[8].Value = model.areaid;
			parameters[9].Value = model.areaname;
			parameters[10].Value = model.fenbuid;
			parameters[11].Value = model.fenbuname;
			parameters[12].Value = model.ywbid;
			parameters[13].Value = model.ywbname;

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Maticsoft.Model.device_patrol_infor model)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update device_patrol_infor set ");
			strSql.Append("createtime=@createtime,");
			strSql.Append("inspector=@inspector,");
			strSql.Append("conclusion=@conclusion,");
			strSql.Append("exceptionnumber=@exceptionnumber,");
			strSql.Append("patrolnumber=@patrolnumber,");
			strSql.Append("stationid=@stationid,");
			strSql.Append("stationname=@stationname,");
			strSql.Append("areaid=@areaid,");
			strSql.Append("areaname=@areaname,");
			strSql.Append("fenbuid=@fenbuid,");
			strSql.Append("fenbuname=@fenbuname,");
			strSql.Append("ywbid=@ywbid,");
			strSql.Append("ywbname=@ywbname");
			strSql.Append(" where patrolid=@patrolid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@inspector", MySqlDbType.VarChar,50),
					new MySqlParameter("@conclusion", MySqlDbType.VarChar,50),
					new MySqlParameter("@exceptionnumber", MySqlDbType.Int32,11),
					new MySqlParameter("@patrolnumber", MySqlDbType.Int32,11),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,50),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,50),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,50),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,50),
					new MySqlParameter("@patrolid", MySqlDbType.VarChar,50)};
			parameters[0].Value = model.createtime;
			parameters[1].Value = model.inspector;
			parameters[2].Value = model.conclusion;
			parameters[3].Value = model.exceptionnumber;
			parameters[4].Value = model.patrolnumber;
			parameters[5].Value = model.stationid;
			parameters[6].Value = model.stationname;
			parameters[7].Value = model.areaid;
			parameters[8].Value = model.areaname;
			parameters[9].Value = model.fenbuid;
			parameters[10].Value = model.fenbuname;
			parameters[11].Value = model.ywbid;
			parameters[12].Value = model.ywbname;
			parameters[13].Value = model.patrolid;

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(string patrolid)
		{

			StringBuilder strSql = new StringBuilder();
			strSql.Append("delete from device_patrol_infor ");
			strSql.Append(" where patrolid=@patrolid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@patrolid", MySqlDbType.VarChar,50)         };
			parameters[0].Value = patrolid;

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string patrolidlist)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("delete from device_patrol_infor ");
			strSql.Append(" where patrolid in (" + patrolidlist + ")  ");
			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.device_patrol_infor GetModel(string patrolid)
		{

			StringBuilder strSql = new StringBuilder();
			strSql.Append("select patrolid,createtime,inspector,conclusion,exceptionnumber,patrolnumber,stationid,stationname,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname from device_patrol_infor ");
			strSql.Append(" where patrolid=@patrolid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@patrolid", MySqlDbType.VarChar,50)         };
			parameters[0].Value = patrolid;

			Maticsoft.Model.device_patrol_infor model = new Maticsoft.Model.device_patrol_infor();
			DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
			if (ds.Tables[0].Rows.Count > 0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.device_patrol_infor DataRowToModel(DataRow row)
		{
			Maticsoft.Model.device_patrol_infor model = new Maticsoft.Model.device_patrol_infor();
			if (row != null)
			{
				if (row["patrolid"] != null)
				{
					model.patrolid = row["patrolid"].ToString();
				}
				if (row["createtime"] != null && row["createtime"].ToString() != "")
				{
					model.createtime = DateTime.Parse(row["createtime"].ToString());
				}
				if (row["inspector"] != null)
				{
					model.inspector = row["inspector"].ToString();
				}
				if (row["conclusion"] != null)
				{
					model.conclusion = row["conclusion"].ToString();
				}
				if (row["exceptionnumber"] != null && row["exceptionnumber"].ToString() != "")
				{
					model.exceptionnumber = int.Parse(row["exceptionnumber"].ToString());
				}
				if (row["patrolnumber"] != null && row["patrolnumber"].ToString() != "")
				{
					model.patrolnumber = int.Parse(row["patrolnumber"].ToString());
				}
				if (row["stationid"] != null)
				{
					model.stationid = row["stationid"].ToString();
				}
				if (row["stationname"] != null)
				{
					model.stationname = row["stationname"].ToString();
				}
				if (row["areaid"] != null)
				{
					model.areaid = row["areaid"].ToString();
				}
				if (row["areaname"] != null)
				{
					model.areaname = row["areaname"].ToString();
				}
				if (row["fenbuid"] != null)
				{
					model.fenbuid = row["fenbuid"].ToString();
				}
				if (row["fenbuname"] != null)
				{
					model.fenbuname = row["fenbuname"].ToString();
				}
				if (row["ywbid"] != null)
				{
					model.ywbid = row["ywbid"].ToString();
				}
				if (row["ywbname"] != null)
				{
					model.ywbname = row["ywbname"].ToString();
				}
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("select patrolid,createtime,inspector,conclusion,exceptionnumber,patrolnumber,stationid,stationname,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname ");
			strSql.Append(" FROM device_patrol_infor ");
			if (strWhere.Trim() != "")
			{
				strSql.Append(" where " + strWhere);
			}
			return DbHelperMySQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("select count(1) FROM device_patrol_infor ");
			if (strWhere.Trim() != "")
			{
				strSql.Append(" where " + strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby);
			}
			else
			{
				strSql.Append("order by T.patrolid desc");
			}
			strSql.Append(")AS Row, T.*  from device_patrol_infor T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperMySQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			MySqlParameter[] parameters = {
					new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
					new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
					new MySqlParameter("@PageSize", MySqlDbType.Int32),
					new MySqlParameter("@PageIndex", MySqlDbType.Int32),
					new MySqlParameter("@IsReCount", MySqlDbType.Bit),
					new MySqlParameter("@OrderType", MySqlDbType.Bit),
					new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
					};
			parameters[0].Value = "device_patrol_infor";
			parameters[1].Value = "patrolid";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

