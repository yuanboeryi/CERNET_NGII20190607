﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:device_rect_infor
    /// </summary>
    public partial class device_rect_infor
    {
        public device_rect_infor()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string rectid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from device_rect_infor");
            strSql.Append(" where rectid=@rectid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@rectid", MySqlDbType.VarChar,50)			};
            parameters[0].Value = rectid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.device_rect_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into device_rect_infor(");
            strSql.Append("rectid,deviceid,devicename,rectindex,rectname,pointlist,createtime,width,height)");
            strSql.Append(" values (");
            strSql.Append("@rectid,@deviceid,@devicename,@rectindex,@rectname,@pointlist,@createtime,@width,@height)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@rectid", MySqlDbType.VarChar,50),
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,50),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,50),
					new MySqlParameter("@rectindex", MySqlDbType.Int32,10),
					new MySqlParameter("@rectname", MySqlDbType.VarChar,50),
					new MySqlParameter("@pointlist", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
                    new MySqlParameter("@width", MySqlDbType.Int32, 10),
                    new MySqlParameter("@height", MySqlDbType.Int32, 10)
            };

            parameters[0].Value = model.rectid;
            parameters[1].Value = model.deviceid;
            parameters[2].Value = model.devicename;
            parameters[3].Value = model.rectindex;
            parameters[4].Value = model.rectname;
            parameters[5].Value = model.pointlist;
            parameters[6].Value = model.createtime;
            parameters[7].Value = model.width;
            parameters[8].Value = model.height;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);

            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.device_rect_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update device_rect_infor set ");
            strSql.Append("deviceid=@deviceid,");
            strSql.Append("devicename=@devicename,");
            strSql.Append("rectindex=@rectindex,");
            strSql.Append("rectname=@rectname,");
            strSql.Append("pointlist=@pointlist,");
            strSql.Append("createtime=@createtime,");
            strSql.Append("width=@width,");
            strSql.Append("height=@height");
            strSql.Append(" where rectid=@rectid ");

            MySqlParameter[] parameters = {
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,50),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,50),
					new MySqlParameter("@rectindex", MySqlDbType.Int32,10),
					new MySqlParameter("@rectname", MySqlDbType.VarChar,50),
					new MySqlParameter("@pointlist", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@rectid", MySqlDbType.VarChar,50),
                    new MySqlParameter("@width", MySqlDbType.Int32, 10),
                    new MySqlParameter("@height", MySqlDbType.Int32, 10)
            };

            parameters[0].Value = model.deviceid;
            parameters[1].Value = model.devicename;
            parameters[2].Value = model.rectindex;
            parameters[3].Value = model.rectname;
            parameters[4].Value = model.pointlist;
            parameters[5].Value = model.createtime;
            parameters[6].Value = model.rectid;
            parameters[7].Value = model.width;
            parameters[8].Value = model.height;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);

            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string rectid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from device_rect_infor ");
            strSql.Append(" where rectid=@rectid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@rectid", MySqlDbType.VarChar,50)			};
            parameters[0].Value = rectid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string rectidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from device_rect_infor ");
            strSql.Append(" where rectid in (" + rectidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteByPointlist(string deviceId, string rectindex, string pointlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from device_rect_infor ");
            strSql.Append("where deviceid=@deviceid and rectindex=@rectindex and pointlist=@pointlist");

            MySqlParameter[] parameters = {
                    new MySqlParameter("@deviceid",  MySqlDbType.VarChar,50),
                    new MySqlParameter("@rectindex", MySqlDbType.VarChar,50),
                    new MySqlParameter("@pointlist", MySqlDbType.VarChar,20000)
            };

            parameters[0].Value = deviceId;
            parameters[1].Value = rectindex;
            parameters[2].Value = pointlist;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteByIndex(string deviceId, string rectindex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from device_rect_infor ");
            strSql.Append(" where deviceid=@deviceid and rectindex=@rectindex");

            MySqlParameter[] parameters = {
                    new MySqlParameter("@deviceid",  MySqlDbType.VarChar,50),
                    new MySqlParameter("@rectindex", MySqlDbType.VarChar,50)
            };

            parameters[0].Value = deviceId;
            parameters[1].Value = rectindex;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);

            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.device_rect_infor GetModel(string rectid)
        {

            StringBuilder strSql = new StringBuilder();
            // strSql.Append("select rectid,deviceid,devicename,rectindex,rectname,pointlist,createtime from device_rect_infor ");
            
            strSql.Append("select * from device_rect_infor ");
            strSql.Append(" where rectid=@rectid ");

            MySqlParameter[] parameters = {
					new MySqlParameter("@rectid", MySqlDbType.VarChar,50)		
            };

            parameters[0].Value = rectid;

            Maticsoft.Model.device_rect_infor model = new Maticsoft.Model.device_rect_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.device_rect_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.device_rect_infor model = new Maticsoft.Model.device_rect_infor();
            if (row != null)
            {
                if (row["rectid"] != null)
                {
                    model.rectid = row["rectid"].ToString();
                }
                if (row["deviceid"] != null)
                {
                    model.deviceid = row["deviceid"].ToString();
                }
                if (row["devicename"] != null)
                {
                    model.devicename = row["devicename"].ToString();
                }
                if (row["rectindex"] != null && row["rectindex"].ToString() != "")
                {
                    model.rectindex = int.Parse(row["rectindex"].ToString());
                }
                if (row["rectname"] != null)
                {
                    model.rectname = row["rectname"].ToString();
                }
                if (row["pointlist"] != null)
                {
                    model.pointlist = row["pointlist"].ToString();
                }
                if (row["createtime"] != null && row["createtime"].ToString() != "")
                {
                    model.createtime = DateTime.Parse(row["createtime"].ToString());
                }
                if (row["width"] != null && row["width"].ToString() != "")
                {
                    model.width = int.Parse(row["width"].ToString());
                }
                if (row["height"] != null && row["height"].ToString() != "")
                {
                    model.height = int.Parse(row["height"].ToString());
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            //  strSql.Append("select rectid,deviceid,devicename,rectindex,rectname,pointlist,createtime ");
            //strSql.Append(" FROM device_rect_infor ");

            strSql.Append("select * from device_rect_infor ");

            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM device_rect_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.rectid desc");
            }
            strSql.Append(")AS Row, T.*  from device_rect_infor T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "device_rect_infor";
            parameters[1].Value = "rectid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

