﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:image_record_history
    /// </summary>
    public partial class image_record_history
    {
        public image_record_history()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string recordid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from image_record_history");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = recordid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }

        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.image_record_history model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into image_record_history(");
            strSql.Append("recordid,deviceid,devicename,machinemac,deviceindex,image0,image1,image2,valuemax,valuemin,valueave,templist_24,isalarm,createtime,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname)");
            strSql.Append(" values (");
            strSql.Append("@recordid,@deviceid,@devicename,@machinemac,@deviceindex,@image0,@image1,@image2,@valuemax,@valuemin,@valueave,@templist_24,@isalarm,@createtime,@areaid,@areaname,@fenbuid,@fenbuname,@ywbid,@ywbname)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,50),
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,50),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,50),
					new MySqlParameter("@machinemac", MySqlDbType.VarChar,50),
					new MySqlParameter("@deviceindex", MySqlDbType.VarChar,50),
					new MySqlParameter("@image0", MySqlDbType.VarChar,255),
					new MySqlParameter("@image1", MySqlDbType.VarChar,255),
					new MySqlParameter("@image2", MySqlDbType.VarChar,255),
					new MySqlParameter("@valuemax", MySqlDbType.VarChar,10),
					new MySqlParameter("@valuemin", MySqlDbType.VarChar,10),
					new MySqlParameter("@valueave", MySqlDbType.VarChar,10),
					new MySqlParameter("@templist_24", MySqlDbType.VarChar,255),
					new MySqlParameter("@isalarm", MySqlDbType.VarChar,10),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,50),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,50)};
            parameters[0].Value = model.recordid;
            parameters[1].Value = model.deviceid;
            parameters[2].Value = model.devicename;
            parameters[3].Value = model.machinemac;
            parameters[4].Value = model.deviceindex;
            parameters[5].Value = model.image0;
            parameters[6].Value = model.image1;
            parameters[7].Value = model.image2;
            parameters[8].Value = model.valuemax;
            parameters[9].Value = model.valuemin;
            parameters[10].Value = model.valueave;
            parameters[11].Value = model.templist_24;
            parameters[12].Value = model.isalarm;
            parameters[13].Value = model.createtime;
            parameters[14].Value = model.areaid;
            parameters[15].Value = model.areaname;
            parameters[16].Value = model.fenbuid;
            parameters[17].Value = model.fenbuname;
            parameters[18].Value = model.ywbid;
            parameters[19].Value = model.ywbname;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.image_record_history model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update image_record_history set ");
            strSql.Append("deviceid=@deviceid,");
            strSql.Append("devicename=@devicename,");
            strSql.Append("machinemac=@machinemac,");
            strSql.Append("deviceindex=@deviceindex,");
            strSql.Append("image0=@image0,");
            strSql.Append("image1=@image1,");
            strSql.Append("image2=@image2,");
            strSql.Append("valuemax=@valuemax,");
            strSql.Append("valuemin=@valuemin,");
            strSql.Append("valueave=@valueave,");
            strSql.Append("templist_24=@templist_24,");
            strSql.Append("isalarm=@isalarm,");
            strSql.Append("createtime=@createtime,");
            strSql.Append("areaid=@areaid,");
            strSql.Append("areaname=@areaname,");
            strSql.Append("fenbuid=@fenbuid,");
            strSql.Append("fenbuname=@fenbuname,");
            strSql.Append("ywbid=@ywbid,");
            strSql.Append("ywbname=@ywbname");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,50),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,50),
					new MySqlParameter("@machinemac", MySqlDbType.VarChar,50),
					new MySqlParameter("@deviceindex", MySqlDbType.VarChar,50),
					new MySqlParameter("@image0", MySqlDbType.VarChar,255),
					new MySqlParameter("@image1", MySqlDbType.VarChar,255),
					new MySqlParameter("@image2", MySqlDbType.VarChar,255),
					new MySqlParameter("@valuemax", MySqlDbType.VarChar,10),
					new MySqlParameter("@valuemin", MySqlDbType.VarChar,10),
					new MySqlParameter("@valueave", MySqlDbType.VarChar,10),
					new MySqlParameter("@templist_24", MySqlDbType.VarChar,255),
					new MySqlParameter("@isalarm", MySqlDbType.VarChar,10),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,50),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,50),
					new MySqlParameter("@recordid", MySqlDbType.VarChar,50)};
            parameters[0].Value = model.deviceid;
            parameters[1].Value = model.devicename;
            parameters[2].Value = model.machinemac;
            parameters[3].Value = model.deviceindex;
            parameters[4].Value = model.image0;
            parameters[5].Value = model.image1;
            parameters[6].Value = model.image2;
            parameters[7].Value = model.valuemax;
            parameters[8].Value = model.valuemin;
            parameters[9].Value = model.valueave;
            parameters[10].Value = model.templist_24;
            parameters[11].Value = model.isalarm;
            parameters[12].Value = model.createtime;
            parameters[13].Value = model.areaid;
            parameters[14].Value = model.areaname;
            parameters[15].Value = model.fenbuid;
            parameters[16].Value = model.fenbuname;
            parameters[17].Value = model.ywbid;
            parameters[18].Value = model.ywbname;
            parameters[19].Value = model.recordid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string recordid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from image_record_history ");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = recordid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string recordidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from image_record_history ");
            strSql.Append(" where recordid in (" + recordidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.image_record_history GetModel(string recordid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select recordid,deviceid,devicename,machinemac,deviceindex,image0,image1,image2,valuemax,valuemin,valueave,templist_24,isalarm,createtime,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname from image_record_history ");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = recordid;

            Maticsoft.Model.image_record_history model = new Maticsoft.Model.image_record_history();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.image_record_history DataRowToModel(DataRow row)
        {
            Maticsoft.Model.image_record_history model = new Maticsoft.Model.image_record_history();
            if (row != null)
            {
                if (row["recordid"] != null)
                {
                    model.recordid = row["recordid"].ToString();
                }
                if (row["deviceid"] != null)
                {
                    model.deviceid = row["deviceid"].ToString();
                }
                if (row["devicename"] != null)
                {
                    model.devicename = row["devicename"].ToString();
                }
                if (row["machinemac"] != null)
                {
                    model.machinemac = row["machinemac"].ToString();
                }
                if (row["deviceindex"] != null)
                {
                    model.deviceindex = row["deviceindex"].ToString();
                }
                if (row["image0"] != null)
                {
                    model.image0 = row["image0"].ToString();
                }
                if (row["image1"] != null)
                {
                    model.image1 = row["image1"].ToString();
                }
                if (row["image2"] != null)
                {
                    model.image2 = row["image2"].ToString();
                }
                if (row["valuemax"] != null)
                {
                    model.valuemax = row["valuemax"].ToString();
                }
                if (row["valuemin"] != null)
                {
                    model.valuemin = row["valuemin"].ToString();
                }
                if (row["valueave"] != null)
                {
                    model.valueave = row["valueave"].ToString();
                }
                if (row["templist_24"] != null)
                {
                    model.templist_24 = row["templist_24"].ToString();
                }
                if (row["isalarm"] != null)
                {
                    model.isalarm = row["isalarm"].ToString();
                }
                if (row["createtime"] != null && row["createtime"].ToString() != "")
                {
                    model.createtime = DateTime.Parse(row["createtime"].ToString());
                }
                if (row["areaid"] != null)
                {
                    model.areaid = row["areaid"].ToString();
                }
                if (row["areaname"] != null)
                {
                    model.areaname = row["areaname"].ToString();
                }
                if (row["fenbuid"] != null)
                {
                    model.fenbuid = row["fenbuid"].ToString();
                }
                if (row["fenbuname"] != null)
                {
                    model.fenbuname = row["fenbuname"].ToString();
                }
                if (row["ywbid"] != null)
                {
                    model.ywbid = row["ywbid"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select recordid,deviceid,devicename,machinemac,deviceindex,image0,image1,image2,valuemax,valuemin,valueave,templist_24,isalarm,createtime,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname ");
            strSql.Append(" FROM image_record_history ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }
        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetListValuemax(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select recordid,deviceid,devicename,valuemax,createtime ");
            strSql.Append(" FROM image_record_history ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }
        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM image_record_history ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.recordid desc");
            }
            strSql.Append(")AS Row, T.*  from image_record_history T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "image_record_history";
            parameters[1].Value = "recordid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/
        /// <summary>
        /// 获取最大valuemax值
        /// </summary>
        public string GetMaxValuemax(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select max(valuemax) FROM image_record_history ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperMySQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return "";
            }
            else
            {
                return obj.ToString();
            }
        }
        /// <summary>
        /// 获取时间最大值
        /// </summary>
        public string GetMaxCreatetime(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select max(createtime) FROM image_record_history ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperMySQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return "";
            }
            else
            {
                return obj.ToString();
            }
        }
        #endregion  BasicMethod
        #region  查询历史表数据
        public DataSet HisGetModelList(string tablename,string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select recordid,deviceid,devicename,machinemac,deviceindex,image0,image1,image2,valuemax,valuemin,valueave,templist_24,isalarm,createtime,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname ");
            strSql.Append(" FROM image_record_history"+tablename+" ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());

        }

        public bool HisDelete(string tablename, string recordid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from image_record_history"+tablename + " ");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@recordid", MySqlDbType.VarChar,255)            };
            parameters[0].Value = recordid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool HisDeleteList(string tablename, string recordidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from image_record_history" + tablename + " ");
            strSql.Append(" where recordid in (" + recordidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion  查询历史表数据
    }
}

