﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
	/// <summary>
	/// 数据访问类:machine_infor
	/// </summary>
	public partial class machine_infor
	{
		public machine_infor()
		{}
		#region  BasicMethod

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(string machineid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from machine_infor");
			strSql.Append(" where machineid=@machineid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255)			};
			parameters[0].Value = machineid;

			return DbHelperMySQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(Maticsoft.Model.machine_infor model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into machine_infor(");
			strSql.Append("machineid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machinename,machinecompany,machinemac,machinecode,installcode,currentversion,newversion,machinestate,ysdcount,onlinetime,runtime,imagecatchspan,wifiname,wifipass,fushelv,offsetvalue,buchang,topvalue,createtime)");
			strSql.Append(" values (");
			strSql.Append("@machineid,@areaid,@areaname,@fenbuid,@fenbuname,@ywbid,@ywbname,@stationid,@stationname,@buildingid,@buildingname,@machinename,@machinecompany,@machinemac,@machinecode,@installcode,@currentversion,@newversion,@machinestate,@ysdcount,@onlinetime,@runtime,@imagecatchspan,@wifiname,@wifipass,@fushelv,@offsetvalue,@buchang,@topvalue,@createtime)");
			MySqlParameter[] parameters = {
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinecompany", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinemac", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinecode", MySqlDbType.VarChar,255),
					new MySqlParameter("@installcode", MySqlDbType.VarChar,50),
					new MySqlParameter("@currentversion", MySqlDbType.VarChar,255),
					new MySqlParameter("@newversion", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinestate", MySqlDbType.VarChar,255),
					new MySqlParameter("@ysdcount", MySqlDbType.VarChar,255),
					new MySqlParameter("@onlinetime", MySqlDbType.DateTime),
					new MySqlParameter("@runtime", MySqlDbType.VarChar,255),
					new MySqlParameter("@imagecatchspan", MySqlDbType.VarChar,255),
					new MySqlParameter("@wifiname", MySqlDbType.VarChar,255),
					new MySqlParameter("@wifipass", MySqlDbType.VarChar,255),
					new MySqlParameter("@fushelv", MySqlDbType.VarChar,255),
					new MySqlParameter("@offsetvalue", MySqlDbType.VarChar,255),
					new MySqlParameter("@buchang", MySqlDbType.VarChar,255),
					new MySqlParameter("@topvalue", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime)};
			parameters[0].Value = model.machineid;
			parameters[1].Value = model.areaid;
			parameters[2].Value = model.areaname;
			parameters[3].Value = model.fenbuid;
			parameters[4].Value = model.fenbuname;
			parameters[5].Value = model.ywbid;
			parameters[6].Value = model.ywbname;
			parameters[7].Value = model.stationid;
			parameters[8].Value = model.stationname;
			parameters[9].Value = model.buildingid;
			parameters[10].Value = model.buildingname;
			parameters[11].Value = model.machinename;
			parameters[12].Value = model.machinecompany;
			parameters[13].Value = model.machinemac;
			parameters[14].Value = model.machinecode;
			parameters[15].Value = model.installcode;
			parameters[16].Value = model.currentversion;
			parameters[17].Value = model.newversion;
			parameters[18].Value = model.machinestate;
			parameters[19].Value = model.ysdcount;
			parameters[20].Value = model.onlinetime;
			parameters[21].Value = model.runtime;
			parameters[22].Value = model.imagecatchspan;
			parameters[23].Value = model.wifiname;
			parameters[24].Value = model.wifipass;
			parameters[25].Value = model.fushelv;
			parameters[26].Value = model.offsetvalue;
			parameters[27].Value = model.buchang;
			parameters[28].Value = model.topvalue;
			parameters[29].Value = model.createtime;

			int rows=DbHelperMySQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateBuilding1(string id, string name, string idnew)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update machine_infor set ");
            strSql.Append("buildingname='" + name + "',buildingid='" + idnew + "'");
            strSql.Append(" where buildingid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());



            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Updatetime(string id, string time)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update machine_infor set ");
            strSql.Append("createtime='" + time + "'");
            strSql.Append(" where machineid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());



            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateBuilding(string id, string name, string idnew,string machineid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update machine_infor set ");
            strSql.Append("buildingname='" + name + "',buildingid='" + idnew + "'");
            strSql.Append(" where machineid='" + machineid + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());



            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Maticsoft.Model.machine_infor model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update machine_infor set ");
			strSql.Append("areaid=@areaid,");
			strSql.Append("areaname=@areaname,");
			strSql.Append("fenbuid=@fenbuid,");
			strSql.Append("fenbuname=@fenbuname,");
			strSql.Append("ywbid=@ywbid,");
			strSql.Append("ywbname=@ywbname,");
			strSql.Append("stationid=@stationid,");
			strSql.Append("stationname=@stationname,");
			strSql.Append("buildingid=@buildingid,");
			strSql.Append("buildingname=@buildingname,");
			strSql.Append("machinename=@machinename,");
			strSql.Append("machinecompany=@machinecompany,");
			strSql.Append("machinemac=@machinemac,");
			strSql.Append("machinecode=@machinecode,");
			strSql.Append("installcode=@installcode,");
			strSql.Append("currentversion=@currentversion,");
			strSql.Append("newversion=@newversion,");
			strSql.Append("machinestate=@machinestate,");
			strSql.Append("ysdcount=@ysdcount,");
			strSql.Append("onlinetime=@onlinetime,");
			strSql.Append("runtime=@runtime,");
			strSql.Append("imagecatchspan=@imagecatchspan,");
			strSql.Append("wifiname=@wifiname,");
			strSql.Append("wifipass=@wifipass,");
			strSql.Append("fushelv=@fushelv,");
			strSql.Append("offsetvalue=@offsetvalue,");
			strSql.Append("buchang=@buchang,");
			strSql.Append("topvalue=@topvalue,");
			strSql.Append("createtime=@createtime");
			strSql.Append(" where machineid=@machineid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinecompany", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinemac", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinecode", MySqlDbType.VarChar,255),
					new MySqlParameter("@installcode", MySqlDbType.VarChar,50),
					new MySqlParameter("@currentversion", MySqlDbType.VarChar,255),
					new MySqlParameter("@newversion", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinestate", MySqlDbType.VarChar,255),
					new MySqlParameter("@ysdcount", MySqlDbType.VarChar,255),
					new MySqlParameter("@onlinetime", MySqlDbType.DateTime),
					new MySqlParameter("@runtime", MySqlDbType.VarChar,255),
					new MySqlParameter("@imagecatchspan", MySqlDbType.VarChar,255),
					new MySqlParameter("@wifiname", MySqlDbType.VarChar,255),
					new MySqlParameter("@wifipass", MySqlDbType.VarChar,255),
					new MySqlParameter("@fushelv", MySqlDbType.VarChar,255),
					new MySqlParameter("@offsetvalue", MySqlDbType.VarChar,255),
					new MySqlParameter("@buchang", MySqlDbType.VarChar,255),
					new MySqlParameter("@topvalue", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255)};
			parameters[0].Value = model.areaid;
			parameters[1].Value = model.areaname;
			parameters[2].Value = model.fenbuid;
			parameters[3].Value = model.fenbuname;
			parameters[4].Value = model.ywbid;
			parameters[5].Value = model.ywbname;
			parameters[6].Value = model.stationid;
			parameters[7].Value = model.stationname;
			parameters[8].Value = model.buildingid;
			parameters[9].Value = model.buildingname;
			parameters[10].Value = model.machinename;
			parameters[11].Value = model.machinecompany;
			parameters[12].Value = model.machinemac;
			parameters[13].Value = model.machinecode;
			parameters[14].Value = model.installcode;
			parameters[15].Value = model.currentversion;
			parameters[16].Value = model.newversion;
			parameters[17].Value = model.machinestate;
			parameters[18].Value = model.ysdcount;
			parameters[19].Value = model.onlinetime;
			parameters[20].Value = model.runtime;
			parameters[21].Value = model.imagecatchspan;
			parameters[22].Value = model.wifiname;
			parameters[23].Value = model.wifipass;
			parameters[24].Value = model.fushelv;
			parameters[25].Value = model.offsetvalue;
			parameters[26].Value = model.buchang;
			parameters[27].Value = model.topvalue;
			parameters[28].Value = model.createtime;
			parameters[29].Value = model.machineid;

			int rows=DbHelperMySQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateMachineState(string id, string state, string isonline,string runtime)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update machine_infor set ");
            strSql.Append("machinestate='" + state + "',");
            strSql.Append("isonline='" + isonline + "',runtime='"+runtime+"'");
            strSql.Append(" where machineid='" + id + "' ");


            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateMachineMac(string id, string mac, string code)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update machine_infor set ");
            strSql.Append("machinemac='" + mac + "',");
            strSql.Append("machinecode='" + code + "'");
            strSql.Append(" where machineid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateWifi(string mac, string ssid, string password)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update machine_infor set ");
			strSql.Append("wifiname='" + ssid + "',");
			strSql.Append("wifipass='" + password + "'");
			strSql.Append(" where machinemac='" + mac + "' ");

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateInterval(string mac, string capinterv, string insinterv)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update machine_infor set ");
			strSql.Append("capinterv='" + capinterv + "',");
			strSql.Append("insinterv='" + insinterv + "'");
			strSql.Append(" where machinemac='" + mac + "' ");

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateFusion(string mac, string fusion)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update machine_infor set ");
			strSql.Append("fushelv='" + fusion + "'");
			strSql.Append(" where machinemac='" + mac + "' ");

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public bool UpdateRonghe(string mac, string rong_S, string rong_R, string rong_L, string rong_T)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update machine_infor set ");
			strSql.Append("sv='" + rong_S + "',");
			strSql.Append("rv='" + rong_R + "',");
			strSql.Append("lv='" + rong_L + "',");
			strSql.Append("tv='" + rong_T + "'");
			strSql.Append(" where machinemac='" + mac + "' ");

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


			/// <summary>
			/// 更新一条数据
			/// </summary>
			public bool UpdateCode(string mac, string code)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update machine_infor set ");
			strSql.Append("machinecode='" + code + "'");
			strSql.Append(" where machinemac='" + mac + "' ");

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateCloudAddress(string mac, string address)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update machine_infor set ");
			strSql.Append("cloudaddr='" + address + "'");
			strSql.Append(" where machinemac='" + mac + "' ");

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateSpan(string id,string time1,string time2)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update machine_infor set ");
            strSql.Append("newversion='"+time2+"',");
            strSql.Append("imagecatchspan='"+time1+"'");
            strSql.Append(" where machineid='"+id+"' ");
           

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

		public bool ModifyYsdCount(string machineid, int number)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("select ysdcount from machine_infor where machineid=@machineid");

			MySqlParameter[] parameters = {
					new MySqlParameter("@machineid", MySqlDbType.VarChar,50)
			};
			parameters[0].Value = machineid;

			DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);

			int ysdCount = 0;

			if (ds.Tables[0].Rows.Count > 0)
			{
				ysdCount = Convert.ToInt32(ds.Tables[0].Rows[0]["ysdcount"].ToString());
			}

			ysdCount += number;

			if (ysdCount > 0)
			{
				return UpdateYsdCount(machineid, Convert.ToString(ysdCount));
			}
			else
			{
				return false;
			}

		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool UpdateYsdCount(string id, string count)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update machine_infor set ");
            strSql.Append("ysdcount='" + count + "'");
            strSql.Append(" where machineid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(string machineid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from machine_infor ");
			strSql.Append(" where machineid=@machineid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255)			};
			parameters[0].Value = machineid;

			int rows=DbHelperMySQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string machineidlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from machine_infor ");
			strSql.Append(" where machineid in ("+machineidlist + ")  ");
			int rows=DbHelperMySQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.machine_infor GetModel(string machineid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select * from machine_infor ");
			strSql.Append(" where machineid=@machineid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255)			};
			parameters[0].Value = machineid;

			Maticsoft.Model.machine_infor model=new Maticsoft.Model.machine_infor();
			DataSet ds=DbHelperMySQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.machine_infor GetModelBymac(string machinemac)
        {

            StringBuilder strSql = new StringBuilder();
            //strSql.Append("select machineid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machinename,machinecompany,machinemac,machinecode,installcode,currentversion,newversion,machinestate,ysdcount,onlinetime,runtime,imagecatchspan,wifiname,wifipass,fushelv,offsetvalue,buchang,topvalue,createtime from machine_infor ");
            strSql.Append("select * from machine_infor ");
            strSql.Append(" where machinemac=@machinemac ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@machinemac", MySqlDbType.VarChar,255)			};
            parameters[0].Value = machinemac;

            Maticsoft.Model.machine_infor model = new Maticsoft.Model.machine_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.machine_infor DataRowToModel(DataRow row)
		{
			Maticsoft.Model.machine_infor model=new Maticsoft.Model.machine_infor();
			if (row != null)
			{
				if(row["machineid"]!=null)
				{
					model.machineid=row["machineid"].ToString();
				}
				if(row["areaid"]!=null)
				{
					model.areaid=row["areaid"].ToString();
				}
				if(row["areaname"]!=null)
				{
					model.areaname=row["areaname"].ToString();
				}
				if(row["fenbuid"]!=null)
				{
					model.fenbuid=row["fenbuid"].ToString();
				}
				if(row["fenbuname"]!=null)
				{
					model.fenbuname=row["fenbuname"].ToString();
				}
				if(row["ywbid"]!=null)
				{
					model.ywbid=row["ywbid"].ToString();
				}
				if(row["ywbname"]!=null)
				{
					model.ywbname=row["ywbname"].ToString();
				}
				if(row["stationid"]!=null)
				{
					model.stationid=row["stationid"].ToString();
				}
				if(row["stationname"]!=null)
				{
					model.stationname=row["stationname"].ToString();
				}
				if(row["buildingid"]!=null)
				{
					model.buildingid=row["buildingid"].ToString();
				}
				if(row["buildingname"]!=null)
				{
					model.buildingname=row["buildingname"].ToString();
				}
				if(row["machinename"]!=null)
				{
					model.machinename=row["machinename"].ToString();
				}
				if(row["machinecompany"]!=null)
				{
					model.machinecompany=row["machinecompany"].ToString();
				}
				if(row["machinemac"]!=null)
				{
					model.machinemac=row["machinemac"].ToString();
				}
				if(row["machinecode"]!=null)
				{
					model.machinecode=row["machinecode"].ToString();
				}
				if(row["installcode"]!=null)
				{
					model.installcode=row["installcode"].ToString();
				}
				if(row["currentversion"]!=null)
				{
					model.currentversion=row["currentversion"].ToString();
				}
				if(row["newversion"]!=null)
				{
					model.newversion=row["newversion"].ToString();
				}
				if(row["machinestate"]!=null)
				{
					model.machinestate=row["machinestate"].ToString();
				}
				if(row["ysdcount"]!=null)
				{
					model.ysdcount=row["ysdcount"].ToString();
				}
				if(row["onlinetime"]!=null && row["onlinetime"].ToString()!="")
				{
					model.onlinetime=DateTime.Parse(row["onlinetime"].ToString());
				}
				if(row["runtime"]!=null)
				{
					model.runtime=row["runtime"].ToString();
				}
				if(row["imagecatchspan"]!=null)
				{
					model.imagecatchspan=row["imagecatchspan"].ToString();
				}
				if(row["wifiname"]!=null)
				{
					model.wifiname=row["wifiname"].ToString();
				}
				if(row["wifipass"]!=null)
				{
					model.wifipass=row["wifipass"].ToString();
				}
				if(row["fushelv"]!=null)
				{
					model.fushelv=row["fushelv"].ToString();
				}
				if(row["offsetvalue"]!=null)
				{
					model.offsetvalue=row["offsetvalue"].ToString();
				}
				if(row["buchang"]!=null)
				{
					model.buchang=row["buchang"].ToString();
				}
				if(row["topvalue"]!=null)
				{
					model.topvalue=row["topvalue"].ToString();
				}
				if(row["createtime"]!=null && row["createtime"].ToString()!="")
				{
					model.createtime=DateTime.Parse(row["createtime"].ToString());
				}
				
				if(row["cloudaddr"]!=null)
                {
					model.Cloudaddr = row["cloudaddr"].ToString();
                }

				if (row["ftpaddr"] != null)
				{
					model.Ftpaddr = row["ftpaddr"].ToString();
				}

				if (row["warntemp"] != null)
				{
					model.Warntemp = row["warntemp"].ToString();
				}

				if (row["capinterv"] != null)
				{
					model.Capinterv = row["capinterv"].ToString();
				}
				if (row["insinterv"] != null)
				{
					model.Insinterv = row["insinterv"].ToString();
				}
				if (row["sv"] != null)
				{
					model.Sv = row["sv"].ToString();
				}
				if (row["rv"] != null)
				{
					model.Rv = row["rv"].ToString();
				}
				if (row["lv"] != null)
				{
					model.Lv = row["lv"].ToString();
				}
				if (row["tv"] != null)
				{
					model.Tv = row["tv"].ToString();
				}
				if(row["mediaindex"] != null)
                {
					model.MediaIndex = Convert.ToInt32(row["mediaindex"]);
                }
                if (row["piflirversion"] != null)
                {                 
                    model.piFlirVersion = row["piflirversion"].ToString();
                }
                if (row["pivideoversion"] != null)
                {                    
                    model.piVideoVersion = row["pivideoversion"].ToString();
                }
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public string getMachineIdByCode(string code)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("select machineid ");
			strSql.Append("from   machine_infor ");
			strSql.Append("where  machinecode='"+code+"'");
			DataTable dt = DbHelperMySQL.Query(strSql.ToString()).Tables[0];
			if(dt!=null)
			{
				return dt.Rows[0]["machineid"].ToString();
			} 
			else
            {
				return null;
            }
		}

		public string getMacByCode(string code)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("select machinemac ");
			strSql.Append("from   machine_infor ");
			strSql.Append("where  machinecode='" + code + "'");
			DataTable dt = DbHelperMySQL.Query(strSql.ToString()).Tables[0];
			if (dt != null)
			{
				return dt.Rows[0]["machinemac"].ToString();
			}
			else
			{
				return null;
			}
		}

		public string getMachineIdByMac(string mac)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("select machineid ");
			strSql.Append("from   machine_infor ");
			strSql.Append("where  machinemac='" + mac + "'");
			DataTable dt = DbHelperMySQL.Query(strSql.ToString()).Tables[0];
			if (dt != null)
			{
				return dt.Rows[0]["machineid"].ToString();
			}
			else
			{
				return null;
			}
		}

		public bool UpdateMediaIndex(string macid, string index)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update machine_infor set ");
			strSql.Append("mediaindex=" + index);
			strSql.Append(" where machineid='" + macid + "' ");
			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());

			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public bool UpdateArgs(Maticsoft.Model.machine_infor model)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update machine_infor set ");
			strSql.Append("fushelv=@rad,");
			strSql.Append("warntemp=@warn,");
			strSql.Append("sv=@sv,");
			strSql.Append("rv=@rv,");
			strSql.Append("lv=@lv,");
			strSql.Append("tv=@tv,");
			strSql.Append("cloudaddr=@mip,");
			strSql.Append("ftpaddr=@fip,");
			strSql.Append("wifiname=@wn,");
			strSql.Append("wifipass=@wp,");
			strSql.Append("machinecode=@num,");
			strSql.Append("piflirversion=@pfv,");
			strSql.Append("pivideoversion=@pvv ");
			strSql.Append("where machinemac=@mac");

			MySqlParameter[] parameters = {
					new MySqlParameter("@rad", MySqlDbType.VarChar, 255),
					new MySqlParameter("@warn", MySqlDbType.VarChar, 255),
					new MySqlParameter("@sv", MySqlDbType.VarChar, 255),
					new MySqlParameter("@rv", MySqlDbType.VarChar, 255),
					new MySqlParameter("@lv", MySqlDbType.VarChar, 255),
					new MySqlParameter("@tv", MySqlDbType.VarChar, 255),
					new MySqlParameter("@mip", MySqlDbType.VarChar, 255),
					new MySqlParameter("@fip", MySqlDbType.VarChar, 255),
					new MySqlParameter("@wn", MySqlDbType.VarChar, 255),
					new MySqlParameter("@wp", MySqlDbType.VarChar, 255),
					new MySqlParameter("@num", MySqlDbType.VarChar, 255),
					new MySqlParameter("@pfv", MySqlDbType.VarChar, 255),
					new MySqlParameter("@pvv", MySqlDbType.VarChar, 255),
					new MySqlParameter("@mac", MySqlDbType.VarChar, 50)
			};

			parameters[0].Value = model.fushelv;
			parameters[1].Value = model.Warntemp;
			parameters[2].Value = model.Sv;
			parameters[3].Value = model.Rv;
			parameters[4].Value = model.Lv;
			parameters[5].Value = model.Tv;
			parameters[6].Value = model.Cloudaddr;
			parameters[7].Value = model.Ftpaddr;
			parameters[8].Value = model.wifiname;
			parameters[9].Value = model.wifipass;
			parameters[10].Value = model.machinecode;
			parameters[11].Value = model.piFlirVersion;
			parameters[12].Value = model.piVideoVersion;
			parameters[13].Value = model.machinemac;

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);

			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public bool UpdateVersion(string macid, string piFlirVersion, string piVideoVersion)
		{
			StringBuilder strSql = new StringBuilder();
			strSql.Append("update machine_infor set ");
			strSql.Append("piflirversion=@piFlirVersion, ");
			strSql.Append("pivideoversion=@piVideoVersion ");
			strSql.Append("where machineid=@macid ");
			MySqlParameter[] parameters = {
			     	new MySqlParameter("@piFlirVersion", MySqlDbType.VarChar, 255),
					new MySqlParameter("@piVideoVersion", MySqlDbType.VarChar, 255),
					new MySqlParameter("@macid", MySqlDbType.VarChar, 50)        
			};
			parameters[0].Value = piFlirVersion;
			parameters[1].Value = piVideoVersion;
			parameters[2].Value = macid;

			int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);

			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public string getMediaIndexByMachineId(string mid)
		{

			StringBuilder strSql = new StringBuilder();
			strSql.Append("select mediaindex from machine_infor ");
			strSql.Append(" where machineid=@mid ");
			MySqlParameter[] parameters = {
					new MySqlParameter("@mid", MySqlDbType.VarChar, 50)          
			};
			parameters[0].Value = mid;

			DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
			if (ds.Tables[0].Rows.Count > 0)
			{
				return ds.Tables[0].Rows[0]["mediaindex"].ToString();
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{

			StringBuilder strSql=new StringBuilder();
			// strSql.Append("select machineid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machinename,machinecompany,machinemac,machinecode,installcode,currentversion,newversion,machinestate,ysdcount,onlinetime,runtime,imagecatchspan,wifiname,wifipass,fushelv,offsetvalue,buchang,topvalue,createtime,cloudaddr,capinterv  ");

			strSql.Append("select * ");
			strSql.Append("FROM machine_infor ");

			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperMySQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM machine_infor ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
            object obj = DbHelperMySQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.machineid desc");
			}
			strSql.Append(")AS Row, T.*  from machine_infor T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperMySQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			MySqlParameter[] parameters = {
					new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
					new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
					new MySqlParameter("@PageSize", MySqlDbType.Int32),
					new MySqlParameter("@PageIndex", MySqlDbType.Int32),
					new MySqlParameter("@IsReCount", MySqlDbType.Bit),
					new MySqlParameter("@OrderType", MySqlDbType.Bit),
					new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
					};
			parameters[0].Value = "machine_infor";
			parameters[1].Value = "machineid";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

