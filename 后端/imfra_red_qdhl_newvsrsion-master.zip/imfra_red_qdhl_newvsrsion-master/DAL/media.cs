﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:device_rect_infor
    /// </summary>
    public partial class media
    {
        public media()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(int id)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from media");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@id", MySqlDbType.Int32, 10)        
            };
            parameters[0].Value = id;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.media model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into media(");
            strSql.Append("host, port, details)");
            strSql.Append(" values (");
            strSql.Append("@host, @port, @details)");
            MySqlParameter[] parameters = {  
                    new MySqlParameter("@host",    MySqlDbType.VarChar,50),
                    new MySqlParameter("@port",    MySqlDbType.VarChar, 50),
                    new MySqlParameter("@details", MySqlDbType.Text, 50)
            };
            
            parameters[0].Value = model.Host;
            parameters[1].Value = model.Port;
            parameters[2].Value = model.Details;
    
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.media model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update media set ");
            strSql.Append("host=@host,");
            strSql.Append("port=@port,");
            strSql.Append("details=@details");
            strSql.Append(" where id=@id ");

            MySqlParameter[] parameters = {
                    new MySqlParameter("@host",    MySqlDbType.VarChar,50),
                    new MySqlParameter("@port",    MySqlDbType.VarChar, 50),
                    new MySqlParameter("@details", MySqlDbType.Text, 50),
                    new MySqlParameter("@id",      MySqlDbType.Int32, 50)
            };
         
            parameters[0].Value = model.Host;
            parameters[1].Value = model.Port;
            parameters[2].Value = model.Details;
            parameters[3].Value = model.Id;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(int id)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from media ");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@id", MySqlDbType.Int32, 10)           
            };

            parameters[0].Value = id;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
     
        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.media GetModel(int id)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select id, host, port, details from media");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@id", MySqlDbType.Int32, 10) 
            };
            
            parameters[0].Value = id;

            Maticsoft.Model.media model = new Maticsoft.Model.media();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.media DataRowToModel(DataRow row)
        {
            Maticsoft.Model.media model = new Maticsoft.Model.media();
            if (row != null)
            { 
                if (row["id"] != null)
                {
                    model.Id = Convert.ToInt32(row["id"]);
                }
               
                if (row["host"] != null)
                {
                    model.Host = row["host"].ToString();
                }

                if (row["port"] != null)
                {
                    model.Port = row["port"].ToString();
                }

                if (row["details"] != null)
                {
                    model.Details = row["details"].ToString();    
                }
            }

            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * ");
            strSql.Append(" from media");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

