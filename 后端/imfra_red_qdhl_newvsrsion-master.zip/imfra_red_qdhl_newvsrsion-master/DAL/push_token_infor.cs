﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:push_token_infor
    /// </summary>
    public partial class push_token_infor
    {
        public push_token_infor()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string tokenid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from push_token_infor");
            strSql.Append(" where tokenid=@tokenid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@tokenid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = tokenid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.push_token_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into push_token_infor(");
            strSql.Append("tokenid,tokenname,tokenvalue,areaname,fenbuname,ywbname,stationname,createtime)");
            strSql.Append(" values (");
            strSql.Append("@tokenid,@tokenname,@tokenvalue,@areaname,@fenbuname,@ywbname,@stationname,@createtime)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@tokenid", MySqlDbType.VarChar,255),
					new MySqlParameter("@tokenname", MySqlDbType.VarChar,255),
					new MySqlParameter("@tokenvalue", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime)};
            parameters[0].Value = model.tokenid;
            parameters[1].Value = model.tokenname;
            parameters[2].Value = model.tokenvalue;
            parameters[3].Value = model.areaname;
            parameters[4].Value = model.fenbuname;
            parameters[5].Value = model.ywbname;
            parameters[6].Value = model.stationname;
            parameters[7].Value = model.createtime;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.push_token_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update push_token_infor set ");
            strSql.Append("tokenname=@tokenname,");
            strSql.Append("tokenvalue=@tokenvalue,");
            strSql.Append("areaname=@areaname,");
            strSql.Append("fenbuname=@fenbuname,");
            strSql.Append("ywbname=@ywbname,");
            strSql.Append("stationname=@stationname,");
            strSql.Append("createtime=@createtime");
            strSql.Append(" where tokenid=@tokenid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@tokenname", MySqlDbType.VarChar,255),
					new MySqlParameter("@tokenvalue", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@tokenid", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.tokenname;
            parameters[1].Value = model.tokenvalue;
            parameters[2].Value = model.areaname;
            parameters[3].Value = model.fenbuname;
            parameters[4].Value = model.ywbname;
            parameters[5].Value = model.stationname;
            parameters[6].Value = model.createtime;
            parameters[7].Value = model.tokenid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateToken(string tokenid,string username)
        {
            string strSql = "update push_token_infor set areaname='" + username + "' where tokenid = '" + tokenid + "'";
            int rows = DbHelperMySQL.ExecuteSql(strSql);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string tokenid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from push_token_infor ");
            strSql.Append(" where tokenid=@tokenid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@tokenid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = tokenid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string tokenidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from push_token_infor ");
            strSql.Append(" where tokenid in (" + tokenidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.push_token_infor GetModel(string tokenid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select tokenid,tokenname,tokenvalue,areaname,fenbuname,ywbname,stationname,createtime from push_token_infor ");
            strSql.Append(" where tokenid=@tokenid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@tokenid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = tokenid;

            Maticsoft.Model.push_token_infor model = new Maticsoft.Model.push_token_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.push_token_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.push_token_infor model = new Maticsoft.Model.push_token_infor();
            if (row != null)
            {
                if (row["tokenid"] != null)
                {
                    model.tokenid = row["tokenid"].ToString();
                }
                if (row["tokenname"] != null)
                {
                    model.tokenname = row["tokenname"].ToString();
                }
                if (row["tokenvalue"] != null)
                {
                    model.tokenvalue = row["tokenvalue"].ToString();
                }
                if (row["areaname"] != null)
                {
                    model.areaname = row["areaname"].ToString();
                }
                if (row["fenbuname"] != null)
                {
                    model.fenbuname = row["fenbuname"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
                if (row["stationname"] != null)
                {
                    model.stationname = row["stationname"].ToString();
                }
                if (row["createtime"] != null && row["createtime"].ToString() != "")
                {
                    model.createtime = DateTime.Parse(row["createtime"].ToString());
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select tokenid,tokenname,tokenvalue,areaname,fenbuname,ywbname,stationname,createtime ");
            strSql.Append(" FROM push_token_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM push_token_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.tokenid desc");
            }
            strSql.Append(")AS Row, T.*  from push_token_infor T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "push_token_infor";
            parameters[1].Value = "tokenid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

