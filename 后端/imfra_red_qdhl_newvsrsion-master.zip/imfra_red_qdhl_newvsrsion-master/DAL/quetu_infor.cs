﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:quetu_infor
    /// </summary>
    public partial class quetu_infor
    {
        public quetu_infor()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string recordid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from quetu_infor");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = recordid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.quetu_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into quetu_infor(");
            strSql.Append("recordid,deviceid,devicename,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,quetudate,quetutime,queinfor)");
            strSql.Append(" values (");
            strSql.Append("@recordid,@deviceid,@devicename,@areaid,@areaname,@fenbuid,@fenbuname,@ywbid,@ywbname,@stationid,@stationname,@quetudate,@quetutime,@queinfor)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@quetudate", MySqlDbType.DateTime),
					new MySqlParameter("@quetutime", MySqlDbType.VarChar,255),
					new MySqlParameter("@queinfor", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.recordid;
            parameters[1].Value = model.deviceid;
            parameters[2].Value = model.devicename;
            parameters[3].Value = model.areaid;
            parameters[4].Value = model.areaname;
            parameters[5].Value = model.fenbuid;
            parameters[6].Value = model.fenbuname;
            parameters[7].Value = model.ywbid;
            parameters[8].Value = model.ywbname;
            parameters[9].Value = model.stationid;
            parameters[10].Value = model.stationname;
            parameters[11].Value = model.quetudate;
            parameters[12].Value = model.quetutime;
            parameters[13].Value = model.queinfor;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.quetu_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update quetu_infor set ");
            strSql.Append("deviceid=@deviceid,");
            strSql.Append("devicename=@devicename,");
            strSql.Append("areaid=@areaid,");
            strSql.Append("areaname=@areaname,");
            strSql.Append("fenbuid=@fenbuid,");
            strSql.Append("fenbuname=@fenbuname,");
            strSql.Append("ywbid=@ywbid,");
            strSql.Append("ywbname=@ywbname,");
            strSql.Append("stationid=@stationid,");
            strSql.Append("stationname=@stationname,");
            strSql.Append("quetudate=@quetudate,");
            strSql.Append("quetutime=@quetutime,");
            strSql.Append("queinfor=@queinfor");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@quetudate", MySqlDbType.DateTime),
					new MySqlParameter("@quetutime", MySqlDbType.VarChar,255),
					new MySqlParameter("@queinfor", MySqlDbType.VarChar,255),
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.deviceid;
            parameters[1].Value = model.devicename;
            parameters[2].Value = model.areaid;
            parameters[3].Value = model.areaname;
            parameters[4].Value = model.fenbuid;
            parameters[5].Value = model.fenbuname;
            parameters[6].Value = model.ywbid;
            parameters[7].Value = model.ywbname;
            parameters[8].Value = model.stationid;
            parameters[9].Value = model.stationname;
            parameters[10].Value = model.quetudate;
            parameters[11].Value = model.quetutime;
            parameters[12].Value = model.queinfor;
            parameters[13].Value = model.recordid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string recordid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from quetu_infor ");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = recordid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string recordidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from quetu_infor ");
            strSql.Append(" where recordid in (" + recordidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.quetu_infor GetModel(string recordid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select recordid,deviceid,devicename,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,quetudate,quetutime,queinfor from quetu_infor ");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = recordid;

            Maticsoft.Model.quetu_infor model = new Maticsoft.Model.quetu_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.quetu_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.quetu_infor model = new Maticsoft.Model.quetu_infor();
            if (row != null)
            {
                if (row["recordid"] != null)
                {
                    model.recordid = row["recordid"].ToString();
                }
                if (row["deviceid"] != null)
                {
                    model.deviceid = row["deviceid"].ToString();
                }
                if (row["devicename"] != null)
                {
                    model.devicename = row["devicename"].ToString();
                }
                if (row["areaid"] != null)
                {
                    model.areaid = row["areaid"].ToString();
                }
                if (row["areaname"] != null)
                {
                    model.areaname = row["areaname"].ToString();
                }
                if (row["fenbuid"] != null)
                {
                    model.fenbuid = row["fenbuid"].ToString();
                }
                if (row["fenbuname"] != null)
                {
                    model.fenbuname = row["fenbuname"].ToString();
                }
                if (row["ywbid"] != null)
                {
                    model.ywbid = row["ywbid"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
                if (row["stationid"] != null)
                {
                    model.stationid = row["stationid"].ToString();
                }
                if (row["stationname"] != null)
                {
                    model.stationname = row["stationname"].ToString();
                }
                if (row["quetudate"] != null && row["quetudate"].ToString() != "")
                {
                    model.quetudate = DateTime.Parse(row["quetudate"].ToString());
                }
                if (row["quetutime"] != null)
                {
                    model.quetutime = row["quetutime"].ToString();
                }
                if (row["queinfor"] != null)
                {
                    model.queinfor = row["queinfor"].ToString();
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select recordid,deviceid,devicename,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,quetudate,quetutime,queinfor ");
            strSql.Append(" FROM quetu_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM quetu_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.recordid desc");
            }
            strSql.Append(")AS Row, T.*  from quetu_infor T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "quetu_infor";
            parameters[1].Value = "recordid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

