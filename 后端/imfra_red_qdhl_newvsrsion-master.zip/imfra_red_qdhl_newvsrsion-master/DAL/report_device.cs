﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:report_device
    /// </summary>
    public partial class report_device
    {
        public report_device()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string devicereportid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from report_device");
            strSql.Append(" where devicereportid=@devicereportid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@devicereportid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = devicereportid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.report_device model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into report_device(");
            strSql.Append("devicereportid,fenbuname,ywbname,stationnane,devicename,devicelevel,fuhe,alarmtime,alarmtemp,machinename,machinecode,buildingname,image_red,image_high,templist_24,templist_30,manager1,manager2,manager3,note1,note2,note3)");
            strSql.Append(" values (");
            strSql.Append("@devicereportid,@fenbuname,@ywbname,@stationnane,@devicename,@devicelevel,@fuhe,@alarmtime,@alarmtemp,@machinename,@machinecode,@buildingname,@image_red,@image_high,@templist_24,@templist_30,@manager1,@manager2,@manager3,@note1,@note2,@note3)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@devicereportid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationnane", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicelevel", MySqlDbType.VarChar,255),
					new MySqlParameter("@fuhe", MySqlDbType.VarChar,255),
					new MySqlParameter("@alarmtime", MySqlDbType.DateTime),
					new MySqlParameter("@alarmtemp", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinecode", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_red", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_high", MySqlDbType.VarChar,255),
					new MySqlParameter("@templist_24", MySqlDbType.VarChar,255),
					new MySqlParameter("@templist_30", MySqlDbType.VarChar,255),
					new MySqlParameter("@manager1", MySqlDbType.VarChar,255),
					new MySqlParameter("@manager2", MySqlDbType.VarChar,255),
					new MySqlParameter("@manager3", MySqlDbType.VarChar,255),
					new MySqlParameter("@note1", MySqlDbType.VarChar,255),
					new MySqlParameter("@note2", MySqlDbType.VarChar,255),
					new MySqlParameter("@note3", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.devicereportid;
            parameters[1].Value = model.fenbuname;
            parameters[2].Value = model.ywbname;
            parameters[3].Value = model.stationnane;
            parameters[4].Value = model.devicename;
            parameters[5].Value = model.devicelevel;
            parameters[6].Value = model.fuhe;
            parameters[7].Value = model.alarmtime;
            parameters[8].Value = model.alarmtemp;
            parameters[9].Value = model.machinename;
            parameters[10].Value = model.machinecode;
            parameters[11].Value = model.buildingname;
            parameters[12].Value = model.image_red;
            parameters[13].Value = model.image_high;
            parameters[14].Value = model.templist_24;
            parameters[15].Value = model.templist_30;
            parameters[16].Value = model.manager1;
            parameters[17].Value = model.manager2;
            parameters[18].Value = model.manager3;
            parameters[19].Value = model.note1;
            parameters[20].Value = model.note2;
            parameters[21].Value = model.note3;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.report_device model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update report_device set ");
            strSql.Append("fenbuname=@fenbuname,");
            strSql.Append("ywbname=@ywbname,");
            strSql.Append("stationnane=@stationnane,");
            strSql.Append("devicename=@devicename,");
            strSql.Append("devicelevel=@devicelevel,");
            strSql.Append("fuhe=@fuhe,");
            strSql.Append("alarmtime=@alarmtime,");
            strSql.Append("alarmtemp=@alarmtemp,");
            strSql.Append("machinename=@machinename,");
            strSql.Append("machinecode=@machinecode,");
            strSql.Append("buildingname=@buildingname,");
            strSql.Append("image_red=@image_red,");
            strSql.Append("image_high=@image_high,");
            strSql.Append("templist_24=@templist_24,");
            strSql.Append("templist_30=@templist_30,");
            strSql.Append("manager1=@manager1,");
            strSql.Append("manager2=@manager2,");
            strSql.Append("manager3=@manager3,");
            strSql.Append("note1=@note1,");
            strSql.Append("note2=@note2,");
            strSql.Append("note3=@note3");
            strSql.Append(" where devicereportid=@devicereportid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationnane", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicelevel", MySqlDbType.VarChar,255),
					new MySqlParameter("@fuhe", MySqlDbType.VarChar,255),
					new MySqlParameter("@alarmtime", MySqlDbType.DateTime),
					new MySqlParameter("@alarmtemp", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinecode", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_red", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_high", MySqlDbType.VarChar,255),
					new MySqlParameter("@templist_24", MySqlDbType.VarChar,255),
					new MySqlParameter("@templist_30", MySqlDbType.VarChar,255),
					new MySqlParameter("@manager1", MySqlDbType.VarChar,255),
					new MySqlParameter("@manager2", MySqlDbType.VarChar,255),
					new MySqlParameter("@manager3", MySqlDbType.VarChar,255),
					new MySqlParameter("@note1", MySqlDbType.VarChar,255),
					new MySqlParameter("@note2", MySqlDbType.VarChar,255),
					new MySqlParameter("@note3", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicereportid", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.fenbuname;
            parameters[1].Value = model.ywbname;
            parameters[2].Value = model.stationnane;
            parameters[3].Value = model.devicename;
            parameters[4].Value = model.devicelevel;
            parameters[5].Value = model.fuhe;
            parameters[6].Value = model.alarmtime;
            parameters[7].Value = model.alarmtemp;
            parameters[8].Value = model.machinename;
            parameters[9].Value = model.machinecode;
            parameters[10].Value = model.buildingname;
            parameters[11].Value = model.image_red;
            parameters[12].Value = model.image_high;
            parameters[13].Value = model.templist_24;
            parameters[14].Value = model.templist_30;
            parameters[15].Value = model.manager1;
            parameters[16].Value = model.manager2;
            parameters[17].Value = model.manager3;
            parameters[18].Value = model.note1;
            parameters[19].Value = model.note2;
            parameters[20].Value = model.note3;
            parameters[21].Value = model.devicereportid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string devicereportid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from report_device ");
            strSql.Append(" where devicereportid=@devicereportid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@devicereportid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = devicereportid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string devicereportidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from report_device ");
            strSql.Append(" where devicereportid in (" + devicereportidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.report_device GetModel(string devicereportid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select devicereportid,fenbuname,ywbname,stationnane,devicename,devicelevel,fuhe,alarmtime,alarmtemp,machinename,machinecode,buildingname,image_red,image_high,templist_24,templist_30,manager1,manager2,manager3,note1,note2,note3 from report_device ");
            strSql.Append(" where devicereportid=@devicereportid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@devicereportid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = devicereportid;

            Maticsoft.Model.report_device model = new Maticsoft.Model.report_device();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.report_device DataRowToModel(DataRow row)
        {
            Maticsoft.Model.report_device model = new Maticsoft.Model.report_device();
            if (row != null)
            {
                if (row["devicereportid"] != null)
                {
                    model.devicereportid = row["devicereportid"].ToString();
                }
                if (row["fenbuname"] != null)
                {
                    model.fenbuname = row["fenbuname"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
                if (row["stationnane"] != null)
                {
                    model.stationnane = row["stationnane"].ToString();
                }
                if (row["devicename"] != null)
                {
                    model.devicename = row["devicename"].ToString();
                }
                if (row["devicelevel"] != null)
                {
                    model.devicelevel = row["devicelevel"].ToString();
                }
                if (row["fuhe"] != null)
                {
                    model.fuhe = row["fuhe"].ToString();
                }
                if (row["alarmtime"] != null && row["alarmtime"].ToString() != "")
                {
                    model.alarmtime = DateTime.Parse(row["alarmtime"].ToString());
                }
                if (row["alarmtemp"] != null)
                {
                    model.alarmtemp = row["alarmtemp"].ToString();
                }
                if (row["machinename"] != null)
                {
                    model.machinename = row["machinename"].ToString();
                }
                if (row["machinecode"] != null)
                {
                    model.machinecode = row["machinecode"].ToString();
                }
                if (row["buildingname"] != null)
                {
                    model.buildingname = row["buildingname"].ToString();
                }
                if (row["image_red"] != null)
                {
                    model.image_red = row["image_red"].ToString();
                }
                if (row["image_high"] != null)
                {
                    model.image_high = row["image_high"].ToString();
                }
                if (row["templist_24"] != null)
                {
                    model.templist_24 = row["templist_24"].ToString();
                }
                if (row["templist_30"] != null)
                {
                    model.templist_30 = row["templist_30"].ToString();
                }
                if (row["manager1"] != null)
                {
                    model.manager1 = row["manager1"].ToString();
                }
                if (row["manager2"] != null)
                {
                    model.manager2 = row["manager2"].ToString();
                }
                if (row["manager3"] != null)
                {
                    model.manager3 = row["manager3"].ToString();
                }
                if (row["note1"] != null)
                {
                    model.note1 = row["note1"].ToString();
                }
                if (row["note2"] != null)
                {
                    model.note2 = row["note2"].ToString();
                }
                if (row["note3"] != null)
                {
                    model.note3 = row["note3"].ToString();
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select devicereportid,fenbuname,ywbname,stationnane,devicename,devicelevel,fuhe,alarmtime,alarmtemp,machinename,machinecode,buildingname,image_red,image_high,templist_24,templist_30,manager1,manager2,manager3,note1,note2,note3 ");
            strSql.Append(" FROM report_device ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM report_device ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.devicereportid desc");
            }
            strSql.Append(")AS Row, T.*  from report_device T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "report_device";
            parameters[1].Value = "devicereportid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

