﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:report_ywb
    /// </summary>
    public partial class report_ywb
    {
        public report_ywb()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string ywbreportid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from report_ywb");
            strSql.Append(" where ywbreportid=@ywbreportid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@ywbreportid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = ywbreportid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.report_ywb model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into report_ywb(");
            strSql.Append("ywbreportid,reporttime,reportdanwei,devicereport,hightempreport,alarmreport,image_red_list,image_hihg_list,qushireport,templist_24,templist_7,ywbname,manager)");
            strSql.Append(" values (");
            strSql.Append("@ywbreportid,@reporttime,@reportdanwei,@devicereport,@hightempreport,@alarmreport,@image_red_list,@image_hihg_list,@qushireport,@templist_24,@templist_7,@ywbname,@manager)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@ywbreportid", MySqlDbType.VarChar,255),
					new MySqlParameter("@reporttime", MySqlDbType.DateTime),
					new MySqlParameter("@reportdanwei", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicereport", MySqlDbType.VarChar,255),
					new MySqlParameter("@hightempreport", MySqlDbType.VarChar,255),
					new MySqlParameter("@alarmreport", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_red_list", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_hihg_list", MySqlDbType.VarChar,255),
					new MySqlParameter("@qushireport", MySqlDbType.VarChar,255),
					new MySqlParameter("@templist_24", MySqlDbType.VarChar,255),
					new MySqlParameter("@templist_7", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@manager", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.ywbreportid;
            parameters[1].Value = model.reporttime;
            parameters[2].Value = model.reportdanwei;
            parameters[3].Value = model.devicereport;
            parameters[4].Value = model.hightempreport;
            parameters[5].Value = model.alarmreport;
            parameters[6].Value = model.image_red_list;
            parameters[7].Value = model.image_hihg_list;
            parameters[8].Value = model.qushireport;
            parameters[9].Value = model.templist_24;
            parameters[10].Value = model.templist_7;
            parameters[11].Value = model.ywbname;
            parameters[12].Value = model.manager;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.report_ywb model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update report_ywb set ");
            strSql.Append("reporttime=@reporttime,");
            strSql.Append("reportdanwei=@reportdanwei,");
            strSql.Append("devicereport=@devicereport,");
            strSql.Append("hightempreport=@hightempreport,");
            strSql.Append("alarmreport=@alarmreport,");
            strSql.Append("image_red_list=@image_red_list,");
            strSql.Append("image_hihg_list=@image_hihg_list,");
            strSql.Append("qushireport=@qushireport,");
            strSql.Append("templist_24=@templist_24,");
            strSql.Append("templist_7=@templist_7,");
            strSql.Append("ywbname=@ywbname,");
            strSql.Append("manager=@manager");
            strSql.Append(" where ywbreportid=@ywbreportid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@reporttime", MySqlDbType.DateTime),
					new MySqlParameter("@reportdanwei", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicereport", MySqlDbType.VarChar,255),
					new MySqlParameter("@hightempreport", MySqlDbType.VarChar,255),
					new MySqlParameter("@alarmreport", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_red_list", MySqlDbType.VarChar,255),
					new MySqlParameter("@image_hihg_list", MySqlDbType.VarChar,255),
					new MySqlParameter("@qushireport", MySqlDbType.VarChar,255),
					new MySqlParameter("@templist_24", MySqlDbType.VarChar,255),
					new MySqlParameter("@templist_7", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@manager", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbreportid", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.reporttime;
            parameters[1].Value = model.reportdanwei;
            parameters[2].Value = model.devicereport;
            parameters[3].Value = model.hightempreport;
            parameters[4].Value = model.alarmreport;
            parameters[5].Value = model.image_red_list;
            parameters[6].Value = model.image_hihg_list;
            parameters[7].Value = model.qushireport;
            parameters[8].Value = model.templist_24;
            parameters[9].Value = model.templist_7;
            parameters[10].Value = model.ywbname;
            parameters[11].Value = model.manager;
            parameters[12].Value = model.ywbreportid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string ywbreportid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from report_ywb ");
            strSql.Append(" where ywbreportid=@ywbreportid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@ywbreportid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = ywbreportid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string ywbreportidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from report_ywb ");
            strSql.Append(" where ywbreportid in (" + ywbreportidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.report_ywb GetModel(string ywbreportid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ywbreportid,reporttime,reportdanwei,devicereport,hightempreport,alarmreport,image_red_list,image_hihg_list,qushireport,templist_24,templist_7,ywbname,manager from report_ywb ");
            strSql.Append(" where ywbreportid=@ywbreportid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@ywbreportid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = ywbreportid;

            Maticsoft.Model.report_ywb model = new Maticsoft.Model.report_ywb();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.report_ywb DataRowToModel(DataRow row)
        {
            Maticsoft.Model.report_ywb model = new Maticsoft.Model.report_ywb();
            if (row != null)
            {
                if (row["ywbreportid"] != null)
                {
                    model.ywbreportid = row["ywbreportid"].ToString();
                }
                if (row["reporttime"] != null && row["reporttime"].ToString() != "")
                {
                    model.reporttime = DateTime.Parse(row["reporttime"].ToString());
                }
                if (row["reportdanwei"] != null)
                {
                    model.reportdanwei = row["reportdanwei"].ToString();
                }
                if (row["devicereport"] != null)
                {
                    model.devicereport = row["devicereport"].ToString();
                }
                if (row["hightempreport"] != null)
                {
                    model.hightempreport = row["hightempreport"].ToString();
                }
                if (row["alarmreport"] != null)
                {
                    model.alarmreport = row["alarmreport"].ToString();
                }
                if (row["image_red_list"] != null)
                {
                    model.image_red_list = row["image_red_list"].ToString();
                }
                if (row["image_hihg_list"] != null)
                {
                    model.image_hihg_list = row["image_hihg_list"].ToString();
                }
                if (row["qushireport"] != null)
                {
                    model.qushireport = row["qushireport"].ToString();
                }
                if (row["templist_24"] != null)
                {
                    model.templist_24 = row["templist_24"].ToString();
                }
                if (row["templist_7"] != null)
                {
                    model.templist_7 = row["templist_7"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
                if (row["manager"] != null)
                {
                    model.manager = row["manager"].ToString();
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ywbreportid,reporttime,reportdanwei,devicereport,hightempreport,alarmreport,image_red_list,image_hihg_list,qushireport,templist_24,templist_7,ywbname,manager ");
            strSql.Append(" FROM report_ywb ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM report_ywb ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.ywbreportid desc");
            }
            strSql.Append(")AS Row, T.*  from report_ywb T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "report_ywb";
            parameters[1].Value = "ywbreportid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

