﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:round_infor
    /// </summary>
    public partial class round_infor
    {
        public round_infor()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string userid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from round_infor");
            strSql.Append(" where userid=@userid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@userid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = userid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.round_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into round_infor(");
            strSql.Append("userid,todaytop,yestodaytop,weektop,monthtop,historytop)");
            strSql.Append(" values (");
            strSql.Append("@userid,@todaytop,@yestodaytop,@weektop,@monthtop,@historytop)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@userid", MySqlDbType.VarChar,255),
					new MySqlParameter("@todaytop", MySqlDbType.VarChar,255),
					new MySqlParameter("@yestodaytop", MySqlDbType.VarChar,255),
					new MySqlParameter("@weektop", MySqlDbType.VarChar,255),
					new MySqlParameter("@monthtop", MySqlDbType.VarChar,255),
					new MySqlParameter("@historytop", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.userid;
            parameters[1].Value = model.todaytop;
            parameters[2].Value = model.yestodaytop;
            parameters[3].Value = model.weektop;
            parameters[4].Value = model.monthtop;
            parameters[5].Value = model.historytop;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.round_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update round_infor set ");
            strSql.Append("todaytop=@todaytop,");
            strSql.Append("yestodaytop=@yestodaytop,");
            strSql.Append("weektop=@weektop,");
            strSql.Append("monthtop=@monthtop,");
            strSql.Append("historytop=@historytop");
            strSql.Append(" where userid=@userid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@todaytop", MySqlDbType.VarChar,255),
					new MySqlParameter("@yestodaytop", MySqlDbType.VarChar,255),
					new MySqlParameter("@weektop", MySqlDbType.VarChar,255),
					new MySqlParameter("@monthtop", MySqlDbType.VarChar,255),
					new MySqlParameter("@historytop", MySqlDbType.VarChar,255),
					new MySqlParameter("@userid", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.todaytop;
            parameters[1].Value = model.yestodaytop;
            parameters[2].Value = model.weektop;
            parameters[3].Value = model.monthtop;
            parameters[4].Value = model.historytop;
            parameters[5].Value = model.userid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string userid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from round_infor ");
            strSql.Append(" where userid=@userid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@userid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = userid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string useridlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from round_infor ");
            strSql.Append(" where userid in (" + useridlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.round_infor GetModel(string userid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select userid,todaytop,yestodaytop,weektop,monthtop,historytop from round_infor ");
            strSql.Append(" where userid=@userid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@userid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = userid;

            Maticsoft.Model.round_infor model = new Maticsoft.Model.round_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.round_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.round_infor model = new Maticsoft.Model.round_infor();
            if (row != null)
            {
                if (row["userid"] != null)
                {
                    model.userid = row["userid"].ToString();
                }
                if (row["todaytop"] != null)
                {
                    model.todaytop = row["todaytop"].ToString();
                }
                if (row["yestodaytop"] != null)
                {
                    model.yestodaytop = row["yestodaytop"].ToString();
                }
                if (row["weektop"] != null)
                {
                    model.weektop = row["weektop"].ToString();
                }
                if (row["monthtop"] != null)
                {
                    model.monthtop = row["monthtop"].ToString();
                }
                if (row["historytop"] != null)
                {
                    model.historytop = row["historytop"].ToString();
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select userid,todaytop,yestodaytop,weektop,monthtop,historytop ");
            strSql.Append(" FROM round_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM round_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.userid desc");
            }
            strSql.Append(")AS Row, T.*  from round_infor T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "round_infor";
            parameters[1].Value = "userid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

