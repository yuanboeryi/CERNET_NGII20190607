﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:round_top_infor
    /// </summary>
    public partial class round_top_infor
    {
        public round_top_infor()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string id)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from round_top_infor");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255)			};
            parameters[0].Value = id;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.round_top_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into round_top_infor(");
            strSql.Append("id,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,todayTop,yestodayTop,monthTop,weekTop,deviceid_today,deviceid_yestoday,deviceid_week,deviceid_month)");
            strSql.Append(" values (");
            strSql.Append("@id,@areaid,@areaname,@fenbuid,@fenbuname,@ywbid,@ywbname,@stationid,@stationname,@todayTop,@yestodayTop,@monthTop,@weekTop,@deviceid_today,@deviceid_yestoday,@deviceid_week,@deviceid_month)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@todayTop", MySqlDbType.VarChar,255),
					new MySqlParameter("@yestodayTop", MySqlDbType.VarChar,255),
					new MySqlParameter("@monthTop", MySqlDbType.VarChar,255),
					new MySqlParameter("@weekTop", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid_today", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid_yestoday", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid_week", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid_month", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.id;
            parameters[1].Value = model.areaid;
            parameters[2].Value = model.areaname;
            parameters[3].Value = model.fenbuid;
            parameters[4].Value = model.fenbuname;
            parameters[5].Value = model.ywbid;
            parameters[6].Value = model.ywbname;
            parameters[7].Value = model.stationid;
            parameters[8].Value = model.stationname;
            parameters[9].Value = model.todayTop;
            parameters[10].Value = model.yestodayTop;
            parameters[11].Value = model.monthTop;
            parameters[12].Value = model.weekTop;
            parameters[13].Value = model.deviceid_today;
            parameters[14].Value = model.deviceid_yestoday;
            parameters[15].Value = model.deviceid_week;
            parameters[16].Value = model.deviceid_month;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.round_top_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update round_top_infor set ");
            strSql.Append("areaid=@areaid,");
            strSql.Append("areaname=@areaname,");
            strSql.Append("fenbuid=@fenbuid,");
            strSql.Append("fenbuname=@fenbuname,");
            strSql.Append("ywbid=@ywbid,");
            strSql.Append("ywbname=@ywbname,");
            strSql.Append("stationid=@stationid,");
            strSql.Append("stationname=@stationname,");
            strSql.Append("todayTop=@todayTop,");
            strSql.Append("yestodayTop=@yestodayTop,");
            strSql.Append("monthTop=@monthTop,");
            strSql.Append("weekTop=@weekTop,");
            strSql.Append("deviceid_today=@deviceid_today,");
            strSql.Append("deviceid_yestoday=@deviceid_yestoday,");
            strSql.Append("deviceid_week=@deviceid_week,");
            strSql.Append("deviceid_month=@deviceid_month");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@todayTop", MySqlDbType.VarChar,255),
					new MySqlParameter("@yestodayTop", MySqlDbType.VarChar,255),
					new MySqlParameter("@monthTop", MySqlDbType.VarChar,255),
					new MySqlParameter("@weekTop", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid_today", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid_yestoday", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid_week", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid_month", MySqlDbType.VarChar,255),
					new MySqlParameter("@id", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.areaid;
            parameters[1].Value = model.areaname;
            parameters[2].Value = model.fenbuid;
            parameters[3].Value = model.fenbuname;
            parameters[4].Value = model.ywbid;
            parameters[5].Value = model.ywbname;
            parameters[6].Value = model.stationid;
            parameters[7].Value = model.stationname;
            parameters[8].Value = model.todayTop;
            parameters[9].Value = model.yestodayTop;
            parameters[10].Value = model.monthTop;
            parameters[11].Value = model.weekTop;
            parameters[12].Value = model.deviceid_today;
            parameters[13].Value = model.deviceid_yestoday;
            parameters[14].Value = model.deviceid_week;
            parameters[15].Value = model.deviceid_month;
            parameters[16].Value = model.id;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string id)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from round_top_infor ");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255)			};
            parameters[0].Value = id;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string idlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from round_top_infor ");
            strSql.Append(" where id in (" + idlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.round_top_infor GetModel(string id)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select id,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,todayTop,yestodayTop,monthTop,weekTop,deviceid_today,deviceid_yestoday,deviceid_week,deviceid_month from round_top_infor ");
            strSql.Append(" where id=@id ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@id", MySqlDbType.VarChar,255)			};
            parameters[0].Value = id;

            Maticsoft.Model.round_top_infor model = new Maticsoft.Model.round_top_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.round_top_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.round_top_infor model = new Maticsoft.Model.round_top_infor();
            if (row != null)
            {
                if (row["id"] != null)
                {
                    model.id = row["id"].ToString();
                }
                if (row["areaid"] != null)
                {
                    model.areaid = row["areaid"].ToString();
                }
                if (row["areaname"] != null)
                {
                    model.areaname = row["areaname"].ToString();
                }
                if (row["fenbuid"] != null)
                {
                    model.fenbuid = row["fenbuid"].ToString();
                }
                if (row["fenbuname"] != null)
                {
                    model.fenbuname = row["fenbuname"].ToString();
                }
                if (row["ywbid"] != null)
                {
                    model.ywbid = row["ywbid"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
                if (row["stationid"] != null)
                {
                    model.stationid = row["stationid"].ToString();
                }
                if (row["stationname"] != null)
                {
                    model.stationname = row["stationname"].ToString();
                }
                if (row["todayTop"] != null)
                {
                    model.todayTop = row["todayTop"].ToString();
                }
                if (row["yestodayTop"] != null)
                {
                    model.yestodayTop = row["yestodayTop"].ToString();
                }
                if (row["monthTop"] != null)
                {
                    model.monthTop = row["monthTop"].ToString();
                }
                if (row["weekTop"] != null)
                {
                    model.weekTop = row["weekTop"].ToString();
                }
                if (row["deviceid_today"] != null)
                {
                    model.deviceid_today = row["deviceid_today"].ToString();
                }
                if (row["deviceid_yestoday"] != null)
                {
                    model.deviceid_yestoday = row["deviceid_yestoday"].ToString();
                }
                if (row["deviceid_week"] != null)
                {
                    model.deviceid_week = row["deviceid_week"].ToString();
                }
                if (row["deviceid_month"] != null)
                {
                    model.deviceid_month = row["deviceid_month"].ToString();
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select id,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,todayTop,yestodayTop,monthTop,weekTop,deviceid_today,deviceid_yestoday,deviceid_week,deviceid_month ");
            strSql.Append(" FROM round_top_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM round_top_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.id desc");
            }
            strSql.Append(")AS Row, T.*  from round_top_infor T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "round_top_infor";
            parameters[1].Value = "id";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

