﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:shortname_infor
    /// </summary>
    public partial class shortname_infor
    {
        public shortname_infor()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string nameid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from shortname_infor");
            strSql.Append(" where nameid=@nameid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@nameid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = nameid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.shortname_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into shortname_infor(");
            strSql.Append("nameid,nameold,namenew1,namenew2,namenew3)");
            strSql.Append(" values (");
            strSql.Append("@nameid,@nameold,@namenew1,@namenew2,@namenew3)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@nameid", MySqlDbType.VarChar,255),
					new MySqlParameter("@nameold", MySqlDbType.VarChar,255),
					new MySqlParameter("@namenew1", MySqlDbType.VarChar,255),
					new MySqlParameter("@namenew2", MySqlDbType.VarChar,255),
					new MySqlParameter("@namenew3", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.nameid;
            parameters[1].Value = model.nameold;
            parameters[2].Value = model.namenew1;
            parameters[3].Value = model.namenew2;
            parameters[4].Value = model.namenew3;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.shortname_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update shortname_infor set ");
            strSql.Append("nameold=@nameold,");
            strSql.Append("namenew1=@namenew1,");
            strSql.Append("namenew2=@namenew2,");
            strSql.Append("namenew3=@namenew3");
            strSql.Append(" where nameid=@nameid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@nameold", MySqlDbType.VarChar,255),
					new MySqlParameter("@namenew1", MySqlDbType.VarChar,255),
					new MySqlParameter("@namenew2", MySqlDbType.VarChar,255),
					new MySqlParameter("@namenew3", MySqlDbType.VarChar,255),
					new MySqlParameter("@nameid", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.nameold;
            parameters[1].Value = model.namenew1;
            parameters[2].Value = model.namenew2;
            parameters[3].Value = model.namenew3;
            parameters[4].Value = model.nameid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string nameid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from shortname_infor ");
            strSql.Append(" where nameid=@nameid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@nameid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = nameid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string nameidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from shortname_infor ");
            strSql.Append(" where nameid in (" + nameidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.shortname_infor GetModel(string nameid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select nameid,nameold,namenew1,namenew2,namenew3 from shortname_infor ");
            strSql.Append(" where nameid=@nameid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@nameid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = nameid;

            Maticsoft.Model.shortname_infor model = new Maticsoft.Model.shortname_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.shortname_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.shortname_infor model = new Maticsoft.Model.shortname_infor();
            if (row != null)
            {
                if (row["nameid"] != null)
                {
                    model.nameid = row["nameid"].ToString();
                }
                if (row["nameold"] != null)
                {
                    model.nameold = row["nameold"].ToString();
                }
                if (row["namenew1"] != null)
                {
                    model.namenew1 = row["namenew1"].ToString();
                }
                if (row["namenew2"] != null)
                {
                    model.namenew2 = row["namenew2"].ToString();
                }
                if (row["namenew3"] != null)
                {
                    model.namenew3 = row["namenew3"].ToString();
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select nameid,nameold,namenew1,namenew2,namenew3 ");
            strSql.Append(" FROM shortname_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM shortname_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.nameid desc");
            }
            strSql.Append(")AS Row, T.*  from shortname_infor T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "shortname_infor";
            parameters[1].Value = "nameid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

