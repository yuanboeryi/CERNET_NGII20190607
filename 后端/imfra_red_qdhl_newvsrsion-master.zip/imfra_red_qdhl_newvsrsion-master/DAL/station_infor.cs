﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:station_infor
    /// </summary>
    public partial class station_infor
    {
        public station_infor()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string stationid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from station_infor");
            strSql.Append(" where stationid=@stationid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = stationid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.station_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into station_infor(");
            strSql.Append("stationid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationname,devicecount,manager,phone,stationlevel,city,address,jingdu,weidu,topvalue,alarmcount,createtime,todaytop,yestodaytop,weektop,monthtop,historytop,todayid,yestodayid,weekid,monthid,historyid,now_flag,top_flag)");
            strSql.Append(" values (");
            strSql.Append("@stationid,@areaid,@areaname,@fenbuid,@fenbuname,@ywbid,@ywbname,@stationname,@devicecount,@manager,@phone,@stationlevel,@city,@address,@jingdu,@weidu,@topvalue,@alarmcount,@createtime,@todaytop,@yestodaytop,@weektop,@monthtop,@historytop,@todayid,@yestodayid,@weekid,@monthid,@historyid,@now_flag,@top_flag)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@stationid", MySqlDbType.VarChar,50),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,50),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,50),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,50),
					new MySqlParameter("@devicecount", MySqlDbType.VarChar,50),
					new MySqlParameter("@manager", MySqlDbType.VarChar,50),
					new MySqlParameter("@phone", MySqlDbType.VarChar,50),
					new MySqlParameter("@stationlevel", MySqlDbType.VarChar,50),
					new MySqlParameter("@city", MySqlDbType.VarChar,50),
					new MySqlParameter("@address", MySqlDbType.VarChar,100),
					new MySqlParameter("@jingdu", MySqlDbType.VarChar,50),
					new MySqlParameter("@weidu", MySqlDbType.VarChar,50),
					new MySqlParameter("@topvalue", MySqlDbType.VarChar,50),
					new MySqlParameter("@alarmcount", MySqlDbType.VarChar,50),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@todaytop", MySqlDbType.VarChar,50),
					new MySqlParameter("@yestodaytop", MySqlDbType.VarChar,50),
					new MySqlParameter("@weektop", MySqlDbType.VarChar,50),
					new MySqlParameter("@monthtop", MySqlDbType.VarChar,50),
					new MySqlParameter("@historytop", MySqlDbType.VarChar,50),
					new MySqlParameter("@todayid", MySqlDbType.VarChar,50),
					new MySqlParameter("@yestodayid", MySqlDbType.VarChar,50),
					new MySqlParameter("@weekid", MySqlDbType.VarChar,50),
					new MySqlParameter("@monthid", MySqlDbType.VarChar,50),
					new MySqlParameter("@historyid", MySqlDbType.VarChar,50),
					new MySqlParameter("@now_flag", MySqlDbType.VarChar,100),
					new MySqlParameter("@top_flag", MySqlDbType.VarChar,100)};
            parameters[0].Value = model.stationid;
            parameters[1].Value = model.areaid;
            parameters[2].Value = model.areaname;
            parameters[3].Value = model.fenbuid;
            parameters[4].Value = model.fenbuname;
            parameters[5].Value = model.ywbid;
            parameters[6].Value = model.ywbname;
            parameters[7].Value = model.stationname;
            parameters[8].Value = model.devicecount;
            parameters[9].Value = model.manager;
            parameters[10].Value = model.phone;
            parameters[11].Value = model.stationlevel;
            parameters[12].Value = model.city;
            parameters[13].Value = model.address;
            parameters[14].Value = model.jingdu;
            parameters[15].Value = model.weidu;
            parameters[16].Value = model.topvalue;
            parameters[17].Value = model.alarmcount;
            parameters[18].Value = model.createtime;
            parameters[19].Value = model.todaytop;
            parameters[20].Value = model.yestodaytop;
            parameters[21].Value = model.weektop;
            parameters[22].Value = model.monthtop;
            parameters[23].Value = model.historytop;
            parameters[24].Value = model.todayid;
            parameters[25].Value = model.yestodayid;
            parameters[26].Value = model.weekid;
            parameters[27].Value = model.monthid;
            parameters[28].Value = model.historyid;
            parameters[29].Value = model.now_flag;
            parameters[30].Value = model.top_flag;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.station_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update station_infor set ");
            strSql.Append("areaid=@areaid,");
            strSql.Append("areaname=@areaname,");
            strSql.Append("fenbuid=@fenbuid,");
            strSql.Append("fenbuname=@fenbuname,");
            strSql.Append("ywbid=@ywbid,");
            strSql.Append("ywbname=@ywbname,");
            strSql.Append("stationname=@stationname,");
            strSql.Append("devicecount=@devicecount,");
            strSql.Append("manager=@manager,");
            strSql.Append("phone=@phone,");
            strSql.Append("stationlevel=@stationlevel,");
            strSql.Append("city=@city,");
            strSql.Append("address=@address,");
            strSql.Append("jingdu=@jingdu,");
            strSql.Append("weidu=@weidu,");
            strSql.Append("topvalue=@topvalue,");
            strSql.Append("alarmcount=@alarmcount,");
            strSql.Append("createtime=@createtime,");
            strSql.Append("todaytop=@todaytop,");
            strSql.Append("yestodaytop=@yestodaytop,");
            strSql.Append("weektop=@weektop,");
            strSql.Append("monthtop=@monthtop,");
            strSql.Append("historytop=@historytop,");
            strSql.Append("todayid=@todayid,");
            strSql.Append("yestodayid=@yestodayid,");
            strSql.Append("weekid=@weekid,");
            strSql.Append("monthid=@monthid,");
            strSql.Append("historyid=@historyid,");
            strSql.Append("now_flag=@now_flag,");
            strSql.Append("top_flag=@top_flag");
            strSql.Append(" where stationid=@stationid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@areaid", MySqlDbType.VarChar,50),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,50),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,50),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,50),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,50),
					new MySqlParameter("@devicecount", MySqlDbType.VarChar,50),
					new MySqlParameter("@manager", MySqlDbType.VarChar,50),
					new MySqlParameter("@phone", MySqlDbType.VarChar,50),
					new MySqlParameter("@stationlevel", MySqlDbType.VarChar,50),
					new MySqlParameter("@city", MySqlDbType.VarChar,50),
					new MySqlParameter("@address", MySqlDbType.VarChar,100),
					new MySqlParameter("@jingdu", MySqlDbType.VarChar,50),
					new MySqlParameter("@weidu", MySqlDbType.VarChar,50),
					new MySqlParameter("@topvalue", MySqlDbType.VarChar,50),
					new MySqlParameter("@alarmcount", MySqlDbType.VarChar,50),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@todaytop", MySqlDbType.VarChar,50),
					new MySqlParameter("@yestodaytop", MySqlDbType.VarChar,50),
					new MySqlParameter("@weektop", MySqlDbType.VarChar,50),
					new MySqlParameter("@monthtop", MySqlDbType.VarChar,50),
					new MySqlParameter("@historytop", MySqlDbType.VarChar,50),
					new MySqlParameter("@todayid", MySqlDbType.VarChar,50),
					new MySqlParameter("@yestodayid", MySqlDbType.VarChar,50),
					new MySqlParameter("@weekid", MySqlDbType.VarChar,50),
					new MySqlParameter("@monthid", MySqlDbType.VarChar,50),
					new MySqlParameter("@historyid", MySqlDbType.VarChar,50),
					new MySqlParameter("@now_flag", MySqlDbType.VarChar,100),
					new MySqlParameter("@top_flag", MySqlDbType.VarChar,100),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,50)};
            parameters[0].Value = model.areaid;
            parameters[1].Value = model.areaname;
            parameters[2].Value = model.fenbuid;
            parameters[3].Value = model.fenbuname;
            parameters[4].Value = model.ywbid;
            parameters[5].Value = model.ywbname;
            parameters[6].Value = model.stationname;
            parameters[7].Value = model.devicecount;
            parameters[8].Value = model.manager;
            parameters[9].Value = model.phone;
            parameters[10].Value = model.stationlevel;
            parameters[11].Value = model.city;
            parameters[12].Value = model.address;
            parameters[13].Value = model.jingdu;
            parameters[14].Value = model.weidu;
            parameters[15].Value = model.topvalue;
            parameters[16].Value = model.alarmcount;
            parameters[17].Value = model.createtime;
            parameters[18].Value = model.todaytop;
            parameters[19].Value = model.yestodaytop;
            parameters[20].Value = model.weektop;
            parameters[21].Value = model.monthtop;
            parameters[22].Value = model.historytop;
            parameters[23].Value = model.todayid;
            parameters[24].Value = model.yestodayid;
            parameters[25].Value = model.weekid;
            parameters[26].Value = model.monthid;
            parameters[27].Value = model.historyid;
            parameters[28].Value = model.now_flag;
            parameters[29].Value = model.top_flag;
            parameters[30].Value = model.stationid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update_every_value(string stationid)
        {
            string value = "0.0";
            StringBuilder strSql = new StringBuilder();
            //strSql.Append("update station_infor set ");
            //strSql.Append("topvalue='" + value +"',todaytop='"+value+"',yestodaytop='" + value +"',weektop='"+value+"',monthtop='"+value+"',historytop='"+value+"'");
            //strSql.Append(" where stationid='"+stationid+"'");
            strSql.Append("update station_infor set ");
            strSql.Append("topvalue='" + value + "',todaytop='" + value + "',yestodaytop='" + value + "',weektop='" + value + "',monthtop='" + value + "',historytop='" + value + "'");
            strSql.Append(" where stationid='"+stationid+"'");

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if(rows > 0)
            {
                return true;
            }
            else
            {
               return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateTopValue(string id, string value,string nowflag)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update station_infor set ");

            strSql.Append("topvalue='" + value + "',now_flag='"+nowflag+"',createtime='"+System.DateTime.Now+"'");

            strSql.Append(" where stationid='" + id + "' ");

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateTodayTopValue(string id, string topvalue, string todaytop, string todayid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update station_infor set ");

            strSql.Append("topvalue='" + topvalue + "',todaytop='" + todaytop + "' ,todayid='" + todayid + "' ");

            strSql.Append(" where stationid='" + id + "' ");

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateAlarmcount(string id, string alarmcount)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update station_infor set ");

            strSql.Append("alarmcount='" + alarmcount + "'");

            strSql.Append(" where stationid='" + id + "' ");

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool ModifyDeviceCount(string stationid, int number)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select devicecount from station_infor where stationid=@stationid");
            
            MySqlParameter[] parameters = {
                    new MySqlParameter("@stationid", MySqlDbType.VarChar,50)
            };
            parameters[0].Value = stationid;

            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);

            int deviceCount = 0;

            if (ds.Tables[0].Rows.Count > 0)
            {
                deviceCount = Convert.ToInt32(ds.Tables[0].Rows[0]["devicecount"].ToString());
            }
            
            deviceCount += number;

            if (deviceCount > 0)
            {
                return UpdateDevicecount(stationid, Convert.ToString(deviceCount));
            } 
            else
            {
                return false;
            }
           
        }

          /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateDevicecount(string id,string devicecount)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update station_infor set ");
           
            strSql.Append("devicecount='"+devicecount+"'");
           
            strSql.Append(" where stationid='"+id+"' ");
            
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool UpdateHistoryValue(string id,string nowvalue, string today, string yestoday, string week, string month, string history,string id1,string id2,string id3,string id4,string id5,string topflag,string nowflag)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update station_infor set ");

            strSql.Append("topvalue='"+nowvalue+"',todaytop='"+today+"',yestodaytop='"+yestoday+"',weektop='"+week+"',monthtop='"+month+"',historytop='"+history+"',");
            strSql.Append("todayid='" + id1 + "',yestodayid='" + id2 + "',weekid='" + id3 + "',monthid='" + id4 + "',historyid='" + id5 + "',top_flag='"+topflag+"',now_flag='"+nowflag+"'");

            strSql.Append(" where stationid='" + id + "' ");

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string stationid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from station_infor ");
            strSql.Append(" where stationid=@stationid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = stationid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string stationidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from station_infor ");
            strSql.Append(" where stationid in (" + stationidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.station_infor GetModel(string stationid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select stationid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationname,devicecount,manager,phone,stationlevel,city,address,jingdu,weidu,topvalue,alarmcount,createtime,todaytop,yestodaytop,weektop,monthtop,historytop,todayid,yestodayid,weekid,monthid,historyid,now_flag,top_flag from station_infor ");
            strSql.Append(" where stationid=@stationid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@stationid", MySqlDbType.VarChar,50)			};
            parameters[0].Value = stationid;

            Maticsoft.Model.station_infor model = new Maticsoft.Model.station_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.station_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.station_infor model = new Maticsoft.Model.station_infor();
            if (row != null)
            {
                if (row["stationid"] != null)
                {
                    model.stationid = row["stationid"].ToString();
                }
                if (row["areaid"] != null)
                {
                    model.areaid = row["areaid"].ToString();
                }
                if (row["areaname"] != null)
                {
                    model.areaname = row["areaname"].ToString();
                }
                if (row["fenbuid"] != null)
                {
                    model.fenbuid = row["fenbuid"].ToString();
                }
                if (row["fenbuname"] != null)
                {
                    model.fenbuname = row["fenbuname"].ToString();
                }
                if (row["ywbid"] != null)
                {
                    model.ywbid = row["ywbid"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
                if (row["stationname"] != null)
                {
                    model.stationname = row["stationname"].ToString();
                }
                if (row["devicecount"] != null)
                {
                    model.devicecount = row["devicecount"].ToString();
                }
                if (row["manager"] != null)
                {
                    model.manager = row["manager"].ToString();
                }
                if (row["phone"] != null)
                {
                    model.phone = row["phone"].ToString();
                }
                if (row["stationlevel"] != null)
                {
                    model.stationlevel = row["stationlevel"].ToString();
                }
                if (row["city"] != null)
                {
                    model.city = row["city"].ToString();
                }
                if (row["address"] != null)
                {
                    model.address = row["address"].ToString();
                }
                if (row["jingdu"] != null)
                {
                    model.jingdu = row["jingdu"].ToString();
                }
                if (row["weidu"] != null)
                {
                    model.weidu = row["weidu"].ToString();
                }
                if (row["topvalue"] != null)
                {
                    model.topvalue = row["topvalue"].ToString();
                }
                if (row["alarmcount"] != null)
                {
                    model.alarmcount = row["alarmcount"].ToString();
                }
                if (row["createtime"] != null && row["createtime"].ToString() != "")
                {
                    model.createtime = DateTime.Parse(row["createtime"].ToString());
                }
                if (row["todaytop"] != null)
                {
                    model.todaytop = row["todaytop"].ToString();
                }
                if (row["yestodaytop"] != null)
                {
                    model.yestodaytop = row["yestodaytop"].ToString();
                }
                if (row["weektop"] != null)
                {
                    model.weektop = row["weektop"].ToString();
                }
                if (row["monthtop"] != null)
                {
                    model.monthtop = row["monthtop"].ToString();
                }
                if (row["historytop"] != null)
                {
                    model.historytop = row["historytop"].ToString();
                }
                if (row["todayid"] != null)
                {
                    model.todayid = row["todayid"].ToString();
                }
                if (row["yestodayid"] != null)
                {
                    model.yestodayid = row["yestodayid"].ToString();
                }
                if (row["weekid"] != null)
                {
                    model.weekid = row["weekid"].ToString();
                }
                if (row["monthid"] != null)
                {
                    model.monthid = row["monthid"].ToString();
                }
                if (row["historyid"] != null)
                {
                    model.historyid = row["historyid"].ToString();
                }
                if (row["now_flag"] != null)
                {
                    model.now_flag = row["now_flag"].ToString();
                }
                if (row["top_flag"] != null)
                {
                    model.top_flag = row["top_flag"].ToString();
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select stationid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationname,devicecount,manager,phone,stationlevel,city,address,jingdu,weidu,topvalue,alarmcount,createtime,todaytop,yestodaytop,weektop,monthtop,historytop,todayid,yestodayid,weekid,monthid,historyid,now_flag,top_flag ");
            strSql.Append(" FROM station_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM station_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.stationid desc");
            }
            strSql.Append(")AS Row, T.*  from station_infor T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "station_infor";
            parameters[1].Value = "stationid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

