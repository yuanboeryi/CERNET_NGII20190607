﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:temp_rase_infor
    /// </summary>
    public partial class temp_rase_infor
    {
        public temp_rase_infor()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string recordid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from temp_rase_infor");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = recordid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.temp_rase_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into temp_rase_infor(");
            strSql.Append("recordid,areaname,fenbuname,ywbname,stationname,buildingname,devicetype,devicename,areaid,fenbuid,ywbid,stationid,buildingid,deviceid,createtime,lasttemp,nowtemp,overtemp)");
            strSql.Append(" values (");
            strSql.Append("@recordid,@areaname,@fenbuname,@ywbname,@stationname,@buildingname,@devicetype,@devicename,@areaid,@fenbuid,@ywbid,@stationid,@buildingid,@deviceid,@createtime,@lasttemp,@nowtemp,@overtemp)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicetype", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@lasttemp", MySqlDbType.VarChar,255),
					new MySqlParameter("@nowtemp", MySqlDbType.VarChar,255),
					new MySqlParameter("@overtemp", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.recordid;
            parameters[1].Value = model.areaname;
            parameters[2].Value = model.fenbuname;
            parameters[3].Value = model.ywbname;
            parameters[4].Value = model.stationname;
            parameters[5].Value = model.buildingname;
            parameters[6].Value = model.devicetype;
            parameters[7].Value = model.devicename;
            parameters[8].Value = model.areaid;
            parameters[9].Value = model.fenbuid;
            parameters[10].Value = model.ywbid;
            parameters[11].Value = model.stationid;
            parameters[12].Value = model.buildingid;
            parameters[13].Value = model.deviceid;
            parameters[14].Value = model.createtime;
            parameters[15].Value = model.lasttemp;
            parameters[16].Value = model.nowtemp;
            parameters[17].Value = model.overtemp;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.temp_rase_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update temp_rase_infor set ");
            strSql.Append("areaname=@areaname,");
            strSql.Append("fenbuname=@fenbuname,");
            strSql.Append("ywbname=@ywbname,");
            strSql.Append("stationname=@stationname,");
            strSql.Append("buildingname=@buildingname,");
            strSql.Append("devicetype=@devicetype,");
            strSql.Append("devicename=@devicename,");
            strSql.Append("areaid=@areaid,");
            strSql.Append("fenbuid=@fenbuid,");
            strSql.Append("ywbid=@ywbid,");
            strSql.Append("stationid=@stationid,");
            strSql.Append("buildingid=@buildingid,");
            strSql.Append("deviceid=@deviceid,");
            strSql.Append("createtime=@createtime,");
            strSql.Append("lasttemp=@lasttemp,");
            strSql.Append("nowtemp=@nowtemp,");
            strSql.Append("overtemp=@overtemp");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicetype", MySqlDbType.VarChar,255),
					new MySqlParameter("@devicename", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
					new MySqlParameter("@deviceid", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@lasttemp", MySqlDbType.VarChar,255),
					new MySqlParameter("@nowtemp", MySqlDbType.VarChar,255),
					new MySqlParameter("@overtemp", MySqlDbType.VarChar,255),
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.areaname;
            parameters[1].Value = model.fenbuname;
            parameters[2].Value = model.ywbname;
            parameters[3].Value = model.stationname;
            parameters[4].Value = model.buildingname;
            parameters[5].Value = model.devicetype;
            parameters[6].Value = model.devicename;
            parameters[7].Value = model.areaid;
            parameters[8].Value = model.fenbuid;
            parameters[9].Value = model.ywbid;
            parameters[10].Value = model.stationid;
            parameters[11].Value = model.buildingid;
            parameters[12].Value = model.deviceid;
            parameters[13].Value = model.createtime;
            parameters[14].Value = model.lasttemp;
            parameters[15].Value = model.nowtemp;
            parameters[16].Value = model.overtemp;
            parameters[17].Value = model.recordid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string recordid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from temp_rase_infor ");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = recordid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string recordidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from temp_rase_infor ");
            strSql.Append(" where recordid in (" + recordidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.temp_rase_infor GetModel(string recordid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select recordid,areaname,fenbuname,ywbname,stationname,buildingname,devicetype,devicename,areaid,fenbuid,ywbid,stationid,buildingid,deviceid,createtime,lasttemp,nowtemp,overtemp from temp_rase_infor ");
            strSql.Append(" where recordid=@recordid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@recordid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = recordid;

            Maticsoft.Model.temp_rase_infor model = new Maticsoft.Model.temp_rase_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.temp_rase_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.temp_rase_infor model = new Maticsoft.Model.temp_rase_infor();
            if (row != null)
            {
                if (row["recordid"] != null)
                {
                    model.recordid = row["recordid"].ToString();
                }
                if (row["areaname"] != null)
                {
                    model.areaname = row["areaname"].ToString();
                }
                if (row["fenbuname"] != null)
                {
                    model.fenbuname = row["fenbuname"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
                if (row["stationname"] != null)
                {
                    model.stationname = row["stationname"].ToString();
                }
                if (row["buildingname"] != null)
                {
                    model.buildingname = row["buildingname"].ToString();
                }
                if (row["devicetype"] != null)
                {
                    model.devicetype = row["devicetype"].ToString();
                }
                if (row["devicename"] != null)
                {
                    model.devicename = row["devicename"].ToString();
                }
                if (row["areaid"] != null)
                {
                    model.areaid = row["areaid"].ToString();
                }
                if (row["fenbuid"] != null)
                {
                    model.fenbuid = row["fenbuid"].ToString();
                }
                if (row["ywbid"] != null)
                {
                    model.ywbid = row["ywbid"].ToString();
                }
                if (row["stationid"] != null)
                {
                    model.stationid = row["stationid"].ToString();
                }
                if (row["buildingid"] != null)
                {
                    model.buildingid = row["buildingid"].ToString();
                }
                if (row["deviceid"] != null)
                {
                    model.deviceid = row["deviceid"].ToString();
                }
                if (row["createtime"] != null && row["createtime"].ToString() != "")
                {
                    model.createtime = DateTime.Parse(row["createtime"].ToString());
                }
                if (row["lasttemp"] != null)
                {
                    model.lasttemp = row["lasttemp"].ToString();
                }
                if (row["nowtemp"] != null)
                {
                    model.nowtemp = row["nowtemp"].ToString();
                }
                if (row["overtemp"] != null)
                {
                    model.overtemp = row["overtemp"].ToString();
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select recordid,areaname,fenbuname,ywbname,stationname,buildingname,devicetype,devicename,areaid,fenbuid,ywbid,stationid,buildingid,deviceid,createtime,lasttemp,nowtemp,overtemp ");
            strSql.Append(" FROM temp_rase_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM temp_rase_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.recordid desc");
            }
            strSql.Append(")AS Row, T.*  from temp_rase_infor T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "temp_rase_infor";
            parameters[1].Value = "recordid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

