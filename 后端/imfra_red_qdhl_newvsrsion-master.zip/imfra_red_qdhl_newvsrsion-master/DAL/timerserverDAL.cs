﻿using Maticsoft.DBUtility;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace Maticsoft.DAL
{

    /// <summary>
    /// 执行Sql
    /// </summary>
   public class timerserverDAL
    {


        public void CreateTable()
        {
            string Name = DateTime.Now.ToString("yyyyMM");
            string NewName = "image_record_history" + Name;
            int IsContions=ConinusTableCreateTable(NewName);
            if (IsContions==0)
            {
                
                string CreateSql = "CREATE TABLE  " + NewName + "  SELECT * FROM" + "  image_record_history  " + "  WHERE 1=2 ";
                int Count = DbHelperMySQL.ExecuteSql(CreateSql);
            }
        }

        /// <summary>
        /// 是否存在 image_record_history_copy_copy
        /// </summary>
        /// <returns></returns>
        public int ContinusTableSour()
        {
            return 0;
        }
        /// <summary>
        /// 是否存在需要创建的表
        /// </summary>
        /// <returns></returns>
        public int ConinusTableCreateTable(string CreateTableName)
        {
            int GetIsCreate = 1;
            //获取AppSetting字符串
            string AppSetting=ConfigurationManager.AppSettings["ConnectionString"];
            //AppSetting = "Server=116.255.207.148;User Id=test;Password=test;Persist Security Info=True;Database=infrared_net;Charset=utf8";
            int IndexOf=AppSetting.IndexOf("Database=");

            //Database = infrared_net; Charset = utf8
            AppSetting =AppSetting.Remove(0, IndexOf);
            int IndexOfX=AppSetting.IndexOf(";");
            //Database = infrared_net
            AppSetting = AppSetting.Remove(IndexOfX,AppSetting.Length-IndexOfX);
            AppSetting=AppSetting.Replace("Database","");
            AppSetting = AppSetting.Replace("=", "");
            AppSetting = AppSetting.Trim(); /*infrared_net*/
            string Sql = "SELECT COUNT(*)as Count FROM information_schema.TABLES WHERE table_schema = '"+AppSetting+ "' and table_name = '"+CreateTableName+"'";
            //执行Sql
            var dataSet=DbHelperMySQL.Query(Sql);
            if (dataSet.Tables.Count>=1)
            {
                // 获取第一个Table
                var TableOne = dataSet.Tables[0];
                GetIsCreate= Convert.ToInt32(TableOne.Rows[0]["Count"].ToString());
            }
            return GetIsCreate;
        }
    }
}
