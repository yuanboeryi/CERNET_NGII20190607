﻿using System;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.DAL
{
    /// <summary>
    /// 数据访问类:ysd_infor
    /// </summary>
    public partial class ysd_infor
    {
        public ysd_infor()
        { }
        #region  BasicMethod

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(string ysdid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from ysd_infor");
            strSql.Append(" where ysdid=@ysdid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@ysdid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = ysdid;

            return DbHelperMySQL.Exists(strSql.ToString(), parameters);
        }


        public Maticsoft.Model.ysd_infor GetModelByMachine(string machineid, string ysdname)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * from ysd_infor ");
            strSql.Append(" where machineid=@machineid and ysdname=@ysdname ");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdname", MySqlDbType.VarChar,255)};
            parameters[0].Value = machineid;
            parameters[1].Value = ysdname;

            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Maticsoft.Model.ysd_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into ysd_infor(");
            strSql.Append("ysdid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdname,iskeypoint,isroundpoint,createtime,orderindex)");
            strSql.Append(" values (");
            strSql.Append("@ysdid,@areaid,@areaname,@fenbuid,@fenbuname,@ywbid,@ywbname,@stationid,@stationname,@buildingid,@buildingname,@machineid,@machinename,@ysdname,@iskeypoint,@isroundpoint,@createtime,@orderindex)");
            MySqlParameter[] parameters = {
					new MySqlParameter("@ysdid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
					new MySqlParameter("@ysdname", MySqlDbType.VarChar,255),
					new MySqlParameter("@iskeypoint", MySqlDbType.VarChar,255),
					new MySqlParameter("@isroundpoint", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@orderindex", MySqlDbType.Double)};
            parameters[0].Value = model.ysdid;
            parameters[1].Value = model.areaid;
            parameters[2].Value = model.areaname;
            parameters[3].Value = model.fenbuid;
            parameters[4].Value = model.fenbuname;
            parameters[5].Value = model.ywbid;
            parameters[6].Value = model.ywbname;
            parameters[7].Value = model.stationid;
            parameters[8].Value = model.stationname;
            parameters[9].Value = model.buildingid;
            parameters[10].Value = model.buildingname;
            parameters[11].Value = model.machineid;
            parameters[12].Value = model.machinename;
            parameters[13].Value = model.ysdname;
            parameters[14].Value = model.iskeypoint;
            parameters[15].Value = model.isroundpoint;
            parameters[16].Value = model.createtime;
            parameters[17].Value = model.orderindex;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateBuilding(string id, string name, string idnew,string machineid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update ysd_infor set ");
            strSql.Append("buildingname='" + name + "',buildingid='" + idnew + "'");
            strSql.Append(" where machineid='" + machineid + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());



            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool UpdateBuilding1(string id, string name, string idnew)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update ysd_infor set ");
            strSql.Append("buildingname='" + name + "',buildingid='" + idnew + "'");
            strSql.Append(" where buildingid='" + id + "' ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());



            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Maticsoft.Model.ysd_infor model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update ysd_infor set ");
            strSql.Append("areaid=@areaid,");
            strSql.Append("areaname=@areaname,");
            strSql.Append("fenbuid=@fenbuid,");
            strSql.Append("fenbuname=@fenbuname,");
            strSql.Append("ywbid=@ywbid,");
            strSql.Append("ywbname=@ywbname,");
            strSql.Append("stationid=@stationid,");
            strSql.Append("stationname=@stationname,");
            strSql.Append("buildingid=@buildingid,");
            strSql.Append("buildingname=@buildingname,");
            strSql.Append("machineid=@machineid,");
            strSql.Append("machinename=@machinename,");
            strSql.Append("ysdname=@ysdname,");
            strSql.Append("iskeypoint=@iskeypoint,");
            strSql.Append("isroundpoint=@isroundpoint,");
            strSql.Append("createtime=@createtime,");
            strSql.Append("orderindex=@orderindex");
            strSql.Append(" where ysdid=@ysdid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@areaid", MySqlDbType.VarChar,255),
					new MySqlParameter("@areaname", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuid", MySqlDbType.VarChar,255),
					new MySqlParameter("@fenbuname", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbid", MySqlDbType.VarChar,255),
					new MySqlParameter("@ywbname", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationid", MySqlDbType.VarChar,255),
					new MySqlParameter("@stationname", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
					new MySqlParameter("@buildingname", MySqlDbType.VarChar,255),
					new MySqlParameter("@machineid", MySqlDbType.VarChar,255),
					new MySqlParameter("@machinename", MySqlDbType.VarChar,255),
					new MySqlParameter("@ysdname", MySqlDbType.VarChar,255),
					new MySqlParameter("@iskeypoint", MySqlDbType.VarChar,255),
					new MySqlParameter("@isroundpoint", MySqlDbType.VarChar,255),
					new MySqlParameter("@createtime", MySqlDbType.DateTime),
					new MySqlParameter("@orderindex", MySqlDbType.Double),
					new MySqlParameter("@ysdid", MySqlDbType.VarChar,255)};
            parameters[0].Value = model.areaid;
            parameters[1].Value = model.areaname;
            parameters[2].Value = model.fenbuid;
            parameters[3].Value = model.fenbuname;
            parameters[4].Value = model.ywbid;
            parameters[5].Value = model.ywbname;
            parameters[6].Value = model.stationid;
            parameters[7].Value = model.stationname;
            parameters[8].Value = model.buildingid;
            parameters[9].Value = model.buildingname;
            parameters[10].Value = model.machineid;
            parameters[11].Value = model.machinename;
            parameters[12].Value = model.ysdname;
            parameters[13].Value = model.iskeypoint;
            parameters[14].Value = model.isroundpoint;
            parameters[15].Value = model.createtime;
            parameters[16].Value = model.orderindex;
            parameters[17].Value = model.ysdid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(string ysdid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from ysd_infor ");
            strSql.Append(" where ysdid=@ysdid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@ysdid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = ysdid;

            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string ysdidlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from ysd_infor ");
            strSql.Append(" where ysdid in (" + ysdidlist + ")  ");
            int rows = DbHelperMySQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string getYsdid(string buildingid, string machineid, string ysdname)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ysdid from ysd_infor ");
            strSql.Append("where  buildingid=@buildingid and ");
            strSql.Append("       machineid=@machineid   and ");
            strSql.Append("       ysdname=@ysdname");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@buildingid", MySqlDbType.VarChar,255),
                    new MySqlParameter("@machineid",  MySqlDbType.VarChar,255),
                    new MySqlParameter("@ysdname",    MySqlDbType.VarChar,255),
            };
            parameters[0].Value = buildingid;
            parameters[1].Value = machineid;
            parameters[2].Value = ysdname;

            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return ds.Tables[0].Rows[0]["ysdid"].ToString();
            }
            else
            {
                return "";
            }
        }

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.ysd_infor GetModel(string ysdid)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ysdid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdname,iskeypoint,isroundpoint,createtime,orderindex from ysd_infor ");
            strSql.Append(" where ysdid=@ysdid ");
            MySqlParameter[] parameters = {
					new MySqlParameter("@ysdid", MySqlDbType.VarChar,255)			};
            parameters[0].Value = ysdid;

            Maticsoft.Model.ysd_infor model = new Maticsoft.Model.ysd_infor();
            DataSet ds = DbHelperMySQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Maticsoft.Model.ysd_infor DataRowToModel(DataRow row)
        {
            Maticsoft.Model.ysd_infor model = new Maticsoft.Model.ysd_infor();
            if (row != null)
            {
                if (row["ysdid"] != null)
                {
                    model.ysdid = row["ysdid"].ToString();
                }
                if (row["areaid"] != null)
                {
                    model.areaid = row["areaid"].ToString();
                }
                if (row["areaname"] != null)
                {
                    model.areaname = row["areaname"].ToString();
                }
                if (row["fenbuid"] != null)
                {
                    model.fenbuid = row["fenbuid"].ToString();
                }
                if (row["fenbuname"] != null)
                {
                    model.fenbuname = row["fenbuname"].ToString();
                }
                if (row["ywbid"] != null)
                {
                    model.ywbid = row["ywbid"].ToString();
                }
                if (row["ywbname"] != null)
                {
                    model.ywbname = row["ywbname"].ToString();
                }
                if (row["stationid"] != null)
                {
                    model.stationid = row["stationid"].ToString();
                }
                if (row["stationname"] != null)
                {
                    model.stationname = row["stationname"].ToString();
                }
                if (row["buildingid"] != null)
                {
                    model.buildingid = row["buildingid"].ToString();
                }
                if (row["buildingname"] != null)
                {
                    model.buildingname = row["buildingname"].ToString();
                }
                if (row["machineid"] != null)
                {
                    model.machineid = row["machineid"].ToString();
                }
                if (row["machinename"] != null)
                {
                    model.machinename = row["machinename"].ToString();
                }
                if (row["ysdname"] != null)
                {
                    model.ysdname = row["ysdname"].ToString();
                }
                if (row["iskeypoint"] != null)
                {
                    model.iskeypoint = row["iskeypoint"].ToString();
                }
                if (row["isroundpoint"] != null)
                {
                    model.isroundpoint = row["isroundpoint"].ToString();
                }
                if (row["createtime"] != null && row["createtime"].ToString() != "")
                {
                    model.createtime = DateTime.Parse(row["createtime"].ToString());
                }
                //model.orderindex=row["orderindex"].ToString();
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            //  strSql.Append("select ysdid,areaid,areaname,fenbuid,fenbuname,ywbid,ywbname,stationid,stationname,buildingid,buildingname,machineid,machinename,ysdname,iskeypoint,isroundpoint,createtime,orderindex ");
            strSql.Append("select * ");
            strSql.Append("from ysd_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM ysd_infor ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.ysdid desc");
            }
            strSql.Append(")AS Row, T.*  from ysd_infor T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperMySQL.Query(strSql.ToString());
        }

        /*
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        {
            MySqlParameter[] parameters = {
                    new MySqlParameter("@tblName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@fldName", MySqlDbType.VarChar, 255),
                    new MySqlParameter("@PageSize", MySqlDbType.Int32),
                    new MySqlParameter("@PageIndex", MySqlDbType.Int32),
                    new MySqlParameter("@IsReCount", MySqlDbType.Bit),
                    new MySqlParameter("@OrderType", MySqlDbType.Bit),
                    new MySqlParameter("@strWhere", MySqlDbType.VarChar,1000),
                    };
            parameters[0].Value = "ysd_infor";
            parameters[1].Value = "ysdid";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;	
            return DbHelperMySQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
        }*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

