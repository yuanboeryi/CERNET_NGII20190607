﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;

namespace FileSystemWatcher
{
    public static class App
    {
        public static CookieContainer cc = new CookieContainer();
        public static int BAIDU_QPS = 0;
        public static string BAIDU_TOKEN = "";
    }
}
