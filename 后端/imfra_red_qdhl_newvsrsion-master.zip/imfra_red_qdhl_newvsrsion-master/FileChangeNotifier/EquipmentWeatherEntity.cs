﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FileSystemWatcher
{
    class EquipmentWeatherEntity
    {
        private bool InstanceFieldsInitialized = false;

        public EquipmentWeatherEntity()
        {
            if (!InstanceFieldsInitialized)
            {
                InitializeInstanceFields();
                InstanceFieldsInitialized = true;
            }
        }

        private void InitializeInstanceFields()
        {
            lastModifyTime = createTime;
        }


        /// <summary>
        /// 主键
        /// </summary>
        private long _wid;
        /// <summary>
        /// 版本号
        /// </summary>
        private long _optLock;
        /// <summary>
        /// 创建时间
        /// </summary>
        private long _createTime = DateTimeHelper.CurrentUnixTimeMillis();
        /// <summary>
        /// 最后修改时间
        /// </summary>
        private long _lastModifyTime;
        /// <summary>
        /// 逻辑删除标记
        /// </summary>
        private bool _isDeleted = false;

        /// <summary>
        /// 监控ID
        /// </summary>
        private long _montioneid;
        /// <summary>
        /// 设备号
        /// </summary>
        private string _equipmentnumber;
        /// <summary>
        /// 电压等级
        /// </summary>
        private string _voltagelevel;
        /// <summary>
        /// 线路名称
        /// </summary>
        private string _linename;
        /// <summary>
        /// 杆塔号
        /// </summary>
        private string _towernumber;
        /// <summary>
        /// 纬度
        /// </summary>
        private double _lat;
        /// <summary>
        /// 经度
        /// </summary>
        private double _lng;
        /// <summary>
        /// 查询日期
        /// </summary>
        private DateTime _querytime;
        /// <summary>
        /// 图像文件名
        /// </summary>
        private string _picname;
        /// <summary>
        /// 温度
        /// </summary>
        private double _temperature;
        /// <summary>
        /// 气压
        /// </summary>
        private double _pres;
        /// <summary>
        /// 相对湿度
        /// </summary>
        private double _humidity;
        /// <summary>
        /// 风向
        /// </summary>
        private double _winddirection;
        /// <summary>
        /// 风速
        /// </summary>
        private double _windspeed;
        /// <summary>
        /// 最近的降水带距离
        /// </summary>
        private double _nearestprecdistance;
        /// <summary>
        /// 最近的降水带降水强度
        /// </summary>
        private double _nearestprecintensity;
        /// <summary>
        /// 本地降水强度
        /// </summary>
        private double _localprecintensity;
        /// <summary>
        /// 本地降水观测的数据源
        /// </summary>
        private string _localprecdatasource;
        /// <summary>
        /// 云量
        /// </summary>
        private double _cloudrate;
        /// <summary>
        /// 向下短波辐射通量
        /// </summary>
        private double _dswrf;
        /// <summary>
        /// 能见度
        /// </summary>
        private double _visibility;
        /// <summary>
        /// 主要天气现象
        /// </summary>
        private string _skycon;
        /// <summary>
        /// 舒适度指数
        /// </summary>
        private double _comfortindex;
        /// <summary>
        /// 舒适度自然语言描述
        /// </summary>
        private string _comfortdesc;
        /// <summary>
        /// 紫外线指数
        /// </summary>
        private double _ultravioletindex;
        /// <summary>
        /// 紫外线自然语言描述
        /// </summary>
        private string _ultravioletdesc;
        /// <summary>
        /// pm25质量浓度值
        /// </summary>
        private double _pm25;
        /// <summary>
        /// pm10质量浓度值
        /// </summary>
        private double _pm10;
        /// <summary>
        /// 臭氧
        /// </summary>
        private double _o3;
        /// <summary>
        /// 二氧化氮
        /// </summary>
        private double _no2;
        /// <summary>
        /// 二氧化硫
        /// </summary>
        private double _so2;
        /// <summary>
        /// 一氧化碳
        /// </summary>
        private double _co;
        /// <summary>
        /// AQI
        /// </summary>
        private double _aqi;
        /// <summary>
        /// 实时天气数据
        /// </summary>
        private string _realsrc;
        /// <summary>
        /// 预警信息
        /// </summary>
        private string _alertsrc;
        /// <summary>
        /// 天气原始数据
        /// </summary>
        private string _srcdesc;
        /// <summary>
        /// 天气预警描述
        /// </summary>
        private string _alarmdesc;
        /// <summary>
        /// 预留字段1
        /// </summary>
        private string _r1;
        /// <summary>
        /// 预留字段2
        /// </summary>
        private string _r2;
        /// <summary>
        /// 预留字段3
        /// </summary>
        private string _r3;

        /// <returns> the wid </returns>
        public virtual long wid
        {
            get
            {
                return _wid;
            }
            set
            {
                this._wid = value;
            }
        }


        /// <returns> the optLock </returns>
        public virtual long optLock
        {
            get
            {
                return _optLock;
            }
            set
            {
                this._optLock = value;
            }
        }


        /// <returns> the createTime </returns>
        public virtual long createTime
        {
            get
            {
                return _createTime;
            }
            set
            {
                this._createTime = value;
            }
        }


        /// <returns> the lastModifyTime </returns>
        public virtual long lastModifyTime
        {
            get
            {
                return _lastModifyTime;
            }
            set
            {
                this._lastModifyTime = value;
            }
        }


        /// <returns> the isDeleted </returns>
        public virtual bool isDeleted
        {
            get
            {
                return _isDeleted;
            }
            set
            {
                this._isDeleted = value;
            }
        }


        /// <returns> the montioneid </returns>
        public virtual long montioneid
        {
            get
            {
                return _montioneid;
            }
            set
            {
                this._montioneid = value;
            }
        }


        /// <returns> the equipmentnumber </returns>
        public virtual string equipmentnumber
        {
            get
            {
                return _equipmentnumber;
            }
            set
            {
                this._equipmentnumber = value;
            }
        }

        public virtual string voltagelevel
        {
            get
            {
                return _voltagelevel;
            }
            set
            {
                this._voltagelevel = value;
            }
        }
        public virtual string linename
        {
            get
            {
                return _linename;
            }
            set
            {
                this._linename = value;
            }
        }
        public virtual string towernumber
        {
            get
            {
                return _towernumber;
            }
            set
            {
                this._towernumber = value;
            }
        }
        public virtual double lat
        {
            get
            {
                return _lat;
            }
            set
            {
                this._lat = value;
            }
        }
        public virtual double lng
        {
            get
            {
                return _lng;
            }
            set
            {
                this._lng = value;
            }
        }
        public virtual DateTime querytime
        {
            get
            {
                return _querytime;
            }
            set
            {
                this._querytime = value;
            }
        }
        public virtual string picname
        {
            get
            {
                return _picname;
            }
            set
            {
                this._picname = value;
            }
        }
        public virtual double temperature
        {
            get
            {
                return _temperature;
            }
            set
            {
                this._temperature = value;
            }
        }
        public virtual double pres
        {
            get
            {
                return _pres;
            }
            set
            {
                this._pres = value;
            }
        }
        public virtual double humidity
        {
            get
            {
                return _humidity;
            }
            set
            {
                this._humidity = value;
            }
        }
        public virtual double winddirection
        {
            get
            {
                return _winddirection;
            }
            set
            {
                this._winddirection = value;
            }
        }
        public virtual double windspeed
        {
            get
            {
                return _windspeed;
            }
            set
            {
                this._windspeed = value;
            }
        }
        public virtual double nearestprecdistance
        {
            get
            {
                return _nearestprecdistance;
            }
            set
            {
                this._nearestprecdistance = value;
            }
        }
        public virtual double nearestprecintensity
        {
            get
            {
                return _nearestprecintensity;
            }
            set
            {
                this._nearestprecintensity = value;
            }
        }
        public virtual double localprecintensity
        {
            get
            {
                return _localprecintensity;
            }
            set
            {
                this._localprecintensity = value;
            }
        }
        public virtual string localprecdatasource
        {
            get
            {
                return _localprecdatasource;
            }
            set
            {
                this._localprecdatasource = value;
            }
        }
        public virtual double cloudrate
        {
            get
            {
                return _cloudrate;
            }
            set
            {
                this._cloudrate = value;
            }
        }
        public virtual double dswrf
        {
            get
            {
                return _dswrf;
            }
            set
            {
                this._dswrf = value;
            }
        }
        public virtual double visibility
        {
            get
            {
                return _visibility;
            }
            set
            {
                this._visibility = value;
            }
        }
        public virtual string skycon
        {
            get
            {
                return _skycon;
            }
            set
            {
                this._skycon = value;
            }
        }
        public virtual double comfortindex
        {
            get
            {
                return _comfortindex;
            }
            set
            {
                this._comfortindex = value;
            }
        }
        public virtual string comfortdesc
        {
            get
            {
                return _comfortdesc;
            }
            set
            {
                this._comfortdesc = value;
            }
        }
        public virtual double ultravioletindex
        {
            get
            {
                return _ultravioletindex;
            }
            set
            {
                this._ultravioletindex = value;
            }
        }
        public virtual string ultravioletdesc
        {
            get
            {
                return _ultravioletdesc;
            }
            set
            {
                this._ultravioletdesc = value;
            }
        }
        public virtual double pm25
        {
            get
            {
                return _pm25;
            }
            set
            {
                this._pm25 = value;
            }
        }
        public virtual double pm10
        {
            get
            {
                return _pm10;
            }
            set
            {
                this._pm10 = value;
            }
        }
        public virtual double o3
        {
            get
            {
                return _o3;
            }
            set
            {
                this._o3 = value;
            }
        }
        public virtual double no2
        {
            get
            {
                return _no2;
            }
            set
            {
                this._no2 = value;
            }
        }
        public virtual double so2
        {
            get
            {
                return _so2;
            }
            set
            {
                this._so2 = value;
            }
        }
        public virtual double co
        {
            get
            {
                return _co;
            }
            set
            {
                this._co = value;
            }
        }
        public virtual double aqi
        {
            get
            {
                return _aqi;
            }
            set
            {
                this._aqi = value;
            }
        }
        public virtual string realsrc
        {
            get
            {
                return _realsrc;
            }
            set
            {
                this._realsrc = value;
            }
        }
        public virtual string alertsrc
        {
            get
            {
                return _alertsrc;
            }
            set
            {
                this._alertsrc = value;
            }
        }
        public virtual string srcdesc
        {
            get
            {
                return _srcdesc;
            }
            set
            {
                this._srcdesc = value;
            }
        }

        public virtual string alarmdesc
        {
            get
            {
                return _alarmdesc;
            }
            set
            {
                this._alarmdesc = value;
            }
        }
        public virtual string r1
        {
            get
            {
                return _r1;
            }
            set
            {
                this._r1 = value;
            }
        }
        public virtual string r2
        {
            get
            {
                return _r2;
            }
            set
            {
                this._r2 = value;
            }
        }
        public virtual string r3
        {
            get
            {
                return _r3;
            }
            set
            {
                this._r3 = value;
            }
        }

    }
    internal static class DateTimeHelper
    {
        private static readonly System.DateTime Jan1st1970 = new System.DateTime(1970, 1, 1, 0, 0, 0, System.DateTimeKind.Utc);
        public static long CurrentUnixTimeMillis()
        {
            return (long)(System.DateTime.UtcNow - Jan1st1970).TotalMilliseconds;
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public class SkyconItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class CloudrateItem
    {
        /// <summary>
        /// 
        /// </summary>
        public int value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class AqiItem
    {
        /// <summary>
        /// 
        /// </summary>
        public int value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class DswrfItem
    {
        /// <summary>
        /// 
        /// </summary>
        public int value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class VisibilityItem
    {
        /// <summary>
        /// 
        /// </summary>
        public double value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class HumidityItem
    {
        /// <summary>
        /// 
        /// </summary>
        public double value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class PresItem
    {
        /// <summary>
        /// 
        /// </summary>
        public double value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class Pm25Item
    {
        /// <summary>
        /// 
        /// </summary>
        public int value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class PrecipitationItem
    {
        /// <summary>
        /// 
        /// </summary>
        public int value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class WindItem
    {
        /// <summary>
        /// 
        /// </summary>
        public int direction { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double speed { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class TemperatureItem
    {
        /// <summary>
        /// 
        /// </summary>
        public double value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class Hourly
    {
        /// <summary>
        /// 
        /// </summary>
        public string status { get; set; }
        /// <summary>
        /// 未来24小时多云
        /// </summary>
        public string description { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<SkyconItem> skycon { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<CloudrateItem> cloudrate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<AqiItem> aqi { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<DswrfItem> dswrf { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<VisibilityItem> visibility { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<HumidityItem> humidity { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<PresItem> pres { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Pm25Item> pm25 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<PrecipitationItem> precipitation { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<WindItem> wind { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<TemperatureItem> temperature { get; set; }
    }

    public class Nearest
    {
        /// <summary>
        /// 
        /// </summary>
        public string status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double distance { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double intensity { get; set; }
    }

    public class Local
    {
        /// <summary>
        /// 
        /// </summary>
        public string status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double intensity { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datasource { get; set; }
    }

    public class Precipitation
    {
        /// <summary>
        /// 
        /// </summary>
        public Nearest nearest { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Local local { get; set; }
    }

    public class Ultraviolet
    {
        /// <summary>
        /// 
        /// </summary>
        public double index { get; set; }
        /// <summary>
        /// 强
        /// </summary>
        public string desc { get; set; }
    }

    public class Comfort
    {
        /// <summary>
        /// 
        /// </summary>
        public double index { get; set; }
        /// <summary>
        /// 凉爽
        /// </summary>
        public string desc { get; set; }
    }

    public class Wind
    {
        /// <summary>
        /// 
        /// </summary>
        public double direction { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double speed { get; set; }
    }

    public class Realtime
    {
        /// <summary>
        /// 
        /// </summary>
        public string status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double o3 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double co { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double temperature { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double pm10 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string skycon { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double cloudrate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Precipitation precipitation { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double dswrf { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double visibility { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double humidity { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double so2 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Ultraviolet ultraviolet { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double pres { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double aqi { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int pm25 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double no2 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double apparent_temperature { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Comfort comfort { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Wind wind { get; set; }
    }
    /*
    public class ComfortItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string index { get; set; }
        /// <summary>
        /// 舒适
        /// </summary>
        public string desc { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class Skycon_20h_32hItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string value { get; set; }
    }

    public class TemperatureItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int max { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double avg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int min { get; set; }
    }

    public class DswrfItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int max { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double avg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int min { get; set; }
    }

    public class CloudrateItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int max { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double avg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int min { get; set; }
    }

    public class AqiItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int max { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double avg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int min { get; set; }
    }

    public class SkyconItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string value { get; set; }
    }

    public class VisibilityItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double max { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double avg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double min { get; set; }
    }

    public class HumidityItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double max { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double avg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double min { get; set; }
    }

    public class Sunset
    {
        /// <summary>
        /// 
        /// </summary>
        public string time { get; set; }
    }

    public class Sunrise
    {
        /// <summary>
        /// 
        /// </summary>
        public string time { get; set; }
    }

    public class AstroItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Sunset sunset { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Sunrise sunrise { get; set; }
    }

    public class ColdRiskItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string index { get; set; }
        /// <summary>
        /// 极易发
        /// </summary>
        public string desc { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class UltravioletItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string index { get; set; }
        /// <summary>
        /// 强
        /// </summary>
        public string desc { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class PresItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double max { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double avg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double min { get; set; }
    }

    public class Pm25Item
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int max { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double avg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int min { get; set; }
    }

    public class DressingItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string index { get; set; }
        /// <summary>
        /// 温暖
        /// </summary>
        public string desc { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class CarWashingItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string index { get; set; }
        /// <summary>
        /// 较不适宜
        /// </summary>
        public string desc { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datetime { get; set; }
    }

    public class PrecipitationItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int max { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int avg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int min { get; set; }
    }

    public class Max
    {
        /// <summary>
        /// 
        /// </summary>
        public double direction { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double speed { get; set; }
    }

    public class Avg
    {
        /// <summary>
        /// 
        /// </summary>
        public double direction { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double speed { get; set; }
    }

    public class Min
    {
        /// <summary>
        /// 
        /// </summary>
        public double direction { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double speed { get; set; }
    }

    public class WindItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Max max { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Avg avg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Min min { get; set; }
    }

    public class Skycon_08h_20hItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string value { get; set; }
    }

    public class Daily
    {
        /// <summary>
        /// 
        /// </summary>
        public string status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<ComfortItem> comfort { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Skycon_20h_32hItem> skycon_20h_32h { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<TemperatureItem> temperature { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<DswrfItem> dswrf { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<CloudrateItem> cloudrate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<AqiItem> aqi { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<SkyconItem> skycon { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<VisibilityItem> visibility { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<HumidityItem> humidity { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<AstroItem> astro { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<ColdRiskItem> coldRisk { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<UltravioletItem> ultraviolet { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<PresItem> pres { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Pm25Item> pm25 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<DressingItem> dressing { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<CarWashingItem> carWashing { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<PrecipitationItem> precipitation { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<WindItem> wind { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Skycon_08h_20hItem> skycon_08h_20h { get; set; }
    }

    public class Minutely
    {
        /// <summary>
        /// 
        /// </summary>
        public string status { get; set; }
        /// <summary>
        /// 未来两小时不会下雨，放心出门吧
        /// </summary>
        public string description { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<int> probability { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string datasource { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<int> precipitation_2h { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<int> precipitation { get; set; }
    }

    public class Result
    {
        /// <summary>
        /// 
        /// </summary>
        public Hourly hourly { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Realtime realtime { get; set; }
        /// <summary>
        /// 未来两小时不会下雨，放心出门吧
        /// </summary>
        public string forecast_keypoint { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int primary { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Daily daily { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Minutely minutely { get; set; }
    }

    public class Root
    {
        /// <summary>
        /// 
        /// </summary>
        public string status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string lang { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Result result { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int server_time { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string api_status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int tzshift { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string api_version { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string unit { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<double> location { get; set; }
    }
     */
}
