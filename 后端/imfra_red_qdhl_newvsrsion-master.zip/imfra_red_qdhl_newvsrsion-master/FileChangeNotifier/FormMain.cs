﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Management;
using System.Diagnostics;
using System.Drawing.Printing;
using FileSystemWatcher;
using System.IO.Compression;
using System.Threading;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net;
using System.Web;
using System.Globalization;
namespace FileChangeNotifier
{
    public partial class frmNotifier : Form
    {
        private StringBuilder m_Sb;
        private bool m_bDirty;
        private System.IO.FileSystemWatcher m_Watcher;
        private bool m_bIsWatching;


        private string m_strOutPath;
        bool UseRawHelper = false;
        Font printFont = new Font("Arial", 10);
        System.IO.StreamReader streamToPrint = null;
        //string EtichettaTXTPath = Application.StartupPath+@"\etichetta_zebra.txt";
        //string PrinterName = @"zebra";
        System.Drawing.Printing.PrintDocument printDocument1;
        //private JavaInterface m_JavaInterface;
        private IniFiles m_ini;
        private string m_strMyPicHttpServer;
        private string m_strDataServerIp;
        private int m_iCheckStatus = 0;
        private string httpurl;

        public frmNotifier()
        {
            InitializeComponent();
            m_Sb = new StringBuilder();
            m_bDirty = false;
            m_bIsWatching = false;
            m_ini = new IniFiles(AppDomain.CurrentDomain.BaseDirectory + "Config.ini");

            m_strMyPicHttpServer = m_ini.IniReadvalue("Set", "MyPicHttpServer");
            m_strDataServerIp = m_ini.IniReadvalue("Set", "DataServerIp");
            //m_JavaInterface = new JavaInterface(false);

            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(OnFormClosing);

            string strIn = "";
            string strOut = "";

            strIn = m_ini.IniReadvalue("Set", "MointerIn");
            strOut = m_ini.IniReadvalue("Set", "MointerOut");
            httpurl = m_ini.IniReadvalue("Set", "imagethhpip");

            textBox1.Text = httpurl;
            txtFile.Text = strIn;// @"D:\My Prj\Src\Workspaces\MyEclipse Professional\.metadata\.me_tcat\webapps\InsWeb\bugImages\";// @"c:\SafeSupPic\";
            string dir = txtFile.Text;
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
            m_strOutPath = strOut;// @"Z:\E\SafeSupPic\";



            //string ss = descUnicode("\u672a\u676524\u5c0f\u65f6\u591a\u4e91");
            //string ss1 = ss;
        }



        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (DialogResult.No == MessageBox.Show("此程序不允许退出?", "提示!", MessageBoxButtons.OK))
            {
                this.WindowState = FormWindowState.Minimized;

                e.Cancel = true;
            }
        }

        private void btnWatchFile_Click(object sender, EventArgs e)
        {
            if (m_bIsWatching)
            {
                m_bIsWatching = false;
                m_Watcher.EnableRaisingEvents = false;
                m_Watcher.Dispose();
                btnWatchFile.BackColor = Color.LightSkyBlue;
                btnWatchFile.Text = "开始监听";
                timer1.Enabled = false;
            }
            else
            {
                m_bIsWatching = true;
                btnWatchFile.BackColor = Color.Red;
                btnWatchFile.Text = "停止监听";

                m_Watcher = new System.IO.FileSystemWatcher();
                if (rdbDir.Checked)
                {
                    m_Watcher.Filter = "*.*";
                    m_Watcher.Path = txtFile.Text;
                }
                else
                {
                    m_Watcher.Filter = txtFile.Text.Substring(txtFile.Text.LastIndexOf('\\') + 1);
                    m_Watcher.Path = txtFile.Text.Substring(0, txtFile.Text.Length - m_Watcher.Filter.Length);
                }

                if (chkSubFolder.Checked)
                {
                    m_Watcher.IncludeSubdirectories = true;
                }

                m_Watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite
                                     | NotifyFilters.FileName | NotifyFilters.DirectoryName;
                m_Watcher.Changed += new FileSystemEventHandler(OnChanged);
               // m_Watcher.Created += new FileSystemEventHandler(OnChanged);
               // m_Watcher.Deleted += new FileSystemEventHandler(OnChanged);
               // m_Watcher.Renamed += new RenamedEventHandler(OnRenamed);
                m_Watcher.EnableRaisingEvents = true;

                timer1.Enabled = true;
            }
        }
        public void startlisten()
        {
            if (m_bIsWatching)
            {
                m_bIsWatching = false;
                m_Watcher.EnableRaisingEvents = false;
                m_Watcher.Dispose();
                btnWatchFile.BackColor = Color.LightSkyBlue;
                btnWatchFile.Text = "开始监听";
                timer1.Enabled = false;
            }
            else
            {
                m_bIsWatching = true;
                btnWatchFile.BackColor = Color.Red;
                btnWatchFile.Text = "停止监听";

                m_Watcher = new System.IO.FileSystemWatcher();
                if (rdbDir.Checked)
                {
                    m_Watcher.Filter = "*.*";
                    m_Watcher.Path = txtFile.Text;
                }
                else
                {
                    m_Watcher.Filter = txtFile.Text.Substring(txtFile.Text.LastIndexOf('\\') + 1);
                    m_Watcher.Path = txtFile.Text.Substring(0, txtFile.Text.Length - m_Watcher.Filter.Length);
                }

                if (chkSubFolder.Checked)
                {
                    m_Watcher.IncludeSubdirectories = true;
                }

                m_Watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite
                                     | NotifyFilters.FileName | NotifyFilters.DirectoryName;
                m_Watcher.Changed += new FileSystemEventHandler(OnChanged);
                m_Watcher.Created += new FileSystemEventHandler(OnChanged);
                m_Watcher.Deleted += new FileSystemEventHandler(OnChanged);
                m_Watcher.Renamed += new RenamedEventHandler(OnRenamed);
                m_Watcher.EnableRaisingEvents = true;

                timer1.Enabled = true;
            }
        }
        private void updateArm(object strParm)
        {
            try
            {
                JavaInterface mJavaInterface = new JavaInterface(m_strDataServerIp);
                mJavaInterface.callInterface((string)strParm, "saveOfEarlyWarningAutoanalysis", "1");
            }
            catch (Exception ue)
            {
                writeLog(ue.Source);
            }
        }
        private void descWeather(JObject devObj, string strWeather, string strFileName)
        {
            var jsonRoot = (JObject)JsonConvert.DeserializeObject(strWeather);
            if (jsonRoot != null)
            {
                if (jsonRoot["status"] != null)
                {
                    if (jsonRoot["status"].ToString() == "ok")
                    {
                        //
                        if (jsonRoot["result"] != null)
                        {
                            if (jsonRoot["result"]["realtime"] != null)
                            {
                                Realtime realtime = JsonConvert.DeserializeObject<Realtime>(jsonRoot["result"]["realtime"].ToString());

                                var jsonRtn = new JObject();
                                jsonRtn.Add("montioneid", devObj["device_montioneId"].ToString());
                                jsonRtn.Add("equipmentnumber", devObj["equipmentNumber"].ToString());
                                jsonRtn.Add("voltagelevel", devObj["voltageLevel"].ToString());
                                jsonRtn.Add("linename", devObj["lineName"].ToString());
                                jsonRtn.Add("towernumber", devObj["towerNumber"].ToString());
                                jsonRtn.Add("lat", devObj["lat"].ToString());
                                jsonRtn.Add("lng", devObj["lng"].ToString());
                                jsonRtn.Add("querytime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                                jsonRtn.Add("picname", strFileName);

                                jsonRtn.Add("temperature", realtime.temperature.ToString());
                                jsonRtn.Add("pres", realtime.pres.ToString());
                                jsonRtn.Add("humidity", realtime.humidity.ToString());
                                jsonRtn.Add("winddirection", realtime.wind.speed.ToString());
                                jsonRtn.Add("windspeed", realtime.temperature.ToString());
                                if (realtime.precipitation.nearest != null)
                                    jsonRtn.Add("nearestprecdistance", realtime.precipitation.nearest.distance.ToString());
                                if (realtime.precipitation.nearest != null)
                                    jsonRtn.Add("nearestprecintensity", realtime.precipitation.nearest.intensity.ToString());
                                if (realtime.precipitation.local != null)
                                    jsonRtn.Add("localprecintensity", realtime.precipitation.local.intensity.ToString());
                                if (realtime.precipitation.local != null)
                                    jsonRtn.Add("localprecdatasource", realtime.precipitation.local.datasource.ToString());
                                jsonRtn.Add("cloudrate", realtime.cloudrate.ToString());
                                jsonRtn.Add("dswrf", realtime.dswrf.ToString());
                                jsonRtn.Add("visibility", realtime.visibility.ToString());
                                jsonRtn.Add("skycon", realtime.skycon.ToString());
                                jsonRtn.Add("comfortindex", realtime.comfort.index.ToString());
                                jsonRtn.Add("comfortdesc", realtime.comfort.desc.ToString());
                                jsonRtn.Add("ultravioletindex", realtime.ultraviolet.index.ToString());
                                jsonRtn.Add("ultravioletdesc", realtime.ultraviolet.desc.ToString());

                                jsonRtn.Add("pm25", realtime.pm25.ToString());
                                jsonRtn.Add("pm10", realtime.pm10.ToString());
                                jsonRtn.Add("o3", realtime.o3.ToString());
                                jsonRtn.Add("no2", realtime.no2.ToString());
                                jsonRtn.Add("so2", realtime.so2.ToString());
                                jsonRtn.Add("co", realtime.co.ToString());
                                jsonRtn.Add("aqi", realtime.aqi.ToString());

                                char[] s1 = new char[32];

                                s1[0] = Convert.ToChar(1);
                                s1[1] = Convert.ToChar(1);
                                s1[2] = Convert.ToChar(1);
                                s1[3] = Convert.ToChar(0);
                                for (int i = 4; i < 32; i++)
                                {
                                    s1[i] = Convert.ToChar(0); ;
                                }
                                string head = new string(s1);

                                string ss = jsonRoot["result"]["realtime"].ToString();
                                ss = ss.Replace("\r\n", "");
                                ss = ss.Replace(" ", "");
                                jsonRtn.Add("realsrc", DataEncryption.addAndEncryption(head, ss));

                                string ss1 = jsonRoot.ToString();
                                ss1 = ss1.Replace("\r\n", "");
                                ss1 = ss1.Replace(" ", "");
                                jsonRtn.Add("srcdesc", DataEncryption.addAndEncryption(head, ss1));//strWeather);
                                if (jsonRoot["result"]["alert"] != null)
                                {
                                    string ss2 = jsonRoot["result"]["alert"].ToString();
                                    ss2 = ss2.Replace("\r\n", "");
                                    ss2 = ss2.Replace(" ", "");
                                    jsonRtn.Add("alertsrc", DataEncryption.addAndEncryption(head, ss2));
                                }




                                string strRtn = jsonRtn.ToString();//JsonConvert.SerializeObject(w1);
                                JavaInterface mJavaInterface = new JavaInterface(m_strDataServerIp);

                                strRtn = strRtn.Replace("\r\n", "");
                                strRtn = strRtn.Replace(" ", "");
                                string strSaveParm = "{\"equipmentWeatherEntityJson\":" + strRtn + "}";
                                string strSaveRtn = mJavaInterface.callInterface((string)strSaveParm, "addEquipmentWeatherEntity", "2");
                            }
                        }
                    }
                }
            }

        }
        private string descUnicode(string strInfo)
        {
            string rtn = "";
            char sOut = '1';
            string[] arr = strInfo.Split(new string[] { "\\u" }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in arr)
            {
                sOut = (char)Convert.ToInt32(s.Substring(0, 4), 16);
                rtn += sOut;
            }
            return rtn;
        }

        private void Weather(object strParm)
        {
            try
            {
                string strFile = "";

                var jsonParm = (JObject)JsonConvert.DeserializeObject((string)strParm);

                strFile = jsonParm["ImagePath"].ToString();

                JavaInterface mJavaInterface = new JavaInterface(m_strDataServerIp);
                string strRtn = mJavaInterface.callInterface((string)strParm, "findPoleCameraTableNoImageByCityCoulmn", "1");
                if (strRtn != null)
                {
                    var jsonRoot = (JObject)JsonConvert.DeserializeObject(strRtn);
                    if (jsonRoot != null)
                    {
                        if (jsonRoot["state"] != null)
                        {
                            if (jsonRoot["state"].ToString() == "1")
                            {
                                JArray list = JArray.Parse(jsonRoot["msg"].ToString());
                                foreach (var row in list)
                                {
                                    string strlat = "";
                                    string strlng = "";
                                    if (row["lat"] != null)
                                    {
                                        strlat = row["lat"].ToString();
                                    }
                                    if (row["lng"] != null)
                                    {
                                        strlng = row["lng"].ToString();
                                    }
                                    if ("".Equals(strlat) == false && "".Equals(strlng) == false)
                                    {
                                        WebRequest wrt = null;
                                        WebResponse wrp = null;
                                        try
                                        {
                                            wrt = WebRequest.Create("https://api.caiyunapp.com/v2/GFPfziHBpbfozV8h/" + strlng + "," + strlat + "/weather.json");

                                            wrt.Credentials = CredentialCache.DefaultCredentials;
                                            wrp = wrt.GetResponse();
                                            StreamReader sr = new StreamReader(wrp.GetResponseStream(), Encoding.UTF8);
                                            string html = sr.ReadToEnd();

                                            descWeather((JObject)row, html, strFile);

                                            sr.Close();
                                            wrp.Close();

                                        }
                                        catch (WebException ue)
                                        {
                                            writeLog(ue.Source);
                                        }
                                        catch (Exception ue)
                                        {
                                            writeLog(ue.Source);
                                        }
                                        finally
                                        {
                                            if (wrp != null)
                                                wrp.Close();
                                            if (wrt != null)
                                                wrt.Abort();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ue)
            {
                writeLog(ue.Source);
            }
        }
        private void OnChanged(object sender, FileSystemEventArgs e)
        {
            if (chkTimer.Checked == true)
                return;

            if (!m_bDirty)
            {
                m_Sb.Remove(0, m_Sb.Length);
                m_Sb.Append(e.Name);
                count(m_Sb.ToString());
                if (e.ChangeType == WatcherChangeTypes.Created)
                {
                    if (Directory.Exists(e.FullPath))
                    {
                        //目录
                        string strPath = e.FullPath + "\\";
                        string strNewPath = strPath.Replace(txtFile.Text, m_strOutPath);
                        if (!Directory.Exists(strNewPath))
                        {
                            Directory.CreateDirectory(strNewPath);
                        }
                    }
                    else
                    {
                        if (File.Exists(e.FullPath))
                        {
                            if (chbSynRename.Checked)
                            {
                                //文件
                                string strPath = Path.GetDirectoryName(e.FullPath) + "\\";

                                string strNewFile = e.FullPath.Replace(txtFile.Text, m_strOutPath);
                                string strNewPath = strPath.Replace(txtFile.Text, m_strOutPath);

                                if (!Directory.Exists(strNewPath))
                                {
                                    Directory.CreateDirectory(strNewPath);
                                }
                                if (!File.Exists(strNewFile))
                                {
                                    File.Copy(e.FullPath, strNewFile, true);
                                }
                            }
                            if (chbAramKsh.Checked)
                            {
                                //201115200001447055\20190629\20190629153504_0E2B.jpg
                                string strPath0 = e.FullPath.Replace(txtFile.Text, "");
                                int idx0 = strPath0.IndexOf("\\");
                                if (idx0 >= 0)
                                {
                                    string strDevid = strPath0.Substring(0, idx0);
                                    string strPathFull = e.FullPath;
                                    strPathFull = strPathFull.Replace("\\", "\\\\");

                                    string strParm = "{'equipmentNumber':'" + strDevid + "','alarmImagePath':'" + m_strMyPicHttpServer + strPathFull + "'}";
                                    Thread t = new Thread(new ParameterizedThreadStart(updateArm));
                                    t.Start(strParm);
                                }
                            }
                            if (chbWeather.Checked)
                            {
                                string strPath0 = e.FullPath.Replace(txtFile.Text, "");
                                int idx0 = strPath0.IndexOf("\\");
                                if (idx0 >= 0)
                                {
                                    string strDevid = strPath0.Substring(0, idx0);
                                    string strPathFull = e.FullPath;
                                    strPathFull = strPathFull.Replace("\\", "\\\\");

                                    idx0 = strPath0.LastIndexOf("\\");
                                    string strPicFileName = strPath0.Substring(idx0 + 1);
                                    string strParm = "{'equipmentNumber':'" + strDevid + "','ImagePath':'" + strPicFileName + "'}";

                                    Thread t = new Thread(new ParameterizedThreadStart(Weather));
                                    t.Start(strParm);
                                }
                            }
                        }
                    }

                }
                if (e.ChangeType == WatcherChangeTypes.Deleted)
                {
                    if (Directory.Exists(e.FullPath))
                    {
                        //目录
                        string strPath = e.FullPath + "\\";
                        string strNewPath = strPath.Replace(txtFile.Text, m_strOutPath);
                        //if (Directory.Exists(strNewPath))
                        //{
                        //    Directory.Delete(strNewPath);
                        //}
                    }
                    else
                    {
                        if (File.Exists(e.FullPath))
                        {
                            if (chkSynDelete.Checked)
                            {
                                //文件
                                string strPath = Path.GetDirectoryName(e.FullPath) + "\\";

                                string strNewFile = e.FullPath.Replace(txtFile.Text, m_strOutPath);
                                string strNewPath = strPath.Replace(txtFile.Text, m_strOutPath);
                                if (File.Exists(strNewFile))
                                {
                                    File.Delete(strNewFile);
                                }
                            }

                        }
                    }
                }

            }

        }



        private void OnRenamed(object sender, RenamedEventArgs e)
        {
            if (chkTimer.Checked == true)
                return;
            if (!m_bDirty)
            {
                m_Sb.Remove(0, m_Sb.Length);
                m_Sb.Append(e.OldFullPath);
                m_Sb.Append(" ");
                m_Sb.Append(e.ChangeType.ToString());
                m_Sb.Append(" ");
                m_Sb.Append("to ");
                m_Sb.Append(e.Name);
                m_Sb.Append("    ");
                m_Sb.Append(DateTime.Now.ToString());
                m_bDirty = true;
                

                if (rdbFile.Checked)
                {
                    m_Watcher.Filter = e.Name;
                    m_Watcher.Path = e.FullPath.Substring(0, e.FullPath.Length - m_Watcher.Filter.Length);
                }
            }
        }
        List<string> imagenamelist = new List<string>();
        List<string> imagenamelist1 = new List<string>();


        int timespan = 0;
        string oldname = "";
        private void count(string imagename)
        {
            if (!imagename.Contains("~2~"))
                return;
            if(oldname!=imagename)
            {
                if (timespan == 1000)
                    timespan = 0;
                timespan += 1;
               // imagenamelist.Add(imagename);

                if (timespan % 2 == 0)
                {
                    imagenamelist.Add(imagename);
                }
                else
                {
                    imagenamelist1.Add(imagename);
                }
                oldname = imagename;
            }
        }
     
        int imagecount = 0;
        public void httpsend(string imagename)
        {
            //ServiceReference1.ImageListenServiceSoapClient service = new ServiceReference1.ImageListenServiceSoapClient("ImageListenServiceSoap");
            //service.sendImageInfor(s);
            string url = httpurl; 
            string method = "sendImageInfor";
            HttpPostWebService(url, method, imagename);
        }
        public void httpsend1(string imagename)
        {
            //ServiceReference1.ImageListenServiceSoapClient service = new ServiceReference1.ImageListenServiceSoapClient("ImageListenServiceSoap");
            //service.sendImageInfor(s);
            string url = httpurl;
            string method = "sendImageInfor";
            HttpPostWebService1(url, method, imagename);
        }
        public string HttpPostWebService(string url, string method, string imagename)
        {
            byte[] bytes = null;
            string result = string.Empty;
            string param = string.Empty;
            Stream writer = null;
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            try
            {
                param = HttpUtility.UrlEncode("imagename") + "=" + HttpUtility.UrlEncode(imagename);
                bytes = Encoding.UTF8.GetBytes(param);
                request = (HttpWebRequest)WebRequest.Create(url + "/" + method);
                request.Proxy = null;
                writeLog(url + "/" + method + "&" + param);
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                //request.ContentType = "text/html"; 
                request.ContentLength = bytes.Length;
                writer = request.GetRequestStream();  //获取用于写入请求数据的Stream对象
            }
            catch (Exception ex)
            {
                writeLog(ex.Message);
                return "";
            }
            try
            {
                writer.Write(bytes, 0, bytes.Length);  //把参数数据写入请求数据流
                writer.Close();
                imagecount += 1;

                response = (HttpWebResponse)request.GetResponse();  //获得响应
                string sx = response.ToString();

                writeLog(sx);
                response.Dispose();
                response.Close();
                return result;
            }
            catch (WebException ex)
            {
                writeLog(ex.Message);
                return "";
            }

        }
        public string HttpPostWebService1(string url, string method, string imagename)
        {
            byte[] bytes = null;
            string result = string.Empty;
            string param = string.Empty;
            Stream writer = null;
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            try
            {
                param = HttpUtility.UrlEncode("imagename") + "=" + HttpUtility.UrlEncode(imagename);
                bytes = Encoding.UTF8.GetBytes(param);
                request = (HttpWebRequest)WebRequest.Create(url + "/" + method);
                request.Proxy = null;

                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                //request.ContentType = "text/html"; 
                request.ContentLength = bytes.Length;

                writer = request.GetRequestStream();  //获取用于写入请求数据的Stream对象
            }
            catch (Exception ex)
            {
                writeLog(ex.Message);
                return "";
            }
            try
            {
                writer.Write(bytes, 0, bytes.Length);  //把参数数据写入请求数据流
                writer.Dispose();
                writer.Close();
                imagecount += 1;

                response = (HttpWebResponse)request.GetResponse();  //获得响应
                string sx = response.ToString();
                response.Dispose();
                response.Close();
                return result;
            }
            catch (WebException ex)
            {
                writeLog(ex.Message);
                return "";
            }

        }
        public string PostMessage(string url, string method, string imagename)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url + "/" + method);

                request.Accept = "text/plain, */*; q=0.01";
                request.ContentType = "application/x-www-form-urlencoded; charset=UTF-8";
                //请求方式
                request.Method = "POST";
                request.KeepAlive = false;
                request.ContentLength = imagename.Length;
                Stream postStream = request.GetRequestStream();
                byte[] postData = Encoding.UTF8.GetBytes(imagename);
                postStream.Write(postData, 0, postData.Length);
                postStream.Dispose();
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                Stream myResponseStream = response.GetResponseStream();

                StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
                string res = myStreamReader.ReadToEnd().ToString();
                return res;

            }
            catch (Exception e)
            {
                writeLog(e.Message);
                return e.ToString();
            }

        }
        #region 线程
        Thread sendthread = null;
        public void sendimage()
        {
            try
            {
                while (true)
                {
                    if(imagenamelist.Count>0)
                    {
                        httpsend(imagenamelist[0]);
                        imagenamelist.RemoveAt(0);
                    }
                  
                }
            }
            catch
            {

            }
        }
        Thread sendthread1 = null;
        public void sendimage1()
        {
            try
            {
                while (true)
                {
                    if (imagenamelist1.Count > 0)
                    {
                        httpsend1(imagenamelist1[0]);
                        imagenamelist1.RemoveAt(0);
                    }
                }
            }
            catch
            {

            }

        }
        #endregion
        private void tmrEditNotify_Tick(object sender, EventArgs e)
        {
            if (m_bDirty)
            {
                lstNotification.BeginUpdate();
                string s = m_Sb.ToString();
                if (s.Contains("Created"))
                {
                    lstNotification.Items.Add(m_Sb.ToString());
                    lstNotification.EndUpdate();
                }
                    
                
                m_bDirty = false;
            }
        }

        private void btnBrowseFile_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer", txtFile.Text);
            /*if (rdbDir.Checked)
            {
                DialogResult resDialog = dlgOpenDir.ShowDialog();
                if (resDialog.ToString() == "OK")
                {
                    txtFile.Text = dlgOpenDir.SelectedPath;
                }
            }
            else
            {
                DialogResult resDialog = dlgOpenFile.ShowDialog();
                if (resDialog.ToString() == "OK")
                {
                    txtFile.Text = dlgOpenFile.FileName;
                }
            }*/
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            DialogResult resDialog = dlgSaveFile.ShowDialog();
            if (resDialog.ToString() == "OK")
            {
                FileInfo fi = new FileInfo(dlgSaveFile.FileName);
                StreamWriter sw = fi.CreateText();
                foreach (string sItem in lstNotification.Items)
                {
                    sw.WriteLine(sItem);
                }
                sw.Close();
            }
        }

        private void rdbFile_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbFile.Checked == true)
            {
                chkSubFolder.Enabled = false;
                chkSubFolder.Checked = false;
            }
        }

        private void rdbDir_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbDir.Checked == true)
            {
                chkSubFolder.Enabled = true;
            }
        }





        private void writeLog(string logtext)
        {
            FileInfo fi = new FileInfo("log.txt");
            if (File.Exists("log.txt") && fi.Length > 1000000)
            {
                Compress(fi);
                DateTime ora = DateTime.Now;
                File.Move("log.txt.gz", "log.txt." + ora.Year + "." + ora.Month + "." + ora.Day + "." + ora.Hour + "." + ora.Minute + "." + ora.Second + ".gz");
                File.Delete("log.txt");
            }
            StreamWriter sw;
            if (File.Exists("log.txt")) sw = new StreamWriter("log.txt", true);
            else sw = fi.CreateText();
            sw.WriteLine(logtext);
            sw.Close();
        }


        public void stampa(string ipAddress, int TCPIPPort, string filename, string PrinterName)
        {
            try
            {
                if (ipAddress != null && !string.IsNullOrEmpty(ipAddress) && TCPIPPort > 0)
                {
                    PrintZebraFileToTCPIP(ipAddress, TCPIPPort, filename);
                }
                else if (!UseRawHelper)
                {
                    using (streamToPrint = new System.IO.StreamReader(filename))
                    {
                        try
                        {
                            printFont = new Font("Arial", 10);
                            printDocument1 = new System.Drawing.Printing.PrintDocument();
                            printDocument1.PrinterSettings.PrinterName = PrinterName;
                            printDocument1.PrinterSettings.Copies = 1;
                            printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(printDocument1_PrintPage);
                            printDocument1.Print();
                        }
                        finally
                        {
                            try
                            {
                                streamToPrint.Close();
                            }
                            catch { }
                        }
                    }
                }
                else
                {
                    if (!RawPrinterHelper.RawPrinterHelper.SendFileToPrinter(PrinterName, filename))
                    {
                        writeLog("ERRORE DURANTE L'INVIO DEL FILE ZEBRA ALLA STAMPANTE!");
                        //return;
                    }
                }
                System.Threading.Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
                writeLog("ERRORE DURANTE LA STAMPA!" + Environment.NewLine + Environment.NewLine + "Messaggio di errore:" + Environment.NewLine + ex.Message);
                return;
            }
        }





        private void PrintZebraFileToTCPIP(string ipAddress, int port, string EtichettaTXTPath)
        {
            try
            {
                writeLog("PrintZebraFileToTCPIP: ipAddress: " + ipAddress + " - port: " + port.ToString());
            }
            catch (Exception ex)
            {
                writeLog("ERROR in PrintZebraFileToTCPIP() durante il Log: \r\n\r\n" + ex.Message);
            }

            string ZPLString = "";
            using (streamToPrint = new System.IO.StreamReader(EtichettaTXTPath))
            {
                try
                {
                    ZPLString = streamToPrint.ReadToEnd();
                }
                finally
                {
                    try
                    {
                        streamToPrint.Close();
                    }
                    catch { }
                }
            }
            if (String.IsNullOrEmpty(ZPLString))
            {
                writeLog("ERRORE DURANTE LA LETTURA DEL FILE ETICHETTA: " + EtichettaTXTPath);
            }
            else
            {
                PrintZebraZPLToTCPIP(ipAddress, port, ZPLString);
            }
        }

        private void PrintZebraZPLToTCPIP(string ipAddress, int port, string ZPLString)
        {
            try
            {
                // Open connection
                System.Net.Sockets.TcpClient client = new System.Net.Sockets.TcpClient();
                client.Connect(ipAddress, port);

                // Write ZPL String to connection
                System.IO.StreamWriter writer = new System.IO.StreamWriter(client.GetStream());
                writer.Write(ZPLString);
                writer.Flush();

                // Close Connection
                writer.Close();
                client.Close();
            }
            catch (Exception ex)
            {
                writeLog("ERRORE DURANTE LA STAMPA IN TCP/IP!" + Environment.NewLine + Environment.NewLine + "Messaggio di errore:" + Environment.NewLine + ex.Message);
            }
        }





        void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs ev)
        {
            Single linesPerPage = 0;
            Single yPos = 0;
            int count = 0;
            Single leftMargin = ev.MarginBounds.Left;
            Single topMargin = ev.MarginBounds.Top;
            string line = "";

            // Calculate the number of lines per page.
            linesPerPage = ev.MarginBounds.Height / printFont.GetHeight(ev.Graphics);

            // Print each line of the file.
            while (count < linesPerPage)
            {
                line = streamToPrint.ReadLine();
                if (line == null)
                {
                    break;
                }
                yPos = topMargin + count * printFont.GetHeight(ev.Graphics);
                ev.Graphics.DrawString(line, printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
                count++;
            }

            // If more lines exist, print another page.
            if (line != null)
            {
                ev.HasMorePages = true;
            }
            else
            {
                ev.HasMorePages = false;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void frmNotifier_Load(object sender, EventArgs e)
        {
            btnWatchFile.PerformClick();
            timer2.Interval = 50000;
            timer2.Start();
            sendthread = new Thread(sendimage);
            sendthread.Start();
            sendthread1 = new Thread(sendimage1);
            sendthread1.Start();
        }

        public static void Compress(FileInfo fileToCompress)
        {

            using (FileStream originalFileStream = fileToCompress.OpenRead())
            {
                if ((File.GetAttributes(fileToCompress.FullName) &
                   FileAttributes.Hidden) != FileAttributes.Hidden & fileToCompress.Extension != ".gz")
                {
                    using (FileStream compressedFileStream = File.Create(fileToCompress.FullName + ".gz"))
                    {
                        using (GZipStream compressionStream = new GZipStream(compressedFileStream,
                           CompressionMode.Compress))
                        {
                            originalFileStream.CopyTo(compressionStream);

                        }
                    }
                    //DateTime ora = DateTime.Now;

                    FileInfo info = new FileInfo(fileToCompress.Name + ".gz");
                    Console.WriteLine("Compressed {0} from {1} to {2} bytes.",
                    fileToCompress.Name, fileToCompress.Length.ToString(), info.Length.ToString());
                    //File.Move(fileToCompress.Name, fileToCompress.Name.Substring(0, fileToCompress.Name.Length - 3) + "." + ora.Year + "." + ora.Month + "." + ora.Day + "." + ora.Hour + "." + ora.Minute + "." + ora.Second + ".gz");
                }

            }

        }

        private void frmNotifier_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
                Hide();
        }

        private void notifyIcon1_DoubleClick(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }

        private void readmeZebraTCPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //System.Diagnostics.Process.Start("explorer", "readme.txt");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (chkTimer.Checked)
            {
                if (m_iCheckStatus == 0)
                {
                    checkcopy();
                }
            }
        }
        private void checkcopy()
        {
            Thread t = new Thread(new ThreadStart(ThreadMethod));
            t.Start();
        }
        private void ThreadMethod()
        {
            m_iCheckStatus = 1;

            string[] strFiles1 = Directory.GetFiles(txtFile.Text, "*.*");
            string[] strFiles2 = Directory.GetFiles(m_strOutPath, "*.*");
            if (strFiles1 != null)
            {
                foreach (string path in strFiles1)
                {
                    string name = Path.GetFileName(path);
                    string findpath = "";
                    bool bFind = false;
                    foreach (string path2 in strFiles2)
                    {
                        string name2 = Path.GetFileName(path2);
                        if (name == name2)
                        {
                            findpath = path2;
                            bFind = true;
                            break;
                        }
                    }
                    if (bFind)
                    {
                        string strpathDate = Directory.GetLastWriteTime(path).ToString();
                        string strpathDate2 = Directory.GetLastWriteTime(findpath).ToString();
                        if (strpathDate != strpathDate2)
                        {
                            File.Copy(path, m_strOutPath + name, true);

                            m_Sb.Remove(0, m_Sb.Length);
                            m_Sb.Append(path);
                            m_Sb.Append(" ");
                            m_Sb.Append("copy");
                            m_Sb.Append(" ");
                            m_Sb.Append("to ");
                            m_Sb.Append(m_strOutPath + name);
                            m_Sb.Append("    ");
                            m_Sb.Append(DateTime.Now.ToString());
                            m_bDirty = true;
                            //
                        }
                    }
                    else
                    {
                        File.Copy(path, m_strOutPath + name, true);
                        m_Sb.Remove(0, m_Sb.Length);
                        m_Sb.Append(path);
                        m_Sb.Append(" ");
                        m_Sb.Append("copy");
                        m_Sb.Append(" ");
                        m_Sb.Append("to ");
                        m_Sb.Append(m_strOutPath + name);
                        m_Sb.Append("    ");
                        m_Sb.Append(DateTime.Now.ToString());
                        m_bDirty = true;
                        //
                    }
                }
            }
            if (strFiles2 != null)
            {
                foreach (string path2 in strFiles2)
                {
                    string name2 = Path.GetFileName(path2);
                    string findpath2 = "";
                    bool bFind = false;
                    foreach (string path in strFiles1)
                    {
                        string name = Path.GetFileName(path);
                        if (name == name2)
                        {
                            findpath2 = path;
                            bFind = true;
                            break;
                        }
                    }
                    if (bFind)
                    {

                    }
                    else
                    {
                        File.Delete(path2);
                        m_Sb.Remove(0, m_Sb.Length);
                        m_Sb.Append(path2);
                        m_Sb.Append(" ");
                        m_Sb.Append("delete");
                        m_Sb.Append("    ");
                        m_Sb.Append(DateTime.Now.ToString());
                        m_bDirty = true;
                        //
                    }
                }
            }
            m_iCheckStatus = 0;
        }

        private void chbWeather_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void frmNotifier_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel=true;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            string s = System.DateTime.Now.ToString("hh:mm:ss");
            if (System.DateTime.Now.ToString("hh:mm:ss") == "00:00:00")
                imagecount = 0;
            // SendimageToserver();  
            this.Invoke((EventHandler)delegate
            {
                label2.Text = "今日图片上传数目：" + imagecount + "未上传：" + (imagenamelist.Count + imagenamelist1.Count );
                if (listPrinters.Items.Count > 3)
                    listPrinters.Items.Clear();

            });
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = System.DateTime.Now.ToString("hh:mm:ss");
            if (System.DateTime.Now.ToString("hh:mm:ss") == "00:00:00")
                imagecount = 0;
            // SendimageToserver();  
            label2.Text = "今日图片上传数目：" + imagecount + "未上传：" + (imagenamelist.Count + imagenamelist1.Count);
                if (listPrinters.Items.Count > 3)
                    listPrinters.Items.Clear();

        }
    }

}

