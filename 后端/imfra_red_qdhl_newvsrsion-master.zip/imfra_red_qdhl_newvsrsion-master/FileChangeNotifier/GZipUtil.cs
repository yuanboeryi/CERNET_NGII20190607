﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Compression;

namespace FileSystemWatcher
{
    class GZipUtil
    {

        public static string Zip(string value)
        {
            byte[] byteArray = Encoding.UTF8.GetBytes(value);
            byte[] tmpArray;

            using (MemoryStream ms = new MemoryStream())
            {
                using (GZipStream sw = new GZipStream(ms, CompressionMode.Compress))
                {
                    sw.Write(byteArray, 0, byteArray.Length);
                    sw.Flush();
                }
                tmpArray = ms.ToArray();
            }
            return Convert.ToBase64String(tmpArray);
        }

        public static string UnZip(string value)
        {
            byte[] byteArray = Convert.FromBase64String(value);
            byte[] tmpArray;

            using (MemoryStream msOut = new MemoryStream())
            {
                using (MemoryStream msIn = new MemoryStream(byteArray))
                {
                    using (GZipStream swZip = new GZipStream(msIn, CompressionMode.Decompress))
                    {
                        swZip.CopyTo(msOut);
                        tmpArray = msOut.ToArray();
                    }
                }
            }
            return Encoding.UTF8.GetString(tmpArray);
        }
    }
}
