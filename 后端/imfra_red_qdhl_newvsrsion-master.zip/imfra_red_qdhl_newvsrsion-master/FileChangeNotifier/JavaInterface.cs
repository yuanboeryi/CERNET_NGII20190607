﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Web;

namespace FileSystemWatcher
{
    class JavaInterface
    {
        /// <summary>
        /// 上次调用接口时间
        /// </summary>
        private DateTime m_lastCallInterfaceTimeStart;
        /// <summary>
        /// 上次调用接口结束时间
        /// </summary>
        private string m_lastCallInterfaceTimeEnd;
        /// <summary>
        /// 进入定时开关，防止一个还没结束进入下一个。
        /// </summary>
        private bool m_bInTimer;
        /// <summary>
        /// 本机外网地址
        /// </summary>
        private string m_strMyIp = "";
        /// <summary>
        /// 接口调用时间
        /// </summary>
        private string m_strTransTime = "";
        /// <summary>
        /// 当前缓存后台更新索引id
        /// </summary>
        private int m_iCurrentBackTransIdx;
        /// <summary>
        /// 服务器地址
        /// </summary>
        private string m_strServerIp;
        /// <summary>
        /// 使用缓存
        /// </summary>
        private bool m_bUseCache;
        /// <summary>
        /// 缓存有效时间
        /// </summary>
        private int m_iCacheTime;
        private string m_strUserBackThread;
        /// <summary>
        /// 选择名称
        /// </summary>
        private string m_strSelectOpName;
        /// <summary>
        /// 选择类型，0机构，1线路
        /// </summary>
        private string m_strSelectOpType;
        /// <summary>
        /// 上次选择类型
        /// </summary>
        private string m_strLastSelectOpType;
        /// <summary>
        /// 上次选择名称
        /// </summary>
        private string m_strLastSelectOpName;
        private bool m_bSetTime;
        private string m_strInterFace;
        private string m_strStaticIp;
        public struct SYSTEMTIME
        {
            public ushort wYear;
            public ushort wMonth;
            public ushort wDayOfWeek;
            public ushort wDay;
            public ushort wHour;
            public ushort wMinute;
            public ushort wSecond;
            public ushort wMilliseconds;

            /// <summary>
            /// 从System.DateTime转换。
            /// </summary>
            /// <param name="time">System.DateTime类型的时间。</param>
            public void FromDateTime(DateTime time)
            {
                wYear = (ushort)time.Year;
                wMonth = (ushort)time.Month;
                wDayOfWeek = (ushort)time.DayOfWeek;
                wDay = (ushort)time.Day;
                wHour = (ushort)time.Hour;
                wMinute = (ushort)time.Minute;
                wSecond = (ushort)time.Second;
                wMilliseconds = (ushort)time.Millisecond;
            }
            /// <summary>
            /// 转换为System.DateTime类型。
            /// </summary>
            /// <returns></returns>
            public DateTime ToDateTime()
            {
                return new DateTime(wYear, wMonth, wDay, wHour, wMinute, wSecond, wMilliseconds);
            }
            /// <summary>
            /// 静态方法。转换为System.DateTime类型。
            /// </summary>
            /// <param name="time">SYSTEMTIME类型的时间。</param>
            /// <returns></returns>
            public static DateTime ToDateTime(SYSTEMTIME time)
            {
                return time.ToDateTime();
            }
        }
        /// <summary>
        /// 设置系统时间
        /// </summary>
        /// <param name="Time"></param>
        /// <returns></returns>
        [DllImport("Kernel32.dll")]
        public static extern bool SetLocalTime(ref SYSTEMTIME Time);
        public void openCache()
        {
            m_bUseCache = true;
        }
        public void closeCache()
        {
            m_bUseCache = false;
        }
        /// <summary>
        /// 取得外网ip
        /// </summary>
        /// <returns></returns>
        private string GetIP()
        {
            return GetMacAddressByNetworkInformation();
        }

        public string GetMacAddressByNetworkInformation()
        {
            string key = "SYSTEM\\CurrentControlSet\\Control\\Network\\{4D36E972-E325-11CE-BFC1-08002BE10318}\\";
            string macAddress = string.Empty;
            try
            {
                NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
                foreach (NetworkInterface adapter in nics)
                {
                    if (adapter.NetworkInterfaceType == NetworkInterfaceType.Ethernet
                        && adapter.GetPhysicalAddress().ToString().Length != 0)
                    {
                        string fRegistryKey = key + adapter.Id + "\\Connection";
                        RegistryKey rk = Registry.LocalMachine.OpenSubKey(fRegistryKey, false);
                        if (rk != null)
                        {
                            string fPnpInstanceID = rk.GetValue("PnpInstanceID", "").ToString();
                            int fMediaSubType = Convert.ToInt32(rk.GetValue("MediaSubType", 0));
                            if (fPnpInstanceID.Length > 3 &&
                                fPnpInstanceID.Substring(0, 3) == "PCI")
                            {
                                macAddress = adapter.GetPhysicalAddress().ToString();
                                for (int i = 1; i < 6; i++)
                                {
                                    macAddress = macAddress.Insert(3 * i - 1, ":");
                                }
                                break;
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {

                //这里写异常的处理

            }

            return macAddress;

        }

        /// <summary>
        /// 获取ntp时间
        /// </summary>
        /// <returns></returns>

        public DateTime DataStandardTime()
        {
            DateTime dt;
            WebRequest wrt = null;
            WebResponse wrp = null;
            try
            {
                wrt = WebRequest.Create("http://www.time.ac.cn/timeflash.asp?user=flash");

                wrt.Credentials = CredentialCache.DefaultCredentials;
                wrp = wrt.GetResponse();
                StreamReader sr = new StreamReader(wrp.GetResponseStream(), Encoding.UTF8);
                string html = sr.ReadToEnd();
                sr.Close();
                wrp.Close();
                int yearIndex = html.IndexOf("<year>") + 6;
                int monthIndex = html.IndexOf("<month>") + 7;
                int dayIndex = html.IndexOf("<day>") + 5;
                int hourIndex = html.IndexOf("<hour>") + 6;
                int miniteIndex = html.IndexOf("<minite>") + 8;
                int secondIndex = html.IndexOf("<second>") + 8;
                string year = html.Substring(yearIndex, html.IndexOf("</year>") - yearIndex);
                string month = html.Substring(monthIndex, html.IndexOf("</month>") - monthIndex); ;
                string day = html.Substring(dayIndex, html.IndexOf("</day>") - dayIndex);
                string hour = html.Substring(hourIndex, html.IndexOf("</hour>") - hourIndex);
                string minite = html.Substring(miniteIndex, html.IndexOf("</minite>") - miniteIndex);
                string second = html.Substring(secondIndex, html.IndexOf("</second>") - secondIndex);
                dt = DateTime.Parse(year + "-" + month + "-" + day + "" + hour + ":" + minite + ":" + second);
            }
            catch (WebException)
            {
                return DateTime.Now;
            }
            catch (Exception)
            {
                return DateTime.Now;
            }
            finally
            {
                if (wrp != null)
                    wrp.Close();
                if (wrt != null)
                    wrt.Abort();
            }
            return dt;

        }

        private string m_strMsg;

        private void decoderImgThread(object msg)
        {
            string strMsg = (string)msg;
            var jsonRoot = (JObject)JsonConvert.DeserializeObject(strMsg);
            if (jsonRoot != null)
            {
                if (jsonRoot["state"] != null)
                {
                    if (jsonRoot["state"].ToString() == "1")
                    {
                        JArray list = JArray.Parse(jsonRoot["msg"].ToString());
                        foreach (var row in list)
                        {
                            if (row["imagePath"] != null)
                            {
                                string strUrl = row["imagePath"].ToString();
                                if (row["equipmentNumber"] != null)
                                {
                                    string strequipmentNumber = row["equipmentNumber"].ToString();

                                    downImg(strUrl, strequipmentNumber);
                                }

                            }

                        }
                    }
                }
            }
        }

        private void decoderImg1Thread(object msg)
        {
            string strMsg = (string)msg;
            var jsonRoot = (JObject)JsonConvert.DeserializeObject(strMsg);
            //Loger.Print_Run(strMsg);
            if (jsonRoot != null)
            {
                if (jsonRoot["msg"] != null)
                {
                    string strequipmentNumber = jsonRoot["equpmentNumber"].ToString();
                    JArray list = JArray.Parse(jsonRoot["msg"].ToString());
                    foreach (var row in list)
                    {
                        string strUrl = row.ToString();

                        downImg(strUrl, strequipmentNumber);

                    }
                }
            }
        }
        private void downImg(string url, string equipmentNumber)
        {
            string strPath = AppDomain.CurrentDomain.BaseDirectory + "Admin\\PicCache\\" + equipmentNumber;
            if (Directory.Exists(strPath) == false)
            {
                Directory.CreateDirectory(strPath);
            }
            int iFind = url.LastIndexOf("\\");
            if (iFind > 0)
            {
                string strFile = url.Substring(iFind + 1);
                string strNewFile = strPath + "\\" + strFile;
                if (File.Exists(strNewFile) == false)
                {
                    try
                    {
                        System.Net.HttpWebRequest Myrq = (System.Net.HttpWebRequest)System.Net.HttpWebRequest.Create(new Uri(url));
                        Myrq.CookieContainer = App.cc;
                        System.Net.HttpWebResponse myrp = (System.Net.HttpWebResponse)Myrq.GetResponse();
                        long totalBytes = myrp.ContentLength;

                        System.IO.Stream st = myrp.GetResponseStream();
                        System.IO.Stream so = new System.IO.FileStream(strNewFile, System.IO.FileMode.Create);
                        long totalDownloadedByte = 0;
                        byte[] by = new byte[1024];
                        int osize = st.Read(by, 0, (int)by.Length);
                        while (osize > 0)
                        {
                            totalDownloadedByte = osize + totalDownloadedByte;
                            so.Write(by, 0, osize);

                            osize = st.Read(by, 0, (int)by.Length);
                        }
                        so.Close();
                        st.Close();
                    }
                    catch (Exception ue)
                    {

                    }
                }

            }
            return;
        }
        public JavaInterface(string strServerIp)
        {
            m_strServerIp = strServerIp;
        }
        //组装请求参数
        private string BuildQuery(IDictionary<string, string> parameters, string encode)
        {
            StringBuilder postData = new StringBuilder();
            bool hasParam = false;
            IEnumerator<KeyValuePair<string, string>> dem = parameters.GetEnumerator();
            while (dem.MoveNext())
            {
                string name = dem.Current.Key;
                string value = dem.Current.Value;
                // 忽略参数名或参数值为空的参数
                if (!string.IsNullOrEmpty(name))
                {
                    if (hasParam)
                    {
                        postData.Append("&");
                    }
                    postData.Append(name);
                    postData.Append("=");
                    if (encode == "gb2312")
                    {
                        postData.Append(HttpUtility.UrlEncode(value, Encoding.GetEncoding("gb2312")));
                    }
                    else if (encode == "utf8")
                    {
                        postData.Append(HttpUtility.UrlEncode(value, Encoding.UTF8));
                    }
                    else
                    {
                        postData.Append(value);
                    }
                    hasParam = true;
                }
            }
            return postData.ToString();
        }
        /// <summary>
        /// 接口调用
        /// </summary>
        /// <param name="text">参数</param>
        /// <param name="name">接口名称</param>
        /// <returns></returns>
        public string callInterface(string text, string name, string strType)
        {
            m_lastCallInterfaceTimeStart = DateTime.Now;
            m_lastCallInterfaceTimeEnd = null;

            string strReturn = "";
            char[] s1 = new char[32];

            s1[0] = Convert.ToChar(1);
            s1[1] = Convert.ToChar(1);
            s1[2] = Convert.ToChar(1);
            s1[3] = Convert.ToChar(0);
            for (int i = 4; i < 32; i++)
            {
                s1[i] = Convert.ToChar(0); ;
            }

            if (m_strMyIp == "")
                m_strMyIp = GetIP();

            DateTime dtStandardTime = DateTime.Now;// DataStandardTime();
            m_strTransTime = dtStandardTime.ToString("yyyy-MM-dd HH:mm:ss");
            string stxt = text;
            int iFrist = text.IndexOf("{");
            int iLast = text.LastIndexOf("}");
            if (iFrist == 0)
            {
                stxt = text.Substring(iFrist + 1, iLast - 1);
            }

            stxt = stxt.Replace("'", "\"");

            string head = new string(s1);
            string strinfo = "{\"param\":{" + stxt + "},\"protocol\":\"" + name + "\",\"ip\":\"" + m_strMyIp + "\",\"time\":\"" + m_strTransTime + "\"" + "}";
            var jsoIn = (JObject)JsonConvert.DeserializeObject(strinfo);
            string strParam = jsoIn["param"].ToString();
            string strParamEncryp = DataEncryption.addAndEncryption(head, strParam);
#if DEBUG
            Loger.Print_Op(strinfo);
            Loger.Print_Op(strParam);
            Loger.Print_Op(strParamEncryp);
#endif
            string afterEncryption = DataEncryption.addAndEncryption(head, strinfo);

            string url = "";
            if (strType == "1")
                url = "http://" + m_strServerIp + "/InsWeb/trans/weatherAction!put?data=" + afterEncryption;
            else
                url = "http://" + m_strServerIp + "/InsWeb/trans/weatherAction!putnew";
            //url = "http://" + m_strServerIp + "/InsWeb/trans/weatherAction!putnew";//data=" + afterEncryption;
#if DEBUG
            Loger.Print_Op(afterEncryption);
#endif
            int iQueryRtn = -1;

            if (iQueryRtn < 2)
            {
                HttpWebRequest wRequest = (HttpWebRequest)WebRequest.Create(url);

                wRequest.CookieContainer = App.cc;
                WebResponse wResponse = null;
                Stream stream = null;
                StreamReader reader = null;
                string str = null;
                try
                {
                    Dictionary<string, string> parameters = new Dictionary<string, string>();    //参数列表
                    parameters.Add("data", afterEncryption);
                    if (strType == "1")
                        wRequest.Method = "GET";// "GET";
                    else
                    {
                        wRequest.Method = "POST";// "GET";
                        wRequest.ContentType = "application/octet-stream;charset=utf-8";
                        string spost = afterEncryption;
                        byte[] postData1 = Encoding.UTF8.GetBytes(spost);
                        wRequest.ContentLength = postData1.Length;
                        wRequest.Timeout = 1000 * 60 * 5;
                        stream = wRequest.GetRequestStream();
                        //byte[] postData = Encoding.UTF8.GetBytes(BuildQuery(parameters, "utf8"));   //使用utf-8格式组装post参数
                        //for (int i = 0; i < postData1.Length;i+=1024 )
                        //{
                        //    int iLen = i + 1024;
                        //    if (iLen > postData1.Length)
                        //    {
                        //        iLen = postData1.Length - iLen;
                        //    }
                        //    stream.Write(postData1, i, iLen);
                        //}
                        stream.Write(postData1, 0, postData1.Length);
                        stream.Close();
                    }

                    wResponse = wRequest.GetResponse();
                    stream = wResponse.GetResponseStream();

                    reader = new StreamReader(stream, System.Text.Encoding.Default);
                    str = reader.ReadToEnd();   //url返回的值  
                }
                catch (Exception ue)
                {
#if DEBUG
                    Loger.Print_Op(ue.Message);
#endif
                    strReturn = "{\"msg\":\"[]\",\"number\":0,\"state\":-1}";//"网络错误。";
                    return strReturn;
                }
#if DEBUG
                Loger.Print_Op(str);
#endif

                string afterDecryption = "";
                try
                {
                    afterDecryption = DataEncryption.analysis(str);
                }
                catch (Exception ue)
                {
#if DEBUG
                    Loger.Print_Op(ue.Message);
#endif
                    strReturn = "{\"msg\":\"[]\",\"number\":0,\"state\":-2}";//"查不到数据了。";
                    return strReturn;
                }
#if DEBUG
                Loger.Print_Op(afterDecryption);
#endif
                var jsonRoot = (JObject)JsonConvert.DeserializeObject(afterDecryption);
                if (jsonRoot != null)
                {
                    if (jsonRoot["status"] != null)
                    {
                        if (jsonRoot["status"].ToString() == "1")
                        {
                            strReturn = afterDecryption;
                        }
                        else
                        {
                            strReturn = "{\"msg\":\"[]\",\"number\":0,\"state\":-3}";// "失败";
                        }
                    }
                    if (jsonRoot["state"] != null)
                    {
                        if (jsonRoot["state"].ToString() == "1")
                        {
                            strReturn = afterDecryption;
                        }
                        else
                        {
                            strReturn = "{\"msg\":\"[]\",\"number\":0,\"state\":-4}";//"失败";
                        }
                    }
                }
            }
            else
            {
                if (m_bUseCache)
                {
                    if (name == "getPoleImgHistoryByColumn")
                    {

                    }
                }
            }
            m_lastCallInterfaceTimeEnd = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            return strReturn;
        }
    }
}
