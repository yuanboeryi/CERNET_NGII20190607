﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace FileSystemWatcher
{
    class Loger
    {
        static Loger()
        {
        }
        /// <summary>
        /// 运行跟踪日志
        /// </summary>
        /// <param name="msg"></param>
        public static void Print_Run(string msg)
        {
            string FilePath = AppDomain.CurrentDomain.BaseDirectory + "AppRun_Log.txt";
            using (var sw = File.AppendText(FilePath))
            {
                var logLine = string.Format("{0:G}: {1}.", DateTime.Now, msg);
                sw.WriteLine(logLine);
            }
        }
        /// <summary>
        /// 接口日志
        /// </summary>
        /// <param name="msg"></param>
        public static void Print_Op(string msg)
        {
#if DEBUG
            string FilePath = AppDomain.CurrentDomain.BaseDirectory + "Interface_Log.txt";
            using (var sw = File.AppendText(FilePath))
            {
                var logLine = string.Format("{0:G}: {1}.", DateTime.Now, msg);
                sw.WriteLine(logLine);
            }
#endif
        }
        /// <summary>
        /// js日志
        /// </summary>
        /// <param name="msg"></param>
        public static void Print_Js(string msg)
        {
#if DEBUG
            string FilePath = AppDomain.CurrentDomain.BaseDirectory + "Js_Log.txt";
            using (var sw = File.AppendText(FilePath))
            {
                var logLine = string.Format("{0:G}: {1}.", DateTime.Now, msg);
                sw.WriteLine(logLine);
            }
#endif
        }
    }
}
