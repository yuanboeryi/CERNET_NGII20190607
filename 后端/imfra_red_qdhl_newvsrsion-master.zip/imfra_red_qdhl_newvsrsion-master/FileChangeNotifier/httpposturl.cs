﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace FileChangeNotifier
{
    class httpposturl
    {
        public string HttpPostWebService(string url, string method, string imagename)
        {
            byte[] bytes = null;
            string result = string.Empty;
            string param = string.Empty;
            Stream writer = null;
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            try
            {
                param = HttpUtility.UrlEncode("imagename") + "=" + HttpUtility.UrlEncode(imagename);
                bytes = Encoding.UTF8.GetBytes(param);
                request = (HttpWebRequest)WebRequest.Create(url + "/" + method);
                request.Proxy = null;

                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                //request.ContentType = "text/html"; 
                request.ContentLength = bytes.Length;
                writer = request.GetRequestStream();  //获取用于写入请求数据的Stream对象
            }
            catch (Exception ex)
            {
                return "";
            }
            try
            {
                writer.Write(bytes, 0, bytes.Length);  //把参数数据写入请求数据流
                writer.Close();

                //response = (HttpWebResponse)request.GetResponse();  //获得响应
                //string sx = response.ToString();
                response.Dispose();
                response.Close();
                return result;
            }
            catch (WebException ex)
            {
                return "";
            }

        }
      
    }
}
