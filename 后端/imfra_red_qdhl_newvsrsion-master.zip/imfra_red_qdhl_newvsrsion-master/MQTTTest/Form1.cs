﻿using HslCommunication;
using HslCommunication.MQTT;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MQTTTest
{
    public partial class Form1 : Form
    {
        private MqttServer mqttServer = new MqttServer();
        private MqttClient mqttClient1 = null;
        private MqttClient mqttClient2 = null;

        public Form1()
        {
            InitializeComponent();
          
        }
        public void showtext(string s)
        {
            richTextBox1.AppendText(s+"\r\n");

        }
        public void showtext1(string s)
        {
            richTextBox3.AppendText(s + "\r\n");

        }
        //122.114.204.83  61613
        private void Form1_Load(object sender, EventArgs e)
        {
            mqttClient1 = new MqttClient(new MqttConnectionOptions()
            {
                Port = 61613,
                ClientId = "Client1",
                IpAddress = "122.114.204.83",
                 Credentials = new MqttCredential( "admin", "password" )   // 设置了用户名和密码
            });
            mqttClient1.OnMqttMessageReceived += MqttClient_OnMqttMessageReceived; // 调用一次即可
            mqttClient2 = new MqttClient(new MqttConnectionOptions()
            {
                Port = 61613,
                ClientId = "Client2",
                IpAddress = "122.114.204.83",
                Credentials = new MqttCredential("admin", "password")   // 设置了用户名和密码
            });
            mqttClient2.OnMqttMessageReceived += MqttClient_OnMqttMessageReceived1; // 调用一次即可
            
        }
        //字符串转json
        public  string strJson(string str)
        {
            string jsonText = str;

            JObject jo = (JObject)JsonConvert.DeserializeObject(jsonText);//或者JObject jo = JObject.Parse(jsonText);
            string deviceID = jo["deviceId"].ToString();
            JArray array = (JArray)jo["data"];
            string type = "";
            string value = "";
            string status = "";
            for(int i=0;i<array.Count;i++)
            {
                type = array[i]["type"].ToString();
                value = array[i]["value"].ToString();
                status= array[i]["status"].ToString();
            }
            if (deviceID == "b827eb4ffb4e")
                showtext("测试设备回来数据了");
            return deviceID;
        }
        private void MqttClient_OnMqttMessageReceived(string topic, byte[] payload)
        {
            // 跨线程更新了UI界面的内容
            Invoke(new Action(() =>
            {
                showtext(System.Text.Encoding.Default.GetString(payload));
                string sx = System.Text.Encoding.Default.GetString(payload);

                richTextBox4.AppendText(strJson(sx) + "\r\n");
            }));
        }
        private void MqttClient_OnMqttMessageReceived1(string topic, byte[] payload)
        {
            // 跨线程更新了UI界面的内容
            Invoke(new Action(() =>
            {
                showtext1(System.Text.Encoding.Default.GetString(payload));
                string sx = System.Text.Encoding.Default.GetString(payload);
                richTextBox5.AppendText(strJson(sx) + "\r\n");
            }));
        }
        private void button1_Click(object sender, EventArgs e)
        {
            // 连接
            OperateResult connect = mqttClient1.ConnectServer();
            
            if (connect.IsSuccess)
            {
                
                showtext("成功连接到服务器：122.114.204.83");
            }
            else
            {
                showtext("连接122.114.204.83服务器失败");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 测试发布
            mqttClient1.PublishMessage(new MqttApplicationMessage()
            {
                Topic = "Client1",                                                // 主题
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,     // 消息等级
                Payload = System.Text.Encoding.ASCII.GetBytes(textBox2.Text),     // 数据
                Retain = false,                                                   // 是否保留
            });
        }

        
        #region mqtt服务
        private void button3_Click(object sender, EventArgs e)
        {

        }
        bool isno = false;
        private void button3_Click_1(object sender, EventArgs e)
        {
            if (isno == false)
            {
                mqttServer.ServerStart(61613);
                richTextBox2.AppendText("MQTTServer已启动，端口：61613" + "\r\n");
                mqttServer.OnClientApplicationMessageReceive += MqttServer_OnClientApplicationMessageReceive;
                mqttServer.OnClientConnected += MqttServer_OnClientConnected;
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            for (int i = 0; i < sessionlist.Count; i++)
            {
                comboBox1.Items.Add(sessionlist[i]);
            }
            if (comboBox1.Items.Count > 0)
                comboBox1.SelectedIndex = 0;
        }
        //
        List<string> sessionlist = new List<string>();
        int sessioncount = 0;
        private void MqttServer_OnClientConnected(MqttSession session)
        {
            // 当客户端连接上来时，可以立即返回一些数据内容信息
            mqttServer.PublishTopicPayload(session, "HslMqtt", Encoding.UTF8.GetBytes("this is test message from Server"));
            this.Invoke((EventHandler)delegate
            {
                bool ishave = false;
                for (int i = 0; i < sessionlist.Count(); i++)
                {
                    if (sessionlist[i] == session.ClientId)
                        ishave = true;
                }
                if (ishave == false)
                {
                    sessionlist.Add(session.ClientId);
                    label2.Text = "设备上线数：" + sessionlist.Count().ToString();
                    richTextBox2.AppendText(session.ToString() + "上线\r\n");
                    button7_Click(null,null);
                }


            });
        }
        private void MqttServer_OnClientApplicationMessageReceive(MqttSession session, MqttClientApplicationMessage message)
        {
            Invoke(new Action(() =>
            {
                richTextBox2.AppendText(System.Text.Encoding.Default.GetString(message.Payload) + "\r\n");
            }));
        }
     

        #endregion
     
        #region 进制转换
        public static string GetHexFromChs(string s)
        {
            if ((s.Length % 2) != 0)
            {
                s += " ";//空格
                //throw new ArgumentException("s is not valid chinese string!");
            }

            System.Text.Encoding chs = System.Text.Encoding.GetEncoding("gb2312");

            byte[] bytes = chs.GetBytes(s);

            string str = "";

            for (int i = 0; i < bytes.Length; i++)
            {
                str += string.Format("{0:X}", bytes[i]);
            }

            return str;
        }
        #endregion

        private void button4_Click_1(object sender, EventArgs e)
        {
            byte[] sx = System.Text.Encoding.ASCII.GetBytes(textBox1.Text);
            //mqttServer.PublishTopicPayload("ABC", Encoding.UTF8.GetBytes("服务器向客户端名称为ABC发送消息：this is test"));
            mqttServer.PublishTopicPayload(comboBox1.Text, "AAA", System.Text.Encoding.ASCII.GetBytes(textBox1.Text));
            //针对ClientId为1000的客户端发送消息

            //mqttServer.PublishAllClientTopicPayload("A", Encoding.UTF8.GetBytes("asd"));
            //强制给所有的客户端发送消息
        }

        private void button8_Click(object sender, EventArgs e)
        {
            OperateResult connect = mqttClient2.ConnectServer();

            if (connect.IsSuccess)
            {

                showtext1("成功连接到服务器：122.114.204.83");
            }
            else
            {
                showtext1("连接122.114.204.83服务器失败");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            mqttClient2.PublishMessage(new MqttApplicationMessage()
            {
                Topic = "Client2",                                                      // 主题
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,     // 消息等级
                Payload = System.Text.Encoding.ASCII.GetBytes(textBox3.Text),        // 数据
                Retain = false,                                                   // 是否保留
            });
        }

        private void button12_Click(object sender, EventArgs e)//客户端1订阅消息
        {
            button12.Enabled = false;
            mqttClient1.SubscribeMessage("temperature/v2/status");     // 订阅Client2的主题
            showtext("开启订阅temperature主题消息");

        }

        private void button10_Click(object sender, EventArgs e)//客户端2订阅消息
        {
            button10.Enabled = false;
            mqttClient2.SubscribeMessage("heart/v2/status");     // 订阅Client2的主题
            showtext1("开启订阅heart主题消息");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            List<rectjson> jsonlist = new List<rectjson>();

            string pointlist = "320,240:0,1:p,4/60,60/180,60/180,180/60,180/:";
            DataTable dt = new DataTable();
            dt.Columns.Add("type", Type.GetType("System.Int32"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("status", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { 174,pointlist,"" });
            rectjson json = new rectjson();
            json.deviceId = "B827EB4FFB4E";
            json.data = dt;
            jsonlist.Add(json);
            string jsonstr = Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
            richTextBox6.Text = "";
            richTextBox6.Text = "发送区域命令：\r\n" + jsonstr;
            // 测试发布
            mqttClient1.PublishMessage(new MqttApplicationMessage()
            {
                Topic = "video/v2/cmd",                                                // 主题
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,     // 消息等级
                Payload = System.Text.Encoding.ASCII.GetBytes(jsonstr),     // 数据
                Retain = false,                                                   // 是否保留
            });
        }

        public void goleft()
        {
            List<rectjson> jsonlist = new List<rectjson>();
            DataTable dt = new DataTable();
            dt.Columns.Add("type", Type.GetType("System.Int32"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("status", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { 4, "", "" });
            rectjson json = new rectjson();
            json.deviceId = "B827EB4FFB4E";
            json.data = dt;
            jsonlist.Add(json);
            string jsonstr = Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
            richTextBox6.Text = "";
            richTextBox6.Text = "发送左转命令：\r\n" + jsonstr;
           // string s1 = "B827EB4FFB4E";
            //string ssendstring = "{deviceID:B827EB4FFB4E,data:[{type:4,value:,status:}]}";
            // 测试发布
            mqttClient1.PublishMessage(new MqttApplicationMessage()
            {
                Topic = "cloud/v2/cmd",                                                // 主题
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,     // 消息等级
                Payload = System.Text.Encoding.ASCII.GetBytes(jsonstr),     // 数据
                Retain = false,                                                   // 是否保留
            });
        }
        public void gostop()
        {
            List<rectjson> jsonlist = new List<rectjson>();

            DataTable dt = new DataTable();
            dt.Columns.Add("type", Type.GetType("System.Int32"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("status", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { 0, "", "" });
            rectjson json = new rectjson();
            json.deviceId = "B827EB4FFB4E";
            json.data = dt;
            jsonlist.Add(json);
            string jsonstr = Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
            richTextBox6.Text = "";
            richTextBox6.Text = "发送停止命令：\r\n" + jsonstr;
            // 测试发布
            mqttClient1.PublishMessage(new MqttApplicationMessage()
            {
                Topic = "cloud/v2/cmd",                                                // 主题
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,     // 消息等级
                Payload = System.Text.Encoding.ASCII.GetBytes(jsonstr),     // 数据
                Retain = false,                                                   // 是否保留
            });
        }
        public void goright()
        {
            List<rectjson> jsonlist = new List<rectjson>();

            DataTable dt = new DataTable();
            dt.Columns.Add("type", Type.GetType("System.Int32"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("status", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { 2, "", "" });
            rectjson json = new rectjson();
            json.deviceId = "B827EB4FFB4E";
            json.data = dt;
            jsonlist.Add(json);
            string jsonstr = Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
            richTextBox6.Text = "";
            richTextBox6.Text = "发送右转命令：\r\n" + jsonstr;
            // 测试发布
            mqttClient1.PublishMessage(new MqttApplicationMessage()
            {
                Topic = "cloud/v2/cmd",                                             // 主题
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,       // 消息等级
                Payload = System.Text.Encoding.ASCII.GetBytes(jsonstr),             // 数据
                Retain = false,                                                     // 是否保留
            });
        }
        public void goup()
        {
            List<rectjson> jsonlist = new List<rectjson>();

            DataTable dt = new DataTable();
            dt.Columns.Add("type", Type.GetType("System.Int32"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("status", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { 160, "0", "0" });
            rectjson json = new rectjson();
            json.deviceId = "B827EB4FFB4E";
            json.data = dt;
            jsonlist.Add(json);
            string jsonstr = Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
            richTextBox6.Text = "";
            richTextBox6.Text = "发送上转命令：\r\n" + jsonstr;
            // 测试发布
            mqttClient1.PublishMessage(new MqttApplicationMessage()
            {
                Topic = "cloud/v2/cmd",                                           // 主题
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,     // 消息等级
                Payload = System.Text.Encoding.ASCII.GetBytes(jsonstr),           // 数据
                Retain = false,                                                   // 是否保留
            });
        }
        public void gobottom()
        {
            List<rectjson> jsonlist = new List<rectjson>();

            DataTable dt = new DataTable();
            dt.Columns.Add("type", Type.GetType("System.Int32"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("status", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { 161, "", "" });
            rectjson json = new rectjson();
            json.deviceId = "B827EB4FFB4E";
            json.data = dt;
            jsonlist.Add(json);
            string jsonstr = Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
            richTextBox6.Text = "";
            richTextBox6.Text = "发送下转命令：\r\n" + jsonstr;
            // 测试发布
            mqttClient1.PublishMessage(new MqttApplicationMessage()
            {
                Topic = "cloud/v2/cmd",                                           // 主题
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,     // 消息等级
                Payload = System.Text.Encoding.ASCII.GetBytes(jsonstr),           // 数据
                Retain = false,                                                   // 是否保留
            });
        }

        private void button6_Click(object sender, EventArgs e)
        {
            goup();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            gobottom();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            goleft();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            goright();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            gostop();
        }
     
    }
}
