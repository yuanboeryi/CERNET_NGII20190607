﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MQTTTest
{
    public class msgvalue
    {
        string _type = "";

        public string type
        {
            get { return _type; }
            set { _type = value; }
        }
        string _value = "";

        public string value
        {
            get { return _value; }
            set { _value = value; }
        }
        string _status = "";

        public string status
        {
            get { return _status; }
            set { _status = value; }
        }
    }
}
