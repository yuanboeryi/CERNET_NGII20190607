﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MQTTTest
{
    class rectjson
    {
        string _deviceId = "";

        public string deviceId
        {
            get { return _deviceId; }
            set { _deviceId = value; }
        }
        DataTable _data = new DataTable();

        public DataTable data
        {
            get { return _data; }
            set { _data = value; }
        }
    }
}
