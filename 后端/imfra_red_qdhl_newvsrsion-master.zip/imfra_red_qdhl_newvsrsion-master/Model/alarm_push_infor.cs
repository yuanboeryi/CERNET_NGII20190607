﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// alarm_push_infor:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class alarm_push_infor
	{
		public alarm_push_infor()
		{ }
		#region Model
		private string _id = "0";
		private string _areaid;
		private string _areaname;
		private string _fenbuid;
		private string _fenbuname;
		private string _ywbid;
		private string _ywbname;
		private string _stationid;
		private string _stationname;
		private string _buildingid;
		private string _buildingname;
		private string _machineid;
		private string _machinename;
		private string _ysdid;
		private string _ysdname;
		private string _deviceid;
		private string _devicename;
		private string _devicetype;
		private string _alarmvalue;
		private string _isok;
		private string _ysdtype;
		private string _overvalue;
		private DateTime? _createtime;
		private string _image_url;
		private string _isread;
		private string _fuhe;
		private string _mensurehuman;
		private string _report_device_id;
		private DateTime? _mensuretime;
		private string _ispush = "0";
		/// <summary>
		/// 
		/// </summary>
		public string id
		{
			set { _id = value; }
			get { return _id; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaid
		{
			set { _areaid = value; }
			get { return _areaid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaname
		{
			set { _areaname = value; }
			get { return _areaname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuid
		{
			set { _fenbuid = value; }
			get { return _fenbuid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuname
		{
			set { _fenbuname = value; }
			get { return _fenbuname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbid
		{
			set { _ywbid = value; }
			get { return _ywbid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbname
		{
			set { _ywbname = value; }
			get { return _ywbname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string stationid
		{
			set { _stationid = value; }
			get { return _stationid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string stationname
		{
			set { _stationname = value; }
			get { return _stationname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string buildingid
		{
			set { _buildingid = value; }
			get { return _buildingid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string buildingname
		{
			set { _buildingname = value; }
			get { return _buildingname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string machineid
		{
			set { _machineid = value; }
			get { return _machineid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string machinename
		{
			set { _machinename = value; }
			get { return _machinename; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ysdid
		{
			set { _ysdid = value; }
			get { return _ysdid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ysdname
		{
			set { _ysdname = value; }
			get { return _ysdname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string deviceid
		{
			set { _deviceid = value; }
			get { return _deviceid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string devicename
		{
			set { _devicename = value; }
			get { return _devicename; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string devicetype
		{
			set { _devicetype = value; }
			get { return _devicetype; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string alarmvalue
		{
			set { _alarmvalue = value; }
			get { return _alarmvalue; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string isok
		{
			set { _isok = value; }
			get { return _isok; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ysdtype
		{
			set { _ysdtype = value; }
			get { return _ysdtype; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string overvalue
		{
			set { _overvalue = value; }
			get { return _overvalue; }
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? createtime
		{
			set { _createtime = value; }
			get { return _createtime; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string image_url
		{
			set { _image_url = value; }
			get { return _image_url; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string isread
		{
			set { _isread = value; }
			get { return _isread; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string fuhe
		{
			set { _fuhe = value; }
			get { return _fuhe; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string mensurehuman
		{
			set { _mensurehuman = value; }
			get { return _mensurehuman; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string report_device_id
		{
			set { _report_device_id = value; }
			get { return _report_device_id; }
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? mensuretime
		{
			set { _mensuretime = value; }
			get { return _mensuretime; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string IsPush
		{
			set { _ispush = value; }
			get { return _ispush; }
		}
		#endregion Model

	}
}

