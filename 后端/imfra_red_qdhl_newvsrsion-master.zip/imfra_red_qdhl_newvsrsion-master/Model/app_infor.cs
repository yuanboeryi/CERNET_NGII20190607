﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// app_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class app_infor
    {
        public app_infor()
        { }
        #region Model
        private string _id;
        private string _version_no;
        private string _version_note;
        private string _download_url;
        private string _platform_target;
        private DateTime? _createtime;
        private string _isopen;
        /// <summary>
        /// 
        /// </summary>
        public string id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string version_no
        {
            set { _version_no = value; }
            get { return _version_no; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string version_note
        {
            set { _version_note = value; }
            get { return _version_note; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string download_url
        {
            set { _download_url = value; }
            get { return _download_url; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string platform_target
        {
            set { _platform_target = value; }
            get { return _platform_target; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? createtime
        {
            set { _createtime = value; }
            get { return _createtime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string isopen
        {
            set { _isopen = value; }
            get { return _isopen; }
        }
        #endregion Model

    }
}

