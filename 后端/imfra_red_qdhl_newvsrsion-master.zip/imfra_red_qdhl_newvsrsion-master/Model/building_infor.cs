﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// building_infor:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class building_infor
	{
		public building_infor()
		{}
		#region Model
		private string _buildingid;
		private string _areaid;
		private string _areaname;
		private string _fenbuid;
		private string _fenbuname;
		private string _ywbid;
		private string _ywbname;
		private string _stationid;
		private string _stationname;
		private string _buildingname;
		private string _topvalue;
		private string _alarmcount;
		private DateTime? _createtime;
		/// <summary>
		/// 
		/// </summary>
		public string buildingid
		{
			set{ _buildingid=value;}
			get{return _buildingid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaid
		{
			set{ _areaid=value;}
			get{return _areaid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaname
		{
			set{ _areaname=value;}
			get{return _areaname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuid
		{
			set{ _fenbuid=value;}
			get{return _fenbuid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuname
		{
			set{ _fenbuname=value;}
			get{return _fenbuname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbid
		{
			set{ _ywbid=value;}
			get{return _ywbid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbname
		{
			set{ _ywbname=value;}
			get{return _ywbname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string stationid
		{
			set{ _stationid=value;}
			get{return _stationid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string stationname
		{
			set{ _stationname=value;}
			get{return _stationname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string buildingname
		{
			set{ _buildingname=value;}
			get{return _buildingname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string topvalue
		{
			set{ _topvalue=value;}
			get{return _topvalue;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string alarmcount
		{
			set{ _alarmcount=value;}
			get{return _alarmcount;}
		}
		/// <summary>
		/// on update CURRENT_TIMESTAMP
		/// </summary>
		public DateTime? createtime
		{
			set{ _createtime=value;}
			get{return _createtime;}
		}
		#endregion Model

	}
}

