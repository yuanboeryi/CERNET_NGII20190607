﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// city_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class city_infor
    {
        public city_infor()
        { }
        #region Model
        private string _cityid;
        private string _ywbid;
        private string _ywbname;
        private string _cityname;
        private string _devicetopvalue;
        private string _windspeed;
        private string _humidity;
        private string _weather;
        private string _citytemputer;
        private string _weatnerinfor;
        private string _jingdu;
        private string _weidu;
        private string _temprecordid;
        /// <summary>
        /// 
        /// </summary>
        public string cityid
        {
            set { _cityid = value; }
            get { return _cityid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbid
        {
            set { _ywbid = value; }
            get { return _ywbid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string cityname
        {
            set { _cityname = value; }
            get { return _cityname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicetopvalue
        {
            set { _devicetopvalue = value; }
            get { return _devicetopvalue; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string windspeed
        {
            set { _windspeed = value; }
            get { return _windspeed; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string humidity
        {
            set { _humidity = value; }
            get { return _humidity; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string weather
        {
            set { _weather = value; }
            get { return _weather; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string citytemputer
        {
            set { _citytemputer = value; }
            get { return _citytemputer; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string weatnerinfor
        {
            set { _weatnerinfor = value; }
            get { return _weatnerinfor; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string jingdu
        {
            set { _jingdu = value; }
            get { return _jingdu; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string weidu
        {
            set { _weidu = value; }
            get { return _weidu; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string temprecordid
        {
            set { _temprecordid = value; }
            get { return _temprecordid; }
        }
        #endregion Model

    }
}

