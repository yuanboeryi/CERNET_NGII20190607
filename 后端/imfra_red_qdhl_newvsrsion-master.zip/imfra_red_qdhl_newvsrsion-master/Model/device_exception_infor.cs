﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// device_exception_infor:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class device_exception_infor
	{
		public device_exception_infor()
		{ }
		#region Model
		private string _id;
		private string _deviceid;
		private string _areaid;
		private string _areaname;
		private string _fenbuid;
		private string _fenbuname;
		private string _ywbid;
		private string _ywbname;
		private string _stationid;
		private string _stationname;
		private string _buildingid;
		private string _buildingname;
		private string _machineid;
		private string _machinename;
		private string _machinecode;
		private string _ysdname;
		private string _ysdindex;
		private string _devicename;
		private string _image_red;
		private string _image_high;
		private string _image_mix;
		private DateTime? _createtime;
		private string _operaternumber;
		private string _discoverer;
		private string _typename;
		private DateTime? _catchtime;
		private string _description;
		private string _patrolid;
		private string _status = "1";//未消除状态
		private string _exceptiontypeid;//异常类型id
		private string _temperature;//温度
		/// <summary>
		/// 
		/// </summary>
		public string id
		{
			set { _id = value; }
			get { return _id; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string deviceid
		{
			set { _deviceid = value; }
			get { return _deviceid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaid
		{
			set { _areaid = value; }
			get { return _areaid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaname
		{
			set { _areaname = value; }
			get { return _areaname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuid
		{
			set { _fenbuid = value; }
			get { return _fenbuid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuname
		{
			set { _fenbuname = value; }
			get { return _fenbuname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbid
		{
			set { _ywbid = value; }
			get { return _ywbid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbname
		{
			set { _ywbname = value; }
			get { return _ywbname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string stationid
		{
			set { _stationid = value; }
			get { return _stationid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string stationname
		{
			set { _stationname = value; }
			get { return _stationname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string buildingid
		{
			set { _buildingid = value; }
			get { return _buildingid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string buildingname
		{
			set { _buildingname = value; }
			get { return _buildingname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string machineid
		{
			set { _machineid = value; }
			get { return _machineid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string machinename
		{
			set { _machinename = value; }
			get { return _machinename; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string machinecode
		{
			set { _machinecode = value; }
			get { return _machinecode; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ysdname
		{
			set { _ysdname = value; }
			get { return _ysdname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ysdindex
		{
			set { _ysdindex = value; }
			get { return _ysdindex; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string devicename
		{
			set { _devicename = value; }
			get { return _devicename; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string image_red
		{
			set { _image_red = value; }
			get { return _image_red; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string image_high
		{
			set { _image_high = value; }
			get { return _image_high; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string image_mix
		{
			set { _image_mix = value; }
			get { return _image_mix; }
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? createtime
		{
			set { _createtime = value; }
			get { return _createtime; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string operaterNumber
		{
			set { _operaternumber = value; }
			get { return _operaternumber; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string discoverer
		{
			set { _discoverer = value; }
			get { return _discoverer; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string typename
		{
			set { _typename = value; }
			get { return _typename; }
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? catchtime
		{
			set { _catchtime = value; }
			get { return _catchtime; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string description
		{
			set { _description = value; }
			get { return _description; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string patrolid
		{
			set { _patrolid = value; }
			get { return _patrolid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string status
		{
			set { _status = value; }
			get { return _status; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string exceptiontypeid
		{
			set { _exceptiontypeid = value; }
			get { return _exceptiontypeid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string temperature
		{
			set { _temperature = value; }
			get { return _temperature; }
		}
		#endregion Model

	}
}

