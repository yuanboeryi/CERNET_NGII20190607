﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// device_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class device_infor
    {
        public device_infor()
        { }
        #region Model
        private string _deviceid;
        private string _areaid;
        private string _areaname;
        private string _fenbuid;
        private string _fenbuname;
        private string _ywbid;
        private string _ywbname;
        private string _stationid;
        private string _stationname;
        private string _buildingid;
        private string _buildingname;
        private string _machineid;
        private string _machinename;
        private string _ysdname;
        private string _ysdindex;
        private string _devicename;
        private string _iskeypoint;
        private string _isroundpoint;
        private string _isopen = "0";
        private double _distance = 0;
        private string _fuhe;
        private string _offsethuman;
        private string _offsetvalue;
        private string _ysdtype;
        private string _ysdlevel;
        private string _isok = "0";
        private string _isalarm = "0";
        private string _yestodaytop = "0";
        private string _todaytop = "0";
        private string _weektop = "120";
        private string _monthtop = "120";
        private string _historytop = "120";
        private string _image_red;
        private string _image_high;
        private string _image_mix;
        private DateTime? _createtime;
        private string _templist;
        private string _fuhelist;
        private double? _orderindex;
        private string _todaymaxid;
        private string _yestodaymaxid;
        private string _weekmaxid;
        private string _monthmaxid;
        private string _historymaxid;
        private string _todaymax;
        private string _monthmax;
        private int _mediaindex;
        private string _operaterNumber;//运行编号（电力设备）

        private String _ppmax; // 预设点最高温度
        private String _ppmin; // 预设点最低温度
        private String _ppavg; // 预设点平均温度
        private String _ppcnt;
        private DateTime? _pptime; // 预设点温度更新时间
        private string _patrolStatus;//巡视状态（默认0）

        private string _multiArea;//多区域名称（用 , 隔开）
        private string _multiAreaTemperature;//多区域温度（例p0:20,p1:10）
        private string _temporary;//临时字段，在巡视接口中使用

        public string temporary
        {
            set { _temporary = value; }
            get { return _temporary; }
        }
        public string multiAreaTemperature
        {
            set { _multiAreaTemperature = value; }
            get { return _multiAreaTemperature; }
        }
        public string multiArea
        {
            set { _multiArea = value; }
            get { return _multiArea; }
        }
        public string patrolStatus
        {
            set { _patrolStatus = value; }
            get { return _patrolStatus; }
        }
        public string ppmax
        {
            set { _ppmax = value; }
            get { return _ppmax; }
        }

        public string ppmin
        {
            set { _ppmin = value; }
            get { return _ppmin; }
        }

        public string ppavg
        {
            set { _ppavg = value; }
            get { return _ppavg; }
        }

        public string ppcnt
        {
            set { _ppcnt = value; }
            get { return _ppcnt; }
        }

        public DateTime? pptime
        {
            set { _pptime = value; }
            get { return _pptime; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string deviceid
        {
            set { _deviceid = value; }
            get { return _deviceid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaid
        {
            set { _areaid = value; }
            get { return _areaid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaname
        {
            set { _areaname = value; }
            get { return _areaname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuid
        {
            set { _fenbuid = value; }
            get { return _fenbuid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuname
        {
            set { _fenbuname = value; }
            get { return _fenbuname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbid
        {
            set { _ywbid = value; }
            get { return _ywbid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationid
        {
            set { _stationid = value; }
            get { return _stationid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationname
        {
            set { _stationname = value; }
            get { return _stationname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string buildingid
        {
            set { _buildingid = value; }
            get { return _buildingid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string buildingname
        {
            set { _buildingname = value; }
            get { return _buildingname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string machineid
        {
            set { _machineid = value; }
            get { return _machineid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string machinename
        {
            set { _machinename = value; }
            get { return _machinename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ysdname
        {
            set { _ysdname = value; }
            get { return _ysdname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ysdindex
        {
            set { _ysdindex = value; }
            get { return _ysdindex; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicename
        {
            set { _devicename = value; }
            get { return _devicename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string iskeypoint
        {
            set { _iskeypoint = value; }
            get { return _iskeypoint; }
        }
        /// <summary>
        /// =1表示实时监测, =0表示非实时监测
        /// </summary>
        public string isroundpoint
        {
            set { _isroundpoint = value; }
            get { return _isroundpoint; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string isopen
        {
            set { _isopen = value; }
            get { return _isopen; }
        }
        /// <summary>
        /// 
        /// </summary>
        public double distance
        {
            set { _distance = value; }
            get { return _distance; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fuhe
        {
            set { _fuhe = value; }
            get { return _fuhe; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string offsethuman
        {
            set { _offsethuman = value; }
            get { return _offsethuman; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string offsetvalue
        {
            set { _offsetvalue = value; }
            get { return _offsetvalue; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ysdtype
        {
            set { _ysdtype = value; }
            get { return _ysdtype; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ysdlevel
        {
            set { _ysdlevel = value; }
            get { return _ysdlevel; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string isok
        {
            set { _isok = value; }
            get { return _isok; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string isalarm
        {
            set { _isalarm = value; }
            get { return _isalarm; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string yestodaytop
        {
            set { _yestodaytop = value; }
            get { return _yestodaytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string todaytop
        {
            set { _todaytop = value; }
            get { return _todaytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string weektop
        {
            set { _weektop = value; }
            get { return _weektop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string monthtop
        {
            set { _monthtop = value; }
            get { return _monthtop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string historytop
        {
            set { _historytop = value; }
            get { return _historytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string image_red
        {
            set { _image_red = value; }
            get { return _image_red; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string image_high
        {
            set { _image_high = value; }
            get { return _image_high; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string image_mix
        {
            set { _image_mix = value; }
            get { return _image_mix; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? createtime
        {
            set { _createtime = value; }
            get { return _createtime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string templist
        {
            set { _templist = value; }
            get { return _templist; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fuhelist
        {
            set { _fuhelist = value; }
            get { return _fuhelist; }
        }
        /// <summary>
        /// 
        /// </summary>
        public double? orderindex
        {
            set { _orderindex = value; }
            get { return _orderindex; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string todaymaxid
        {
            set { _todaymaxid = value; }
            get { return _todaymaxid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string yestodaymaxid
        {
            set { _yestodaymaxid = value; }
            get { return _yestodaymaxid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string weekmaxid
        {
            set { _weekmaxid = value; }
            get { return _weekmaxid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string monthmaxid
        {
            set { _monthmaxid = value; }
            get { return _monthmaxid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string historymaxid
        {
            set { _historymaxid = value; }
            get { return _historymaxid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string todaymax
        {
            set { _todaymax = value; }
            get { return _todaymax; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string monthmax
        {
            set { _monthmax = value; }
            get { return _monthmax; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int mediaindex
        {
            set { _mediaindex = value; }
            get { return _mediaindex; }
        }
        public string operaterNumber
        {
            set { _operaterNumber = value; }
            get { return _operaterNumber; }
        }



        #endregion Model

    }
}

