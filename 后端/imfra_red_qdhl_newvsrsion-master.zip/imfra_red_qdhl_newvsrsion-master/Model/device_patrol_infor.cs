﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// device_patrol_infor:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class device_patrol_infor
	{
		public device_patrol_infor()
		{ }
		#region Model
		private string _patrolid;
		private DateTime? _createtime;
		private string _inspector;
		private string _conclusion;
		private int? _exceptionnumber;
		private int? _patrolnumber;
		private string _stationid;
		private string _stationname;
		private string _areaid;
		private string _areaname;
		private string _fenbuid;
		private string _fenbuname;
		private string _ywbid;
		private string _ywbname;
		/// <summary>
		/// 
		/// </summary>
		public string patrolid
		{
			set { _patrolid = value; }
			get { return _patrolid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? createtime
		{
			set { _createtime = value; }
			get { return _createtime; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string inspector
		{
			set { _inspector = value; }
			get { return _inspector; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string conclusion
		{
			set { _conclusion = value; }
			get { return _conclusion; }
		}
		/// <summary>
		/// 
		/// </summary>
		public int? exceptionnumber
		{
			set { _exceptionnumber = value; }
			get { return _exceptionnumber; }
		}
		/// <summary>
		/// 
		/// </summary>
		public int? patrolnumber
		{
			set { _patrolnumber = value; }
			get { return _patrolnumber; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string stationid
		{
			set { _stationid = value; }
			get { return _stationid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string stationname
		{
			set { _stationname = value; }
			get { return _stationname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaid
		{
			set { _areaid = value; }
			get { return _areaid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaname
		{
			set { _areaname = value; }
			get { return _areaname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuid
		{
			set { _fenbuid = value; }
			get { return _fenbuid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuname
		{
			set { _fenbuname = value; }
			get { return _fenbuname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbid
		{
			set { _ywbid = value; }
			get { return _ywbid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbname
		{
			set { _ywbname = value; }
			get { return _ywbname; }
		}
		#endregion Model

	}
}

