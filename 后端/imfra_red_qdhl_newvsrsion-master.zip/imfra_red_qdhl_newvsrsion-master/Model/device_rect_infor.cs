﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// device_rect_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class device_rect_infor
    {
        public device_rect_infor()
        { }
        #region Model
        private string _rectid;
        private string _deviceid;
        private string _devicename;
        private int _rectindex;
        private string _rectname;
        private string _pointlist;
        private DateTime? _createtime;
        private int _width;
        private int _height;


        public int height
        {
            get { return _height; }
            set { _height = value; }
        }

        public int width
        {
            get { return _width; }
            set { _width = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string rectid
        {
            set { _rectid = value; }
            get { return _rectid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string deviceid
        {
            set { _deviceid = value; }
            get { return _deviceid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicename
        {
            set { _devicename = value; }
            get { return _devicename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int rectindex
        {
            set { _rectindex = value; }
            get { return _rectindex; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string rectname
        {
            set { _rectname = value; }
            get { return _rectname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string pointlist
        {
            set { _pointlist = value; }
            get { return _pointlist; }
        }
        /// <summary>
        /// on update CURRENT_TIMESTAMP
        /// </summary>
        public DateTime? createtime
        {
            set { _createtime = value; }
            get { return _createtime; }
        }
        #endregion Model

    }
}

