﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// devicetype_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class devicetype_infor
    {
        public devicetype_infor()
        { }
        #region Model
        private string _devicetypeid;
        private string _devicetype;
        /// <summary>
        /// 
        /// </summary>
        public string devicetypeid
        {
            set { _devicetypeid = value; }
            get { return _devicetypeid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicetype
        {
            set { _devicetype = value; }
            get { return _devicetype; }
        }
        #endregion Model

    }
}

