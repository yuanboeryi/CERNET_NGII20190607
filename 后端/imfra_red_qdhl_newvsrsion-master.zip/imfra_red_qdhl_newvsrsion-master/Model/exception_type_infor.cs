﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// exception_type_infor:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class exception_type_infor
	{
		public exception_type_infor()
		{ }
		#region Model
		private string _exceptiontypeid;
		private string _description;
		private string _typename;
		/// <summary>
		/// 
		/// </summary>
		public string exceptiontypeid
		{
			set { _exceptiontypeid = value; }
			get { return _exceptiontypeid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string description
		{
			set { _description = value; }
			get { return _description; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string typename
		{
			set { _typename = value; }
			get { return _typename; }
		}
		#endregion Model

	}
}

