﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// fenbu_infor:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class fenbu_infor
	{
		public fenbu_infor()
		{}
		#region Model
		private string _fenbuid;
		private string _areaid;
		private string _areaname;
		private string _fenbuname;
		private string _manager;
		private string _phone;
		private string _address;
		private DateTime? _createtime;
		/// <summary>
		/// 
		/// </summary>
		public string fenbuid
		{
			set{ _fenbuid=value;}
			get{return _fenbuid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaid
		{
			set{ _areaid=value;}
			get{return _areaid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaname
		{
			set{ _areaname=value;}
			get{return _areaname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuname
		{
			set{ _fenbuname=value;}
			get{return _fenbuname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string manager
		{
			set{ _manager=value;}
			get{return _manager;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string phone
		{
			set{ _phone=value;}
			get{return _phone;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string address
		{
			set{ _address=value;}
			get{return _address;}
		}
		/// <summary>
		/// on update CURRENT_TIMESTAMP
		/// </summary>
		public DateTime? createtime
		{
			set{ _createtime=value;}
			get{return _createtime;}
		}
		#endregion Model

	}
}

