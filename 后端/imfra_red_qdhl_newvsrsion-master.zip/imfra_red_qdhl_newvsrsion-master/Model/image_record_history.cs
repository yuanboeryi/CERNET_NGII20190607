﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// image_record_history:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class image_record_history
    {
        public image_record_history()
        { }
        #region Model
        private string _recordid;
        private string _deviceid;
        private string _devicename;
        private string _machinemac;
        private string _deviceindex;
        private string _image0;
        private string _image1;
        private string _image2;
        private string _valuemax;
        private string _valuemin;
        private string _valueave;
        private string _templist_24;
        private string _isalarm;
        private DateTime? _createtime;
        private string _areaid;
        private string _areaname;
        private string _fenbuid;
        private string _fenbuname;
        private string _ywbid;
        private string _ywbname;
        /// <summary>
        /// 
        /// </summary>
        public string recordid
        {
            set { _recordid = value; }
            get { return _recordid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string deviceid
        {
            set { _deviceid = value; }
            get { return _deviceid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicename
        {
            set { _devicename = value; }
            get { return _devicename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string machinemac
        {
            set { _machinemac = value; }
            get { return _machinemac; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string deviceindex
        {
            set { _deviceindex = value; }
            get { return _deviceindex; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string image0
        {
            set { _image0 = value; }
            get { return _image0; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string image1
        {
            set { _image1 = value; }
            get { return _image1; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string image2
        {
            set { _image2 = value; }
            get { return _image2; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string valuemax
        {
            set { _valuemax = value; }
            get { return _valuemax; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string valuemin
        {
            set { _valuemin = value; }
            get { return _valuemin; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string valueave
        {
            set { _valueave = value; }
            get { return _valueave; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string templist_24
        {
            set { _templist_24 = value; }
            get { return _templist_24; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string isalarm
        {
            set { _isalarm = value; }
            get { return _isalarm; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? createtime
        {
            set { _createtime = value; }
            get { return _createtime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaid
        {
            set { _areaid = value; }
            get { return _areaid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaname
        {
            set { _areaname = value; }
            get { return _areaname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuid
        {
            set { _fenbuid = value; }
            get { return _fenbuid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuname
        {
            set { _fenbuname = value; }
            get { return _fenbuname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbid
        {
            set { _ywbid = value; }
            get { return _ywbid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        #endregion Model

    }
}

