﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// machine_infor:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class machine_infor
	{
		public machine_infor()
		{}
		#region Model
		private string _machineid;
		private string _areaid;
		private string _areaname;
		private string _fenbuid;
		private string _fenbuname;
		private string _ywbid;
		private string _ywbname;
		private string _stationid;
		private string _stationname;
		private string _buildingid;
		private string _buildingname;
		private string _machinename;
		private string _machinecompany;
		private string _machinemac;
		private string _machinecode;
		private string _installcode;
		private string _currentversion;
		private string _newversion;
		private string _machinestate;
		private string _ysdcount;
		private DateTime? _onlinetime;
		private string _runtime;
		private string _imagecatchspan;
		private string _wifiname;
		private string _wifipass;
		private string _fushelv;
		private string _offsetvalue;
		private string _buchang;
		private string _topvalue;
		private DateTime? _createtime;

		private string _cloudaddr;
		private string _ftpaddr;
		private string _warntemp;
		private string _capinterv;
		private string _insinterv;
		private string _sv;
		private string _rv;
		private string _lv;
		private string _tv;
		private int _mediaIndex;
		private string _piflirversion;
		private string _pivideoversion;

		public string Ftpaddr
		{
			set { _ftpaddr = value; }
			get { return _ftpaddr; }
		}

		public string Warntemp
		{
			set { _warntemp = value; }
			get { return _warntemp; }
		}

		public string piFlirVersion
        {
			set { _piflirversion = value; }
			get { return _piflirversion; }
        }

		public string piVideoVersion
        {
			set { _pivideoversion = value; }
			get { return _pivideoversion; }
        }

		public int MediaIndex
		{
			set { _mediaIndex = value; }
			get { return _mediaIndex; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string machineid
		{
			set{ _machineid=value;}
			get{return _machineid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaid
		{
			set{ _areaid=value;}
			get{return _areaid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaname
		{
			set{ _areaname=value;}
			get{return _areaname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuid
		{
			set{ _fenbuid=value;}
			get{return _fenbuid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuname
		{
			set{ _fenbuname=value;}
			get{return _fenbuname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbid
		{
			set{ _ywbid=value;}
			get{return _ywbid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbname
		{
			set{ _ywbname=value;}
			get{return _ywbname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string stationid
		{
			set{ _stationid=value;}
			get{return _stationid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string stationname
		{
			set{ _stationname=value;}
			get{return _stationname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string buildingid
		{
			set{ _buildingid=value;}
			get{return _buildingid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string buildingname
		{
			set{ _buildingname=value;}
			get{return _buildingname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string machinename
		{
			set{ _machinename=value;}
			get{return _machinename;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string machinecompany
		{
			set{ _machinecompany=value;}
			get{return _machinecompany;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string machinemac
		{
			set{ _machinemac=value;}
			get{return _machinemac;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string machinecode
		{
			set{ _machinecode=value;}
			get{return _machinecode;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string installcode
		{
			set{ _installcode=value;}
			get{return _installcode;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string currentversion
		{
			set{ _currentversion=value;}
			get{return _currentversion;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string newversion
		{
			set{ _newversion=value;}
			get{return _newversion;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string machinestate
		{
			set{ _machinestate=value;}
			get{return _machinestate;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ysdcount
		{
			set{ _ysdcount=value;}
			get{return _ysdcount;}
		}
		/// <summary>
		/// on update CURRENT_TIMESTAMP
		/// </summary>
		public DateTime? onlinetime
		{
			set{ _onlinetime=value;}
			get{return _onlinetime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string runtime
		{
			set{ _runtime=value;}
			get{return _runtime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string imagecatchspan
		{
			set{ _imagecatchspan=value;}
			get{return _imagecatchspan;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string wifiname
		{
			set{ _wifiname=value;}
			get{return _wifiname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string wifipass
		{
			set{ _wifipass=value;}
			get{return _wifipass;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string fushelv
		{
			set{ _fushelv=value;}
			get{return _fushelv;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string offsetvalue
		{
			set{ _offsetvalue=value;}
			get{return _offsetvalue;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string buchang
		{
			set{ _buchang=value;}
			get{return _buchang;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string topvalue
		{
			set{ _topvalue=value;}
			get{return _topvalue;}
		}
		/// <summary>
		/// on update CURRENT_TIMESTAMP
		/// </summary>
		public DateTime? createtime
		{
			set{ _createtime=value;}
			get{return _createtime;}
		}

        //public string Cloudaddr { get => _cloudaddr; set => _cloudaddr = value; }
        public string Cloudaddr {
            set { _cloudaddr = value; }
            get { return _cloudaddr; }
        }
        //public string Capinterv { get => _capinterv; set => _capinterv = value; }
        public string Capinterv
        {
            set { _capinterv = value; }
            get { return _capinterv; }
        }
        //public string Insinterv { get => _insinterv; set => _insinterv = value; }
        public string Insinterv
        {
            set { _insinterv = value; }
            get { return _insinterv; }
        }
        //public string Sv { get => _sv; set => _sv = value; }
        public string Sv
        {
            set { _sv = value; }
            get { return _sv; }
        }
        //public string Rv { get => _rv; set => _rv = value; }
        public string Rv
        {
            set { _rv = value; }
            get { return _rv; }
        }
        //public string Lv { get => _lv; set => _lv = value; }
        public string Lv
        {
            set { _lv = value; }
            get { return _lv; }
        }
        //public string Tv { get => _tv; set => _tv = value; }
        public string Tv
        {
            set { _tv = value; }
            get { return _tv; }
        }
        #endregion Model

    }
}

