﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// machinetype_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class machinetype_infor
    {
        public machinetype_infor()
        { }
        #region Model
        private string _typeid;
        private string _machinetype;
        /// <summary>
        /// 
        /// </summary>
        public string typeid
        {
            set { _typeid = value; }
            get { return _typeid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string machinetype
        {
            set { _machinetype = value; }
            get { return _machinetype; }
        }
        #endregion Model

    }
}

