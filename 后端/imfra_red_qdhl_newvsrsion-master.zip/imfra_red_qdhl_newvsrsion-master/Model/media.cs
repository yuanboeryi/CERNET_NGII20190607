﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// device_rect_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class media
    {
        public media()
        { }
        #region Model
        private int _id;
        private string _host;
        private string _port;
        private string _details;
        
        /// <summary>
        /// 
        /// </summary>
        public int Id
        {
            set { _id = value; }
            get { return _id; }
        }
      
        /// <summary>
        /// 
        /// </summary>
        public string Host
        {
            set { _host = value; }
            get { return _host; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Port
        {
            set { _port = value; }
            get { return _port; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Details
        {
            set { _details = value; }
            get { return _details; }
        }
        #endregion Model

    }
}

