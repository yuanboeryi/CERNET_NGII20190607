﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// push_token_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class push_token_infor
    {
        public push_token_infor()
        { }
        #region Model
        private string _tokenid;
        private string _tokenname;
        private string _tokenvalue;
        private string _areaname;
        private string _fenbuname;
        private string _ywbname;
        private string _stationname;
        private DateTime? _createtime;
        /// <summary>
        /// 
        /// </summary>
        public string tokenid
        {
            set { _tokenid = value; }
            get { return _tokenid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string tokenname
        {
            set { _tokenname = value; }
            get { return _tokenname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string tokenvalue
        {
            set { _tokenvalue = value; }
            get { return _tokenvalue; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaname
        {
            set { _areaname = value; }
            get { return _areaname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuname
        {
            set { _fenbuname = value; }
            get { return _fenbuname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationname
        {
            set { _stationname = value; }
            get { return _stationname; }
        }
        /// <summary>
        /// on update CURRENT_TIMESTAMP
        /// </summary>
        public DateTime? createtime
        {
            set { _createtime = value; }
            get { return _createtime; }
        }
        #endregion Model

    }
}

