﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// quetu_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class quetu_infor
    {
        public quetu_infor()
        { }
        #region Model
        private string _recordid;
        private string _deviceid;
        private string _devicename;
        private string _areaid;
        private string _areaname;
        private string _fenbuid;
        private string _fenbuname;
        private string _ywbid;
        private string _ywbname;
        private string _stationid;
        private string _stationname;
        private DateTime? _quetudate;
        private string _quetutime;
        private string _queinfor;
        /// <summary>
        /// 
        /// </summary>
        public string recordid
        {
            set { _recordid = value; }
            get { return _recordid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string deviceid
        {
            set { _deviceid = value; }
            get { return _deviceid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicename
        {
            set { _devicename = value; }
            get { return _devicename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaid
        {
            set { _areaid = value; }
            get { return _areaid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaname
        {
            set { _areaname = value; }
            get { return _areaname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuid
        {
            set { _fenbuid = value; }
            get { return _fenbuid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuname
        {
            set { _fenbuname = value; }
            get { return _fenbuname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbid
        {
            set { _ywbid = value; }
            get { return _ywbid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationid
        {
            set { _stationid = value; }
            get { return _stationid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationname
        {
            set { _stationname = value; }
            get { return _stationname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? quetudate
        {
            set { _quetudate = value; }
            get { return _quetudate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string quetutime
        {
            set { _quetutime = value; }
            get { return _quetutime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string queinfor
        {
            set { _queinfor = value; }
            get { return _queinfor; }
        }
        #endregion Model

    }
}

