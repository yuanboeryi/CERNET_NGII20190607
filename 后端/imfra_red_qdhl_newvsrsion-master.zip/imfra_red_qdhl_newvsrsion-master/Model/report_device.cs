﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// report_device:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class report_device
    {
        public report_device()
        { }
        #region Model
        private string _devicereportid;
        private string _fenbuname;
        private string _ywbname;
        private string _stationnane;
        private string _devicename;
        private string _devicelevel;
        private string _fuhe;
        private DateTime? _alarmtime;
        private string _alarmtemp;
        private string _machinename;
        private string _machinecode;
        private string _buildingname;
        private string _image_red;
        private string _image_high;
        private string _templist_24;
        private string _templist_30;
        private string _manager1;
        private string _manager2;
        private string _manager3;
        private string _note1;
        private string _note2;
        private string _note3;
        /// <summary>
        /// 
        /// </summary>
        public string devicereportid
        {
            set { _devicereportid = value; }
            get { return _devicereportid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuname
        {
            set { _fenbuname = value; }
            get { return _fenbuname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationnane
        {
            set { _stationnane = value; }
            get { return _stationnane; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicename
        {
            set { _devicename = value; }
            get { return _devicename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicelevel
        {
            set { _devicelevel = value; }
            get { return _devicelevel; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fuhe
        {
            set { _fuhe = value; }
            get { return _fuhe; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? alarmtime
        {
            set { _alarmtime = value; }
            get { return _alarmtime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string alarmtemp
        {
            set { _alarmtemp = value; }
            get { return _alarmtemp; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string machinename
        {
            set { _machinename = value; }
            get { return _machinename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string machinecode
        {
            set { _machinecode = value; }
            get { return _machinecode; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string buildingname
        {
            set { _buildingname = value; }
            get { return _buildingname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string image_red
        {
            set { _image_red = value; }
            get { return _image_red; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string image_high
        {
            set { _image_high = value; }
            get { return _image_high; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string templist_24
        {
            set { _templist_24 = value; }
            get { return _templist_24; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string templist_30
        {
            set { _templist_30 = value; }
            get { return _templist_30; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string manager1
        {
            set { _manager1 = value; }
            get { return _manager1; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string manager2
        {
            set { _manager2 = value; }
            get { return _manager2; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string manager3
        {
            set { _manager3 = value; }
            get { return _manager3; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string note1
        {
            set { _note1 = value; }
            get { return _note1; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string note2
        {
            set { _note2 = value; }
            get { return _note2; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string note3
        {
            set { _note3 = value; }
            get { return _note3; }
        }
        #endregion Model

    }
}

