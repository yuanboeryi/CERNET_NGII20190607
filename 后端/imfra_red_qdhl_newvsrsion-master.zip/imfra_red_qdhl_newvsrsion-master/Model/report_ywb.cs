﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// report_ywb:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class report_ywb
    {
        public report_ywb()
        { }
        #region Model
        private string _ywbreportid;
        private DateTime? _reporttime;
        private string _reportdanwei;
        private string _devicereport;
        private string _hightempreport;
        private string _alarmreport;
        private string _image_red_list;
        private string _image_hihg_list;
        private string _qushireport;
        private string _templist_24;
        private string _templist_7;
        private string _ywbname;
        private string _manager;
        /// <summary>
        /// 
        /// </summary>
        public string ywbreportid
        {
            set { _ywbreportid = value; }
            get { return _ywbreportid; }
        }
        /// <summary>
        /// on update CURRENT_TIMESTAMP
        /// </summary>
        public DateTime? reporttime
        {
            set { _reporttime = value; }
            get { return _reporttime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string reportdanwei
        {
            set { _reportdanwei = value; }
            get { return _reportdanwei; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicereport
        {
            set { _devicereport = value; }
            get { return _devicereport; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string hightempreport
        {
            set { _hightempreport = value; }
            get { return _hightempreport; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string alarmreport
        {
            set { _alarmreport = value; }
            get { return _alarmreport; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string image_red_list
        {
            set { _image_red_list = value; }
            get { return _image_red_list; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string image_hihg_list
        {
            set { _image_hihg_list = value; }
            get { return _image_hihg_list; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string qushireport
        {
            set { _qushireport = value; }
            get { return _qushireport; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string templist_24
        {
            set { _templist_24 = value; }
            get { return _templist_24; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string templist_7
        {
            set { _templist_7 = value; }
            get { return _templist_7; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string manager
        {
            set { _manager = value; }
            get { return _manager; }
        }
        #endregion Model

    }
}

