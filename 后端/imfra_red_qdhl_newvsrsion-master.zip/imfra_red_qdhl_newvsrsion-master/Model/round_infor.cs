﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// round_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class round_infor
    {
        public round_infor()
        { }
        #region Model
        private string _userid;
        private string _todaytop;
        private string _yestodaytop;
        private string _weektop;
        private string _monthtop;
        private string _historytop;
        /// <summary>
        /// 
        /// </summary>
        public string userid
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string todaytop
        {
            set { _todaytop = value; }
            get { return _todaytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string yestodaytop
        {
            set { _yestodaytop = value; }
            get { return _yestodaytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string weektop
        {
            set { _weektop = value; }
            get { return _weektop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string monthtop
        {
            set { _monthtop = value; }
            get { return _monthtop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string historytop
        {
            set { _historytop = value; }
            get { return _historytop; }
        }
        #endregion Model

    }
}

