﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// round_top_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class round_top_infor
    {
        public round_top_infor()
        { }
        #region Model
        private string _id;
        private string _areaid;
        private string _areaname;
        private string _fenbuid;
        private string _fenbuname;
        private string _ywbid;
        private string _ywbname;
        private string _stationid;
        private string _stationname;
        private string _todaytop;
        private string _yestodaytop;
        private string _monthtop;
        private string _weektop;
        private string _deviceid_today;
        private string _deviceid_yestoday;
        private string _deviceid_week;
        private string _deviceid_month;
        /// <summary>
        /// 
        /// </summary>
        public string id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaid
        {
            set { _areaid = value; }
            get { return _areaid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaname
        {
            set { _areaname = value; }
            get { return _areaname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuid
        {
            set { _fenbuid = value; }
            get { return _fenbuid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuname
        {
            set { _fenbuname = value; }
            get { return _fenbuname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbid
        {
            set { _ywbid = value; }
            get { return _ywbid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationid
        {
            set { _stationid = value; }
            get { return _stationid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationname
        {
            set { _stationname = value; }
            get { return _stationname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string todayTop
        {
            set { _todaytop = value; }
            get { return _todaytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string yestodayTop
        {
            set { _yestodaytop = value; }
            get { return _yestodaytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string monthTop
        {
            set { _monthtop = value; }
            get { return _monthtop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string weekTop
        {
            set { _weektop = value; }
            get { return _weektop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string deviceid_today
        {
            set { _deviceid_today = value; }
            get { return _deviceid_today; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string deviceid_yestoday
        {
            set { _deviceid_yestoday = value; }
            get { return _deviceid_yestoday; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string deviceid_week
        {
            set { _deviceid_week = value; }
            get { return _deviceid_week; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string deviceid_month
        {
            set { _deviceid_month = value; }
            get { return _deviceid_month; }
        }
        #endregion Model

    }
}

