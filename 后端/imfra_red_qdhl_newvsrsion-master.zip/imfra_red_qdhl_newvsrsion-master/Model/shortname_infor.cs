﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// shortname_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class shortname_infor
    {
        public shortname_infor()
        { }
        #region Model
        private string _nameid;
        private string _nameold;
        private string _namenew1;
        private string _namenew2;
        private string _namenew3;
        /// <summary>
        /// 
        /// </summary>
        public string nameid
        {
            set { _nameid = value; }
            get { return _nameid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string nameold
        {
            set { _nameold = value; }
            get { return _nameold; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string namenew1
        {
            set { _namenew1 = value; }
            get { return _namenew1; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string namenew2
        {
            set { _namenew2 = value; }
            get { return _namenew2; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string namenew3
        {
            set { _namenew3 = value; }
            get { return _namenew3; }
        }
        #endregion Model

    }
}

