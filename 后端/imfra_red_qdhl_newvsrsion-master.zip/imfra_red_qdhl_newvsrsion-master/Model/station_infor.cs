﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// station_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class station_infor
    {
        public station_infor()
        { }
        #region Model
        private string _stationid;
        private string _areaid;
        private string _areaname;
        private string _fenbuid;
        private string _fenbuname;
        private string _ywbid;
        private string _ywbname;
        private string _stationname;
        private string _devicecount;
        private string _manager;
        private string _phone;
        private string _stationlevel;
        private string _city;
        private string _address;
        private string _jingdu;
        private string _weidu;
        private string _topvalue;
        private string _alarmcount;
        private DateTime? _createtime;
        private string _todaytop;
        private string _yestodaytop;
        private string _weektop;
        private string _monthtop;
        private string _historytop;
        private string _todayid;
        private string _yestodayid;
        private string _weekid;
        private string _monthid;
        private string _historyid;
        private string _now_flag;
        private string _top_flag;
        /// <summary>
        /// 
        /// </summary>
        public string stationid
        {
            set { _stationid = value; }
            get { return _stationid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaid
        {
            set { _areaid = value; }
            get { return _areaid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaname
        {
            set { _areaname = value; }
            get { return _areaname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuid
        {
            set { _fenbuid = value; }
            get { return _fenbuid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuname
        {
            set { _fenbuname = value; }
            get { return _fenbuname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbid
        {
            set { _ywbid = value; }
            get { return _ywbid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationname
        {
            set { _stationname = value; }
            get { return _stationname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicecount
        {
            set { _devicecount = value; }
            get { return _devicecount; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string manager
        {
            set { _manager = value; }
            get { return _manager; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string phone
        {
            set { _phone = value; }
            get { return _phone; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationlevel
        {
            set { _stationlevel = value; }
            get { return _stationlevel; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string city
        {
            set { _city = value; }
            get { return _city; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string address
        {
            set { _address = value; }
            get { return _address; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string jingdu
        {
            set { _jingdu = value; }
            get { return _jingdu; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string weidu
        {
            set { _weidu = value; }
            get { return _weidu; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string topvalue
        {
            set { _topvalue = value; }
            get { return _topvalue; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string alarmcount
        {
            set { _alarmcount = value; }
            get { return _alarmcount; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? createtime
        {
            set { _createtime = value; }
            get { return _createtime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string todaytop
        {
            set { _todaytop = value; }
            get { return _todaytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string yestodaytop
        {
            set { _yestodaytop = value; }
            get { return _yestodaytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string weektop
        {
            set { _weektop = value; }
            get { return _weektop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string monthtop
        {
            set { _monthtop = value; }
            get { return _monthtop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string historytop
        {
            set { _historytop = value; }
            get { return _historytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string todayid
        {
            set { _todayid = value; }
            get { return _todayid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string yestodayid
        {
            set { _yestodayid = value; }
            get { return _yestodayid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string weekid
        {
            set { _weekid = value; }
            get { return _weekid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string monthid
        {
            set { _monthid = value; }
            get { return _monthid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string historyid
        {
            set { _historyid = value; }
            get { return _historyid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string now_flag
        {
            set { _now_flag = value; }
            get { return _now_flag; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string top_flag
        {
            set { _top_flag = value; }
            get { return _top_flag; }
        }
        #endregion Model

    }
}

