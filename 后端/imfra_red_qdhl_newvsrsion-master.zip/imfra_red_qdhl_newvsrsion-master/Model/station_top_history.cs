﻿using System;


namespace Maticsoft.Model
{
    /// <summary>
    /// station_top_history:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class station_top_history
    {
        public station_top_history()
        { }
        #region Model
        private string _toprecordid;
        private string _stationid;
        private string _stationname;
        private string _todaytop;
        private DateTime? _toptime;
        private string _topdevicename;
        private string _offsetvalue;
        /// <summary>
        /// 
        /// </summary>
        public string toprecordid
        {
            set { _toprecordid = value; }
            get { return _toprecordid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationid
        {
            set { _stationid = value; }
            get { return _stationid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationname
        {
            set { _stationname = value; }
            get { return _stationname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string todaytop
        {
            set { _todaytop = value; }
            get { return _todaytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? toptime
        {
            set { _toptime = value; }
            get { return _toptime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string topdevicename
        {
            set { _topdevicename = value; }
            get { return _topdevicename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string offsetvalue
        {
            set { _offsetvalue = value; }
            get { return _offsetvalue; }
        }
        #endregion Model

    }
}
