﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// station_top_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class station_top_infor
    {
        public station_top_infor()
        { }
        #region Model
        private string _stationid;
        private string _stationname;
        private string _todaytop;
        private string _topdrecord;
        private DateTime? _toptime;
        /// <summary>
        /// 
        /// </summary>
        public string stationid
        {
            set { _stationid = value; }
            get { return _stationid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationname
        {
            set { _stationname = value; }
            get { return _stationname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string todaytop
        {
            set { _todaytop = value; }
            get { return _todaytop; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string topdrecord
        {
            set { _topdrecord = value; }
            get { return _topdrecord; }
        }
        /// <summary>
        /// on update CURRENT_TIMESTAMP
        /// </summary>
        public DateTime? toptime
        {
            set { _toptime = value; }
            get { return _toptime; }
        }
        #endregion Model

    }
}

