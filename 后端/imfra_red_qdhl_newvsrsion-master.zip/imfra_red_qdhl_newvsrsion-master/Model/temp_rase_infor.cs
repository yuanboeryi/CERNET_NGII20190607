﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// temp_rase_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class temp_rase_infor
    {
        public temp_rase_infor()
        { }
        #region Model
        private string _recordid;
        private string _areaname;
        private string _fenbuname;
        private string _ywbname;
        private string _stationname;
        private string _buildingname;
        private string _devicetype;
        private string _devicename;
        private string _areaid;
        private string _fenbuid;
        private string _ywbid;
        private string _stationid;
        private string _buildingid;
        private string _deviceid;
        private DateTime? _createtime;
        private string _lasttemp;
        private string _nowtemp;
        private string _overtemp;
        /// <summary>
        /// 
        /// </summary>
        public string recordid
        {
            set { _recordid = value; }
            get { return _recordid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaname
        {
            set { _areaname = value; }
            get { return _areaname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuname
        {
            set { _fenbuname = value; }
            get { return _fenbuname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationname
        {
            set { _stationname = value; }
            get { return _stationname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string buildingname
        {
            set { _buildingname = value; }
            get { return _buildingname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicetype
        {
            set { _devicetype = value; }
            get { return _devicetype; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string devicename
        {
            set { _devicename = value; }
            get { return _devicename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaid
        {
            set { _areaid = value; }
            get { return _areaid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuid
        {
            set { _fenbuid = value; }
            get { return _fenbuid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbid
        {
            set { _ywbid = value; }
            get { return _ywbid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationid
        {
            set { _stationid = value; }
            get { return _stationid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string buildingid
        {
            set { _buildingid = value; }
            get { return _buildingid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string deviceid
        {
            set { _deviceid = value; }
            get { return _deviceid; }
        }
        /// <summary>
        /// on update CURRENT_TIMESTAMP
        /// </summary>
        public DateTime? createtime
        {
            set { _createtime = value; }
            get { return _createtime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string lasttemp
        {
            set { _lasttemp = value; }
            get { return _lasttemp; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string nowtemp
        {
            set { _nowtemp = value; }
            get { return _nowtemp; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string overtemp
        {
            set { _overtemp = value; }
            get { return _overtemp; }
        }
        #endregion Model

    }
}

