﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// thisismytesttable:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class thisismytesttable
    {
        public thisismytesttable()
        { }
        #region Model
        private string _id;
        private string _imagename;
        /// <summary>
        /// 
        /// </summary>
        public string id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string imagename
        {
            set { _imagename = value; }
            get { return _imagename; }
        }
        #endregion Model

    }
}

