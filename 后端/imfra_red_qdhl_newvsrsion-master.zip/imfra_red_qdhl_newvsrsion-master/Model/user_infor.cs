﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// user_infor:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class user_infor
	{
		public user_infor()
		{ }
		#region Model
		private string _userid;
		private string _areaid;
		private string _areaname;
		private string _fenbuid;
		private string _fenbuname;
		private string _ywbid;
		private string _ywbname;
		private string _username;
		private string _password;
		private string _usertype;
		private string _city;
		private string _manager;
		private string _phone;
		private DateTime? _createtime;
		private string _show;
		private string _jingdu;
		private string _weidu;
		/// <summary>
		/// 
		/// </summary>
		public string userid
		{
			set { _userid = value; }
			get { return _userid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaid
		{
			set { _areaid = value; }
			get { return _areaid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string areaname
		{
			set { _areaname = value; }
			get { return _areaname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuid
		{
			set { _fenbuid = value; }
			get { return _fenbuid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string fenbuname
		{
			set { _fenbuname = value; }
			get { return _fenbuname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbid
		{
			set { _ywbid = value; }
			get { return _ywbid; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ywbname
		{
			set { _ywbname = value; }
			get { return _ywbname; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string username
		{
			set { _username = value; }
			get { return _username; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string password
		{
			set { _password = value; }
			get { return _password; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string usertype
		{
			set { _usertype = value; }
			get { return _usertype; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string city
		{
			set { _city = value; }
			get { return _city; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string manager
		{
			set { _manager = value; }
			get { return _manager; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string phone
		{
			set { _phone = value; }
			get { return _phone; }
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? createtime
		{
			set { _createtime = value; }
			get { return _createtime; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string show
		{
			set { _show = value; }
			get { return _show; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string JingDu
		{
			set { _jingdu = value; }
			get { return _jingdu; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string WeiDu
		{
			set { _weidu = value; }
			get { return _weidu; }
		}
		#endregion Model

	}
}

