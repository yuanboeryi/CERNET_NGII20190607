﻿using System;
namespace Maticsoft.Model
{
    /// <summary>
    /// ysd_infor:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class ysd_infor
    {
        public ysd_infor()
        { }
        #region Model
        private string _ysdid;
        private string _areaid;
        private string _areaname;
        private string _fenbuid;
        private string _fenbuname;
        private string _ywbid;
        private string _ywbname;
        private string _stationid;
        private string _stationname;
        private string _buildingid;
        private string _buildingname;
        private string _machineid;
        private string _machinename;
        private string _ysdname;
        private string _iskeypoint;
        private string _isroundpoint;
        private DateTime? _createtime;
        private double _orderindex;
        /// <summary>
        /// 
        /// </summary>
        public string ysdid
        {
            set { _ysdid = value; }
            get { return _ysdid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaid
        {
            set { _areaid = value; }
            get { return _areaid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string areaname
        {
            set { _areaname = value; }
            get { return _areaname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuid
        {
            set { _fenbuid = value; }
            get { return _fenbuid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string fenbuname
        {
            set { _fenbuname = value; }
            get { return _fenbuname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbid
        {
            set { _ywbid = value; }
            get { return _ywbid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ywbname
        {
            set { _ywbname = value; }
            get { return _ywbname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationid
        {
            set { _stationid = value; }
            get { return _stationid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string stationname
        {
            set { _stationname = value; }
            get { return _stationname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string buildingid
        {
            set { _buildingid = value; }
            get { return _buildingid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string buildingname
        {
            set { _buildingname = value; }
            get { return _buildingname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string machineid
        {
            set { _machineid = value; }
            get { return _machineid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string machinename
        {
            set { _machinename = value; }
            get { return _machinename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ysdname
        {
            set { _ysdname = value; }
            get { return _ysdname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string iskeypoint
        {
            set { _iskeypoint = value; }
            get { return _iskeypoint; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string isroundpoint
        {
            set { _isroundpoint = value; }
            get { return _isroundpoint; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? createtime
        {
            set { _createtime = value; }
            get { return _createtime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public double orderindex
        {
            set { _orderindex = value; }
            get { return _orderindex; }
        }
        #endregion Model

    }
}

