﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.alarm_push_infor
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtid.Text.Trim().Length==0)
			{
				strErr+="id不能为空！\\n";	
			}
			if(this.txtareaid.Text.Trim().Length==0)
			{
				strErr+="areaid不能为空！\\n";	
			}
			if(this.txtareaname.Text.Trim().Length==0)
			{
				strErr+="areaname不能为空！\\n";	
			}
			if(this.txtfenbuid.Text.Trim().Length==0)
			{
				strErr+="fenbuid不能为空！\\n";	
			}
			if(this.txtfenbuname.Text.Trim().Length==0)
			{
				strErr+="fenbuname不能为空！\\n";	
			}
			if(this.txtywbid.Text.Trim().Length==0)
			{
				strErr+="ywbid不能为空！\\n";	
			}
			if(this.txtywbname.Text.Trim().Length==0)
			{
				strErr+="ywbname不能为空！\\n";	
			}
			if(this.txtstationid.Text.Trim().Length==0)
			{
				strErr+="stationid不能为空！\\n";	
			}
			if(this.txtstationname.Text.Trim().Length==0)
			{
				strErr+="stationname不能为空！\\n";	
			}
			if(this.txtbuildingid.Text.Trim().Length==0)
			{
				strErr+="buildingid不能为空！\\n";	
			}
			if(this.txtbuildingname.Text.Trim().Length==0)
			{
				strErr+="buildingname不能为空！\\n";	
			}
			if(this.txtmachineid.Text.Trim().Length==0)
			{
				strErr+="machineid不能为空！\\n";	
			}
			if(this.txtmachinename.Text.Trim().Length==0)
			{
				strErr+="machinename不能为空！\\n";	
			}
			if(this.txtysdid.Text.Trim().Length==0)
			{
				strErr+="ysdid不能为空！\\n";	
			}
			if(this.txtysdname.Text.Trim().Length==0)
			{
				strErr+="ysdname不能为空！\\n";	
			}
			if(this.txtalarmvalue.Text.Trim().Length==0)
			{
				strErr+="alarmvalue不能为空！\\n";	
			}
			if(this.txtovervalue.Text.Trim().Length==0)
			{
				strErr+="overvalue不能为空！\\n";	
			}
			if(!PageValidate.IsDateTime(txtcreatetime.Text))
			{
				strErr+="on update CURRE格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string id=this.txtid.Text;
			string areaid=this.txtareaid.Text;
			string areaname=this.txtareaname.Text;
			string fenbuid=this.txtfenbuid.Text;
			string fenbuname=this.txtfenbuname.Text;
			string ywbid=this.txtywbid.Text;
			string ywbname=this.txtywbname.Text;
			string stationid=this.txtstationid.Text;
			string stationname=this.txtstationname.Text;
			string buildingid=this.txtbuildingid.Text;
			string buildingname=this.txtbuildingname.Text;
			string machineid=this.txtmachineid.Text;
			string machinename=this.txtmachinename.Text;
			string ysdid=this.txtysdid.Text;
			string ysdname=this.txtysdname.Text;
			string alarmvalue=this.txtalarmvalue.Text;
			string overvalue=this.txtovervalue.Text;
			DateTime createtime=DateTime.Parse(this.txtcreatetime.Text);

			Maticsoft.Model.alarm_push_infor model=new Maticsoft.Model.alarm_push_infor();
			model.id=id;
			model.areaid=areaid;
			model.areaname=areaname;
			model.fenbuid=fenbuid;
			model.fenbuname=fenbuname;
			model.ywbid=ywbid;
			model.ywbname=ywbname;
			model.stationid=stationid;
			model.stationname=stationname;
			model.buildingid=buildingid;
			model.buildingname=buildingname;
			model.machineid=machineid;
			model.machinename=machinename;
			model.ysdid=ysdid;
			model.ysdname=ysdname;
			model.alarmvalue=alarmvalue;
			model.overvalue=overvalue;
			model.createtime=createtime;

			Maticsoft.BLL.alarm_push_infor bll=new Maticsoft.BLL.alarm_push_infor();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
