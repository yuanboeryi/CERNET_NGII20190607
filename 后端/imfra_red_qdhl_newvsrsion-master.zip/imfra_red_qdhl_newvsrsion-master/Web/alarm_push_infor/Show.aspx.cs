﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.alarm_push_infor
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string id= strid;
					ShowInfo(id);
				}
			}
		}
		
	private void ShowInfo(string id)
	{
		Maticsoft.BLL.alarm_push_infor bll=new Maticsoft.BLL.alarm_push_infor();
		Maticsoft.Model.alarm_push_infor model=bll.GetModel(id);
		this.lblid.Text=model.id;
		this.lblareaid.Text=model.areaid;
		this.lblareaname.Text=model.areaname;
		this.lblfenbuid.Text=model.fenbuid;
		this.lblfenbuname.Text=model.fenbuname;
		this.lblywbid.Text=model.ywbid;
		this.lblywbname.Text=model.ywbname;
		this.lblstationid.Text=model.stationid;
		this.lblstationname.Text=model.stationname;
		this.lblbuildingid.Text=model.buildingid;
		this.lblbuildingname.Text=model.buildingname;
		this.lblmachineid.Text=model.machineid;
		this.lblmachinename.Text=model.machinename;
		this.lblysdid.Text=model.ysdid;
		this.lblysdname.Text=model.ysdname;
		this.lblalarmvalue.Text=model.alarmvalue;
		this.lblovervalue.Text=model.overvalue;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
