﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.app_infor
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtid.Text.Trim().Length==0)
			{
				strErr+="id不能为空！\\n";	
			}
			if(this.txtversion_no.Text.Trim().Length==0)
			{
				strErr+="version_no不能为空！\\n";	
			}
			if(this.txtversion_note.Text.Trim().Length==0)
			{
				strErr+="version_note不能为空！\\n";	
			}
			if(this.txtdownload_url.Text.Trim().Length==0)
			{
				strErr+="download_url不能为空！\\n";	
			}
			if(this.txtplatform_target.Text.Trim().Length==0)
			{
				strErr+="platform_target不能为空！\\n";	
			}
			if(!PageValidate.IsDateTime(txtcreatetime.Text))
			{
				strErr+="on update CURRE格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string id=this.txtid.Text;
			string version_no=this.txtversion_no.Text;
			string version_note=this.txtversion_note.Text;
			string download_url=this.txtdownload_url.Text;
			string platform_target=this.txtplatform_target.Text;
			DateTime createtime=DateTime.Parse(this.txtcreatetime.Text);

			Maticsoft.Model.app_infor model=new Maticsoft.Model.app_infor();
			model.id=id;
			model.version_no=version_no;
			model.version_note=version_note;
			model.download_url=download_url;
			model.platform_target=platform_target;
			model.createtime=createtime;

			Maticsoft.BLL.app_infor bll=new Maticsoft.BLL.app_infor();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
