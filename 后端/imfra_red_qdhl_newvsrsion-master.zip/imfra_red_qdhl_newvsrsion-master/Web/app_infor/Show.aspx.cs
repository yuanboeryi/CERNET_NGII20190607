﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.app_infor
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string id= strid;
					ShowInfo(id);
				}
			}
		}
		
	private void ShowInfo(string id)
	{
		Maticsoft.BLL.app_infor bll=new Maticsoft.BLL.app_infor();
		Maticsoft.Model.app_infor model=bll.GetModel(id);
		this.lblid.Text=model.id;
		this.lblversion_no.Text=model.version_no;
		this.lblversion_note.Text=model.version_note;
		this.lbldownload_url.Text=model.download_url;
		this.lblplatform_target.Text=model.platform_target;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
