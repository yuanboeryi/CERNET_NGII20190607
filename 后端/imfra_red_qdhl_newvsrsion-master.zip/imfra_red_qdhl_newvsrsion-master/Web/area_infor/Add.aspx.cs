﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.area_infor
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtareaid.Text.Trim().Length==0)
			{
				strErr+="areaid不能为空！\\n";	
			}
			if(this.txtareaname.Text.Trim().Length==0)
			{
				strErr+="areaname不能为空！\\n";	
			}
			if(this.txtmanager.Text.Trim().Length==0)
			{
				strErr+="manager不能为空！\\n";	
			}
			if(this.txtphone.Text.Trim().Length==0)
			{
				strErr+="phone不能为空！\\n";	
			}
			if(this.txtcity.Text.Trim().Length==0)
			{
				strErr+="city不能为空！\\n";	
			}
			if(this.txtaddress.Text.Trim().Length==0)
			{
				strErr+="address不能为空！\\n";	
			}
			if(!PageValidate.IsDateTime(txtcreatetime.Text))
			{
				strErr+="on update CURRE格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string areaid=this.txtareaid.Text;
			string areaname=this.txtareaname.Text;
			string manager=this.txtmanager.Text;
			string phone=this.txtphone.Text;
			string city=this.txtcity.Text;
			string address=this.txtaddress.Text;
			DateTime createtime=DateTime.Parse(this.txtcreatetime.Text);

			Maticsoft.Model.area_infor model=new Maticsoft.Model.area_infor();
			model.areaid=areaid;
			model.areaname=areaname;
			model.manager=manager;
			model.phone=phone;
			model.city=city;
			model.address=address;
			model.createtime=createtime;

			Maticsoft.BLL.area_infor bll=new Maticsoft.BLL.area_infor();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
