﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.area_infor
{
    public partial class Modify : Page
    {       

        		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					string areaid= Request.Params["id"];
					ShowInfo(areaid);
				}
			}
		}
			
	private void ShowInfo(string areaid)
	{
		Maticsoft.BLL.area_infor bll=new Maticsoft.BLL.area_infor();
		Maticsoft.Model.area_infor model=bll.GetModel(areaid);
		this.lblareaid.Text=model.areaid;
		this.txtareaname.Text=model.areaname;
		this.txtmanager.Text=model.manager;
		this.txtphone.Text=model.phone;
		this.txtcity.Text=model.city;
		this.txtaddress.Text=model.address;
		this.txtcreatetime.Text=model.createtime.ToString();

	}

		public void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtareaname.Text.Trim().Length==0)
			{
				strErr+="areaname不能为空！\\n";	
			}
			if(this.txtmanager.Text.Trim().Length==0)
			{
				strErr+="manager不能为空！\\n";	
			}
			if(this.txtphone.Text.Trim().Length==0)
			{
				strErr+="phone不能为空！\\n";	
			}
			if(this.txtcity.Text.Trim().Length==0)
			{
				strErr+="city不能为空！\\n";	
			}
			if(this.txtaddress.Text.Trim().Length==0)
			{
				strErr+="address不能为空！\\n";	
			}
			if(!PageValidate.IsDateTime(txtcreatetime.Text))
			{
				strErr+="on update CURRE格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string areaid=this.lblareaid.Text;
			string areaname=this.txtareaname.Text;
			string manager=this.txtmanager.Text;
			string phone=this.txtphone.Text;
			string city=this.txtcity.Text;
			string address=this.txtaddress.Text;
			DateTime createtime=DateTime.Parse(this.txtcreatetime.Text);


			Maticsoft.Model.area_infor model=new Maticsoft.Model.area_infor();
			model.areaid=areaid;
			model.areaname=areaname;
			model.manager=manager;
			model.phone=phone;
			model.city=city;
			model.address=address;
			model.createtime=createtime;

			Maticsoft.BLL.area_infor bll=new Maticsoft.BLL.area_infor();
			bll.Update(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","list.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
