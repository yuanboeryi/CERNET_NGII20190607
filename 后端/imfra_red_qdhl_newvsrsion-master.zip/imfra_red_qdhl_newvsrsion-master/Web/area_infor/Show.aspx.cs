﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.area_infor
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string areaid= strid;
					ShowInfo(areaid);
				}
			}
		}
		
	private void ShowInfo(string areaid)
	{
		Maticsoft.BLL.area_infor bll=new Maticsoft.BLL.area_infor();
		Maticsoft.Model.area_infor model=bll.GetModel(areaid);
		this.lblareaid.Text=model.areaid;
		this.lblareaname.Text=model.areaname;
		this.lblmanager.Text=model.manager;
		this.lblphone.Text=model.phone;
		this.lblcity.Text=model.city;
		this.lbladdress.Text=model.address;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
