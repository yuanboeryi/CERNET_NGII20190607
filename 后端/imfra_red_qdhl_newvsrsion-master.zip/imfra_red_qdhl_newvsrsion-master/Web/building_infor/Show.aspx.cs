﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.building_infor
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string buildingid= strid;
					ShowInfo(buildingid);
				}
			}
		}
		
	private void ShowInfo(string buildingid)
	{
		Maticsoft.BLL.building_infor bll=new Maticsoft.BLL.building_infor();
		Maticsoft.Model.building_infor model=bll.GetModel(buildingid);
		this.lblbuildingid.Text=model.buildingid;
		this.lblareaid.Text=model.areaid;
		this.lblareaname.Text=model.areaname;
		this.lblfenbuid.Text=model.fenbuid;
		this.lblfenbuname.Text=model.fenbuname;
		this.lblywbid.Text=model.ywbid;
		this.lblywbname.Text=model.ywbname;
		this.lblstationid.Text=model.stationid;
		this.lblstationname.Text=model.stationname;
		this.lblbuildingname.Text=model.buildingname;
		this.lbltopvalue.Text=model.topvalue;
		this.lblalarmcount.Text=model.alarmcount;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
