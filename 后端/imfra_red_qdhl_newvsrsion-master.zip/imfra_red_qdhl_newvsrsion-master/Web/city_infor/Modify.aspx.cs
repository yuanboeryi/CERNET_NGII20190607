﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.city_infor
{
    public partial class Modify : Page
    {       

        		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					string cityid= Request.Params["id"];
					ShowInfo(cityid);
				}
			}
		}
			
	private void ShowInfo(string cityid)
	{
		Maticsoft.BLL.city_infor bll=new Maticsoft.BLL.city_infor();
		Maticsoft.Model.city_infor model=bll.GetModel(cityid);
		this.lblcityid.Text=model.cityid;
		this.txtcityname.Text=model.cityname;
		this.txtdevicetopvalue.Text=model.devicetopvalue;
		this.txtcitytemputer.Text=model.citytemputer;
		this.txtweatnerinfor.Text=model.weatnerinfor;
		this.txtjingdu.Text=model.jingdu;
		this.txtweidu.Text=model.weidu;

	}

		public void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtcityname.Text.Trim().Length==0)
			{
				strErr+="cityname不能为空！\\n";	
			}
			if(this.txtdevicetopvalue.Text.Trim().Length==0)
			{
				strErr+="devicetopvalue不能为空！\\n";	
			}
			if(this.txtcitytemputer.Text.Trim().Length==0)
			{
				strErr+="citytemputer不能为空！\\n";	
			}
			if(this.txtweatnerinfor.Text.Trim().Length==0)
			{
				strErr+="weatnerinfor不能为空！\\n";	
			}
			if(this.txtjingdu.Text.Trim().Length==0)
			{
				strErr+="jingdu不能为空！\\n";	
			}
			if(this.txtweidu.Text.Trim().Length==0)
			{
				strErr+="weidu不能为空！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string cityid=this.lblcityid.Text;
			string cityname=this.txtcityname.Text;
			string devicetopvalue=this.txtdevicetopvalue.Text;
			string citytemputer=this.txtcitytemputer.Text;
			string weatnerinfor=this.txtweatnerinfor.Text;
			string jingdu=this.txtjingdu.Text;
			string weidu=this.txtweidu.Text;


			Maticsoft.Model.city_infor model=new Maticsoft.Model.city_infor();
			model.cityid=cityid;
			model.cityname=cityname;
			model.devicetopvalue=devicetopvalue;
			model.citytemputer=citytemputer;
			model.weatnerinfor=weatnerinfor;
			model.jingdu=jingdu;
			model.weidu=weidu;

			Maticsoft.BLL.city_infor bll=new Maticsoft.BLL.city_infor();
			bll.Update(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","list.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
