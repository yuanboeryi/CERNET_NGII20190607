﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.device_infor
{
    public partial class Modify : Page
    {       

        		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					string deviceid= Request.Params["id"];
					ShowInfo(deviceid);
				}
			}
		}
			
	private void ShowInfo(string deviceid)
	{
		Maticsoft.BLL.device_infor bll=new Maticsoft.BLL.device_infor();
		Maticsoft.Model.device_infor model=bll.GetModel(deviceid);
		this.lbldeviceid.Text=model.deviceid;
		this.txtareaid.Text=model.areaid;
		this.txtareaname.Text=model.areaname;
		this.txtfenbuid.Text=model.fenbuid;
		this.txtfenbuname.Text=model.fenbuname;
		this.txtywbid.Text=model.ywbid;
		this.txtywbname.Text=model.ywbname;
		this.txtstationid.Text=model.stationid;
		this.txtstationname.Text=model.stationname;
		this.txtbuildingid.Text=model.buildingid;
		this.txtbuildingname.Text=model.buildingname;
		this.txtmachineid.Text=model.machineid;
		this.txtmachinename.Text=model.machinename;
		this.txtysdname.Text=model.ysdname;
		this.txtysdindex.Text=model.ysdindex;
		this.txtdevicename.Text=model.devicename;
		this.txtiskeypoint.Text=model.iskeypoint;
		this.txtisroundpoint.Text=model.isroundpoint;
		this.txtisopen.Text=model.isopen;
		this.txtdistance.Text=model.distance;
		this.txtfuhe.Text=model.fuhe;
		this.txtoffsetvalue.Text=model.offsetvalue;
		this.txtysdtype.Text=model.ysdtype;
		this.txtysdlevel.Text=model.ysdlevel;
		this.txtisalarm.Text=model.isalarm;
		this.txtyestodaytop.Text=model.yestodaytop;
		this.txttodaytop.Text=model.todaytop;
		this.txtweektop.Text=model.weektop;
		this.txtmonthtop.Text=model.monthtop;
		this.txthistorytop.Text=model.historytop;
		this.txtcurrentimage.Text=model.currentimage;
		this.txtcreatetime.Text=model.createtime.ToString();

	}

		public void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtareaid.Text.Trim().Length==0)
			{
				strErr+="areaid不能为空！\\n";	
			}
			if(this.txtareaname.Text.Trim().Length==0)
			{
				strErr+="areaname不能为空！\\n";	
			}
			if(this.txtfenbuid.Text.Trim().Length==0)
			{
				strErr+="fenbuid不能为空！\\n";	
			}
			if(this.txtfenbuname.Text.Trim().Length==0)
			{
				strErr+="fenbuname不能为空！\\n";	
			}
			if(this.txtywbid.Text.Trim().Length==0)
			{
				strErr+="ywbid不能为空！\\n";	
			}
			if(this.txtywbname.Text.Trim().Length==0)
			{
				strErr+="ywbname不能为空！\\n";	
			}
			if(this.txtstationid.Text.Trim().Length==0)
			{
				strErr+="stationid不能为空！\\n";	
			}
			if(this.txtstationname.Text.Trim().Length==0)
			{
				strErr+="stationname不能为空！\\n";	
			}
			if(this.txtbuildingid.Text.Trim().Length==0)
			{
				strErr+="buildingid不能为空！\\n";	
			}
			if(this.txtbuildingname.Text.Trim().Length==0)
			{
				strErr+="buildingname不能为空！\\n";	
			}
			if(this.txtmachineid.Text.Trim().Length==0)
			{
				strErr+="machineid不能为空！\\n";	
			}
			if(this.txtmachinename.Text.Trim().Length==0)
			{
				strErr+="machinename不能为空！\\n";	
			}
			if(this.txtysdname.Text.Trim().Length==0)
			{
				strErr+="ysdname不能为空！\\n";	
			}
			if(this.txtysdindex.Text.Trim().Length==0)
			{
				strErr+="ysdindex不能为空！\\n";	
			}
			if(this.txtdevicename.Text.Trim().Length==0)
			{
				strErr+="devicename不能为空！\\n";	
			}
			if(this.txtiskeypoint.Text.Trim().Length==0)
			{
				strErr+="iskeypoint不能为空！\\n";	
			}
			if(this.txtisroundpoint.Text.Trim().Length==0)
			{
				strErr+="isroundpoint不能为空！\\n";	
			}
			if(this.txtisopen.Text.Trim().Length==0)
			{
				strErr+="isopen不能为空！\\n";	
			}
			if(this.txtdistance.Text.Trim().Length==0)
			{
				strErr+="distance不能为空！\\n";	
			}
			if(this.txtfuhe.Text.Trim().Length==0)
			{
				strErr+="fuhe不能为空！\\n";	
			}
			if(this.txtoffsetvalue.Text.Trim().Length==0)
			{
				strErr+="offsetvalue不能为空！\\n";	
			}
			if(this.txtysdtype.Text.Trim().Length==0)
			{
				strErr+="ysdtype不能为空！\\n";	
			}
			if(this.txtysdlevel.Text.Trim().Length==0)
			{
				strErr+="ysdlevel不能为空！\\n";	
			}
			if(this.txtisalarm.Text.Trim().Length==0)
			{
				strErr+="isalarm不能为空！\\n";	
			}
			if(this.txtyestodaytop.Text.Trim().Length==0)
			{
				strErr+="yestodaytop不能为空！\\n";	
			}
			if(this.txttodaytop.Text.Trim().Length==0)
			{
				strErr+="todaytop不能为空！\\n";	
			}
			if(this.txtweektop.Text.Trim().Length==0)
			{
				strErr+="weektop不能为空！\\n";	
			}
			if(this.txtmonthtop.Text.Trim().Length==0)
			{
				strErr+="monthtop不能为空！\\n";	
			}
			if(this.txthistorytop.Text.Trim().Length==0)
			{
				strErr+="historytop不能为空！\\n";	
			}
			if(this.txtcurrentimage.Text.Trim().Length==0)
			{
				strErr+="currentimage不能为空！\\n";	
			}
			if(!PageValidate.IsDateTime(txtcreatetime.Text))
			{
				strErr+="on update CURRE格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string deviceid=this.lbldeviceid.Text;
			string areaid=this.txtareaid.Text;
			string areaname=this.txtareaname.Text;
			string fenbuid=this.txtfenbuid.Text;
			string fenbuname=this.txtfenbuname.Text;
			string ywbid=this.txtywbid.Text;
			string ywbname=this.txtywbname.Text;
			string stationid=this.txtstationid.Text;
			string stationname=this.txtstationname.Text;
			string buildingid=this.txtbuildingid.Text;
			string buildingname=this.txtbuildingname.Text;
			string machineid=this.txtmachineid.Text;
			string machinename=this.txtmachinename.Text;
			string ysdname=this.txtysdname.Text;
			string ysdindex=this.txtysdindex.Text;
			string devicename=this.txtdevicename.Text;
			string iskeypoint=this.txtiskeypoint.Text;
			string isroundpoint=this.txtisroundpoint.Text;
			string isopen=this.txtisopen.Text;
			string distance=this.txtdistance.Text;
			string fuhe=this.txtfuhe.Text;
			string offsetvalue=this.txtoffsetvalue.Text;
			string ysdtype=this.txtysdtype.Text;
			string ysdlevel=this.txtysdlevel.Text;
			string isalarm=this.txtisalarm.Text;
			string yestodaytop=this.txtyestodaytop.Text;
			string todaytop=this.txttodaytop.Text;
			string weektop=this.txtweektop.Text;
			string monthtop=this.txtmonthtop.Text;
			string historytop=this.txthistorytop.Text;
			string currentimage=this.txtcurrentimage.Text;
			DateTime createtime=DateTime.Parse(this.txtcreatetime.Text);


			Maticsoft.Model.device_infor model=new Maticsoft.Model.device_infor();
			model.deviceid=deviceid;
			model.areaid=areaid;
			model.areaname=areaname;
			model.fenbuid=fenbuid;
			model.fenbuname=fenbuname;
			model.ywbid=ywbid;
			model.ywbname=ywbname;
			model.stationid=stationid;
			model.stationname=stationname;
			model.buildingid=buildingid;
			model.buildingname=buildingname;
			model.machineid=machineid;
			model.machinename=machinename;
			model.ysdname=ysdname;
			model.ysdindex=ysdindex;
			model.devicename=devicename;
			model.iskeypoint=iskeypoint;
			model.isroundpoint=isroundpoint;
			model.isopen=isopen;
			model.distance=distance;
			model.fuhe=fuhe;
			model.offsetvalue=offsetvalue;
			model.ysdtype=ysdtype;
			model.ysdlevel=ysdlevel;
			model.isalarm=isalarm;
			model.yestodaytop=yestodaytop;
			model.todaytop=todaytop;
			model.weektop=weektop;
			model.monthtop=monthtop;
			model.historytop=historytop;
			model.currentimage=currentimage;
			model.createtime=createtime;

			Maticsoft.BLL.device_infor bll=new Maticsoft.BLL.device_infor();
			bll.Update(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","list.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
