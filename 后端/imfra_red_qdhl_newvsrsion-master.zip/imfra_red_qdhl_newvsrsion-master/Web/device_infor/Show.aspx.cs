﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.device_infor
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string deviceid= strid;
					ShowInfo(deviceid);
				}
			}
		}
		
	private void ShowInfo(string deviceid)
	{
		Maticsoft.BLL.device_infor bll=new Maticsoft.BLL.device_infor();
		Maticsoft.Model.device_infor model=bll.GetModel(deviceid);
		this.lbldeviceid.Text=model.deviceid;
		this.lblareaid.Text=model.areaid;
		this.lblareaname.Text=model.areaname;
		this.lblfenbuid.Text=model.fenbuid;
		this.lblfenbuname.Text=model.fenbuname;
		this.lblywbid.Text=model.ywbid;
		this.lblywbname.Text=model.ywbname;
		this.lblstationid.Text=model.stationid;
		this.lblstationname.Text=model.stationname;
		this.lblbuildingid.Text=model.buildingid;
		this.lblbuildingname.Text=model.buildingname;
		this.lblmachineid.Text=model.machineid;
		this.lblmachinename.Text=model.machinename;
		this.lblysdname.Text=model.ysdname;
		this.lblysdindex.Text=model.ysdindex;
		this.lbldevicename.Text=model.devicename;
		this.lbliskeypoint.Text=model.iskeypoint;
		this.lblisroundpoint.Text=model.isroundpoint;
		this.lblisopen.Text=model.isopen;
		this.lbldistance.Text=model.distance;
		this.lblfuhe.Text=model.fuhe;
		this.lbloffsetvalue.Text=model.offsetvalue;
		this.lblysdtype.Text=model.ysdtype;
		this.lblysdlevel.Text=model.ysdlevel;
		this.lblisalarm.Text=model.isalarm;
		this.lblyestodaytop.Text=model.yestodaytop;
		this.lbltodaytop.Text=model.todaytop;
		this.lblweektop.Text=model.weektop;
		this.lblmonthtop.Text=model.monthtop;
		this.lblhistorytop.Text=model.historytop;
		this.lblcurrentimage.Text=model.currentimage;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
