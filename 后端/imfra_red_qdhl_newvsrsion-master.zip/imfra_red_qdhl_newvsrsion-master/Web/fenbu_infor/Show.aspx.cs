﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.fenbu_infor
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string fenbuid= strid;
					ShowInfo(fenbuid);
				}
			}
		}
		
	private void ShowInfo(string fenbuid)
	{
		Maticsoft.BLL.fenbu_infor bll=new Maticsoft.BLL.fenbu_infor();
		Maticsoft.Model.fenbu_infor model=bll.GetModel(fenbuid);
		this.lblfenbuid.Text=model.fenbuid;
		this.lblareaid.Text=model.areaid;
		this.lblareaname.Text=model.areaname;
		this.lblfenbuname.Text=model.fenbuname;
		this.lblmanager.Text=model.manager;
		this.lblphone.Text=model.phone;
		this.lbladdress.Text=model.address;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
