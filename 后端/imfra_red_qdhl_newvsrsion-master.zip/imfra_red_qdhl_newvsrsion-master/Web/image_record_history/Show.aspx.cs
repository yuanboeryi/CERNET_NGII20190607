﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.image_record_history
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string imageid= strid;
					ShowInfo(imageid);
				}
			}
		}
		
	private void ShowInfo(string imageid)
	{
		Maticsoft.BLL.image_record_history bll=new Maticsoft.BLL.image_record_history();
		Maticsoft.Model.image_record_history model=bll.GetModel(imageid);
		this.lblimageid.Text=model.imageid;
		this.lblareaid.Text=model.areaid;
		this.lblareaname.Text=model.areaname;
		this.lblfenbuid.Text=model.fenbuid;
		this.lblfenbuname.Text=model.fenbuname;
		this.lblywbid.Text=model.ywbid;
		this.lblywbname.Text=model.ywbname;
		this.lblstationid.Text=model.stationid;
		this.lblstationname.Text=model.stationname;
		this.lblbuildingid.Text=model.buildingid;
		this.lblbuildingname.Text=model.buildingname;
		this.lblmachineid.Text=model.machineid;
		this.lblmachinename.Text=model.machinename;
		this.lblysdid.Text=model.ysdid;
		this.lblysdname.Text=model.ysdname;
		this.lblysdindex.Text=model.ysdindex;
		this.lblimagehigh.Text=model.imagehigh;
		this.lblimagered.Text=model.imagered;
		this.lblimagemix.Text=model.imagemix;
		this.lblmaxvalue.Text=model.maxvalue;
		this.lblminvalue.Text=model.minvalue;
		this.lbllevelvalue.Text=model.levelvalue;
		this.lblisalarm.Text=model.isalarm;
		this.lblcolorbar.Text=model.colorbar;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
