﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.image_record_month
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtimageid.Text.Trim().Length==0)
			{
				strErr+="imageid不能为空！\\n";	
			}
			if(this.txtareaid.Text.Trim().Length==0)
			{
				strErr+="areaid不能为空！\\n";	
			}
			if(this.txtareaname.Text.Trim().Length==0)
			{
				strErr+="areaname不能为空！\\n";	
			}
			if(this.txtfenbuid.Text.Trim().Length==0)
			{
				strErr+="fenbuid不能为空！\\n";	
			}
			if(this.txtfenbuname.Text.Trim().Length==0)
			{
				strErr+="fenbuname不能为空！\\n";	
			}
			if(this.txtywbid.Text.Trim().Length==0)
			{
				strErr+="ywbid不能为空！\\n";	
			}
			if(this.txtywbname.Text.Trim().Length==0)
			{
				strErr+="ywbname不能为空！\\n";	
			}
			if(this.txtstationid.Text.Trim().Length==0)
			{
				strErr+="stationid不能为空！\\n";	
			}
			if(this.txtstationname.Text.Trim().Length==0)
			{
				strErr+="stationname不能为空！\\n";	
			}
			if(this.txtbuildingid.Text.Trim().Length==0)
			{
				strErr+="buildingid不能为空！\\n";	
			}
			if(this.txtbuildingname.Text.Trim().Length==0)
			{
				strErr+="buildingname不能为空！\\n";	
			}
			if(this.txtmachineid.Text.Trim().Length==0)
			{
				strErr+="machineid不能为空！\\n";	
			}
			if(this.txtmachinename.Text.Trim().Length==0)
			{
				strErr+="machinename不能为空！\\n";	
			}
			if(this.txtysdid.Text.Trim().Length==0)
			{
				strErr+="ysdid不能为空！\\n";	
			}
			if(this.txtysdname.Text.Trim().Length==0)
			{
				strErr+="ysdname不能为空！\\n";	
			}
			if(this.txtysdindex.Text.Trim().Length==0)
			{
				strErr+="ysdindex不能为空！\\n";	
			}
			if(this.txtimagehigh.Text.Trim().Length==0)
			{
				strErr+="imagehigh不能为空！\\n";	
			}
			if(this.txtimagered.Text.Trim().Length==0)
			{
				strErr+="imagered不能为空！\\n";	
			}
			if(this.txtimagemix.Text.Trim().Length==0)
			{
				strErr+="imagemix不能为空！\\n";	
			}
			if(this.txtmaxvalue.Text.Trim().Length==0)
			{
				strErr+="maxvalue不能为空！\\n";	
			}
			if(this.txtminvalue.Text.Trim().Length==0)
			{
				strErr+="minvalue不能为空！\\n";	
			}
			if(this.txtlevelvalue.Text.Trim().Length==0)
			{
				strErr+="levelvalue不能为空！\\n";	
			}
			if(this.txtisalarm.Text.Trim().Length==0)
			{
				strErr+="isalarm不能为空！\\n";	
			}
			if(this.txtcolorbar.Text.Trim().Length==0)
			{
				strErr+="colorbar不能为空！\\n";	
			}
			if(!PageValidate.IsDateTime(txtcreatetime.Text))
			{
				strErr+="on update CURRE格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string imageid=this.txtimageid.Text;
			string areaid=this.txtareaid.Text;
			string areaname=this.txtareaname.Text;
			string fenbuid=this.txtfenbuid.Text;
			string fenbuname=this.txtfenbuname.Text;
			string ywbid=this.txtywbid.Text;
			string ywbname=this.txtywbname.Text;
			string stationid=this.txtstationid.Text;
			string stationname=this.txtstationname.Text;
			string buildingid=this.txtbuildingid.Text;
			string buildingname=this.txtbuildingname.Text;
			string machineid=this.txtmachineid.Text;
			string machinename=this.txtmachinename.Text;
			string ysdid=this.txtysdid.Text;
			string ysdname=this.txtysdname.Text;
			string ysdindex=this.txtysdindex.Text;
			string imagehigh=this.txtimagehigh.Text;
			string imagered=this.txtimagered.Text;
			string imagemix=this.txtimagemix.Text;
			string maxvalue=this.txtmaxvalue.Text;
			string minvalue=this.txtminvalue.Text;
			string levelvalue=this.txtlevelvalue.Text;
			string isalarm=this.txtisalarm.Text;
			string colorbar=this.txtcolorbar.Text;
			DateTime createtime=DateTime.Parse(this.txtcreatetime.Text);

			Maticsoft.Model.image_record_month model=new Maticsoft.Model.image_record_month();
			model.imageid=imageid;
			model.areaid=areaid;
			model.areaname=areaname;
			model.fenbuid=fenbuid;
			model.fenbuname=fenbuname;
			model.ywbid=ywbid;
			model.ywbname=ywbname;
			model.stationid=stationid;
			model.stationname=stationname;
			model.buildingid=buildingid;
			model.buildingname=buildingname;
			model.machineid=machineid;
			model.machinename=machinename;
			model.ysdid=ysdid;
			model.ysdname=ysdname;
			model.ysdindex=ysdindex;
			model.imagehigh=imagehigh;
			model.imagered=imagered;
			model.imagemix=imagemix;
			model.maxvalue=maxvalue;
			model.minvalue=minvalue;
			model.levelvalue=levelvalue;
			model.isalarm=isalarm;
			model.colorbar=colorbar;
			model.createtime=createtime;

			Maticsoft.BLL.image_record_month bll=new Maticsoft.BLL.image_record_month();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
