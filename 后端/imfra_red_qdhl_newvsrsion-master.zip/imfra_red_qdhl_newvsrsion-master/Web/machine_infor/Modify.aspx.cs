﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.machine_infor
{
    public partial class Modify : Page
    {       

        		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					string machineid= Request.Params["id"];
					ShowInfo(machineid);
				}
			}
		}
			
	private void ShowInfo(string machineid)
	{
		Maticsoft.BLL.machine_infor bll=new Maticsoft.BLL.machine_infor();
		Maticsoft.Model.machine_infor model=bll.GetModel(machineid);
		this.lblmachineid.Text=model.machineid;
		this.txtareaid.Text=model.areaid;
		this.txtareaname.Text=model.areaname;
		this.txtfenbuid.Text=model.fenbuid;
		this.txtfenbuname.Text=model.fenbuname;
		this.txtywbid.Text=model.ywbid;
		this.txtywbname.Text=model.ywbname;
		this.txtstationid.Text=model.stationid;
		this.txtstationname.Text=model.stationname;
		this.txtbuildingid.Text=model.buildingid;
		this.txtbuildingname.Text=model.buildingname;
		this.txtmachinename.Text=model.machinename;
		this.txtmachinecompany.Text=model.machinecompany;
		this.txtmachinemac.Text=model.machinemac;
		this.txtmachinecode.Text=model.machinecode;
		this.txtinstallcode.Text=model.installcode;
		this.txtcurrentversion.Text=model.currentversion;
		this.txtnewversion.Text=model.newversion;
		this.txtmachinestate.Text=model.machinestate;
		this.txtysdcount.Text=model.ysdcount;
		this.txtonlinetime.Text=model.onlinetime.ToString();
		this.txtruntime.Text=model.runtime;
		this.txtimagecatchspan.Text=model.imagecatchspan;
		this.txtwifiname.Text=model.wifiname;
		this.txtwifipass.Text=model.wifipass;
		this.txtfushelv.Text=model.fushelv;
		this.txtoffsetvalue.Text=model.offsetvalue;
		this.txtbuchang.Text=model.buchang;
		this.txttopvalue.Text=model.topvalue;
		this.txtcreatetime.Text=model.createtime.ToString();

	}

		public void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtareaid.Text.Trim().Length==0)
			{
				strErr+="areaid不能为空！\\n";	
			}
			if(this.txtareaname.Text.Trim().Length==0)
			{
				strErr+="areaname不能为空！\\n";	
			}
			if(this.txtfenbuid.Text.Trim().Length==0)
			{
				strErr+="fenbuid不能为空！\\n";	
			}
			if(this.txtfenbuname.Text.Trim().Length==0)
			{
				strErr+="fenbuname不能为空！\\n";	
			}
			if(this.txtywbid.Text.Trim().Length==0)
			{
				strErr+="ywbid不能为空！\\n";	
			}
			if(this.txtywbname.Text.Trim().Length==0)
			{
				strErr+="ywbname不能为空！\\n";	
			}
			if(this.txtstationid.Text.Trim().Length==0)
			{
				strErr+="stationid不能为空！\\n";	
			}
			if(this.txtstationname.Text.Trim().Length==0)
			{
				strErr+="stationname不能为空！\\n";	
			}
			if(this.txtbuildingid.Text.Trim().Length==0)
			{
				strErr+="buildingid不能为空！\\n";	
			}
			if(this.txtbuildingname.Text.Trim().Length==0)
			{
				strErr+="buildingname不能为空！\\n";	
			}
			if(this.txtmachinename.Text.Trim().Length==0)
			{
				strErr+="machinename不能为空！\\n";	
			}
			if(this.txtmachinecompany.Text.Trim().Length==0)
			{
				strErr+="machinecompany不能为空！\\n";	
			}
			if(this.txtmachinemac.Text.Trim().Length==0)
			{
				strErr+="machinemac不能为空！\\n";	
			}
			if(this.txtmachinecode.Text.Trim().Length==0)
			{
				strErr+="machinecode不能为空！\\n";	
			}
			if(this.txtinstallcode.Text.Trim().Length==0)
			{
				strErr+="installcode不能为空！\\n";	
			}
			if(this.txtcurrentversion.Text.Trim().Length==0)
			{
				strErr+="currentversion不能为空！\\n";	
			}
			if(this.txtnewversion.Text.Trim().Length==0)
			{
				strErr+="newversion不能为空！\\n";	
			}
			if(this.txtmachinestate.Text.Trim().Length==0)
			{
				strErr+="machinestate不能为空！\\n";	
			}
			if(this.txtysdcount.Text.Trim().Length==0)
			{
				strErr+="ysdcount不能为空！\\n";	
			}
			if(!PageValidate.IsDateTime(txtonlinetime.Text))
			{
				strErr+="on update CURRE格式错误！\\n";	
			}
			if(this.txtruntime.Text.Trim().Length==0)
			{
				strErr+="runtime不能为空！\\n";	
			}
			if(this.txtimagecatchspan.Text.Trim().Length==0)
			{
				strErr+="imagecatchspan不能为空！\\n";	
			}
			if(this.txtwifiname.Text.Trim().Length==0)
			{
				strErr+="wifiname不能为空！\\n";	
			}
			if(this.txtwifipass.Text.Trim().Length==0)
			{
				strErr+="wifipass不能为空！\\n";	
			}
			if(this.txtfushelv.Text.Trim().Length==0)
			{
				strErr+="fushelv不能为空！\\n";	
			}
			if(this.txtoffsetvalue.Text.Trim().Length==0)
			{
				strErr+="offsetvalue不能为空！\\n";	
			}
			if(this.txtbuchang.Text.Trim().Length==0)
			{
				strErr+="buchang不能为空！\\n";	
			}
			if(this.txttopvalue.Text.Trim().Length==0)
			{
				strErr+="topvalue不能为空！\\n";	
			}
			if(!PageValidate.IsDateTime(txtcreatetime.Text))
			{
				strErr+="on update CURRE格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string machineid=this.lblmachineid.Text;
			string areaid=this.txtareaid.Text;
			string areaname=this.txtareaname.Text;
			string fenbuid=this.txtfenbuid.Text;
			string fenbuname=this.txtfenbuname.Text;
			string ywbid=this.txtywbid.Text;
			string ywbname=this.txtywbname.Text;
			string stationid=this.txtstationid.Text;
			string stationname=this.txtstationname.Text;
			string buildingid=this.txtbuildingid.Text;
			string buildingname=this.txtbuildingname.Text;
			string machinename=this.txtmachinename.Text;
			string machinecompany=this.txtmachinecompany.Text;
			string machinemac=this.txtmachinemac.Text;
			string machinecode=this.txtmachinecode.Text;
			string installcode=this.txtinstallcode.Text;
			string currentversion=this.txtcurrentversion.Text;
			string newversion=this.txtnewversion.Text;
			string machinestate=this.txtmachinestate.Text;
			string ysdcount=this.txtysdcount.Text;
			DateTime onlinetime=DateTime.Parse(this.txtonlinetime.Text);
			string runtime=this.txtruntime.Text;
			string imagecatchspan=this.txtimagecatchspan.Text;
			string wifiname=this.txtwifiname.Text;
			string wifipass=this.txtwifipass.Text;
			string fushelv=this.txtfushelv.Text;
			string offsetvalue=this.txtoffsetvalue.Text;
			string buchang=this.txtbuchang.Text;
			string topvalue=this.txttopvalue.Text;
			DateTime createtime=DateTime.Parse(this.txtcreatetime.Text);


			Maticsoft.Model.machine_infor model=new Maticsoft.Model.machine_infor();
			model.machineid=machineid;
			model.areaid=areaid;
			model.areaname=areaname;
			model.fenbuid=fenbuid;
			model.fenbuname=fenbuname;
			model.ywbid=ywbid;
			model.ywbname=ywbname;
			model.stationid=stationid;
			model.stationname=stationname;
			model.buildingid=buildingid;
			model.buildingname=buildingname;
			model.machinename=machinename;
			model.machinecompany=machinecompany;
			model.machinemac=machinemac;
			model.machinecode=machinecode;
			model.installcode=installcode;
			model.currentversion=currentversion;
			model.newversion=newversion;
			model.machinestate=machinestate;
			model.ysdcount=ysdcount;
			model.onlinetime=onlinetime;
			model.runtime=runtime;
			model.imagecatchspan=imagecatchspan;
			model.wifiname=wifiname;
			model.wifipass=wifipass;
			model.fushelv=fushelv;
			model.offsetvalue=offsetvalue;
			model.buchang=buchang;
			model.topvalue=topvalue;
			model.createtime=createtime;

			Maticsoft.BLL.machine_infor bll=new Maticsoft.BLL.machine_infor();
			bll.Update(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","list.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
