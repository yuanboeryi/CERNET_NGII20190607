﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.machine_infor
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string machineid= strid;
					ShowInfo(machineid);
				}
			}
		}
		
	private void ShowInfo(string machineid)
	{
		Maticsoft.BLL.machine_infor bll=new Maticsoft.BLL.machine_infor();
		Maticsoft.Model.machine_infor model=bll.GetModel(machineid);
		this.lblmachineid.Text=model.machineid;
		this.lblareaid.Text=model.areaid;
		this.lblareaname.Text=model.areaname;
		this.lblfenbuid.Text=model.fenbuid;
		this.lblfenbuname.Text=model.fenbuname;
		this.lblywbid.Text=model.ywbid;
		this.lblywbname.Text=model.ywbname;
		this.lblstationid.Text=model.stationid;
		this.lblstationname.Text=model.stationname;
		this.lblbuildingid.Text=model.buildingid;
		this.lblbuildingname.Text=model.buildingname;
		this.lblmachinename.Text=model.machinename;
		this.lblmachinecompany.Text=model.machinecompany;
		this.lblmachinemac.Text=model.machinemac;
		this.lblmachinecode.Text=model.machinecode;
		this.lblinstallcode.Text=model.installcode;
		this.lblcurrentversion.Text=model.currentversion;
		this.lblnewversion.Text=model.newversion;
		this.lblmachinestate.Text=model.machinestate;
		this.lblysdcount.Text=model.ysdcount;
		this.lblonlinetime.Text=model.onlinetime.ToString();
		this.lblruntime.Text=model.runtime;
		this.lblimagecatchspan.Text=model.imagecatchspan;
		this.lblwifiname.Text=model.wifiname;
		this.lblwifipass.Text=model.wifipass;
		this.lblfushelv.Text=model.fushelv;
		this.lbloffsetvalue.Text=model.offsetvalue;
		this.lblbuchang.Text=model.buchang;
		this.lbltopvalue.Text=model.topvalue;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
