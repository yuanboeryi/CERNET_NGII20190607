﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.station_infor
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string stationid= strid;
					ShowInfo(stationid);
				}
			}
		}
		
	private void ShowInfo(string stationid)
	{
		Maticsoft.BLL.station_infor bll=new Maticsoft.BLL.station_infor();
		Maticsoft.Model.station_infor model=bll.GetModel(stationid);
		this.lblstationid.Text=model.stationid;
		this.lblareaid.Text=model.areaid;
		this.lblareaname.Text=model.areaname;
		this.lblfenbuid.Text=model.fenbuid;
		this.lblfenbuname.Text=model.fenbuname;
		this.lblywbid.Text=model.ywbid;
		this.lblywbname.Text=model.ywbname;
		this.lblstationname.Text=model.stationname;
		this.lblmanager.Text=model.manager;
		this.lblphone.Text=model.phone;
		this.lblstationlevel.Text=model.stationlevel;
		this.lblcity.Text=model.city;
		this.lbladdress.Text=model.address;
		this.lbljingdu.Text=model.jingdu;
		this.lblweidu.Text=model.weidu;
		this.lbltopvalue.Text=model.topvalue;
		this.lblalarmcount.Text=model.alarmcount;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
