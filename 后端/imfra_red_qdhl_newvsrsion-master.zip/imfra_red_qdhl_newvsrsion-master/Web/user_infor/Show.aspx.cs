﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.user_infor
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string userid= strid;
					ShowInfo(userid);
				}
			}
		}
		
	private void ShowInfo(string userid)
	{
		Maticsoft.BLL.user_infor bll=new Maticsoft.BLL.user_infor();
		Maticsoft.Model.user_infor model=bll.GetModel(userid);
		this.lbluserid.Text=model.userid;
		this.lblareaid.Text=model.areaid;
		this.lblareaname.Text=model.areaname;
		this.lblfenbuid.Text=model.fenbuid;
		this.lblfenbuname.Text=model.fenbuname;
		this.lblywbid.Text=model.ywbid;
		this.lblywbname.Text=model.ywbname;
		this.lblusername.Text=model.username;
		this.lblpassword.Text=model.password;
		this.lblusertype.Text=model.usertype;
		this.lblcity.Text=model.city;
		this.lblmanager.Text=model.manager;
		this.lblphone.Text=model.phone;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
