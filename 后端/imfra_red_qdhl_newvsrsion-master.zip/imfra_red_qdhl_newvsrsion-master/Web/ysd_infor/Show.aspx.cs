﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.ysd_infor
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string ysdid= strid;
					ShowInfo(ysdid);
				}
			}
		}
		
	private void ShowInfo(string ysdid)
	{
		Maticsoft.BLL.ysd_infor bll=new Maticsoft.BLL.ysd_infor();
		Maticsoft.Model.ysd_infor model=bll.GetModel(ysdid);
		this.lblysdid.Text=model.ysdid;
		this.lblareaid.Text=model.areaid;
		this.lblareaname.Text=model.areaname;
		this.lblfenbuid.Text=model.fenbuid;
		this.lblfenbuname.Text=model.fenbuname;
		this.lblywbid.Text=model.ywbid;
		this.lblywbname.Text=model.ywbname;
		this.lblstationid.Text=model.stationid;
		this.lblstationname.Text=model.stationname;
		this.lblbuildingid.Text=model.buildingid;
		this.lblbuildingname.Text=model.buildingname;
		this.lblmachineid.Text=model.machineid;
		this.lblmachinename.Text=model.machinename;
		this.lblysdname.Text=model.ysdname;
		this.lbliskeypoint.Text=model.iskeypoint;
		this.lblisroundpoint.Text=model.isroundpoint;
		this.lblcreatetime.Text=model.createtime.ToString();

	}


    }
}
