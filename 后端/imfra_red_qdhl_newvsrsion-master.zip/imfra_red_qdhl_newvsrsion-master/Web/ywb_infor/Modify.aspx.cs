﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.ywb_infor
{
    public partial class Modify : Page
    {       

        		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					string ywbid= Request.Params["id"];
					ShowInfo(ywbid);
				}
			}
		}
			
	private void ShowInfo(string ywbid)
	{
		Maticsoft.BLL.ywb_infor bll=new Maticsoft.BLL.ywb_infor();
		Maticsoft.Model.ywb_infor model=bll.GetModel(ywbid);
		this.lblywbid.Text=model.ywbid;
		this.txtareaid.Text=model.areaid;
		this.txtareaname.Text=model.areaname;
		this.txtfenbuid.Text=model.fenbuid;
		this.txtfenbuname.Text=model.fenbuname;
		this.txtywbname.Text=model.ywbname;
		this.txtmanager.Text=model.manager;
		this.txtphone.Text=model.phone;
		this.txtaddress.Text=model.address;
		this.txtcreatetime.Text=model.createtime.ToString();

	}

		public void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtareaid.Text.Trim().Length==0)
			{
				strErr+="areaid不能为空！\\n";	
			}
			if(this.txtareaname.Text.Trim().Length==0)
			{
				strErr+="areaname不能为空！\\n";	
			}
			if(this.txtfenbuid.Text.Trim().Length==0)
			{
				strErr+="fenbuid不能为空！\\n";	
			}
			if(this.txtfenbuname.Text.Trim().Length==0)
			{
				strErr+="fenbuname不能为空！\\n";	
			}
			if(this.txtywbname.Text.Trim().Length==0)
			{
				strErr+="ywbname不能为空！\\n";	
			}
			if(this.txtmanager.Text.Trim().Length==0)
			{
				strErr+="manager不能为空！\\n";	
			}
			if(this.txtphone.Text.Trim().Length==0)
			{
				strErr+="phone不能为空！\\n";	
			}
			if(this.txtaddress.Text.Trim().Length==0)
			{
				strErr+="address不能为空！\\n";	
			}
			if(!PageValidate.IsDateTime(txtcreatetime.Text))
			{
				strErr+="on update CURRE格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string ywbid=this.lblywbid.Text;
			string areaid=this.txtareaid.Text;
			string areaname=this.txtareaname.Text;
			string fenbuid=this.txtfenbuid.Text;
			string fenbuname=this.txtfenbuname.Text;
			string ywbname=this.txtywbname.Text;
			string manager=this.txtmanager.Text;
			string phone=this.txtphone.Text;
			string address=this.txtaddress.Text;
			DateTime createtime=DateTime.Parse(this.txtcreatetime.Text);


			Maticsoft.Model.ywb_infor model=new Maticsoft.Model.ywb_infor();
			model.ywbid=ywbid;
			model.areaid=areaid;
			model.areaname=areaname;
			model.fenbuid=fenbuid;
			model.fenbuname=fenbuname;
			model.ywbname=ywbname;
			model.manager=manager;
			model.phone=phone;
			model.address=address;
			model.createtime=createtime;

			Maticsoft.BLL.ywb_infor bll=new Maticsoft.BLL.ywb_infor();
			bll.Update(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","list.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
