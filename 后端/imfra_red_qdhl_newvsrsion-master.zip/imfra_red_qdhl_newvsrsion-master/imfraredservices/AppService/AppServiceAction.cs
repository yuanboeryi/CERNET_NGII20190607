﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;

namespace imfraredservices.AppService
{
    public class AppServiceAction
    {
        public DataTable AppLogin(string username, string password)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            DataTable dt = new DataTable();
            dt = userservice.GetList("username='" + username + "' and password='" + password + "'").Tables[0];
            if(dt.Rows.Count<1)
            {
                return null;
            }
            else
            {
                return dt;
            }

        }

        public DataTable getWeather(string userid)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if(usermodel==null)
            {
                return null;
            }
            else
            {
                string ywbid = usermodel.ywbid;
                Maticsoft.BLL.city_infor cityservice = new Maticsoft.BLL.city_infor();
                DataTable dt = cityservice.GetList("ywbid='" + ywbid + "'").Tables[0];
                if(dt.Rows.Count<1)
                {
                    return null;
                }
                else
                {
                    return dt;
                }
            }
        }


        public DataTable getDeviceTongji(string userid)
        {
             Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
            {
                return null;
            }
            else
            {

                Maticsoft.BLL.machine_infor service = new Maticsoft.BLL.machine_infor();
                List<Maticsoft.Model.machine_infor> modellist = new List<Maticsoft.Model.machine_infor>();
               
                int allcount = modellist.Count();//抓拍设备总数
                //////////////////////////////////////////抓拍设备在线总数/////////////////////////////////////////////////////////
                string isonline = "1";
                if (usermodel.usertype == "0")
                {
                    modellist = service.GetModelList("areaid='" + usermodel.areaid + "' and isonline='" + isonline + "'");
                }
                if (usermodel.usertype == "1")
                {
                    modellist = service.GetModelList("fenbuid='" + usermodel.fenbuid + "' and isonline='" + isonline + "'");
                }
                if (usermodel.usertype == "2")
                {
                    modellist = service.GetModelList("ywbid='" + usermodel.ywbid + "' and isonline='" + isonline + "'");
                }
                if (usermodel.usertype == "3")
                {
                    modellist = service.GetModelList("isonline='" + isonline + "'");
                }
                int onlinecount = modellist.Count();
                int offlinecount = allcount - onlinecount;
                DataTable dt = new DataTable("machinecount");
                dt.Columns.Add("allcount", Type.GetType("System.String"));
                dt.Columns.Add("onlinecount", Type.GetType("System.String"));
                dt.Columns.Add("offlinecount", Type.GetType("System.String"));
                dt.Rows.Add(new object[] { allcount.ToString(), onlinecount.ToString(), offlinecount.ToString() });
                return dt;
            }
        }

        public DataTable getalarmpush(string stationid)
        {
          
                List<Maticsoft.Model.alarm_push_infor> modellist = new List<Maticsoft.Model.alarm_push_infor>();
                Maticsoft.BLL.alarm_push_infor bllservice = new Maticsoft.BLL.alarm_push_infor();
                DataSet ds = new DataSet();
                    ds = bllservice.GetList("stationid='" + stationid + "'");
                return ds.Tables[0];
           
        }


        public DataTable getstationByuser(string userid)
        {
             Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
            {
                return null;
            }
            else
            {
                List<Maticsoft.Model.device_infor> modellist = new List<Maticsoft.Model.device_infor>();
                Maticsoft.BLL.device_infor service = new Maticsoft.BLL.device_infor();
                DataSet ds = new DataSet();
                if(usermodel.usertype=="0")
                {
                    ds = service.GetList("areaid='"+usermodel.areaid+"'");
                }
                if(usermodel.usertype=="1")
                {
                    ds = service.GetList("fenbuid='" + usermodel.fenbuid + "'");

                }
                if(usermodel.usertype=="2")
                {
                    ds = service.GetList("ywbid='" + usermodel.ywbid + "'");

                }
                if (usermodel.usertype=="3")
                {
                    ds = service.GetList("");
                }
                return ds.Tables[0];
            }
        }
        public string getDeviceReport(string deviceid)
        {
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
            devicemodel = deviceservice.GetModel(deviceid);
            string fenbuname = devicemodel.fenbuname;
            string ywbname = devicemodel.ywbname;
            string stationname = devicemodel.stationname;
            string devicename = devicemodel.devicename;
            string devicelevel = devicemodel.ysdlevel;
            string fuhe = devicemodel.fuhe;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            System.DateTime alarmtime = Convert.ToDateTime(devicemodel.createtime.ToString(), dtFormat);
            DateTime dttoday = (DateTime)devicemodel.createtime;
            string alarmtemp = devicemodel.todaytop;
            string machinename = devicemodel.machinename;
            string machinecode = devicemodel.machinename;//此处根据抓拍设备名称获取设备编号
            string buildingname = devicemodel.buildingname;
            string image1 = devicemodel.image_high;
            string image2 = devicemodel.image_mix;
            string image3 = devicemodel.image_red;
            string templist_24 = devicemodel.templist;
            string today = devicemodel.todaytop;
            string yestoday = devicemodel.yestodaytop;
            string week = devicemodel.weektop;
            string month = devicemodel.monthtop;
            string history = devicemodel.historytop;
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();
            historylist = historyservice.GetModelList("deviceid='" + devicemodel.deviceid + "' order by createtime desc limit 0,720");
            historylist.Reverse();
            string startTime = "";
            string templist_30 = "";//此处需要根据设备id去历史记录里面查最近30条
            if (historylist.Count() > 0)
            {
                string dayold = historylist[0].createtime.Value.Day.ToString();
                startTime = historylist[0].createtime.Value.Hour.ToString();
                string dateold = historylist[0].createtime.Value.Year.ToString() + "-" + historylist[0].createtime.Value.Month.ToString() + "-" + historylist[0].createtime.Value.Day.ToString();
                templist_30 += dateold + ";" + historylist[0].createtime.Value.Day.ToString() + ";" + historylist[0].valuemax + ",";
                string daynew = "";
                string datenew = "";
                for (int i = 1; i < historylist.Count() - 1; i++)
                {
                    daynew = historylist[i].createtime.Value.Day.ToString();
                    datenew = historylist[i].createtime.Value.Year.ToString() + "-" + historylist[i].createtime.Value.Month.ToString() + "-" + historylist[i].createtime.Value.Day.ToString();
                    if (daynew != dayold)
                    {
                        templist_30 += datenew + ";" + daynew + ";" + historylist[i].valuemax + ",";
                        dayold = daynew;
                    }
                }
            }

            templist_30.Remove(templist_30.Length - 1, 1);
            string manager1 = "张三";
            string manager2 = "李四";
            string manager3 = "马六";
            ReportServic.devicereportjson json = new ReportServic.devicereportjson();

            json.Fenbuname = fenbuname;
            json.Ywbname = ywbname;
            json.Stationnane = stationname;
            json.Deviceid = deviceid;
            json.Devicename = devicename; json.Devicelevle = devicelevel;
            json.Fuhe = fuhe;
            json.Alarmtime = alarmtime;
            json.Alarmtemp = alarmtemp;
            json.Machinename = machinename;
            json.Machinecode = machinecode;
            json.Buildingname = buildingname;
            json.Image1 = image1;
            json.Image2 = image2;
            json.Image3 = image3;
            json.Date1 = dttoday.Year + "-" + dttoday.Month + "-" + dttoday.Day;
            json.Templist_241 = templist_24.Split(',').ToList();
            json.Date2 = dttoday.Year + "-" + dttoday.Month + "-" + (dttoday.Day - 1);
            json.Date3 = dttoday.Year + "-" + dttoday.Month + "-" + (dttoday.Day - 2);
            json.Date4 = dttoday.Year + "-" + dttoday.Month + "-" + (dttoday.Day - 3);
            json.Date5 = dttoday.Year + "-" + dttoday.Month + "-" + (dttoday.Day - 4);
            if (historylist.Count() > 0)
            {
                for (int i = 0; i < historylist.Count(); i++)
                {
                    string sdatedate = historylist[i].createtime.Value.Year + "-" + historylist[i].createtime.Value.Month + "-" + historylist[i].createtime.Value.Day;
                    string shourhor = historylist[i].createtime.Value.Hour.ToString();
                    if (json.Date2 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_242 = historylist[i].templist_24.Split(',').ToList();

                    }
                    if (json.Date3 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_243 = historylist[i].templist_24.Split(',').ToList();

                    }
                    if (json.Date4 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_244 = historylist[i].templist_24.Split(',').ToList();

                    }
                    if (json.Date5 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_245 = historylist[i].templist_24.Split(',').ToList();
                    }
                }
            }

            json.Templist_30 = templist_30.Split(',').ToList();
            json.Testhuman = manager1;
            json.Shenhehuman = manager2;
            json.Pizhunhunam = manager3;
            json.Today = today;
            json.Yestoday = yestoday;
            json.Week = week;
            json.Month = month;
            json.History = history;
            List<ReportServic.devicereportjson> jsonlist = new List<ReportServic.devicereportjson>();
            jsonlist.Add(json);
            return Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
        }
        public string modifyAlarmValue(string deviceid,string value,string manager)
        {
            Maticsoft.BLL.device_infor deser = new Maticsoft.BLL.device_infor();
            bool IsUpdate=deser.modifyAlarmValue(deviceid, value, manager);
            if (IsUpdate==true)
            {
                return "更新成功";
            }
                return "更新失败";
        }
        public string deleteAlarm(string alarmid)
        {
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            var IsDelete=alarmservice.Delete(alarmid);
            if (IsDelete==true)
            {
                return "删除成功";
            }
            return "删除失败";
        }
    }
}