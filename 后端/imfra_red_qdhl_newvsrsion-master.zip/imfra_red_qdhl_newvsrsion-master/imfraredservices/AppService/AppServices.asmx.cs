﻿using imfraredservices.UserServices;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace imfraredservices.AppService
{
    /// <summary>
    /// AppServices 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class AppServices : System.Web.Services.WebService
    {
        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }

        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = Int32.MaxValue;
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        public string jsonlistj(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        //字符串转json
        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msgsend");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        AppServiceAction action = new AppServiceAction();
        [WebMethod(Description = "接口描述：APP登录:")]
        public void AppLogin(string username, string password)
        {
            if (action.AppLogin(username, password) == null)
            {
                httpsend(strJson("用户不存在或者密码错误"));
            }
            else
            {
                httpsend(ToJson(action.AppLogin(username, password)));
            }
        }
        [WebMethod(Description = "接口描述：天气获取:userid=登录用户返回的id")]
        public void a_getWeather(string userid)
        {
            if (action.getWeather(userid) == null)
            {
                httpsend(strJson("用户不存在或者密码错误"));
            }
            else
            {
                httpsend(ToJson(action.getWeather(userid)));
            }
        }
        [WebMethod(Description = "接口描述：获取监视设备在线不在线统计")]
        public void b_getDeviceTongji(string userid)
        {
            if (action.getDeviceTongji(userid) == null)
            {
                httpsend(strJson("没有监视设备需要统计"));
            }
            else
            {
                httpsend(ToJson(action.getDeviceTongji(userid)));
            }
        }
        public void dgeAlarm(string userid)
        {
            if ((action.getalarmpush(userid)) == null)
            {
                httpsend(strJson("没有告警信息"));
            }
            else
            {
                httpsend(ToJson(action.getalarmpush(userid)));
            }
        }

        [WebMethod(Description = "接口描述：获取告警推送信息")]
        public void c_getAlarmPush(string userid)
        {
            if (action.getalarmpush(userid) == null)
            {
                httpsend(strJson("没有告警推送信息"));
            }
            else
            {
                httpsend(ToJson(action.getalarmpush(userid)));
            }
        }

        [WebMethod(Description = "接口描述：获取当前登录用户下首页变电站信息列表")]
        public void d_getStationInfor(string userid)
        {
            httpsend(ToJson(action.getstationByuser(userid)));
        }
        [WebMethod(Description = "接口描述：获取站内告警设备列表")]
        public void e_getAlarmDevice(string stationid)
        {
            httpsend(ToJson(action.getalarmpush(stationid)));
        }
        [WebMethod(Description = "接口描述，生成设备报告，传值deviceid【设备id】，返回报表所有信息")]
        public void getDevicereport(string deviceid)
        {
            httpsend(action.getDeviceReport(deviceid));
        }
        [WebMethod(Description = "接口描述，修改告警值，传值deviceid,value,manager")]
        public void modifyAlarmValue(string deviceid, string value, string manager)
        {
            httpsend(strJson(action.modifyAlarmValue(deviceid, value, manager)));
        }


        [WebMethod(Description = "接口描述，删除告警信息，alarmid")]
        public void deleteAlarm(string alarmid)
        {
            httpsend(strJson(action.deleteAlarm(alarmid)));
        }

        //[WebMethod(Description = "接口描述：")]
        [WebMethod(Description = "接口描述：获取失联红外设备列表")]
        public void getofflinemachine(string userid)
        {
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            usermodel = user.GetModel(userid);
            if (usermodel == null)
                return;
            else
            {
                string isonline = "0";
                if (usermodel.usertype == "0")
                {
                    httpsend(ToJson(machineservice.GetList("areaid='" + usermodel.areaid + "' and isonline='" + isonline + "'").Tables[0]));
                }
                if (usermodel.usertype == "1")
                    httpsend(ToJson(machineservice.GetList("fenbuid='" + usermodel.fenbuid + "' and isonline='" + isonline + "'").Tables[0]));
                {
                }
                if (usermodel.usertype == "2")
                    httpsend(ToJson(machineservice.GetList("ywbid='" + usermodel.ywbid + "' and isonline='" + isonline + "'").Tables[0]));
                {
                }
                if (usermodel.usertype == "3")
                    httpsend(ToJson(machineservice.GetList("isonline='" + isonline + "'").Tables[0]));
                {
                }
            }
        }

        [WebMethod(Description = "接口描述：获取登录用户下红外设备总数，红外设备在线数，红外设备不在线数")]
        public void getMachineCount(string userid)
        {
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            int machinecount = 0;
            int machineonlinecount = 0;
            int machineofflinecount = 0;
            int devicecount = 0;
            string isonline = "1";
            usermodel = user.GetModel(userid);
            if (usermodel == null)
                return;
            else
            {
                if (usermodel.usertype == "0")
                {
                    machinecount = machineservice.GetList("areaid='" + usermodel.areaid + "'").Tables[0].Rows.Count;
                    machineonlinecount = machineservice.GetList("areaid='" + usermodel.areaid + "' and isonline='" + isonline + "'").Tables[0].Rows.Count;
                    machineofflinecount = machinecount - machineonlinecount;
                    devicecount = deviceservice.GetList("areaid='" + usermodel.areaid + "'").Tables[0].Rows.Count;

                }
                if (usermodel.usertype == "1")
                {
                    machinecount = machineservice.GetList("fenbuid='" + usermodel.fenbuid + "'").Tables[0].Rows.Count;
                    machineonlinecount = machineservice.GetList("fenbuid='" + usermodel.fenbuid + "' and isonline='" + isonline + "'").Tables[0].Rows.Count;
                    machineofflinecount = machinecount - machineonlinecount;
                    devicecount = deviceservice.GetList("fenbuid='" + usermodel.fenbuid + "'").Tables[0].Rows.Count;

                }
                if (usermodel.usertype == "2")
                {
                    machinecount = machineservice.GetList("ywbid='" + usermodel.ywbid + "'").Tables[0].Rows.Count;
                    machineonlinecount = machineservice.GetList("ywbid='" + usermodel.ywbid + "' and isonline='" + isonline + "'").Tables[0].Rows.Count;
                    machineofflinecount = machinecount - machineonlinecount;
                    devicecount = deviceservice.GetList("ywbid='" + usermodel.ywbid + "'").Tables[0].Rows.Count;

                }
                if (usermodel.usertype == "3")
                {
                    machinecount = machineservice.GetList("").Tables[0].Rows.Count;
                    machineonlinecount = machineservice.GetList("isonline='" + isonline + "'").Tables[0].Rows.Count;
                    machineofflinecount = machinecount - machineonlinecount;
                    devicecount = deviceservice.GetList("").Tables[0].Rows.Count;

                }
                DataTable dt = new DataTable("machinecount");
                dt.Columns.Add("machinecount", Type.GetType("System.String"));
                dt.Columns.Add("onlinecount", Type.GetType("System.String"));
                dt.Columns.Add("offlinecount", Type.GetType("System.String"));
                dt.Rows.Add(new object[] { machinecount, machineonlinecount, machineofflinecount });
                httpsend(ToJson(dt));
            }
        }
        [WebMethod(Description = "接口描述：获取登录用户下电力设备的统计")]
        public void getDeviceCount(string userid)
        {
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            int deviceallcount = 0;
            usermodel = user.GetModel(userid);
            devicefenleitongjijson json = new devicefenleitongjijson();
            if (usermodel == null)
                return;
            else
            {
                DataTable dt1 = new DataTable();
                DataTable dt2 = new DataTable();
                if (usermodel.usertype == "0")
                {
                    deviceallcount = deviceservice.GetList("areaid='" + usermodel.areaid + "'").Tables[0].Rows.Count;
                    dt1 = deviceservice.GetDeviceTongji("areaid='" + usermodel.areaid + "'").Tables[0];
                    dt2 = deviceservice.GetLevelTongji("areaid='" + usermodel.areaid + "'").Tables[0];
                }
                if (usermodel.usertype == "1")
                {
                    deviceallcount = deviceservice.GetList("fenbuid='" + usermodel.fenbuid + "'").Tables[0].Rows.Count;
                    dt1 = deviceservice.GetDeviceTongji("fenbuid='" + usermodel.fenbuid + "'").Tables[0];
                    dt2 = deviceservice.GetLevelTongji("fenbuid='" + usermodel.fenbuid + "'").Tables[0];
                }
                if (usermodel.usertype == "2")
                {
                    deviceallcount = deviceservice.GetList("ywbid='" + usermodel.ywbid + "'").Tables[0].Rows.Count;
                    dt1 = deviceservice.GetDeviceTongji("ywbid='" + usermodel.ywbid + "'").Tables[0];
                    dt2 = deviceservice.GetLevelTongji("ywbid='" + usermodel.ywbid + "'").Tables[0];
                }
                if (usermodel.usertype == "3")
                {
                    deviceallcount = deviceservice.GetList("").Tables[0].Rows.Count;
                    dt1 = deviceservice.GetDeviceTongji("1=1 ").Tables[0];
                    dt2 = deviceservice.GetLevelTongji("1=1 ").Tables[0];
                }

                json.Deviceallcount = deviceallcount.ToString();
                json.DeviceType = dt1;
                json.DeviceLevel = dt2;
                httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));

            }
        }


        [WebMethod(Description = "接口描述：保存手机token")]
        public void saveToken(string username, string token)
        {
            Maticsoft.BLL.push_token_infor Pushservice = new Maticsoft.BLL.push_token_infor();
            Maticsoft.Model.push_token_infor Pushmodel = new Maticsoft.Model.push_token_infor();
            Maticsoft.BLL.user_infor usser = new Maticsoft.BLL.user_infor();
            List<Maticsoft.Model.user_infor> usmodel = new List<Maticsoft.Model.user_infor>();
            usmodel = usser.GetModelList("username='"+username+"'");
            var ModelPush= Pushservice.GetModelList("tokenvalue='"+token+"'");
            if (usmodel.Count>=1)
            {

                //大于一条数据
                if (ModelPush.Count>=1)
                {
                    //更新数据 关于当前手机的Token
                    var NewModelPush=ModelPush.FirstOrDefault();
                    NewModelPush.tokenname = username;
                    NewModelPush.tokenvalue = token;
                    NewModelPush.createtime = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    NewModelPush.fenbuname = usmodel[0].fenbuname;
                    NewModelPush.ywbname = usmodel[0].ywbname;
                    NewModelPush.areaname = usmodel[0].areaname;
                    Pushservice.Update(NewModelPush);
                    httpsend(strJson("1"));
                }
                else if(ModelPush.Count<=0) // 不存在数据
                {
                    // 开始添加数据
                    Pushmodel.tokenid = Guid.NewGuid().ToString("N");
                    Pushmodel.tokenname = username;
                    Pushmodel.tokenvalue = token;
                    Pushmodel.createtime = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    Pushmodel.fenbuname = usmodel[0].fenbuname;
                    Pushmodel.ywbname = usmodel[0].ywbname;
                    Pushmodel.areaname = usmodel[0].areaname;
                    Pushservice.Add(Pushmodel);
                    httpsend(strJson("1"));
                }
            }


            //if (usmodel.Count > 0)
            //{
            //    // 已经存在进行覆盖
            //    if (ModelPush.Count>=1)
            //    {
            //        pushmodel = ModelPush[0];
            //        // 更新当前的id 覆盖信息
            //        pushmodel.tokenid = Guid.NewGuid().ToString("N");
            //        pushmodel.tokenname = username;
            //        pushmodel.tokenvalue = token;
            //        pushmodel.createtime = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            //        pushmodel.fenbuname = usmodel[0].fenbuname;
            //        pushmodel.ywbname = usmodel[0].ywbname;
            //        pushmodel.areaname = usmodel[0].areaname;
            //        service.Update(pushmodel);
            //    }
            //    else
            //    {
            //        pushmodel.tokenid = Guid.NewGuid().ToString("N");
            //        pushmodel.tokenname = username;
            //        pushmodel.tokenvalue = token;
            //        pushmodel.createtime = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            //        pushmodel.fenbuname = usmodel[0].fenbuname;
            //        pushmodel.ywbname = usmodel[0].ywbname;
            //        pushmodel.areaname = usmodel[0].areaname;
            //        service.Add(pushmodel);
            //    }
            //    httpsend(strJson("1"));
            //}
           

            //List<Maticsoft.Model.push_token_infor> model = new List<Maticsoft.Model.push_token_infor>();
            //model = service.GetModelList("");
            //bool ishave = false;
            //string sid="";
            //for (int i = 0; i < model.Count(); i++)
            //{
            //    if (token == model[i].tokenvalue)
            //    {
            //        ishave = true;
            //        sid = model[i].tokenid;
            //    }
            //}
            //Maticsoft.BLL.user_infor usser = new Maticsoft.BLL.user_infor();
            //Maticsoft.Model.user_infor usmodel = new Maticsoft.Model.user_infor();
            //usmodel = usser.GetModel(username);
            //if (ishave == false)
            //{
            //    Maticsoft.Model.push_token_infor pushmodel = new Maticsoft.Model.push_token_infor();
            //    pushmodel.tokenid = Guid.NewGuid().ToString("N");
            //    pushmodel.tokenname = username;
            //    pushmodel.tokenvalue = token;
            //    pushmodel.ywbname = usmodel.ywbname;
            //    pushmodel.areaname = usmodel.areaname;
            //    service.Add(pushmodel);
            //    httpsend(strJson("1"));
            //}
            //else
            //{
            //    service.UpdateToken(sid, username);
            //}
        }

        [WebMethod(Description = "接口描述：获取可更新的app版本")]
        public void update()
        {
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Columns.Add("data", Type.GetType("System.String"));
            dt.Columns.Add("code", Type.GetType("System.String"));
            dt.Columns.Add("uploadurl", Type.GetType("System.String"));
            dt.Columns.Add("id", Type.GetType("System.String"));
            dt.Columns.Add("sendTime", Type.GetType("System.String"));
            dt.Columns.Add("state", Type.GetType("System.String"));
            Maticsoft.BLL.app_infor bll = new Maticsoft.BLL.app_infor();
            List<Maticsoft.Model.app_infor> model = new List<Maticsoft.Model.app_infor>();
            model = bll.GetModelList("");
            if (model.Count() > 0)
            {
                string id = model[0].id;
                string code = model[0].version_no;
                string msg = model[0].version_note;
                string uploadurl = model[0].download_url;
                string sendTime = model[0].createtime.ToString();
                string data = model[0].version_note;
                string state = "1";
                dt.Rows.Add(new object[] { msg, data, code, uploadurl, id, sendTime, state });
            }
            httpsend(ToJson(dt));
        }


        [WebMethod(Description = "获取设备历史")]
        public void l_getDeviceImageByUnit(string userid, string starttime, string endtime, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string deviceid, string isok, string page, string limit)
        {
            DateTime dtS, dtE;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            dtS = Convert.ToDateTime(starttime, dtFormat);
            dtE = Convert.ToDateTime(endtime, dtFormat);
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();

            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel.usertype == "0")
            {
                if (areaid == "" || areaid == null)
                {
                    areaid = usermodel.areaid;
                }
            }
            if (usermodel.usertype == "1")
            {
                if (fenbuid == "" || fenbuid == null)
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                if (ywbid == "" || ywbid == null)
                {
                    ywbid = usermodel.ywbid;
                }
            }
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1);
            {

                List<string> sqllist = new List<string>();
                if (areaid != "" && areaid != "全部")
                    sqllist.Add("areaid='" + areaid + "'");
                if (fenbuid != "" && fenbuid != "全部")
                    sqllist.Add("fenbuid='" + fenbuid + "'");
                if (ywbid != "" && ywbid != "全部")
                    sqllist.Add("ywbid='" + ywbid + "'");
                if (stationid != "" && stationid != "全部")
                    sqllist.Add("stationid='" + stationid + "'");
                if (buildingid != "" && buildingid != "全部")
                    sqllist.Add("buildingid='" + buildingid + "'");
                if (deviceid != "" && deviceid != "全部")
                    sqllist.Add("deviceid='" + deviceid + "'");
                if (devicetype != "" && devicetype != "全部")
                    sqllist.Add("ysdtype='" + devicetype + "'");
                if (isok != "" && isok != "全部")
                    sqllist.Add("isok='" + isok + "'");
                string sql = "";
                int ncount = sqllist.Count();
                if (ncount < 1)
                {
                    sql = "";
                }
                else if (ncount == 1)
                {
                    sql += sqllist[0];
                }
                else if (ncount > 1)
                {
                    for (int i = 0; i < ncount - 1; i++)
                    {
                        sql += sqllist[i] + " and ";
                    }
                    sql += sqllist[ncount - 1];
                }

                string sql1 = sql;
                //sql += " limit " + npage + "," + end + "";

                Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
                List<string> deviceidlist = new List<string>();
                DataTable dt = deviceservice.GetList(sql).Tables[0];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    deviceidlist.Add(dt.Rows[i]["deviceid"].ToString());
                }
                int nallcount = 0;
                DataTable dtnew = new DataTable("keyDevice");
                dtnew.Columns.Add("recordid", Type.GetType("System.String"));
                dtnew.Columns.Add("deviceid", Type.GetType("System.String"));
                dtnew.Columns.Add("devicename", Type.GetType("System.String"));
                dtnew.Columns.Add("stationname", Type.GetType("System.String"));
                dtnew.Columns.Add("image_red", Type.GetType("System.String"));
                dtnew.Columns.Add("image_mix", Type.GetType("System.String"));
                dtnew.Columns.Add("image_high", Type.GetType("System.String"));
                dtnew.Columns.Add("todaytop", Type.GetType("System.String"));

                dtnew.Columns.Add("machinecode", Type.GetType("System.String"));
                dtnew.Columns.Add("createtime", Type.GetType("System.String"));
                for (int k = 0; k < deviceidlist.Count; k++)
                {
                    Maticsoft.BLL.image_record_history imagebll = new Maticsoft.BLL.image_record_history();
                    DataTable dimage = imagebll.GetList("deviceid='" + deviceidlist[k] + "' and createtime>'" + dtS.Date + "' and createtime<'" + dtE.AddDays(1).Date + "' group by createtime order by createtime desc ").Tables[0];
                    nallcount += dimage.Rows.Count;
                    string machineid = dt.Rows[k]["machineid"].ToString();
                    Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                    Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
                    macmodel = macser.GetModel(machineid);
                    if (macmodel != null)
                    {
                        string machinecode = macmodel.machinecode;
                        string stationname = macmodel.stationname;
                        for (int i = 0; i < dimage.Rows.Count; i++)
                        {
                            dtnew.Rows.Add(new object[] { dimage.Rows[i]["recordid"].ToString(), dimage.Rows[i]["deviceid"].ToString(), dimage.Rows[i]["devicename"].ToString(), stationname, dimage.Rows[i]["image0"].ToString(), dimage.Rows[i]["image1"].ToString(), dimage.Rows[i]["image2"].ToString(), dimage.Rows[i]["valuemax"].ToString(), machinecode, dimage.Rows[i]["createtime"].ToString() });
                        }

                    }

                }

                devicelistjson list = new devicelistjson();
                DataTable dt2 = new DataTable();
                dt2 = dtnew.Copy();
                dt2.Rows.Clear();
                for (int i = (npage) * int.Parse(limit); i < (npage) * int.Parse(limit) + int.Parse(limit); i++)
                {
                    if (i < dtnew.Rows.Count)
                    {
                        dt2.ImportRow(dtnew.Rows[i]);//这是加入的是第一行

                    }
                }
                list.Recordcount = dtnew.Rows.Count.ToString();
                list.Recorddt = dt2;
                List<devicelistjson> nn = new List<devicelistjson>();

                nn.Add(list);

                httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(list));
            }

        }



        [WebMethod(Description = "接口描述：获取当前登录用户下，变电站各个时间段的最高温度（今日，昨日，本周，本月，历史）")]
        public void getStation_TYWMH(string userid, string areaid, string fenbuid, string ywbid, string stationid)
        {
            updatestation(userid);
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel.usertype == "0")
            {
                {
                    areaid = usermodel.areaid;
                }
            }
            if (usermodel.usertype == "1")
            {
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                {
                    ywbid = usermodel.ywbid;
                }
            }
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部" && areaid != null)
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部" && fenbuid != null)
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部" && ywbid != null)
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部" && stationid != null)
                sqllist.Add("stationid='" + stationid + "'");

            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql += "1=1 ";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1] + "";
            }
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> modellist = new List<Maticsoft.Model.station_infor>();
            if (usermodel.usertype == "0")
            {
                modellist = stationservice.GetModelList(sql);

            }
            if (usermodel.usertype == "1")
            {
                modellist = stationservice.GetModelList(sql);

            }
            if (usermodel.usertype == "2")
            {
                modellist = stationservice.GetModelList(sql);

            }
            if (usermodel.usertype == "3")
            {
                modellist = stationservice.GetModelList(sql);

            }

            List<station_tongji_json> jsonlist = new List<station_tongji_json>();
            for (int i = 0; i < modellist.Count(); i++)
            {
                station_tongji_json json = new station_tongji_json();
                json.Stationname = modellist[i].stationname;
                json.Today = modellist[i].todaytop;
                json.Todayid = modellist[i].todayid;
                json.Yestoday = modellist[i].yestodaytop;
                json.Yestodayid = modellist[i].yestodayid;
                json.Week = modellist[i].weektop;
                json.Weekid = modellist[i].weekid;
                json.Month = modellist[i].monthtop;
                json.Monthid = modellist[i].monthid;
                json.History = modellist[i].historytop;
                json.Historyid = modellist[i].monthid;
                jsonlist.Add(json);
            }
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist));
        }
        public int getMaxindex(List<double> list)
        {
            double a = list[0];
            int index = 0;//把假设的最大值索引赋值非index
            for (int i = 1; i < list.Count; i++)
            {
                if (list[i] > a)
                {
                    a = list[i];
                    index = i;//把较大值的索引赋值非index
                }
            }
            return index;
        }
        public void updatestation(string userid)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
                return;
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> modellist = new List<Maticsoft.Model.station_infor>();
            if (usermodel.usertype == "0")
            {
                modellist = stationservice.GetModelList("areaid='" + usermodel.areaid + "'");

            }
            if (usermodel.usertype == "1")
            {
                modellist = stationservice.GetModelList("fenbuid='" + usermodel.fenbuid + "'");

            }
            if (usermodel.usertype == "2")
            {
                modellist = stationservice.GetModelList("ywbid='" + usermodel.ywbid + "'");

            }
            if (usermodel.usertype == "3")
            {
                modellist = stationservice.GetModelList("");

            }
            for (int i = 0; i < modellist.Count(); i++)
            {
                updatedevice(modellist[i].stationid);
            }
        }
        public void updatedevice(string stationid)
        {
            string today = "0";
            string yestoday = "0";
            string week = "0";
            string month = "0";
            string history = "0";
            string id1 = "";
            string id2 = ""; string id3 = ""; string id4 = ""; string id5 = "";
            Maticsoft.BLL.device_infor devservice = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devlist = new List<Maticsoft.Model.device_infor>();
            devlist = devservice.GetModelList("stationid='" + stationid + "'");
            if (devlist.Count() > 0)
            {
                List<double> todaynowlist = new List<double>(); todaynowlist.Add(0);
                List<string> todaynowid = new List<string>(); todaynowid.Add("");
                List<double> todaylist = new List<double>(); todaylist.Add(0);
                List<string> todayid = new List<string>(); todayid.Add("");
                List<double> yestodaylist = new List<double>(); yestodaylist.Add(0);
                List<string> yestodayid = new List<string>(); yestodayid.Add("");
                List<double> weeklist = new List<double>(); weeklist.Add(0);
                List<string> weekid = new List<string>(); weekid.Add("");
                List<double> monthlist = new List<double>(); monthlist.Add(0);
                List<string> monthid = new List<string>(); monthid.Add("");
                List<double> historylist = new List<double>(); historylist.Add(0);
                List<string> historyid = new List<string>(); historyid.Add("");
                for (int i = 0; i < devlist.Count(); i++)
                {
                    //update_device_state stateac = new update_device_state();
                    //stateac.UpdateDevice(devlist[i].deviceid);
                    if (devlist[i].todaytop != "" && devlist[i].todaytop != null && devlist[i].todaytop != "0")
                    {
                        todaynowlist.Add(double.Parse(devlist[i].todaytop));
                        todaynowid.Add(devlist[i].todaymaxid);
                    }
                    if (devlist[i].todaymax != "" && devlist[i].todaymax != null && devlist[i].todaymax != "0")
                    {
                        todaylist.Add(double.Parse(devlist[i].todaymax));
                        todayid.Add(devlist[i].todaymaxid);
                    }
                    if (devlist[i].yestodaytop != "" && devlist[i].yestodaytop != null && devlist[i].yestodaytop != "0")
                    {
                        yestodaylist.Add(double.Parse(devlist[i].yestodaytop));
                        yestodayid.Add(devlist[i].yestodaymaxid);
                    }
                    if (devlist[i].weektop != "" && devlist[i].weektop != null && devlist[i].weektop != "0")
                    {
                        weeklist.Add(double.Parse(devlist[i].weektop));
                        weekid.Add(devlist[i].weekmaxid);
                    }
                    if (devlist[i].monthmax != "" && devlist[i].monthmax != null && devlist[i].monthmax != "0")
                    {
                        monthlist.Add(double.Parse(devlist[i].monthmax));
                        monthid.Add(devlist[i].monthmaxid);
                    }
                    if (devlist[i].historytop != "" && devlist[i].historytop != null && devlist[i].historytop != "0")
                    {
                        historylist.Add(double.Parse(devlist[i].historytop));
                        historyid.Add(devlist[i].historymaxid);
                    }
                }
                string nowtop = todaynowlist.Max().ToString();
                today = todaylist.Max().ToString();
                id1 = todayid[getMaxindex(todaylist)];
                yestoday = yestodaylist.Max().ToString();
                id2 = yestodayid[getMaxindex(yestodaylist)];
                week = weeklist.Max().ToString();
                id3 = weekid[getMaxindex(weeklist)];
                month = monthlist.Max().ToString();
                id4 = monthid[getMaxindex(monthlist)];
                history = historylist.Max().ToString();
                id5 = historyid[getMaxindex(historylist)];
                string topflag = "";
                string nowflag = "";
                if (todaylist.Max() >= yestodaylist.Max())
                    topflag = "0";
                else
                    topflag = "1";
                Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
                Maticsoft.Model.station_infor model = new Maticsoft.Model.station_infor();
                model = stationservice.GetModel(stationid);
                double nowtopold = 0;
                if (model.topvalue != "" && model.topvalue != null)
                {
                    nowtopold = double.Parse(model.topvalue);
                }
                else
                {
                    nowtopold = 0.0;
                }
                if (todaynowlist.Max() >= nowtopold)
                {
                    nowflag = "0";
                }
                else
                {
                    nowflag = "1";
                }
                stationservice.UpdateHistoryValue(stationid, nowtop, today, yestoday, week, month, history, id1, id2, id3, id4, id5, topflag, nowflag);
            }

        }
      



















    }
}
