﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.AppService
{
    public class devicefenleitongjijson
    {
        string deviceallcount = "";

        public string Deviceallcount
        {
            get { return deviceallcount; }
            set { deviceallcount = value; }
        }
        DataTable deviceType = new DataTable();

        public DataTable DeviceType
        {
            get { return deviceType; }
            set { deviceType = value; }
        }
        DataTable deviceLevel = new DataTable();

        public DataTable DeviceLevel
        {
            get { return deviceLevel; }
            set { deviceLevel = value; }
        }
    }
}