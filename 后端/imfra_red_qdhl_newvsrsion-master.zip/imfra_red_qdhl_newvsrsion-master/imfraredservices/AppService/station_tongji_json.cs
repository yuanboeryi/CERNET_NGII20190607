﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.AppService
{
    public class station_tongji_json
    {
        string stationname = "";

        public string Stationname
        {
            get { return stationname; }
            set { stationname = value; }
        }
        string today = "";

        public string Today
        {
            get { return today; }
            set { today = value; }
        }
        string todayid = "";

        public string Todayid
        {
            get { return todayid; }
            set { todayid = value; }
        }
        string yestoday = "";

        public string Yestoday
        {
            get { return yestoday; }
            set { yestoday = value; }
        }
        string yestodayid = "";

        public string Yestodayid
        {
            get { return yestodayid; }
            set { yestodayid = value; }
        }
        string week = "";

        public string Week
        {
            get { return week; }
            set { week = value; }
        }
        string weekid = "";

        public string Weekid
        {
            get { return weekid; }
            set { weekid = value; }
        }
        string month = "";

        public string Month
        {
            get { return month; }
            set { month = value; }
        }
        string monthid = "";

        public string Monthid
        {
            get { return monthid; }
            set { monthid = value; }
        }
        string history = "";

        public string History
        {
            get { return history; }
            set { history = value; }
        }
        string historyid = "";

        public string Historyid
        {
            get { return historyid; }
            set { historyid = value; }
        }
    }
}