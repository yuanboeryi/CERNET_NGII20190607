﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.IO;


namespace imfraredservices.AppVersionService
{
    /// <summary>
    /// AppversionService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class AppversionService : System.Web.Services.WebService
    {
        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        //字符串转json
        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msgsend");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        ////已弃用
        //[WebMethod(Description = "接口描述：添加APP版本")]
        //public void Addapp1(string versionNo,string UpdateMsg,string downloadUrl,string targetPlaform)
        //{
        //    Maticsoft.BLL.app_infor service = new Maticsoft.BLL.app_infor();
        //    List<Maticsoft.Model.app_infor> modellist = new List<Maticsoft.Model.app_infor>();
        //    modellist = service.GetModelList("");
        //    bool ishave = false;
            
        //        for(int i=0;i<modellist.Count();i++)
        //            if(modellist[i].version_no==versionNo)
        //            {
        //                ishave = true;
        //            }


        //        if(ishave)
        //        {
        //            httpsend(strJson("此版本已存在"));
        //        }
        //        else
        //        {
        //            Maticsoft.Model.app_infor model = new Maticsoft.Model.app_infor();
        //            model.id = Guid.NewGuid().ToString("N");
        //            model.version_no = versionNo;
        //            model.version_note = UpdateMsg;
        //            model.download_url = downloadUrl;
        //            model.platform_target = targetPlaform;
        //            model.createtime = System.DateTime.Now;
        //            model.isopen = "0";
        //            service.Add(model);
        //            httpsend(strJson("添加成功"));
        //        }
        //}


        [WebMethod(Description = "接口描述:添加App版本:参数versionNo,UpdateMsg,targetPlaform,fileBase(文件)")]
        //[ValidateInput(false)]
        public void Addapp()
        {
            if (HttpContext.Current.Request.Files.Count == 0)
            {
                httpsend(strJson("请选择上传的文件"));
            }
            HttpFileCollection fileBase = HttpContext.Current.Request.Files;
            string versionNo = HttpContext.Current.Request.Params["versionNo"];
            string UpdateMsg = HttpContext.Current.Request.Params["UpdateMsg"];
            string targetPlaform = HttpContext.Current.Request.Params["targetPlaform"];

            var FileData = fileBase[0];

            //字节大小
            if (FileData.ContentLength == 0)
            {
                httpsend(strJson("文件大小不得为空"));
            }
            if (string.IsNullOrEmpty(versionNo))
            {
                httpsend(strJson("版本号不得为空"));
            }

            string FileName = System.IO.Path.GetExtension(FileData.FileName);
            if (string.IsNullOrEmpty(FileName))
            {
                httpsend(strJson("文件名字不得为空"));
            }
            else if (!string.IsNullOrEmpty(FileName))
            {
                if (FileName != ".apk")
                {
                    httpsend(strJson("请上传文件后缀名称为.apk的文件"));
                }
            }

            Maticsoft.BLL.app_infor appservice = new Maticsoft.BLL.app_infor();
            var GetModelAppList = appservice.GetModelList("version_no='"+ versionNo+"'");
            Maticsoft.Model.app_infor appmodel = new Maticsoft.Model.app_infor();
            if (GetModelAppList.Count > 0)
            {
                httpsend(strJson("已经存在当前的版本号"));
            }
            else
            {
                // 保存的文件路径
                string SaveFilePath = @"D:\infrared_new_service\apk_Floder\";

                //string FilePath = AppDomain.CurrentDomain.BaseDirectory.ToString() + @"AppPath";
                // 浏览器访问路径
                string DownLoadFile = @"http://116.225.207.148:21889/";

                if (Directory.Exists(SaveFilePath) == false)
                {
                    Directory.CreateDirectory(SaveFilePath);
                }
                //不采用覆盖的方式 文件名称TODO
                //string NewGuid = Guid.NewGuid().ToString();
                // 新名字=旧名字
                string SaveName = FileData.FileName;
                // 拼接新名字
                string Result = string.Format("{0}\\{1}", SaveFilePath, SaveName);
                // 保存
                FileData.SaveAs(Result);
                // 保存的新路径
                string NewFilePath = DownLoadFile + SaveName;
                // 执行数据库操作
                Maticsoft.Model.app_infor model = new Maticsoft.Model.app_infor();
                model.id = Guid.NewGuid().ToString("N");
                model.version_no = versionNo;
                model.version_note = UpdateMsg;
                model.download_url = NewFilePath;
                model.platform_target = targetPlaform;
                model.createtime = System.DateTime.Now;
                model.isopen = "0";
                appservice.Add(model);
                httpsend(strJson("添加成功"));
            }

        }

        [WebMethod(Description="接口描述：获取APP信息列表")]
        public void getAppList()
        {
            appjson json = new appjson();
            Maticsoft.BLL.app_infor service = new Maticsoft.BLL.app_infor();
            DataTable dt = new DataTable();
            dt = service.GetList("").Tables[0];
            json.dt = dt;
            json.count = dt.Rows.Count.ToString();
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));
        }

        [WebMethod(Description = "接口描述：启用或者禁用版本号，id，isopen【id=版本id，isopen=0或者1,0表示禁用，1表示启用】")]
        public void setIsopen(string id, string isopen)
        {
            Maticsoft.BLL.app_infor service = new Maticsoft.BLL.app_infor();
            service.UpdateIsopen(id,isopen);
            httpsend(strJson("更新成功"));
        }
    }
}
