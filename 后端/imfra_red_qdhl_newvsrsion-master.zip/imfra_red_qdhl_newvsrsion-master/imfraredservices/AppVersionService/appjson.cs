﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.AppVersionService
{

    public class appjson
    {
        string _count = "";

        public string count
        {
            get { return _count; }
            set { _count = value; }
        }
        DataTable _dt = new DataTable();

        public DataTable dt
        {
            get { return _dt; }
            set { _dt = value; }
        }
    }
}