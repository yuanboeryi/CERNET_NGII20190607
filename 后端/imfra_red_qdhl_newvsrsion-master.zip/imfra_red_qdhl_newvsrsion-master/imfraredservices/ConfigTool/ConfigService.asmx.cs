﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Text;
using King.MqttSupport;
using System.Linq;
using imfraredservices.UserServices;

namespace imfraredservices.ConfigTool
{

    /// <summary>
    /// ConfigService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class ConfigService : System.Web.Services.WebService
    {

        // By King-1025 2020.10.13 1543641386@qq.com
        #region 控制接口

        #region 上传软件版本

        [WebMethod(Description = "接口描述：上传软件版本 注意：deviceID 设备编号")]
        public void upload_version(string machinemac, string deviceID, string piFlir, string piVideo)
        {
            string piFlirVersion = "";
            if(piFlir!=null)
            {
                piFlirVersion = piFlir;
            }

            string piVideoVersion = "";
            if(piVideo!=null)
            {
                piVideoVersion = piVideo;
            }

            string mac = parseMac(machinemac, deviceID);
            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
            bool IsUpdate=machineService.updateVersionByMac(mac, piFlirVersion, piVideoVersion);
            if (IsUpdate==true)
            {
                httpsend(strJson("更新成功"));
            }
            httpsend(strJson("更新失败"));
        }

        #endregion

        #region 设备程序更新

        [WebMethod(Description = "接口描述：设备程序更新 注意：deviceID 设备编号")]
        public void update_program(string machinemac, string deviceID, string programName, string programSize)
        {
            Command command = new Command(CType.UPDATE_PROGRAM, "设备程序更新", true);
            command.mac = machinemac;
            command.code = deviceID;
            command.value = programName;
            command.status = programSize;
            sendCommand(command);
        }

        [WebMethod(Description = "接口描述：批量设备程序更新 targetList格式: [ {\"machinemac\": \"2c564512dfee\", \"deviceID\": \"dfdsffdsf45fdsfsdfsdfd6\"}, {\"machinemac\": \"156dcd2dfee\", \"deviceID\": \"8910715fsdsfdsaf\"} ]")]
        public void update_program_multi(string targetList, string programName, string programSize)
        {

            Newtonsoft.Json.Linq.JArray jsonArr = parseTargetArray(targetList);

            if (jsonArr != null)
            {
                int targetCount = jsonArr.Count;

                if(targetCount > 0 && targetCount <= 255 )
                {
                    Command command = new Command(CType.UPDATE_PROGRAM, "设备程序更新", true);
                    command.value = programName;
                    command.status = programSize;

                    for (int i = 0; i < targetCount; i++)
                    {
                        string machinemac = jsonArr[i]["machinemac"].ToString();
                        string deviceID = jsonArr[i]["deviceID"].ToString();

                        command.mac = machinemac;
                        command.code = deviceID;

                        sendCommandByMQTT(command);
                    }

                    httpsend(strJson("批量更新成功"));
                }
                else
                {
                    httpsend(strJson("批量更新一次最大支持255个设备更新"));
                }
               
            }
            else
            {
                httpsend(strJson("批量更新失败，非法参数"));
            }
          
        }

        #endregion

        #region 抓拍

        [WebMethod(Description = "接口描述：抓拍")]
        public void catch_picture(string machinemac)
        {
            Command command = new Command(CType.CAPTURE_PICTURE, "抓拍", true);
            command.mac = machinemac;
            sendCommand(command);
        }

        #endregion

        #region 调用预设点

        [WebMethod(Description = "接口描述，调用预设点, value取值范围[0, 128] （value值从0开始！！！）")]
        public void do_ysd(string machinemac, string deviceID, string value)
        {
            //判断预设点下是否有区域
            if (machinemac != "" && value!="")
            {              
                string ysdname = parseYsdname(value);
                Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
                Maticsoft.BLL.machine_infor macService = new Maticsoft.BLL.machine_infor();
                string machineid = macService.getMachineIdByMac(machinemac);
                if (machineid != "")
                {
                    List<Maticsoft.Model.device_infor> devicelists = deviceService.GetModelList("machineid='" + machineid + "' and ysdname='" + ysdname + "'");
                    if (devicelists.Count > 0)//有区域进行预设点调用
                    {
                        Command command = new Command(CType.CALL_POINT, "调用预设点", true);
                        command.mac = machinemac;
                        command.code = deviceID;
                        //string ysdname = parseYsdname(value);
                        command.value = ysdname;
                        // 判断是否存在图片
                        //ReturnImage.ReturnImage(machinemac,deviceID,value);
                        sendCommand(command);
                    }
                    else//没有区域则调用失败
                    {
                        Command command = new Command(CType.CALL_POINT, "请在预设点下添加设备，调用预设点", false);
                        sendCommand(command);
                    }

                }
            }
           
        }

       
        #endregion

        #region 清除预设点

        [WebMethod(Description = "接口描述：清除预设点 传值：machinemac，ysdindex 取值范围[0-127]（ysdindex从0开始！！！）")]
        public void clearysd(string machinemac, string deviceID, string ysdindex)
        {
            if (machinemac == "" || deviceID == "" || ysdindex == "" )
            {
                httpsend("参数不能为空");
            }
            string mac = parseMac(machinemac, deviceID);

            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor machine = machineService.getModelByMac(mac);

            //string ysdname = parseYsdname(ysdindex);

            Maticsoft.BLL.ysd_infor ysdService = new Maticsoft.BLL.ysd_infor();
            string ysdid = ysdService.getYsdid(machine.buildingid, machine.machineid, ysdindex);          
            if (ysdid != null && ysdid != "")
            {
                ysdService.Delete(ysdid);
                //删除预设点同时删除该预设点下的所有设备
                Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
                List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
                devicelist = deviceService.GetModelList("ysdindex='" + ysdid + "'");
                for (int i = 0; i < devicelist.Count; i++)
                {
                    deviceService.Delete(devicelist[i].deviceid);
                }

                // ysdCount -1
                machineService.ModifyYsdCount(machine.machineid, -1);

                Command command = new Command(CType.CLEAR_POINT, "清除预设点", true);
                command.mac = machinemac;
                command.code = deviceID;
                command.value = ysdindex; // 预设点起始值 1
                command.isValueUseInt = true; // 使用整形
                sendCommand(command);
            }
            else
            {
                Command command = new Command(CType.CLEAR_POINT, "预设点不存在", false);
                command.mac = machinemac;
                command.code = deviceID;
                command.value = ysdindex; // 预设点起始值 1
                command.isValueUseInt = false; // 使用整形
                sendCommand(command);
            }           

        }

        #endregion

        #region 添加预设点
        [WebMethod(Description = "接口描述：添加预设点 传值：machinemac，ysdindex 取值范围 [1-127] （ysdindex从1开始！！！）,distance取值范围[4-20]")]
        public void addysd(string machinemac, string deviceID, string ysdindex, string distance)
        {
            if (machinemac==""|| deviceID==""|| ysdindex==""|| distance=="")
            {
                httpsend("参数不能为空");
            }
            string mac = parseMac(machinemac, deviceID);

            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor machine = machineService.GetModelbymac(mac);

            if (machine != null)
            {

                string machineid = machine.machineid;
                //string ysdname = parseYsdname(ysdindex);

                Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
                Maticsoft.Model.device_infor deviceModel = deviceService.GetModelByMachine(machineid, ysdindex);
                
                if (deviceModel != null)
                {
                    deviceModel.distance = Convert.ToDouble(distance);

                    deviceService.Update(deviceModel);

                }

                Maticsoft.BLL.ysd_infor ysdService = new Maticsoft.BLL.ysd_infor();

                Maticsoft.Model.ysd_infor ysdModel = ysdService.GetModelByMachine(machineid, ysdindex);

                if(ysdModel==null)
                {
                    ysdModel = new Maticsoft.Model.ysd_infor();

                    ysdModel.ysdid = Guid.NewGuid().ToString("N");
                    ysdModel.areaid = machine.areaid;
                    ysdModel.areaname = machine.areaname;
                    ysdModel.fenbuid = machine.fenbuid;
                    ysdModel.fenbuname = machine.fenbuname;
                    ysdModel.ywbid = machine.ywbid;
                    ysdModel.ywbname = machine.ywbname;
                    ysdModel.stationid = machine.stationid;
                    ysdModel.stationname = machine.stationname;
                    ysdModel.buildingid = machine.buildingid;
                    ysdModel.buildingname = machine.buildingname;
                    ysdModel.machineid = machine.machineid;
                    ysdModel.machinename = machine.machinename;
                    ysdModel.ysdname = ysdindex;
                    ysdModel.orderindex = Convert.ToInt32(ysdindex);
                    ysdModel.createtime = System.DateTime.Now;

                    bool isOk = ysdService.Add(ysdModel);

                    // ysdCount +1
                    machineService.ModifyYsdCount(machineid, +1);
                }

                Command command = new Command(CType.ADD_POINT, "设定预设点", true);
                command.mac = machinemac;
                command.code = deviceID;
                command.value = ysdindex; // 预设点起始值 1
                command.status = distance;
                command.isValueUseInt = true;  // 使用整形
                command.isStatusUseInt = true; // 使用整形
                sendCommand(command);

            }
            else
            {
                Command command = new Command(CType.ADD_POINT, "红外设备不存在", false);
                command.mac = machinemac;
                command.code = deviceID;
                command.value = ysdindex; // 预设点起始值 1
                command.status = distance;
                command.isValueUseInt = false;  // 使用整形
                command.isStatusUseInt = false; // 使用整形
                sendCommand(command);
            }

        }

        #endregion

        #region 重启设备

        [WebMethod(Description = "接口描述：重启设备，复位系统")]
        public void rebootDevice(string machinemac)
        {
            Command command = new Command(CType.REBOOT, "重启设备", true);
            command.mac = machinemac;
            sendCommand(command);
        }

        #endregion

        #region 恢复出厂设置

        [WebMethod(Description = "接口描述：恢复出厂设置")]
        public void SystemRecovery(string machinemac)
        {
            Command command = new Command(CType.RESET, "恢复出厂设置", true);
            command.mac = machinemac;
            sendCommand(command);
        }

        #endregion

        #region 方向控制

        #region 向上

        [WebMethod(Description = "接口描述：上")]
        public void goUp(string machinemac)
        {
            Command command = new Command(CType.GO_UP, "向上", true);
            command.mac = machinemac;
            sendCommand(command);
        }

        [WebMethod(Description = "接口描述：上")]
        public void goUp_v2(string machinemac, string deviceID)
        {
            Command command = new Command(CType.GO_UP, "向上", true);
            command.mac = machinemac;
            command.code = deviceID;
            sendCommand(command);
        }

        #endregion

        #region 向下

       [WebMethod(Description = "接口描述：下")]
       public void goDown(string machinemac)
       {
            Command command = new Command(CType.GO_DOWN, "向下", true);
            command.mac = machinemac;
            sendCommand(command);
       }

        [WebMethod(Description = "接口描述：下")]
        public void goDown_v2(string machinemac, string deviceID)
        {
            Command command = new Command(CType.GO_DOWN, "向下", true);
            command.mac = machinemac;
            command.code = deviceID;
            sendCommand(command);
        }

        #endregion

        #region 向左

        [WebMethod(Description = "接口描述：左")]
        public void goLeft(string machinemac)
        {
            Command command = new Command(CType.GO_LEFT, "向左", true);
            command.mac = machinemac;
            sendCommand(command);
        }

        [WebMethod(Description = "接口描述：左")]
        public void goLeft_v2(string machinemac, string deviceID)
        {
            Command command = new Command(CType.GO_LEFT, "向左", true);
            command.mac = machinemac;
            command.code = deviceID;
            sendCommand(command);
        }

        #endregion

        #region 向右

        [WebMethod(Description = "接口描述：右")]
        public void goright(string machinemac)
        {
            Command command = new Command(CType.GO_RIGHT, "向右", true);
            command.mac = machinemac;
            sendCommand(command);
        }


        [WebMethod(Description = "接口描述：右")]
        public void goRight_v2(string machinemac, string deviceID)
        {
            Command command = new Command(CType.GO_RIGHT, "向右", true);
            command.mac = machinemac;
            command.code = deviceID;
            sendCommand(command);
        }

        #endregion

        #region 停止

        [WebMethod(Description = "接口描述：停")]
        public void goStop(string machinemac)
        {
            Command command = new Command(CType.GO_STOP, "停止", true);
            command.mac = machinemac;
            sendCommand(command);
        }

        [WebMethod(Description = "接口描述：停")]
        public void goStop_v2(string machinemac, string deviceID)
        {
            Command command = new Command(CType.GO_STOP, "停止", true);
            command.mac = machinemac;
            command.code = deviceID;
            sendCommand(command);
        }

        #endregion

        #endregion

        #region 参数修改

        #region 设置wifi

        [WebMethod(Description = "接口描述：设置wifi")]
        public void b_setWifi(string machinemac, string deviceID, string wifiname, string wifipass)
        {
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            machineservice.UpdateWifi(machinemac, wifiname, wifipass);

            Command command = new Command(CType.SET_WIFI, "设置wifi", true);
            command.mac = machinemac;
            command.code = deviceID;
            command.value = wifiname;
            command.status = wifipass;
            sendCommand(command);
        }

        #endregion

        #region 设置云接入地址

        [WebMethod(Description = "接口描述：设置云接入地址")]
        public void c_setCloudAddr(string machinemac, string deviceID, string Cloud_addr, string ftp_addr)
        {
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            machineservice.UpdateCloudAddress(machinemac, Cloud_addr);

            Command command = new Command(CType.SET_CLOUD, "设置云接入地址", true);
            command.mac = machinemac;
            command.code = deviceID;
            // 禁用修改MQTT地址
            // command.value = Cloud_addr;
            command.value = "122.114.204.83";
            command.status = ftp_addr;
            sendCommand(command);
        }


        [WebMethod(Description = "接口描述：批量更新云接入地址 targetList格式: [ {\"machinemac\": \"2c564512dfee\", \"deviceID\": \"dfdsffdsf45fdsfsdfsdfd6\"}, {\"machinemac\": \"156dcd2dfee\", \"deviceID\": \"8910715fsdsfdsaf\"} ]")]
        public void update_CloudAddr_multi(string targetList, string Cloud_addr, string ftp_addr)
        {

            Newtonsoft.Json.Linq.JArray jsonArr = parseTargetArray(targetList);

            if (jsonArr != null)
            {
                int targetCount = jsonArr.Count;

                if (targetCount > 0 && targetCount <= 255)
                {
                    Command command = new Command(CType.SET_CLOUD, "设置云接入地址", true);
                    // command.value = Cloud_addr;

                    // 禁用修改MQTT地址
                    command.value = "122.114.204.83";
                    command.status = ftp_addr;

                    for (int i = 0; i < targetCount; i++)
                    {
                        string machinemac = jsonArr[i]["machinemac"].ToString();
                        string deviceID = jsonArr[i]["deviceID"].ToString();

                      //  Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                      //  machineservice.UpdateCloudAddress(machinemac, Cloud_addr);

                        command.mac = machinemac;
                        command.code = deviceID;

                        sendCommandByMQTT(command);
                    }

                    httpsend(strJson("批量更新成功"));
                }
                else
                {
                    httpsend(strJson("批量更新一次最大支持255个设备更新"));
                }

            }
            else
            {
                httpsend(strJson("批量更新失败，非法参数"));
            }

        }


        #endregion

        #region 设置辐射率

        [WebMethod(Description = "接口描述：设置辐射率 value取值范围0-1.0")]
        public void d_setFusheLv(string machinemac, string deviceID, string value)
        {
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            machineservice.UpdateFusion(machinemac, value);

            Command command = new Command(CType.SET_FUSHE, "设置辐射率", true);
            command.mac = machinemac;
            command.code = deviceID;
            command.value = value;
            sendCommand(command);
        }

        #endregion

        #region 设置设备编号

        [WebMethod(Description = "接口描述：设置设备编号")]
        public void e_setDeviceCode(string machinemac, string deviceID, string value)
        {
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            machineservice.UpdateCode(machinemac, value);

            Command command = new Command(CType.SET_DEVCODE, "设置设备编号", true);
            command.mac = machinemac;
            command.code = deviceID;
            command.value = value;
            sendCommand(command);
        }

        #endregion

        # region 设置融合参数

        [WebMethod(Description = "接口描述：设定融合参数rong_L，rong_R取值范围-320到+320  rong_S，rong_T取值范围-240到+240")]
        public void g_setRonghe(string machinemac, string deviceID, string rong_S, string rong_R, string rong_L, string rong_T)
        {
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            machineservice.UpdateRonghe(machinemac, rong_S, rong_R, rong_L, rong_T);

            Command ltCommand = new Command(CType.SET_LaT, "设置融合参数L,T", true);
            ltCommand.mac = machinemac;
            ltCommand.code = deviceID;
            ltCommand.value = rong_L;
            ltCommand.status = rong_T;
          
            Command rsCommand = new Command(CType.SET_RaS, "设置融合参数R,S", true);
            rsCommand.mac = machinemac;
            rsCommand.code = deviceID;
            rsCommand.value = rong_R;
            rsCommand.status = rong_S;

            sendCommandByMQTT(ltCommand);
            sendCommandByMQTT(rsCommand);

            httpsend(strJson("设置融合参数 (L, T, R, S) 成功"));
        }

        #endregion

        #region 设置红外呈现参数

        [WebMethod(Description = "接口描述：设置红外呈现参数 value取值范围(1-5)开区间，浮点数")]
        public void h_set_infraParam(string machinemac, string deviceID, string value)
        {
            Command command = new Command(CType.SET_INFRA, "设置红外呈现参数", true);
            command.mac = machinemac;
            command.code = deviceID;
            command.value = value;
            sendCommand(command);
        }

        #endregion

        #region 设置红外勾边参数

        [WebMethod(Description = "接口描述：设置红外勾边参数 value取值范围[0-1]闭区间，浮点数")]
        public void i_set_edgeParam(string machinemac, string deviceID, string value)
        {
            Command command = new Command(CType.SET_EDGE, "设置红外勾边参数", true);
            command.mac = machinemac;
            command.code = deviceID;
            command.value = value;
            sendCommand(command);
        }

        #endregion

        #region 设置告警温度

        [WebMethod(Description = "接口描述：设置告警温度 value取值范围0-65535")]
        public void j_setAlarmvalue(string machinemac, string deviceID, string value)
        {
            Command command = new Command(CType.SET_WARNTMP, "设置告警温度", true);
            command.mac = machinemac;
            command.code = deviceID;
            command.value = value;
            sendCommand(command);
        }

        #endregion

        # region 设置守望点

        [WebMethod(Description = "接口描述：设置守望点 value范围 1-128")]
        public void k_setPointIndex(string machinemac, string deviceID, string value)
        {

            string mac = parseMac(machinemac, deviceID);

            string ysdname = value;

            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            string machineid = machineservice.getMachineIdByMac(mac);

            if(machineid != null)
            {
                Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
                Maticsoft.Model.device_infor deviceModel = deviceService.GetModelByMachineid(machineid, ysdname);

                if (deviceModel != null)
                {
                  
                    deviceModel.isroundpoint = Convert.ToString(1);

                    deviceService.Update(deviceModel);


                    Command command = new Command(CType.SET_LOOK_POINT, "设置守望点", true);
                    command.mac = machinemac;
                    command.code = deviceID;
                    command.value = value;
                    sendCommand(command);

                } 
                else
                {
                    httpsend(strJson("非法参数(-2)"));
                }
            } 
            else
            {
                httpsend(strJson("非法参数(-1)"));
            }

        }

        #endregion

        #region 设置巡检和抓拍周期

        [WebMethod(Description = "接口描述：设置巡检和抓拍周期, value_Catch: 拍图周期, value_Xun: 巡检周期")]
        public void l_setCatchSpan(string machinemac, string deviceID, string value_Catch, string value_Xun)
        {
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            machineservice.UpdateInterval(machinemac, value_Catch, value_Xun);

            Command command = new Command(CType.SET_CATCH_XUN, "设置巡检和抓拍周期", true);
            command.mac = machinemac;
            command.code = deviceID;
            command.value = value_Catch;
            command.status = value_Xun;
            sendCommand(command);
        }

        #endregion

        #endregion

        #region unused methods

        // [WebMethod(Description = "接口描述：修正温度补偿")]
        public void f_upLoadFile(string machinemac, string deviceID, string value)
        {
            Command command = new Command(CType.FIT_TEMP, "修正温度补偿", true);
            command.mac = machinemac;
            command.code = deviceID;
            command.value = value;
            sendCommand(command);

            httpsend(strJson("1"));
        }

        #endregion

        #endregion

        #region 推流接口

        [WebMethod(Description = "接口描述： 更新设备推流信息")]
        public void updateMediaByMachineId(string machineid, string mediaIndex)
        {
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            deviceservice.UpdateMediaIndex(machineid, mediaIndex);

            Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
            macservice.UpdateMediaIndex(machineid, mediaIndex);

            httpsend(strJson("1"));

        }

        [WebMethod(Description = "接口描述：获取推流地址")]
        public void getMediaAddressInfo()
        {
            Maticsoft.BLL.media mediaService = new Maticsoft.BLL.media();
            DataTable dt = mediaService.GetAllList().Tables[0];
            ArrayList list = new ArrayList();
            list.Add(new MediaAddress());

            foreach (DataRow dataRow in dt.Rows)
            {
                MediaAddress ma = new MediaAddress();
                ma.Name = dataRow["details"].ToString();
                ma.Value = dataRow["id"].ToString();
                list.Add(ma);
            }

            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(list));
        }

        #endregion

        #region 区域测温接口

        [WebMethod(Description = "接口描述：获取预设点对应设备的所画测温区")]
        public void getRectbyYsd(string ysdid, string width, string height)
        {
            // 增加区域坐标点查询 by King-1025
            Maticsoft.BLL.device_infor ysdservice = new Maticsoft.BLL.device_infor();

            //这个地方的ysdindex, 与其他地方的含义不同，表示自动生成的预设点id值！！！
            DataTable dt = ysdservice.GetList("ysdindex='" + ysdid + "'").Tables[0];

            if (dt != null && dt.Rows.Count > 0)
            {
                //  string deviceID = "2e8f8b701874494589eb12de4e50867f";
                string deviceID = dt.Rows[0]["deviceid"].ToString();

                dt = gen_rectlist(deviceID, width, height);

                if (dt != null && dt.Rows.Count > 0)
                {
                    httpsend(ToJson(dt));
                }
                else
                {
                    httpsend(strJson("暂无区域"));
                }
            }
            else
            {
                httpsend(strJson("暂无区域"));
            }
        }

        [WebMethod(Description = "接口描述: 清除对应设备所有画测温区 All Rect")]
        public void removeAllRect(string deviceID, string rectindex)
        {
            Maticsoft.BLL.device_rect_infor rectService = new Maticsoft.BLL.device_rect_infor();
            rectService.DeleteByIndex(deviceID, rectindex);

            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor deviceModel = deviceService.GetModel(deviceID);

            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor machine = machineService.GetModel(deviceModel.machineid);

            bool isHSDevice = false;

            if (machine.MediaIndex > 0 || deviceModel.mediaindex > 0)
            {
                isHSDevice = true;
            }

            string mac = machine.machinemac.ToLower();
            int index = Convert.ToInt32(rectindex);

            // TODO 区别设备
            if (isHSDevice || true)
            {
                // 海思清除区域，预设点从0开始
                index = index < 1 ? 0 : index - 1;
            }

            Command command = new Command(CType.REMOVE_REGION, "清除测温区域", true);
            command.mac = mac;
            command.code = deviceID;
            command.value = Convert.ToString(index);
            sendCommand(command);

            httpsend(strJson("清除成功"));

        }

        [WebMethod(Description = "接口描述: 清除对应设备的所画测温区 rectidlist")]
        public void removeRectByRectidlist(string deviceID, string rectindex, string rectidlist)
        {
            Maticsoft.BLL.device_rect_infor rectService = new Maticsoft.BLL.device_rect_infor();
            rectService.DeleteList(rectidlist);

            bool isOk = removeRegion(rectService, deviceID, rectindex);

            if (isOk)
            {
                httpsend(strJson("清除成功"));
            }
            else
            {
                httpsend(strJson("数据异常，清除失败"));
            }

        }

        [WebMethod(Description = "接口描述: 清除对应设备的所画测温区 pointlist")]
        public void removeRect(string deviceID, string rectindex, string pointlist)
        {
            Maticsoft.BLL.device_rect_infor rectService = new Maticsoft.BLL.device_rect_infor();
            rectService.DeleteByPointlist(deviceID, rectindex, pointlist);

            bool isOk = removeRegion(rectService, deviceID, rectindex);

            if (isOk)
            {
                httpsend(strJson("清除成功"));
            }
            else
            {
                httpsend(strJson("数据异常，清除失败"));
            }
        }

        [WebMethod(Description = "上传坐标区域deviceID,rectindex,rectname,pointlist  设备id  区域编号，区域名称，坐标数组 ，返回0表示提交成功，返回1表示区域已存在，返回2表示区域重叠，返回3表示提交失败")]
        public void upLoadRect(string deviceID, string rectindex, string rectname, string pointlist, string width, string height)
        {
            // if (true) testRegion(); // for king test
            //[{"x":175,"y":114},{"x":239,"y":265},{"x":349,"y":238},{"x":175,"y":114}]

            int w = 0; int h = 0;

            if (width != null && height != null)
            {
                if (width != "" && height != "")
                {
                    w = int.Parse(width);
                    h = int.Parse(height);
                }
            }

            if (!(w > 0 && h > 0))
            {
                httpsend(strJson("非法数据，提交失败"));
                return;
            }

            if (rectindex == null || rectindex == "")
            {
                rectindex = "1";
            }

            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor deviceModel = deviceService.GetModel(deviceID);
            if (deviceModel == null)
            {
                httpsend(strJson("设备不存在"));
            }
            Maticsoft.BLL.device_rect_infor rectService = new Maticsoft.BLL.device_rect_infor();
            Maticsoft.Model.device_rect_infor rectmodel = new Maticsoft.Model.device_rect_infor();
            List<Maticsoft.Model.device_rect_infor> deviceRectlist = rectService.GetModelList("deviceid='" + deviceID + "' and rectindex='" + rectindex + "'");
            if (pointlist != null && pointlist != "" && pointlist != "\"\"")
            {
                Newtonsoft.Json.Linq.JArray Obj = parsePointArray(pointlist);
                Obj.RemoveAt(Obj.Count - 1);
                string NewStr = "[";
                for (int i = 0; i < Obj.Count; i++)
                {
                    string GetX = Obj[i]["x"].ToString();
                    string GetY = Obj[i]["y"].ToString();
                    if (i == Obj.Count - 1)
                    {
                        NewStr += "{x:" + GetX + "," + "y:" + GetY + "}";
                    }
                    else
                    {
                        NewStr += "{x:" + GetX + "," + "y:" + GetY + "}" + ",";
                    }
                    //string GetI = Obj[i]["x"].ToString();
                }
                NewStr += "]";
                pointlist = JsonConvert.SerializeObject(parsePointArray(NewStr));
            }
            bool isOk = false;
            if (deviceRectlist.Count>0)
            {
                deviceRectlist[0].pointlist = pointlist;
                deviceRectlist[0].rectname = rectname;
                deviceRectlist[0].pointlist = pointlist;
                deviceRectlist[0].width = w;
                deviceRectlist[0].height = h;
                isOk = rectService.Update(deviceRectlist[0]);
            }
            else
            {
                rectmodel.rectid = Guid.NewGuid().ToString("N");
                rectmodel.deviceid = deviceID;
                rectmodel.devicename = deviceModel.devicename;
                rectmodel.rectname = rectname;
                rectmodel.createtime = System.DateTime.Now;
                rectmodel.rectindex = int.Parse(rectindex);
                //if (pointlist != null && pointlist != "" && pointlist != "\"\"")
                //{
                //    Newtonsoft.Json.Linq.JArray Obj = parsePointArray(pointlist);
                //    Obj.RemoveAt(Obj.Count - 1);
                //    string NewStr = "[";
                //    for (int i = 0; i < Obj.Count; i++)
                //    {
                //        string GetX = Obj[i]["x"].ToString();
                //        string GetY = Obj[i]["y"].ToString();
                //        if (i==Obj.Count-1)
                //        {
                //            NewStr += "{x:" + GetX + "," + "y:" + GetY + "}" ;
                //        }
                //        else
                //        {
                //            NewStr += "{x:" + GetX + "," + "y:" + GetY + "}" + ",";
                //        }                                      
                //        //string GetI = Obj[i]["x"].ToString();
                //    }
                //    NewStr += "]";
                //    rectmodel.pointlist = NewStr;
                //}
                rectmodel.pointlist = pointlist;
                rectmodel.width = w;
                rectmodel.height = h;
                rectService.Add(rectmodel);        
                List<Maticsoft.Model.device_rect_infor> list = rectService.GetModelList("deviceID='" + deviceID + "' and rectindex='" + rectindex + "'");
                isOk = submitRegion(deviceModel, list);         
            }
            if (isOk)
            {
                httpsend(strJson("提交成功"));
            }
            else
            {
                httpsend(strJson("数据异常，提交失败"));
            }

        }

        #endregion

        #region 预设点数据操作接口

        [WebMethod(Description = "接口描述：获取当前红外设备下的所有预设点 machinemac")]
        public void getYsds(string machinemac, string deviceID)
        {

            string mac = parseMac(machinemac, deviceID);

            ArrayList ysdList = new ArrayList();

            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
            string machineid = machineService.getMachineIdByMac(mac);

            if (machineid != null)
            {
                Maticsoft.BLL.ysd_infor ysdService = new Maticsoft.BLL.ysd_infor();
                List<Maticsoft.Model.ysd_infor> list = ysdService.GetModelList("machineid='" + machineid + "' order by orderindex asc");
                if (list != null)
                {
                    foreach (Maticsoft.Model.ysd_infor ysd in list)
                    {
                        string ysdname = ysd.ysdname;

                        DataTable devicelist = gen_devicelist(mac, ysdname);

                        PresetPoint presetPoint = new PresetPoint();
                        presetPoint.name = "预设点" + ysdname;
                        presetPoint.isAdd = (devicelist.Rows.Count > 0)||true;
                        presetPoint.deviceList = devicelist;

                        ysdList.Add(presetPoint);
                    }
                }
            }

            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(ysdList));

        }

        [WebMethod(Description = "接口描述：获取预设点下的设备 machinemac, ysdindex （ysdindex从0开始！！！）")]
        public void getDevices(string machinemac, string deviceID, string ysdindex)
        {
            string mac = parseMac(machinemac, deviceID);

            string ysdname = parseYsdname(ysdindex);

            DataTable devicelist = gen_devicelist(mac, ysdname);

            httpsend(ToJson(devicelist));
        }

        [WebMethod(Description = "接口描述：配置预设点距离，阈值，是否是守望点，是否是重点监测设备（ysdindex从0开始！！！）")]
        public void Y_device_Config(string machinemac, string deviceID, string devicename, string ysdindex, string distance, string offsetvalue, string isWatch, string isKeypoint)
        {
            string mac = parseMac(machinemac, deviceID);

            string ysdname = parseYsdname(ysdindex);

            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor deviceModel = deviceService.GetModelByName(devicename, ysdname);

            if (deviceModel != null)
            {
                deviceModel.distance = Convert.ToDouble(distance);
                deviceModel.offsetvalue = offsetvalue;
                deviceModel.isroundpoint = isWatch;
                deviceModel.iskeypoint = isKeypoint;

                deviceService.Update(deviceModel);
            }
            else
            {
                deviceModel = new Maticsoft.Model.device_infor();

                deviceModel.deviceid = Guid.NewGuid().ToString("N");

                Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
                Maticsoft.Model.machine_infor machine = machineService.GetModelbymac(mac);

                if (machine != null)
                {
                    deviceModel.areaid = machine.areaid;
                    deviceModel.areaname = machine.areaname;
                    deviceModel.fenbuid = machine.fenbuid;
                    deviceModel.fenbuname = machine.fenbuname;
                    deviceModel.ywbid = machine.ywbid;
                    deviceModel.ywbname = machine.ywbname;
                    deviceModel.stationid = machine.stationid;
                    deviceModel.stationname = machine.stationname;
                    deviceModel.buildingid = machine.buildingid;
                    deviceModel.buildingname = machine.buildingname;
                    deviceModel.machineid = machine.machineid;
                    deviceModel.machinename = machine.machinename;
                }

                deviceModel.ysdname = ysdname;

                Maticsoft.BLL.ysd_infor ysdService = new Maticsoft.BLL.ysd_infor();
                string ysdid = ysdService.getYsdid(
                        deviceModel.buildingid,
                        deviceModel.machineid,
                        deviceModel.ysdname
                );

                deviceModel.ysdindex = ysdid; // 这个地方的ysdindex, 与其他地方的含义不同，表示自动生成的预设点id值！！！
                deviceModel.devicename = devicename;
                deviceModel.iskeypoint = isKeypoint;
                deviceModel.isroundpoint = isWatch;
                deviceModel.orderindex = Convert.ToDouble(ysdname);
                deviceModel.isopen = Convert.ToString(1);
                deviceModel.distance = Convert.ToDouble(distance);
                deviceModel.offsetvalue = offsetvalue;
                deviceModel.createtime = System.DateTime.Now;

                deviceService.Add(deviceModel);

                // deviceCount +1
                Maticsoft.BLL.station_infor stationService = new Maticsoft.BLL.station_infor();
                stationService.ModifyDeviceCount(deviceModel.stationid, +1);

            }

            httpsend(strJson("1"));
        }

        #endregion

        #region 设备数据查询接口

        [WebMethod(Description = "接口描述：获取电力设备配置类参数")]
        public void getdevice_config_infor(string deviceID, string width, string height,string machineid,string ysdname)
        {
            device_config_infor jsoninfor = new device_config_infor();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
            if (!string.IsNullOrEmpty(deviceID))
            {
                devicemodel = deviceservice.GetModel(deviceID);
            }
            else
            {
                var ModelList=deviceservice.GetModelList("machineid='"+machineid+ "' And ysdname='"+ysdname+"'");
                if (ModelList.Count>=1)
                {
                    devicemodel = ModelList[0];
                }
                else
                {
                    jsoninfor.returnValue = "请先在预设点下添加设备";
                    httpsend( Newtonsoft.Json.JsonConvert.SerializeObject(jsoninfor));
                }
            }
            if (devicemodel != null)
            {
                jsoninfor.Areaid = devicemodel.areaid;
                jsoninfor.Areaname = devicemodel.areaname;
                jsoninfor.Fenbuid = devicemodel.fenbuid;
                jsoninfor.Fenbuname = devicemodel.fenbuname;
                jsoninfor.Ywbid = devicemodel.ywbid;
                jsoninfor.Ywbname = devicemodel.ywbname;
                jsoninfor.Stationid = devicemodel.stationid;
                jsoninfor.Stationname = devicemodel.stationname;
                jsoninfor.Buildingid = devicemodel.buildingid;
                jsoninfor.Buildingname = devicemodel.buildingname;
                jsoninfor.Machineid = devicemodel.machineid;
                jsoninfor.Machinename = devicemodel.machinename;
                jsoninfor.Ysdid = devicemodel.ysdindex; // 这个地方的ysdindex, 与其他地方的含义不同，表示自动生成的预设点id值！！！
                jsoninfor.Ysdname = devicemodel.ysdname;
                jsoninfor.Alarmvalue = devicemodel.offsetvalue;

                Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                Maticsoft.Model.machine_infor machinemodel = new Maticsoft.Model.machine_infor();

                machinemodel = machineservice.GetModel(devicemodel.machineid);
                if (machinemodel != null)
                {
                    jsoninfor.Machinemac = machinemodel.machinemac;
                    jsoninfor.Machinecode = machinemodel.machinecode;
                    jsoninfor.Machineip = "192.168.1.168";
                    jsoninfor.Wifiname = machinemodel.wifiname;
                    jsoninfor.Wifipass = machinemodel.wifipass;
                    jsoninfor.Red_video_infor = "红外视频流";
                    jsoninfor.High_video_infor = "高清视频流";
                    jsoninfor.Cloudaddr = machinemodel.Cloudaddr;
                    jsoninfor.Fushelv = machinemodel.fushelv;
                    jsoninfor.Filepath = "//温度校准文件.xls";
                    jsoninfor.Rong_S = machinemodel.Sv;
                    jsoninfor.Rong_R = machinemodel.Rv;
                    jsoninfor.Rong_L = machinemodel.Lv;
                    jsoninfor.Rong_T = machinemodel.Tv;
                    jsoninfor.Hongwai_cx = "";
                    jsoninfor.Bianyuan_cx = "";
                    jsoninfor.Point_ysd_index = "";
                    jsoninfor.Catch_span = machinemodel.imagecatchspan;//抓拍周期
                    jsoninfor.Xunshi_span = machinemodel.newversion;//巡视周期
                }
                jsoninfor.Image1 = devicemodel.image_high;
                jsoninfor.Image2 = devicemodel.image_mix;

                Maticsoft.BLL.media mediaService = new Maticsoft.BLL.media();
                Maticsoft.Model.media mediaModel = mediaService.GetModel(devicemodel.mediaindex);

                if (mediaModel != null)
                {
                    // 增加视频数据
                    jsoninfor.Video = gen_video(
                        mediaModel.Host,
                        mediaModel.Port,
                        jsoninfor.Machinemac
                        );
                }
                else
                {
                    jsoninfor.Video = new Video();
                }

                // 增加区域坐标数据
                if (deviceID != "" && width != "" && height != "")
                {
                    jsoninfor.Rectlist = gen_rectlist(deviceID, width, height);
                }
                Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
                jsoninfor.Imagelist = historyservice.GetList("deviceID='" + deviceID + "' and createtime>'" + System.DateTime.Now.Date + "'").Tables[0];
                jsoninfor.Devicelist = deviceservice.GetList("machineid='" + devicemodel.machineid + "'").Tables[0];
                Maticsoft.BLL.ysd_infor ysdservice = new Maticsoft.BLL.ysd_infor();
                jsoninfor.Ysdlist = ysdservice.GetList("machineid='" + devicemodel.machineid + "'").Tables[0];
                jsoninfor.returnValue = "成功";
                //httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(jsoninfor));
            }
            else
            {
                jsoninfor.returnValue = "请先在预设点下添加设备";
            }
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(jsoninfor));
        }

        [WebMethod(Description = "接口描述：获取当前红外设备下的抓拍图片")]
        public void getHistoryImagebymachine(string machineid,string ysdname)
        {
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            DataSet ds = historyservice.GetList("deviceid in (select deviceid from device_infor where machineid='" + machineid + "' And  ysdname='" + ysdname + "') and createtime>'" + System.DateTime.Now.AddHours(-2) + "' order by createtime desc ");
            httpsend(ToJson(ds.Tables[0]));
        }

        [WebMethod(Description = "接口描述：获取当前红外设备下的所有预设点")]
        public void getYsdinforBymachine(string machineid)
        {
            Maticsoft.BLL.ysd_infor ysdservice = new Maticsoft.BLL.ysd_infor();

            DataTable dt = ysdservice.GetList("machineid='" + machineid + "' order by orderindex asc").Tables[0];
            dt.Columns.Add("distance", Type.GetType("System.String"));

            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();

            foreach (DataRow dataRow in dt.Rows)
            {
                string ysdid = dataRow["ysdid"].ToString();
                string distance = "0";
                // Maticsoft.Model.device_infor device = deviceService.GetModelByMach(machineid, ysdname);
                Maticsoft.Model.device_infor device = deviceService.GetModelByYsdid(ysdid);
                if (device!=null)
                {
                   distance = Convert.ToString(device.distance);
                }
                dataRow["distance"] = distance;
            }
            DataTable dt1;
            dt1 = dt.Clone();
            for (int i = 1; i < 61; i++)
            {
                bool falg = true;
                string index = i.ToString();
                if (dt.Rows.Count > 0)
                {
                    for (int j = 0; j < dt.Rows.Count; j++)
                    {
                        string ysdname = dt.Rows[j]["ysdname"].ToString();
                        if (ysdname == index)//添加数据库预设点数据
                        {
                            dt1.Rows.Add(dt.Rows[j].ItemArray);
                            falg = false;
                            break;
                        }
                        //else//添加虚拟数据
                        //{
                        //    string ceshiysdname = "预设点名称" + i;
                        //    //DataRow newRow = dt1.NewRow();
                        //    //newRow["ysdname"] = ceshiysdname;
                        //    //dt1.Rows.Add(newRow);//在最后面插入数据
                        //    dt1.Rows.Add(new object[] { });
                        //    dt1.Rows[i - 1]["ysdname"] = ceshiysdname;

                        //}
                    }
                    if (falg)
                    {
                        string ceshiysdname = "预设点名称" + i;
                        dt1.Rows.Add(new object[] { });
                        dt1.Rows[i - 1]["ysdname"] = ceshiysdname;
                    }
                }
                else
                {
                    string ceshiysdname = "预设点名称" + i;
                    dt1.Rows.Add(new object[] { });
                    dt1.Rows[i - 1]["ysdname"] = ceshiysdname;
                }

            }
            httpsend(ToJson(dt1));
        }

        [WebMethod(Description = "接口描述：获取预设点下的设备")]
        public void getdeviceBuysd(string ysdid)
        {
            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            DataTable dt = new DataTable();
            //这个地方的ysdindex, 与其他地方的含义不同，表示自动生成的预设点id值！！！
            if (ysdid!=null&& ysdid!="")
            {
             dt = deviceService.GetList("ysdindex='" + ysdid + "' ").Tables[0];

            }                       
            httpsend(ToJson(dt));
           

        }

        #endregion

        #region 工具方法

        #region MQTT 命令发送

        private void sendCommand(Command command)
        {
            if (command.type == CType.GO_UP ||
                command.type == CType.GO_DOWN ||
                command.type == CType.GO_LEFT ||
                command.type == CType.GO_RIGHT ||
                command.type == CType.GO_STOP)
            {
                command.value = "1500"; // 步进值
            }

            Result result = sendCommandByMQTT(command);
            //returnjson json = new returnjson();
            if (result.status == MqttAgent.STATUS_OK)
            {
                //httpsend(strJson(String.Format("{0}成功! ({1} {2})", command.message, result.message, result.status)));               
                httpsend(strJson1(String.Format("{0}成功", command.message),command.isCloudCommand));
            }
            else
            {
                
                httpsend(strJson1(String.Format("{0}失败", command.message),command.isCloudCommand));
            }         

        }

        private Result sendCommandByMQTT(Command command)
        {

            Result result = new Result(MqttAgent.STATUS_ERROR, "");

            string mac = parseMac(command.mac, command.code);
            // 查询是否存在当前的Mac地址
            Maticsoft.BLL.machine_infor BLLMachine = new Maticsoft.BLL.machine_infor();

            var BLLList=BLLMachine.getModelByMac(mac);

            if (BLLList!=null)
            {
                // 判断是否存在当前的预设点
                Maticsoft.BLL.ysd_infor BLLYSD = new Maticsoft.BLL.ysd_infor();
                var BLLYSDList=BLLYSD.GetModelList(" machineid='"+BLLList.machineid+"'");
                if (BLLYSDList.Count>=1)
                {
                    if (mac != null)
                    {
                        command.mac = mac;

                        if (command.isCloudCommand)
                        {
                            result = MqttAgent.sendCloudCommand(command);
                        }
                        else
                        {
                            result = MqttAgent.sendVideoCommand(command);
                        }

                    }
                }
            }
            return result;
        }

        #endregion

        #region 生成操作

        public Video gen_video(string host, string port, string machineMac)
        {
            Video vd = new Video();

            if (host != null && port != null && machineMac != null)
            {
                // TODO 查询流媒体服务器接口，生成视频列表

                string baseStr = host + ":" + port + "/live/" + machineMac;
                // string baseStr = host + ":" + port + "/live/test";
                string baseIr = baseStr + "/ir.flv";
                string baseHigh = baseStr + "/high.flv";

                vd.HasVideo = "3"; // 0: 无视频 1：只有红外视频 2: 只有高清视频 3：两者都有

                vd.Ir.Add("http://" + baseIr);
                vd.Ir.Add("ws://" + baseIr);

                vd.High.Add("http://" + baseHigh);
                vd.High.Add("ws://" + baseHigh);
            }

            return vd;
        }

        private DataTable gen_rectlist(String deviceID, string width, string height)
        {

            DataTable rectlist = new DataTable("rectlist");

            rectlist.Columns.Add("rectid", Type.GetType("System.String"));
            rectlist.Columns.Add("count", Type.GetType("System.Int32"));
            rectlist.Columns.Add("pointlist", Type.GetType("System.String"));
            rectlist.Columns.Add("width", Type.GetType("System.Int32"));
            rectlist.Columns.Add("height", Type.GetType("System.Int32"));
            rectlist.Columns.Add("isValid", Type.GetType("System.Boolean"));

            // 查询区域坐标点 by King-1025
            Maticsoft.BLL.device_rect_infor deviceRectService = new Maticsoft.BLL.device_rect_infor();
            DataTable tmpRec = deviceRectService.GetList("deviceid='" + deviceID + "'").Tables[0];
            string NewStr = "";
            if (tmpRec != null && tmpRec.Rows.Count > 0)
            {
                foreach (DataRow dataRow in tmpRec.Rows)
                {
                    string pointlist = dataRow["pointlist"].ToString();
                    if (pointlist!=null && pointlist!=""&& pointlist!="\"\"")
                    {
                        Newtonsoft.Json.Linq.JArray jsonArr = parsePointArray(pointlist);

                        if (jsonArr == null)
                        {
                            continue;
                        }
                        int pointCount = jsonArr.Count;
                        int newPoinCount = pointCount + 1;
                        NewStr += "[";
                        for (int i = 0; i < newPoinCount; i++)
                        {
                            string GetX = "";
                            string GetY = "";                          
                            if (i == newPoinCount - 1)
                            {
                                GetX = jsonArr[0]["x"].ToString();
                                GetY = jsonArr[0]["y"].ToString();
                                NewStr += "{x:" + GetX + "," + "y:" + GetY + "}";
                            }
                            else
                            {
                                GetX = jsonArr[i]["x"].ToString();
                                GetY = jsonArr[i]["y"].ToString();
                                NewStr += "{x:" + GetX + "," + "y:" + GetY + "}" + ",";
                            }
                        }
                        NewStr += "]";
                        jsonArr = parsePointArray(NewStr);
                        float w = float.Parse(width);  // 前端画布宽
                        float h = float.Parse(height); // 前端画布高
                        int pw = 0;
                        int ph = 0;

                        if (dataRow["width"] != null && dataRow["width"].ToString() != "")
                        {
                            pw = int.Parse(dataRow["width"].ToString()); // 坐标系宽
                        }

                        if (dataRow["height"] != null && dataRow["height"].ToString() != "")
                        {
                            ph = int.Parse(dataRow["height"].ToString());  // 坐标系高 
                        }

                        pw = (pw == 0) ? 640 : pw;
                        ph = (ph == 0) ? 480 : ph;

                        int px = pw;
                        int py = ph;
                        bool isValid = false;

                        if (w > 0 && h > 0 && pw > 0 && ph > 0)
                        {
                            isValid = true;

                            if (pw != w || ph != h)
                            {
                                float fx = w / pw;
                                float fy = h / ph;

                                for (int i = 0; i < pointCount; i++)
                                {

                                    int sx = int.Parse(jsonArr[i]["x"].ToString());
                                    int sy = int.Parse(jsonArr[i]["y"].ToString());                                 

                                    int x = (int)(sx * fx);
                                    int y = (int)(sy * fy);

                                    x = (x < 0) ? 0 : x;
                                    y = (y < 0) ? 0 : y;

                                    x = (int)((x > w) ? w : x);
                                    y = (int)((y > h) ? h : y);

                                    jsonArr[i]["x"] = x;
                                    jsonArr[i]["y"] = y;
                                }

                                px = (int)w;
                                py = (int)h;
                            }

                        }
                        rectlist.Rows.Add(new object[] {
                                     dataRow["rectid"].ToString(),
                                     newPoinCount,
                                     JsonConvert.SerializeObject(jsonArr),
                                     px,
                                     py,
                                     isValid
                            });                  
                    }


                }
            }

            return rectlist;
        }

        private DataTable gen_devicelist(string machinemac, string ysdname)
        {
            DataTable devicelist = new DataTable("devicelist");
            devicelist.Columns.Add("tag", Type.GetType("System.String"));
            devicelist.Columns.Add("name", Type.GetType("System.String"));
            devicelist.Columns.Add("mac", Type.GetType("System.String"));
            devicelist.Columns.Add("warnTemperature", Type.GetType("System.String"));
            devicelist.Columns.Add("distance", Type.GetType("System.String"));
            devicelist.Columns.Add("isLookPoint", Type.GetType("System.Boolean"));
            devicelist.Columns.Add("isTrack", Type.GetType("System.Boolean"));

            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
            string machineid = machineService.getMachineIdByMac(machinemac);
            if (machineid != null)
            {

                Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
                List<Maticsoft.Model.device_infor> list = deviceService.GetModelList("machineid='" + machineid + "' and ysdname='" + ysdname + "'");
                if (list != null)
                {
                    int i = 0;
                    foreach (Maticsoft.Model.device_infor device in list)
                    {
                        i += 1;

                        string isroundpoint = device.isroundpoint;
                        string iskeypoint = device.iskeypoint;

                        // for bad data
                        if (isroundpoint == null ||
                            "true".Equals(isroundpoint) ||
                            "false".Equals(isroundpoint) ||
                            "".Equals(isroundpoint)
                            ) {
                            isroundpoint = "0";
                        }

                        // for bad data 
                        if (iskeypoint == null ||
                            "true".Equals(iskeypoint) ||
                            "false".Equals(iskeypoint) ||
                            "".Equals(iskeypoint)
                         )
                        {
                            iskeypoint = "0";
                        }

                        devicelist.Rows.Add(new Object[] {
                            "设备",
                            device.devicename,
                            machinemac,
                            device.offsetvalue,
                            Convert.ToString(device.distance),
                            Convert.ToInt32(isroundpoint) == 1,
                            Convert.ToInt32(iskeypoint) == 1
                        });
                    }
                }
            }

            return devicelist;
        }

        #endregion

        #region JSON操作

        public string json_to_point(List<Maticsoft.Model.device_rect_infor> list, bool isHSDevice)
        {
            StringBuilder areastr = null;

            if (list != null && list.Count > 0)
            {
                // 字符串拼接修复 by King-1025
                areastr = new StringBuilder(); ;

                float w = 640;
                float h = 480;

                // 如果是海思设备，改变坐标宽高
                if (isHSDevice)
                {
                    w = 320;
                    h = 240;
                }

                // 预设点编号从0开始
                int pindex = list[0].rectindex - 1;

                pindex = pindex < 0 ? 0 : pindex;

                areastr.Append(w + "," + h + ":");

                int areacount = list.Count;
                
                areastr.Append(pindex + "," + areacount + ":");

                foreach (Maticsoft.Model.device_rect_infor rect in list)
                {
                    int width  = (rect.width  > 0)? rect.width  : 640;
                    int height = (rect.height > 0)? rect.height : 480;

                    Newtonsoft.Json.Linq.JArray jsonArr = parsePointArray(rect.pointlist);

                    if(jsonArr != null)
                    {
                        // 坐标数量
                        int pointCount = jsonArr.Count;

                        areastr.Append("p," + pointCount + "/");

                        float fx = w / width;
                        float fy = h / height;

                        for (int i = 0; i < pointCount; i++)
                        {
                            int sx = int.Parse(jsonArr[i]["x"].ToString());
                            int sy = int.Parse(jsonArr[i]["y"].ToString());

                            int x = (int)(sx * fx);
                            int y = (int)(sy * fy);

                            x = (x < 0) ? 0 : x;
                            y = (y < 0) ? 0 : y;

                            x = (int)((x > w) ? w : x);
                            y = (int)((y > h) ? h : y);

                            areastr.Append(x + "," + y + "/");
                        }

                        areastr.Append(":");
                    }
                }

            }

           // areastr.Append("   fx: " +String.Format("{0:f}", (w/width)) +
           //    " fy: " + String.Format("{0:f}", fy) + " w: " + w + " h: " + h + " width: " + width + " height: " + height);

            if(areastr != null)
            {
                return areastr.ToString();
            } else
            {
                return null;
            }
           
        }

        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }

        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = Int32.MaxValue;
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }

        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msg");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        public string strJson1(string jsonText,bool falg)
        {
            DataTable dt = new DataTable("msg");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Columns.Add("falg", Type.GetType("System.Boolean"));
            dt.Rows.Add(new object[] { jsonText,falg });
            return ToJson(dt);
        }

        #endregion

        #region 区域操作

        private bool submitRegion(Maticsoft.Model.device_infor deviceModel, List<Maticsoft.Model.device_rect_infor> list)
        {
         
            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor machine = machineService.GetModel(deviceModel.machineid);

            bool isHSDevice = false;

            if (machine.MediaIndex > 0 || deviceModel.mediaindex > 0)
            {
                isHSDevice = true;
            }

            string data = json_to_point(list, isHSDevice);

            if (data != null)
            {
                string mac = machine.machinemac.ToLower();

                Command command = new Command(CType.SET_REGION, "设定测温区域", true);
                command.mac = mac;
                command.code = machine.machinecode;
                command.value = data;
                sendCommand(command);

                return true;
            }
            else
            {
                return false;
            }

        }

        private bool removeRegion(Maticsoft.BLL.device_rect_infor rectService, string deviceID, string rectindex)
        {
            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor deviceModel = deviceService.GetModel(deviceID);

            List<Maticsoft.Model.device_rect_infor> list = rectService.GetModelList("deviceID='" + deviceID + "' and rectindex='" + rectindex + "'");

            return submitRegion(deviceModel, list);
        }

        #endregion

        #region 解析操作

        private Newtonsoft.Json.Linq.JArray parseTargetArray(string targetlist)
        {
            Newtonsoft.Json.Linq.JArray arry = null;

            if (targetlist != null && targetlist != "")
            {
                Newtonsoft.Json.Linq.JArray jsonArr = (Newtonsoft.Json.Linq.JArray)JsonConvert.DeserializeObject(targetlist);

                if (jsonArr != null)
                {
                    if (jsonArr.Count > 0)
                    {
                        arry = jsonArr;
                    }
                }
            }

            return arry;
        }

        private Newtonsoft.Json.Linq.JArray parsePointArray(string pointlist)
        {
            Newtonsoft.Json.Linq.JArray arry = null;

            if (pointlist != null && pointlist != "")
            {
                Newtonsoft.Json.Linq.JArray jsonArr = (Newtonsoft.Json.Linq.JArray)JsonConvert.DeserializeObject(pointlist);

                if (jsonArr != null)
                {
                    if (jsonArr.Count > 0)
                    {
                        arry = jsonArr;
                    }
                }
            }

            return arry;
        }

        private string parseYsdname(string value)
        {
            string ysdname = "";
            if(value!=null)
            {
                ysdname = Convert.ToString(Convert.ToInt32(value)+1);
            }
            return ysdname;
        }

        private string parseMac(string mac, string code)
        {
            string tmpMac = mac;
            if(tmpMac == null || "".Equals(tmpMac))
            {
                if(code != null && !"".Equals(code))
                {
                    Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
                    tmpMac = machineService.getMacByCode(code);
                }
            }
            return tmpMac;
        }

        #endregion

        #region 测试方法

        public void testRegion()
        {
            // for king test
            X_sendRectToMachine("b827eb3e343a", "640,480:0,1:l,4/248,213/198,321/371,283/10,10/:");

            httpsend(strJson("提交成功"));

        }

        public void X_sendRectToMachine(string machinemac, string point)
        {
            machinemac = machinemac.ToLower(); // 这里需要小写转换! by King-1025
            /* MessageJson json = new MessageJson();
             json.deviceID = machinemac;
             json.data = null;*/
           // action.sendMsg_Cloud(machinemac, 0xAE, point, "");
        }

        private void _X_connectMqttServer_old()
        {
            mqttCommunication action = new mqttCommunication();

            action.updateMqtt();

            string sx = action.connectServer();

            if (sx == "0")
            {
                httpsend(strJson("连接失败"));
            }
            else
            {
                httpsend(strJson("连接成功"));
            }
        }

        [WebMethod(Description = "初始化并连接mqtt服务器")]
        public void X_connectMqttServer()
        {
            httpsend(strJson("连接成功"));
        }

        #endregion

        #endregion

        #region 预设点设备操作
        [WebMethod(Description = "接口描述：添加预设点设备 传值：ysdid[413160f9b8aa4c17b0f0a1117edc42c1]，deviceNmae[监控部位] ,operaterNumber[电力设备],deviceID[当前页面的设备id   16fb78c9e0a04a2d8df26e01d21195ac]")]
        public void saveDeviceByYsd(string ysdid, string deviceName, string operaterNumber,string deviceID)
        {
            Maticsoft.BLL.ysd_infor ysdService = new Maticsoft.BLL.ysd_infor();
            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            if (ysdid !=null && ysdid!="")
            {
                Maticsoft.Model.ysd_infor ysdModel = ysdService.GetModel(ysdid);
                if (ysdModel!=null)
                {
                    Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
                    //添加设备
                    model.deviceid = Guid.NewGuid().ToString("N");
                    model.areaname = ysdModel.areaname;
                    model.fenbuname = ysdModel.fenbuname;
                    model.ywbname = ysdModel.ywbname;
                    model.stationname = ysdModel.stationname;
                    model.buildingname = ysdModel.buildingname;
                    model.machinename = ysdModel.machinename;
                    model.areaid = ysdModel.areaid;
                    model.fenbuid = ysdModel.fenbuid;
                    model.ywbid = ysdModel.ywbid;
                    model.stationid = ysdModel.stationid;
                    model.buildingid = ysdModel.buildingid;
                    model.machineid = ysdModel.machineid;
                    model.ysdname = ysdModel.ysdname;
                    model.ysdindex = ysdModel.ysdid;
                    model.devicename = deviceName;
                    model.iskeypoint = "0";
                    model.isroundpoint = "0";
                    model.todaytop = "0.0";
                    model.yestodaytop = "0.0";
                    model.weektop = "0.0";
                    model.monthtop = "0.0";
                    model.historytop = "0.0";
                    model.todaymax = "0.0";
                    model.monthmax = "0.0";
                    model.orderindex = int.Parse(ysdModel.ysdname);
                    model.isopen = "1";
                    model.fuhe = "";
                    model.offsethuman = "";
                    if (deviceID!=null && deviceID!=null)
                    {
                       Maticsoft.Model.device_infor deviceinfor =  deviceService.GetModel(deviceID);
                        if (deviceinfor!=null)
                        {
                            model.offsetvalue = deviceinfor.offsetvalue;
                            model.ysdtype = deviceinfor.ysdtype;
                            model.ysdlevel = deviceinfor.ysdlevel;                           
                        }
                    }
                    model.createtime = System.DateTime.Now;
                    model.operaterNumber = operaterNumber;//添加运行编号
                    deviceService.Add(model);
                    List<Maticsoft.Model.device_infor> deviceList = new List<Maticsoft.Model.device_infor>();
                    deviceList = deviceService.GetModelList("stationid='" + ysdModel.stationname + "'");
                    Maticsoft.BLL.station_infor stationService = new Maticsoft.BLL.station_infor();
                    stationService.UpdateDevicecount(ysdModel.stationid, deviceList.Count.ToString());
                    //Command command = new Command(CType.ADD_POINT, "添加预设点设备", true);
                    //sendCommand(command);
                    httpsend(strJson("区域添加成功"));
                }
             
            }
            else
            {
                httpsend(strJson("预设点不存在"));
            }
        }

        [WebMethod(Description = "接口描述：区域重命名 传值：rangeId区域id值[16fb78c9e0a04a2d8df26e01d21195ac],deviceNmae[监控部位] ")]
        public void modifyDeviceNamed(string deviceID, string deviceName)
        {
            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            if (deviceID != null && deviceID != "")
            {
                Maticsoft.Model.device_infor deviceModel = deviceService.GetModel(deviceID);
                if (deviceModel!=null)
                {
                    if (deviceName!=null && deviceName!="")
                    {
                        bool updatestatus = deviceService.UpdateDeviceName(deviceName, deviceID);
                        if (updatestatus)
                        {
                             httpsend(strJson("修改成功"));
                        }
                        else
                        {
                            httpsend(strJson("修改失败"));
                        }
                    }
                }
            }
            else
            {
                httpsend(strJson("区域不存在"));
            }



        }
        #endregion

        #region 心跳参数监听接口
        [WebMethod(Description = "接口描述：心跳参数监听接口")]
        public void listen_heartbeat(
            string mac,  // mac地址
            string rad,  // 辐射率
            string warn, // 告警温度
            string sv,   // S 红外融合呈现参数
            string rv,   // R 边缘呈现参数
            string lv,   // L 水平偏移
            string tv,   // T 垂直偏移
            string mip,  // MQTT地址
            string fip,  // FTP地址
            string wn,   // WIFI名称
            string wp,   // WIFI密码
            string num,  // 设备编号
            string pfv,  // piFlir版本
            string pvv   // piVideo版本
        ) {
            Maticsoft.Model.machine_infor machine = new Maticsoft.Model.machine_infor();
            machine.machinemac = mac;
            machine.fushelv = rad;
            machine.Warntemp = warn;
            machine.Sv = sv;
            machine.Rv = rv;
            machine.Lv = lv;
            machine.Tv = tv;
            machine.Cloudaddr = mip;
            machine.Ftpaddr = fip;
            machine.wifiname = wn;
            machine.wifipass = wp;
            machine.machinecode = num;
            machine.piFlirVersion = pfv;
            machine.piVideoVersion = pvv;

            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
            machineService.UpdateArgs(machine);
            httpsend(strJson("1"));
        }

        #endregion

        #region 预设点温度监听接口
        [WebMethod(Description = "接口描述：预设点温度监听接口")]
        public void listen_temperature(
            string mac,
            string ysdname, // 预设点编号
            string max,
            string min,
            string avg,
            string cnt,
            string time
        ) {
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();

            Maticsoft.Model.device_infor device = new Maticsoft.Model.device_infor();

            device.machineid = machineService.getMachineIdByMac(mac);
            device.ysdname = ysdname;
            device.ppmax = max;
            device.ppmin = min;
            device.ppavg = avg;
            device.ppcnt = cnt;
            device.pptime = DateTime.Parse(time);

            deviceservice.UpdatePresetTemp(device);
            httpsend(strJson("1"));
        }

        #endregion

      /*  [WebMethod(Description = "接口描述：心跳参数接入接口")]
        public void getDeviceHeartBeat()
        {
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            Maticsoft.BLL.device_heart_infor deviceheartservice = new Maticsoft.BLL.device_heart_infor();
            devicelist = deviceservice.GetModelList("");
            if (devicelist.Count > 0)
            {
                foreach (var device in devicelist)
                {
                    if (device != null)//更新设备15分钟测温表
                    {
                        Maticsoft.Model.device_heart_infor deviceHeartModel = new Maticsoft.Model.device_heart_infor();
                        deviceHeartModel.id = Guid.NewGuid().ToString("N");
                        deviceHeartModel.deviceid = device.deviceid;
                        deviceHeartModel.devicename = device.devicename;
                        deviceHeartModel.areaid = device.areaid;
                        deviceHeartModel.areaname = device.areaname;
                        deviceHeartModel.fenbuid = device.fenbuid;
                        deviceHeartModel.fenbuname = device.fenbuname;
                        deviceHeartModel.ywbid = device.ywbid;
                        deviceHeartModel.ywbname = device.ywbname;
                        deviceHeartModel.stationid = device.stationid;
                        deviceHeartModel.stationname = device.stationname;
                        deviceHeartModel.buildingid = device.buildingid;
                        deviceHeartModel.buildingname = device.buildingname;
                        deviceHeartModel.machineid = device.machineid;
                        deviceHeartModel.machinename = device.machinename;
                        deviceHeartModel.ysdindex = device.ysdindex;
                        deviceHeartModel.ysdname = device.ysdname;
                        deviceHeartModel.operaterNumber = device.operaterNumber;
                        deviceHeartModel.ppavg = device.ppavg;
                        deviceHeartModel.ppcnt = device.ppcnt;
                        deviceHeartModel.ppmax = device.ppmax;
                        deviceHeartModel.ppmin = device.ppmin;
                        deviceHeartModel.createtime = device.pptime;
                        deviceheartservice.Add(deviceHeartModel);
                    }
                }
            }
            //设置守望点
            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
            List<Maticsoft.Model.machine_infor> machinelist = machineService.GetModelList("");
            Maticsoft.BLL.ysd_infor ysdService = new Maticsoft.BLL.ysd_infor();
            if (machinelist.Count > 0)
            {
                System.Diagnostics.Debug.WriteLine("machinelist===========" + machinelist.Count);
                for (int i = 0; i < machinelist.Count; i++)
                {
                    System.Diagnostics.Debug.WriteLine("红外设备执行===========" + i + "================次");
                    if (machinelist[i] != null)//获取红外设备的所有预设点
                    {
                        double ppmaxMax = 0.0;//15分钟测温最大值
                        string deviceidmax = "";//15分钟测温最大值的设备id 
                        string machineid = machinelist[i].machineid;
                        List<Maticsoft.Model.ysd_infor> ysdlist = ysdService.GetModelList("machineid='" + machineid + "' order by orderindex asc");
                        if (ysdlist.Count > 0)
                        {
                            for (int j = 0; j < ysdlist.Count; j++)//获取预设点下的所有设备
                            {
                                if (ysdlist[j] != null)
                                {
                                    string ysdid = ysdlist[j].ysdid;
                                    List<Maticsoft.Model.device_infor> deviceModellist = deviceservice.GetModelList("ysdindex='" + ysdid + "'");
                                    if (deviceModellist.Count > 0)
                                    {
                                        List<double> ppmaxlist = new List<double>(); ppmaxlist.Add(0.0);
                                        List<string> deviceidlist = new List<string>(); deviceidlist.Add("");
                                        for (int k = 0; k < deviceModellist.Count; k++)//获取设备的15分钟测温值
                                        {
                                            if (deviceModellist[k] != null && deviceModellist[k].ppmax != null)
                                            {
                                                ppmaxlist.Add(double.Parse(deviceModellist[k].ppmax));//15分钟测温值
                                                                                                      //System.Diagnostics.Debug.WriteLine("deviceModellist[k]===========" + deviceModellist[k].ppmax);
                                                deviceidlist.Add(deviceModellist[k].deviceid);
                                                //deviceModellist[k].isroundpoint = Convert.ToString(0);
                                                //deviceservice.Update(deviceModellist[k]);
                                                bool falg = deviceservice.UpdateRound(deviceModellist[k].deviceid, "0");
                                                System.Diagnostics.Debug.WriteLine("更新设备状态为0===========" + falg);
                                            }
                                        }
                                        double ppmax = ppmaxlist.Max();//当前预设点下15分钟测温最大值
                                        if (ppmax >= ppmaxMax)//与上个预设点的最大值对比
                                        {
                                            ppmaxMax = ppmax;//替换最大值
                                            int Indexof = ppmaxlist.IndexOf(ppmaxMax);//当前预设点的最大下坐标
                                            deviceidmax = deviceidlist[Indexof];//当前预设点的15分钟测温最大值的设备id                                      
                                        }
                                    }
                                }
                            }
                        }
                        if (deviceidmax != null && deviceidmax != "")//获取设备的machinecode
                        {
                            System.Diagnostics.Debug.WriteLine("守望点设置执行第==========" + i + "================次");
                            Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(deviceidmax);
                            if (devicemodel != null)
                            {
                                //修改数据库
                                //devicemodel.isroundpoint = Convert.ToString(1);
                                deviceservice.UpdateRound(deviceidmax, "1");
                                //发送指令
                                Command command = new Command(CType.SET_LOOK_POINT, "设置守望点", true);
                                command.mac = machinelist[i].machinemac;
                                command.code = devicemodel.deviceid;
                                command.value = devicemodel.ysdname;
                                sendCommandByMQTT(command);
                            }
                        }
                    }
                }
            }
        }*/
    }

}