﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.ConfigTool
{
    public class MessageJson
    {
        string _deviceID = "";

        public string deviceID
        {
            get { return _deviceID; }
            set { _deviceID = value; }
        }
        List<msgvalue> _data = new List<msgvalue>();

        public List<msgvalue> data
        {
            get { return _data; }
            set { _data = value; }
        }
    }
}