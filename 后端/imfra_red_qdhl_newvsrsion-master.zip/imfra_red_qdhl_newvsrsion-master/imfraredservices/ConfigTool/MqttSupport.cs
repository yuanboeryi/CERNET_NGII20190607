﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Data;
using System.Text;
using System.IO;

namespace King.MqttSupport
{

    // By King-1025 2020.11.18 1543641386@qq.com

    #region MQTT 命令类型

    public enum CType
    {
        CAPTURE_PICTURE = 0x80, // 抓拍
        GO_UP = 0xA0, // 云台向上
        GO_DOWN = 0xA1, // 云台向下
        GO_LEFT = 0x04, // 云台向左
        GO_RIGHT = 0x02, // 云台向右
        GO_STOP = 0x00, // 云台停止
        SET_WIFI = 0xA3, // 设置WIFI
        SET_CLOUD = 0x9D, // 设置云接入地址，MQTT FTP
        SET_FUSHE = 0xA5, // 设置辐射率
        SET_DEVCODE = 0xB7, // 设置设备编号 MAC
        SET_LaT = 0xAB, // 融合参数 L, T
        SET_RaS = 0xAC, // 融合参数 R, S
        SET_INFRA = 0xA9, // 红外呈现参数
        SET_EDGE = 0xAA, // 红外沟边参数
        SET_WARNTMP = 0x9C, // 告警温度
        SET_LOOK_POINT = 0x97, // 守望点
        SET_CATCH_XUN = 0xB4, // 巡检，抓拍周期
        CALL_POINT = 0x07, // 调用预设点
        ADD_POINT = 0x03, // 添加预设点
        REBOOT = 0xA6, // 重启设备
        RESET = 0xA4, // 恢复出厂设置
        UPDATE_PROGRAM = 0xB3, // 设备程序更新
        CLEAR_POINT = 0x05, // 清除预设点
        FIT_TEMP = 0xB1, // 修正温度补偿
        REMOVE_REGION = 0xAF, // 清除测温区域
        SET_REGION = 0xAE, // 设定测温区域
    }

    #endregion

    #region MqttAgent 代理类定义

    public class MqttAgent
    {
        #region HttpWebRequest 定义

        private static readonly string MQTT_AGENT_URL = "http://117.159.7.31:3134/post/submit";
        private static readonly string MQTT_AGENT_URL_V2 = "http://117.159.7.31:3133/post/submit";

        public static readonly int STATUS_OK = 0;
        public static readonly int STATUS_ERROR = 0xff;

        public static Result sendCloudCommand(Command command)
        {
            return sendMqttCommandByHttp("cloud/v2/cmd", command);
        }

        public static Result sendVideoCommand(Command command)
        {
            return sendMqttCommandByHttp("video/v2/cmd", command);
        }

        private static Result sendMqttCommandByHttp(String topic, Command command)
        {

            String payload = genPayload(command);

            WebRequest httpWebRequest = null;

            // 设置守望点命令单独处理，应对周期性突发事件
            if(command.type == CType.SET_LOOK_POINT)
            {
                httpWebRequest = obtainWebRequest(MQTT_AGENT_URL_V2);
            } else
            {
                httpWebRequest = obtainWebRequest(MQTT_AGENT_URL);
            }

            return sendMqttCommandByHttp(topic,  payload, httpWebRequest);

        }

        private static Result sendMqttCommandByHttp(String topic, String payload, WebRequest httpWebRequest)
        {

            if(httpWebRequest==null)
            {
                return new Result(STATUS_ERROR, "httpWebRequest is null!\n");
            }

            Result result = new Result(STATUS_OK, "oK");

            try
            {
                string value = String.Format("topic={0}&payload={1}", topic, payload);
                byte[] data = Encoding.ASCII.GetBytes(value);


                Stream stream = httpWebRequest.GetRequestStream();
                stream.Write(data, 0, data.Length);


                WebResponse response = (WebResponse)httpWebRequest.GetResponse();
                stream = response.GetResponseStream();
                StreamReader sr = new StreamReader(stream, Encoding.UTF8);

                String ss = sr.ReadToEnd();

                stream.Close();
                sr.Close();

                if (ss != null)
                {
                    // result = (Result)JsonConvert.DeserializeObject(ss);
                    result.message = ss;
                }

            }
            catch (Exception e)
            {
                result.status = STATUS_ERROR;
                result.message = e.ToString();
            }

            return result;
        }

        private static string genPayload(Command command)
        {
            DataTable dt = new DataTable();
            
            dt.Columns.Add("type", Type.GetType("System.Int32"));
            dt.Columns.Add("value", command.isValueUseInt ? Type.GetType("System.Int32") : Type.GetType("System.String"));
            dt.Columns.Add("status", command.isStatusUseInt ? Type.GetType("System.Int32") : Type.GetType("System.String"));

            dt.Rows.Add(new object[] { command.type, command.value, command.status });

            List<SendData> list = new List<SendData>
            {
                new SendData(command.mac, dt)
            };

            return Newtonsoft.Json.JsonConvert.SerializeObject(list);
        }

        private static WebRequest obtainWebRequest(String url)
        {
            WebRequest webRequest = null;
            if (url != null)
            {
                webRequest = (WebRequest)WebRequest.Create(url);
                webRequest.Method = "POST";
                webRequest.ContentType = "application/x-www-form-urlencoded";
            }
            return webRequest;
        }

        #endregion

    }

    #endregion

    #region 数据结构定义

    public struct Command
    {
        public string mac;
        public string code;
        public string value;
        public string status;

        private readonly CType _type;
        private string _message;
        private bool _isCloudCommand;
        private bool _isStatusUseInt;
        private bool _isValueUseInt;

        public Command(CType type, string message, bool isCloudCommand)
        {
            this.mac = null;
            this.code = null;
            this.value = "";
            this.status = "";
            this._type = type;
            this._message = message;
            this._isCloudCommand = isCloudCommand;
            this._isStatusUseInt = false;
            this._isValueUseInt = false;
        }

        public CType type
        {
            get { return this._type; }
        }

        public string message
        {
            get { return this._message; }
        }

        public bool isCloudCommand
        {
            get { return this._isCloudCommand; }
        }

        public bool isStatusUseInt
        {
            get { return this._isStatusUseInt; }
            set { this._isStatusUseInt = value; }
        }

        public bool isValueUseInt
        {
            get { return this._isValueUseInt; }
            set { this._isValueUseInt = value; }
        }
    }

    public class Result
    {

        private int _status;
        private string _message;

        public Result(int status, string message)
        {
            _status = status;
            _message = message;
        }

        public int status
        {
            get { return this._status; }
            set { this._status = value; }
        }

        public string message
        {
            get { return this._message; }
            set { this._message = value; }
        }

    }

    public class SendData
    {
        private string _deviceId;
        private DataTable _data;

        public SendData(string deviceId, DataTable data)
        {
            this._deviceId = deviceId;
            this._data = data;
        }

        public string deviceId
        {
            get { return this._deviceId; }
            set { this._deviceId = value; }
        }

        public DataTable data
        {
            get { return this._data; }
            set { this._data = value; }
        }
    }

    #endregion

}