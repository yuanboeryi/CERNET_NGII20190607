﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Collections;

namespace imfraredservices.ConfigTool
{

    public class PresetPoint
    {
        private String _name;
        private Boolean _isAdd;
        private DataTable _deviceList;

        public String name
        {
            get { return this._name; }
            set { this._name = value; }
        }

        public Boolean isAdd
        {
            get { return this._isAdd; }
            set { this._isAdd = value; }
        }

       public DataTable deviceList
       {
            get { return this._deviceList; }
            set { this._deviceList = value; }
       }

    }

    public class MediaAddress
    {
        private string name;
        private string value;

        public MediaAddress() 
        {
            this.name = "缺省";
            this.value = "0";
        }

        public string Name
        {
            get { return name; }
            set { this.name = value; }
        }

        public string Value
        {
            get { return value; }
            set { this.value = value; }
        }

    }

    public class Video
    {
        private string hasVideo;
        private ArrayList ir;
        private ArrayList high;

        public Video()
        {
            this.hasVideo = "0";
            this.ir = new ArrayList();
            this.high = new ArrayList();
        }


        public string HasVideo {
            get { return hasVideo; }
            set { hasVideo = value; }
        }

        public ArrayList Ir {
            get { return ir; }
            set { ir = value; }
        }



//        public string HasVideo { get => hasVideo; set => hasVideo = value; }

//        public ArrayList Ir { get => ir; set => ir = value; }

 //       public ArrayList High { get => high; set => high = value; }
         public ArrayList High {
            set{ high = value; }
            get{return high;}

        }
    }

    public class device_config_infor
    {
        string areaid = "";
        string areaname = "";
        string fenbuid = "";
        string fenbuname = "";
        string ywbid = "";
        string ywbname = "";
        string stationid = "";
        string stationname = "";
        string buildingid = "";
        string buildingname = "";
        string deviceid = "";
        string devicename = "";
        string ysdid = "";
        string ysdname = "";
        string machineid = "";
        string machinename = "";
        string machinemac = "";
        string machinecode = "";
        string machineip = "";
        string wifiname = "";
        string wifipass = "";
        string red_video_infor = "";
        string high_video_infor = "";
        string cloudaddr = "";
        string fushelv = "";
        string filepath = "";
        string rong_S = "";
        string rong_R = "";
        string rong_L = "";
        string rong_T = "";
        string hongwai_cx = "";
        string bianyuan_cx = "";
        string alarmvalue = "";
        string point_ysd_index = "";
        string catch_span = "";
        string xunshi_span = "";
        string image1 = "";
        string returnvalue = "";
        public string returnValue
        {
            get { return returnvalue; }
            set { returnvalue = value; }
        }

        Video video = null;
        //       public Video Video { get => video; set => video = value; }
        public Video Video {
            set { video = value; }
            get { return video; }

        }

        public string Image1
        {
            get { return image1; }
            set { image1 = value; }
        }
        string image2 = "";

        public string Image2
        {
            get { return image2; }
            set { image2 = value; }
        }
        public string Areaid
        {
            get { return areaid; }
            set { areaid = value; }
        }
        public string Areaname
        {
            get { return areaname; }
            set { areaname = value; }
        }
        public string Fenbuid
        {
            get { return fenbuid; }
            set { fenbuid = value; }
        }
        public string Ywbid
        {
            get { return ywbid; }
            set { ywbid = value; }
        }
        public string Fenbuname
        {
            get { return fenbuname; }
            set { fenbuname = value; }
        }
        public string Ywbname
        {
            get { return ywbname; }
            set { ywbname = value; }
        }
        public string Stationid
        {
            get { return stationid; }
            set { stationid = value; }
        }
        public string Stationname
        {
            get { return stationname; }
            set { stationname = value; }
        }

        public string Buildingid
        {
            get { return buildingid; }
            set { buildingid = value; }
        }

        public string Buildingname
        {
            get { return buildingname; }
            set { buildingname = value; }
        }

        public string Deviceid
        {
            get { return deviceid; }
            set { deviceid = value; }
        }


        public string Devicename
        {
            get { return devicename; }
            set { devicename = value; }
        }

        public string Ysdid
        {
            get { return ysdid; }
            set { ysdid = value; }
        }

        public string Ysdname
        {
            get { return ysdname; }
            set { ysdname = value; }
        }

        public string Machineid
        {
            get { return machineid; }
            set { machineid = value; }
        }

        public string Machinename
        {
            get { return machinename; }
            set { machinename = value; }
        }

        public string Machinemac
        {
            get { return machinemac; }
            set { machinemac = value; }
        }

        public string Machinecode
        {
            get { return machinecode; }
            set { machinecode = value; }
        }

        public string Machineip
        {
            get { return machineip; }
            set { machineip = value; }
        }

        public string Wifiname
        {
            get { return wifiname; }
            set { wifiname = value; }
        }

        public string Wifipass
        {
            get { return wifipass; }
            set { wifipass = value; }
        }

        public string Red_video_infor
        {
            get { return red_video_infor; }
            set { red_video_infor = value; }
        }

        public string High_video_infor
        {
            get { return high_video_infor; }
            set { high_video_infor = value; }
        }

        public string Cloudaddr
        {
            get { return cloudaddr; }
            set { cloudaddr = value; }
        }

        public string Fushelv
        {
            get { return fushelv; }
            set { fushelv = value; }
        }

        public string Filepath
        {
            get { return filepath; }
            set { filepath = value; }
        }

        public string Rong_S
        {
            get { return rong_S; }
            set { rong_S = value; }
        }

        public string Rong_R
        {
            get { return rong_R; }
            set { rong_R = value; }
        }

        public string Rong_L
        {
            get { return rong_L; }
            set { rong_L = value; }
        }

        public string Rong_T
        {
            get { return rong_T; }
            set { rong_T = value; }
        }

        public string Hongwai_cx
        {
            get { return hongwai_cx; }
            set { hongwai_cx = value; }
        }

        public string Bianyuan_cx
        {
            get { return bianyuan_cx; }
            set { bianyuan_cx = value; }
        }

        public string Alarmvalue
        {
            get { return alarmvalue; }
            set { alarmvalue = value; }
        }

        public string Point_ysd_index
        {
            get { return point_ysd_index; }
            set { point_ysd_index = value; }
        }

        public string Catch_span
        {
            get { return catch_span; }
            set { catch_span = value; }
        }


        public string Xunshi_span
        {
            get { return xunshi_span; }
            set { xunshi_span = value; }
        }
        DataTable imagelist = new DataTable();

        public DataTable Imagelist
        {
            get { return imagelist; }
            set { imagelist = value; }
        }
        DataTable devicelist = new DataTable();

        public DataTable Devicelist
        {
            get { return devicelist; }
            set { devicelist = value; }
        }
        DataTable ysdlist = new DataTable();

        public DataTable Ysdlist
        {
            get { return ysdlist; }
            set { ysdlist = value; }
        }
        DataTable rectlist = new DataTable();

        public DataTable Rectlist
        {
            get { return rectlist; }
            set { rectlist = value; }
        }

    }
}