﻿using HslCommunication;
using HslCommunication.MQTT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.ConfigTool
{
    public class mqttCommunication
    {
        private MqttClient mqttClient= null;

        public void updateMqtt()
        {
             mqttClient = new MqttClient(new MqttConnectionOptions()
            {
                Port = 61613,
                ClientId = "148服务器",
                IpAddress = "122.114.204.83",
                 Credentials = new MqttCredential( "admin", "password" )   // 设置了用户名和密码
            });
            mqttClient.OnMqttMessageReceived += MqttClient_OnMqttMessageReceived; // 调用一次即可
        }

        public string connectServer()
        {
             OperateResult connect = mqttClient.ConnectServer();
            
            if (connect.IsSuccess)
            {
               return ("1");
            }
            else
            {
                return ("0");
            }
        }

        private void MqttClient_OnMqttMessageReceived(string topic, byte[] payload)
        {
            // 跨线程更新了UI界面的内容
            string sx = (System.Text.Encoding.Default.GetString(payload));
        }

        public void sendMsg_Cloud(string machinemac,int type,string value,string status)
        {
            updateMqtt();
            connectServer();
            List<msgjson> jsonlist = new List<msgjson>();
            DataTable dt = new DataTable();
            dt.Columns.Add("type", Type.GetType("System.Int32"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("status", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { type, value, status });
            msgjson json = new msgjson();
            json.deviceId = machinemac;
            json.data = dt;
            jsonlist.Add(json);
            string jsonstr = Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
            mqttClient.PublishMessage(new MqttApplicationMessage()
            {
                Topic = "cloud/v2/cmd",                                           // 主题
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,     // 消息等级
                Payload = System.Text.Encoding.ASCII.GetBytes(jsonstr),           // 数据
                Retain = false,                                                   // 是否保留
            });
        }

        public void sendMsg_Video(string machinemac, int type, string value, string status)
        {
            updateMqtt();
            connectServer();
            List<msgjson> jsonlist = new List<msgjson>();
            DataTable dt = new DataTable();
            dt.Columns.Add("type", Type.GetType("System.Int32"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("status", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { type, value, status });
            msgjson json = new msgjson();
            json.deviceId = machinemac;
            json.data = dt;
            jsonlist.Add(json);
            string jsonstr = Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
            mqttClient.PublishMessage(new MqttApplicationMessage()
            {
                Topic = "video/v2/cmd",                                           // 视频控制用该主题 by King-1025
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,     // 消息等级
                Payload = System.Text.Encoding.ASCII.GetBytes(jsonstr),           // 数据
                Retain = false,                                                   // 是否保留
            });
        }

        #region 进制转换
        public static string GetHexFromChs(string s)
        {
            if ((s.Length % 2) != 0)
            {
                s += " ";//空格
                //throw new ArgumentException("s is not valid chinese string!");
            }

            System.Text.Encoding chs = System.Text.Encoding.GetEncoding("gb2312");

            byte[] bytes = chs.GetBytes(s);

            string str = "";

            for (int i = 0; i < bytes.Length; i++)
            {
                str += string.Format("{0:X}", bytes[i]);
            }

            return str;
        }
        #endregion

    }
}