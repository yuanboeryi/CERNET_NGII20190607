﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.ConfigTool
{
    public class msgjson
    {
        string _deviceId = "";

        public string deviceId
        {
            get { return _deviceId; }
            set { _deviceId = value; }
        }
        DataTable _data = new DataTable();

        public DataTable data
        {
            get { return _data; }
            set { _data = value; }
        }
    }
}