﻿using FluentScheduler;
using imfraredservices.HelperServer;
using imfraredservices.TimerServer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace imfraredservices
{

    /// <summary>
    /// 全局控制类
    /// </summary>
    public class Global : System.Web.HttpApplication
    {
        /// <summary>
        /// 程序启动
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static System.Timers.Timer MonthTime = null;
        private void Application_Start(object sender, EventArgs e)
        {
            TimerServerCopy.Start();
        }

        protected void Application_End(object sender, EventArgs e)
        {
            WriteLog("进程即将被IIS回收" + DateTime.Now);
            WriteLog("重新访问一个页面,以唤醒服务" + DateTime.Now);
            string strURL = System.Configuration.ConfigurationManager.AppSettings["homeURL"].ToString();
            try
            {
                System.Net.WebClient wc = new System.Net.WebClient();
                System.IO.Stream stream = wc.OpenRead(strURL);
                System.IO.StreamReader reader = new StreamReader(stream);
                string html = reader.ReadToEnd();
                if (!string.IsNullOrWhiteSpace(html))
                {
                    WriteLog("唤醒成功");
                }
                reader.Close();
                reader.Dispose();
                stream.Close();
                stream.Dispose();
                wc.Dispose();
            }
            catch (Exception ex)
            {
                WriteLog("唤醒异常");
                 //HttpHelperServer.CreateTxt("Application_End", "", "唤醒异常");
            }
        }
        public void WriteLog(string str)
        {
            System.IO.StreamWriter writer = null;
            try
            {
                //写入日志 
                string path = string.Empty;
                path = @"D:\ErrorLogs\";
                //不存在则创建错误日志文件夹
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                path += string.Format(@"\{0}.txt", "唤醒应用程序");

                writer = !System.IO.File.Exists(path) ? System.IO.File.CreateText(path) : System.IO.File.AppendText(path); //判断文件是否存在，如果不存在则创建，存在则添加
                writer.WriteLine(str);
                writer.WriteLine("********************************************************************************************");
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
        }
    }
}