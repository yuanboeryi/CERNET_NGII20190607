﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace imfraredservices.HelperServer
{
    public class HttpHelperServer
    {

        public static void CreateTxt(string Action,string UserId,string CreateLog)
        {
            string Path = @"D:\CreateLogHelp\";
            if (Directory.Exists(Path)==false)
            {
                Directory.CreateDirectory(Path);
            }
            // 防止产生过多的Log文件
            string TxtName = "CreateTimeLog.txt";
            string ResultPath = Path + TxtName;
            if (File.Exists(ResultPath)==false)
            {
                File.Create(ResultPath).Close();
            }
            // 写入文件
            using (StreamWriter sw=new StreamWriter(ResultPath,true))
            {
                // 写入时间
                string DataTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                // 创建写入内容,
                string CreateResultLog = "当前时间:" + DataTime + "执行方法:" + Action + "当前登录人:" + UserId+"->>>>>"+CreateLog;
                sw.WriteLine(CreateResultLog);
            }
        }
    }
}