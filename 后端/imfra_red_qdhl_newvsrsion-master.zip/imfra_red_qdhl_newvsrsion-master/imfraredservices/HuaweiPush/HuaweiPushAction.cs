﻿using imfraredservices.JXHService.LoginService;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace imfraredservices.HuaweiPush
{
    public class HuaweiPushAction
    {

        private static string appSecret = "05ea081eac3d618f93ce6fb9c2210c65";
        private static string appId = "100524667";// 用户在华为开发者联盟申请的appId和appSecret（会员中心->我的产品，点击产品对应的Push服务，点击“移动应用详情”获取）
        private static string tokenUrl = "https://login.cloud.huawei.com/oauth2/v2/token"; // 获取认证Token的URL
        private static string apiUrl = "https://api.push.hicloud.com/pushsend.do"; // 应用级消息下发API
        private static string PostUrlWithAppId = @"https://push-api.cloud.huawei.com/v1/"+appId+"/messages:send";
        private static int Count=0;
        private static string accessToken;// 下发通知消息的认证Token
        private static long tokenExpiredTime; // accessToken的过期时间
        Dictionary<string, List<string>> DicPostList = new Dictionary<string, List<string>>();
        // 获取下发通知消息的认证Token
        private void refreshToken()
        {

            string msgBody = String.Format("grant_type=client_credentials&client_secret={0}&client_id={1}",
                    HttpUtility.UrlEncode(appSecret, Encoding.UTF8), appId);
            string response = PostMessage(tokenUrl, msgBody);
            JObject jo = (JObject)JsonConvert.DeserializeObject(response);
            accessToken = jo["access_token"].ToString();
            tokenExpiredTime = System.DateTime.Now.Ticks + 10 * 1000;

        }
        public string get_uft8(string unicodeString)
        {
            UTF8Encoding utf8 = new UTF8Encoding();
            Byte[] encodedBytes = utf8.GetBytes(unicodeString);
            string decodedString = utf8.GetString(encodedBytes);
            return decodedString;
        }

        
        /// <summary>
        /// 高温告警推送
        /// </summary>
        /// <param name="areaname"></param>
        /// <param name="stationname"></param>
        /// <param name="buildingname"></param>
        /// <param name="machinename"></param>
        /// <param name="devicename"></param>
        /// <param name="alarmvalue"></param>
        /// <param name="time"></param>
        /// <param name="alarmid"></param>
        /// <param name="machinecode"></param>
        public void sendPushMessageAlarm(string areaname,string stationname,string buildingname,string machinename,string devicename,string alarmvalue,string time, string alarmid, string machinecode,string SelectIsPush, string userid)
        {


            //   写入文件的Log, 进入的次数
            int Inter = Count += 1;
            //进入的名称 stationname ,当前要推送的哪个变电站, 当前登录人的areaname, 当前是否进行了推送
            Maticsoft.BLL.alarm_push_infor BLLAlarm = new Maticsoft.BLL.alarm_push_infor();
            Maticsoft.DAL.alarm_push_infor DAlAlarm = new Maticsoft.DAL.alarm_push_infor(); // 获取当前的Push 是否进行了推送
            var ModelAlarm=BLLAlarm.GetModel(alarmid);
            string IsPush = "";
            if (ModelAlarm!=null)
            {
                // 如果等于1,说明已经推送 , 同时获取当前的Id
                IsPush = ModelAlarm.IsPush;
            }
            string Result = "当前的AlarmId=" + alarmid + "当前是否已经推送(重新获取的IsPush):" + IsPush + "当前的时间:" + DateTime.Now.ToString("yyyy-MM-dd")+"进入当前方法的次数:"+Count+"传递过来的IsPush="+ SelectIsPush+ "当前推送的areaname(登录人):"+areaname+"当前推送的温度:"+ alarmvalue+"当前登录用户:"+userid;
            WriteLog(Result);















            //refreshToken();
            // 获取最新的Token
            refreshNewToken();
            List<string> deviceTokens = new List<string>();
            Maticsoft.BLL.push_token_infor tokenservice = new Maticsoft.BLL.push_token_infor();
            List<Maticsoft.Model.push_token_infor> tokenlist = new List<Maticsoft.Model.push_token_infor>();
            tokenlist = tokenservice.GetModelList("tokenname='" + areaname + "'");

            if (tokenlist.Count() <= 0)
                return;

            tokenlist.ForEach(m =>
            {
                // 添加一条信息tokenvalue
                if (!deviceTokens.Contains(m.tokenvalue))
                {
                    deviceTokens.Add(m.tokenvalue);
                }
            });
           
            // 设置TiTle
            string Title = "高温预警";
            // Body
            string Body = alarmvalue + "℃ " + stationname + " " + devicename + "时间:" + time;
            //intent 定义跳转的页面
            //获取定义的id machinecode,machinename
            var id= alarmid;
            var code = machinecode;
            var name = machinename;
            string intent = "intent://com.smart.hongwaichengxiang/deeplink?#Intent;scheme=pushscheme;launchFlags=0x4000000;S.content=1;"+"S.id="+ HttpUtility.UrlEncode(alarmid) +";"+ "S.machinecode="+ HttpUtility.UrlEncode(machinecode) +";"+ "S.machinename="+ HttpUtility.UrlEncode(machinename)+";"+ "end";

            // 获取推送消息需要用到的参数, 传入 title bod以及intent,deviceTokens
            string RequestBody =RequestParameters(Title,Body,intent, deviceTokens);
            if (RequestBody=="0")
            {
                return;
            }
            // 通过Http请求,进行推送华为服务
             string HttpCode= ApiHttpPost(PostUrlWithAppId, RequestBody);

            int a = 20;
            #region 弃用之前的调用华为推送服务
            //JObject JBody = new JObject();
            //string message = alarmvalue + "℃ " + stationname + " " + devicename + "时间:" + time;
            //JObject body = new JObject();// 仅通知栏消息需要设置标题和内容，透传消息key和value为用户自定义
            //body.Add("title", "！高温告警");
            //body.Add("content", message);
            //JObject param = new JObject();
            //param.Add("appPkgName", "com.smart.hongwaichengxiang");// 定义需要打开的appPkgName
            //JObject action = new JObject();
            //action.Add("type", 3);//类型3为打开APP，其他行为请参考接口文档设置
            //action.Add("param", param);// 消息点击动作参数
            //JObject msg = new JObject();
            //msg.Add("type", 3);// 3: 通知栏消息，异步透传消息请根据接口文档设置
            //msg.Add("action", action);// 消息点击动作
            //msg.Add("body", body);// 通知栏消息body内容
            //JObject ext = new JObject();// 扩展信息，含BI消息统计，特定展示风格，消息折叠。
            //ext.Add("biTag", "Trump");// 设置消息标签，如果带了这个标签，会在回执中推送给CP用于检测某种类型消息的到达率和状态
            //ext.Add("icon", "");// 自定义推送消息在通知栏的图标,value为一个公网可以访问的URL
            //JObject hps = new JObject();// 华为PUSH消息总结构体
            //hps.Add("msg", msg);
            //hps.Add("ext", ext);
            //JObject payload = new JObject();
            //payload.Add("hps", hps);
            //String postBody = String.Format(
            //          "access_token={0}&nsp_svc={1}&nsp_ts={2}&device_token_list={3}&payload={4}",
            //           HttpUtility.UrlEncode(accessToken, Encoding.UTF8), HttpUtility.UrlEncode("openpush.message.api.send", Encoding.UTF8),
            //            HttpUtility.UrlEncode((System.DateTime.Now.Ticks / 1000).ToString(), Encoding.UTF8),
            //            HttpUtility.UrlEncode(deviceTokens.ToString(), Encoding.UTF8), HttpUtility.UrlEncode(payload.ToString(), Encoding.UTF8));
            //String postUrl = apiUrl + "?nsp_ctx="
            //        + HttpUtility.UrlEncode("{\"ver\":\"1\", \"appId\":\"" + appId + "\"}", Encoding.UTF8);
            //PostMessage(Url, PushMessage);
            #endregion


        }

        /// <summary>
        /// 获取授权
        /// </summary>
        private void refreshNewToken()
        {
            string PostData = "grant_type=client_credentials&client_secret="+appSecret+ "&client_id="+ appId;
            var GetReturnMessage=HttpPost(tokenUrl,PostData);
            var jo = (JObject)JsonConvert.DeserializeObject(GetReturnMessage);
            accessToken = jo["access_token"].ToString();
        }

        public void getAlarmPush(string userid, string newesttime)
        {
            Maticsoft.BLL.machine_infor BllMachine = new Maticsoft.BLL.machine_infor();
            if (userid != "")
            {
                string time = DateTime.Now.ToString("yyyy-MM-dd");
                DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                //dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                //time = Convert.ToDateTime(newesttime, dtFormat);
                //time = time.AddMilliseconds(15);
                Maticsoft.BLL.alarm_push_infor bllservice = new Maticsoft.BLL.alarm_push_infor();
                DataSet ds = new DataSet();
                Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
                Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
                usermodel = user.GetModel(userid);
                string isread = "1";
                string target = "";
                if (usermodel != null)
                {
                    if (usermodel.usertype == "0")
                    {
                        ds = bllservice.GetList("areaid='" + usermodel.areaid + "' and isread='" + isread + "' group by createtime order by createtime desc");
                        target = "";
                    }
                    if (usermodel.usertype == "1")
                    {
                        ds = bllservice.GetList("fenbuid='" + usermodel.fenbuid + "' and isread='" + isread + "' group by createtime  order by createtime desc");
                        target = usermodel.areaid;
                    }
                    if (usermodel.usertype == "2")
                    {
                        ds = bllservice.GetList("ywbid='" + usermodel.ywbid + "' and isread='" + isread + "' group by createtime order by createtime desc");
                        target = usermodel.fenbuid;

                    }
                    if (usermodel.usertype == "3")
                    {
                        ds = bllservice.GetList("   isread='" + isread + "' and createtime>'" + time + "'  group by createtime");
                        target = usermodel.ywbid;

                    }
                    string stime = "";
                    if (ds.Tables[0].Rows.Count > 0)
                        stime = ds.Tables[0].Rows[0]["createtime"].ToString();
                    else
                        return;

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string sid = ds.Tables[0].Rows[i]["id"].ToString();
                        string deviceid = ds.Tables[0].Rows[i]["deviceid"].ToString();
                        string devicename = ds.Tables[0].Rows[i]["devicename"].ToString();
                        string ywbname = ds.Tables[0].Rows[i]["ywbname"].ToString();
                        string fenbuname = ds.Tables[0].Rows[i]["fenbuname"].ToString();
                        string stationname = ds.Tables[0].Rows[i]["stationname"].ToString();
                        string buildingname = ds.Tables[0].Rows[i]["buildingname"].ToString();
                        string areaname = ds.Tables[0].Rows[i]["areaname"].ToString();
                        string machinename = ds.Tables[0].Rows[i]["machinename"].ToString();
                        string ysdname = ds.Tables[0].Rows[i]["ysdname"].ToString();
                        string alarmvalue = ds.Tables[0].Rows[i]["alarmvalue"].ToString();
                        string overvalue = ds.Tables[0].Rows[i]["overvalue"].ToString();
                        string isok = ds.Tables[0].Rows[i]["isok"].ToString();
                        string createtime = ds.Tables[0].Rows[i]["createtime"].ToString();
                        string isread1 = ds.Tables[0].Rows[i]["isread"].ToString();

                        // 是否已经推送
                        string IsPush = ds.Tables[0].Rows[i]["IsPush"].ToString();
                        string machineid = ds.Tables[0].Rows[i]["machineid"].ToString();
                        var ModelMachine = BllMachine.GetModel(machineid);
                        if (ModelMachine != null)
                        {
                            // 已经推送
                            if (IsPush == "1")
                            {

                                //sendPushMessageAlarm(areaname, stationname, buildingname, machinename, devicename, alarmvalue, createtime, sid, ModelMachine.machinecode);
                                continue;
                            }
                            else
                            {
                                // 当前的登录人是admin 并且推送的消息是河南省检修公司和郑州供电公司 重新设置areaname=admin
                                if (usermodel.usertype=="3")
                                {
                                    if (areaname.Contains("河南省检修公司")||areaname.Contains("郑州供电公司"))
                                    {
                                        areaname = usermodel.username;
                                        sendPushMessageAlarm(areaname, stationname, buildingname, machinename, devicename, alarmvalue, createtime, sid, ModelMachine.machinecode,IsPush, userid);
                                    }
                                }
                                else
                                {
                                    // 调用推送设置
                                    sendPushMessageAlarm(areaname, stationname, buildingname, machinename, devicename, alarmvalue, createtime, sid, ModelMachine.machinecode,IsPush, userid);
                                }
                                // 推送完成设置为已经推送
                                bllservice.UpdateIsPush(sid);
                                bllservice.Updateisread(sid);
                            }

                        }

                    }
                }
            }
        }
        /// <summary>
        /// 温升告警推送
        /// </summary>
        /// <param name="areaname"></param>
        /// <param name="stationname"></param>
        /// <param name="buildingname"></param>
        /// <param name="machinename"></param>
        /// <param name="devicename"></param>
        /// <param name="alarmvalue"></param>
        /// <param name="time"></param>
        public void sendPushMessageOver(string areaname, string stationname, string buildingname, string machinename, string devicename, string alarmvalue, string time,string IsSwitchCabinet)
        {
            refreshToken();
            JArray deviceTokens = new JArray();// 目标设备Token

            Maticsoft.BLL.push_token_infor tokenservice = new Maticsoft.BLL.push_token_infor();
            List<Maticsoft.Model.push_token_infor> tokenlist = new List<Maticsoft.Model.push_token_infor>();
            tokenlist = tokenservice.GetModelList("tokenname='" + areaname + "'");//此处暂时修改为向所有手机推消息 areaname='" + areaname + "'
            if (tokenlist.Count() <= 0)
                return;
            for (int i = 0; i < tokenlist.Count(); i++)
            {
                deviceTokens.Add(tokenlist[i].tokenvalue);

            }
            string message = alarmvalue + "℃ " + stationname + " " + devicename + "时间:" + time;
            JObject body = new JObject();// 仅通知栏消息需要设置标题和内容，透传消息key和value为用户自定义
            if (IsSwitchCabinet=="")
            {
                body.Add("title", "！温升超20℃");
            }else
            {
                body.Add("title", "！开关柜温升超10℃");
            }
            body.Add("content", message);
            JObject param = new JObject();
            param.Add("appPkgName", "com.smart.hongwaichengxiang");// 定义需要打开的appPkgName
            JObject action = new JObject();
            action.Add("type", 3);// 类型3为打开APP，其他行为请参考接口文档设置
            action.Add("param", param);// 消息点击动作参数
            JObject msg = new JObject();
            msg.Add("type", 3);// 3: 通知栏消息，异步透传消息请根据接口文档设置
            msg.Add("action", action);// 消息点击动作
            msg.Add("body", body);// 通知栏消息body内容
            JObject ext = new JObject();// 扩展信息，含BI消息统计，特定展示风格，消息折叠。
            ext.Add("biTag", "Trump");// 设置消息标签，如果带了这个标签，会在回执中推送给CP用于检测某种类型消息的到达率和状态
            ext.Add("icon", "");// 自定义推送消息在通知栏的图标,value为一个公网可以访问的URL
            JObject hps = new JObject();// 华为PUSH消息总结构体
            hps.Add("msg", msg);
            hps.Add("ext", ext);
            JObject payload = new JObject();
            payload.Add("hps", hps);
            String postBody = String.Format(
                      "access_token={0}&nsp_svc={1}&nsp_ts={2}&device_token_list={3}&payload={4}",
                       HttpUtility.UrlEncode(accessToken, Encoding.UTF8), HttpUtility.UrlEncode("openpush.message.api.send", Encoding.UTF8),
                        HttpUtility.UrlEncode((System.DateTime.Now.Ticks / 1000).ToString(), Encoding.UTF8),
                        HttpUtility.UrlEncode(deviceTokens.ToString(), Encoding.UTF8), HttpUtility.UrlEncode(payload.ToString(), Encoding.UTF8));
            String postUrl = apiUrl + "?nsp_ctx="
                    + HttpUtility.UrlEncode("{\"ver\":\"1\", \"appId\":\"" + appId + "\"}", Encoding.UTF8);
            PostMessage(postUrl, postBody);
        }
        public string PostMessage(string httpUrl, string body)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(httpUrl);

                request.Accept = "text/plain, */*; q=0.01";
                request.ContentType = "application/x-www-form-urlencoded; charset=UTF-8";
                //请求方式
                request.Method = "POST";
                request.KeepAlive = false;
                request.ContentLength = body.Length;
                Stream postStream = request.GetRequestStream();
                byte[] postData = Encoding.UTF8.GetBytes(body);
                postStream.Write(postData, 0, postData.Length);
                postStream.Dispose();
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream myResponseStream = response.GetResponseStream();
                StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
                string res = myStreamReader.ReadToEnd().ToString();
                return res;

            }
            catch (Exception e)
            {
                return e.ToString();
            }

        }
        /// <summary>
        ///  模拟HttpPost请求
        /// </summary>
        /// <param name="Url"></param>
        /// <param name="postDataStr"></param>
        /// <returns></returns>
        private string HttpPost(string Url, string postDataStr,string ContentType= "application/x-www-form-urlencoded")
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            request.Method = "POST";
            request.ContentType = ContentType;
            request.ContentLength = Encoding.UTF8.GetByteCount(postDataStr);
            Stream myRequestStream = request.GetRequestStream();
            StreamWriter myStreamWriter = new StreamWriter(myRequestStream, Encoding.GetEncoding("gb2312"));
            myStreamWriter.Write(postDataStr);
            myStreamWriter.Close();
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();

            return retString;
        }

        /// <summary>
        ///  防止传递参数为空
        /// </summary>
        /// <param name="id"></param>
        /// <param name="machinecode"></param>
        /// <param name="machinename"></param>
        /// <returns></returns>
        private string RequestParameters(string title,string body,string intent,List<string>token)
        {

            string Str = string.Empty;
            NotiFication fication = new NotiFication();
            Click_action click = new Click_action(intent, 1);
            AndroidNotiFicaTion androidNotiFicaTion = new AndroidNotiFicaTion(click);
            Android android = new Android(androidNotiFicaTion, -1);
            DataMessage message = new DataMessage(fication, android, token);
            fication.title = title;
            fication.body = body;
            PostPush push = new PostPush();
            push.message = message;
            push.validate_only = false;
            Str = JsonConvert.SerializeObject(push);
            return Str;
        }
        /// <summary>
        ///  推送华为消息
        /// </summary>
        /// <param name="Url"></param>
        /// <param name="postDataStr"></param>
        /// <param name="ContentType"></param>
        /// <returns></returns>
        public string ApiHttpPost(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            request.Accept = "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
            request.Headers["Accept-Language"] = "zh-CN,zh;q=0.";
            request.Headers["Accept-Charset"] = "GBK,utf-8;q=0.7,*;q=0.3";
            request.UserAgent = "User-Agent:Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.202 Safari/535.1";
            request.KeepAlive = true;
            request.Headers["Authorization"] = "Bearer " + accessToken;
            //上面的http头看情况而定，但是下面俩必须加  
            request.ContentType = "application/json";
            request.Method = "POST";

            Encoding encoding = Encoding.UTF8;//根据网站的编码自定义 
            byte[] postData = encoding.GetBytes(postDataStr);//postDataStr即为发送的数据，格式还是和上次说的一样  
            request.ContentLength = postData.Length;
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(postData, 0, postData.Length);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader streamReader = new StreamReader(responseStream, encoding);
            string retString = streamReader.ReadToEnd();

            streamReader.Close();
            responseStream.Close();
            return retString;
        }


        /// <summary>
        /// 捕获异常信息
        /// </summary>
        /// <returns></returns>
        public void WriteLog(string Result)
        {
            string path = @"D:\PushLog\";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string Time = DateTime.Now.ToString("yyyy-MM-dd");
            string PushLog = path + Time + ".txt";
            if (File.Exists(PushLog)==false)
            {
                File.Create(PushLog).Close();
            }


            // 进行追加
            using (StreamWriter sw=new StreamWriter(PushLog,true))
            {
                // 换行
                sw.WriteLine(Time+"#" +Result);
            }
        }
    }
}
