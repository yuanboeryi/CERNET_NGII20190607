﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace imfraredservices.HuaweiPush
{
    public class PushTimer
    {
        double iTimerInterval;
        System.Timers.Timer timer = new System.Timers.Timer();
        object objLock = new object();
        protected void Application_Start(object sender, EventArgs e)
        {
            //在应用程序启动时运行的代码
            //在新会话启动时运行的代码
            SetAccount();
            timer.Start();//定时器开始
        }

        protected void Application_End(object sender, EventArgs e)
        {
            timer.Stop();
        }

        private void SetAccount()
        {
            double.TryParse(ConfigurationManager.AppSettings["TimerInterval"], out iTimerInterval);
            timer.Interval = 2000;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(getMessage);
            //getMessage是个方法(略)
        }
        public void getMessage(object sender, EventArgs e)
        {

        }
    }
}