﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace imfraredservices.JXHService
{
    /// <summary>
    /// JyhService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class JyhService : System.Web.Services.WebService
    {
        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        //字符串转json
        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msgsend");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        [WebMethod(Description="接口描述：获取红外后台用户登录信息，传值：ywbname【运维班名称】,usertype[usertype='1'表示运维班权限，  usertype='0'表示超级管理员]")]
        public void getInfraRedUserInfor(string ywbname,string usertype)
        {
            string type = "1";
            if (usertype == "1")
                type = "2";
            if (usertype == "0")
                type = "3";
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            DataSet ds = new DataSet();
            ds = userservice.GetList("ywbname='"+ywbname+"' and usertype='"+type+"'");
            if(ds.Tables[0].Rows.Count>0)
            {
                httpsend(ToJson(ds.Tables[0]));
            }
        }



        [WebMethod(Description="接口描述：返回精益化所需红外后台的数据：传值ywbname【运维班名称】，ywbname=某某运维班(红外后台运维班名称：庆丰运维班，柳林运维班，牛砦运维班)，则返回一个温度值，   ywbname='' 则返回工区下所有变电站当前的温度信息，")]
        public void getInfraRedInfor(string ywbname)
        {
            if(ywbname=="")
            {
                string areaname = "郑州供电公司";
                Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
                List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
                stationlist = stationservice.GetModelList("areaname='"+areaname+"'");
                publicAction.getShortName pa = new publicAction.getShortName();
                DataTable dt = new DataTable();
                dt.Columns.Add("number", Type.GetType("System.String"));
                dt.Columns.Add("work_area_id", Type.GetType("System.String"));
                dt.Columns.Add("address", Type.GetType("System.String"));
                dt.Columns.Add("temper", Type.GetType("System.String"));
                dt.Columns.Add("op_id", Type.GetType("System.String"));
                dt.Columns.Add("isalarm", Type.GetType("System.String"));
                dt.Columns.Add("address1", Type.GetType("System.String"));
                dt.Columns.Add("address2", Type.GetType("System.String"));
                dt.Columns.Add("address3", Type.GetType("System.String"));
                dt.Columns.Add("topvalue", Type.GetType("System.String"));
                Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
                List<Maticsoft.Model.image_record_history> historymodellist = new List<Maticsoft.Model.image_record_history>();
                historymodellist = historyservice.GetModelList("areaname='" + areaname + "'");
                List<int> templist = new List<int>();
                for (int i = 0; i < historymodellist.Count(); i++)
                {
                    if (historymodellist[i].valuemax != "" && historymodellist[i].valuemax != null)
                    {
                        templist.Add((int)double.Parse(historymodellist[i].valuemax));
                    }
                }
               
                for (int i = 0; i < stationlist.Count(); i++)
                {
                    //删除没有设备的变电站 
                    Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                    int count = machineservice.GetRecordCount("stationid = '" + stationlist[i].stationid + "'");
                    int machinemac = machineservice.GetRecordCount("machinemac = '" + "' and stationid = '" + stationlist[i].stationid + "'");
                    if (machinemac == count)
                    {
                        continue;
                    }
                    string name1 = pa.getshortname(stationlist[i].stationid).Split(',')[0];
                    string name2 = pa.getshortname(stationlist[i].stationid).Split(',')[1];
                    string name3 = pa.getshortname(stationlist[i].stationid).Split(',')[2];
                    Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
                    List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
                    string isok = "1";
                    string isalarm = "0";
                    alarmlist = alarmservice.GetModelList("stationid = '" + stationlist[i].stationid + "'and createtime > '" + DateTime.Now.ToString("yyyy-MM-dd") + "'and isok='" + isok + "'");
                    if (alarmlist.Count > 0)
                    {
                        isalarm = "1";
                        stationlist[i].alarmcount = alarmlist.Count.ToString();
                    }
                    else
                    {
                        stationlist[i].alarmcount = "0";
                    }
                    //string isalarm = "0";
                    //if(stationlist[i].alarmcount!=""&&stationlist[i].alarmcount!=null)
                    //{
                    //    if (int.Parse(stationlist[i].alarmcount) > 0)
                    //        isalarm = "1";
                    //}
                    dt.Rows.Add(new object[] { stationlist[i].alarmcount,"1",stationlist[i].stationname,stationlist[i].topvalue,"1",isalarm,name1,name2,name3,templist.Max().ToString() });
                   
                }              
                httpsend(ToJson(dt));

            }
            else
            {
                Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
                List<Maticsoft.Model.image_record_history> historymodellist = new List<Maticsoft.Model.image_record_history>();
                historymodellist = historyservice.GetModelList("ywbname='"+ywbname+"'");
                List<int> templist = new List<int>();
                for(int i=0;i<historymodellist.Count();i++)
                {
                    if(historymodellist[i].valuemax!=""&&historymodellist[i].valuemax!=null)
                    {
                        templist.Add((int)double.Parse(historymodellist[i].valuemax));
                    }
                }
                DataTable dt = new DataTable();
                dt.Columns.Add("number", Type.GetType("System.String"));
                dt.Columns.Add("work_area_id", Type.GetType("System.String"));
                dt.Columns.Add("address", Type.GetType("System.String"));
                dt.Columns.Add("temper", Type.GetType("System.String"));
                dt.Columns.Add("op_id", Type.GetType("System.String"));
                dt.Columns.Add("isalarm", Type.GetType("System.String"));
                dt.Columns.Add("address1", Type.GetType("System.String"));
                dt.Columns.Add("address2", Type.GetType("System.String"));
                dt.Columns.Add("address3", Type.GetType("System.String"));
                dt.Columns.Add("topvalue", Type.GetType("System.String"));

                dt.Rows.Add(new object[] { "", "1", "", "", "1", "", "", "","", templist.Max().ToString() });

                httpsend(ToJson(dt));
                
            }

        }

    }
}
