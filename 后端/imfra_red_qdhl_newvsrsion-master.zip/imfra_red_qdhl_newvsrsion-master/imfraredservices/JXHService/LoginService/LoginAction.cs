﻿using imfraredservices.HuaweiPush;
using King.MqttSupport;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
namespace imfraredservices.LoginService
{
    public class LoginAction 
    {
        Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
        System.Timers.Timer timer = new System.Timers.Timer();
        System.Timers.Timer heartbeattimer = new System.Timers.Timer();
        public string login(string username,string password)
        {

            List<Maticsoft.Model.user_infor> userlist = new List<Maticsoft.Model.user_infor>();
            Maticsoft.Model.user_infor ModelUser = new Maticsoft.Model.user_infor();
            loginjson json = new loginjson();
                userlist = userservice.GetModelList("");
            bool ishave = false;
            for(int i=0;i<userlist.Count();i++)
            {
                if(userlist[i].username==username)
                {
                    ishave = true;

                    if(userlist[i].password==password)
                    {
                        json.State = "0";
                        json.Msg = "登录成功";
                        json.Areaid = userlist[i].areaid;
                        json.Areaname = userlist[i].areaname;
                        json.Fenbuid = userlist[i].fenbuid;
                        json.Fenbuname = userlist[i].fenbuname;
                        json.Ywbid = userlist[i].ywbid;
                        json.Ywbname = userlist[i].ywbname;
                        json.Userid = userlist[i].userid;
                        json.Username = userlist[i].username;
                        json.Usertype = userlist[i].usertype;
                        json.City = userlist[i].city;
                        ModelUser = userlist[i];
                    }
                    else
                    {
                        json.State = "1";
                        json.Msg = "密码错误";
                        json.Areaid = "";
                        json.Areaname = "";
                        json.Fenbuid = "";
                        json.Fenbuname = "";
                        json.Ywbid = "";
                        json.Ywbname = "";
                        json.Userid = "";
                        json.Username = "";
                        json.Usertype = "";
                    }
                    break;
                }
                
            }
            if(ishave==false)
            {
                json.State = "2";
                json.Msg = "用户不存在";
                json.Areaid = "";
                json.Areaname = "";
                json.Fenbuid = "";
                json.Fenbuname = "";
                json.Ywbid = "";
                json.Ywbname = "";
                json.Userid = "";
                json.Username = "";
                json.Usertype = "";
            }


            //getMessage(ModelUser);
            timer.Interval = 7000;
            timer.Elapsed += new System.Timers.ElapsedEventHandler((s, e) => getMessage(s, e, ModelUser));
            if (timer.Enabled == false)
                timer.Start();

            //设备15分钟测温实时更新定时器
            //heartbeattimer.Interval = 120000;
            heartbeattimer.Interval = 1200000; // 20分钟执行一次设备心跳数据
            // heartbeattimer.Interval = 3 * 1000; // 3s
            heartbeattimer.Elapsed += new System.Timers.ElapsedEventHandler(getDeviceHeartBeat); //到达时间的时候执行事件           
            heartbeattimer.Start();

            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }
        public void getMessage(object sender, EventArgs e, Maticsoft.Model.user_infor UserModel)
        {
            HuaweiPushAction aaa = new HuaweiPushAction();
            if (UserModel != null && UserModel.userid != null)
            {
                aaa.getAlarmPush(UserModel.userid, System.DateTime.Now.ToString());
            }
        }
        [WebMethod(Description = "接口描述：测试设置守望点")]
        public void getDeviceHeartBeat(object sender, EventArgs e)
        {
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            Maticsoft.BLL.device_heart_infor deviceheartservice = new Maticsoft.BLL.device_heart_infor();
            devicelist = deviceservice.GetModelList("");
            if (devicelist.Count>0)
            {
                foreach (var device in devicelist)
                {
                    if (device != null)//更新设备15分钟测温表
                    {
                        Maticsoft.Model.device_heart_infor deviceHeartModel = new Maticsoft.Model.device_heart_infor();
                        deviceHeartModel.id = Guid.NewGuid().ToString("N");
                        deviceHeartModel.deviceid = device.deviceid;
                        deviceHeartModel.devicename = device.devicename;
                        deviceHeartModel.areaid = device.areaid;
                        deviceHeartModel.areaname = device.areaname;
                        deviceHeartModel.fenbuid = device.fenbuid;
                        deviceHeartModel.fenbuname = device.fenbuname;
                        deviceHeartModel.ywbid = device.ywbid;
                        deviceHeartModel.ywbname = device.ywbname;
                        deviceHeartModel.stationid = device.stationid;
                        deviceHeartModel.stationname = device.stationname;
                        deviceHeartModel.buildingid = device.buildingid;
                        deviceHeartModel.buildingname = device.buildingname;
                        deviceHeartModel.machineid = device.machineid;
                        deviceHeartModel.machinename = device.machinename;
                        deviceHeartModel.ysdindex = device.ysdindex;
                        deviceHeartModel.ysdname = device.ysdname;
                        deviceHeartModel.operaterNumber = device.operaterNumber;
                        deviceHeartModel.ppavg = device.ppavg;
                        deviceHeartModel.ppcnt = device.ppcnt;
                        deviceHeartModel.ppmax = device.ppmax;
                        deviceHeartModel.ppmin = device.ppmin;
                        deviceHeartModel.createtime = device.pptime;
                        deviceheartservice.Add(deviceHeartModel);
                    }
                }
            }
            //设置守望点
            Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
            List<Maticsoft.Model.machine_infor> machinelist = machineService.GetModelList("");
            Maticsoft.BLL.ysd_infor ysdService = new Maticsoft.BLL.ysd_infor();
            if (machinelist.Count > 0)
            {
                //System.Diagnostics.Debug.WriteLine("machinelist===========" + machinelist.Count);
                for (int i = 0; i < machinelist.Count; i++)
                {
                    //System.Diagnostics.Debug.WriteLine("红外设备执行===========" + i + "================次");
                    if (machinelist[i] != null)//获取红外设备的所有预设点
                    {
                        double ppmaxMax = 0.0;//15分钟测温最大值
                        string deviceidmax = "";//15分钟测温最大值的设备id 
                        string machineid = machinelist[i].machineid;
                        List<Maticsoft.Model.ysd_infor> ysdlist = ysdService.GetModelList("machineid='" + machineid + "'");
                        if (ysdlist.Count > 0)
                        {
                            for (int j = 0; j < ysdlist.Count; j++)//获取预设点下的所有设备
                            {
                                if (ysdlist[j] != null)
                                {
                                    string ysdid = ysdlist[j].ysdid;
                                    List<Maticsoft.Model.device_infor> deviceModellist = deviceservice.GetModelList("ysdindex='" + ysdid + "'");
                                    if (deviceModellist.Count > 0)
                                    {
                                        List<double> ppmaxlist = new List<double>(); ppmaxlist.Add(0.0);
                                        List<string> deviceidlist = new List<string>(); deviceidlist.Add("");
                                        for (int k = 0; k < deviceModellist.Count; k++)//获取设备的15分钟测温值
                                        {
                                            if (deviceModellist[k] != null)
                                            {
                                                if (!string.IsNullOrEmpty(deviceModellist[k].ppmax)&&!string.IsNullOrWhiteSpace(deviceModellist[k].ppmax))
                                                {
                                                    ppmaxlist.Add(double.Parse(deviceModellist[k].ppmax));//15分钟测温值                                             
                                                    deviceidlist.Add(deviceModellist[k].deviceid);
                                                    //deviceModellist[k].isroundpoint = Convert.ToString(0);
                                                    //deviceservice.Update(deviceModellist[k]);
                                                }
                                                deviceservice.UpdateRound(deviceModellist[k].deviceid, "0");
                                            }
                                        }
                                        double ppmax = ppmaxlist.Max();//当前预设点下15分钟测温最大值
                                        if (ppmax >= ppmaxMax)//与上个预设点的最大值对比
                                        {
                                            ppmaxMax = ppmax;//替换最大值
                                            int Indexof = ppmaxlist.IndexOf(ppmaxMax);//当前预设点的最大下坐标
                                            deviceidmax = deviceidlist[Indexof];//当前预设点的15分钟测温最大值的设备id                                      
                                        }                                      
                                    }
                                }
                            }
                        }
                        if (deviceidmax != null && deviceidmax != "")//获取设备的machinecode
                        {
                            System.Diagnostics.Debug.WriteLine("守望点设置执行第==========" + i + "================次");
                            Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(deviceidmax);
                            if (devicemodel != null)
                            {
                                //修改数据库
                                deviceservice.UpdateRound(deviceidmax, "1");
                                //发送指令
                                Command command = new Command(CType.SET_LOOK_POINT, "设置守望点", true);
                                command.mac = machinelist[i].machinemac;
                                command.code = devicemodel.deviceid;
                                command.value = devicemodel.ysdname;
                                sendCommand(command);
                           }
                        }
                    }
                }
            }
        }

        public string loginout(string username)
        {
            loginjson json = new loginjson();

            json.State = "3";
            json.Msg = "用户登出";
            json.Areaid = "";
            json.Areaname = "";
            json.Fenbuid = "";
            json.Fenbuname = "";
            json.Ywbid = "";
            json.Ywbname = "";
            json.Userid = "";
            json.Username = "";
            json.Usertype = "";
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);

        }
        public DataTable loginApp(string username,string password)
        {
            DataTable dt = new DataTable();
            dt = userservice.GetList("username='" + username + "' and password='"+password+"'").Tables[0];
            return dt;
            
        }
        private void sendCommand(Command command)
        {
            if (command.type == CType.GO_UP ||
                command.type == CType.GO_DOWN ||
                command.type == CType.GO_LEFT ||
                command.type == CType.GO_RIGHT ||
                command.type == CType.GO_STOP)
            {
                command.value = "1500"; // 步进值
            }
            sendCommandByMQTT(command);        
        }      
        private Result sendCommandByMQTT(Command command)
        {

            Result result = new Result(MqttAgent.STATUS_ERROR, "mac is null!");

            string mac = parseMac(command.mac, command.code);

            if (mac != null)
            {
                command.mac = mac;

                if (command.isCloudCommand)
                {
                    result = MqttAgent.sendCloudCommand(command);
                }
                else
                {
                    result = MqttAgent.sendVideoCommand(command);
                }

            }

            return result;
        }
        private string parseMac(string mac, string code)
        {
            string tmpMac = mac;
            if (tmpMac == null || "".Equals(tmpMac))
            {
                if (code != null && !"".Equals(code))
                {
                    Maticsoft.BLL.machine_infor machineService = new Maticsoft.BLL.machine_infor();
                    tmpMac = machineService.getMacByCode(code);
                }
            }
            return tmpMac;
        }
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
    }
}