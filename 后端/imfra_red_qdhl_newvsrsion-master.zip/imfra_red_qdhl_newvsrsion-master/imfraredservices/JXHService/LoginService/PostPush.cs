﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// 定义推送消息需要用到的字段, 推送类 参考连接 https://developer.huawei.com/consumer/cn/doc/development/HMSCore-References-V5/https-send-api-0000001050986197-V5
/// 示例 https://developer.huawei.com/consumer/cn/doc/development/HMSCore-Guides-V5/rest-sample-code-0000001050040242-V5
/// 更多类型参考文档进行添加
/// </summary>
namespace imfraredservices.JXHService.LoginService
{
    /// <summary>
    /// 推送消息类
    /// </summary>
    public class PostPush
    {
        /// <summary>
        /// 控制当前是否为测试消息，测试消息只做格式合法性校验，不会推送给用户设备，取值如下：true：测试消息false：正式消息
        /// </summary>
        /// 

        public PostPush()
        {

        }
        // 构造
        public PostPush(DataMessage _message, bool _validate_only = false)
        {
            this.validate_only = false;
            this.message = message;
        }
        public bool validate_only { get; set; }
        /// <summary>
        /// 定义 message结构类
        /// </summary>
        public DataMessage message { get; set; }
    }


    public class DataMessage
    {
        /// <summary>
        ///  缺省构造
        /// </summary>
        public DataMessage()
        {

        }
        public DataMessage(NotiFication _fication, Android _android, List<string> _token)
        {
            this.notification = _fication;
            this.android = _android;
            this.token = _token;
        }
        public NotiFication notification { get; set; }

        public Android android { get; set; }

        public List<string> token { get; set; }
    }

    /// <summary>
    /// title 和body
    /// </summary>
    public class NotiFication
    {
        public NotiFication()
        {

        }
        public NotiFication(string _title, string _body)
        {
            this.title = _title;
            this.body = body;
        }
        public string title { get; set; }
        public string body { get; set; }
        // 如果需要添加图片,添加下面字段
        //string notify_icon

    }
    public class Android
    {
        public Android()
        {

        }
        public Android(AndroidNotiFicaTion _androidNotiFicaTion, int _collapse_key = -1)
        {
            this.notification = _androidNotiFicaTion;
            this.collapse_key = _collapse_key;
        }
        public int collapse_key { get; set; }

        public AndroidNotiFicaTion notification { get; set; }
    }

    public class AndroidNotiFicaTion
    {
        public AndroidNotiFicaTion()
        {

        }
        public AndroidNotiFicaTion(Click_action _click_Action)
        {
            this.click_action = _click_Action;
        }

        public Click_action click_action { get; set; }
    }


    public class Click_action
    {
        public Click_action()
        {

        }
        public Click_action(string _intent, int _type=1)
        {
            this.intent = _intent;
            this.type = _type;
        }

        public int type { get; set; }

        public string intent { get; set; }
    }
}
