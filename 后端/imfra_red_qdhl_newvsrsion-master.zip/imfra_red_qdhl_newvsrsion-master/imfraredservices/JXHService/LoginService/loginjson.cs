﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.LoginService
{
    public class loginjson
    {
        string state = "";

        public string State
        {
            get { return state; }
            set { state = value; }
        }
        string msg = "";

        public string Msg
        {
            get { return msg; }
            set { msg = value; }
        }
        string areaid = "";

        public string Areaid
        {
            get { return areaid; }
            set { areaid = value; }
        }
        string areaname = "";

        public string Areaname
        {
            get { return areaname; }
            set { areaname = value; }
        }
        string fenbuid = "";

        public string Fenbuid
        {
            get { return fenbuid; }
            set { fenbuid = value; }
        }
        string fenbuname = "";

        public string Fenbuname
        {
            get { return fenbuname; }
            set { fenbuname = value; }
        }
        string ywbid = "";

        public string Ywbid
        {
            get { return ywbid; }
            set { ywbid = value; }
        }
        string ywbname = "";

        public string Ywbname
        {
            get { return ywbname; }
            set { ywbname = value; }
        }
        string userid = "";

        public string Userid
        {
            get { return userid; }
            set { userid = value; }
        }
        string username = "";

        public string Username
        {
            get { return username; }
            set { username = value; }
        }
        string usertype = "";

        public string Usertype
        {
            get { return usertype; }
            set { usertype = value; }
        }
        string city = "";

        public string City
        {
            get { return city; }
            set { city = value; }
        }
    }
}