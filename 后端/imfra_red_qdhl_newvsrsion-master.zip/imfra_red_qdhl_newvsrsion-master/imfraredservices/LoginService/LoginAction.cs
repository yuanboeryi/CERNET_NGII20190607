﻿using imfraredservices.HuaweiPush;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.LoginService
{
    public class LoginAction
    {
        Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
        System.Timers.Timer timer = new System.Timers.Timer();

        public string login(string username,string password)
        {
            List<Maticsoft.Model.user_infor> userlist = new List<Maticsoft.Model.user_infor>();
            loginjson json = new loginjson();
                userlist = userservice.GetModelList("");
            bool ishave = false;
            for(int i=0;i<userlist.Count();i++)
            {
                if(userlist[i].username==username)
                {
                    ishave = true;

                    if(userlist[i].password==password)
                    {
                        json.State = "0";
                        json.Msg = "登录成功";
                        json.Areaid = userlist[i].areaid;
                        json.Areaname = userlist[i].areaname;
                        json.Fenbuid = userlist[i].fenbuid;
                        json.Fenbuname = userlist[i].fenbuname;
                        json.Ywbid = userlist[i].ywbid;
                        json.Ywbname = userlist[i].ywbname;
                        json.Userid = userlist[i].userid;
                        json.Username = userlist[i].username;
                        json.Usertype = userlist[i].usertype;
                    }
                    else
                    {
                        json.State = "1";
                        json.Msg = "密码错误";
                        json.Areaid = "";
                        json.Areaname = "";
                        json.Fenbuid = "";
                        json.Fenbuname = "";
                        json.Ywbid = "";
                        json.Ywbname = "";
                        json.Userid = "";
                        json.Username = "";
                        json.Usertype = "";
                    }
                    break;
                }
                
            }
            if(ishave==false)
            {
                json.State = "2";
                json.Msg = "用户不存在";
                json.Areaid = "";
                json.Areaname = "";
                json.Fenbuid = "";
                json.Fenbuname = "";
                json.Ywbid = "";
                json.Ywbname = "";
                json.Userid = "";
                json.Username = "";
                json.Usertype = "";
            }
            //List<loginjson> jsonlist = new List<loginjson>();
            //jsonlist.Add(json);

            timer.Interval = 2000;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(getMessage);
            if(timer.Enabled==false)
              timer.Start();
            //getMessage是个方法(略)
       
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }
        public void getMessage(object sender, EventArgs e)
        {
            HuaweiPushAction aaa = new HuaweiPushAction();
            aaa.getAlarmPush("",System.DateTime.Now.ToString());
            
        }
        public string loginout(string username)
        {
            loginjson json = new loginjson();

            json.State = "3";
            json.Msg = "用户登出";
            json.Areaid = "";
            json.Areaname = "";
            json.Fenbuid = "";
            json.Fenbuname = "";
            json.Ywbid = "";
            json.Ywbname = "";
            json.Userid = "";
            json.Username = "";
            json.Usertype = "";
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);

        }
        public DataTable loginApp(string username,string password)
        {
            DataTable dt = new DataTable();
            dt = userservice.GetList("username='" + username + "' and password='"+password+"'").Tables[0];
            return dt;
            
        }
    }
}