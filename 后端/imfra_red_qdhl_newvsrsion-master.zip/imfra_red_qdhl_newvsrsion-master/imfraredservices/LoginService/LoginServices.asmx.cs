﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace imfraredservices.LoginService
{
    /// <summary>
    /// LoginServices 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class LoginServices : System.Web.Services.WebService
    {
        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msgsend");
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        LoginAction action = new LoginAction();
        [WebMethod(Description = "接口描述：用户登录,返回成功或者失败")]
        public void login(string username, string password)
        {
            httpsend((action.login(username, password)));
        }
        [WebMethod(Description = "接口描述：用户登录,验证成功后返回用户信息实体类")]
        public void loginApp(string username,string password)
        {
            httpsend(ToJson(action.loginApp(username,password)));
        }
         [WebMethod(Description = "接口描述：用户登出")]
        public void loginout(string username)
        {
            httpsend((action.loginout(username)));
        }
         [WebMethod(Description = "接口描述：上报手机token")]
         public void saveToken(string userid, string token)
         {
             Maticsoft.BLL.push_token_infor service = new Maticsoft.BLL.push_token_infor();
             List<Maticsoft.Model.push_token_infor> model = new List<Maticsoft.Model.push_token_infor>();
             model = service.GetModelList("");
             bool ishave = false;
             string sid = "";
             for (int i = 0; i < model.Count(); i++)
             {
                 if (token == model[i].tokenvalue)
                 {
                     ishave = true;
                     sid = model[i].tokenid;
                 }
             }
             Maticsoft.BLL.user_infor usser = new Maticsoft.BLL.user_infor();
             Maticsoft.Model.user_infor usmodel = new Maticsoft.Model.user_infor();
             usmodel = usser.GetModel(userid);
             if (ishave == false)
             {
                 Maticsoft.Model.push_token_infor pushmodel = new Maticsoft.Model.push_token_infor();
                 pushmodel.tokenid = Guid.NewGuid().ToString("N");
                 pushmodel.tokenname = userid;
                 pushmodel.tokenvalue = token;
                 pushmodel.ywbname = "配置";
                 pushmodel.areaname = usmodel.areaname;
                 service.Add(pushmodel);
                 httpsend(strJson("1"));
             }
             else
             {
                 service.UpdateToken(sid, userid);
             }
         }

    }
}
















