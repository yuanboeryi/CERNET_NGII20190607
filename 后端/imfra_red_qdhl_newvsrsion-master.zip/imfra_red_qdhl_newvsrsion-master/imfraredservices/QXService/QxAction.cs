﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.QXService
{
    public class QxAction
    {
        public DataTable Qx_getstation(string areaname)
        {
            string x = "0";
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            return stationservice.GetList(" areaname='"+areaname+"' and alarmcount <> '0'").Tables[0];

        }
        public string getkeyPointdeviceBystation(string companyname, string page, string numbers)//重点监测设备
        {
            string iskey = "1";
            int end = ( int.Parse(numbers));
            int npage = (int.Parse(page) - 1)*int.Parse(numbers);
            Maticsoft.BLL.device_infor bll = new Maticsoft.BLL.device_infor();


            UserServices.devicelistjson l = new UserServices.devicelistjson();
            DataTable dt = bll.GetList("areaname='" + companyname + "' and iskeypoint='" + iskey + "'").Tables[0];
            int allcount = dt.Rows.Count;
            DataTable dt1 = bll.GetList("areaname='" + companyname + "' and iskeypoint='" + iskey + "' limit " + npage + "," + end + "").Tables[0];
            if (allcount % int.Parse(numbers)==0)
            {
                l.Recordcount = (allcount / int.Parse(numbers)).ToString();

            }
            else
            {
                l.Recordcount = (allcount / int.Parse(numbers)+1).ToString();
                
            }
            l.Recorddt = dt1;
            return Newtonsoft.Json.JsonConvert.SerializeObject(l); 
        }
        public string getkeyPointdeviceBystationName(string stationname)//重点监测设备
        {
            if (stationname == "")
                return "没有找到变电站名称";
            string iskey = "1";
            Maticsoft.BLL.device_infor bll = new Maticsoft.BLL.device_infor();
            List<UserServices.devicelistjson> ljson = new List<UserServices.devicelistjson>();
            for(int i=0;i<stationname.Split(',').Length;i++)
            {
                UserServices.devicelistjson l = new UserServices.devicelistjson();

                DataTable dt = bll.GetList("iskeypoint='" + iskey + "' and stationname='" + stationname.Split(',')[i] + "'").Tables[0];
                int allcount = dt.Rows.Count;
                DataTable dtnew = new DataTable("keyDevice");
                dtnew.Columns.Add("deviceid", Type.GetType("System.String"));
                dtnew.Columns.Add("devicename", Type.GetType("System.String"));
                dtnew.Columns.Add("stationname", Type.GetType("System.String"));
                dtnew.Columns.Add("image_red", Type.GetType("System.String"));
                dtnew.Columns.Add("image_high", Type.GetType("System.String"));
                dtnew.Columns.Add("image_mix", Type.GetType("System.String"));
                dtnew.Columns.Add("machineid", Type.GetType("System.String"));
                dtnew.Columns.Add("machinename", Type.GetType("System.String"));
                dtnew.Columns.Add("machinecode", Type.GetType("System.String"));
                dtnew.Columns.Add("todaytop", Type.GetType("System.String"));
                dtnew.Columns.Add("createtime", Type.GetType("System.String"));
                

                for (int k = 0; k < dt.Rows.Count; k++)
                {
                    string machineid = dt.Rows[k]["machineid"].ToString();
                    Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                    Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
                    macmodel = macser.GetModel(machineid);
                    if (macmodel != null)
                    {
                        string machinecode = macmodel.machinecode;
                        dtnew.Rows.Add(new object[] { dt.Rows[k]["deviceid"].ToString(), dt.Rows[k]["devicename"].ToString(), dt.Rows[k]["stationname"].ToString(), dt.Rows[k]["image_red"].ToString(), dt.Rows[k]["image_high"].ToString(), dt.Rows[k]["image_mix"].ToString(), dt.Rows[k]["machineid"].ToString(), dt.Rows[k]["machinename"].ToString(), machinecode, dt.Rows[k]["todaytop"].ToString(),dt.Rows[k]["createtime"].ToString(), });
                    }

                    //dt.Rows.Add(new object[] { allcount.ToString(), count1.ToString(), count2.ToString(), count3.ToString() });

                }
                l.Recorddt = dtnew;
                ljson.Add(l);
            }
            
            return Newtonsoft.Json.JsonConvert.SerializeObject(ljson);
        }
    }
}