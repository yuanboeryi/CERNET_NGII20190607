﻿using imfraredservices.ReportServic;
using imfraredservices.TableService;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace imfraredservices.QXService
{
    /// <summary>
    /// QxService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class QxService : System.Web.Services.WebService
    {
        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain; charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msg");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = Int32.MaxValue;
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows) 
            {               
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        QxAction action = new QxAction();
        [WebMethod(Description = "接口描述：全息平台，获取所有报警的变电站")]
        public void e_getStation_Qx(string areaname)
        {
            httpsend(ToJson(action.Qx_getstation(areaname)));
        }
         [WebMethod(Description = "接口描述：全息平台，获取所有的变电站")]
        public void getAllstation(string userid)
        {
            Maticsoft.BLL.user_infor s1 = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor m1 = new Maticsoft.Model.user_infor();
            m1 = s1.GetModel(userid);
            if (m1 == null)
            {
                return;
            }
            else
            {
                Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
                DataTable dt = new DataTable();
                if (m1.usertype == "0")
                {
                    dt = stationservice.GetList("areaid='" + m1.areaid + "'").Tables[0];

                }

                if (m1.usertype == "1")
                {
                    dt = stationservice.GetList("fenbuid='" + m1.fenbuid + "'").Tables[0];

                }
                if (m1.usertype == "2")
                {
                    dt = stationservice.GetList("ywbid='" + m1.ywbid + "'").Tables[0];

                }
                if (m1.usertype == "3")
                {
                    dt = stationservice.GetList("").Tables[0];

                }
                httpsend(ToJson( dt));
            }
        }
        [WebMethod(Description = "接口描述：获取重点监测设备")]
        public void getkeyPointdeviceBystation(string companyname,string page,string numbers)//重点监测设备
        {
            httpsend((action.getkeyPointdeviceBystation(companyname, page, numbers)));
        }


        [WebMethod(Description = "接口描述：获取重点监测设备.参数stationnamelist=变电站名称1,变电站名称2....")]
        public void getkeyPointdeviceBystationName(string stationnamelist)//重点监测设备
        {
            httpsend((action.getkeyPointdeviceBystationName(stationnamelist)));
        }

        [WebMethod(Description = "接口描述：获取当前登录用户下昨日80度测温统计，告警统计[昨日八点至今日八点]")]
        public void getAlarmAndOver80(string startDate,string endDate)
        {
            DateTime nowtime = System.DateTime.Now;
            DateTime timeToday = new DateTime();
            DateTime timeyestoday = new DateTime();
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            timeToday = Convert.ToDateTime(nowtime.Date.ToString("yyyy-MM-dd"), dtFormat);
            timeyestoday = timeToday;
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            string areaid = "40098b7fd8af43b88cd5db37611d3539";
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicemodel = new List<Maticsoft.Model.device_infor>();
            string topv="80";
            devicemodel = deviceservice.GetModelList("areaid='" + areaid + "' and todaytop>'" + topv + "'");
           
            int count_80 = 0;
            List<string> id_over_80=new List<string>();
            List<string> value_over_80 = new List<string>();
            List<string> id_alarm = new List<string>();
            List<string> value_alarm = new List<string>();
            List<string> alarmtime1 = new List<string>();
            List<string> alarmtime2 = new List<string>();
            string sql = "";
            if (startDate == "" && endDate == "")
                sql = "areaid='" + areaid + "'and createtime>'" + System.DateTime.Now.Date + "' group by devicename order by alarmvalue desc";
            else
                sql = "areaid='" + areaid + "' and createtime>'" + startDate + "' and createtime<'" + System.DateTime.Now.ToString()+"' group by devicename order by alarmvalue desc";
            Maticsoft.BLL.alarm_push_infor alarmservicve = new Maticsoft.BLL.alarm_push_infor();
            DataSet ds = alarmservicve.GetList(sql);// and createtime<'" + timeToday + "'
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    string stemp = ds.Tables[0].Rows[i]["alarmvalue"].ToString();
                    string isalarm ="1";
                    double dtemp = 0;
                    if (stemp != "" && stemp != null && stemp != "0")
                    {
                        dtemp = double.Parse(stemp);
                        if (dtemp >= 80)
                        {
                            count_80 += 1;
                            id_over_80.Add(ds.Tables[0].Rows[i]["deviceid"].ToString());
                            value_over_80.Add(stemp);
                            alarmtime1.Add(ds.Tables[0].Rows[i]["createtime"].ToString());
                        }
                    }
                }
           
            DataTable  dt1= new DataTable();
            dt1.Columns.Add("stationname", Type.GetType("System.String"));
            dt1.Columns.Add("devicename", Type.GetType("System.String"));
            dt1.Columns.Add("temputer", Type.GetType("System.String"));
            dt1.Columns.Add("alarmtime", Type.GetType("System.String"));

            for(int i=0;i<id_over_80.Count();i++)
            {
                Maticsoft.BLL.device_infor dser = new Maticsoft.BLL.device_infor();
                Maticsoft.Model.device_infor dmodel = new Maticsoft.Model.device_infor();
                dmodel = dser.GetModel(id_over_80[i]);
                dt1.Rows.Add(new object[] {dmodel.stationname,dmodel.devicename,value_over_80[i],alarmtime1[i] });
            }

            DataTable dt2 = new DataTable();
            dt2.Columns.Add("stationname", Type.GetType("System.String"));
            dt2.Columns.Add("devicename", Type.GetType("System.String"));
            dt2.Columns.Add("temputer", Type.GetType("System.String"));
            dt2.Columns.Add("alarmtime", Type.GetType("System.String"));
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
            alarmlist = alarmservice.GetModelList("areaid='" + areaid + "'  and createtime>'" + System.DateTime.Now.Date+"' group by devicename order by alarmvalue desc");
            for (int i = 0; i < alarmlist.Count(); i++)
            {
                dt2.Rows.Add(new object[] { alarmlist[i].stationname, alarmlist[i].devicename, alarmlist[i].alarmvalue, alarmlist[i].createtime.ToString() });
            }
            qxjson json = new qxjson();
            json.Over_80_count = count_80.ToString();
            json.Dt_over_80 = dt1;
            json.Alarm_count = dt2.Rows.Count.ToString(); ;
            json.Dt_alarm = dt2;

            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));
        }


        [WebMethod(Description = "点击告警变电站，右侧弹出告警的设备列表")]
        public void l_getAlarmStation(string stationid)
        {
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("id", Type.GetType("System.String"));
            dt.Columns.Add("deviceid", Type.GetType("System.String"));
            dt.Columns.Add("devicename", Type.GetType("System.String"));
            dt.Columns.Add("stationname", Type.GetType("System.String"));
            dt.Columns.Add("machinecode", Type.GetType("System.String"));

            dt.Columns.Add("alarmtime", Type.GetType("System.String"));
            dt.Columns.Add("alarmvalue", Type.GetType("System.String"));
            dt.Columns.Add("offsetvalue", Type.GetType("System.String"));
            dt.Columns.Add("offsethuman", Type.GetType("System.String"));
            dt.Columns.Add("fuhe", Type.GetType("System.String"));
            dt.Columns.Add("mensurehuman", Type.GetType("System.String"));
            dt.Columns.Add("mensuretime", Type.GetType("System.String"));
            dt.Columns.Add("isok", Type.GetType("System.String"));
            dt.Columns.Add("isread", Type.GetType("System.String"));
            dt.Columns.Add("imageurl1", Type.GetType("System.String"));
            dt.Columns.Add("imageurl2", Type.GetType("System.String"));
            dt.Columns.Add("imageurl3", Type.GetType("System.String"));


            string isok = "1";
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            List<Maticsoft.Model.alarm_push_infor> alarmmodel = new List<Maticsoft.Model.alarm_push_infor>();
            Maticsoft.BLL.device_infor devservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devmodel = new Maticsoft.Model.device_infor();
            alarmmodel = alarmservice.GetModelList("stationid='" + stationid + "' and isok='" + isok + "'");
            for (int i = 0; i < alarmmodel.Count(); i++)
            {
                string machinecode = "";
                if (alarmmodel != null)
                {
                    devmodel = devservice.GetModel(alarmmodel[i].deviceid);
                    Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                    machinecode = macser.GetModel(devmodel.machineid).machinecode;
                }
                string imagename = alarmmodel[i].image_url;
                string image_0 = "";
                string image_1 = "";
                string image_2 = "";
                if (imagename.Contains("~0~"))
                {
                    image_0 = imagename;
                    image_2 = imagename.Replace("~0~", "~2~");
                    image_1 = imagename.Replace("~0~", "~1~");
                }
                if (imagename.Contains("~1~"))
                {
                    image_1 = imagename;
                    image_2 = imagename.Replace("~1~", "~2~");
                    image_0 = imagename.Replace("~1~", "~0~");
                }
                if (imagename.Contains("~2~"))
                {
                    image_2 = imagename;
                    image_0 = imagename.Replace("~2~", "~0~");
                    image_1 = imagename.Replace("~2~", "~1~");
                }
                dt.Rows.Add(new object[] { alarmmodel[i].id, devmodel.deviceid, devmodel.devicename, devmodel.stationname, machinecode, alarmmodel[i].createtime.ToString(), alarmmodel[i].alarmvalue, devmodel.offsetvalue, devmodel.offsethuman, alarmmodel[i].fuhe, alarmmodel[i].mensurehuman, alarmmodel[i].mensuretime.ToString(), alarmmodel[i].isok, alarmmodel[i].isread, image_0, image_1, image_2 });
                httpsend(ToJson(dt));
            }


        }




        [WebMethod(Description="接口描述：全息平台下测温跟踪页面")]
        public void getTrackDevice(string ywbid,string stationid,string isalarm,string page,string limit)
        {
            trackDevicejson json = new trackDevicejson();
            string areaname = "郑州供电公司";
            Maticsoft.BLL.ywb_infor ywbservice = new Maticsoft.BLL.ywb_infor();
            List<Maticsoft.Model.ywb_infor> ywblist = new List<Maticsoft.Model.ywb_infor>();
            ywblist = ywbservice.GetModelList("areaname='" + areaname + "'");
            for(int i=0;i<ywblist.Count();i++)
            {
                string[] ywb = new string[2];
                ywb[0] = ywblist[i].ywbid;
                ywb[1] = ywblist[i].ywbname;
                json.Ywblist.Add(ywb);
            }
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            if(ywbid!=""&&ywbid!=null)
            {
                machinelist = machineservice.GetModelList("ywbid='" + ywbid + "'");
                stationlist = stationservice.GetModelList("ywbid='"+ywbid+"'");
            }
            else
            {
                machinelist = machineservice.GetModelList("areaname='" + areaname + "'");
                stationlist = stationservice.GetModelList("areaname='" + areaname + "'");
            }
            json.Stationcount = stationlist.Count().ToString();
            json.Machinecount = machinelist.Count().ToString();
            for(int i=0;i<stationlist.Count();i++)
            {
                string[] station = new string[2];
                station[0] = stationlist[i].stationid;
                station[1] = stationlist[i].stationname;
                json.Stationlist.Add(station);
            }
            string sql = "";

            List<string> sqllist = new List<string>();
            sqllist.Add("areaname='" + areaname + "'");
            if (ywbid != "" && ywbid != "全部" && ywbid != null)
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部" && stationid != null)
                sqllist.Add("stationid='" + stationid + "'");
            if (isalarm != "" && isalarm != "全部" && isalarm != null)
                sqllist.Add("isalarm='" + isalarm + "'");
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql = "";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1];
            }
            if (sql == "")
            {
                sql += "1=1";
            }
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1) * int.Parse(limit);
            string sql1 = sql;
           // string isround="1";
           // sql += " and isroundpoint='" + isround + "' limit " + npage + "," + end + "";
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            //DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            ds1 = deviceservice.GetList(sql1);
           // ds = deviceservice.GetList(sql);
            json.Devicecount = ds1.Tables[0].Rows.Count.ToString();
            int alarmcount = 0;
            if (ds1.Tables[0].Rows.Count > 0)
            {
                for(int i=0;i<ds1.Tables[0].Rows.Count;i++)
                {
                    if (ds1.Tables[0].Rows[i]["isalarm"].ToString()=="1")
                    {
                        alarmcount += 1;
                    }
                }
            }
            json.Alarmcount = alarmcount.ToString();
            int jcount = 0;
            
            List<roundDevicejson> newlist = new List<roundDevicejson>();
            List<roundDevicejson> oldlist = new List<roundDevicejson>();
            oldlist = getAllRounddevice(sql);
            jcount = oldlist.Count();
            if (jcount>0)
            {
                for (int i = npage; i < npage + end;i++ )
                {
                    if(i<jcount)
                    {
                        newlist.Add(oldlist[i]);
                    }
                }
            }
            json.Jsonlist = newlist;
            json.Pointdevicecount = newlist.Count().ToString();
            DataSet ds2 = new DataSet();
            ds2 = deviceservice.GetDeviceTongji(sql1);
            DataTable dtt = new DataTable("machinecount");
            dtt.Columns.Add("deviceType", Type.GetType("System.String"));
            dtt.Columns.Add("count", Type.GetType("System.String"));
            if (ds2.Tables[0].Rows.Count>0)
            {
                for (int i = 0; i < ds2.Tables[0].Rows.Count; i++)
                {
                    if (int.Parse(ds2.Tables[0].Rows[i]["devicecount"].ToString()) > 0)
                    {
                        dtt.Rows.Add(new object[] { ds2.Tables[0].Rows[i]["deviceType"], ds2.Tables[0].Rows[i]["devicecount"] });
                    }
                }

            }
            json.Devicebili = dtt;

            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));

        }

        public List<roundDevicejson> getAllRounddevice(string areaname)//实时监测设备
        {
            
            Maticsoft.BLL.device_infor bll = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> modellist = new List<Maticsoft.Model.device_infor>();
            string isround = "1";
            modellist = bll.GetModelList("isroundpoint='" + isround + "' and " +areaname);

            List<roundDevicejson> jsonlist = new List<roundDevicejson>();
            for (int i = 0; i < modellist.Count(); i++)
            {
                publicAction.getShortName pa = new publicAction.getShortName();

                roundDevicejson json = new roundDevicejson();
                json.Deviceid = modellist[i].deviceid;
                json.Devicename = modellist[i].devicename;
                json.Stationid = modellist[i].stationid;
                json.Isalarm = modellist[i].isalarm;
                json.Stationname = modellist[i].stationname;
                json.Stationshortname1 = pa.getshortname(modellist[i].stationid).Split(',')[0];
                json.Stationshortname2 = pa.getshortname(modellist[i].stationid).Split(',')[1];
                json.Stationshortname3 = pa.getshortname(modellist[i].stationid).Split(',')[2];
                json.Todaytop = modellist[i].todaytop;
                json.Templist = modellist[i].templist.Split(',').ToList<string>();
                json.Fuhelist = modellist[i].fuhelist.Split(',').ToList<string>();
                json.Time = (DateTime)modellist[i].createtime;
                json.Image_red = modellist[i].image_red;
                json.Image_high = modellist[i].image_high;
                json.Image_mix = modellist[i].image_mix;


                Maticsoft.Model.device_infor dddmodel = bll.GetModel(modellist[i].deviceid);
                Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
                macmodel = macser.GetModel(dddmodel.machineid);
                if (macmodel!=null)
                {
                    json.Machinecode = macmodel.machinecode;
                }


                jsonlist.Add(json);
            }
            return jsonlist;
        }


        [WebMethod(Description="接口描述：获取各个站今日最高温")]
        public void getTodayTop_Station(string page)
        {
            Maticsoft.BLL.station_top_infor service = new Maticsoft.BLL.station_top_infor();
            Maticsoft.Model.station_top_infor model = new Maticsoft.Model.station_top_infor();
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            string areaname = "郑州供电公司";
            stationlist = stationservice.GetModelList("areaname='"+areaname+"'");
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("stationid", Type.GetType("System.String"));
            dt.Columns.Add("stationname", Type.GetType("System.String"));
            dt.Columns.Add("todaytop", Type.GetType("System.String"));
            dt.Columns.Add("deviceid", Type.GetType("System.String"));
            dt.Columns.Add("devicename", Type.GetType("System.String"));
            dt.Columns.Add("createtime", Type.GetType("System.String"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("imageurl1", Type.GetType("System.String"));
            dt.Columns.Add("imageurl2", Type.GetType("System.String"));
            dt.Columns.Add("imageurl3", Type.GetType("System.String"));
            if (stationlist.Count > 0)
            {
                for(int i=0;i<stationlist.Count();i++)
                {
                    model = service.GetModel(stationlist[i].stationid);
                    if (model != null)
                    {
                        if(model.topdrecord!="" && model.topdrecord!=null)
                        {
                            string recordid = model.topdrecord;
                            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
                            Maticsoft.Model.image_record_history historymodel = new Maticsoft.Model.image_record_history();
                            historymodel = historyservice.GetModel(recordid);
                            if (historymodel != null)
                            {
                                string stationid = stationlist[i].stationid;
                                string stationname = stationlist[i].stationname;
                                string deviceid = historymodel.deviceid;
                                string devicename = historymodel.devicename;
                                string todaytop = historymodel.valuemax;
                                string createtime = historymodel.createtime.Value.ToString("yyyy-MM-dd HH:mm:ss");
                                 if (historymodel.createtime > System.DateTime.Now.AddDays(0).Date)
                                {
                                    dt.Rows.Add(new object[] { stationid, stationname, todaytop, deviceid, devicename, createtime, historymodel.valuemax, historymodel.image0, historymodel.image1, historymodel.image2 });

                                }
                            }
                  
                        }
                    }
             
                }
            }           
            DataTable table = new DataTable();
            table = dt.Clone();
            if (dt.Rows.Count > 0)
            {
                dt.DefaultView.Sort = "createtime DESC";
                int start = (int.Parse(page) - 1) * 6;
                int end = int.Parse(page) * 6;              
                if (dt.Rows.Count > 0)
                {
                    for (int i = start; i < end; i++)
                    {
                        if (i < dt.Rows.Count)
                            table.Rows.Add(dt.Rows[i].ItemArray);
                    }
                }
            }           
            httpsend(ToJson(table));          
        }

        [WebMethod(Description = "接口描述：根据运维班、变电站获取各个站今日最高温和告警列表(isalarm的值为0时，查询今日最高；isalarm的值为1时，查询告警列表)")]
        public void getImageByParam(string ywbid, string stationid, string isalarm, string page, string limit)
        {
            qximagejson json = new qximagejson();
            Maticsoft.BLL.station_top_infor service = new Maticsoft.BLL.station_top_infor();
            Maticsoft.Model.station_top_infor model = new Maticsoft.Model.station_top_infor();
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            string areaname = "郑州供电公司";
            string sql = "areaname='" + areaname + "'";
            if (ywbid != "" && ywbid != "全部" && ywbid != null)
            {
                sql += " and ywbid='" + ywbid + "'";
            }
            if (stationid != "" && stationid != "全部" && stationid != null)
            {
                sql += " and stationid='" + stationid + "'";
            }
            stationlist = stationservice.GetModelList(sql);
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("stationid", Type.GetType("System.String"));
            dt.Columns.Add("stationname", Type.GetType("System.String"));
            dt.Columns.Add("todaytop", Type.GetType("System.String"));
            dt.Columns.Add("deviceid", Type.GetType("System.String"));
            dt.Columns.Add("devicename", Type.GetType("System.String"));
            dt.Columns.Add("createtime", Type.GetType("System.String"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("image_red", Type.GetType("System.String"));
            dt.Columns.Add("image_high", Type.GetType("System.String"));
            dt.Columns.Add("image_mix", Type.GetType("System.String"));
            if (stationlist.Count > 0)
            {
                for (int i = 0; i < stationlist.Count(); i++)
                {
                    Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
                    Maticsoft.Model.image_record_history historymodel = new Maticsoft.Model.image_record_history();
                    if (isalarm == "0")//查询变电站今日最高温
                    {
                        model = service.GetModel(stationlist[i].stationid);
                        if (model != null)
                        {
                            if (model.topdrecord != "" && model.topdrecord != null)
                            {
                                string recordid = model.topdrecord;
                                historymodel = historyservice.GetModel(recordid);
                                if (historymodel != null)
                                {
                                    stationid = stationlist[i].stationid;
                                    string stationname = stationlist[i].stationname;
                                    string deviceid = historymodel.deviceid;
                                    string devicename = historymodel.devicename;
                                    string todaytop = historymodel.valuemax;
                                    string createtime = historymodel.createtime.Value.ToString("yyyy-MM-dd HH:mm:ss");
                                    if (historymodel.createtime > System.DateTime.Now.AddDays(0).Date)
                                    {
                                        dt.Rows.Add(new object[] { stationid, stationname, todaytop, deviceid, devicename, createtime, historymodel.valuemax, historymodel.image0, historymodel.image1, historymodel.image2 });
                                    }
                                }

                            }
                        }
                    }
                    else //查询告警数据
                    {
                        Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
                        List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
                        string starttime = System.DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd");
                        string endtime = System.DateTime.Now.AddDays(0).ToString("yyyy-MM-dd");
                        alarmlist = alarmservice.GetModelList(" stationid='" + stationlist[i].stationid + "' and createtime >'" + starttime + "' and createtime <'" + endtime + "' order by createtime desc ");
                        if (alarmlist.Count > 0)
                        {
                            List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();
                            for(int a= 0;a<alarmlist.Count;a++){
                                historylist = historyservice.GetModelList("deviceid = '" + alarmlist[a].deviceid + "' and valuemax = '" + alarmlist[a].alarmvalue + "' ");
                                if (historylist.Count >0)
                                {
                                    historymodel = historylist[0];
                                    if (historymodel != null)
                                    {
                                        stationid = stationlist[i].stationid;
                                        string stationname = stationlist[i].stationname;
                                        string deviceid = historymodel.deviceid;
                                        string devicename = historymodel.devicename;
                                        string todaytop = historymodel.valuemax;
                                        string createtime = historymodel.createtime.Value.ToString("yyyy-MM-dd hh:mm:ss");                                    
                                         dt.Rows.Add(new object[] { stationid, stationname, todaytop, deviceid, devicename, createtime, historymodel.valuemax, historymodel.image0, historymodel.image1, historymodel.image2 });                                       
                                    }

                                }
                             }
                          }
                       }
                    

                }
            }
            if (dt.Rows.Count > 0)
            {
                dt.DefaultView.Sort = "createtime DESC";
                dt = dt.DefaultView.ToTable();
            }         
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1) * int.Parse(limit);
            //var TEST = dt;
            //DataRow[] rows = dt.Select("", "createtime" + " desc");
            //DataTable t = dt.Clone();
            //t.Clear();
            //foreach (DataRow row in rows)
            //{
            //    t.ImportRow(row);
            //}

            //dt = t;

            DataTable table = new DataTable();
            table = dt.Clone();
            for (int i = npage; i < npage + end; i++)
            {
                if (i < dt.Rows.Count)
                {
                    table.Rows.Add(dt.Rows[i].ItemArray);
                }
            }                
            json.Count = dt.Rows.Count;
            json.Table = table;
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));
        }

        [WebMethod(Description="接口描述：获取郑州供电工区下所有温升超过20度的设备")]
        public void getSevenDaysTempRase(string startDate,string endDate)
        {
            string userid="10a29c9e1ecf4175bdc0ec36976b4068";
            string hour = System.DateTime.Now.Hour.ToString();
            List<sevendayRasejson> jsonlist = new List<sevendayRasejson>();
            Maticsoft.BLL.user_infor uservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = uservice.GetModel(userid);
            Maticsoft.BLL.device_infor devicemm = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            string isround = "1";
            if (usermodel.usertype == "0")
            {
                devicelist = devicemm.GetModelList("areaid='" + usermodel.areaid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "1")
            {
                devicelist = devicemm.GetModelList("fenbuid='" + usermodel.fenbuid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "2")
            {
                devicelist = devicemm.GetModelList("ywbid='" + usermodel.ywbid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "3")
            {
                devicelist = devicemm.GetModelList("isroundpoint='" + isround + "'");
            }
            if (devicelist.Count < 1)
                return ;
            for (int mk = 0; mk < devicelist.Count(); mk++)
            {
                string deviceid = devicelist[mk].deviceid;
                Maticsoft.BLL.device_infor dser = new Maticsoft.BLL.device_infor();
                Maticsoft.Model.device_infor dmodel = new Maticsoft.Model.device_infor();
                dmodel = dser.GetModel(deviceid);
                if (dmodel == null)
                    return ;
                string devicename = dmodel.devicename;
                string machineid = dmodel.machineid;
                string machinename = dmodel.machinename;
                List<string> returnlist = new List<string>();

               
                string[] stimelist = null;

                List<string> testlist = new List<string>();
                for (int i = 0; i < 24; i++)
                {
                    testlist.Add(i.ToString("00"));
                    returnlist.Add(i.ToString("00") + ":00");
                }
                stimelist = testlist.ToArray();

                DateTime dateStart, dateEnd;
                DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                dateStart = Convert.ToDateTime(startDate, dtFormat);
                dateEnd = Convert.ToDateTime(endDate, dtFormat);

                TimeSpan ts1 = new TimeSpan(dateEnd.Ticks);
                TimeSpan ts2 = new TimeSpan(dateStart.Ticks);
                TimeSpan ts = ts1.Subtract(ts2).Duration();
                int dateSpan = ts.Days;



                List<string> datelist = new List<string>();
                for (int i = 0; i < dateSpan + 1; i++)
                {
                    datelist.Add((dateStart.AddDays(i).Date).ToString("yyyy-MM-dd"));
                }

                Maticsoft.BLL.image_record_history histryservice = new Maticsoft.BLL.image_record_history();
                List<Maticsoft.Model.image_record_history> histrymodel = new List<Maticsoft.Model.image_record_history>();
                string sql = "";
                if (startDate != "" && endDate != "")
                    sql = "deviceid='" + deviceid + "'and createtime>'" + dateStart + "' and createtime<'" + dateEnd.AddDays(1) + "'";
                else
                    sql = "deviceid='" + deviceid + "'";
                histrymodel = histryservice.GetModelList(sql);

                List<List<double>> wendulistall = new List<List<double>>();
                for (int i = 0; i < stimelist.Length; i++)
                {
                    List<double> newlist = new List<double>();
                    for (int k = 0; k < datelist.Count(); k++)
                    {
                        string riqi = datelist[k];
                        string shijian = stimelist[i];
                        string svalue = "0.0";
                        for (int m = 0; m < histrymodel.Count(); m++)
                        {
                            string ssriqi = histrymodel[m].createtime.Value.Year.ToString() + "-" + histrymodel[m].createtime.Value.Month.ToString("00") + "-" + histrymodel[m].createtime.Value.Day.ToString("00");
                            string ssshijian = histrymodel[m].createtime.Value.Hour.ToString("00");

                            if (riqi == ssriqi && shijian == ssshijian)
                            {
                                svalue = histrymodel[m].valuemax;
                            }
                        }
                        newlist.Add(double.Parse(svalue));

                    }
                    double xxx0 = (newlist[0]);
                    for (int xx = 1; xx < newlist.Count(); xx++)
                    {
                        double xxx = (newlist[xx]);
                        if (xxx == 0.0)
                        {
                            xxx = (newlist[xx - 1]);
                            newlist.RemoveAt(xx);
                            newlist.Insert(xx, xxx);
                        }
                    }
                    if (((newlist[newlist.Count - 1] - newlist[0]) >= 20) && newlist[0] > 0)
                    {
                        wendulistall.Add(newlist);
                    }
                }
                for (int xk = 0; xk < wendulistall.Count(); xk++)
                {
                    if (IsIncreasingMontonically(wendulistall[xk]))
                    {
                        sevendayRasejson jsontest = new sevendayRasejson();
                        jsontest.Stationname = devicelist[mk].stationname;
                        jsontest.Buildingname = devicelist[mk].buildingname;
                        jsontest.Machineid = devicelist[mk].machineid;
                        jsontest.Machinename = devicelist[mk].machinename;
                        jsontest.Deviceid = devicelist[mk].deviceid;
                        jsontest.Decicename = devicelist[mk].devicename;
                        string s = "";
                        for (int kk = System.DateTime.Now.AddDays(-7).Day; kk < System.DateTime.Now.AddDays(-7).Day + 7; kk++)
                        {
                            s += kk.ToString("00") + ";" + wendulistall[xk][kk - System.DateTime.Now.AddDays(-7).Day] + ",";
                        }
                        s = s.Remove(s.Length - 1);
                        jsontest.Templist = s.Split(',').ToList();
                        jsontest.Shengwenqushi = "趋势：上升";
                        jsonlist.Add(jsontest);
                    }
                }
            }
            httpsend( Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist));
        }



        [WebMethod(Description="接口描述，保电平台，获取每个站下面的重点监测设备，和实时监测设备,传值：stationnamelist例如：春藤变,石佛变,瀚海变,临海变，逗号隔开")]
        public void getkeyPointdeviceBystationNamelist(string stationnamelist)//重点监测设备
        {
            qxshishijson jsonlist = new qxshishijson();
            if (stationnamelist == "")
                return;
            string iskey = "1";
            Maticsoft.BLL.device_infor bll = new Maticsoft.BLL.device_infor();
       
            for (int i = 0; i < stationnamelist.Split(',').Length; i++)
            {
                qxshishi json = new qxshishi();
                UserServices.devicelistjson l = new UserServices.devicelistjson();

                DataTable dt = bll.GetList("iskeypoint='" + iskey + "' and stationname='" + stationnamelist.Split(',')[i] + "'").Tables[0];
                if(dt.Rows.Count>0)
                {
                    json.Stationname = stationnamelist.Split(',')[i];

                    json.Devicelist = dt;
                    jsonlist.Devicelist.Add(json);
                
                }
               
            }

            httpsend( Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist));
        }
      
        [WebMethod(Description = "接口描述，获取周报")]
        public void getAllreport_f(string userid, string startDate, string endDate)
        {
            DateTime timeStart, timeEnd;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            timeStart = Convert.ToDateTime(startDate, dtFormat).AddDays(0).Date;
            timeEnd = Convert.ToDateTime(endDate, dtFormat).AddDays(1);

            allreportjson json = new allreportjson();
            json.Betweentime= startDate + "至" + endDate;
            json.ReportTime = System.DateTime.Now.ToString();
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            //Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
            {
                return;
            }
            string usertype = usermodel.usertype;
            DataSet station_ds = new DataSet();
            DataSet device_ds = new DataSet();
            DataSet machine_ds = new DataSet();
            //List<allreportjson_device> all_device_list = new List<allreportjson_device>();

            #region 跟踪设备统计
            if (usertype == "0")
            {
                json.ReportDanwei = usermodel.areaname;
                station_ds = stationservice.GetList("areaid='" + usermodel.areaid + "'");
                device_ds = deviceservice.GetList("areaid='" + usermodel.areaid + "'");
                machine_ds = macservice.GetList("areaid='" + usermodel.areaid + "'");
                json.DeviceTongji = startDate + "至" + endDate + "期间：测温跟踪共" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + device_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪,监测主变81台，监测电抗器28台";
                //for (int i = 0; i < station_ds.Tables[0].Rows.Count; i++)
                //{
                //    List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
                //    Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
                //    buildinglist = buildingservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //    List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
                //    machinelist = macservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //    for (int j = 0; j < buildinglist.Count; j++)
                //    {
                //        Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
                //        List<Maticsoft.Model.devicetype_infor> typemodel = new List<Maticsoft.Model.devicetype_infor>();
                //        typemodel = typeservice.GetModelList("");
                //        for (int k = 0; k < typemodel.Count; k++)
                //        {
                //            allreportjson_device all_device = new allreportjson_device();
                //            all_device.Stationname = station_ds.Tables[0].Rows[i]["stationname"].ToString();
                //            all_device.Machinecount = machinelist.Count.ToString();
                //            all_device.Buildingname = buildinglist[j].buildingname;
                //            all_device.Devicetype = typemodel[k].devicetype;
                //            List<Maticsoft.Model.device_infor> devicelist_type = new List<Maticsoft.Model.device_infor>();
                //            devicelist_type = deviceservice.GetModelList("buildingname='" + buildinglist[j].buildingname + "' and ysdtype='" + typemodel[k].devicetype + "'");
                //            string sx = "";
                //            for (int m = 0; m < devicelist_type.Count; m++)
                //            {
                //                sx += (devicelist_type[m].devicename) + "，";
                //            }
                //            all_device.Devicelist = sx;
                //            all_device_list.Add(all_device);
                //        }

                //    }
                //}
            }
            if (usertype == "1")
            {
                json.ReportDanwei = usermodel.fenbuname;

                station_ds = stationservice.GetList("fenbuid='" + usermodel.fenbuid + "'");
                device_ds = deviceservice.GetList("fenbuid='" + usermodel.fenbuid + "'");

                machine_ds = macservice.GetList("fenbuid='" + usermodel.fenbuid + "'");
                json.DeviceTongji = startDate + "至" + endDate + "期间测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共：" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对：" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + device_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪,监测主变81台，监测电抗器28台";
                //for (int i = 0; i < station_ds.Tables[0].Rows.Count; i++)
                //{
                //    List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
                //    Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
                //    buildinglist = buildingservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //    List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
                //    machinelist = macservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //    for (int j = 0; j < buildinglist.Count; j++)
                //    {
                //        Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
                //        List<Maticsoft.Model.devicetype_infor> typemodel = new List<Maticsoft.Model.devicetype_infor>();
                //        typemodel = typeservice.GetModelList("");
                //        for (int k = 0; k < typemodel.Count; k++)
                //        {
                //            allreportjson_device all_device = new allreportjson_device();
                //            all_device.Stationname = station_ds.Tables[0].Rows[i]["stationname"].ToString();
                //            all_device.Machinecount = machinelist.Count.ToString();
                //            all_device.Buildingname = buildinglist[j].buildingname;
                //            all_device.Devicetype = typemodel[k].devicetype;
                //            List<Maticsoft.Model.device_infor> devicelist_type = new List<Maticsoft.Model.device_infor>();
                //            devicelist_type = deviceservice.GetModelList("buildingname='" + buildinglist[j].buildingname + "' and ysdtype='" + typemodel[k].devicetype + "'");
                //            string sx = "";
                //            for (int m = 0; m < devicelist_type.Count; m++)
                //            {
                //                sx += (devicelist_type[m].devicename) + "，";
                //            }
                //            all_device.Devicelist = sx;
                //            all_device_list.Add(all_device);
                //        }

                //    }
                //}
            }
            if (usertype == "2")
            {
                json.ReportDanwei = usermodel.ywbname;

                station_ds = stationservice.GetList("ywbid='" + usermodel.ywbid + "'");
                device_ds = deviceservice.GetList("ywbid='" + usermodel.ywbid + "'");

                machine_ds = macservice.GetList("ywbid='" + usermodel.ywbid + "'");
                json.DeviceTongji = startDate + "至" + endDate + "期间测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共：" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对：" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + device_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪,监测主变81台，监测电抗器28台";
                //for (int i = 0; i < station_ds.Tables[0].Rows.Count; i++)
                //{
                //    List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
                //    Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
                //    buildinglist = buildingservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //    List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
                //    machinelist = macservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //    for (int j = 0; j < buildinglist.Count; j++)
                //    {
                //        Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
                //        List<Maticsoft.Model.devicetype_infor> typemodel = new List<Maticsoft.Model.devicetype_infor>();
                //        typemodel = typeservice.GetModelList("");
                //        for (int k = 0; k < typemodel.Count; k++)
                //        {
                //            allreportjson_device all_device = new allreportjson_device();
                //            all_device.Stationname = station_ds.Tables[0].Rows[i]["stationname"].ToString();
                //            all_device.Machinecount = machinelist.Count.ToString();
                //            all_device.Buildingname = buildinglist[j].buildingname;
                //            all_device.Devicetype = typemodel[k].devicetype;
                //            List<Maticsoft.Model.device_infor> devicelist_type = new List<Maticsoft.Model.device_infor>();
                //            devicelist_type = deviceservice.GetModelList("buildingname='" + buildinglist[j].buildingname + "' and ysdtype='" + typemodel[k].devicetype + "'");
                //            string sx = "";
                //            for (int m = 0; m < devicelist_type.Count; m++)
                //            {
                //                sx += (devicelist_type[m].devicename) + "，";
                //            }
                //            all_device.Devicelist = sx;
                //            all_device_list.Add(all_device);
                //        }

                //    }
                //}
            }
            if (usertype == "3")
            {
                json.ReportDanwei = "admin";

                station_ds = stationservice.GetList("");
                device_ds = deviceservice.GetList("");

                machine_ds = macservice.GetList("");
                json.DeviceTongji = startDate + "至" + endDate + "期间测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共：" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对：" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + device_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪,监测主变81台，监测电抗器28台";
                //for (int i = 0; i < station_ds.Tables[0].Rows.Count; i++)
                //{
                //    List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
                //    Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
                //    buildinglist = buildingservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //    List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
                //    machinelist = macservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //    for (int j = 0; j < buildinglist.Count; j++)
                //    {
                //        Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
                //        List<Maticsoft.Model.devicetype_infor> typemodel = new List<Maticsoft.Model.devicetype_infor>();
                //        typemodel = typeservice.GetModelList("");
                //        for (int k = 0; k < typemodel.Count; k++)
                //        {
                //            allreportjson_device all_device = new allreportjson_device();
                //            all_device.Stationname = station_ds.Tables[0].Rows[i]["stationname"].ToString();
                //            all_device.Machinecount = machinelist.Count.ToString();
                //            all_device.Buildingname = buildinglist[j].buildingname;
                //            all_device.Devicetype = typemodel[k].devicetype;
                //            List<Maticsoft.Model.device_infor> devicelist_type = new List<Maticsoft.Model.device_infor>();
                //            devicelist_type = deviceservice.GetModelList("buildingname='" + buildinglist[j].buildingname + "' and ysdtype='" + typemodel[k].devicetype + "'");
                //            string sx = "";
                //            for (int m = 0; m < devicelist_type.Count; m++)
                //            {
                //                sx += (devicelist_type[m].devicename) + "，";
                //            }
                //            all_device.Devicelist = sx;
                //            all_device_list.Add(all_device);
                //        }

                //    }
                //}
            }
            #endregion
            //json.Device_json = all_device_list;
            //for (int i = 0; i < count_120_list.Count; i++)
            //{

            //    Maticsoft.Model.alarm_push_infor lm = new Maticsoft.Model.alarm_push_infor();
            //    lm = alarmservice.GetModel(count_120_list[i]);

            //    string offset = deviceservice.GetModel(lm.deviceid).offsetvalue;
            //    string isalarm = "";
            //    if (offset != "")
            //    {
            //        if (double.Parse(offset) >= 120)
            //            isalarm = "是";
            //    }

            //    dtx.Rows.Add(new object[] { lm.createtime.ToString(), lm.stationname, lm.devicename, lm.alarmvalue, offset, isalarm });
            //}
            #region 高温设备统计
            List<string> devicelist = new List<string>();
            DataSet Topdev = new DataSet();

            //List<Maticsoft.Model.alarm_push_infor> hismodellist = new List<Maticsoft.Model.alarm_push_infor>();
            //List<string> count_80_list = new List<string>(); List<string> count_80_station = new List<string>();
            //List<string> count_90_list = new List<string>(); List<string> count_90_station = new List<string>();
            //List<string> count_100_list = new List<string>(); List<string> count_100_station = new List<string>();
            //List<string> count_120_list = new List<string>(); List<string> count_120_station = new List<string>();
            //string count1 = count_80_list.Count().ToString();
            //string count2 = count_90_list.Count().ToString();
            //string count3 = count_100_list.Count().ToString();
            //string count4 = count_120_list.Count().ToString();
            //string station_80_str = "";
            //string station_90_str = "";
            //string station_100_str = "";
            //string station_120_str = "";
            //DataTable dtx = new DataTable("machinecount");

            //try
            //{
                //获取device_infor
                //if (usertype == "0")
                //{
                //    Topdev = deviceservice.GetList("areaid='" + usermodel.areaid + "' GROUP BY stationname");
                //}
                //if (usertype == "1")
                //{
                //    Topdev = deviceservice.GetList("fenbuid='" + usermodel.fenbuid + "' GROUP BY stationname");
                //}
                //if (usertype == "2")
                //{
                //    Topdev = deviceservice.GetList("ywbid='" + usermodel.ywbid + "' GROUP BY stationname");
                //}
                //if (usertype == "3")
                //{
                //    Topdev = deviceservice.GetList("1=1  GROUP BY stationname");
                //}

                //DataTable dtx_device = new DataTable("machinecount");
                //dtx_device.Columns.Add("stationname", Type.GetType("System.String"));//变电站
                //dtx_device.Columns.Add("devicename", Type.GetType("System.String"));//设备
                //dtx_device.Columns.Add("weekvalue", Type.GetType("System.String"));//周top
                //dtx_device.Columns.Add("monthvalue", Type.GetType("System.String"));//月top
                //dtx_device.Columns.Add("historyvalue", Type.GetType("System.String"));//历史top
                //if (Topdev.Tables != null)
                //{
                //    for (int i = 0; i < Topdev.Tables[0].Rows.Count; i++)//得到当前用户下的设备列表
                //    {

                //        devicelist.Add(Topdev.Tables[0].Rows[i]["deviceid"].ToString());

                //        string weektopstr = Topdev.Tables[0].Rows[i]["weektop"].ToString();
                //        string monthtopstr = Topdev.Tables[0].Rows[i]["monthtop"].ToString();
                //        string historytopstr = Topdev.Tables[0].Rows[i]["historytop"].ToString();
                //        if (weektopstr != null && monthtopstr != null && historytopstr != null && weektopstr != "" && monthtopstr != "" && historytopstr != "")
                //        {
                //            double weektop = double.Parse(weektopstr);
                //            double monthtop = double.Parse(monthtopstr);
                //            double historytop = double.Parse(historytopstr);
                //            if (weektop > 0.0 && monthtop > 0.0 && historytop > 0.0)
                //            {
                //                dtx_device.Rows.Add(new object[] { Topdev.Tables[0].Rows[i]["stationname"].ToString(), Topdev.Tables[0].Rows[i]["devicename"].ToString(), weektopstr, monthtopstr, historytopstr });
                //            }

                //        }

                //    }
                //}

                //json.Device_history_list = dtx_device;
                Maticsoft.BLL.image_record_history imageservice = new Maticsoft.BLL.image_record_history();
                List<Maticsoft.Model.image_record_history> imagemodellist = new List<Maticsoft.Model.image_record_history>();
                List<Maticsoft.Model.device_infor> devicetoplist = new List<Maticsoft.Model.device_infor>();
                if (usertype == "0")
                {
                    devicetoplist = deviceservice.GetModelList("areaid='" + usermodel.areaid + "'");                  
                }
                if (usertype == "1")
                {
                    devicetoplist = deviceservice.GetModelList("fenbuid='" + usermodel.fenbuid + "'");                   
                }
                if (usertype == "2")
                {
                    devicetoplist = deviceservice.GetModelList("ywbid='" + usermodel.ywbid + "'");
                }
                if (usertype == "3")
                {
                    devicetoplist = deviceservice.GetModelList("");
                }
                if (devicetoplist != null && devicetoplist.Count > 0)//查询每个设备的最高温,进行显示
                {
                    foreach (var device in devicetoplist)
                    {
                        if (device != null)
                        {
                            List<Maticsoft.Model.image_record_history> imagerecordlist = imageservice.GetModelList("deviceid='" + device.deviceid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "'  and valuemax >=80  and valuemax <150 and isalarm=0  ORDER BY  CAST(valuemax AS DECIMAL) DESC ");
                            if (imagerecordlist != null && imagerecordlist.Count > 0)
                            {
                                imagemodellist.Add(imagerecordlist[0]);//每个设备最大值放到集合中
                            }
                        }
                    }
                }


                List<string> count_80_list = new List<string>(); List<string> count_80_station = new List<string>();
                List<string> count_90_list = new List<string>(); List<string> count_90_station = new List<string>();
                List<string> count_100_list = new List<string>(); List<string> count_100_station = new List<string>();
                List<string> count_120_list = new List<string>(); List<string> count_120_station = new List<string>(); 
                Maticsoft.Model.image_record_history imagemmodel = new Maticsoft.Model.image_record_history();
                if (imagemodellist.Count > 0)
                {
                    for (int i = 0; i < imagemodellist.Count; i++)
                    {
                        if (imagemodellist[i].valuemax != "" && imagemodellist[i].valuemax != null)
                        {
                            if (double.Parse(imagemodellist[i].valuemax) >= 80 && double.Parse(imagemodellist[i].valuemax) < 90)
                            {
                                if (!count_80_list.Contains(imagemodellist[i].deviceid))
                                {
                                    count_80_list.Add(imagemodellist[i].recordid);
                                    string his_deviceid = "";
                                    string ala_stationname = "";
                                    his_deviceid = imagemodellist[i].deviceid;
                                    Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                                    devicemodel = deviceservice.GetModel(his_deviceid);
                                    if (devicemodel != null)
                                        ala_stationname = devicemodel.stationname;

                                    if (!count_80_station.Contains(ala_stationname))
                                        count_80_station.Add(ala_stationname);
                                }
                            }
                            if (double.Parse(imagemodellist[i].valuemax) >= 90 && double.Parse(imagemodellist[i].valuemax) < 100)
                            {
                                if (!count_90_list.Contains(imagemodellist[i].deviceid))
                                {
                                    count_90_list.Add(imagemodellist[i].recordid);
                                    string his_deviceid = "";
                                    string ala_stationname = "";
                                    his_deviceid = imagemodellist[i].deviceid;
                                    Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                                    devicemodel = deviceservice.GetModel(his_deviceid);
                                    if (devicemodel != null)
                                        ala_stationname = devicemodel.stationname;
                                    if (!count_90_station.Contains(ala_stationname))
                                        count_90_station.Add(ala_stationname);
                                }
                            }
                            if (double.Parse(imagemodellist[i].valuemax) >= 100 && double.Parse(imagemodellist[i].valuemax) < 120)
                            {
                                if (!count_100_list.Contains(imagemodellist[i].deviceid))
                                {
                                    count_100_list.Add(imagemodellist[i].recordid);
                                    string his_deviceid = "";
                                    string ala_stationname = "";
                                    his_deviceid = imagemodellist[i].deviceid;
                                    Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                                    devicemodel = deviceservice.GetModel(his_deviceid);
                                    if (devicemodel != null)
                                        ala_stationname = devicemodel.stationname;
                                    if (!count_100_station.Contains(ala_stationname))
                                        count_100_station.Add(ala_stationname);
                                }
                            }
                            if (double.Parse(imagemodellist[i].valuemax) >= 120 && double.Parse(imagemodellist[i].valuemax) < 140)
                            {
                                if (!count_120_list.Contains(imagemodellist[i].deviceid))
                                {
                                    count_120_list.Add(imagemodellist[i].recordid);
                                    string his_deviceid = "";
                                    string ala_stationname = "";
                                    his_deviceid = imagemodellist[i].deviceid;
                                    Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                                    devicemodel = deviceservice.GetModel(his_deviceid);
                                    if (devicemodel != null)
                                        ala_stationname = devicemodel.stationname;
                                    if (!count_120_station.Contains(ala_stationname))
                                        count_120_station.Add(ala_stationname);
                                }
                            }
                        }
                    }

                }
                string count1 = count_80_list.Count().ToString();
                string count2 = count_90_list.Count().ToString();
                string count3 = count_100_list.Count().ToString();
                string count4 = count_120_list.Count().ToString();
                DataTable dtx = new DataTable("machinecount");
                dtx.Columns.Add("createtime", Type.GetType("System.String"));
                dtx.Columns.Add("stationname", Type.GetType("System.String"));
                dtx.Columns.Add("devicename", Type.GetType("System.String"));
                dtx.Columns.Add("valuemax", Type.GetType("System.String"));
                dtx.Columns.Add("offsetvalue", Type.GetType("System.String"));
                for (int i = 0; i < count_120_list.Count; i++)
                {

                    Maticsoft.Model.image_record_history lm = new Maticsoft.Model.image_record_history();
                    lm = imageservice.GetModel(count_120_list[i]);
                    if (lm != null)
                    {
                        Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(lm.deviceid);                      
                        if (devicemodel != null)
                        {
                            dtx.Rows.Add(new object[] { lm.createtime.ToString(), devicemodel.stationname, lm.devicename, lm.valuemax, devicemodel.offsetvalue });
                        }
                    }
                }
                for (int i = 0; i < count_80_list.Count; i++)
                {

                    Maticsoft.Model.image_record_history lm = new Maticsoft.Model.image_record_history();
                    lm = imageservice.GetModel(count_80_list[i]);
                    if (lm != null)
                    {
                        Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(lm.deviceid);                       
                        if (devicemodel != null)
                        {
                            dtx.Rows.Add(new object[] { lm.createtime.ToString(), devicemodel.stationname, lm.devicename, lm.valuemax, devicemodel.offsetvalue });
                        }
                    }
                }
                for (int i = 0; i < count_90_list.Count; i++)
                {

                    Maticsoft.Model.image_record_history lm = new Maticsoft.Model.image_record_history();
                    lm = imageservice.GetModel(count_90_list[i]);
                    if (lm != null)
                    {
                        Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(lm.deviceid);
                        if (devicemodel != null)
                        {
                            dtx.Rows.Add(new object[] { lm.createtime.ToString(), devicemodel.stationname, lm.devicename, lm.valuemax, devicemodel.offsetvalue });
                        }
                    }
                }
                for (int i = 0; i < count_100_list.Count; i++)
                {

                    Maticsoft.Model.image_record_history lm = new Maticsoft.Model.image_record_history();
                    lm = imageservice.GetModel(count_100_list[i]);
                    if (lm != null)
                    {
                        Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(lm.deviceid);
                        if (devicemodel != null)
                        {
                            dtx.Rows.Add(new object[] { lm.createtime.ToString(), devicemodel.stationname, lm.devicename, lm.valuemax, devicemodel.offsetvalue });
                        }
                    }
                }
                string station_80_str = "";
                if (count_80_station != null && count_80_station.Count > 0)
                {
                    for (int i = 0; i < count_80_station.Count; i++)
                    {
                        if (i == (count_80_station.Count() - 1))
                        {
                            station_80_str += count_80_station[i] + "。";
                        }
                        else
                        {
                            station_80_str += count_80_station[i] + "、";
                        }
                    }

                }
                string station_90_str = "";
                if (count_90_station != null && count_90_station.Count > 0)
                {
                    for (int i = 0; i < count_90_station.Count; i++)
                    {
                        if (i == (count_90_station.Count() - 1))
                        {
                            station_90_str += count_90_station[i] + "。";
                        }
                        else
                        {
                            station_90_str += count_90_station[i] + "、";
                        }
                        //station_90_str += count_90_station[i] + "、";
                    }
                }
                string station_100_str = "";
                if (count_100_station != null && count_100_station.Count > 0)
                {
                    for (int i = 0; i < count_100_station.Count; i++)
                    {
                        if (i == (count_100_station.Count() - 1))
                        {
                            station_100_str += count_100_station[i] + "。";
                        }
                        else
                        {
                            station_100_str += count_100_station[i] + "、";
                        }
                        //station_100_str += count_100_station[i] + "、";
                    }
                }
                string station_120_str = "";
                if (count_120_station != null && count_120_station.Count > 0)
                {
                    for (int i = 0; i < count_120_station.Count; i++)
                    {
                        if (i == (count_120_station.Count() - 1))
                        {
                            station_120_str += count_120_station[i] + "。";
                        }
                        else
                        {
                            station_120_str += count_120_station[i] + "、";
                        }
                        //station_120_str += count_120_station[i] + "、";
                    }
                }
                //            json.DeviceTongji2 = json.DeviceTongji + ",监测主变81台，监测电抗器28台，";
                json.DeviceTongji2 = json.DeviceTongji;
                json.DeviceTongji += "，共检测到超80℃监测点：" + count1 + "处；超90℃：" + count2 + "处；超100℃：" + count3 + "处；超120℃：" + count4 + "处。";
                json.DeviceTongji1 = "在" + startDate + "至" + endDate + "之间，超80℃监测点：" + count1 + "处；超90℃：" + count2 + "处；超100℃：" + count3 + "处；超120℃：" + count4 + "处。";
                //json.HightemputerTongji = "超80℃监测点：" + count1 + "处：来自于：" + station_80_str + "；\r\n超90℃：" + count2 + "处，来自于：" + station_90_str + ";\r\n超100℃：" + count3 + "处，来自于：" + station_100_str + ";\r\n超120℃：" + count4 + "处，来自于：" + station_120_str + "；";
            //}
            //catch (Exception ue)
            //{
            //    String str = "";
            //    str += ue.Message + "\n";//异常消息
            //    str += ue.StackTrace + "\n";//提示出错位置，不会定位到方法内部去
            //    str += ue.ToString() + "\n";//将方法内部和外部所有出错的位置提示出来
            //    System.Diagnostics.Debug.WriteLine(str);
            //    json.catchsoure = ue.Source;

            //}
            #endregion
                #region 超过80
                json.Over_80_tongji = startDate + "至" + endDate + "期间：" + "超80℃监测点：" + count1 + "处，分别是：" + station_80_str;
                DataTable dtx_device_over_80 = new DataTable("machinecount");
                dtx_device_over_80.Columns.Add("createtime", Type.GetType("System.String"));
                dtx_device_over_80.Columns.Add("stationname", Type.GetType("System.String"));
                dtx_device_over_80.Columns.Add("devicename", Type.GetType("System.String"));
                dtx_device_over_80.Columns.Add("overvlaue", Type.GetType("System.String"));
                dtx_device_over_80.Columns.Add("offsetvalue", Type.GetType("System.String"));
                dtx_device_over_80.Columns.Add("image_high", Type.GetType("System.String"));
                dtx_device_over_80.Columns.Add("image_red", Type.GetType("System.String"));
                for (int i = 0; i < imagemodellist.Count; i++)
                {
                    string smm = imagemodellist[i].valuemax;
                    if (smm != "")
                    {
                        if (double.Parse(smm) >= 80 && double.Parse(smm) < 90)
                        {
                            string deviceid_id = imagemodellist[i].deviceid;
                            Maticsoft.Model.device_infor devmmm = new Maticsoft.Model.device_infor();
                            devmmm = deviceservice.GetModel(deviceid_id);
                            if (devmmm != null)
                            {                               
                                dtx_device_over_80.Rows.Add(new object[] { imagemodellist[i].createtime.Value.ToString(), devmmm.stationname, imagemodellist[i].devicename, imagemodellist[i].valuemax, devmmm.offsetvalue, imagemodellist[i].image0, imagemodellist[i].image1 });
                            }


                        }
                    }
                }

                json.Over_80_list = dtx_device_over_80;
                #endregion
                #region 超过90
                json.Over_90_tongji = "超90℃监测点：" + count2 + "处，分别是：" + station_90_str;
                DataTable dtx_device_over_90 = new DataTable("machinecount");
                dtx_device_over_90.Columns.Add("createtime", Type.GetType("System.String"));
                dtx_device_over_90.Columns.Add("stationname", Type.GetType("System.String"));
                dtx_device_over_90.Columns.Add("devicename", Type.GetType("System.String"));
                dtx_device_over_90.Columns.Add("overvlaue", Type.GetType("System.String"));
                dtx_device_over_90.Columns.Add("offsetvalue", Type.GetType("System.String"));
                dtx_device_over_90.Columns.Add("image_high", Type.GetType("System.String"));
                dtx_device_over_90.Columns.Add("image_red", Type.GetType("System.String"));
                for (int i = 0; i < imagemodellist.Count; i++)
                {
                    string smm = imagemodellist[i].valuemax;
                    if (smm != "")
                    {
                        if (double.Parse(smm) >= 90 && double.Parse(smm) < 100)
                        {
                            string deviceid_id = imagemodellist[i].deviceid;
                            Maticsoft.Model.device_infor devmmm = new Maticsoft.Model.device_infor();
                            devmmm = deviceservice.GetModel(deviceid_id);
                            if (devmmm != null)
                            {
                                dtx_device_over_90.Rows.Add(new object[] { imagemodellist[i].createtime.Value.ToString(), devmmm.stationname, imagemodellist[i].devicename, imagemodellist[i].valuemax, devmmm.offsetvalue, imagemodellist[i].image0, imagemodellist[i].image1 });
                            }                   
                        }
                    }
                }

                json.Over_90_list = dtx_device_over_90;
                #endregion
                #region 超过100
                json.Over_100_tongji = "超100℃监测点：" + count3 + "处，分别是：" + station_100_str;
                DataTable dtx_device_over_100 = new DataTable("machinecount");
                dtx_device_over_100.Columns.Add("createtime", Type.GetType("System.String"));
                dtx_device_over_100.Columns.Add("stationname", Type.GetType("System.String"));
                dtx_device_over_100.Columns.Add("devicename", Type.GetType("System.String"));
                dtx_device_over_100.Columns.Add("overvlaue", Type.GetType("System.String"));
                dtx_device_over_100.Columns.Add("offsetvalue", Type.GetType("System.String"));
                dtx_device_over_100.Columns.Add("image_high", Type.GetType("System.String"));
                dtx_device_over_100.Columns.Add("image_red", Type.GetType("System.String"));
                for (int i = 0; i < imagemodellist.Count; i++)
                {
                    string smm = imagemodellist[i].valuemax;
                    if (smm != "")
                    {
                        if (double.Parse(smm) >= 100 && double.Parse(smm) < 120)
                        {
                            string deviceid_id = imagemodellist[i].deviceid;
                            Maticsoft.Model.device_infor devmmm = new Maticsoft.Model.device_infor();
                            devmmm = deviceservice.GetModel(deviceid_id);
                            if (devmmm != null)
                            {
                                dtx_device_over_100.Rows.Add(new object[] { imagemodellist[i].createtime.Value.ToString(), devmmm.stationname, imagemodellist[i].devicename, imagemodellist[i].valuemax, devmmm.offsetvalue, imagemodellist[i].image0, imagemodellist[i].image1 });
                            }                         
                        }
                    }
                }

                json.Over_100_list = dtx_device_over_100;
                #endregion
                #region 超过120
                json.Over_120_tongji = "超120℃监测点：" + count4 + "处，分别是：" + station_120_str;
                DataTable dtx_device_over_120 = new DataTable("machinecount");
                dtx_device_over_120.Columns.Add("createtime", Type.GetType("System.String"));
                dtx_device_over_120.Columns.Add("stationname", Type.GetType("System.String"));
                dtx_device_over_120.Columns.Add("devicename", Type.GetType("System.String"));
                dtx_device_over_120.Columns.Add("overvlaue", Type.GetType("System.String"));
                dtx_device_over_120.Columns.Add("offsetvalue", Type.GetType("System.String"));
                dtx_device_over_120.Columns.Add("image_high", Type.GetType("System.String"));
                dtx_device_over_120.Columns.Add("image_red", Type.GetType("System.String"));
                for (int i = 0; i < imagemodellist.Count; i++)
                {
                    string smm = imagemodellist[i].valuemax;
                    if (smm != "")
                    {
                        if (double.Parse(smm) >= 120 && double.Parse(smm) < 140)
                        {
                            string deviceid_id = imagemodellist[i].deviceid;
                            Maticsoft.Model.device_infor devmmm = new Maticsoft.Model.device_infor();
                            devmmm = deviceservice.GetModel(deviceid_id);
                            if (devmmm != null)
                            {
                                dtx_device_over_120.Rows.Add(new object[] { imagemodellist[i].createtime.Value.ToString(), devmmm.stationname, imagemodellist[i].devicename, imagemodellist[i].valuemax, devmmm.offsetvalue, imagemodellist[i].image0, imagemodellist[i].image1 });
                            }                           
                        }
                    }
                }
                json.Over_120_list = dtx_device_over_120;

                #endregion
               
            //各站最高温统计
            json.HightemputerDevlist1 = dtx;
            DataTable dtx_station = new DataTable("machinecount");
            dtx_station.Columns.Add("createtime", Type.GetType("System.String"));
            dtx_station.Columns.Add("stationname", Type.GetType("System.String"));
            dtx_station.Columns.Add("devicename", Type.GetType("System.String"));
            dtx_station.Columns.Add("alarmvalue", Type.GetType("System.String"));
            dtx_station.Columns.Add("offsetvalue", Type.GetType("System.String"));
            dtx_station.Columns.Add("offsetstatus", Type.GetType("System.String"));//超过80度
            dtx_station.Columns.Add("alarmstatus", Type.GetType("System.String"));//超过预警值
            string offsetstatus = "0";
            string alarmstatus = "0";
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            if (usertype == "0")
            {
                stationlist = stationservice.GetModelList("areaid='" + usermodel.areaid + "'");
            }
            if (usertype == "1")
            {
                stationlist = stationservice.GetModelList("fenbuid='" + usermodel.fenbuid + "'");
            }
            if (usertype == "2")
            {
                stationlist = stationservice.GetModelList("ywbid='" + usermodel.ywbid + "'");
            }
            if (usertype == "3")
            {
                stationlist = stationservice.GetModelList("");
            }           
            if (stationlist.Count > 0)
            {
                for (int i = 0; i < stationlist.Count; i++)
                {
                    string stationid = stationlist[i].stationid;
                    List<double> valuemaxs = new List<double>(); valuemaxs.Add(0);
                    List<string> creaatetimes = new List<string>(); creaatetimes.Add("");
                    List<Maticsoft.Model.device_infor> devices = new List<Maticsoft.Model.device_infor>(); devices.Add(null);
                    //获取变电站下的所有设备信息
                    List<Maticsoft.Model.image_record_history> imageList = new List<Maticsoft.Model.image_record_history>();
                    imageList = imageservice.GetModelList("deviceid in( SELECT deviceid FROM device_infor where stationid = '" + stationid + "')  and createtime >'" + startDate + "'and createtime < '" + endDate + "'  ORDER BY  CAST(valuemax AS DECIMAL) DESC");
                    if (imageList != null && imageList.Count > 0)
                    {
                        if (imageList[0] != null)
                        {
                            Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(imageList[0].deviceid);
                            if (devicemodel != null)
                            {                              
                                if (imageList[0].valuemax!="")
                                {
                                    if (double.Parse(imageList[0].valuemax)>=80)//超过80度，该温度值显示红色
                                    {
                                        offsetstatus = "1";
                                    }
                                    if (double.Parse(imageList[0].valuemax) >= double.Parse(devicemodel.offsetvalue))//超过预警值，该温度和告警值都显示红色
                                    {
                                        alarmstatus = "1";
                                    }
                                }                             
                                dtx_station.Rows.Add(new object[] { imageList[0].createtime.ToString(), devicemodel.stationname, devicemodel.devicename, imageList[0].valuemax + "℃", devicemodel.offsetvalue + "℃", offsetstatus, alarmstatus });
                            }
                        }

                    }               
                }
            }
            json.DeviceTongji3 = startDate + "至" + endDate + "期间，各站监测最高温度情况如下：";
            json.Station_top_value = dtx_station;

            
            #region 测温异常告警统计
            List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
            if (usertype == "0")
            {
                alarmlist = alarmservice.GetModelList("areaid='" + usermodel.areaid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' group by devicename  ORDER BY  CAST(alarmvalue AS DECIMAL) DESC");

            }
            if (usertype == "1")
            {
                alarmlist = alarmservice.GetModelList("fenbuid='" + usermodel.fenbuid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' group by devicename  ORDER BY  CAST(alarmvalue AS DECIMAL) DESC");
            }
            if (usertype == "2")
            {
                alarmlist = alarmservice.GetModelList("ywbid='" + usermodel.ywbid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "'  group by devicename  ORDER BY  CAST(alarmvalue AS DECIMAL) DESC");

            }
            if (usertype == "3")
            {
                alarmlist = alarmservice.GetModelList(" createtime>'" + timeStart + "' and createtime<'" + timeEnd + "'  group by devicename  ORDER BY  CAST(alarmvalue AS DECIMAL) DESC");

            }
            string sheader = "告警共" + alarmlist.Count().ToString() + "条：";

            json.AlarmTongji = sheader;

            DataTable alarmtable = new DataTable();
            alarmtable.Columns.Add("headerText", Type.GetType("System.String"));
            alarmtable.Columns.Add("image1", Type.GetType("System.String"));
            alarmtable.Columns.Add("image2", Type.GetType("System.String"));
            alarmtable.Columns.Add("image_week", Type.GetType("System.String"));
            alarmtable.Columns.Add("image_month", Type.GetType("System.String"));
            alarmtable.Columns.Add("image_history", Type.GetType("System.String"));
            alarmtable.Columns.Add("bottonText", Type.GetType("System.String"));
            if (alarmlist.Count>0)
            {
                for (int i = 0; i < alarmlist.Count; i++)
                {
                    string dengjifuhe = "无";
                    string querenrenyuan = "无";
                    if (alarmlist[i].fuhe != "" && alarmlist[i].fuhe != null)
                    {
                        dengjifuhe = alarmlist[i].fuhe;
                    }
                    if (alarmlist[i].mensurehuman != "" && alarmlist[i].mensurehuman != null)
                    {
                        querenrenyuan = alarmlist[i].mensurehuman;
                    }
                    string s1 = "";
                    string imagename = alarmlist[i].image_url;
                    string image1 = "";
                    string image2 = "";
                    if (imagename.Contains("~0~"))
                    {
                        image1 = imagename;
                        image2 = imagename.Replace("~0~", "~1~");
                    }
                    if (imagename.Contains("~1~"))
                    {
                        image2 = imagename;
                        image1 = imagename.Replace("~1~", "~0~");
                    }
                    if (imagename.Contains("~2~"))
                    {
                        image1 = imagename.Replace("~2~", "~0~");
                        image2 = imagename.Replace("~2~", "~1~");
                    }
                    Maticsoft.Model.device_infor devmmm = new Maticsoft.Model.device_infor();
                    devmmm = deviceservice.GetModel(alarmlist[i].deviceid);
                    if (devmmm != null)
                    {
                        string s2 = "";
                        string fuhe = devmmm.fuhe;
                        if (fuhe == "" || fuhe == null)
                            fuhe = "未填写";
                        s2 = alarmlist[i].stationname + "  " + alarmlist[i].devicename + "   " + alarmlist[i].alarmvalue + "℃(阈值：" + devmmm.offsetvalue + "℃) 负荷：" + fuhe + "告警时间：" + alarmlist[i].createtime.ToString();
                        if (image1 != "" || image2 != "")
                        {
                            string image_week = "";
                            //if(devmmm.weekmaxid!=""&&devmmm.weekmaxid!=null)
                            //{
                            //    if (null != historyservice.GetModel(devmmm.weekmaxid).image1)
                            //    {
                            //        if (historyservice.GetModel(devmmm.weekmaxid).image1 != null)
                            //            image_week = historyservice.GetModel(devmmm.weekmaxid).image1;
                            //    }
                            //}

                            string image_month = "";
                            //if(devmmm.monthmaxid!=""&&devmmm.monthmaxid!=null)
                            //{
                            //    if (null != historyservice.GetModel(devmmm.monthmaxid).image1)
                            //    {
                            //        if (historyservice.GetModel(devmmm.monthmaxid).image1 != null)
                            //            image_month = historyservice.GetModel(devmmm.monthmaxid).image1;
                            //    }
                            //}

                            string image_his = "";
                            //if(devmmm.historymaxid!=""&&devmmm.historymaxid!=null)
                            //{
                            //    if (null != historyservice.GetModel(devmmm.historymaxid).image1)
                            //    {
                            //        if (historyservice.GetModel(devmmm.historymaxid).image1 != null)
                            //            image_his = historyservice.GetModel(devmmm.historymaxid).image1;
                            //    }
                            //}


                            alarmtable.Rows.Add(new object[] { s1, image1, image2, image_week, image_month, image_his, s2 });

                        }
                    }

                }

            }
            json.DtAlarm = alarmtable;
            #endregion

            #region 趋势统计

            DataTable shengwentable = new DataTable();
            //shengwentable = null;
            json.QushiTongji = "过去一周持续升温的设备数量：0处。";// + shengwentable.Rows.Count.ToString() + "处";
            json.DtQushi = shengwentable;
            json.Downloadurl = "";
            #endregion
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));
            
        }

        [WebMethod(Description = "接口描述：查询郑州供电公司下所有变电站今日最高和当前最高以及当前变电站的告警数量，查询郑州供电公司下今天未确认告警总数量)")]

        public void getAllStationTop_alarmCount()
        {
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            List<youcejson> jsonlist = new List<youcejson>();
            qxstationtop qxjson = new qxstationtop();
            string areaname = "郑州供电公司";
            stationlist = stationservice.GetModelList("areaname = '"+areaname+"'");         
            if (stationlist.Count > 0)
            {                  
                TableAction action = new TableAction();
                for (int s = 0; s < stationlist.Count; s++)
                {
                    string stationid = stationlist[s].stationid;
                    if (stationid != "" && stationid!=null)
                    {
                        //删除没有设备的变电站 
                        Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                        int count = machineservice.GetRecordCount("stationid = '" + stationid + "'");
                        int machinemac = machineservice.GetRecordCount("machinemac = '" + "' and stationid = '" + stationid + "'");
                        if (machinemac == count)
                        {                                                
                            continue;
                        }
                        youcejson json = action.l_getAlarmStation1(stationid);
                        if (json != null)
                        {
                            jsonlist.Add(json);
                        }

                    }
                }
            }
    
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
            string isok = "1";
            alarmlist = alarmservice.GetModelList("areaname = '" + areaname + "'and createtime > '" + DateTime.Now.ToString("yyyy-MM-dd") + "' and isok='" + isok + "'");
            qxjson.jsonList = jsonlist;
            qxjson.alarmCount = alarmlist.Count.ToString();           
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(qxjson));
        }


        public int getMaxindex(List<double> list)
        {
            double a = list[0];
            int index = 0;//把假设的最大值索引赋值非index

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] > a)
                {
                    a = list[i];
                    index = i;//把较大值的索引赋值非index
                }
            }
            return index;
        }
        public static bool IsIncreasingMontonically<T>(List<T> list) where T : IComparable
        {
            return list.Zip(list.Skip(1), (a, b) => a.CompareTo(b) <= 0)
                .All(b => b);
        }
    }
}
