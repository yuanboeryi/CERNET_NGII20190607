﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.QXService
{
    public class qximagejson
    {
        int count = 0;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }
        DataTable table = new DataTable();

        public DataTable Table
        {
            get { return table; }
            set { table = value; }
        }
    }
}