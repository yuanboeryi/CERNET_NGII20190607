﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.QXService
{
    public class qxjson
    {
        string over_80_count = "";

        public string Over_80_count
        {
            get { return over_80_count; }
            set { over_80_count = value; }
        }
        DataTable dt_over_80 = new DataTable();

        public DataTable Dt_over_80
        {
            get { return dt_over_80; }
            set { dt_over_80 = value; }
        }
        string alarm_count = "";

        public string Alarm_count
        {
            get { return alarm_count; }
            set { alarm_count = value; }
        }
        DataTable dt_alarm = new DataTable();

        public DataTable Dt_alarm
        {
            get { return dt_alarm; }
            set { dt_alarm = value; }
        }
    }
}