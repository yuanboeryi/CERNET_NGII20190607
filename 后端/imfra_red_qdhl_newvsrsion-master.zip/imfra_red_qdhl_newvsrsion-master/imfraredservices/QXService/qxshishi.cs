﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.QXService
{
    public class qxshishi
    {
        string stationname = "";

        public string Stationname
        {
            get { return stationname; }
            set { stationname = value; }
        }
        DataTable devicelist = new DataTable();

        public DataTable Devicelist
        {
            get { return devicelist; }
            set { devicelist = value; }
        }
    }
}