﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.QXService
{
    public class qxshishijson
    {
        List<qxshishi> devicelist = new List<qxshishi>();

        public List<qxshishi> Devicelist
        {
            get { return devicelist; }
            set { devicelist = value; }
        }
    }
}