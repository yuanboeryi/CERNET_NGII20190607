﻿using imfraredservices.TableService;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.QXService
{
    public class qxstationtop
    {
        string alarmcount = "";

        public string alarmCount
        {
            get { return alarmcount; }
            set { alarmcount = value; }
        }
        List<youcejson> jsonlist = new List<youcejson>();

        public List<youcejson> jsonList
        {
            get { return jsonlist; }
            set { jsonlist = value; }
        }
    }
}