﻿using imfraredservices.TableService;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.QXService
{
    public class trackDevicejson
    {
        List<string[]> _ywblist = new List<string[]>();

        public List<string[]> Ywblist
        {
            get { return _ywblist; }
            set { _ywblist = value; }
        }
        List<string[]> _stationlist = new List<string[]>();

        public List<string[]> Stationlist
        {
            get { return _stationlist; }
            set { _stationlist = value; }
        }
        string _stationcount = "";

        public string Stationcount
        {
            get { return _stationcount; }
            set { _stationcount = value; }
        }
        string _machinecount = "";

        public string Machinecount
        {
            get { return _machinecount; }
            set { _machinecount = value; }
        }

        string _devicecount = "";

        public string Devicecount
        {
            get { return _devicecount; }
            set { _devicecount = value; }
        }
        private string pointdevicecount = "";

        public string Pointdevicecount
        {
            get { return pointdevicecount; }
            set { pointdevicecount = value; }
        }

        string _alarmcount = "";

        public string Alarmcount
        {
            get { return _alarmcount; }
            set { _alarmcount = value; }
        }
        DataTable devicebili = new DataTable();

        public DataTable Devicebili
        {
            get { return devicebili; }
            set { devicebili = value; }
        }
        List<roundDevicejson> jsonlist = new List<roundDevicejson>();

        public List<roundDevicejson> Jsonlist
        {
            get { return jsonlist; }
            set { jsonlist = value; }
        }
    }
}