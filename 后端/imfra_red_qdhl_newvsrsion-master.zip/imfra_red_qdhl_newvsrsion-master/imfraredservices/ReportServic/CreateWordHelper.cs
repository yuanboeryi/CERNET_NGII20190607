﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NPOI.OpenXmlFormats.Wordprocessing;
using NPOI.XWPF.UserModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace imfraredservices.ReportServic
{
    public class CreateWordHelper
    {
        public static JsonHelper helper;
        public static JObject jObject = null;
        public static CT_RPr StaticCTR;
        /// <summary>
        /// 定义模板路径
        /// </summary>
        public string TempPath = AppDomain.CurrentDomain.BaseDirectory + "Word模板.doc";


        /// <summary>
        /// 初始化 jObject
        /// </summary>
        /// <param name="Json"></param>
        public CreateWordHelper(string Json)
        {
            helper = new JsonHelper();
            jObject = helper.CreeateFile(Json);
        }

        /// <summary>
        /// 开始创建Word
        /// </summary>
        public string  TryCreateword()
        {
            
            string SaveWordPath = CreateWordPath();
            // 保存路径
            string SaveWordPathFile = SaveWordPath.Split('#')[0];
            // 后缀名称
            string SaveWordPathExistsFileName= SaveWordPath.Split('#')[1];
            string DownLoadFilePath ="http://116.255.207.148:8080/report/"+ SaveWordPathExistsFileName;
            //定义段落要使用的字段 与返回的Json保持一致
            List<string> AddParagraph = new List<string>()
            {
              //"time",
              "AlarmTongji",
              "Betweentime",
              "DeviceTongji",
              "DeviceTongji2",
              "DeviceTongji3",
              "Over_80_tongji",
              "Over_90_tongji",
              "Over_100_tongji",
              "Over_120_tongji",
              "DeviceTongji1",
              "QushiTongji",
            };
            //获取模板
            using (FileStream stream = File.OpenRead(TempPath))
            {
                XWPFDocument doc = new XWPFDocument(stream);
                var GetParagraphList = doc.Paragraphs.ToList();
                // 遍历所有的段落
                foreach (var item in doc.Paragraphs)
                {
                    //段落中进行修改值
                    foreach (var la in AddParagraph)
                    {
                        string StrJson = Readjson(la);
                        // 开始替换段落值
                        ReplaceKey(item, la, StrJson);
                    }
                }

                //开始针对Table表格设置  异步处理方式
                WriteTable(doc);
                
                //进行保存 同时进行覆盖
                FileStream outFile = new FileStream(SaveWordPathFile, FileMode.Create);
                doc.Write(outFile);
                // 关闭流
                stream.Close();
                outFile.Close();
            }

            return DownLoadFilePath;
        }

        private void WriteTable(XWPFDocument doc)
        {
            /*  
              doc,当前第几个表格,表格对应的Json数据
             */
            //获取或者设置第一个表格
            Task.Run(() => ObtainOneTable(doc, 0, "Station_top_value")).Wait();
            //获取第二个表格
            Task.Run(() => ObtainTwoTable(doc, 1, "Over_80_list")).Wait();
            //获取第三个表格
            Task.Run(() => ObtainTwoTable(doc, 2, "Over_90_list")).Wait();
            //获取第四个表格
            Task.Run(() => ObtainTwoTable(doc, 3, "Over_100_list")).Wait();
            //获取第5个表格
            Task.Run(() => ObtainTwoTable(doc, 4, "Over_120_list")).Wait();
            //获取第6个表格
            Task.Run(() => ObtainFiveTable(doc, 5, "DtAlarm")).Wait();

        }

        /// <summary>
        /// 表格234公用
        /// </summary>
        /// <param name="doc">文档</param>
        /// <param name="TableNum">当前使用的第几个表格</param>
        /// <param name="TableName">对应json标签中的名字</param>
        private void ObtainTwoTable(XWPFDocument doc, int TableNum, string TableName)
        {
            /*
             2,Over_80_list  1 
             3,Over_90_list  2
             4,Over_100_list 3
             5,Over_120_list 4
             */
            int Num = 0;
            // 表格样式公用2345
            var tables = doc.Tables[TableNum];
            XWPFTableRow Zero = tables.GetRow(0);
            XWPFTableRow tableRowOne = tables.GetRow(1);
            XWPFTableRow tableRowTwo = tables.GetRow(2);
            var JsonTable = ReturnJsonToTable(TableName);
            JsonTable.TableName = TableName;

            for (int i = 0; i < JsonTable.Rows.Count; i++)
            {
                AddRowContionCellStyle(1, Zero, tables);
                AddRowContionCellStyle(1, tableRowOne, tables);
                AddRowContionCellStyle(1, tableRowTwo, tables);
            }
            if (JsonTable.Rows.Count>0)
            {
                tables.RemoveRow(tables.Rows.IndexOf(tableRowOne));
                tables.RemoveRow(tables.Rows.IndexOf(Zero));
                tables.RemoveRow(tables.Rows.IndexOf(tableRowTwo));
                ParagraphTable(tables, JsonTable, Num);
            }
            else
            {
                tables.RemoveRow(tables.Rows.IndexOf(tableRowOne));
                tables.RemoveRow(tables.Rows.IndexOf(Zero));
                tables.RemoveRow(tables.Rows.IndexOf(tableRowTwo));
                #region 不在重新创建表格
                ////第一个单元格
                //var TableZero = Zero;
                //var cellsZero = TableZero.GetTableCells().ToList();
                //foreach (var item in cellsZero)
                //{
                //    var Paragraphs = item.Paragraphs;
                //    foreach (var pars in Paragraphs)
                //    {
                //        var GetParas = pars.Text;
                //        if (GetParas.Contains("${"))
                //        {
                //            //获取开始位置
                //            var IndexOf = GetParas.IndexOf("$");
                //            if (IndexOf == 0)
                //            {
                //                var LastIndexOf = GetParas.IndexOf("}");
                //                GetParas = GetParas.Remove(IndexOf, LastIndexOf - IndexOf + 1);
                //                pars.ReplaceText(pars.Text, GetParas);
                //            }
                //            else
                //            {
                //                // 从0开始截取字符串,文本文件
                //                int Sub = 0;
                //                string StrText = GetParas.Substring(0, IndexOf);
                //                // 直接将当前的text替换问文本文件
                //                pars.ReplaceText(pars.Text, StrText);
                //            }
                //        }
                //    }
                //}

                ////第二个单元格
                //var TableOne = tableRowOne;
                //var cellOne = TableOne.GetTableCells().ToList();
                //foreach (var item in cellOne)
                //{
                //    var Paragraphs = item.Paragraphs;
                //    foreach (var pars in Paragraphs)
                //    {
                //        var GetParas = pars.Text;
                //        if (GetParas.Contains("${"))
                //        {
                //            //获取开始位置
                //            var IndexOf = GetParas.IndexOf("$");
                //            if (IndexOf == 0)
                //            {
                //                var LastIndexOf = GetParas.IndexOf("}");
                //                GetParas = GetParas.Remove(IndexOf, LastIndexOf - IndexOf + 1);
                //                pars.ReplaceText(pars.Text, GetParas);
                //            }
                //            else
                //            {
                //                // 从0开始截取字符串,文本文件
                //                int Sub = 0;
                //                string StrText = GetParas.Substring(0, IndexOf);
                //                // 直接将当前的text替换问文本文件
                //                pars.ReplaceText(pars.Text, StrText);
                //            }
                //        }
                //    }
                //}


                //// 第三个单元格
                //var TableTwo = tableRowTwo;
                //var cellsTwo = TableTwo.GetTableCells().ToList();
                //foreach (var item in cellsTwo)
                //{
                //    var Paragraphs = item.Paragraphs;
                //    foreach (var pars in Paragraphs)
                //    {
                //        var GetParas = pars.Text;
                //        if (GetParas.Contains("${"))
                //        {
                //            //获取开始位置
                //            var IndexOf = GetParas.IndexOf("$");
                //            if (IndexOf == 0)
                //            {
                //                var LastIndexOf = GetParas.IndexOf("}");
                //                GetParas = GetParas.Remove(IndexOf, LastIndexOf - IndexOf + 1);
                //                pars.ReplaceText(pars.Text, GetParas);
                //            }
                //            else
                //            {
                //                // 从0开始截取字符串,文本文件
                //                int Sub = 0;
                //                string StrText = GetParas.Substring(0, IndexOf);
                //                // 直接将当前的text替换问文本文件
                //                pars.ReplaceText(pars.Text, StrText);
                //            }
                //        }
                //    }
                //}
                #endregion
                // 保持
            }

        }

        /// <summary>
        /// 第五个表格
        /// </summary>
        /// <param name="doc"></param>
        private void ObtainFiveTable(XWPFDocument doc, int TableNum, string TableName)
        {
            int Num = 0;
            // DtAlarmList 5
            var tables = doc.Tables[TableNum];
            XWPFTableRow Zero = tables.GetRow(0);
            XWPFTableRow tableRowOne = tables.GetRow(1);
            XWPFTableRow tableRowTwo = tables.GetRow(2);
            XWPFTableRow tableRowThree = tables.GetRow(3);
            XWPFTableRow tableRowFor = tables.GetRow(4);

            var JsonTable = ReturnJsonToTable(TableName);
            JsonTable.TableName = TableName;
            for (int i = 0; i < JsonTable.Rows.Count; i++)
            {
                AddRowContionCellStyle(1, Zero, tables);
                AddRowContionCellStyle(1, tableRowOne, tables);
                AddRowContionCellStyle(1, tableRowTwo, tables);
                AddRowContionCellStyle(1, tableRowThree, tables);
                AddRowContionCellStyle(1, tableRowFor, tables);
            }
            if (JsonTable.Rows.Count>0)
            {
                tables.RemoveRow(tables.Rows.IndexOf(tableRowOne));
                tables.RemoveRow(tables.Rows.IndexOf(Zero));
                tables.RemoveRow(tables.Rows.IndexOf(tableRowTwo));
                tables.RemoveRow(tables.Rows.IndexOf(tableRowThree));
                tables.RemoveRow(tables.Rows.IndexOf(tableRowFor));
                ParagraphTable(tables, JsonTable, Num, 5);
            }
            else
            {
                tables.RemoveRow(tables.Rows.IndexOf(tableRowOne));
                tables.RemoveRow(tables.Rows.IndexOf(Zero));
                tables.RemoveRow(tables.Rows.IndexOf(tableRowTwo));
                tables.RemoveRow(tables.Rows.IndexOf(tableRowThree));
                tables.RemoveRow(tables.Rows.IndexOf(tableRowFor));
                #region 不再重新绘制表格
                ////第一个单元格
                //var TableZero = Zero;
                //var cellsZero = TableZero.GetTableCells().ToList();
                //foreach (var item in cellsZero)
                //{
                //    var Paragraphs = item.Paragraphs;
                //    foreach (var pars in Paragraphs)
                //    {
                //        var GetParas = pars.Text;
                //        if (GetParas.Contains("${"))
                //        {
                //            //获取开始位置
                //            var IndexOf = GetParas.IndexOf("$");
                //            if (IndexOf == 0)
                //            {
                //                var LastIndexOf = GetParas.IndexOf("}");
                //                GetParas = GetParas.Remove(IndexOf, LastIndexOf - IndexOf + 1);
                //                pars.ReplaceText(pars.Text, GetParas);
                //            }
                //            else
                //            {
                //                // 从0开始截取字符串,文本文件
                //                int Sub = 0;
                //                string StrText = GetParas.Substring(0, IndexOf);
                //                // 直接将当前的text替换问文本文件
                //                pars.ReplaceText(pars.Text, StrText);
                //            }
                //        }
                //    }
                //}

                ////第二个单元格
                //var TableOne = tableRowOne;
                //var cellOne = TableOne.GetTableCells().ToList();
                //foreach (var item in cellOne)
                //{
                //    var Paragraphs = item.Paragraphs;
                //    foreach (var pars in Paragraphs)
                //    {
                //        var GetParas = pars.Text;
                //        if (GetParas.Contains("${"))
                //        {
                //            //获取开始位置
                //            var IndexOf = GetParas.IndexOf("$");
                //            if (IndexOf == 0)
                //            {
                //                var LastIndexOf = GetParas.IndexOf("}");
                //                GetParas = GetParas.Remove(IndexOf, LastIndexOf - IndexOf + 1);
                //                pars.ReplaceText(pars.Text, GetParas);
                //            }
                //            else
                //            {
                //                // 从0开始截取字符串,文本文件
                //                int Sub = 0;
                //                string StrText = GetParas.Substring(0, IndexOf);
                //                // 直接将当前的text替换问文本文件
                //                pars.ReplaceText(pars.Text, StrText);
                //            }
                //        }
                //    }
                //}


                //// 第三个单元格
                //var TableTwo = tableRowTwo;
                //var cellsTwo = TableTwo.GetTableCells().ToList();
                //foreach (var item in cellsTwo)
                //{
                //    var Paragraphs = item.Paragraphs;
                //    foreach (var pars in Paragraphs)
                //    {
                //        var GetParas = pars.Text;
                //        if (GetParas.Contains("${"))
                //        {
                //            //获取开始位置
                //            var IndexOf = GetParas.IndexOf("$");
                //            if (IndexOf == 0)
                //            {
                //                var LastIndexOf = GetParas.IndexOf("}");
                //                GetParas = GetParas.Remove(IndexOf, LastIndexOf - IndexOf + 1);
                //                pars.ReplaceText(pars.Text, GetParas);
                //            }
                //            else
                //            {
                //                // 从0开始截取字符串,文本文件
                //                int Sub = 0;
                //                string StrText = GetParas.Substring(0, IndexOf);
                //                // 直接将当前的text替换问文本文件
                //                pars.ReplaceText(pars.Text, StrText);
                //            }
                //        }
                //    }
                //}


                //// 第四个单元格
                //var TableFor = tableRowFor;
                //var cellsFor = TableFor.GetTableCells().ToList();
                //foreach (var item in cellsFor)
                //{
                //    var Paragraphs = item.Paragraphs;
                //    foreach (var pars in Paragraphs)
                //    {
                //        var GetParas = pars.Text;
                //        if (GetParas.Contains("${"))
                //        {
                //            //获取开始位置
                //            var IndexOf = GetParas.IndexOf("$");
                //            if (IndexOf == 0)
                //            {
                //                var LastIndexOf = GetParas.IndexOf("}");
                //                GetParas = GetParas.Remove(IndexOf, LastIndexOf - IndexOf + 1);
                //                pars.ReplaceText(pars.Text, GetParas);
                //            }
                //            else
                //            {
                //                // 从0开始截取字符串,文本文件
                //                int Sub = 0;
                //                string StrText = GetParas.Substring(0, IndexOf);
                //                // 直接将当前的text替换问文本文件
                //                pars.ReplaceText(pars.Text, StrText);
                //            }
                //        }
                //    }
                //}
                #endregion
            }

        }

        /// <summary>
        /// 创建第一个表格
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="TableNum"></param>
        /// <param name="TableName"></param>
        private void ObtainOneTable(XWPFDocument doc, int TableNum, string TableName)
        {
            int Num = 1;
            // 表格公用16

            /*
             1表格 Station_top_value 0
             */
            var tables = doc.Tables[TableNum];
            XWPFTableRow tableRow = tables.GetRow(1);
            tables.RemoveRow(tables.Rows.IndexOf(tableRow));
            var JsonTable = ReturnJsonToTable(TableName);
            JsonTable.TableName = TableName;
            if (JsonTable.Rows.Count>0)
            {
                AddRowNotContionCellStyle(JsonTable.Rows.Count, tableRow, tables);
                ParagraphTable(tables, JsonTable, Num);
            }
        }

        /// <summary>
        /// 针对Table中的字段与Json中的字段进行对比替换值
        /// </summary>
        /// <param name="tables"></param>
        /// <param name="jsonTable"></param>
        /// <param name="num"></param>
        public void ParagraphTable(XWPFTable tables, DataTable JsonTable, int Num, int TableFive = 0)
        {
            for (int i = Num; i < tables.Rows.Count; i++)
            {
                var row = tables.Rows[i];
                //tables.SetColumnWidth(i, 6 * 256);

                var cell = row.GetTableCells();
                for (int j = 0; j < cell.Count; j++)
                {
                    var NewParagraphs = cell[j].Paragraphs;
                    for (int k = 0; k < NewParagraphs.Count; k++)
                    {
                        var para = NewParagraphs[k];
                        var text = para.ParagraphText;

                        ReplaceKeyWord(i, JsonTable, para, Num, TableFive);
                    }
                }
            }
        }


        /// <summary>
        /// 替换Word中的值
        /// </summary>
        /// <param name="I">第几行</param>
        /// <param name="JsonTable">Tab</param>
        /// <param name="para">段落</param>
        /// <param name="Num">Word中从第几行开始匹配</param>
        /// <param name="TableFive">当前是第五个表格吗</param>
        private void ReplaceKeyWord(int I, DataTable JsonTable, XWPFParagraph para, int Num, int TableFive = 0)
        {
            //相差了1
            for (int i = 0; i < JsonTable.Rows.Count; i++)
            {
                for (int j = 0; j < JsonTable.Columns.Count; j++)
                {
                    string LableText = JsonTable.Rows[i][j].ToString();
                    string Lable = JsonTable.TableName + "." + JsonTable.Columns[j].ColumnName;

                    if (Num == 1)
                    {
                        if (I == i + 1)
                        {
                            string text = para.ParagraphText;
                            //var  CTP= para.GetCTP();
                            //CTP.AddNewPPr().AddNewSpacing().line = "500";
                            string LableConvert = "${" + Lable + "}";
                            if (LableConvert == text)
                            {
                                string alarmstatus = JsonTable.Rows[i]["alarmstatus"].ToString();
                                string offsetstatus = JsonTable.Rows[i]["offsetstatus"].ToString();
                                //温度
                                if (Lable == JsonTable.TableName + "." + "alarmvalue")
                                {
                                    if (alarmstatus == "1")
                                    {
                                        var GetRun = para.Runs.ToList();
                                        GetRun.ForEach(m =>
                                        {
                                            m.SetColor("FF0000");

                                        });
                                    }
                                    else if (alarmstatus == "0")
                                    {
                                        if (offsetstatus == "1")
                                        {
                                            var GetRun = para.Runs.ToList();
                                            GetRun.ForEach(m =>
                                            {
                                                m.SetColor("FF0000");

                                            });
                                        }
                                    }
                                }
                                // 告警值
                                else if (Lable == JsonTable.TableName + "." + "offsetvalue")
                                {
                                    if (alarmstatus == "1")
                                    {
                                        var GetRun = para.Runs.ToList();
                                        GetRun.ForEach(m =>
                                        {
                                            m.SetColor("FF0000");

                                        });
                                    }
                                }
                                para.ReplaceText(text, LableText);
                                return;
                            }
                        }
                    }

                    //表格2345
                    if (Num == 0)
                    {
                        //表格2345
                        if (TableFive == 0)
                        {
                            string text = para.ParagraphText;
                            int Merchant = I;
                            if (Merchant % 3 == 0)
                            {
                                Merchant = Merchant / 3;
                            }
                            else
                            {
                                Merchant = Convert.ToInt32(Math.Floor(Convert.ToDouble(Merchant) / Convert.ToDouble(3)));
                            }
                            if (Merchant <= 0)
                            {
                                Merchant = 0;
                            }
                            if (text.Contains("${"))
                            {
                                string LableConvert = text;
                                text = text.Replace("${", "");
                                text = text.Replace("}", "");
                                text = text.Replace(JsonTable.TableName + ".", "");
                                text = text.Trim();

                                var Value = JsonTable.Rows[Convert.ToInt32(Merchant)][text].ToString();
                                if (Value.Contains("http://") || Value.Contains("https://"))
                                {

                                    string ImaeName = "1.jpg";
                                    try
                                    {
                                        int Length = Value.Length;
                                        int LastOf = Value.LastIndexOf("~");
                                        if (LastOf != -1)
                                        {
                                            int ShengYu = Length - LastOf;
                                            ImaeName = Value.Remove(0, LastOf + 1);
                                        }
                                        //模拟web请求获取图片
                                        WebResponse response = null;
                                        Stream stream = null;
                                        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Value);
                                        response = request.GetResponse();
                                        stream = response.GetResponseStream();
                                        para.CreateRun().AddPicture(stream, (int)NPOI.SS.UserModel.PictureType.JPEG, ImaeName, (int)(202 * 9525), (int)(180 * 9525));
                                        para.ReplaceText(LableConvert, "");
                                    }
                                    catch (Exception e)
                                    {
                                        para.ReplaceText(LableConvert, "");
                                    }

                                }
                                else
                                {
                                    para.ReplaceText(LableConvert, Value);
                                }
                            }
                            return;
                        }
                        //表格6
                        else if (TableFive == 5)
                        {
                            string text = para.ParagraphText;

                            if (text.Contains("${"))
                            {
                                int Merchant = I;
                                if (Merchant % 5 == 0)
                                {
                                    Merchant = Merchant / 5;
                                }
                                else
                                {
                                    Merchant = Convert.ToInt32(Math.Floor(Convert.ToDouble(Merchant) / Convert.ToDouble(5)));
                                }
                                if (Merchant <= 0)
                                {
                                    Merchant = 0;
                                }

                                string LableConvert = text;
                                text = text.Replace("${", "");
                                text = text.Replace("}", "");
                                text = text.Replace(JsonTable.TableName + ".", "");
                                text = text.Trim();
                                //bottonText
                                var Value = JsonTable.Rows[Convert.ToInt32(Merchant)][text].ToString();
                                if (Value.Contains("http://") || Value.Contains("https://"))
                                {

                                    //图片的文件流   图片类型   图片名称   设置的宽度以及高度
                                    //r2.AddPicture(picData, (int)PictureType.PNG, "testImg", widthEmus, heightEmus);
                                    //  Value = "http://122.114.204.83/image/b827eb4ffb4e/2020-11-19/2020-11-19 14&00&13~b827eb4ffb4e~0.0~27.5~80.4~0~1.jpg";
                                    string ImaeName = "1.jpg";
                                    try
                                    {
                                        int Length = Value.Length;
                                        int LastOf = Value.LastIndexOf("~");
                                        if (LastOf != -1)
                                        {
                                            int ShengYu = Length - LastOf;
                                            ImaeName = Value.Remove(0, LastOf + 1);
                                        }
                                        WebResponse response = null;
                                        Stream stream = null;
                                        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Value);
                                        response = request.GetResponse();
                                        stream = response.GetResponseStream();                                                        //  (int)(102.0 * 9525), (int)(126.0 * 9525)
                                        para.CreateRun().AddPicture(stream, (int)NPOI.SS.UserModel.PictureType.JPEG, ImaeName, (int)(202 * 9525), (int)(180 * 9525));
                                        para.ReplaceText(LableConvert, "");
                                        //para.ReplaceText(LableConvert, Value);
                                    }
                                    catch (Exception e)
                                    {
                                        para.ReplaceText(LableConvert, Value);
                                    }
                                }
                                else
                                {
                                    para.ReplaceText(LableConvert, Value);
                                }
                                return;
                            }

                        }
                    }

                }
            }
        }


        /// <summary>
        /// 复制行,但是不复制样式
        /// </summary>
        /// <param name="count"></param>
        /// <param name="tableRow"></param>
        /// <param name="tables"></param>
        private void AddRowNotContionCellStyle(int Count, XWPFTableRow tableRow, XWPFTable tables)
        {
            CT_Row ctrow = tableRow.GetCTRow();
            for (int j = 0; j < Count; j++)
            {
                CT_Row targetRow = new CT_Row();

                //复制cell结构
                foreach (CT_Tc item in ctrow.Items)
                {
                    CT_Tc addTc = targetRow.AddNewTc();
                    addTc.tcPr = item.tcPr;//cell样式,只包括列宽和cell对齐方式

                    IList<CT_P> list_p = item.GetPList();

                    foreach (var p in list_p)
                    {
                        CT_P addP = addTc.AddNewP();
                        addP.pPr = p.pPr;//段落样式
                        IList<CT_R> list_r = p.GetRList();
                        foreach (CT_R r in list_r)
                        {
                            CT_R addR = addP.AddNewR();
                            //addR.rPr = r.rPr;//run样式 包括字体等
                            StaticCTR = r.rPr;
                            List<CT_Text> list_text = r.GetTList();
                            foreach (CT_Text text in list_text)
                            {
                                CT_Text addText = addR.AddNewT();
                                addText.space = text.space;
                                addText.Value = text.Value;
                            }
                        }
                    }
                }
                //增加数据行
                XWPFTableRow mrow = new XWPFTableRow(targetRow, tables);
                tables.AddRow(mrow);
            }

        }

        /// <summary>
        /// 复制行,同时复制样式
        /// </summary>
        /// <param name="Count"></param>
        /// <param name="tableRow"></param>
        /// <param name="tables"></param>
        public  void AddRowContionCellStyle(int Count, XWPFTableRow tableRow, XWPFTable tables)
        {
            CT_Row ctrow = tableRow.GetCTRow();
            for (int j = 0; j < Count; j++)
            {
                CT_Row targetRow = new CT_Row();

                //复制cell结构
                foreach (CT_Tc item in ctrow.Items)
                {
                    CT_Tc addTc = targetRow.AddNewTc();
                    addTc.tcPr = item.tcPr;//cell样式,只包括列宽和cell对齐方式
                    
                    IList<CT_P> list_p = item.GetPList();

                    foreach (var p in list_p)
                    {
                        CT_P addP = addTc.AddNewP();
                        addP.pPr = p.pPr;//段落样式
                        IList<CT_R> list_r = p.GetRList();
                        foreach (CT_R r in list_r)
                        {
                            CT_R addR = addP.AddNewR();
                            addR.rPr = r.rPr;//run样式 包括字体等
                            List<CT_Text> list_text = r.GetTList();
                            foreach (CT_Text text in list_text)
                            {
                                CT_Text addText = addR.AddNewT();
                                addText.space = text.space;
                                addText.Value = text.Value;
                            }
                        }
                    }

                }
                //增加数据行
                XWPFTableRow mrow = new XWPFTableRow(targetRow, tables);
                tables.AddRow(mrow);
            }
        }

        /// <summary>
        /// 通过Key值返回Table
        /// </summary>
        /// <param name="Key"></param>
        /// <returns></returns>
        public DataTable ReturnJsonToTable(string Key)
        {
            DataTable table = null;
            if (Key!="")
            {
                table = new DataTable();
                string JsonMsg = Readjson(Key);
                if (!string.IsNullOrEmpty(JsonMsg))
                {
                    table = JsonToDataTable(JsonMsg);
                }
               
            }
            return table;
        }
        /// <summary>
        /// 将Json转化为DataTable
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        public static DataTable JsonToDataTable(string json)
        {
            DataTable table = new DataTable();
            //JsonStr为Json字符串
            JArray array = JsonConvert.DeserializeObject(json) as JArray;//反序列化为数组
            if (array.Count > 0)
            {
                StringBuilder columns = new StringBuilder();

                JObject objColumns = array[0] as JObject;
                //构造表头
                foreach (JToken jkon in objColumns.AsEnumerable<JToken>())
                {
                    string name = ((JProperty)(jkon)).Name;
                    columns.Append(name + ",");
                    table.Columns.Add(name);
                }
                //向表中添加数据
                for (int i = 0; i < array.Count; i++)
                {
                    DataRow row = table.NewRow();
                    JObject obj = array[i] as JObject;
                    foreach (JToken jkon in obj.AsEnumerable<JToken>())
                    {

                        string name = ((JProperty)(jkon)).Name;
                        string value = ((JProperty)(jkon)).Value.ToString();
                        row[name] = value;
                    }
                    table.Rows.Add(row);
                }
            }
            return table;
        }

        /// <summary>
        /// 替换段落值
        /// </summary>
        /// <param name="para"></param>
        /// <param name="Lable"></param>
        /// <param name="LableText"></param>
        private void ReplaceKey(XWPFParagraph para, string Lable, string LableText)
        {
            string text = para.ParagraphText;
            var runs = para.Runs;
            string styleid = para.Style;
            for (int i = 0; i < runs.Count; i++)
            {
                var run = runs[i];
                text = run.ToString();
                string CreateLable = "${" + Lable + "}";
                if (text.Contains(CreateLable))
                {
                    runs[i].SetText(LableText, 0);
                }
                else
                {
                    runs[i].SetText(text, 0);
                }
            }
        }

        /// <summary>
        /// 通过jsonKey值返回Value
        /// </summary>
        /// <param name="la"></param>
        /// <returns></returns>
        private string Readjson(string Key)
        {
            string StrMsg = jObject[Key].ToString();
            return StrMsg;
        }

        /// <summary>
        /// 创建Word路径
        /// </summary>
        /// <returns></returns>
        public string CreateWordPath()
        {
            // 设置保存的路径
            string SaveFilePath = @"D:\infrared_new_service\report\";
            //string SaveFilePath = AppDomain.CurrentDomain.BaseDirectory.ToString() + "WordFile";
            if (Directory.Exists(SaveFilePath) == false)
            {
                Directory.CreateDirectory(SaveFilePath);
            }
            string ExistsFileName = @"红外热成像测温报告"+DateTime.Now.ToString("yyyy-MM-dd")+".doc";
            string CompletePath = SaveFilePath + ExistsFileName;
            //创建Doc文件
            if (File.Exists(CompletePath) == false)
            {
                File.Create(CompletePath).Close();
            }
            return SaveFilePath+ExistsFileName+"#"+ExistsFileName;
        }
    }
}