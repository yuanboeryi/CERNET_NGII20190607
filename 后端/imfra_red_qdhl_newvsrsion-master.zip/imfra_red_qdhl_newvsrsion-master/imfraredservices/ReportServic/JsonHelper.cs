﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace imfraredservices.ReportServic
{

    /// <summary>
    /// JsonHelp类
    /// </summary>
    public class JsonHelper
    {

        public static string StrJson = string.Empty;

        public JsonHelper()
        {

        }
        private static JObject jObject = null;
        public string this[string key]
        {
            get
            {
                string str = "";
                if (jObject != null)
                {
                    str = GetValue(key);
                }
                return str;
            }
        }
        public JsonHelper(string path)
        {
            StreamReader streamReader = new StreamReader(path, Encoding.Default);
            string jsonRoot = streamReader.ReadToEnd();  //读全部json
            jObject = JsonConvert.DeserializeObject<dynamic>(jsonRoot);  //转json对象 
        }
        public T GetValue<T>(string key) where T : class
        {
            return JsonConvert.DeserializeObject<T>(jObject.SelectToken(key).ToString());
        }
        public string GetValue(string key)
        {
            return Regex.Replace((jObject.SelectToken(key).ToString()), @"\s", "");
        }

        public JObject CreeateFile(string Str = "")
        {
            if (Str == string.Empty)
            {
                return null;
            }
            else
            {
                jObject = JObject.Parse(Str);
            }
            return jObject;
        }
    }
}