﻿using Aspose.Words;
using Aspose.Words.Drawing;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace imfraredservices.ReportServic
{
    public class ReportAction
    {
        #region 设备报告
        Maticsoft.BLL.city_infor cityservice = new Maticsoft.BLL.city_infor();
        Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
        DataTable dt = new DataTable();
        devicereportjson json_Save = new devicereportjson();
        string sx1 = "";
        string sx2 = "";
        string manager1 = "";
        string manager2 = "";
        string manager3 = "";
        string currentid = "";

        public string getDeviceReport(string alarmid)
        {
            currentid = alarmid;
            string reportid = "";
            devicereportjson json = new devicereportjson();

            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            Maticsoft.Model.alarm_push_infor devicealarmmodel = new Maticsoft.Model.alarm_push_infor();
            devicealarmmodel = alarmservice.GetModel(alarmid);
            reportid = devicealarmmodel.report_device_id;
            if (devicealarmmodel == null)
                return "0";
            string deviceid = devicealarmmodel.deviceid;
            Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
            devicemodel = deviceservice.GetModel(deviceid);
            string ywbid = devicemodel.ywbid;
            string devicetype = devicemodel.ysdtype;
            string fenbuname = devicemodel.fenbuname;
            string fenbuid = devicemodel.fenbuid;
            string ywbname = devicemodel.ywbname;
            string stationname = devicemodel.stationname;
            string stationid = devicemodel.stationid;
            string devicename = devicemodel.devicename;
            string devicelevel = devicemodel.ysdlevel;
            string machineid = devicemodel.machineid;
            string buildingid = devicemodel.buildingid;
            string fuhe = devicemodel.fuhe;
            string ysdname = devicemodel.ysdname;
            string ysdid = devicemodel.ysdindex;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            System.DateTime alarmtime = Convert.ToDateTime(devicealarmmodel.createtime.ToString(), dtFormat);
            DateTime dttoday = (DateTime)devicemodel.createtime;
            string alarmtemp = devicealarmmodel.alarmvalue;
            string machinename = devicemodel.machinename;
            Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
            string machinecode = macser.GetModel(machineid).machinecode;
            string buildingname = devicemodel.buildingname;
            string image1 = devicemodel.image_high;
            string image2 = devicemodel.image_mix;
            string image3 = devicemodel.image_red;
            string templist_24 = "";
            string today = devicealarmmodel.alarmvalue;
            string yestoday = devicealarmmodel.alarmvalue;
            string week = devicealarmmodel.alarmvalue;
            string month = devicealarmmodel.alarmvalue;
            string history = devicealarmmodel.alarmvalue;
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();
            //            historylist = historyservice.GetModelList("deviceid='"+deviceid+"' and createtime>'"+alarmtime.Date.AddDays(-System.DateTime.Now.Day).ToString()+"' order by createtime desc");
            historylist = historyservice.GetModelList("deviceid='" + deviceid + "' and createtime>'" + alarmtime.Date.AddDays(-30).ToString() + "' order by createtime desc");
            historylist.Reverse();
            string startTime = "";
            string templist_30 = "";//此处需要根据设备id去历史记录里面查最近30条
            if (historylist.Count() > 0)
            {
                startTime = historylist[0].createtime.Value.Hour.ToString();
                //templist_30 += dateold+";"+ historylist[0].createtime.Value.Day.ToString() + ";" + historylist[0].valuemax + ",";
                List<DateTime> datelist = new List<DateTime>();
                List<string> maxvaluelist = new List<string>();
                try
                {
                    //for (int i = 0; i < System.DateTime.Now.Day; i++)
                    for (int i = 0; i < 30; i++)
                    {
                        //                        DateTime ddate = System.DateTime.Now.AddDays(-System.DateTime.Now.Day + i).Date;
                        DateTime ddate = System.DateTime.Now.AddDays(-30 + i).Date;
                        datelist.Add(ddate);
                        List<double> linshilist = new List<double>();
                        linshilist.Clear();
                        linshilist.Add(double.Parse(today));
                        for (int k = 0; k < historylist.Count; k++)
                        {
                            if (historylist[k].createtime.Value.Date == ddate)
                            {
                                linshilist.Add(double.Parse(historylist[k].valuemax));
                            }

                        }
                        maxvaluelist.Add(linshilist.Max().ToString("0.0"));
                    }
                    for (int i = 0; i < datelist.Count(); i++)
                    {
                        if (i == (datelist.Count() - 1))
                        {
                            templist_30 += datelist[i].Date.ToString("yyyy-MM-dd") + ";" + datelist[i].Date.Day.ToString() + ";" + maxvaluelist[i];
                        }
                        else
                        {
                            templist_30 += datelist[i].Date.ToString("yyyy-MM-dd") + ";" + datelist[i].Date.Day.ToString() + ";" + maxvaluelist[i] + ",";
                        }
                    }
                }
                catch
                {
                    templist_30 = "";
                }
                for (int i = 1; i < historylist.Count() - 1; i++)
                {
                    if (historylist[i].createtime.Value.Date == alarmtime.Date && historylist[i].createtime.Value.Hour == alarmtime.Hour)
                        templist_24 = historylist[i].templist_24;
                }
            }

            //templist_30.Remove(templist_30.Length - 1, 1);
            sx1 = templist_24;
            sx2 = templist_30;
            json.Fenbuname = fenbuname;
            json.Fenbuid = fenbuid;
            json.Ywbname = ywbname;
            json.Ywbid = ywbid;
            json.Ysdname = ysdname;
            json.Ysdid = ysdid;
            json.Stationnane = stationname;
            json.Stationid = stationid;
            json.Deviceid = deviceid;
            json.Devicename = devicename;
            json.Devicetype = devicetype;
            json.Devicelevle = devicelevel;
            json.Fuhe = fuhe;
            json.Alarmtime = alarmtime;
            json.Alarmtemp = alarmtemp;
            json.Machinename = machinename;
            json.Machineid = machineid;
            json.Machinecode = machinecode;
            json.Buildingname = buildingname;
            json.Buildingid = buildingid;
            string image_00 = "";
            string image_11 = "";
            string image_22 = "";
            string imagename = devicealarmmodel.image_url;
            if (imagename.Contains("~0~"))
            {
                image_00 = imagename;
                image_22 = imagename.Replace("~0~", "~2~");
                image_11 = imagename.Replace("~0~", "~1~");
            }
            if (imagename.Contains("~1~"))
            {
                image_11 = imagename;
                image_22 = imagename.Replace("~1~", "~2~");
                image_00 = imagename.Replace("~1~", "~0~");
            }
            if (imagename.Contains("~2~"))
            {
                image_22 = imagename;
                image_00 = imagename.Replace("~2~", "~0~");
                image_11 = imagename.Replace("~2~", "~1~");
            }
            json.Image1 = image_00;
            json.Image2 = image_11;
            json.Image3 = image_22;
            json.Date1 = dttoday.Date.ToString("yyyy-MM-dd");
            json.Templist_241 = templist_24.Split(',').ToList();
            json.Date2 = dttoday.Date.AddDays(-1).ToString("yyyy-MM-dd");
            json.Date3 = dttoday.Date.AddDays(-2).ToString("yyyy-MM-dd");
            json.Date4 = dttoday.Date.AddDays(-3).ToString("yyyy-MM-dd");
            json.Date5 = dttoday.Date.AddDays(-4).ToString("yyyy-MM-dd");
            Maticsoft.BLL.report_device devicereportservice = new Maticsoft.BLL.report_device();
            Maticsoft.Model.report_device devicereportmodel = new Maticsoft.Model.report_device();
            devicereportmodel = devicereportservice.GetModel(reportid);
            if (devicereportmodel != null)
            {
                json.Note1 = devicereportmodel.note1;
                json.Note2 = devicereportmodel.note2;
                json.Note3 = devicereportmodel.note3;
                json.Peo1 = devicereportmodel.manager1;
                json.Peo2 = devicereportmodel.manager2;
                json.Peo3 = devicereportmodel.manager3;

            }
            if (historylist.Count() > 0)
            {
                for (int i = 0; i < historylist.Count(); i++)
                {
                    string sdatedate = historylist[i].createtime.Value.Date.ToString("yyyy-MM-dd");
                    string shourhor = historylist[i].createtime.Value.Hour.ToString();
                    if (json.Date2 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_242 = historylist[i].templist_24.Split(',').ToList();

                    }
                    if (json.Date3 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_243 = historylist[i].templist_24.Split(',').ToList();

                    }
                    if (json.Date4 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_244 = historylist[i].templist_24.Split(',').ToList();

                    }
                    if (json.Date5 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_245 = historylist[i].templist_24.Split(',').ToList();
                    }
                }
            }
            List<Maticsoft.Model.image_record_history> hismodellist = new List<Maticsoft.Model.image_record_history>();
            hismodellist = historyservice.GetModelList("deviceid='" + deviceid + "' and createtime>'" + System.DateTime.Now.Date + "'");
            List<double> tel = new List<double>();
            tel.Add(0);
            if (hismodellist.Count > 0)
            {
                for (int xx = 0; xx < hismodellist.Count; xx++)
                    tel.Add(double.Parse(hismodellist[xx].valuemax));
            }
            json.Templist_30 = templist_30.Split(',').ToList();
            json.Testhuman = manager1;
            json.Shenhehuman = manager2;
            json.Pizhunhunam = manager3;
            json.Dangqian = today;
            json.Today = tel.Max().ToString("0.0");
            json.Yestoday = yestoday;
            json.Week = week;
            json.Month = month;
            json.History = history;
            List<devicereportjson> jsonlist = new List<devicereportjson>();
            jsonlist.Add(json);
            json_Save = json;

            return Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
        }

        public string getDeviceReport_Device(string deviceid)
        {
            update_device_state action = new update_device_state();
            action.UpdateDevice(deviceid);
            devicereportjson json = new devicereportjson();
            Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
            devicemodel = deviceservice.GetModel(deviceid);
            if (devicemodel == null)
            {
                return "";
            }
            string ywbid = devicemodel.ywbid;
            string devicetype = devicemodel.ysdtype;
            string fenbuname = devicemodel.fenbuname;
            string fenbuid = devicemodel.fenbuid;
            string ywbname = devicemodel.ywbname;
            string stationname = devicemodel.stationname;
            string stationid = devicemodel.stationid;
            string devicename = devicemodel.devicename;
            string devicelevel = devicemodel.ysdlevel;
            string machineid = devicemodel.machineid;
            string buildingid = devicemodel.buildingid;
            string fuhe = devicemodel.fuhe;
            string ysdname = devicemodel.ysdname;
            string ysdid = devicemodel.ysdindex;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            DateTime alarmtime = Convert.ToDateTime(devicemodel.createtime.ToString(), dtFormat);
            DateTime dttoday = (DateTime)devicemodel.createtime;
            string alarmtemp = devicemodel.todaytop;
            string machinename = devicemodel.machinename;
            Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
            string machinecode = macser.GetModel(machineid).machinecode;
            string buildingname = devicemodel.buildingname;
            string image1 = devicemodel.image_high;
            string image2 = devicemodel.image_mix;
            string image3 = devicemodel.image_red;
            string templist_24 = devicemodel.templist;
            string yestoday = devicemodel.yestodaytop;
            string week = devicemodel.weektop;
            string month = devicemodel.monthtop;
            string history = devicemodel.historytop;
            string id1 = devicemodel.todaymaxid;
            string id2 = devicemodel.yestodaymaxid;
            string id3 = devicemodel.weekmaxid;
            string id4 = devicemodel.monthmaxid;
            string id5 = devicemodel.historymaxid;
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();
            Maticsoft.BLL.device_heart_infor deviceheartservice = new Maticsoft.BLL.device_heart_infor();
            List<Maticsoft.Model.device_heart_infor> deviceheartlist = new List<Maticsoft.Model.device_heart_infor>();
            //string startTime = "";
            string templist_30 = "";//此处需要根据设备id去历史记录里面查最近30条
            List<DateTime> datelist = new List<DateTime>();
            List<string> maxvaluelist = new List<string>();
            string nowmonth = DateTime.Now.ToString("yyyyMM");
            //string nowmonth = "202006";
            try
            {
                for (int i = 0; i < 30; i++)
                {
                    //查询设备15分钟测温数据中过去30天的
                    string ppmax = "0.0";
                    DateTime ddate = System.DateTime.Now.AddDays(-30 + i).Date;
                    string enddate = ddate.AddDays(1).ToString("yyyy-MM-dd");
                    deviceheartlist.Clear();
                    deviceheartlist = deviceheartservice.GetModelList("deviceid='" + deviceid + "' and createtime>'" + ddate.ToString("yyyy-MM-dd") + "' and createtime<'" + enddate + "' ORDER BY  CAST(ppmax AS DECIMAL) DESC");
                    if (deviceheartlist.Count > 0)
                    {
                        //datelist.Add(ddate);
                        //maxvaluelist.Add(deviceheartlist[0].ppmax);
                        ppmax = deviceheartlist[0].ppmax;
                    }

                    //查询历史图库表中过去30天的的数据
                    string valuemax = "0.0";
                    //DateTime ddate1 = System.DateTime.Now.AddDays(-30 + i).Date;
                    string tablename = ddate.ToString("yyyyMM");
                    //string tablename = "202006";
                    //string enddate1 = ddate.AddDays(1).ToString("yyyy-MM-dd");
                    historylist.Clear();
                    if (tablename == nowmonth)
                    {
                        historylist = historyservice.GetModelList("deviceid='" + deviceid + "' and createtime>'" + ddate.ToString("yyyy-MM-dd") + "' and createtime<'" + enddate + "' ORDER BY  CAST(valuemax AS DECIMAL) DESC");
                    }
                    else
                    {
                        //if (tablename=="202009"|| tablename=="202010")//此处暂时用不到
                        //{
                        //    tablename = "20200910";
                        //}
                        historylist = historyservice.HisGetModelList(tablename, "deviceid='" + deviceid + "' and createtime>'" + ddate.ToString("yyyy-MM-dd") + "' and createtime<'" + enddate + "' ORDER BY  CAST(valuemax AS DECIMAL) DESC");
                    }
                    if (historylist.Count > 0)
                    {
                        valuemax = historylist[0].valuemax;
                    }
                    //从两个数据中提取最高值
                    if (deviceheartlist.Count > 0 && historylist.Count > 0)
                    {                     
                             datelist.Add(ddate);
                            if (double.Parse(ppmax)>=double.Parse(valuemax))
                            {
                                maxvaluelist.Add(ppmax);
                            }
                            else
                            {
                                maxvaluelist.Add(valuemax);
                            }
                    }else if (deviceheartlist.Count > 0 && historylist.Count == 0)
                    {
                        datelist.Add(ddate);
                        maxvaluelist.Add(ppmax);
                    }
                    else if (deviceheartlist.Count == 0 && historylist.Count > 0)
                    {
                        datelist.Add(ddate);
                        maxvaluelist.Add(valuemax);
                    }                   
                }
                for (int i = 0; i < datelist.Count(); i++)
                {
                    if (i == (datelist.Count() - 1))
                    {
                        templist_30 += datelist[i].Date.ToString("yyyy-MM-dd") + ";" + datelist[i].Date.Day.ToString() + ";" + maxvaluelist[i];
                    }
                    else
                    {
                        templist_30 += datelist[i].Date.ToString("yyyy-MM-dd") + ";" + datelist[i].Date.Day.ToString() + ";" + maxvaluelist[i] + ",";
                    }
                }
            }
            catch
            {
                templist_30 = "";
            }


            //historylist = historyservice.GetModelList("deviceid='" + deviceid + "' and createtime>'" + alarmtime.Date.AddDays(-30).ToString() + "' order by createtime desc");
            //historylist.Reverse();
            //string startTime = "";
            //string templist_30 = "";//此处需要根据设备id去历史记录里面查最近30条
            //if (historylist.Count() > 0)
            //{
            //    startTime = historylist[0].createtime.Value.Hour.ToString();

            //    //templist_30 += dateold+";"+ historylist[0].createtime.Value.Day.ToString() + ";" + historylist[0].valuemax + ",";
            //    List<DateTime> datelist = new List<DateTime>();
            //    List<string> maxvaluelist = new List<string>();
            //    try
            //    {
            //        // for (int i = 0; i < System.DateTime.Now.Day; i++)
            //        for (int i = 0; i < 30; i++)
            //        {
            //            // DateTime ddate = System.DateTime.Now.AddDays(-System.DateTime.Now.Day + i).Date;
            //            DateTime ddate = System.DateTime.Now.AddDays(-30 + i).Date;
            //            datelist.Add(ddate);
            //            List<double> linshilist = new List<double>();
            //            linshilist.Clear();
            //            //linshilist.Add(double.Parse(alarmtemp));
            //            linshilist.Add(0.0);
            //            for (int k = 0; k < historylist.Count; k++)
            //            {
            //                if (historylist[k].createtime.Value.Date == ddate)
            //                {
            //                    linshilist.Add(double.Parse(historylist[k].valuemax));
            //                }
            //            }
            //            int index = getMaxindex(linshilist);
            //            maxvaluelist.Add(linshilist[index].ToString("0.0"));
            //            //maxvaluelist.Add(linshilist.Max().ToString("0.0"));
            //        }
            //        for (int i = 0; i < datelist.Count(); i++)
            //        {
            //            if (i == (datelist.Count() - 1))
            //            {
            //                templist_30 += datelist[i].Date.ToString("yyyy-MM-dd") + ";" + datelist[i].Date.Day.ToString() + ";" + maxvaluelist[i];
            //            }
            //            else
            //            {
            //                templist_30 += datelist[i].Date.ToString("yyyy-MM-dd") + ";" + datelist[i].Date.Day.ToString() + ";" + maxvaluelist[i] + ",";
            //            }
            //        }
            //    }
            //    catch
            //    {
            //        templist_30 = "";
            //    }
            //}

            string manager1 = "";
            string manager2 = "";
            string manager3 = "";
            sx1 = templist_24;
            sx2 = templist_30;

            json.Fenbuname = fenbuname;
            json.Fenbuid = fenbuid;
            json.Ywbname = ywbname;
            json.Ywbid = ywbid;
            json.Ysdname = ysdname;
            json.Ysdid = ysdid;
            json.Stationnane = stationname;
            json.Stationid = stationid;
            json.Deviceid = deviceid;
            json.Devicename = devicename;
            json.Devicetype = devicetype;
            json.Devicelevle = devicelevel;
            json.Fuhe = fuhe;
            json.Alarmtime = alarmtime;
            json.Alarmtemp = alarmtemp;
            json.Machinename = machinename;
            json.Machineid = machineid;
            json.Machinecode = machinecode;
            json.Buildingname = buildingname;
            json.Buildingid = buildingid;
            json.Image1 = image1;
            json.Image2 = image2;
            json.Image3 = image3;
            json.Date1 = dttoday.Date.ToString("yyyy-MM-dd");
            //json.Templist_241 = templist_24.Split(',').ToList();
            json.Date2 = dttoday.Date.AddDays(-1).ToString("yyyy-MM-dd");
            json.Date3 = dttoday.Date.AddDays(-2).ToString("yyyy-MM-dd");
            json.Date4 = dttoday.Date.AddDays(-3).ToString("yyyy-MM-dd");
            json.Date5 = dttoday.Date.AddDays(-4).ToString("yyyy-MM-dd");
            DateTime date1 = dttoday.Date;
            DateTime date2 = dttoday.Date.AddDays(-1);
            DateTime date3 = dttoday.Date.AddDays(-2);
            DateTime date4 = dttoday.Date.AddDays(-3);
            DateTime date5 = dttoday.Date.AddDays(-4);
            //获取24小时温度统计
            json.Templist_241 = getDeviceTopList(deviceid,date1);
            json.Templist_242 = getDeviceTopList(deviceid, date2);
            json.Templist_243 = getDeviceTopList(deviceid, date3);
            json.Templist_244 = getDeviceTopList(deviceid, date4);
            json.Templist_245 = getDeviceTopList(deviceid, date5);
            //List<Maticsoft.Model.image_record_history> imagelist = new List<Maticsoft.Model.image_record_history>();
            //imagelist = historyservice.GetModelList("deviceid='" + deviceid + "' and createtime>'" + dttoday.Date.AddDays(-5).ToString("yyyy-MM-dd") + "' and createtime<'" + dttoday.Date.ToString("yyyy-MM-dd")+"' order by createtime desc");
            //imagelist.Reverse();
            //if (imagelist.Count > 0)
            //{
            //    startTime = imagelist[0].createtime.Value.Hour.ToString();
            //    for (int i = 0; i < imagelist.Count; i++)
            //    {
            //        string sdatedate = imagelist[i].createtime.Value.Date.ToString("yyyy-MM-dd");
            //        string shourhor = imagelist[i].createtime.Value.Hour.ToString();
            //        if (json.Date2 == sdatedate && shourhor == startTime)
            //        {
            //            json.Templist_242 = imagelist[i].templist_24.Split(',').ToList();
            //            System.Diagnostics.Debug.WriteLine("242的imagid======" + imagelist[i].recordid);
            //            continue;
            //        }
            //        if (json.Date3 == sdatedate && shourhor == startTime)
            //        {
            //            json.Templist_243 = imagelist[i].templist_24.Split(',').ToList();
            //            System.Diagnostics.Debug.WriteLine("243的imagid======" + imagelist[i].recordid);
            //            continue;
            //        }
            //        if (json.Date4 == sdatedate && shourhor == startTime)
            //        {
            //            json.Templist_244 = imagelist[i].templist_24.Split(',').ToList();
            //            System.Diagnostics.Debug.WriteLine("244的imagid======" + imagelist[i].recordid);
            //            continue;
            //        }
            //        if (json.Date5 == sdatedate && shourhor == startTime)
            //        {
            //            json.Templist_245 = imagelist[i].templist_24.Split(',').ToList();
            //            System.Diagnostics.Debug.WriteLine("245的imagid======" + imagelist[i].recordid);
            //            continue;
            //        }
            //    }
            //}
            List<Maticsoft.Model.image_record_history> hismodellist = new List<Maticsoft.Model.image_record_history>();
            hismodellist = historyservice.GetModelList("deviceid='" + deviceid + "' and createtime>'" + System.DateTime.Now.Date + "' GROUP BY createtime");
            List<double> tel = new List<double>();
            tel.Add(0);
            if (hismodellist.Count > 0)
            {
                for (int xx = 0; xx < hismodellist.Count; xx++)
                    tel.Add(double.Parse(hismodellist[xx].valuemax));
            }
            json.Templist_30 = templist_30.Split(',').ToList();
            json.Testhuman = manager1;
            json.Shenhehuman = manager2;
            json.Pizhunhunam = manager3;
            json.Dangqian = alarmtemp;
            json.Today = tel.Max().ToString("0.0");
            json.Yestoday = yestoday;
            json.Week = week;
            json.Month = month;
            json.History = history;
            json.Todaymaxid = id1;
            json.Yestodaymaxid = id2;
            json.Weekmaxid = id3;
            json.Monthmaxid = id4;
            json.Historymaxid = id5;
            List<devicereportjson> jsonlist = new List<devicereportjson>();
            jsonlist.Add(json);
            return Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
        }

       //public  string TryEditWord()
       // {
       //     string Str=File.ReadAllText(@"H:\新版Create红外项目\imfraredservices\Config.json",Encoding.Default);
       //     CreateWordHelper createWord = new CreateWordHelper(Str);
       //     string SaveFilePath = createWord.TryCreateword();
       //     return "Ok";
       // }

        string chart1 = "";
        string chart2 = "";
        string msgnote1 = ""; 
        string msgnote2 = "";
        string msgnote3 = "";
        public string saveDevicereport(string alarmid, string note1, string note2, string note3, string s1, string s2, string s3, string s4, string s5)
        {
            Maticsoft.BLL.report_device devicereportservice = new Maticsoft.BLL.report_device();
            Maticsoft.Model.report_device devicereportmodel = new Maticsoft.Model.report_device();
            chart1 = s4; chart2 = s5; msgnote1 = note1; msgnote2 = note2; msgnote3 = note3;
            manager1 = s1; manager2 = s2; manager3 = s3;
            string sxxx = Guid.NewGuid().ToString("N");
            devicereportmodel.devicereportid = sxxx;
            devicereportmodel.fenbuname = json_Save.Fenbuname;
            devicereportmodel.ywbname = json_Save.Ywbname;
            devicereportmodel.stationnane = json_Save.Stationnane;
            devicereportmodel.devicename = json_Save.Devicename;
            devicereportmodel.devicelevel = json_Save.Devicelevle;
            devicereportmodel.fuhe = json_Save.Fuhe;
            devicereportmodel.alarmtemp = json_Save.Alarmtemp;
            devicereportmodel.alarmtime = json_Save.Alarmtime;
            devicereportmodel.machinename = json_Save.Machinename;
            devicereportmodel.machinecode = json_Save.Machinecode;
            devicereportmodel.image_red = json_Save.Image1;
            devicereportmodel.image_high = json_Save.Image2;
            devicereportmodel.templist_24 = sx1;
            devicereportmodel.templist_30 = sx2;
            devicereportmodel.manager1 = s1;
            devicereportmodel.manager2 = s2;
            devicereportmodel.manager3 = s3;
            devicereportmodel.note1 = note1;
            devicereportmodel.note2 = note2;
            devicereportmodel.note3 = note3;
            devicereportservice.Add(devicereportmodel);
            Maticsoft.BLL.alarm_push_infor bll = new Maticsoft.BLL.alarm_push_infor();
            bll.UpdateReportid(alarmid, sxxx);
            return "保存成功";
        }
        public string device_Word_Export(string alarmid, string note1, string note2, string note3, string s1, string s2, string s3, string s4, string s5)
        {
            string savetime = "";
            string stationname = "";
            chart1 = s4; chart2 = s5; msgnote1 = note1; msgnote2 = note2; msgnote3 = note3;
            manager1 = s1; manager2 = s2; manager3 = s3;
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            Maticsoft.Model.alarm_push_infor alarmmodel = new Maticsoft.Model.alarm_push_infor();
            alarmmodel = alarmservice.GetModel(alarmid);
            savetime = alarmmodel.createtime.Value.ToString("yyyyMMddhhMMss");
            stationname = alarmmodel.stationname;
            return setfile(getDeviceReport_word(alarmid), msgnote1, msgnote2, msgnote3, manager1, manager2, manager3, chart1, chart2, savetime, stationname);
        }
        public devicereportjson getDeviceReport_word(string alarmid)
        {
            currentid = alarmid;
            string reportid = "";
            devicereportjson json = new devicereportjson();

            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            Maticsoft.Model.alarm_push_infor devicealarmmodel = new Maticsoft.Model.alarm_push_infor();
            devicealarmmodel = alarmservice.GetModel(alarmid);
            reportid = devicealarmmodel.report_device_id;
            if (devicealarmmodel == null)
                return null;
            string deviceid = devicealarmmodel.deviceid;
            Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
            devicemodel = deviceservice.GetModel(deviceid);
            string ywbid = devicemodel.ywbid;
            string devicetype = devicemodel.ysdtype;
            string fenbuname = devicemodel.fenbuname;
            string fenbuid = devicemodel.fenbuid;
            string ywbname = devicemodel.ywbname;
            string stationname = devicemodel.stationname;
            string stationid = devicemodel.stationid;
            string devicename = devicemodel.devicename;
            string devicelevel = devicemodel.ysdlevel;
            string machineid = devicemodel.machineid;
            string buildingid = devicemodel.buildingid;
            string fuhe = devicemodel.fuhe;
            string ysdname = devicemodel.ysdname;
            string ysdid = devicemodel.ysdindex;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            System.DateTime alarmtime = Convert.ToDateTime(devicealarmmodel.createtime.ToString(), dtFormat);
            DateTime dttoday = (DateTime)devicemodel.createtime;
            string alarmtemp = devicealarmmodel.alarmvalue;
            string machinename = devicemodel.machinename;
            Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
            string machinecode = macser.GetModel(machineid).machinecode;
            string buildingname = devicemodel.buildingname;
            string image1 = devicemodel.image_high;
            string image2 = devicemodel.image_mix;
            string image3 = devicemodel.image_red;
            string templist_24 = devicemodel.templist;
            string today = devicealarmmodel.alarmvalue;
            string yestoday = devicealarmmodel.alarmvalue;
            string week = devicealarmmodel.alarmvalue;
            string month = devicealarmmodel.alarmvalue;
            string history = devicealarmmodel.alarmvalue;
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();
            historylist = historyservice.GetModelList("deviceid='" + deviceid + "' order by createtime desc limit 0,720");
            historylist.Reverse();
            string startTime = "";
            string templist_30 = "";//此处需要根据设备id去历史记录里面查最近30条
            if (historylist.Count() > 0)
            {
                string dayold = historylist[0].createtime.Value.Day.ToString();
                startTime = historylist[0].createtime.Value.Hour.ToString();
                string dateold = historylist[0].createtime.Value.Year.ToString() + "-" + historylist[0].createtime.Value.Month.ToString() + "-" + historylist[0].createtime.Value.Day.ToString();
                templist_30 += dateold + ";" + historylist[0].createtime.Value.Day.ToString() + ";" + historylist[0].valuemax + ",";
                string daynew = "";
                string datenew = "";
                for (int i = 1; i < historylist.Count() - 1; i++)
                {
                    daynew = historylist[i].createtime.Value.Day.ToString();
                    datenew = historylist[i].createtime.Value.Year.ToString() + "-" + historylist[i].createtime.Value.Month.ToString() + "-" + historylist[i].createtime.Value.Day.ToString();
                    if (daynew != dayold)
                    {
                        templist_30 += datenew + ";" + daynew + ";" + historylist[i].valuemax + ",";
                        dayold = daynew;
                    }
                }
            }

            templist_30.Remove(templist_30.Length - 1, 1);

            sx1 = templist_24;
            sx2 = templist_30;
            json.Fenbuname = fenbuname;
            json.Fenbuid = fenbuid;
            json.Ywbname = ywbname;
            json.Ywbid = ywbid;
            json.Ysdname = ysdname;
            json.Ysdid = ysdid;
            json.Stationnane = stationname;
            json.Stationid = stationid;
            json.Deviceid = deviceid;
            json.Devicename = devicename;
            json.Devicetype = devicetype;
            json.Devicelevle = devicelevel;
            json.Fuhe = fuhe;
            json.Alarmtime = alarmtime;
            json.Alarmtemp = alarmtemp;
            json.Machinename = machinename;
            json.Machineid = machineid;
            json.Machinecode = machinecode;
            json.Buildingname = buildingname;
            json.Buildingid = buildingid;
            json.Image1 = image1;
            json.Image2 = image2;
            json.Image3 = image3;
            json.Date1 = dttoday.Year + "-" + dttoday.Month + "-" + dttoday.Day;
            json.Templist_241 = templist_24.Split(',').ToList();
            json.Date2 = dttoday.Year + "-" + dttoday.Month + "-" + (dttoday.Day - 1);
            json.Date3 = dttoday.Year + "-" + dttoday.Month + "-" + (dttoday.Day - 2);
            json.Date4 = dttoday.Year + "-" + dttoday.Month + "-" + (dttoday.Day - 3);
            json.Date5 = dttoday.Year + "-" + dttoday.Month + "-" + (dttoday.Day - 4);
            Maticsoft.BLL.report_device devicereportservice = new Maticsoft.BLL.report_device();
            Maticsoft.Model.report_device devicereportmodel = new Maticsoft.Model.report_device();
            devicereportmodel = devicereportservice.GetModel(reportid);
            if (devicereportmodel != null)
            {
                json.Note1 = devicereportmodel.note1;
                json.Note2 = devicereportmodel.note2;
                json.Note3 = devicereportmodel.note3;
                json.Peo1 = devicereportmodel.manager1;
                json.Peo2 = devicereportmodel.manager2;
                json.Peo3 = devicereportmodel.manager3;

            }
            if (historylist.Count() > 0)
            {
                for (int i = 0; i < historylist.Count(); i++)
                {
                    string sdatedate = historylist[i].createtime.Value.Year + "-" + historylist[i].createtime.Value.Month + "-" + historylist[i].createtime.Value.Day;
                    string shourhor = historylist[i].createtime.Value.Hour.ToString();
                    if (json.Date2 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_242 = historylist[i].templist_24.Split(',').ToList();

                    }
                    if (json.Date3 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_243 = historylist[i].templist_24.Split(',').ToList();

                    }
                    if (json.Date4 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_244 = historylist[i].templist_24.Split(',').ToList();

                    }
                    if (json.Date5 == sdatedate && shourhor == startTime)
                    {
                        json.Templist_245 = historylist[i].templist_24.Split(',').ToList();
                    }
                }
            }

            json.Templist_30 = templist_30.Split(',').ToList();
            json.Testhuman = manager1;
            json.Shenhehuman = manager2;
            json.Pizhunhunam = manager3;
            json.Today = today;
            json.Yestoday = yestoday;
            json.Week = week;
            json.Month = month;
            json.History = history;
            List<devicereportjson> jsonlist = new List<devicereportjson>();
            jsonlist.Add(json);
            json_Save = json;

            return json;
        }
        private string setfile(devicereportjson json, string note1, string note2, string note3, string peo1, string peo2, string peo3, string chartimage1, string chartimage2, string savetime, string stationname)
        {
            Maticsoft.BLL.city_infor bll = new Maticsoft.BLL.city_infor();
            DataSet ds = bll.GetList("ywbid='" + json.Ywbid + "'");
            string tianqi = "";
            string wendu = "";
            string shidu = "";
            string fengli = "";
            if (ds.Tables[0].Rows.Count > 0)
            {
                tianqi = ds.Tables[0].Rows[0]["weather"].ToString();
                wendu = ds.Tables[0].Rows[0]["citytemputer"].ToString();
                shidu = ds.Tables[0].Rows[0]["humidity"].ToString();
                fengli = ds.Tables[0].Rows[0]["windspeed"].ToString();
            }
            string mubanFile = @"D:\infrared_new_service\apk_Floder\红外检测报告-模板.docx";
            string outputPath = @"D:\infrared_new_service\apk_Floder\" + savetime + "-" + stationname + "-红外检测报告.docx";
            Document dm = new Document(mubanFile);

            List<string> list1 = new List<string>();
            list1.Add("testtime");
            list1.Add("tianqi");
            list1.Add("wendu");
            list1.Add("shidu");
            list1.Add("fengli");
            list1.Add("fenbu");
            list1.Add("yunweiban");
            list1.Add("station");
            list1.Add("device");
            list1.Add("level");
            list1.Add("fuhe");
            list1.Add("alarmtime");
            list1.Add("alarmvalue");
            list1.Add("redname");
            list1.Add("redcode");
            list1.Add("building");
            list1.Add("note1");
            list1.Add("note2");
            list1.Add("note3");
            list1.Add("peo1");
            list1.Add("peo2");
            list1.Add("peo3");

            List<string> list2 = new List<string>();
            list2.Add(json.Alarmtime.ToString());
            list2.Add(tianqi);
            list2.Add(wendu + "℃");
            list2.Add(shidu + "%");
            list2.Add(fengli);
            list2.Add(json.Fenbuname);
            list2.Add(json.Ywbname);
            list2.Add(json.Stationnane);
            list2.Add(json.Devicename);
            list2.Add(json.Devicelevle);
            list2.Add(json.Fuhe);
            list2.Add(json.Alarmtime.ToString());
            list2.Add(json.Alarmtemp);
            list2.Add(json.Machinename);
            list2.Add(json.Machinecode);
            list2.Add(json.Buildingname);
            list2.Add(note1);
            list2.Add(note2);
            list2.Add(note3);
            list2.Add(peo1);
            list2.Add(peo2);
            list2.Add(peo3);
            string[] s1 = list1.ToArray();
            string[] s2 = list2.ToArray();
            dm.MailMerge.Execute(s1, s2);

            foreach (Bookmark mark in dm.Range.Bookmarks)
            {
                switch (mark.Name)
                {
                    case "RED":
                        if (1 == 1)
                        {
                            DocumentBuilder builder1 = new DocumentBuilder(dm);
                            string imgPath = WriteBytesToFile("D:\\infrared_new_service\\apk_Floder\\红外.jpg", GetBytesFromUrl(json.Image2));
                            if (File.Exists(imgPath))
                            {
                                builder1.MoveToBookmark("RED");
                                builder1.Writeln();
                                //获取当前所在的段落
                                Paragraph paragraph = builder1.CurrentParagraph;
                                Shape shape = builder1.InsertImage(imgPath);
                                double w = shape.Width;
                                shape.Width = 160;
                                shape.Height = 120;
                                shape.RelativeVerticalPosition = RelativeVerticalPosition.Paragraph;
                                shape.RelativeHorizontalPosition = RelativeHorizontalPosition.Character;
                                shape.Left = paragraph.GetText().Length;
                                shape.WrapType = WrapType.None;
                            }
                        }
                        break;
                    case "HIGH":
                        if (1 == 1)
                        {
                            DocumentBuilder builder1 = new DocumentBuilder(dm);
                            string imgPath = WriteBytesToFile("D:\\infrared_new_service\\apk_Floder\\红外.jpg", GetBytesFromUrl(json.Image1));
                            if (File.Exists(imgPath))
                            {
                                builder1.MoveToBookmark("HIGH");
                                builder1.Writeln();
                                //获取当前所在的段落
                                Paragraph paragraph = builder1.CurrentParagraph;
                                Shape shape = builder1.InsertImage(imgPath);
                                double w = shape.Width;
                                shape.Width = 160;
                                shape.Height = 120;
                                shape.RelativeVerticalPosition = RelativeVerticalPosition.Paragraph;
                                shape.RelativeHorizontalPosition = RelativeHorizontalPosition.Character;
                                shape.Left = paragraph.GetText().Length;
                                shape.WrapType = WrapType.None;
                            }
                        }
                        break;
                    case "CHART1":
                        if (1 == 1)
                        {
                            DocumentBuilder builder1 = new DocumentBuilder(dm);
                            File.WriteAllBytes("D:\\infrared_new_service\\apk_Floder\\图表.jpg", Convert.FromBase64String(chart1.Split(',')[1]));
                            string imgPath = "D:\\infrared_new_service\\apk_Floder\\图表.jpg";//WriteBytesToFile("D:\\infrared_new_service\\apk_Floder\\红外.jpg", GetBytesFromUrl(chart1));
                            if (File.Exists(imgPath))
                            {
                                builder1.MoveToBookmark("CHART1");
                                builder1.Writeln();
                                //获取当前所在的段落
                                Paragraph paragraph = builder1.CurrentParagraph;
                                Shape shape = builder1.InsertImage(imgPath);
                                double w = shape.Width;
                                shape.Width = 160;
                                shape.Height = 120;
                                shape.RelativeVerticalPosition = RelativeVerticalPosition.Paragraph;
                                shape.RelativeHorizontalPosition = RelativeHorizontalPosition.Character;
                                shape.Left = paragraph.GetText().Length;
                                shape.WrapType = WrapType.None;
                            }
                        }
                        break;
                    case "CHART2":
                        if (1 == 1)
                        {
                            DocumentBuilder builder1 = new DocumentBuilder(dm);
                            File.WriteAllBytes("D:\\infrared_new_service\\apk_Floder\\图表.jpg", Convert.FromBase64String(chart2.Split(',')[1]));
                            string imgPath = "D:\\infrared_new_service\\apk_Floder\\图表.jpg";//WriteBytesToFile("D:\\infrared_new_service\\apk_Floder\\红外.jpg", GetBytesFromUrl(chart1));
                            if (File.Exists(imgPath))
                            {
                                builder1.MoveToBookmark("CHART2");
                                builder1.Writeln();
                                //获取当前所在的段落
                                Paragraph paragraph = builder1.CurrentParagraph;
                                Shape shape = builder1.InsertImage(imgPath);
                                double w = shape.Width;
                                shape.Width = 160;
                                shape.Height = 120;
                                shape.RelativeVerticalPosition = RelativeVerticalPosition.Paragraph;
                                shape.RelativeHorizontalPosition = RelativeHorizontalPosition.Character;
                                shape.Left = paragraph.GetText().Length;
                                shape.WrapType = WrapType.None;
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
            dm.Save(outputPath);
            string xxx = "http://116.255.207.148:21889/" + savetime + "-" + stationname + "-红外检测报告.docx";

            return xxx;
        }
        public string WriteBytesToFile(string fileName, byte[] content)
        {
            FileStream fs = new FileStream(fileName, FileMode.Create);
            BinaryWriter w = new BinaryWriter(fs);
            try
            {
                w.Write(content);
            }
            finally
            {
                fs.Close();
                w.Close();
            }
            return fileName;

        }
        public byte[] GetBytesFromUrl(string url)
        {
            byte[] b;
            HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create(url);
            WebResponse myResp = myReq.GetResponse();

            Stream stream = myResp.GetResponseStream();
            //int i;
            using (BinaryReader br = new BinaryReader(stream))
            {
                //i = (int)(stream.Length);
                b = br.ReadBytes(500000);
                br.Close();
            }
            myResp.Close();
            return b;

        }
        public DataTable getHistorydevicereport()
        {
            Maticsoft.BLL.report_device devicereportservice = new Maticsoft.BLL.report_device();
            Maticsoft.Model.report_device devicereportmodel = new Maticsoft.Model.report_device();
            return devicereportservice.GetList("").Tables[0];
        }
        #endregion

        string count80 = "";
        string count90 = "";
        string count100 = "";
        string count120 = "";

        public DataTable getAlarmByTemouterSection(string userid)//获取测温告警统计信息
        {
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;

            List<Maticsoft.Model.device_infor> modellist = new List<Maticsoft.Model.device_infor>();
            Maticsoft.BLL.device_infor bllservice = new Maticsoft.BLL.device_infor();

            if (um.usertype == "1")
            {
                modellist = bllservice.GetModelList("areaid='" + um.areaid + "'");

            }
            if (um.usertype == "2")
            {
                modellist = bllservice.GetModelList("fenbuid='" + um.fenbuid + "'");

            }
            if (um.usertype == "3")
            {
                modellist = bllservice.GetModelList("ywbid='" + um.ywbid + "'");
            }
            int allcount = 0;
            int count1 = 0; int count2 = 0; int count3 = 0;
            int n80 = 0; int n90 = 0; int n100 = 0; int n120 = 0;
            try
            {
                for (int i = 0; i < modellist.Count(); i++)
                {
                    if (int.Parse(modellist[i].todaytop) >= 120 && int.Parse(modellist[i].todaytop) < 140)
                    {
                        count3 += 1;
                        n120++;
                    }
                    if (int.Parse(modellist[i].todaytop) >= 100)
                    {
                        n100++;
                    }
                    if (int.Parse(modellist[i].todaytop) >= 90)
                    {
                        n90++;
                    }
                    if (int.Parse(modellist[i].todaytop) >= 80)
                    {
                        n80++;
                    }
                    if (int.Parse(modellist[i].todaytop) < 120 && int.Parse(modellist[i].todaytop) >= 100)
                    {
                        count2 += 1;
                    }
                    if (int.Parse(modellist[i].todaytop) >= 80 && int.Parse(modellist[i].todaytop) < 100)
                    {
                        count1 += 1;
                    }
                }
                count120 = n120.ToString();
                count100 = n100.ToString();
                count90 = n90.ToString();
                count80 = n80.ToString();
                allcount = count1 + count2 + count3;
                DataTable dt = new DataTable("machinecount");
                dt.Columns.Add("allcount", Type.GetType("System.String"));
                dt.Columns.Add("count_80100", Type.GetType("System.String"));
                dt.Columns.Add("count_100120", Type.GetType("System.String"));
                dt.Columns.Add("count_120", Type.GetType("System.String"));
                dt.Rows.Add(new object[] { allcount.ToString(), count1.ToString(), count2.ToString(), count3.ToString() });
                //select devicename,COUNT(devicename) from alarm_push_infor GROUP by devicename having count(devicename)>1 Order by devicename
                return dt;
            }
            catch
            {
                return null;
            }

        }
        #region 运维班报告
        public void saveMonthReport(string userid, string reporthuman)
        {

        }
        public int getMaxindex(List<double> list)
        {
            double a = list[0];
            int index = 0;//把假设的最大值索引赋值非index

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] > a)
                {
                    a = list[i];
                    index = i;//把较大值的索引赋值非index
                }
            }
            return index;
        }
        public string download_monthReport(string userid, string reporthuman, string tongji1, string tongji2, string tongji3)
        {
            string reportdanwei = "";
            Maticsoft.BLL.user_infor uservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor umodel = new Maticsoft.Model.user_infor();
            umodel = uservice.GetModel(userid);
            if (umodel.usertype == "0")
                reportdanwei = umodel.areaname;
            if (umodel.usertype == "1")
                reportdanwei = umodel.fenbuname;
            if (umodel.usertype == "2")
                reportdanwei = umodel.ywbname;
            if (umodel.usertype == "3")
                reportdanwei = "系统管理员";
            string reporttime = System.DateTime.Now.ToString("yyyyMMddhhMMss");
            string mubanFile = @"D:\infrared_new_service\apk_Floder\班组月报-模板.docx";
            string outputPath = @"D:\infrared_new_service\apk_Floder\" + reporttime + "-" + reportdanwei + "-红外检测报告.docx";
            Document dm = new Document(mubanFile);

            List<string> list1 = new List<string>();
            list1.Add("createtime");
            list1.Add("danwei");
            list1.Add("danwei1");
            list1.Add("human");
            list1.Add("tongji1");
            list1.Add("tongji2");
            list1.Add("tongji3");
            // list1.Add("tongji_list");
            // list1.Add("tongji_list1");

            List<string> list2 = new List<string>();
            list2.Add(reporttime);
            list2.Add(reportdanwei);
            list2.Add(reportdanwei);
            list2.Add(reporthuman);
            list2.Add(tongji1);
            list2.Add(tongji2);
            list2.Add(tongji3);

            string[] s1 = list1.ToArray();
            string[] s2 = list2.ToArray();
            dm.MailMerge.Execute(s1, s2);
            dm.Save(outputPath);
            string xxx = "http://116.255.207.148:21889/" + reporttime + "-" + reportdanwei + "-红外检测报告.docx"; ;
            return xxx;
        }
        public string strJson(string str)
        {
            string jsonText = str;

            JObject jo = (JObject)JsonConvert.DeserializeObject(jsonText);//或者JObject jo = JObject.Parse(jsonText);
            string url = jo["msg"].ToString();
            return url;
        }
        public string geturl(string userid, string startDate, string endDate, string human)
        {
            byte[] bytes = null;
            string result = string.Empty;
            string param = string.Empty;
            Stream writer = null;
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            try
            {
                param = HttpUtility.UrlEncode("userid") + "=" + HttpUtility.UrlEncode(userid) + "&" + HttpUtility.UrlEncode("startDate") + "=" + HttpUtility.UrlEncode(startDate) + "&" + HttpUtility.UrlEncode("endDate") + "=" + HttpUtility.UrlEncode(endDate) + "&" + HttpUtility.UrlEncode("reporthuman") + "=" + HttpUtility.UrlEncode(human);
                bytes = Encoding.UTF8.GetBytes(param);
                request = (HttpWebRequest)WebRequest.Create("http://10.8.0.1:8083/shebeiguanli/holographic/hongWaiExportWord");
                request.Proxy = null;
                request.Method = "POST";
                //request.ContentType = "application/x-www-form-urlencoded";
                request.ContentType = "text/html";
                request.ContentLength = bytes.Length;

                writer = request.GetRequestStream();  //获取用于写入请求数据的Stream对象

                writer.Write(bytes, 0, bytes.Length);  //把参数数据写入请求数据流
                request.ServicePoint.Expect100Continue = false;
                writer.Dispose();
                writer.Close();
                response = (HttpWebResponse)request.GetResponse();  //获得响应
                StreamReader sr = new StreamReader(response.GetResponseStream(), Encoding.UTF8);
                String retXml = sr.ReadToEnd();
                sr.Close();
                string sx = retXml.ToString();
                return strJson(sx);
            }
            catch (WebException ex)
            {
                string Msg = ex.Message.ToString();
                Console.WriteLine(Msg);
                return "";
            }
        }
        public string getAllreport_c(string userid, string startDate, string endDate)
        {

            DateTime timeStart, timeEnd;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            timeStart = Convert.ToDateTime(startDate, dtFormat).AddDays(0).Date;
            timeEnd = Convert.ToDateTime(endDate, dtFormat).AddDays(1);

            allreportjson json = new allreportjson();
            json.Betweentime = startDate + "至" + endDate;
            json.ReportTime = System.DateTime.Now.ToString();
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            // Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
            Maticsoft.BLL.ysd_infor ysdservice = new Maticsoft.BLL.ysd_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
            {
                return "";
            }
            string usertype = usermodel.usertype;
            DataSet station_ds = new DataSet();
            DataSet device_ds = new DataSet();
            DataSet machine_ds = new DataSet();
            DataSet ysd_ds = new DataSet();
            List<allreportjson_device> all_device_list = new List<allreportjson_device>();

            #region 跟踪设备统计
            if (usertype == "0")
            {
                json.ReportDanwei = usermodel.areaname;
                station_ds = stationservice.GetList("areaid='" + usermodel.areaid + "'");
                device_ds = deviceservice.GetList("areaid='" + usermodel.areaid + "' GROUP BY operaterNumber ");
                ysd_ds = ysdservice.GetList("areaid='" + usermodel.areaid + "'");
                machine_ds = macservice.GetList("areaid='" + usermodel.areaid + "'");
                if (station_ds != null && machine_ds != null && device_ds != null)
                {
                    json.DeviceTongji = startDate + "至" + endDate + "期间：测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + ysd_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪，监测主变81台，监测电抗器28台。";
                }
                //if (station_ds != null && station_ds.Tables.Count > 0)
                //{
                //    for (int i = 0; i < station_ds.Tables[0].Rows.Count; i++)
                //    {
                //        List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
                //        Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
                //        buildinglist = buildingservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //        List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
                //        machinelist = macservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //        if (buildinglist != null && buildinglist.Count > 0)
                //        {
                //            for (int j = 0; j < buildinglist.Count; j++)
                //            {
                //                Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
                //                List<Maticsoft.Model.devicetype_infor> typemodel = new List<Maticsoft.Model.devicetype_infor>();
                //                typemodel = typeservice.GetModelList("");
                //                if (typemodel != null && typemodel.Count > 0)
                //                {
                //                    for (int k = 0; k < typemodel.Count; k++)
                //                    {
                //                        allreportjson_device all_device = new allreportjson_device();
                //                        all_device.Stationname = station_ds.Tables[0].Rows[i]["stationname"].ToString();
                //                        if (machinelist != null)
                //                        {
                //                            all_device.Machinecount = machinelist.Count.ToString();
                //                        }
                //                        all_device.Buildingname = buildinglist[j].buildingname;
                //                        all_device.Devicetype = typemodel[k].devicetype;
                //                        List<Maticsoft.Model.device_infor> devicelist_type = new List<Maticsoft.Model.device_infor>();
                //                        devicelist_type = deviceservice.GetModelList("buildingname='" + buildinglist[j].buildingname + "' and ysdtype='" + typemodel[k].devicetype + "'");
                //                        string sx = "";
                //                        if (devicelist_type != null && devicelist_type.Count > 0)
                //                        {
                //                            for (int m = 0; m < devicelist_type.Count; m++)
                //                            {
                //                                sx += (devicelist_type[m].devicename) + ",";
                //                            }
                //                        }
                //                        all_device.Devicelist = sx;
                //                        all_device_list.Add(all_device);
                //                    }

                //                }

                //            }
                //        }
                //    }
                //}
            }
            if (usertype == "1")
            {
                json.ReportDanwei = usermodel.fenbuname;

                station_ds = stationservice.GetList("fenbuid='" + usermodel.fenbuid + "'");
                device_ds = deviceservice.GetList("fenbuid='" + usermodel.fenbuid + "' GROUP BY operaterNumber ");
                ysd_ds = ysdservice.GetList("fenbuid='" + usermodel.fenbuid + "'");
                machine_ds = macservice.GetList("fenbuid='" + usermodel.fenbuid + "'");
                if (station_ds != null && machine_ds != null && device_ds != null)
                {
                    json.DeviceTongji = startDate + "至" + endDate + "期间：测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + ysd_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪，监测主变81台，监测电抗器28台。";
                }
                //if (station_ds != null && station_ds.Tables.Count > 0)
                //{
                //    for (int i = 0; i < station_ds.Tables[0].Rows.Count; i++)
                //    {
                //        List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
                //        Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
                //        buildinglist = buildingservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //        List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
                //        machinelist = macservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //        if (buildinglist != null && buildinglist.Count > 0)
                //        {
                //            for (int j = 0; j < buildinglist.Count; j++)
                //            {
                //                Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
                //                List<Maticsoft.Model.devicetype_infor> typemodel = new List<Maticsoft.Model.devicetype_infor>();
                //                typemodel = typeservice.GetModelList("");
                //                if (typemodel != null && typemodel.Count > 0)
                //                {
                //                    for (int k = 0; k < typemodel.Count; k++)
                //                    {
                //                        allreportjson_device all_device = new allreportjson_device();
                //                        all_device.Stationname = station_ds.Tables[0].Rows[i]["stationname"].ToString();
                //                        if (machinelist != null)
                //                        {
                //                            all_device.Machinecount = machinelist.Count.ToString();
                //                        }
                //                        all_device.Buildingname = buildinglist[j].buildingname;
                //                        all_device.Devicetype = typemodel[k].devicetype;
                //                        List<Maticsoft.Model.device_infor> devicelist_type = new List<Maticsoft.Model.device_infor>();
                //                        devicelist_type = deviceservice.GetModelList("buildingname='" + buildinglist[j].buildingname + "' and ysdtype='" + typemodel[k].devicetype + "'");
                //                        string sx = "";
                //                        if (devicelist_type != null && devicelist_type.Count > 0)
                //                        {
                //                            for (int m = 0; m < devicelist_type.Count; m++)
                //                            {
                //                                sx += (devicelist_type[m].devicename) + ",";
                //                            }
                //                        }
                //                        all_device.Devicelist = sx;
                //                        all_device_list.Add(all_device);
                //                    }
                //                }

                //            }
                //        }
                //    }

                //}
            }
            if (usertype == "2")
            {
                json.ReportDanwei = usermodel.ywbname;

                station_ds = stationservice.GetList("ywbid='" + usermodel.ywbid + "'");
                device_ds = deviceservice.GetList("ywbid='" + usermodel.ywbid + "' GROUP BY operaterNumber ");
                ysd_ds = ysdservice.GetList("ywbid='" + usermodel.ywbid + "'");
                machine_ds = macservice.GetList("ywbid='" + usermodel.ywbid + "'");
                if (station_ds != null && machine_ds != null && device_ds != null)
                {
                    json.DeviceTongji = startDate + "至" + endDate + "期间：测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + ysd_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪，监测主变81台，监测电抗器28台。";
                }
                //if (station_ds != null && station_ds.Tables.Count > 0)
                //{
                //    for (int i = 0; i < station_ds.Tables[0].Rows.Count; i++)
                //    {
                //        List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
                //        Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
                //        buildinglist = buildingservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //        List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
                //        machinelist = macservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //        if (buildinglist != null && buildinglist.Count > 0)
                //        {
                //            for (int j = 0; j < buildinglist.Count; j++)
                //            {
                //                Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
                //                List<Maticsoft.Model.devicetype_infor> typemodel = new List<Maticsoft.Model.devicetype_infor>();
                //                typemodel = typeservice.GetModelList("");
                //                if (typemodel != null && typemodel.Count > 0)
                //                {
                //                    for (int k = 0; k < typemodel.Count; k++)
                //                    {
                //                        allreportjson_device all_device = new allreportjson_device();
                //                        all_device.Stationname = station_ds.Tables[0].Rows[i]["stationname"].ToString();
                //                        if (machinelist != null)
                //                        {
                //                            all_device.Machinecount = machinelist.Count.ToString();
                //                        }
                //                        all_device.Buildingname = buildinglist[j].buildingname;
                //                        all_device.Devicetype = typemodel[k].devicetype;
                //                        List<Maticsoft.Model.device_infor> devicelist_type = new List<Maticsoft.Model.device_infor>();
                //                        devicelist_type = deviceservice.GetModelList("buildingname='" + buildinglist[j].buildingname + "' and ysdtype='" + typemodel[k].devicetype + "'");
                //                        string sx = "";
                //                        if (devicelist_type != null && devicelist_type.Count > 0)
                //                        {
                //                            for (int m = 0; m < devicelist_type.Count; m++)
                //                            {
                //                                sx += (devicelist_type[m].devicename) + ",";
                //                            }
                //                        }
                //                        all_device.Devicelist = sx;
                //                        all_device_list.Add(all_device);
                //                    }
                //                }

                //            }
                //        }
                //    }

                //}
            }
            if (usertype == "3")
            {
                json.ReportDanwei = "admin";

                station_ds = stationservice.GetList("");
                device_ds = deviceservice.GetList(" 1=1  GROUP BY operaterNumber ");
                ysd_ds = ysdservice.GetList("");
                machine_ds = macservice.GetList("");
                if (station_ds != null && machine_ds != null && device_ds != null)
                {
                    json.DeviceTongji = startDate + "至" + endDate + "期间：测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + ysd_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪，监测主变81台，监测电抗器28台。";
                }
                //if (station_ds != null && station_ds.Tables.Count > 0)
                //{
                //    for (int i = 0; i < station_ds.Tables[0].Rows.Count; i++)
                //    {
                //        List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
                //        Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
                //        buildinglist = buildingservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //        List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
                //        machinelist = macservice.GetModelList("stationname='" + station_ds.Tables[0].Rows[i]["stationname"].ToString() + "'");
                //        if (buildinglist != null && buildinglist.Count > 0)
                //        {
                //            for (int j = 0; j < buildinglist.Count; j++)
                //            {
                //                Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
                //                List<Maticsoft.Model.devicetype_infor> typemodel = new List<Maticsoft.Model.devicetype_infor>();
                //                typemodel = typeservice.GetModelList("");
                //                if (typemodel != null && typemodel.Count > 0)
                //                {
                //                    for (int k = 0; k < typemodel.Count; k++)
                //                    {
                //                        allreportjson_device all_device = new allreportjson_device();
                //                        all_device.Stationname = station_ds.Tables[0].Rows[i]["stationname"].ToString();
                //                        if (machinelist != null)
                //                        {
                //                            all_device.Machinecount = machinelist.Count.ToString();
                //                        }
                //                        all_device.Buildingname = buildinglist[j].buildingname;
                //                        all_device.Devicetype = typemodel[k].devicetype;
                //                        List<Maticsoft.Model.device_infor> devicelist_type = new List<Maticsoft.Model.device_infor>();
                //                        devicelist_type = deviceservice.GetModelList("buildingname='" + buildinglist[j].buildingname + "' and ysdtype='" + typemodel[k].devicetype + "'");
                //                        string sx = "";
                //                        if (devicelist_type != null && devicelist_type.Count > 0)
                //                        {
                //                            for (int m = 0; m < devicelist_type.Count; m++)
                //                            {
                //                                sx += (devicelist_type[m].devicename) + ",";
                //                            }
                //                        }
                //                        all_device.Devicelist = sx;
                //                        all_device_list.Add(all_device);
                //                    }
                //                }
                //            }
                //        }
                //    }
                //}
            }
            #endregion
            //json.Device_json = all_device_list;         
            #region 高温设备统计
            //List<string> devicelist = new List<string>();
            //DataSet Topdev = new DataSet();          
            ////获取device_infor
            //if (usertype == "0")
            //{
            //    Topdev = deviceservice.GetList("areaid='" + usermodel.areaid + "' GROUP BY stationname");
            //}
            //if (usertype == "1")
            //{
            //    Topdev = deviceservice.GetList("fenbuid='" + usermodel.fenbuid + "' GROUP BY stationname");
            //}
            //if (usertype == "2")
            //{
            //    Topdev = deviceservice.GetList("ywbid='" + usermodel.ywbid + "' GROUP BY stationname");
            //}
            //if (usertype == "3")
            //{
            //    Topdev = deviceservice.GetList("1=1  GROUP BY stationname");
            //}

            //DataTable dtx_device = new DataTable("machinecount");
            //dtx_device.Columns.Add("stationname", Type.GetType("System.String"));//变电站
            //dtx_device.Columns.Add("devicename", Type.GetType("System.String"));//设备
            //dtx_device.Columns.Add("weekvalue", Type.GetType("System.String"));//周top
            //dtx_device.Columns.Add("monthvalue", Type.GetType("System.String"));//月top
            //dtx_device.Columns.Add("historyvalue", Type.GetType("System.String"));//历史top
            //if (Topdev.Tables != null && Topdev.Tables.Count > 0)
            //{
            //    for (int i = 0; i < Topdev.Tables[0].Rows.Count; i++)//得到当前用户下的设备列表
            //    {
            //        devicelist.Add(Topdev.Tables[0].Rows[i]["deviceid"].ToString());

            //        string weektopstr = Topdev.Tables[0].Rows[i]["weektop"].ToString();
            //        string monthtopstr = Topdev.Tables[0].Rows[i]["monthtop"].ToString();
            //        string historytopstr = Topdev.Tables[0].Rows[i]["historytop"].ToString();
            //        if (weektopstr != null && monthtopstr != null && historytopstr != null && weektopstr != "" && monthtopstr != "" && historytopstr != "")
            //        {
            //            double weektop = double.Parse(weektopstr);
            //            double monthtop = double.Parse(monthtopstr);
            //            double historytop = double.Parse(historytopstr);
            //            if (weektop > 0.0 && monthtop > 0.0 && historytop > 0.0)
            //            {
            //                dtx_device.Rows.Add(new object[] { Topdev.Tables[0].Rows[i]["stationname"].ToString(), Topdev.Tables[0].Rows[i]["devicename"].ToString(), weektopstr, monthtopstr, historytopstr });
            //            }

            //        }

            //    }
            //}

            //json.Device_history_list = dtx_device;
            Maticsoft.BLL.image_record_history imageservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> imagemodellist = new List<Maticsoft.Model.image_record_history>();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            if (usertype == "0")
            {
                devicelist = deviceservice.GetModelList("areaid='" + usermodel.areaid + "'");


                //imagemodellist = imageservice.GetModelList("areaid='" + usermodel.areaid + "' and  createtime > '" + timeStart + "' and createtime<'" + timeEnd + "'  and valuemax >=80  and valuemax <150 and isalarm=0   group by devicename  ORDER BY  CAST(valuemax AS DECIMAL) DESC ");
            }
            if (usertype == "1")
            {
                devicelist = deviceservice.GetModelList("fenbuid='" + usermodel.fenbuid + "'");


                //imagemodellist = imageservice.GetModelList("fenbuid='" + usermodel.fenbuid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "'  and valuemax >=80  and valuemax <150 and isalarm=0   group by devicename ORDER BY  CAST(valuemax AS DECIMAL) DESC ");
            }
            if (usertype == "2")
            {
                devicelist = deviceservice.GetModelList("ywbid='" + usermodel.ywbid + "'");

                //imagemodellist = imageservice.GetModelList("ywbid='" + usermodel.ywbid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "'  and valuemax >=80  and valuemax <150 and isalarm=0   group by devicename ORDER BY  CAST(valuemax AS DECIMAL) DESC ");
            }
            if (usertype == "3")
            {
                devicelist = deviceservice.GetModelList("");

                //imagemodellist = imageservice.GetModelList("createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' and valuemax >=80  and valuemax <150 and isalarm=0  group by devicename ORDER BY  CAST(valuemax AS DECIMAL) DESC ");
            }
            if (devicelist != null && devicelist.Count > 0)//查询每个设备的最高温,进行显示
            {
                foreach (var device in devicelist)
                {
                    if (device != null)
                    {
                        List<Maticsoft.Model.image_record_history> imagerecordlist = imageservice.GetModelList("deviceid='" + device.deviceid + "' and createtime>'" + timeStart + "'and createtime < '" + timeEnd + "'  and valuemax >=80  and valuemax <150 and isalarm=0  ORDER BY  CAST(valuemax AS DECIMAL) DESC ");
                        if (imagerecordlist != null && imagerecordlist.Count > 0)
                        {
                            imagemodellist.Add(imagerecordlist[0]);
                        }
                    }
                }
            }

            List<string> count_80_list = new List<string>(); List<string> count_80_station = new List<string>();
            List<string> count_90_list = new List<string>(); List<string> count_90_station = new List<string>();
            List<string> count_100_list = new List<string>(); List<string> count_100_station = new List<string>();
            List<string> count_120_list = new List<string>(); List<string> count_120_station = new List<string>();
            Maticsoft.Model.alarm_push_infor alarmmodel = new Maticsoft.Model.alarm_push_infor();
            if (imagemodellist != null && imagemodellist.Count > 0)
            {
                for (int i = 0; i < imagemodellist.Count; i++)
                {
                    if (imagemodellist[i].valuemax != "" && imagemodellist[i].valuemax != null)
                    {
                        if (double.Parse(imagemodellist[i].valuemax) >= 80 && double.Parse(imagemodellist[i].valuemax) < 90)
                        {
                            if (!count_80_list.Contains(imagemodellist[i].deviceid))
                            {
                                count_80_list.Add(imagemodellist[i].recordid);
                                string his_deviceid = "";
                                string ala_stationname = "";
                                his_deviceid = imagemodellist[i].deviceid;
                                Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                                devicemodel = deviceservice.GetModel(his_deviceid);
                                if (devicemodel != null)
                                    ala_stationname = devicemodel.stationname;

                                if (!count_80_station.Contains(ala_stationname))
                                    count_80_station.Add(ala_stationname);
                            }
                        }
                        if (double.Parse(imagemodellist[i].valuemax) >= 90 && double.Parse(imagemodellist[i].valuemax) < 100)
                        {
                            if (!count_90_list.Contains(imagemodellist[i].deviceid))
                            {
                                count_90_list.Add(imagemodellist[i].recordid);
                                string his_deviceid = "";
                                string ala_stationname = "";
                                his_deviceid = imagemodellist[i].deviceid;
                                Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                                devicemodel = deviceservice.GetModel(his_deviceid);
                                if (devicemodel != null)
                                    ala_stationname = devicemodel.stationname;
                                if (!count_90_station.Contains(ala_stationname))
                                    count_90_station.Add(ala_stationname);
                            }
                        }
                        if (double.Parse(imagemodellist[i].valuemax) >= 100 && double.Parse(imagemodellist[i].valuemax) < 120)
                        {
                            if (!count_100_list.Contains(imagemodellist[i].deviceid))
                            {
                                count_100_list.Add(imagemodellist[i].recordid);
                                string his_deviceid = "";
                                string ala_stationname = "";
                                his_deviceid = imagemodellist[i].deviceid;
                                Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                                devicemodel = deviceservice.GetModel(his_deviceid);
                                if (devicemodel != null)
                                    ala_stationname = devicemodel.stationname;
                                if (!count_100_station.Contains(ala_stationname))
                                    count_100_station.Add(ala_stationname);
                            }
                        }
                        if (double.Parse(imagemodellist[i].valuemax) >= 120 && double.Parse(imagemodellist[i].valuemax) < 140)
                        {
                            if (!count_120_list.Contains(imagemodellist[i].deviceid))
                            {
                                count_120_list.Add(imagemodellist[i].recordid);
                                string his_deviceid = "";
                                string ala_stationname = "";
                                his_deviceid = imagemodellist[i].deviceid;
                                Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                                devicemodel = deviceservice.GetModel(his_deviceid);
                                if (devicemodel != null)
                                    ala_stationname = devicemodel.stationname;
                                if (!count_120_station.Contains(ala_stationname))
                                    count_120_station.Add(ala_stationname);
                            }
                        }
                    }
                }

            }
            string count1 = count_80_list.Count().ToString();
            string count2 = count_90_list.Count().ToString();
            string count3 = count_100_list.Count().ToString();
            string count4 = count_120_list.Count().ToString();
            DataTable dtx = new DataTable("machinecount");
            dtx.Columns.Add("createtime", Type.GetType("System.String"));
            dtx.Columns.Add("stationname", Type.GetType("System.String"));
            dtx.Columns.Add("devicename", Type.GetType("System.String"));
            dtx.Columns.Add("valuemax", Type.GetType("System.String"));
            dtx.Columns.Add("offsetvalue", Type.GetType("System.String"));
            for (int i = 0; i < count_120_list.Count; i++)
            {
                Maticsoft.Model.image_record_history lm = new Maticsoft.Model.image_record_history();
                lm = imageservice.GetModel(count_120_list[i]);
                if (lm != null)
                {
                    Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(lm.deviceid);
                    if (devicemodel != null)
                    {
                        dtx.Rows.Add(new object[] { lm.createtime.ToString(), devicemodel.stationname, lm.devicename, lm.valuemax, devicemodel.offsetvalue });
                    }

                }
            }
            for (int i = 0; i < count_80_list.Count; i++)
            {
                Maticsoft.Model.image_record_history lm = new Maticsoft.Model.image_record_history();
                lm = imageservice.GetModel(count_80_list[i]);
                if (lm != null)
                {
                    Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(lm.deviceid);
                    if (devicemodel != null)
                    {
                        dtx.Rows.Add(new object[] { lm.createtime.ToString(), devicemodel.stationname, lm.devicename, lm.valuemax, devicemodel.offsetvalue });
                    }
                }
            }
            for (int i = 0; i < count_90_list.Count; i++)
            {
                Maticsoft.Model.image_record_history lm = new Maticsoft.Model.image_record_history();
                lm = imageservice.GetModel(count_90_list[i]);
                if (lm != null)
                {
                    Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(lm.deviceid);
                    if (devicemodel != null)
                    {
                        dtx.Rows.Add(new object[] { lm.createtime.ToString(), devicemodel.stationname, lm.devicename, lm.valuemax, devicemodel.offsetvalue });
                    }
                }
            }
            for (int i = 0; i < count_100_list.Count; i++)
            {
                Maticsoft.Model.image_record_history lm = new Maticsoft.Model.image_record_history();
                lm = imageservice.GetModel(count_100_list[i]);
                if (lm != null)
                {
                    Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(lm.deviceid);
                    if (devicemodel != null)
                    {
                        dtx.Rows.Add(new object[] { lm.createtime.ToString(), devicemodel.stationname, lm.devicename, lm.valuemax, devicemodel.offsetvalue });
                    }
                }
                //Maticsoft.Model.alarm_push_infor lm = new Maticsoft.Model.alarm_push_infor();
                //lm = alarmservice.GetModel(count_100_list[i]);
                //string offset = deviceservice.GetModel(lm.deviceid).offsetvalue;
                //string isalarm = "";
                //if (offset != "")
                //{
                //    if (double.Parse(offset) >= 100)
                //        isalarm = "是";
                //}

                //dtx.Rows.Add(new object[] { lm.createtime.ToString(), lm.stationname, lm.devicename, lm.alarmvalue, offset, isalarm });
            }
            string station_80_str = "";
            if (count_80_station != null && count_80_station.Count > 0)
            {
                for (int i = 0; i < count_80_station.Count; i++)
                {
                    if (i == (count_80_station.Count() - 1))
                    {
                        station_80_str += count_80_station[i] + "。";
                    }
                    else
                    {
                        station_80_str += count_80_station[i] + "、";
                    }
                }

            }
            string station_90_str = "";
            if (count_90_station != null && count_90_station.Count > 0)
            {
                for (int i = 0; i < count_90_station.Count; i++)
                {
                    if (i == (count_90_station.Count() - 1))
                    {
                        station_90_str += count_90_station[i] + "。";
                    }
                    else
                    {
                        station_90_str += count_90_station[i] + "、";
                    }
                    //station_90_str += count_90_station[i] + "、";
                }
            }
            string station_100_str = "";
            if (count_100_station != null && count_100_station.Count > 0)
            {
                for (int i = 0; i < count_100_station.Count; i++)
                {
                    if (i == (count_100_station.Count() - 1))
                    {
                        station_100_str += count_100_station[i] + "。";
                    }
                    else
                    {
                        station_100_str += count_100_station[i] + "、";
                    }
                    //station_100_str += count_100_station[i] + "、";
                }
            }
            string station_120_str = "";
            if (count_120_station != null && count_120_station.Count > 0)
            {
                for (int i = 0; i < count_120_station.Count; i++)
                {
                    if (i == (count_120_station.Count() - 1))
                    {
                        station_120_str += count_120_station[i] + "。";
                    }
                    else
                    {
                        station_120_str += count_120_station[i] + "、";
                    }
                    //station_120_str += count_120_station[i] + "、";
                }
            }
            json.DeviceTongji2 = json.DeviceTongji + ",监测主变81台，监测电抗器28台。";
            //json.DeviceTongji2 = json.DeviceTongji;
            //json.DeviceTongji = string.Empty;
            json.DeviceTongji += "共检测到超80℃监测点：" + count1 + "处；超90℃：" + count2 + "处；超100℃："+ count3 + "处；超120℃：" + count4 + "处。";
            json.DeviceTongji1 = "在" + startDate + "至" + endDate + "之间超80℃监测点：" + count1 + "处；超90℃：" + count2 + "处；超100℃：" + count3 + "处；超120℃：" + count4 + "处。";
            //json.HightemputerTongji = "超80℃监测点：" + count1 + "处:来自于：" + station_80_str + "；\r\n超90℃：" + count2 + "处,来自于：" + station_90_str + ";\r\n超100℃：" + count3 + "处,来自于：" + station_100_str + ";\r\n超120℃：" + count4 + "处，来自于：" + station_120_str + ";";
            #region 超过80
            if (int.Parse(count1) >0)
            {
                json.Over_80_tongji = "超80℃监测点：" + count1 + "处，分别是：" + station_80_str;

            }
            else
            {
                json.Over_80_tongji = "超80℃监测点：0处；";
            }
            DataTable dtx_device_over_80 = new DataTable("machinecount");
            dtx_device_over_80.Columns.Add("createtime", Type.GetType("System.String"));
            dtx_device_over_80.Columns.Add("stationname", Type.GetType("System.String"));
            dtx_device_over_80.Columns.Add("devicename", Type.GetType("System.String"));
            dtx_device_over_80.Columns.Add("overvlaue", Type.GetType("System.String"));
            dtx_device_over_80.Columns.Add("offsetvalue", Type.GetType("System.String"));
            dtx_device_over_80.Columns.Add("image_high", Type.GetType("System.String"));
            dtx_device_over_80.Columns.Add("image_red", Type.GetType("System.String"));
            if (imagemodellist != null && imagemodellist.Count > 0)
            {
                for (int i = 0; i < imagemodellist.Count; i++)
                {
                    string smm = imagemodellist[i].valuemax;
                    if (smm != "")
                    {
                        if (double.Parse(smm) >= 80 && double.Parse(smm) < 90)
                        {
                            string deviceid_id = imagemodellist[i].deviceid;
                            Maticsoft.Model.device_infor devmmm = new Maticsoft.Model.device_infor();
                            devmmm = deviceservice.GetModel(deviceid_id);
                            if (devmmm != null)
                            {
                                dtx_device_over_80.Rows.Add(new object[] { imagemodellist[i].createtime.Value.ToString(), devmmm.stationname, imagemodellist[i].devicename, imagemodellist[i].valuemax + "℃", devmmm.offsetvalue + "℃", imagemodellist[i].image0, imagemodellist[i].image1 });
                            }
                            //if (devmmm != null)
                            //{
                            //string his_deviceid = "";
                            //string ala_stationname = "";
                            //his_deviceid = hismodellist[i].deviceid;
                            //Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                            //devicemodel = deviceservice.GetModel(his_deviceid);
                            //if (devicemodel != null)
                            //    ala_stationname = devicemodel.stationname;
                            //dtx_device_over_80.Rows.Add(new object[] { hismodellist[i].createtime.Value.ToString(), ala_stationname, hismodellist[i].devicename, hismodellist[i].alarmvalue, devmmm.offsetvalue, hismodellist[i].image_url, devmmm.image_high });
                            //}
                        }
                    }
                }

            }

            json.Over_80_list = dtx_device_over_80;
            #endregion
            #region 超过90
            if (int.Parse(count2) >0)
            {
                 json.Over_90_tongji = "超90℃监测点：" + count2 + "处，分别是：" + station_90_str;
            }
            else
            {
                json.Over_90_tongji = "超90℃监测点：0处；";
            }
            DataTable dtx_device_over_90 = new DataTable("machinecount");
            dtx_device_over_90.Columns.Add("createtime", Type.GetType("System.String"));
            dtx_device_over_90.Columns.Add("stationname", Type.GetType("System.String"));
            dtx_device_over_90.Columns.Add("devicename", Type.GetType("System.String"));
            dtx_device_over_90.Columns.Add("overvlaue", Type.GetType("System.String"));
            dtx_device_over_90.Columns.Add("offsetvalue", Type.GetType("System.String"));
            dtx_device_over_90.Columns.Add("image_high", Type.GetType("System.String"));
            dtx_device_over_90.Columns.Add("image_red", Type.GetType("System.String"));
            if (imagemodellist != null && imagemodellist.Count > 0)
            {
                for (int i = 0; i < imagemodellist.Count; i++)
                {
                    string smm = imagemodellist[i].valuemax;
                    if (smm != "")
                    {
                        if (double.Parse(smm) >= 90 && double.Parse(smm) < 100)
                        {
                            string deviceid_id = imagemodellist[i].deviceid;
                            Maticsoft.Model.device_infor devmmm = new Maticsoft.Model.device_infor();
                            devmmm = deviceservice.GetModel(deviceid_id);
                            if (devmmm != null)
                            {
                                dtx_device_over_90.Rows.Add(new object[] { imagemodellist[i].createtime.Value.ToString(), devmmm.stationname, imagemodellist[i].devicename, imagemodellist[i].valuemax + "℃", devmmm.offsetvalue + "℃", imagemodellist[i].image0, imagemodellist[i].image1 });
                            }
                            //string his_deviceid = "";
                            //string ala_stationname = "";
                            //his_deviceid = hismodellist[i].deviceid;
                            //Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                            //devicemodel = deviceservice.GetModel(his_deviceid);
                            //if (devicemodel != null)
                            //    ala_stationname = devicemodel.stationname;
                            //if (devmmm != null)
                            //{
                            //    dtx_device_over_90.Rows.Add(new object[] { hismodellist[i].createtime.Value.ToString(), ala_stationname, hismodellist[i].devicename, hismodellist[i].alarmvalue, devmmm.offsetvalue, hismodellist[i].image_url, devmmm.image_high });
                            //}


                        }
                    }
                }

            }

            json.Over_90_list = dtx_device_over_90;
            #endregion
            #region 超过100
            if (int.Parse(count3) > 0)
            {
                json.Over_100_tongji = "超100℃监测点：" + count3 + "处，分别是：" + station_100_str;
            }
            else
            {
                json.Over_100_tongji = "超100℃监测点：0处；" ;   
            }
            DataTable dtx_device_over_100 = new DataTable("machinecount");
            dtx_device_over_100.Columns.Add("createtime", Type.GetType("System.String"));
            dtx_device_over_100.Columns.Add("stationname", Type.GetType("System.String"));
            dtx_device_over_100.Columns.Add("devicename", Type.GetType("System.String"));
            dtx_device_over_100.Columns.Add("overvlaue", Type.GetType("System.String"));
            dtx_device_over_100.Columns.Add("offsetvalue", Type.GetType("System.String"));
            dtx_device_over_100.Columns.Add("image_high", Type.GetType("System.String"));
            dtx_device_over_100.Columns.Add("image_red", Type.GetType("System.String"));
            if (imagemodellist != null && imagemodellist.Count > 0)
            {
                for (int i = 0; i < imagemodellist.Count; i++)
                {
                    string smm = imagemodellist[i].valuemax;
                    if (smm != "")
                    {
                        if (double.Parse(smm) >= 100 && double.Parse(smm) < 120)
                        {
                            string deviceid_id = imagemodellist[i].deviceid;
                            Maticsoft.Model.device_infor devmmm = new Maticsoft.Model.device_infor();
                            devmmm = deviceservice.GetModel(deviceid_id);
                            if (devmmm != null)
                            {
                                dtx_device_over_100.Rows.Add(new object[] { imagemodellist[i].createtime.Value.ToString(), devmmm.stationname, imagemodellist[i].devicename, imagemodellist[i].valuemax + "℃", devmmm.offsetvalue + "℃", imagemodellist[i].image0, imagemodellist[i].image1 });
                            }
                            //string his_deviceid = "";
                            //string ala_stationname = "";
                            //his_deviceid = hismodellist[i].deviceid;
                            //Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                            //devicemodel = deviceservice.GetModel(his_deviceid);
                            //if (devicemodel != null)
                            //    ala_stationname = devicemodel.stationname;
                            //if (devmmm != null)
                            //{
                            //    dtx_device_over_100.Rows.Add(new object[] { hismodellist[i].createtime.Value.ToString(), ala_stationname, hismodellist[i].devicename, hismodellist[i].alarmvalue, devmmm.offsetvalue, hismodellist[i].image_url, devmmm.image_high });
                            //}


                        }
                    }
                }

            }

            json.Over_100_list = dtx_device_over_100;
            #endregion
            #region 超过120
            if (int.Parse(count4) >0)
            {
                json.Over_120_tongji = "超120℃监测点：" + count4 + "处，分别是：" + station_120_str;
            }
            else
            {
                json.Over_120_tongji = "超120℃监测点：0处。";
            }
           
            DataTable dtx_device_over_120 = new DataTable("machinecount");
            dtx_device_over_120.Columns.Add("createtime", Type.GetType("System.String"));
            dtx_device_over_120.Columns.Add("stationname", Type.GetType("System.String"));
            dtx_device_over_120.Columns.Add("devicename", Type.GetType("System.String"));
            dtx_device_over_120.Columns.Add("overvlaue", Type.GetType("System.String"));
            dtx_device_over_120.Columns.Add("offsetvalue", Type.GetType("System.String"));
            dtx_device_over_120.Columns.Add("image_high", Type.GetType("System.String"));
            dtx_device_over_120.Columns.Add("image_red", Type.GetType("System.String"));
            if (imagemodellist != null && imagemodellist.Count > 0)
            {
                for (int i = 0; i < imagemodellist.Count; i++)
                {
                    string smm = imagemodellist[i].valuemax;
                    if (smm != "")
                    {
                        if (double.Parse(smm) >= 120 && double.Parse(smm) < 140)
                        {
                            string deviceid_id = imagemodellist[i].deviceid;
                            Maticsoft.Model.device_infor devmmm = new Maticsoft.Model.device_infor();
                            devmmm = deviceservice.GetModel(deviceid_id);
                            if (devmmm != null)
                            {
                                dtx_device_over_120.Rows.Add(new object[] { imagemodellist[i].createtime.Value.ToString(), devmmm.stationname, imagemodellist[i].devicename, imagemodellist[i].valuemax+ "℃", devmmm.offsetvalue + "℃", imagemodellist[i].image0, imagemodellist[i].image1 });
                            }
                            //string his_deviceid = "";
                            //string ala_stationname = "";
                            //his_deviceid = hismodellist[i].deviceid;
                            //Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                            //devicemodel = deviceservice.GetModel(his_deviceid);
                            //if (devicemodel != null)
                            //    ala_stationname = devicemodel.stationname;
                            //if (devmmm != null)
                            //{
                            //    dtx_device_over_120.Rows.Add(new object[] { hismodellist[i].createtime.Value.ToString(), ala_stationname, hismodellist[i].devicename, hismodellist[i].alarmvalue, devmmm.offsetvalue, hismodellist[i].image_url, devmmm.image_high });
                            //}


                        }
                    }
                }

            }
            json.Over_120_list = dtx_device_over_120;
            #endregion
            //json.HightemputerDevlist1 = dtx;
            //DataTable dtx_station = new DataTable("machinecount");
            //dtx_station.Columns.Add("createtime", Type.GetType("System.String"));//创建时间
            //dtx_station.Columns.Add("stationname", Type.GetType("System.String"));//变电站
            //dtx_station.Columns.Add("devicename", Type.GetType("System.String"));//检测设备
            //dtx_station.Columns.Add("alarmvalue", Type.GetType("System.String"));//温度
            //dtx_station.Columns.Add("offsetvalue", Type.GetType("System.String"));//告警阈值

            //for (int i = 0; i < station_ds.Tables[0].Rows.Count; i++)
            //{
            //    string stationid = station_ds.Tables[0].Rows[i]["stationid"].ToString();
            //    Maticsoft.BLL.station_top_history topservice = new Maticsoft.BLL.station_top_history();

            //    List<Maticsoft.Model.station_top_history> toplist = new List<Maticsoft.Model.station_top_history>();
            //    toplist = topservice.GetModelList("stationid='"+stationid+"'and toptime >'" + startDate + "'and toptime < '" + endDate + "'");                
            //    List<double> itemvaluelist = new List<double>();
            //    List<string> itemtoprecordidlist = new List<string>();
            //   foreach (var item in toplist)
            //   {
            //      itemvaluelist.Add(double.Parse(item.todaytop));
            //      itemtoprecordidlist.Add(item.toprecordid);
            //   }
            //   if (itemvaluelist.Count>0)
            //    {
            //        int index = getMaxindex(itemvaluelist);//最大值的索引
            //        string maxtoprecordid = itemtoprecordidlist[index];//最大值
            //        Maticsoft.Model.station_top_history topmodel = new Maticsoft.Model.station_top_history();
            //        topmodel = topservice.GetModel(maxtoprecordid);
            //        if (topmodel != null)
            //            {
            //                dtx_station.Rows.Add(new object[] { topmodel.toptime, topmodel.stationname, topmodel.topdevicename, topmodel.todaytop, topmodel.offsetvalue });
            //            }
            //        }

            //}
            //json.DeviceTongji3 = startDate + "至" + endDate + "期间，各站监测最高温度情况如下：";
            //json.Station_top_value = dtx_station;

            json.HightemputerDevlist1 = dtx;

            //各站最高温统计
            DataTable dtx_station = new DataTable("machinecount");
            dtx_station.Columns.Add("createtime", Type.GetType("System.String"));
            dtx_station.Columns.Add("stationname", Type.GetType("System.String"));
            dtx_station.Columns.Add("devicename", Type.GetType("System.String"));
            dtx_station.Columns.Add("alarmvalue", Type.GetType("System.String"));
            dtx_station.Columns.Add("offsetvalue", Type.GetType("System.String"));
            dtx_station.Columns.Add("offsetstatus", Type.GetType("System.String"));//超过80度
            dtx_station.Columns.Add("alarmstatus", Type.GetType("System.String"));//超过预警值
           
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            if (usertype == "0")
            {
                stationlist = stationservice.GetModelList("areaid='" + usermodel.areaid + "'");
            }
            if (usertype == "1")
            {
                stationlist = stationservice.GetModelList("fenbuid='" + usermodel.fenbuid + "'");
            }
            if (usertype == "2")
            {
                stationlist = stationservice.GetModelList("ywbid='" + usermodel.ywbid + "'");
            }
            if (usertype == "3")
            {
                stationlist = stationservice.GetModelList("");
            }
            // stationlist = stationservice.GetModelList("areaid='" + usermodel.areaid + "'");
            if (stationlist != null && stationlist.Count > 0)
            {
                for (int i = 0; i < stationlist.Count; i++)
                {
                    string stationid = stationlist[i].stationid;
                    List<double> valuemaxs = new List<double>();
                    List<string> creaatetimes = new List<string>();
                    List<Maticsoft.Model.device_infor> devices = new List<Maticsoft.Model.device_infor>();
                    //获取变电站的最高温
                    List<Maticsoft.Model.image_record_history> imageList = new List<Maticsoft.Model.image_record_history>();
                    string sql = "deviceid in(select deviceid from device_infor where stationid = '" + stationid + "')  and createtime >'" + timeStart + "'and createtime < '" + timeEnd + "' ORDER BY  CAST(valuemax AS DECIMAL) DESC";
                    imageList = imageservice.GetModelList(sql);
                    if (imageList != null && imageList.Count > 0)
                    {
                        if (imageList[0] != null)
                        {
                            Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(imageList[0].deviceid);
                            string offsetstatus = "0";
                            string alarmstatus = "0";
                            if (devicemodel != null)
                            {
                                if (double.Parse(imageList[0].valuemax) >= 80)//超过80度，该温度值显示红色
                                {
                                    offsetstatus = "1";
                                }
                                if (double.Parse(imageList[0].valuemax) >= double.Parse(devicemodel.offsetvalue))//超过预警值，该温度和告警值都显示红色
                                {
                                    alarmstatus = "1";
                                }
                            }
                            dtx_station.Rows.Add(new object[] { imageList[0].createtime.ToString(), devicemodel.stationname, devicemodel.devicename, imageList[0].valuemax + "℃", devicemodel.offsetvalue + "℃", offsetstatus, alarmstatus });
                        }

                    }




                    //List<Maticsoft.Model.device_infor> deviceList = deviceservice.GetModelList("stationid='" + stationid + "'");
                    //List<Maticsoft.Model.image_record_history> imageList = new List<Maticsoft.Model.image_record_history>();
                    //if (deviceList != null && deviceList.Count>0)
                    //{
                    //    foreach (var item in deviceList)
                    //    {
                    //        if (item!=null)
                    //        {
                    //            //imageList = historyservice.GetModelList("deviceid='" + item.deviceid + "'and createtime >'" + startDate + "'and createtime < '" + endDate + "'");
                    //            imageList = imageservice.GetModelList("deviceid='" + item.deviceid + "'and createtime >'" + startDate + "'and createtime < '" + endDate + "'");
                    //            if (imageList.Count > 0)
                    //            {
                    //                for (int image = 0; image < imageList.Count; image++)
                    //                {
                    //                    valuemaxs.Add(double.Parse(imageList[image].valuemax));
                    //                    creaatetimes.Add(imageList[image].createtime.ToString());
                    //                    devices.Add(item);

                    //                }
                    //            }
                    //        }
                    //    }
                    //}
                    //if (valuemaxs.Count > 0)
                    //{
                    //    int index = getMaxindex(valuemaxs);//最大值的索引                    
                    //    double valuemaxslistmax = valuemaxs[index];
                    //    string creaatetimemax = creaatetimes[index];//最大值
                    //    Maticsoft.Model.device_infor devicemax = devices[index];
                    //    if (devicemax != null)
                    //    {                            
                    //        dtx_station.Rows.Add(new object[] { creaatetimemax, devicemax.stationname, devicemax.devicename, valuemaxslistmax + "℃", devicemax.offsetvalue + "℃" });
                    //    }
                    //}
                }
            }
            json.DeviceTongji3 = startDate + "至" + endDate + "期间，各站监测最高温度情况如下：";
            json.Station_top_value = dtx_station;




            #endregion
            #region 测温异常告警统计
            List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
            if (usertype == "0")
            {
                alarmlist = alarmservice.GetModelList("areaid='" + usermodel.areaid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' group by devicename  ORDER BY  CAST(alarmvalue AS DECIMAL) DESC ");

            }
            if (usertype == "1")
            {
                alarmlist = alarmservice.GetModelList("fenbuid='" + usermodel.fenbuid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' group by devicename  ORDER BY  CAST(alarmvalue AS DECIMAL) DESC ");
            }
            if (usertype == "2")
            {
                alarmlist = alarmservice.GetModelList("ywbid='" + usermodel.ywbid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' group by devicename  ORDER BY  CAST(alarmvalue AS DECIMAL) DESC ");

            }
            if (usertype == "3")
            {
                alarmlist = alarmservice.GetModelList(" createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' group by devicename  ORDER BY  CAST(alarmvalue AS DECIMAL) DESC ");

            }
            string sheader = "告警共0条。";


            #endregion
            DataTable alarmtable = new DataTable();
            alarmtable.Columns.Add("headerText", Type.GetType("System.String"));
            alarmtable.Columns.Add("image1", Type.GetType("System.String"));
            alarmtable.Columns.Add("image2", Type.GetType("System.String"));
            alarmtable.Columns.Add("image_week", Type.GetType("System.String"));
            alarmtable.Columns.Add("image_month", Type.GetType("System.String"));
            alarmtable.Columns.Add("image_history", Type.GetType("System.String"));
            alarmtable.Columns.Add("bottonText", Type.GetType("System.String"));
            if (alarmlist != null && alarmlist.Count > 0)
            {
                sheader = "告警共" + alarmlist.Count.ToString() + "条：";
                for (int i = 0; i < alarmlist.Count; i++)
                {
                    string dengjifuhe = "无";
                    string querenrenyuan = "无";
                    if (alarmlist[i].fuhe != "" && alarmlist[i].fuhe != null)
                    {
                        dengjifuhe = alarmlist[i].fuhe;
                    }
                    if (alarmlist[i].mensurehuman != "" && alarmlist[i].mensurehuman != null)
                    {
                        querenrenyuan = alarmlist[i].mensurehuman;
                    }
                    string s1 = "";
                    string imagename = alarmlist[i].image_url;
                    string image1 = "";
                    string image2 = "";
                    if (imagename.Contains("~0~"))
                    {
                        image1 = imagename;
                        image2 = imagename.Replace("~0~", "~1~");
                    }
                    if (imagename.Contains("~1~"))
                    {
                        image2 = imagename;
                        image1 = imagename.Replace("~1~", "~0~");
                    }
                    if (imagename.Contains("~2~"))
                    {
                        image1 = imagename.Replace("~2~", "~0~");
                        image2 = imagename.Replace("~2~", "~1~");
                    }
                    Maticsoft.Model.device_infor devmmm = new Maticsoft.Model.device_infor();
                    devmmm = deviceservice.GetModel(alarmlist[i].deviceid);
                    if (devmmm != null)
                    {
                        string s2 = "";
                        string fuhe = devmmm.fuhe;
                        if (fuhe == "" || fuhe == null)
                            fuhe = "未填写";
                        s2 = alarmlist[i].stationname + "  " + alarmlist[i].devicename + "   " + alarmlist[i].alarmvalue + "℃(阈值：" + devmmm.offsetvalue + "℃) 负荷：" + fuhe + "告警时间：" + alarmlist[i].createtime.ToString();
                        if (image1 != "" || image2 != "")
                        {
                            string image_week = "";
                            //if(devmmm.weekmaxid!=""&&devmmm.weekmaxid!=null)
                            //{
                            //    if (null != historyservice.GetModel(devmmm.weekmaxid).image1)
                            //    {
                            //        if (historyservice.GetModel(devmmm.weekmaxid).image1 != null)
                            //            image_week = historyservice.GetModel(devmmm.weekmaxid).image1;
                            //    }
                            //}

                            string image_month = "";
                            //if(devmmm.monthmaxid!=""&&devmmm.monthmaxid!=null)
                            //{
                            //    if (null != historyservice.GetModel(devmmm.monthmaxid).image1)
                            //    {
                            //        if (historyservice.GetModel(devmmm.monthmaxid).image1 != null)
                            //            image_month = historyservice.GetModel(devmmm.monthmaxid).image1;
                            //    }
                            //}

                            string image_his = "";
                            //if(devmmm.historymaxid!=""&&devmmm.historymaxid!=null)
                            //{
                            //    if (null != historyservice.GetModel(devmmm.historymaxid).image1)
                            //    {
                            //        if (historyservice.GetModel(devmmm.historymaxid).image1 != null)
                            //            image_his = historyservice.GetModel(devmmm.historymaxid).image1;
                            //    }
                            //}


                            alarmtable.Rows.Add(new object[] { s1, image1, image2, image_week, image_month, image_his, s2 });

                        }
                    }

                }

            }
            json.AlarmTongji = sheader;
            json.DtAlarm = alarmtable;

            #region 趋势统计

            DataTable shengwentable = new DataTable();
            shengwentable = null;
            json.QushiTongji = "过去一周持续升温的设备数量：0处。";// + shengwentable.Rows.Count.ToString() + "处";
            json.DtQushi = shengwentable;
            //json.Downloadurl = geturl(userid,startDate,endDate,"史久峰");
            //导出文档
            string JsonToStr = JsonConvert.SerializeObject(json);
            CreateWordHelper createWord = new CreateWordHelper(JsonToStr);
            string SaveFilePath = createWord.TryCreateword();
            json.Downloadurl = SaveFilePath;
            json.reporthuman = "史久峰";
            #endregion
            return (Newtonsoft.Json.JsonConvert.SerializeObject(json));
        }

        public DataTable getSevenDaysTempRasexx(string userid, string hour)
        {
            List<sevendayRasejson> jsonlist = new List<sevendayRasejson>();
            Maticsoft.BLL.user_infor uservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = uservice.GetModel(userid);
            Maticsoft.BLL.device_infor devicemm = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            string isround = "1";
            if (usermodel.usertype == "0")
            {
                devicelist = devicemm.GetModelList("areaid='" + usermodel.areaid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "1")
            {
                devicelist = devicemm.GetModelList("fenbuid='" + usermodel.fenbuid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "2")
            {
                devicelist = devicemm.GetModelList("ywbid='" + usermodel.ywbid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "3")
            {
                devicelist = devicemm.GetModelList("isroundpoint='" + isround + "'");
            }
            if (devicelist.Count < 1)
                return null;
            DataTable shengwentable = new DataTable();
            shengwentable.Columns.Add("headerText", Type.GetType("System.String"));
            shengwentable.Columns.Add("temp_24", Type.GetType("System.String"));
            shengwentable.Columns.Add("temp_week", Type.GetType("System.String"));
            for (int mk = 0; mk < devicelist.Count(); mk++)
            {
                string deviceid = devicelist[mk].deviceid;
                Maticsoft.BLL.device_infor dser = new Maticsoft.BLL.device_infor();
                Maticsoft.Model.device_infor dmodel = new Maticsoft.Model.device_infor();
                dmodel = dser.GetModel(deviceid);
                if (dmodel == null)
                    return null;
                string devicename = dmodel.devicename;
                string machineid = dmodel.machineid;
                string machinename = dmodel.machinename;
                List<string> returnlist = new List<string>();

                string startDate = System.DateTime.Now.AddDays(-7).Date.ToString();
                string endDate = System.DateTime.Now.Date.ToString();
                string[] stimelist = null;

                List<string> testlist = new List<string>();
                for (int i = 0; i < 24; i++)
                {
                    testlist.Add(i.ToString("00"));
                    returnlist.Add(i.ToString("00") + ":00");
                }
                stimelist = testlist.ToArray();

                DateTime dateStart, dateEnd;
                DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                dateStart = Convert.ToDateTime(startDate, dtFormat);
                dateEnd = Convert.ToDateTime(endDate, dtFormat);

                TimeSpan ts1 = new TimeSpan(dateEnd.Ticks);
                TimeSpan ts2 = new TimeSpan(dateStart.Ticks);
                TimeSpan ts = ts1.Subtract(ts2).Duration();
                int dateSpan = ts.Days;



                List<string> datelist = new List<string>();
                for (int i = 0; i < dateSpan + 1; i++)
                {
                    datelist.Add((dateStart.AddDays(i).Date).ToString("yyyy-MM-dd"));
                }

                Maticsoft.BLL.image_record_history histryservice = new Maticsoft.BLL.image_record_history();
                List<Maticsoft.Model.image_record_history> histrymodel = new List<Maticsoft.Model.image_record_history>();
                histrymodel = histryservice.GetModelList("deviceid='" + deviceid + "'and createtime>'" + dateStart + "' and createtime<'" + dateEnd.AddDays(1) + "'");

                List<List<double>> wendulistall = new List<List<double>>();
                for (int i = 0; i < stimelist.Length; i++)
                {
                    List<double> newlist = new List<double>();
                    for (int k = 0; k < datelist.Count(); k++)
                    {
                        string riqi = datelist[k];
                        string shijian = stimelist[i];
                        string svalue = "0.0";
                        for (int m = 0; m < histrymodel.Count(); m++)
                        {
                            string ssriqi = histrymodel[m].createtime.Value.Year.ToString() + "-" + histrymodel[m].createtime.Value.Month.ToString("00") + "-" + histrymodel[m].createtime.Value.Day.ToString("00");
                            string ssshijian = histrymodel[m].createtime.Value.Hour.ToString("00");

                            if (riqi == ssriqi && shijian == ssshijian)
                            {
                                svalue = histrymodel[m].valuemax;
                            }
                        }
                        newlist.Add(double.Parse(svalue));

                    }
                    double xxx0 = (newlist[0]);
                    for (int xx = 1; xx < newlist.Count(); xx++)
                    {
                        double xxx = (newlist[xx]);
                        if (xxx == 0.0)
                        {
                            xxx = (newlist[xx - 1]);
                            newlist.RemoveAt(xx);
                            newlist.Insert(xx, xxx);
                        }
                    }
                    if ((newlist[0] - newlist[1] < 0) && ((newlist[newlist.Count - 3] - newlist[newlist.Count - 2]) < 0) && newlist[0] > 0)
                    {
                        wendulistall.Add(newlist);
                    }
                }

                for (int xk = 0; xk < wendulistall.Count(); xk++)
                {
                    if (IsIncreasingMontonically(wendulistall[xk]))
                    {
                        string headertext = devicelist[mk].stationname + " " + devicelist[mk].devicename + " 上周最高温：" + wendulistall[xk].Max().ToString("0.0") + "℃ 本周最高温：" + wendulistall[xk].Min().ToString("0.0") + "℃";


                        string s = "";
                        for (int kk = System.DateTime.Now.AddDays(-7).Day; kk < System.DateTime.Now.AddDays(-7).Day + 7; kk++)
                        {
                            s += kk.ToString("00") + ";" + wendulistall[xk][kk - System.DateTime.Now.AddDays(-7).Day] + ",";
                        }
                        shengwentable.Rows.Add(new object[] { headertext, "", s.Remove(s.Length - 1, 1) });

                    }
                }
            }
            return shengwentable;
        }
        public string saveAllreport(string peo1, string peo2)
        {
            Maticsoft.BLL.report_ywb s = new Maticsoft.BLL.report_ywb();
            Maticsoft.Model.report_ywb m = new Maticsoft.Model.report_ywb();
            m.ywbreportid = Guid.NewGuid().ToString("N");
            m.reporttime = System.DateTime.Now;
            m.reportdanwei = "";
            s.Add(m);

            return "保存成功";
        }

        public string getRase(string userid)
        {
            List<sevendayRasejson> jsonlist = new List<sevendayRasejson>();

            Maticsoft.BLL.user_infor uservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = uservice.GetModel(userid);
            Maticsoft.BLL.device_infor devicemm = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            if (usermodel.usertype == "0")
            {
                devicelist = devicemm.GetModelList("areaid='" + usermodel.areaid + "'");
            }
            if (usermodel.usertype == "1")
            {
                devicelist = devicemm.GetModelList("fenbuid='" + usermodel.fenbuid + "'");
            }
            if (usermodel.usertype == "2")
            {
                devicelist = devicemm.GetModelList("ywbid='" + usermodel.ywbid + "'");
            }
            if (usermodel.usertype == "3")
            {
                devicelist = devicemm.GetModelList("");
            }
            if (devicelist.Count < 1)
                return "0";
            for (int mk = 0; mk < devicelist.Count(); mk++)
            {
                string deviceid = devicelist[mk].deviceid;

                Maticsoft.BLL.device_infor dser = new Maticsoft.BLL.device_infor();
                Maticsoft.Model.device_infor dmodel = new Maticsoft.Model.device_infor();
                dmodel = dser.GetModel(deviceid);
                if (dmodel == null)
                    return "没有此设备";

                string devicename = dmodel.devicename;
                string machineid = dmodel.machineid;
                string machinename = dmodel.machinename;
                List<string> returnlist = new List<string>();

                string startDate = System.DateTime.Now.AddDays(-7).Date.ToString();
                string endDate = System.DateTime.Now.Date.ToString();
                string[] stimelist = null;

                List<string> testlist = new List<string>();
                for (int i = 0; i < 24; i++)
                {
                    testlist.Add(i.ToString("00"));
                    returnlist.Add(i.ToString("00") + ":00");
                }
                stimelist = testlist.ToArray();

                DateTime dateStart, dateEnd;
                DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                dateStart = Convert.ToDateTime(startDate, dtFormat);
                dateEnd = Convert.ToDateTime(endDate, dtFormat);

                TimeSpan ts1 = new TimeSpan(dateEnd.Ticks);
                TimeSpan ts2 = new TimeSpan(dateStart.Ticks);
                TimeSpan ts = ts1.Subtract(ts2).Duration();
                int dateSpan = ts.Days;



                List<string> datelist = new List<string>();
                for (int i = 0; i < dateSpan + 1; i++)
                {
                    datelist.Add((dateStart.AddDays(i).Date).ToString("yyyy-MM-dd"));
                }

                Maticsoft.BLL.image_record_history histryservice = new Maticsoft.BLL.image_record_history();
                List<Maticsoft.Model.image_record_history> histrymodel = new List<Maticsoft.Model.image_record_history>();
                histrymodel = histryservice.GetModelList("deviceid='" + deviceid + "'and createtime>'" + dateStart + "' and createtime<'" + dateEnd.AddDays(1) + "'");

                List<List<double>> wendulistall = new List<List<double>>();
                for (int i = 0; i < stimelist.Length; i++)
                {
                    List<double> newlist = new List<double>();
                    for (int k = 0; k < datelist.Count(); k++)
                    {
                        string riqi = datelist[k];
                        string shijian = stimelist[i];
                        string svalue = "0.0";
                        for (int m = 0; m < histrymodel.Count(); m++)
                        {
                            string ssriqi = histrymodel[m].createtime.Value.Year.ToString() + "-" + histrymodel[m].createtime.Value.Month.ToString("00") + "-" + histrymodel[m].createtime.Value.Day.ToString("00");
                            string ssshijian = histrymodel[m].createtime.Value.Hour.ToString("00");

                            if (riqi == ssriqi && shijian == ssshijian)
                            {
                                svalue = histrymodel[m].valuemax;
                            }
                        }
                        newlist.Add(double.Parse(svalue));

                    }
                    double xxx0 = (newlist[0]);
                    for (int xx = 1; xx < newlist.Count(); xx++)
                    {
                        double xxx = (newlist[xx]);
                        if (xxx == 0.0)
                        {
                            xxx = (newlist[xx - 1]);
                            newlist.RemoveAt(xx);
                            newlist.Insert(xx, xxx);
                        }
                    }
                    wendulistall.Add(newlist);
                }
                for (int xk = 0; xk < wendulistall.Count(); xk++)
                {
                    if (IsIncreasingMontonically(wendulistall[xk]))
                    {
                        sevendayRasejson jsontest = new sevendayRasejson();
                        jsontest.Machineid = devicelist[mk].machineid;
                        jsontest.Machinename = devicelist[mk].machinename;
                        jsontest.Deviceid = devicelist[mk].deviceid;
                        jsontest.Decicename = devicelist[mk].devicename;
                        string s = "";
                        for (int kk = System.DateTime.Now.AddDays(-7).Day; kk < System.DateTime.Now.AddDays(-7).Day + 7; kk++)
                        {
                            s += kk.ToString("00") + ";" + wendulistall[xk][kk - System.DateTime.Now.AddDays(-7).Day] + ",";
                        }
                        s = s.Remove(s.Length - 1);
                        jsontest.Templist = s.Split(',').ToList();
                        jsontest.Shengwenqushi = "趋势：上升";
                        jsonlist.Add(jsontest);
                    }
                }
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);

        }
        public string getRaseDeviceCount(string userid, string hour)
        {
            List<sevendayRasejson> jsonlist = new List<sevendayRasejson>();

            Maticsoft.BLL.user_infor uservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = uservice.GetModel(userid);
            Maticsoft.BLL.device_infor devicemm = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            string isround = "1";
            if (usermodel.usertype == "0")
            {
                devicelist = devicemm.GetModelList("areaid='" + usermodel.areaid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "1")
            {
                devicelist = devicemm.GetModelList("fenbuid='" + usermodel.fenbuid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "2")
            {
                devicelist = devicemm.GetModelList("ywbid='" + usermodel.ywbid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "3")
            {
                devicelist = devicemm.GetModelList("  isroundpoint='" + isround + "'");
            }
            if (devicelist.Count < 1)
                return "0";
            for (int mk = 0; mk < devicelist.Count(); mk++)
            {
                string deviceid = devicelist[mk].deviceid;

                Maticsoft.BLL.device_infor dser = new Maticsoft.BLL.device_infor();
                Maticsoft.Model.device_infor dmodel = new Maticsoft.Model.device_infor();
                dmodel = dser.GetModel(deviceid);
                if (dmodel == null)
                    return "没有此设备";

                string devicename = dmodel.devicename;
                string machineid = dmodel.machineid;
                string machinename = dmodel.machinename;
                List<string> returnlist = new List<string>();

                string startDate = System.DateTime.Now.AddDays(-7).Date.ToString();
                string endDate = System.DateTime.Now.Date.ToString();
                string[] stimelist = null;

                List<string> testlist = new List<string>();
                for (int i = 0; i < 24; i++)
                {
                    testlist.Add(i.ToString("00"));
                    returnlist.Add(i.ToString("00") + ":00");
                }
                stimelist = testlist.ToArray();

                DateTime dateStart, dateEnd;
                DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                dateStart = Convert.ToDateTime(startDate, dtFormat);
                dateEnd = Convert.ToDateTime(endDate, dtFormat);

                TimeSpan ts1 = new TimeSpan(dateEnd.Ticks);
                TimeSpan ts2 = new TimeSpan(dateStart.Ticks);
                TimeSpan ts = ts1.Subtract(ts2).Duration();
                int dateSpan = ts.Days;



                List<string> datelist = new List<string>();
                for (int i = 0; i < dateSpan + 1; i++)
                {
                    datelist.Add((dateStart.AddDays(i).Date).ToString("yyyy-MM-dd"));
                }

                Maticsoft.BLL.image_record_history histryservice = new Maticsoft.BLL.image_record_history();
                List<Maticsoft.Model.image_record_history> histrymodel = new List<Maticsoft.Model.image_record_history>();
                histrymodel = histryservice.GetModelList("deviceid='" + deviceid + "'and createtime>'" + dateStart + "' and createtime<'" + dateEnd.AddDays(1) + "'");

                List<List<double>> wendulistall = new List<List<double>>();
                for (int i = 0; i < stimelist.Length; i++)
                {
                    List<double> newlist = new List<double>();
                    for (int k = 0; k < datelist.Count(); k++)
                    {
                        string riqi = datelist[k];
                        string shijian = stimelist[i];
                        string svalue = "0.0";
                        for (int m = 0; m < histrymodel.Count(); m++)
                        {
                            string ssriqi = histrymodel[m].createtime.Value.Year.ToString() + "-" + histrymodel[m].createtime.Value.Month.ToString("00") + "-" + histrymodel[m].createtime.Value.Day.ToString("00");
                            string ssshijian = histrymodel[m].createtime.Value.Hour.ToString("00");

                            if (riqi == ssriqi && shijian == ssshijian)
                            {
                                svalue = histrymodel[m].valuemax;
                            }
                        }
                        newlist.Add(double.Parse(svalue));

                    }
                    double xxx0 = (newlist[0]);
                    for (int xx = 1; xx < newlist.Count(); xx++)
                    {
                        double xxx = (newlist[xx]);
                        if (xxx == 0.0)
                        {
                            xxx = (newlist[xx - 1]);
                            newlist.RemoveAt(xx);
                            newlist.Insert(xx, xxx);
                        }
                    }
                    if ((newlist[0] - newlist[1] < 0) && ((newlist[newlist.Count - 3] - newlist[newlist.Count - 2]) < 0) && newlist[0] > 0)
                    {
                        wendulistall.Add(newlist);
                    }
                }
                for (int xk = 0; xk < wendulistall.Count(); xk++)
                {
                    if (IsIncreasingMontonically(wendulistall[xk]))
                    {
                        sevendayRasejson jsontest = new sevendayRasejson();
                        jsontest.Machineid = devicelist[mk].machineid;
                        jsontest.Machinename = devicelist[mk].machinename;
                        jsontest.Deviceid = devicelist[mk].deviceid;
                        jsontest.Decicename = devicelist[mk].devicename;
                        string s = "";
                        for (int kk = System.DateTime.Now.AddDays(-7).Day; kk < System.DateTime.Now.AddDays(-7).Day + 7; kk++)
                        {
                            s += kk.ToString("00") + ";" + wendulistall[xk][kk - System.DateTime.Now.AddDays(-7).Day] + ",";
                        }
                        s = s.Remove(s.Length - 1);
                        jsontest.Templist = s.Split(',').ToList();
                        jsontest.Shengwenqushi = "趋势：上升";
                        jsonlist.Add(jsontest);
                    }
                }
            }
            return jsonlist.Count().ToString();


        }
        public string getSevenDaysTempRase(string userid, string hour)
        {
            List<sevendayRasejson> jsonlist = new List<sevendayRasejson>();
            Maticsoft.BLL.user_infor uservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = uservice.GetModel(userid);
            Maticsoft.BLL.device_infor devicemm = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            string isround = "1";
            if (usermodel.usertype == "0")
            {
                devicelist = devicemm.GetModelList("areaid='" + usermodel.areaid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "1")
            {
                devicelist = devicemm.GetModelList("fenbuid='" + usermodel.fenbuid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "2")
            {
                devicelist = devicemm.GetModelList("ywbid='" + usermodel.ywbid + "' and isroundpoint='" + isround + "'");
            }
            if (usermodel.usertype == "3")
            {
                devicelist = devicemm.GetModelList("isroundpoint='" + isround + "'");
            }
            if (devicelist.Count < 1)
                return "0";
            for (int mk = 0; mk < devicelist.Count(); mk++)
            {
                string deviceid = devicelist[mk].deviceid;
                Maticsoft.BLL.device_infor dser = new Maticsoft.BLL.device_infor();
                Maticsoft.Model.device_infor dmodel = new Maticsoft.Model.device_infor();
                dmodel = dser.GetModel(deviceid);
                if (dmodel == null)
                    return "没有此设备";
                string devicename = dmodel.devicename;
                string machineid = dmodel.machineid;
                string machinename = dmodel.machinename;
                List<string> returnlist = new List<string>();

                string startDate = System.DateTime.Now.AddDays(-7).Date.ToString();
                string endDate = System.DateTime.Now.Date.ToString();
                string[] stimelist = null;

                List<string> testlist = new List<string>();
                for (int i = 0; i < 24; i++)
                {
                    testlist.Add(i.ToString("00"));
                    returnlist.Add(i.ToString("00") + ":00");
                }
                stimelist = testlist.ToArray();

                DateTime dateStart, dateEnd;
                DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                dateStart = Convert.ToDateTime(startDate, dtFormat);
                dateEnd = Convert.ToDateTime(endDate, dtFormat);

                TimeSpan ts1 = new TimeSpan(dateEnd.Ticks);
                TimeSpan ts2 = new TimeSpan(dateStart.Ticks);
                TimeSpan ts = ts1.Subtract(ts2).Duration();
                int dateSpan = ts.Days;



                List<string> datelist = new List<string>();
                for (int i = 0; i < dateSpan + 1; i++)
                {
                    datelist.Add((dateStart.AddDays(i).Date).ToString("yyyy-MM-dd"));
                }

                Maticsoft.BLL.image_record_history histryservice = new Maticsoft.BLL.image_record_history();
                List<Maticsoft.Model.image_record_history> histrymodel = new List<Maticsoft.Model.image_record_history>();
                histrymodel = histryservice.GetModelList("deviceid='" + deviceid + "'and createtime>'" + dateStart + "' and createtime<'" + dateEnd.AddDays(1) + "'");

                List<List<double>> wendulistall = new List<List<double>>();
                for (int i = 0; i < stimelist.Length; i++)
                {
                    List<double> newlist = new List<double>();
                    for (int k = 0; k < datelist.Count(); k++)
                    {
                        string riqi = datelist[k];
                        string shijian = stimelist[i];
                        string svalue = "0.0";
                        for (int m = 0; m < histrymodel.Count(); m++)
                        {
                            string ssriqi = histrymodel[m].createtime.Value.Year.ToString() + "-" + histrymodel[m].createtime.Value.Month.ToString("00") + "-" + histrymodel[m].createtime.Value.Day.ToString("00");
                            string ssshijian = histrymodel[m].createtime.Value.Hour.ToString("00");

                            if (riqi == ssriqi && shijian == ssshijian)
                            {
                                svalue = histrymodel[m].valuemax;
                            }
                        }
                        newlist.Add(double.Parse(svalue));

                    }
                    double xxx0 = (newlist[0]);
                    for (int xx = 1; xx < newlist.Count(); xx++)
                    {
                        double xxx = (newlist[xx]);
                        if (xxx == 0.0)
                        {
                            xxx = (newlist[xx - 1]);
                            newlist.RemoveAt(xx);
                            newlist.Insert(xx, xxx);
                        }
                    }
                    if ((newlist[0] - newlist[1] < 0) && ((newlist[newlist.Count - 3] - newlist[newlist.Count - 2]) < 0) && newlist[0] > 0)
                    {
                        wendulistall.Add(newlist);
                    }
                }
                for (int xk = 0; xk < wendulistall.Count(); xk++)
                {
                    if (IsIncreasingMontonically(wendulistall[xk]))
                    {
                        sevendayRasejson jsontest = new sevendayRasejson();
                        jsontest.Machineid = devicelist[mk].machineid;
                        jsontest.Machinename = devicelist[mk].stationname + " " + devicelist[mk].buildingname + " " + devicelist[mk].machinename + " 预设点" + devicelist[mk].ysdname + "时间点：" + hour + "时";
                        jsontest.Deviceid = devicelist[mk].deviceid;
                        jsontest.Decicename = devicelist[mk].devicename;
                        string s = "";
                        for (int kk = 0; kk < 7; kk++)
                        {
                            s += System.DateTime.Now.AddDays(-7 + kk).Day.ToString("") + ";" + wendulistall[xk][kk] + ",";
                        }
                        s = s.Remove(s.Length - 1);
                        jsontest.Templist = s.Split(',').ToList();
                        jsontest.Shengwenqushi = "趋势：上升";
                        jsonlist.Add(jsontest);
                    }
                }
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist);
        }
        public static bool IsIncreasingMontonically<T>(List<T> list) where T : IComparable
        {
            return list.Zip(list.Skip(1), (a, b) => a.CompareTo(b) <= 0)
                .All(b => b);
        }

        private List<string> getDeviceTopList(string deviceid, DateTime time)//设备24小时最高温统计
        {
            List<string> timelist = new List<string>();
            string hourlist = "";
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> imagelist = new List<Maticsoft.Model.image_record_history>();
            //从设备15分钟测温表中拿数据
            Maticsoft.BLL.device_heart_infor deviceheartservice = new Maticsoft.BLL.device_heart_infor();
            List<Maticsoft.Model.device_heart_infor> deviceheartlist = new List<Maticsoft.Model.device_heart_infor>();
            deviceheartlist = deviceheartservice.GetModelList("deviceid='" + deviceid + "' and createtime>'" + time.ToString("yyyy-MM-dd") + "' and createtime<'" + time.Date.AddDays(1).ToString("yyyy-MM-dd") + "' order by createtime desc");
            
            //从历史图库中获取数据
            string nowmonth = DateTime.Now.ToString("yyyyMM");
            string timemonth = time.ToString("yyyyMM");
            if (nowmonth == timemonth)
            {
                imagelist = historyservice.GetModelList("deviceid='" + deviceid + "' and createtime>'" + time.ToString("yyyy-MM-dd") + "' and createtime<'" + time.Date.AddDays(1).ToString("yyyy-MM-dd") + "' order by createtime desc");
            }
            else
            {
                imagelist = historyservice.HisGetModelList(timemonth, "deviceid='" + deviceid + "' and createtime>'" + time.ToString("yyyy-MM-dd") + "' and createtime<'" + time.Date.AddDays(1).ToString("yyyy-MM-dd") + "' ORDER BY  CAST(valuemax AS DECIMAL) DESC");
            }


            //将数据放到一个集合中
            List<deviceTemperatureJson> deviceTemperatureList = new List<deviceTemperatureJson>();
            if (deviceheartlist.Count > 0)
            {
                for (int d=0;d< deviceheartlist.Count;d++)
                {
                    deviceTemperatureJson json = new deviceTemperatureJson();
                    json.hour = deviceheartlist[d].createtime.Value.Hour;
                    json.temperature = double.Parse(deviceheartlist[d].ppmax);
                    deviceTemperatureList.Add(json);
                }
            }
            if (imagelist.Count > 0)
            {
                for (int d = 0; d < imagelist.Count; d++)
                {
                    deviceTemperatureJson json = new deviceTemperatureJson();
                    json.hour = imagelist[d].createtime.Value.Hour;
                    json.temperature = double.Parse(imagelist[d].valuemax);
                    deviceTemperatureList.Add(json);
                }
            }


            if (deviceTemperatureList.Count>0)
            {
                double hour0 = 0.0;
                double hour1 = 0.0;
                double hour2 = 0.0;
                double hour3 = 0.0;
                double hour4 = 0.0;
                double hour5 = 0.0;
                double hour6 = 0.0;
                double hour7 = 0.0;
                double hour8 = 0.0;
                double hour9 = 0.0;
                double hour10 = 0.0;
                double hour11 = 0.0;
                double hour12 = 0.0;
                double hour13 = 0.0;
                double hour14 = 0.0;
                double hour15 = 0.0;
                double hour16 = 0.0;
                double hour17 = 0.0;
                double hour18 = 0.0;
                double hour19 = 0.0;
                double hour20 = 0.0;
                double hour21 = 0.0;
                double hour22 = 0.0;
                double hour23 = 0.0;
                for (int h= 0;h < deviceTemperatureList.Count;h++)
                {
                    //int hour = deviceheartlist[h].createtime.Value.Hour;
                    int hour = deviceTemperatureList[h].hour;
                    if (hour == 0)
                    {                     
                        if (deviceTemperatureList[h].temperature > hour0)
                        {
                             hour0 = deviceTemperatureList[h].temperature;
                            continue;
                        }                      
                    }
                    else if (hour == 1)
                    {
                        if (deviceTemperatureList[h].temperature > hour1)
                        {
                            hour1 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 2)
                    {
                        if (deviceTemperatureList[h].temperature > hour2)
                        {
                            hour2 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 3)
                    {
                        if (deviceTemperatureList[h].temperature > hour3)
                        {
                            hour3 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 4)
                    {
                        if (deviceTemperatureList[h].temperature > hour4)
                        {
                            hour4 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 5)
                    {
                        if (deviceTemperatureList[h].temperature > hour5)
                        {
                            hour5 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 6)
                    {
                        if (deviceTemperatureList[h].temperature > hour6)
                        {
                            hour6 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 7)
                    {
                        if (deviceTemperatureList[h].temperature > hour7)
                        {
                            hour7 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 8)
                    {
                        if (deviceTemperatureList[h].temperature > hour8)
                        {
                            hour8 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 9)
                    {
                        if (deviceTemperatureList[h].temperature > hour9)
                        {
                            hour9 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 10)
                    {
                        if (deviceTemperatureList[h].temperature > hour10)
                        {
                            hour10 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 11)
                    {
                        if (deviceTemperatureList[h].temperature > hour11)
                        {
                            hour11 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 12)
                    {
                        if (deviceTemperatureList[h].temperature > hour12)
                        {
                            hour12 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 13)
                    {
                        if (deviceTemperatureList[h].temperature > hour13)
                        {
                            hour13 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 14)
                    {
                        if (deviceTemperatureList[h].temperature > hour14)
                        {
                            hour14 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 15)
                    {
                        if (deviceTemperatureList[h].temperature > hour15)
                        {
                            hour15 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 16)
                    {
                        if (deviceTemperatureList[h].temperature > hour16)
                        {
                            hour16 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 17)
                    {
                        if (deviceTemperatureList[h].temperature > hour17)
                        {
                            hour17 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 18)
                    {
                        if (deviceTemperatureList[h].temperature > hour18)
                        {
                            hour18 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 19)
                    {
                        if (deviceTemperatureList[h].temperature > hour19)
                        {
                            hour19 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 20)
                    {
                        if (deviceTemperatureList[h].temperature > hour20)
                        {
                            hour20 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 21)
                    {
                        if (deviceTemperatureList[h].temperature > hour21)
                        {
                            hour21 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 22)
                    {
                        if (deviceTemperatureList[h].temperature > hour22)
                        {
                            hour22 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                    else if (hour == 23)
                    {
                        if (deviceTemperatureList[h].temperature > hour23)
                        {
                            hour23 = deviceTemperatureList[h].temperature;
                            continue;
                        }
                    }
                }
                hourlist = "0;" + hour0 + ",1;" + hour1 + ",2;" + hour2 + ",3;" + hour3 + ",4;" + hour4 + ",5;" + hour5 + ",6;" + hour6 + ",7;" + hour7 + ",8;" + hour8 + ",9;" + hour9 + ",10;" + hour10 + ",11;" + hour11 + ",12;" + hour12 + ",13;" + hour13 + ",14;" + hour14 + ",15;" + hour15 + ",16;" + hour16 + ",17;" + hour17
                    + ",18;" + hour18 + ",19;" + hour19 + ",20;" + hour20 + ",21;" + hour21 + ",22;" + hour22 + ",23;" + hour23;
            }
            if (hourlist!="")
            {
                timelist = hourlist.Split(',').ToList();
            }
            return timelist;
        }
        #endregion
    }
}