﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.ReportServic
{
    
    public class allreportjson
    {
        string betweentime = "";//导出周报时，需要的参数
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Betweentime
        {
            get { return betweentime; }
            set { betweentime = value; }
        }

        string reportTime = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ReportTime
        {
            get { return reportTime; }
            set { reportTime = value; }
        }
        string reportDanwei = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ReportDanwei
        {
            get { return reportDanwei; }
            set { reportDanwei = value; }
        }
        string deviceTongji = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string DeviceTongji
        {
            get { return deviceTongji; }
            set { deviceTongji = value; }
        }
        string deviceTongji1 = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string DeviceTongji1
        {
            get { return deviceTongji1; }
            set { deviceTongji1 = value; }
        }
        string deviceTongji2 = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string DeviceTongji2
        {
            get { return deviceTongji2; }
            set { deviceTongji2 = value; }
        }
        string over_80_tongji = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Over_80_tongji
        {
            get { return over_80_tongji; }
            set { over_80_tongji = value; }
        }
        DataTable over_80_list = new DataTable();
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public DataTable Over_80_list
        {
            get { return over_80_list; }
            set { over_80_list = value; }
        }
        string over_90_tongji = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Over_90_tongji
        {
            get { return over_90_tongji; }
            set { over_90_tongji = value; }
        }
        DataTable over_90_list = new DataTable();
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public DataTable Over_90_list
        {
            get { return over_90_list; }
            set { over_90_list = value; }
        }
        string over_100_tongji = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Over_100_tongji
        {
            get { return over_100_tongji; }
            set { over_100_tongji = value; }
        }
        DataTable over_100_list = new DataTable();
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public DataTable Over_100_list
        {
            get { return over_100_list; }
            set { over_100_list = value; }
        }
        string over_120_tongji = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Over_120_tongji
        {
            get { return over_120_tongji; }
            set { over_120_tongji = value; }
        }
        DataTable over_120_list = new DataTable();
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public DataTable Over_120_list
        {
            get { return over_120_list; }
            set { over_120_list = value; }
        }

        string deviceTongji3 = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string DeviceTongji3
        {
            get { return deviceTongji3; }
            set { deviceTongji3 = value; }
        }
        DataTable station_top_value = new DataTable();
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public DataTable Station_top_value
        {
            get { return station_top_value; }
            set { station_top_value = value; }
        }

        List<allreportjson_device> device_json = new List<allreportjson_device>();
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<allreportjson_device> Device_json
        {
            get { return device_json; }
            set { device_json = value; }
        }
       
        string hightemputerTongji = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string HightemputerTongji
        {
            get { return hightemputerTongji; }
            set { hightemputerTongji = value; }
        }
        DataTable HightemputerDevlist = new DataTable();
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public DataTable HightemputerDevlist1
        {
            get { return HightemputerDevlist; }
            set { HightemputerDevlist = value; }
        }

        string alarmTongji = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string AlarmTongji
        {
            get { return alarmTongji; }
            set { alarmTongji = value; }
        }
        DataTable dtAlarm = new DataTable();
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public DataTable DtAlarm
        {
            get { return dtAlarm; }
            set { dtAlarm = value; }
        }
        string qushiTongji = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string QushiTongji
        {
            get { return qushiTongji; }
            set { qushiTongji = value; }
        }
        DataTable dtQushi = new DataTable();
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public DataTable DtQushi
        {
            get { return dtQushi; }
            set { dtQushi = value; }
        }

        string downloadurl = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Downloadurl
        {
            get { return downloadurl; }
            set { downloadurl = value; }
        }
        DataTable device_history_list = new DataTable();
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public DataTable Device_history_list
        {
            get { return device_history_list; }
            set { device_history_list = value; }
        }
        string _reporthuman = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string reporthuman
        {
            get { return _reporthuman; }
            set { _reporthuman = value; }
        }
        //string _catchsoure = "";
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        //public string catchsoure
        //{
        //    get { return _catchsoure; }
        //    set { _catchsoure = value; }
        //}

        string _catchsoure = "";
        public string catchsoure
        {
            get { return _catchsoure; }
            set { _catchsoure = value; }
        }
    }
}