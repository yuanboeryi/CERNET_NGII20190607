﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.ReportServic
{
    public class allreportjson_device
    {
        string stationname = "";

        public string Stationname
        {
            get { return stationname; }
            set { stationname = value; }
        }
        string buildingname = "";

        public string Buildingname
        {
            get { return buildingname; }
            set { buildingname = value; }
        }
        string machinecount = "";

        public string Machinecount
        {
            get { return machinecount; }
            set { machinecount = value; }
        }
        string devicetype = "";

        public string Devicetype
        {
            get { return devicetype; }
            set { devicetype = value; }
        }
        string devicelist = "";

        public string Devicelist
        {
            get { return devicelist; }
            set { devicelist = value; }
        }

       
    }
}