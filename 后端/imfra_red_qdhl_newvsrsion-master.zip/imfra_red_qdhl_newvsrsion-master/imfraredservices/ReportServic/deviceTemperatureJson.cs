﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.ReportServic
{

    public class deviceTemperatureJson//设备温度统计json
    {
        double _temperature = 0.0;//温度值

        public double temperature
        {
            get { return _temperature; }
            set { _temperature = value; }
        }
        int _hour = 0;
        public int hour
        {
            get { return _hour; }
            set { _hour = value; }
        }

        DateTime _datetime = new DateTime();
        public DateTime datetime
        {
            get { return _datetime; }
            set { _datetime = value; }
        }
    }
}