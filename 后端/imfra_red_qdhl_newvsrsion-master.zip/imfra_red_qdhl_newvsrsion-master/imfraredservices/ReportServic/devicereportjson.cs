﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.ReportServic
{
    public class devicereportjson
    {
        string fenbuname = "";

        public string Fenbuname
        {
            get { return fenbuname; }
            set { fenbuname = value; }
        }
        string fenbuid = "";

        public string Fenbuid
        {
            get { return fenbuid; }
            set { fenbuid = value; }
        }
        string ywbname = "";

        public string Ywbname
        {
            get { return ywbname; }
            set { ywbname = value; }
        }
        string ysdname = "";

        public string Ysdname
        {
            get { return ysdname; }
            set { ysdname = value; }
        }
        string ysdid = "";

        public string Ysdid
        {
            get { return ysdid; }
            set { ysdid = value; }
        }
        string ywbid = "";

        public string Ywbid
        {
            get { return ywbid; }
            set { ywbid = value; }
        }
        string stationid = "";

        public string Stationid
        {
            get { return stationid; }
            set { stationid = value; }
        }

        string stationnane = "";

        public string Stationnane
        {
            get { return stationnane; }
            set { stationnane = value; }
        }
        string devicetype = "";

        public string Devicetype
        {
            get { return devicetype; }
            set { devicetype = value; }
        }
        string deviceid = "";

        public string Deviceid
        {
            get { return deviceid; }
            set { deviceid = value; }
        }

        string devicename = "";

        public string Devicename
        {
            get { return devicename; }
            set { devicename = value; }
        }
        string devicelevle = "";

        public string Devicelevle
        {
            get { return devicelevle; }
            set { devicelevle = value; }
        }
        string fuhe = "";

        public string Fuhe
        {
            get { return fuhe; }
            set { fuhe = value; }
        }
        System.DateTime alarmtime = new System.DateTime();

        public DateTime Alarmtime
        {
            get { return alarmtime; }
            set { alarmtime = value; }
        }
        string alarmtemp = "";

        public string Alarmtemp
        {
            get { return alarmtemp; }
            set { alarmtemp = value; }
        }
        string machinename = "";

        public string Machinename
        {
            get { return machinename; }
            set { machinename = value; }
        }
        string machinecode = "";
        string machineid = "";

        public string Machineid
        {
            get { return machineid; }
            set { machineid = value; }
        }
        public string Machinecode
        {
            get { return machinecode; }
            set { machinecode = value; }
        }
        string buildingname = "";

        public string Buildingname
        {
            get { return buildingname; }
            set { buildingname = value; }
        }
        string buildingid = "";

        public string Buildingid
        {
            get { return buildingid; }
            set { buildingid = value; }
        }

        string image1 = "";

        public string Image1
        {
            get { return image1; }
            set { image1 = value; }
        }
        string image2 = "";

        public string Image2
        {
            get { return image2; }
            set { image2 = value; }
        }
        string image3 = "";

        public string Image3
        {
            get { return image3; }
            set { image3 = value; }
        }
        string date1 = "";

        public string Date11
        {
            get { return date1; }
            set { date1 = value; }
        }

        public string Date1
        {
            get { return date1; }
            set { date1 = value; }
        }
        List<string> templist_241 = new List<string>();

        public List<string> Templist_241
        {
            get { return templist_241; }
            set { templist_241 = value; }
        }
        string date2 = "";

        public string Date2
        {
            get { return date2; }
            set { date2 = value; }
        }
        List<string> templist_242 = new List<string>();

        public List<string> Templist_242
        {
            get { return templist_242; }
            set { templist_242 = value; }
        }
        string date3 = "";
        public string Date3
        {
            get { return date3; }
            set { date3= value; }
        }
        List<string> templist_243 = new List<string>();

        public List<string> Templist_243
        {
            get { return templist_243; }
            set { templist_243 = value; }
        }


        string date4 = "";
        public string Date4
        {
            get { return date4; }
            set { date4 = value; }
        }
        List<string> templist_244 = new List<string>();

        public List<string> Templist_244
        {
            get { return templist_244; }
            set { templist_244 = value; }
        }

        string date5 = "";
        public string Date5
        {
            get { return date5; }
            set { date5 = value; }
        }
        List<string> templist_245 = new List<string>();

        public List<string> Templist_245
        {
            get { return templist_245; }
            set { templist_245 = value; }
        }



        List<string> templist_30 = new List<string>();

        public List<string> Templist_30
        {
            get { return templist_30; }
            set { templist_30 = value; }
        }
        string testhuman = "张三";

        public string Testhuman
        {
            get { return testhuman; }
            set { testhuman = value; }
        }
        string shenhehuman = "李四";

        public string Shenhehuman
        {
            get { return shenhehuman; }
            set { shenhehuman = value; }
        }
        string pizhunhunam = "马六";

        public string Pizhunhunam
        {
            get { return pizhunhunam; }
            set { pizhunhunam = value; }
        }
        string dangqian = "";

        public string Dangqian
        {
            get { return dangqian; }
            set { dangqian = value; }
        }

        string today = "";

        public string Today
        {
            get { return today; }
            set { today = value; }
        }
        string yestoday = "";

        public string Yestoday
        {
            get { return yestoday; }
            set { yestoday = value; }
        }
        string week = "";

        public string Week
        {
            get { return week; }
            set { week = value; }
        }
        string month = "";

        public string Month
        {
            get { return month; }
            set { month = value; }
        }
        string history = "";

        public string History
        {
            get { return history; }
            set { history = value; }
        }
        string note1 = "";

        public string Note1
        {
            get { return note1; }
            set { note1 = value; }
        }
        string note2 = "";

        public string Note2
        {
            get { return note2; }
            set { note2 = value; }
        }
        string note3 = "";

        public string Note3
        {
            get { return note3; }
            set { note3 = value; }
        }
        string peo1 = "";

        public string Peo1
        {
            get { return peo1; }
            set { peo1 = value; }
        }
        string peo2 = "";

        public string Peo2
        {
            get { return peo2; }
            set { peo2 = value; }
        }
        string peo3 = "";

        public string Peo3
        {
            get { return peo3; }
            set { peo3 = value; }
        }

        string todaymaxid = "";

        public string Todaymaxid
        {
            get { return todaymaxid; }
            set { todaymaxid = value; }
        }
        string yestodaymaxid = "";

        public string Yestodaymaxid
        {
            get { return yestodaymaxid; }
            set { yestodaymaxid = value; }
        }
        string weekmaxid = "";

        public string Weekmaxid
        {
            get { return weekmaxid; }
            set { weekmaxid = value; }
        }
        string monthmaxid = "";

        public string Monthmaxid
        {
            get { return monthmaxid; }
            set { monthmaxid = value; }
        }
        string historymaxid = "";

        public string Historymaxid
        {
            get { return historymaxid; }
            set { historymaxid = value; }
        }
    }
}