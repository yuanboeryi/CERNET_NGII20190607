﻿using imfraredservices.TableService;
using imfraredservices.UserServices;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace imfraredservices.ReportServic
{
    /// <summary>
    /// reportServices 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class reportServices : System.Web.Services.WebService
    {
        
        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msg");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = Int32.MaxValue;
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        ReportAction action = new ReportAction();
        [WebMethod(Description = "接口描述，生成单个设备报告，传值alarmid【告警id】，返回报表所有信息")]
        public void getDevicereport(string alarmid)
        {
            httpsend(action.getDeviceReport(alarmid));
        }
        [WebMethod(Description = "接口描述，生成单个设备报告，传值deviceid【设备id】，返回报表所有信息")]
        public void getDevicereport_device(string deviceid)
        {
            string id = deviceid;

            // 切勿修改，测试目的！！！ by King-1025
            if(deviceid == "34eafb67ce5d4c4c99f0fb6d37ff4f59" || deviceid == "ac1b8bfcec5549eb94a9448651a8aa8f")
            {
                id = "008f010b33aa4ab7845abd894a0eb704";
            }

            httpsend(action.getDeviceReport_Device(id));
        }
        [WebMethod(Description = "接口描述，保存单个设备报告，传值deviceid【设备id】，note1,note2,note3[三个编辑框的信息]，返回报表所有信息")]
        public void saveDevicereport(string alarmid, string note1, string note2, string note3, string peo1, string peo2, string peo3, string url1, string url2)
        {
            httpsend(strJson(action.saveDevicereport(alarmid, note1, note2, note3, peo1, peo2, peo3, url1, url2)));
        }
        [WebMethod(Description = "接口描述：导出设备报表到word文件")]
        public void DownloadFile(string alarmid, string note1, string note2, string note3, string peo1, string peo2, string peo3, string url1, string url2)
        {
            httpsend(strJson(action.device_Word_Export(alarmid, note1, note2, note3, peo1, peo2, peo3, url1, url2)));
        }
        [WebMethod(Description = "接口描述，获取历史设备报表")]
        public void getHistoryDevicereport()
        {
            httpsend(ToJson(action.getHistorydevicereport()));
        }

        [WebMethod(Description = "接口描述：获取周报，传值userid=【全息默认10a29c9e1ecf4175bdc0ec36976b4068】 ，startDate，endDate，初次调用日期默认最近七天")]
        public void getAllReport(string userid, string startDate, string endDate)
        {
            httpsend(action.getAllreport_c(userid, startDate, endDate));
        }
      
        [WebMethod(Description = "接口描述，保存总报表")]

        public void saveAllreport(string peo1, string peo2)
        {
            httpsend(strJson(action.saveAllreport(peo1, peo2)));
        }
        [WebMethod(Description = "接口描述，获取历史总报表")]

        public void getHistoryAllreport()
        {
            //httpsend(ToJson(action.getHistoryAllreport()));
        }
        [WebMethod(Description = "接口描述，获取周报路径")]
        public void lq_geturl(string userid, string startDate, string endDate, string human)
        {
            httpsend(strJson(action.geturl(userid, startDate, endDate, "史久峰")));
        }

        [WebMethod(Description = "接口描述：获取当前用户下所有升温设备数量 以系统当前时间的小时为参数，例如当前2020年5月13日11:48:04  则hour=11")]
        public void getSevenRaseDevciceCount(string userid, string hour)
        {
            httpsend(strJson(action.getRaseDeviceCount(userid, hour)));
        }
        [WebMethod(Description = "接口描述：获取当前用户下所有升温设备统计,以系统当前时间的小时为参数，例如当前2020年5月13日11:48:04  则hour=11")]
        public void getSevenRaseDevcice(string userid, string hour)
        {
            httpsend(action.getSevenDaysTempRase(userid, hour));
        }

        [WebMethod(Description = "接口描述：获取七日升温设备")]
        public void LLLLLLL_getSevenRaseDevcice(string userid)
        {
            httpsend(action.getRase(userid));
        }

        [WebMethod(Description = "接口描述：获取温升20度记录,传值：userid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,page,limit")]
        public void getRaseOver20(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string deviceid, string page, string limit)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel==null)
            {
                return;
            }
            if (usermodel.usertype == "0")
            {
                {
                    areaid = usermodel.areaid;
                }
            }
            if (usermodel.usertype == "1")
            {
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                {
                    ywbid = usermodel.ywbid;
                }
            }
            if (usermodel.usertype == "3")
            {

            }
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1);
            {

                List<string> sqllist = new List<string>();
                if (areaid != "" && areaid != "全部" )
                    sqllist.Add("areaid='" + areaid + "'");
                if (fenbuid != "" && fenbuid != "全部")
                    sqllist.Add("fenbuid='" + fenbuid + "'");
                if (ywbid != "" && ywbid != "全部")
                    sqllist.Add("ywbid='" + ywbid + "'");
                if (stationid != "" && stationid != "全部")
                    sqllist.Add("stationid='" + stationid + "'");
                if (buildingid != "" && buildingid != "全部")
                    sqllist.Add("buildingid='" + buildingid + "'");
                if (deviceid != "" && deviceid != "全部")
                    sqllist.Add("deviceid='" + deviceid + "'");
                if (devicetype != "" && devicetype != "全部")
                    sqllist.Add("devicetype='" + devicetype + "'");

                string sql = "";
                int ncount = sqllist.Count();
                if (ncount < 1)
                {
                    sql = "1=1";
                }
                else if (ncount == 1)
                {
                    sql += sqllist[0];
                }
                else if (ncount > 1)
                {
                    for (int i = 0; i < ncount - 1; i++)
                    {
                        sql += sqllist[i] + " and ";
                    }
                    sql += sqllist[ncount - 1];
                }

                string sql1 = sql;
                //sql += " limit " + npage + "," + end + "";
                temprasejson json = new temprasejson();

                Maticsoft.BLL.temp_rase_infor deviceservice = new Maticsoft.BLL.temp_rase_infor();
                List<Maticsoft.Model.temp_rase_infor> modellist1 = new List<Maticsoft.Model.temp_rase_infor>();
                List<Maticsoft.Model.temp_rase_infor> modellist2 = new List<Maticsoft.Model.temp_rase_infor>();
                List<Maticsoft.Model.temp_rase_infor> modelliststation = new List<Maticsoft.Model.temp_rase_infor>();

                modellist1 = deviceservice.GetModelList(sql1 + " order by createtime desc");
                //if (modellist1.Count < 1)
                //    httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));
                modelliststation = deviceservice.GetModelList(sql1 + " group by stationname");

                DataSet ds2 = deviceservice.GetList(sql1 + " order by createtime desc  limit " + npage + "," + end + "");
                List<double> overlist = new List<double>();
                if (modellist1 != null && modellist1.Count>0)
                {
                    for (int i = 0; i < modellist1.Count; i++)
                    {
                        if (modellist1[i].overtemp!="")
                        {
                            overlist.Add(double.Parse(modellist1[i].overtemp));
                        }
                    }
                 }                
                if (overlist != null && overlist.Count > 0)
                {
                    int index = getMaxindex(overlist);
                    json.Maxdevice = modellist1[index].devicename.ToString();
                    json.Overvalue = modellist1[index].overtemp.ToString();
                    Maticsoft.BLL.device_infor devservice = new Maticsoft.BLL.device_infor();
                    if (modellist1[index] != null && modellist1[index].deviceid != "")
                    {
                        Maticsoft.Model.device_infor devicemodel = devservice.GetModel(modellist1[index].deviceid);
                        if (devicemodel != null)
                        {
                            json.Maxmachine = devicemodel.machinename;
                        }
                    }
                    json.Maxmachine = devservice.GetModel(modellist1[index].deviceid).machinename;               
                }
                json.Stationcount = modelliststation.Count.ToString();
                json.Alarmcount = modellist1.Count.ToString();
                json.Recordcount = modellist1.Count.ToString();               
                json.Recordlist = ds2.Tables[0];                
                httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));

            }

        }
        public int getMaxindex(List<double> list)
        {
            double a = list[0];
            int index = 0;//把假设的最大值索引赋值非index
            for (int i = 1; i < list.Count; i++)
            {
                if (list[i] > a)
                {
                    a = list[i];
                    index = i;//把较大值的索引赋值非index
                }
            }
            return index;
        }
        public DataTable getAlldevice(string userid)
        {
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.BLL.user_infor s1 = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor m1 = new Maticsoft.Model.user_infor();
            m1 = s1.GetModel(userid);
            if (m1 == null)
            {
                return null;
            }
            else
            {
                List<Maticsoft.Model.device_infor> devmodel = new List<Maticsoft.Model.device_infor>();
                if (m1.usertype == "0")
                {
                    devmodel = deviceservice.GetModelList("areaid='" + m1.areaid + "'");

                }

                if (m1.usertype == "1")
                {
                    devmodel = deviceservice.GetModelList("fenbuid='" + m1.fenbuid + "'");

                }
                if (m1.usertype == "2")
                {
                    devmodel = deviceservice.GetModelList("ywbid='" + m1.ywbid + "'");

                }
                if (m1.usertype == "3")
                {
                    devmodel = deviceservice.GetModelList("");

                }
                DataTable dt1 = new DataTable();
                dt1.Columns.Add("工区", Type.GetType("System.String"));
                dt1.Columns.Add("分部", Type.GetType("System.String"));
                dt1.Columns.Add("运维班", Type.GetType("System.String"));
                dt1.Columns.Add("变电站", Type.GetType("System.String"));
                dt1.Columns.Add("设备区", Type.GetType("System.String"));
                dt1.Columns.Add("红外设备", Type.GetType("System.String"));
                dt1.Columns.Add("电力设备", Type.GetType("System.String"));
                dt1.Columns.Add("告警温度", Type.GetType("System.String"));
                dt1.Columns.Add("距离（米）", Type.GetType("System.String"));
                dt1.Columns.Add("设定人", Type.GetType("System.String"));
                dt1.Columns.Add("设定时间", Type.GetType("System.String"));
                dt1.Columns.Add("守望点", Type.GetType("System.String"));
                dt1.Columns.Add("实时监测", Type.GetType("System.String"));
                dt1.Columns.Add("重点监测", Type.GetType("System.String"));
                dt1.Columns.Add("是否启用", Type.GetType("System.String"));

                int nco = devmodel.Count();
                for (int i = 0; i < nco; i++)
                {
                    string iskey = "0"; string isround = "0"; string isopen = "0";
                    if (devmodel[i].iskeypoint == "1")
                    {
                        iskey = "√";
                    }
                    else
                    {
                        iskey = "×";
                    }
                    if (devmodel[i].isroundpoint == "1")
                    {
                        isround = "√";
                    }
                    else
                    {
                        isround = "×";
                    }
                    if (devmodel[i].isopen == "1")
                    {
                        isopen = "√";
                    }
                    else
                    {
                        isopen = "×";
                    }
                    dt1.Rows.Add(new object[] { devmodel[i].areaname, devmodel[i].fenbuname, devmodel[i].ywbname, devmodel[i].stationname, devmodel[i].buildingname, devmodel[i].machinename, devmodel[i].devicename, devmodel[i].offsetvalue, devmodel[i].distance, devmodel[i].offsethuman, devmodel[i].createtime.Value.ToString(), "普通观测点", iskey, isround, isopen });

                }
                return dt1;
            }

        }
        [WebMethod(Description = "接口描述，导出设备信息到excel，传值userid")]
        public void ExportDeviceToExcel(string userid)
        {
            string filepath = "D:\\infrared_new_service\\apk_Floder\\";
            string filename = "设备信息表" + System.DateTime.Now.ToString("yyyyMMddhhMMss") + ".xls";
            DataTableToExcel(getAlldevice(userid), filepath + filename);
            httpsend(strJson("http://116.255.207.148:21889/" + filename));
        }
        [WebMethod(Description = "接口描述：导出数据分析到excel，传值userid")]
        public void ExportAnalsyToExcel(string deviceid)
        {
            Maticsoft.BLL.device_infor devs = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
            model = devs.GetModel(deviceid);
            if (model == null)
                return;
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> devmodel = new List<Maticsoft.Model.image_record_history>();
            devmodel = historyservice.GetModelList("deviceid='" + deviceid + "' order by createtime desc");
            if (devmodel == null)
                return;
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("工区", Type.GetType("System.String"));
            dt1.Columns.Add("分部", Type.GetType("System.String"));
            dt1.Columns.Add("运维班", Type.GetType("System.String"));
            dt1.Columns.Add("变电站", Type.GetType("System.String"));
            dt1.Columns.Add("设备区", Type.GetType("System.String"));
            dt1.Columns.Add("红外设备", Type.GetType("System.String"));
            dt1.Columns.Add("电力设备", Type.GetType("System.String"));
            dt1.Columns.Add("最高温", Type.GetType("System.String"));
            dt1.Columns.Add("平均温", Type.GetType("System.String"));
            dt1.Columns.Add("最低温", Type.GetType("System.String"));
            dt1.Columns.Add("监测时间", Type.GetType("System.String"));
            int nco = devmodel.Count();
            for (int i = 0; i < nco; i++)
            {

                dt1.Rows.Add(new object[] { devmodel[i].areaname, devmodel[i].fenbuname, devmodel[i].ywbname, model.stationname, model.buildingname, model.machinename, model.devicename, devmodel[i].valuemax, devmodel[i].valueave, devmodel[i].valuemin, devmodel[i].createtime.ToString() });

            }
            string filepath = "D:\\infrared_new_service\\apk_Floder\\";
            string filename = "设备温度记录表" + System.DateTime.Now.ToString("yyyyMMddhhMMss") + ".xls";
            DataTableToExcel(dt1, filepath + filename);
            httpsend(strJson("http://116.255.207.148:21889/" + filename));
        }
        public void DataTableToExcel(DataTable table, string file)
        {
            string title = "";
            try
            {
                FileStream fs = new FileStream(file, FileMode.OpenOrCreate);
                StreamWriter sw = new StreamWriter(new BufferedStream(fs), System.Text.Encoding.Default);
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    title += table.Columns[i].ColumnName + "\t"; //栏位：自动跳到下一单元格
                }
                title = title.Substring(0, title.Length - 1) + "\n";
                sw.Write(title);
                foreach (DataRow row in table.Rows)
                {
                    string line = "";
                    for (int i = 0; i < table.Columns.Count; i++)
                    {
                        line += row[i].ToString().Trim() + "\t"; //内容：自动跳到下一单元格
                    }
                    line = line.Substring(0, line.Length - 1) + "\n";
                    sw.Write(line);
                }
                sw.Close();
                fs.Close();
            }
            catch (UnauthorizedAccessException ex)
            {
                //MessageBox.Show("请先开通系统对放置路径的访问权限。");
            }
        }

        //[WebMethod(Description = "测试导出Word")]
        //public void TryEditWord()
        //{
        //    httpsend(action.TryEditWord());
        //}

        #region  周报
        [WebMethod(Description = "接口描述，获取周报")]
        public void getAllreport_f(string userid, string startDate, string endDate)
        {
            DateTime timeStart, timeEnd;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            timeStart = Convert.ToDateTime(startDate, dtFormat).AddDays(0).Date;
            timeEnd = Convert.ToDateTime(endDate, dtFormat).AddDays(1);

            allreportjson json = new allreportjson();
            json.ReportTime = System.DateTime.Now.ToString();
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
            usermodel = userservice.GetModel(userid);

            string usertype = usermodel.usertype;
            #region 跟踪设备统计
            if (usertype == "0")
            {
                json.ReportDanwei = usermodel.areaname;
                DataSet station_ds = stationservice.GetList("areaid='" + usermodel.areaid + "'");
                DataSet device_ds = deviceservice.GetList("areaid='" + usermodel.areaid + "'");
                DataSet machine_ds = macservice.GetList("areaid='" + usermodel.areaid + "'");
                json.DeviceTongji = "当前测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共：" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对：" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + device_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪";
            }
            if (usertype == "1")
            {
                json.ReportDanwei = usermodel.fenbuname;

                DataSet station_ds = stationservice.GetList("fenbuid='" + usermodel.fenbuid + "'");
                DataSet device_ds = deviceservice.GetList("fenbuid='" + usermodel.fenbuid + "'");
                DataSet machine_ds = macservice.GetList("fenbuid='" + usermodel.fenbuid + "'");
                json.DeviceTongji = "当前测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共：" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对：" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + device_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪";
            }
            if (usertype == "2")
            {
                json.ReportDanwei = usermodel.ywbname;

                DataSet station_ds = stationservice.GetList("ywbid='" + usermodel.ywbid + "'");
                DataSet device_ds = deviceservice.GetList("ywbid='" + usermodel.ywbid + "'");
                DataSet machine_ds = macservice.GetList("ywbid='" + usermodel.ywbid + "'");
                json.DeviceTongji = "当前测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共：" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对：" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + device_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪";
            }
            if (usertype == "3")
            {
                json.ReportDanwei = "admin";

                DataSet station_ds = stationservice.GetList("");
                DataSet device_ds = deviceservice.GetList("");
                DataSet machine_ds = macservice.GetList("");
                json.DeviceTongji = "当前测温跟踪：" + station_ds.Tables[0].Rows.Count.ToString() + "个站，共：" + machine_ds.Tables[0].Rows.Count.ToString() + "台测温跟踪设备，对：" + device_ds.Tables[0].Rows.Count.ToString() + "个变电设备的" + device_ds.Tables[0].Rows.Count.ToString() + "个点进行测温跟踪";
            }
            #endregion

            #region 高温设备统计
            List<string> devicelist = new List<string>();
            DataSet Topdev = new DataSet();
            if (usertype == "0")
            {
                Topdev = deviceservice.GetList("areaid='" + usermodel.areaid + "'");
            }
            if (usertype == "1")
            {
                Topdev = deviceservice.GetList("fenbuid='" + usermodel.fenbuid + "'");
            }
            if (usertype == "2")
            {
                Topdev = deviceservice.GetList("ywbid='" + usermodel.ywbid + "'");
            }
            if (usertype == "3")
            {
                Topdev = deviceservice.GetList("");
            }
            for (int i = 0; i < Topdev.Tables[0].Rows.Count; i++)//得到当前用户下的设备列表
            {
                devicelist.Add(Topdev.Tables[0].Rows[i]["deviceid"].ToString());
            }
            List<Maticsoft.Model.alarm_push_infor> hismodellist = new List<Maticsoft.Model.alarm_push_infor>();
            if (usertype == "0")
            {
                hismodellist = alarmservice.GetModelList("areaid='" + usermodel.areaid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' order by stationname desc");
            }
            if (usertype == "1")
            {
                hismodellist = alarmservice.GetModelList("fenbuid='" + usermodel.fenbuid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' order by stationname desc");
            }
            if (usertype == "2")
            {
                hismodellist = alarmservice.GetModelList("ywbid='" + usermodel.ywbid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' order by stationname desc");
            }
            if (usertype == "3")
            {
                hismodellist = alarmservice.GetModelList("createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' order by stationname desc");
            }
            List<string> count_80_list = new List<string>(); List<string> count_80_station = new List<string>();
            List<string> count_90_list = new List<string>(); List<string> count_90_station = new List<string>();
            List<string> count_100_list = new List<string>(); List<string> count_100_station = new List<string>();
            List<string> count_120_list = new List<string>(); List<string> count_120_station = new List<string>();

            for (int i = 0; i < hismodellist.Count(); i++)
            {
                if (hismodellist[i].alarmvalue != "" && hismodellist[i].alarmvalue != null)
                {
                    if (double.Parse(hismodellist[i].alarmvalue) >= 80)
                    {
                        if (!count_80_list.Contains(hismodellist[i].deviceid))
                        {
                            count_80_list.Add(hismodellist[i].id);
                            if (!count_80_station.Contains(hismodellist[i].stationname))
                                count_80_station.Add(hismodellist[i].stationname);
                        }
                    }
                    if (double.Parse(hismodellist[i].alarmvalue) >= 90)
                    {
                        if (!count_90_list.Contains(hismodellist[i].deviceid))
                        {
                            count_90_list.Add(hismodellist[i].id);
                            if (!count_90_station.Contains(hismodellist[i].stationname))
                                count_90_station.Add(hismodellist[i].stationname);
                        }
                    }
                    if (double.Parse(hismodellist[i].alarmvalue) >= 100)
                    {
                        if (!count_100_list.Contains(hismodellist[i].deviceid))
                        {
                            count_100_list.Add(hismodellist[i].id);
                            if (!count_100_station.Contains(hismodellist[i].stationname))
                                count_100_station.Add(hismodellist[i].stationname);
                        }
                    }
                    if (double.Parse(hismodellist[i].alarmvalue) >= 120 && double.Parse(hismodellist[i].alarmvalue)<140)
                    {
                        if (!count_120_list.Contains(hismodellist[i].deviceid))
                        {
                            count_120_list.Add(hismodellist[i].id);
                            if (!count_120_station.Contains(hismodellist[i].stationname))
                                count_120_station.Add(hismodellist[i].stationname);
                        }
                    }
                }
            }
            string count1 = count_80_list.Count().ToString();
            string count2 = count_90_list.Count().ToString();
            string count3 = count_100_list.Count().ToString();
            string count4 = count_120_list.Count().ToString();
            DataTable dtx = new DataTable("machinecount");
            dtx.Columns.Add("alarmtime", Type.GetType("System.String"));
            dtx.Columns.Add("stationname", Type.GetType("System.String"));
            dtx.Columns.Add("devicename", Type.GetType("System.String"));
            dtx.Columns.Add("alarmvalue", Type.GetType("System.String"));
            dtx.Columns.Add("offsetvalue", Type.GetType("System.String"));
            dtx.Columns.Add("isalarm", Type.GetType("System.String"));
            for (int i = 0; i < count_120_list.Count; i++)
            {

                Maticsoft.Model.alarm_push_infor lm = new Maticsoft.Model.alarm_push_infor();
                lm = alarmservice.GetModel(count_120_list[i]);

                string offset = deviceservice.GetModel(lm.deviceid).offsetvalue;
                string isalarm = "";
                if (offset != "")
                {
                    if (double.Parse(offset) >= 120)
                        isalarm = "是";
                }

                dtx.Rows.Add(new object[] { lm.createtime.ToString(), lm.stationname, lm.devicename, lm.alarmvalue, offset, isalarm });
            }
            for (int i = 0; i < count_80_list.Count; i++)
            {

                Maticsoft.Model.alarm_push_infor lm = new Maticsoft.Model.alarm_push_infor();
                lm = alarmservice.GetModel(count_80_list[i]);
                string offset = deviceservice.GetModel(lm.deviceid).offsetvalue;
                string isalarm = "";
                if (offset != "")
                {
                    if (double.Parse(offset) >= 80)
                        isalarm = "是";
                }

                dtx.Rows.Add(new object[] { lm.createtime.ToString(), lm.stationname, lm.devicename, lm.alarmvalue, offset, isalarm });
            }
            for (int i = 0; i < count_90_list.Count; i++)
            {

                Maticsoft.Model.alarm_push_infor lm = new Maticsoft.Model.alarm_push_infor();
                lm = alarmservice.GetModel(count_90_list[i]);
                string offset = deviceservice.GetModel(lm.deviceid).offsetvalue;
                string isalarm = "";
                if (offset != "")
                {
                    if (double.Parse(offset) >= 90)
                        isalarm = "是";
                }

                dtx.Rows.Add(new object[] { lm.createtime.ToString(), lm.stationname, lm.devicename, lm.alarmvalue, offset, isalarm });
            }
            for (int i = 0; i < count_100_list.Count; i++)
            {

                Maticsoft.Model.alarm_push_infor lm = new Maticsoft.Model.alarm_push_infor();
                lm = alarmservice.GetModel(count_100_list[i]);
                string offset = deviceservice.GetModel(lm.deviceid).offsetvalue;
                string isalarm = "";
                if (offset != "")
                {
                    if (double.Parse(offset) >= 100)
                        isalarm = "是";
                }

                dtx.Rows.Add(new object[] { lm.createtime.ToString(), lm.stationname, lm.devicename, lm.alarmvalue, offset, isalarm });
            }
            string station_80_str = "";
            for (int i = 0; i < count_80_station.Count; i++)
            {
                station_80_str += count_80_station[i] + ";";
            }
            string station_90_str = "";
            for (int i = 0; i < count_90_station.Count; i++)
            {
                station_90_str += count_90_station[i] + ";";
            }
            string station_100_str = "";
            for (int i = 0; i < count_100_station.Count; i++)
            {
                station_100_str += count_100_station[i] + ";";
            }
            string station_120_str = "";
            for (int i = 0; i < count_120_station.Count; i++)
            {
                station_120_str += count_120_station[i] + ";";
            }
            json.HightemputerTongji = "超80℃监测点：" + count1 + "处:来自于：" + station_80_str + "等站；超90℃：" + count2 + "处,来自于：" + station_90_str + "等站，超100℃：" + count3+ "处,来自于：" + station_100_str + "等站，超120℃：" + count4 + "处，来自于：" + station_120_str + "等站";
            json.HightemputerDevlist1 = dtx;
            #endregion
            #region 测温异常告警统计
            List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
            if (usertype == "0")
            {
                alarmlist = alarmservice.GetModelList("areaid='" + usermodel.areaid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' group by devicename order by createtime desc");

            }
            if (usertype == "1")
            {
                alarmlist = alarmservice.GetModelList("fenbuid='" + usermodel.fenbuid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' group by devicename order by createtime desc");

            }
            if (usertype == "2")
            {
                alarmlist = alarmservice.GetModelList("ywbid='" + usermodel.ywbid + "' and createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' group by devicename order by createtime desc");

            }
            if (usertype == "3")
            {
                alarmlist = alarmservice.GetModelList(" createtime>'" + timeStart + "' and createtime<'" + timeEnd + "' group by devicename order by createtime desc");

            }
            string sheader = "告警共" + alarmlist.Count().ToString() + "条：";

            json.AlarmTongji = sheader;
            #endregion
            DataTable alarmtable = new DataTable();
            alarmtable.Columns.Add("headerText", Type.GetType("System.String"));
            alarmtable.Columns.Add("image1", Type.GetType("System.String"));
            alarmtable.Columns.Add("image2", Type.GetType("System.String"));
            alarmtable.Columns.Add("bottonText", Type.GetType("System.String"));
            for (int i = 0; i < alarmlist.Count(); i++)
            {
                string dengjifuhe = "无";
                string querenrenyuan = "无";
                if (alarmlist[i].fuhe != "" && alarmlist[i].fuhe != null)
                {
                    dengjifuhe = alarmlist[i].fuhe;
                }
                if (alarmlist[i].mensurehuman != "" && alarmlist[i].mensurehuman != null)
                {
                    querenrenyuan = alarmlist[i].mensurehuman;
                }
                string s1 = "";
                string imagename = alarmlist[i].image_url;
                string image1 = "";
                string image2 = "";
                if (imagename.Contains("~0~"))
                {
                    image1 = imagename;
                    image2 = imagename.Replace("~0~", "~1~");
                }
                if (imagename.Contains("~1~"))
                {
                    image2 = imagename;
                    image1 = imagename.Replace("~1~", "~0~");
                }
                if (imagename.Contains("~2~"))
                {
                    image1 = imagename.Replace("~2~", "~0~");
                    image2 = imagename.Replace("~2~", "~1~");
                }
                string s2 = alarmlist[i].stationname + "  监测点：" + alarmlist[i].devicename + "告警值：" + alarmlist[i].alarmvalue + "告警时间：" + alarmlist[i].createtime.ToString();
                if (image1 != "" || image2 != "")
                {
                    alarmtable.Rows.Add(new object[] { s1, image1, image2, s2 });

                }
            }
            json.DtAlarm = alarmtable;

            #region 趋势统计

            DataTable shengwentable = new DataTable();
            shengwentable = null;
            json.QushiTongji = "过去一周持续升温的设备数量：0处";// +shengwentable.Rows.Count.ToString() + "处";
            json.DtQushi = shengwentable;
            json.Downloadurl = "";

            string JsonToStr = JsonConvert.SerializeObject(json);
            //string JsonToStr = json.ToString();

            CreateWordHelper createWord = new CreateWordHelper(JsonToStr);
            string SaveFilePath=createWord.TryCreateword();









            #endregion
            httpsend(strJson(SaveFilePath)+ JsonToStr);
        }
        #endregion

    }
}
