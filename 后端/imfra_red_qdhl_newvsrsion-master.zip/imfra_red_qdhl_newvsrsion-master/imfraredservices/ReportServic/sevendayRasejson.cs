﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.ReportServic
{
    public class sevendayRasejson
    {
        string stationname = "";

        public string Stationname
        {
            get { return stationname; }
            set { stationname = value; }
        }
        string buildingname = "";

        public string Buildingname
        {
            get { return buildingname; }
            set { buildingname = value; }
        }
        string machineid = "";

        public string Machineid
        {
            get { return machineid; }
            set { machineid = value; }
        }
        string machinename = "";

        public string Machinename
        {
            get { return machinename; }
            set { machinename = value; }
        }
        string deviceid = "";

        public string Deviceid
        {
            get { return deviceid; }
            set { deviceid = value; }
        }
        string decicename = "";

        public string Decicename
        {
            get { return decicename; }
            set { decicename = value; }
        }
        List<string> templist = new List<string>();

        public List<string> Templist
        {
            get { return templist; }
            set { templist = value; }
        }

        string reportwencha = "";

        public string Reportwencha
        {
            get { return reportwencha; }
            set { reportwencha = value; }
        }

        string shengwenqushi = "";

        public string Shengwenqushi
        {
            get { return shengwenqushi; }
            set { shengwenqushi = value; }
        }
    }
}