﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.ReportServic
{
    public class update_device_state
    {
        Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
        Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
        public void UpdateDevice(string deviceid)//更新设备基础信息，如：各个时间段的最高温，以及最高温对应的温度记录
        {
            string yestoday = "";
            string week = "";
            string month = "";
            string history = "";
            string todaymax = "";
            string monthmax = "";
            string todaymaxid = "";
            string yestodaymaxid = "";
            string weekmaxid = "";
            string monthmaxid = "";
            string historymaxid = "";
            List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();
            historylist = historyservice.GetModelList("deviceid='" + deviceid + "' and createtime > '" + System.DateTime.Now.AddDays(-20).ToString()+"'");
            if (historylist.Count > 0)
            {
                List<string> historyidlist = new List<string>();
                historyidlist.Add("");
                List<double> templisthistory = new List<double>();
                templisthistory.Add(0); 

                List<double> temlistmonth = new List<double>();
                temlistmonth.Add(0);
                List<string> monthidlist = new List<string>();
                monthidlist.Add("");
                List<string> weekidlist = new List<string>();
                weekidlist.Add("");
                List<double> templistweek = new List<double>();
                templistweek.Add(0);

                List<double> templistyestoday = new List<double>();
                templistyestoday.Add(0);
                List<string> yestodayidlist = new List<string>();
                yestodayidlist.Add("");

                List<double> templisttoday = new List<double>();
                templisttoday.Add(0);
                List<string> todayidlist = new List<string>();
                todayidlist.Add("");
                for (int i = 0; i < historylist.Count; i++)
                {
                    if (historylist[i].createtime.Value.Ticks > System.DateTime.Now.AddDays(-20).Ticks)
                    {
                        if (historylist[i].valuemax != "" && historylist[i].valuemax != null)
                        {
                            templisthistory.Add(double.Parse(historylist[i].valuemax));
                            historyidlist.Add(historylist[i].recordid);
                        }
                    }
                    if (historylist[i].createtime.Value.Ticks > System.DateTime.Now.AddDays(-15).Ticks)
                    {
                        if (historylist[i].valuemax != "" && historylist[i].valuemax != null)
                        {
                            temlistmonth.Add(double.Parse(historylist[i].valuemax));
                            monthidlist.Add(historylist[i].recordid);
                        }
                    }
                    if (historylist[i].createtime.Value.Ticks > System.DateTime.Now.AddDays(-7).Ticks)
                    {
                        if (historylist[i].valuemax != "" && historylist[i].valuemax != null)
                        {
                            templistweek.Add(double.Parse(historylist[i].valuemax));
                            weekidlist.Add(historylist[i].recordid);
                        }
                    }
                    if (historylist[i].createtime.Value.Ticks > System.DateTime.Now.AddDays(-1).Date.Ticks && historylist[i].createtime.Value.Ticks < System.DateTime.Now.Date.Ticks)
                    {
                        if (historylist[i].valuemax != "" && historylist[i].valuemax != null)
                        {
                            templistyestoday.Add(double.Parse(historylist[i].valuemax));
                            yestodayidlist.Add(historylist[i].recordid);
                        }
                    }
                    if (historylist[i].createtime.Value.Ticks > System.DateTime.Now.Date.Ticks)
                    {
                        if (historylist[i].valuemax != "" && historylist[i].valuemax != null)
                        {
                            templisttoday.Add(double.Parse(historylist[i].valuemax));
                            todayidlist.Add(historylist[i].recordid);
                        }
                    }
                }
                if(templisthistory.Count>0)
                {
                    history = templisthistory.Max().ToString("0.0");
                    historymaxid = historyidlist[getMaxindex(templisthistory)];
                }
                if (temlistmonth.Count()>0)
                {
                    month = temlistmonth.Max().ToString();
                    monthmax = temlistmonth.Max().ToString();
                monthmaxid = monthidlist[getMaxindex(temlistmonth)];

                }
                if (templistweek.Count>0)
                {
                    week = templistweek.Max().ToString();
                    weekmaxid = weekidlist[getMaxindex(templistweek)];
                }
                if(templistyestoday.Count>0)
                {
                    yestoday = templistyestoday.Max().ToString();
                    yestodaymaxid = yestodayidlist[getMaxindex(templistyestoday)];
                }
              if(templisthistory.Count()>0)
              {
                  todaymax = templisttoday.Max().ToString();
                  todaymaxid = todayidlist[getMaxindex(templisttoday)];
              }
               
               

            }
          
            historylist = null;
            deviceservice.UpdateHistory(deviceid, yestoday, week, month, history, todaymax, monthmax, todaymaxid,yestodaymaxid,weekmaxid, monthmaxid,historymaxid);
        }


        public int getMaxindex(List<double> list)
        {
            double a = list[0];
            int index = 0;//把假设的最大值索引赋值非index
            for (int i = 1; i < list.Count; i++)
            {
                if (list[i] > a)
                {
                    a = list[i];
                    index = i;//把较大值的索引赋值非index
                }
            }
            return index;
        }
    }
}