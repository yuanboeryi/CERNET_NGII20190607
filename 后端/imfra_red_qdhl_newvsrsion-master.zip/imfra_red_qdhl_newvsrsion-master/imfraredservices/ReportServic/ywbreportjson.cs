﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.ReportServic
{
    public class ywbreportjson
    {
        DateTime reporttime = new DateTime();

        public DateTime Reporttime
        {
            get { return reporttime; }
            set { reporttime = value; }
        }
        string reportdanwei = "";

        public string Reportdanwei
        {
            get { return reportdanwei; }
            set { reportdanwei = value; }
        }
        string devicereport = "";

        public string Devicereport
        {
            get { return devicereport; }
            set { devicereport = value; }
        }
        string hightempreport = "";

        public string Hightempreport
        {
            get { return hightempreport; }
            set { hightempreport = value; }
        }
        string alarmreport = "";

        public string Alarmreport
        {
            get { return alarmreport; }
            set { alarmreport = value; }
        }
        List<string> image_red_list = new List<string>();

        public List<string> Image_red_list
        {
            get { return image_red_list; }
            set { image_red_list = value; }
        }
        List<string> image_high_list = new List<string>();

        public List<string> Image_high_list
        {
            get { return image_high_list; }
            set { image_high_list = value; }
        }
        string qushireport = "";

        public string Qushireport
        {
            get { return qushireport; }
            set { qushireport = value; }
        }
        List<string> templist_24 = new List<string>();

        public List<string> Templist_24
        {
            get { return templist_24; }
            set { templist_24 = value; }
        }
        List<string> templist_7 = new List<string>();

        public List<string> Templist_7
        {
            get { return templist_7; }
            set { templist_7 = value; }
        }
        string ywbname = "";

        public string Ywbname
        {
            get { return ywbname; }
            set { ywbname = value; }
        }
        string manager = "";

        public string Manager
        {
            get { return manager; }
            set { manager = value; }
        }
    }
}