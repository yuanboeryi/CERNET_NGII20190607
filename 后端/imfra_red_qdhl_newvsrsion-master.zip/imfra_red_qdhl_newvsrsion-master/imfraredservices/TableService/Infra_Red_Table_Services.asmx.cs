﻿using imfraredservices.ReportServic;
using imfraredservices.UserServices;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace imfraredservices.TableService
{
    /// <summary>
    /// Infra_Red_Table_Services 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class Infra_Red_Table_Services : System.Web.Services.WebService
    {
        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        //变电设备，监控设备
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = Int32.MaxValue;
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msg");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        TableAction action = new TableAction();
        [WebMethod(Description = "接口描述：获取当前登录用户下抓拍设备总数，在线数量，不在线数量")]

        public void getmachineNumbers(string userid)
        {
            httpsend(ToJson(action.getmachineNumbers(userid)));
        }
        [WebMethod(Description = "接口描述：获取某个变电站下重点监测设备列表，一个变电站只有一个重点监测设备，传值：stationname变电站名称，返回重点设备信息 page表示页码，从1开始，numbers表示每页多少条")]
        public void getkeyPointdeviceBystation(string stationname, string page, string numbers)//重点监测设备
        {
            httpsend(ToJson(action.getkeyPointdeviceBystation(stationname, page, numbers)));
        }
        [WebMethod(Description = "接口描述：获取用户下所有变电站重点监测设备列表，传值:登录用户的权限名称，比如：工区用户，传值areaname=某某工区，fenbuname=0,ywbname=0  page表示页码，从1开始，numbers表示每页多少条")]
        public void getAllkeyPointdevice(string userid, string page, string numbers)//重点监测设备
        {
            httpsend((action.getkeypointdeviceByuser(userid, page, numbers)));
        }
        [WebMethod(Description = "接口描述：获取当前用户下所有实时监测设备列表，传值:userid")]
        public void getAllRounddevice(string userid, string stationid)//实时监测设备
        {
            httpsend(action.getAllRounddevice(userid, stationid));
        }
        [WebMethod(Description = "接口描述：获取当前用户下所有实时监测设备列表，")]
        public void getAllRound()
        {
            httpsend(action.getAllRound());
        }
        [WebMethod(Description = "接口描述：获取某个变电站下所有实时监测设备列表，传值stationname，返回试试检测设备信息列表")]
        public void getRounddeviceBystation(string stationname)//实时监测设备
        {
            httpsend(action.getRounddeviceBystation(stationname));
        }
        [WebMethod(Description = "接口描述：获取当前登录用户下，最高温度及对应的设备信息")]
        public void getTopdevice(string userid)//获取当前登录用户下设备最高温
        {
            httpsend(ToJson(action.getTopdevice(userid)));
        }
        [WebMethod(Description = "接口描述：获取当前登录用户下，三个最高温度及对应的设备信息")]
        public void getTopdevice_Three(string userid)//获取当前登录用户下设备最高温
        {
            httpsend(ToJson(action.getTopdevice_Three(userid)));
        }
        [WebMethod(Description = "接口描述：获取各个时段最高温对应的图片记录")]
        public void getHistoryImageByrecordid(string recordid)
        {
            httpsend(ToJson(action.getHistoryImageByrecordid(recordid)));
        }
        [WebMethod(Description = "接口描述：获取当前登录用户下，告警推送信息")]
        public void getAlarmPush(string userid, string newesttime)//告警推送信息
        {
            httpsend((action.getAlarmPush(userid, newesttime)));
        }

        [WebMethod(Description = "接口描述：获取当前用户下测温告警统计信息，传值:登录用户的权限名称，比如：工区用户，传值areaname=某某工区，fenbuname=0,ywbname=0")]
        public void getAlarm(string userid)//获取测温告警统计信息
        {
            httpsend(ToJson(action.getAlarm(userid)));
        }
        [WebMethod(Description = "接口描述：获取当前用户下测温告警统计信息,返回告警总数，80-100,100-120,>120，，传值:登录用户的权限名称，比如：工区用户，传值areaname=某某工区，fenbuname=0,ywbname=0")]

        public void getAlarmByTemouterSection(string userid)
        {
            httpsend(ToJson(action.getAlarmByTemouterSection(userid)));
        }
        [WebMethod(Description = "接口描述：获取周期测温峰值统计")]
        public void getRoundTop(string userid)//获取周期测温峰值统计
        {
            httpsend(ToJson(action.getRoundTop(userid)));
        }
        [WebMethod(Description = "接口描述：一周设备温度统计")]
        public void temperatureWeekCount(string userid, string max, string min,  string month)//一周设备温度统计
        {
            string jsonStr = Newtonsoft.Json.JsonConvert.SerializeObject((action.temperatureWeekCount(userid, max, min, month)));
            httpsend(jsonStr);
        }
        [WebMethod(Description = "接口描述：获取地区和设备最高温对比")]
        public void getareaAnddevice(string userid)//地区和设备最高温对比 
        {
            DataTable dt = action.getareaAnddevice(userid);
            httpsend(ToJson(dt));
            // httpsend(strJson(action.getareaAnddevice(userid)));
        }

        [WebMethod(Description = "接口描述：设定或者取消该设备为重点监测设备 iskey=1表示重点监测，iskey=0表示非重点监测,一个站只能有一个重点监测设备，勾选某个设备为重点监测设备，其他设备的重点监测状态会被强制取消掉")]
        public void setkeypointdevice(string deviceid, string stationid, string iskey)//设定或者取消该设备为重点监测设备 iskey=1表示重点监测，iskey=0表示非重点监测
        {
            httpsend(strJson(action.setkeypointdevice(deviceid, stationid, iskey)));
        }
        [WebMethod(Description = "接口描述：设定或者取消该设备为实时监测设备 isround=1表示实时监测，isround=0表示非实时监测")]
        public void setrounddevice(string deviceid, string isround)//设定或者取消该设备为实时监测设备 isround=1表示实时监测，isround=0表示非实时监测
        {
            httpsend(strJson(action.setrounddevice(deviceid, isround)));
        }
        [WebMethod(Description = "接口描述：启用或禁用设备 isopen=1表示启用，isopen=0表示禁用")]
        public void setopendevice(string deviceid, string isopen)//设定或者取消该设备为实时监测设备 isround=1表示实时监测，isround=0表示非实时监测
        {
            httpsend(strJson(action.setopendevice(deviceid, isopen)));
        }
        [WebMethod(Description = "接口描述：确认告警；参数：deviceidlist,确认所有告警，参数传空，否则，以逗号隔开")]
        public void MenureAlarm(string userid, string sationid, string idlist, string human, string time)
        {
            httpsend(strJson(action.MensureAlarm(userid, sationid, idlist, human, time)));
        }

        [WebMethod(Description = "接口描述：删除告警；参数：alarmid,id逗号隔开")]
        public void DeleteAlarm(string idlist)
        {
            httpsend(strJson(action.DeleteAlarm(idlist)));
        }


        [WebMethod(Description = "接口描述：点击变电站，查看测温图库\n测温图库\n参数：stationid\n")]
        public void X_getImageListBystation(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string machineid, string isalarm,string StartTime,string EndTime)
        {
            httpsend(action.X_getImageListBystation(userid, areaid, fenbuid, ywbid, stationid, buildingid, devicetype, machineid, isalarm,StartTime,EndTime));
        }
        [WebMethod(Description = "接口描述：获取某个设备的历史图片，传值deviceid")]

        public void Y_getDeviceHistoryImage(string deviceid)
        {
            httpsend(ToJson(action.Y_getDeviceHistoryImage(deviceid)));
        }
        [WebMethod(Description = "接口描述：获取某个设备的历史告警，传值deviceid")]

        public void Y_getDeviceHistoryAlarm(string deviceid)
        {
            httpsend(ToJson(action.Y_getDeviceHistoryAlarm(deviceid)));

        }
        public string strJson1(string jsonText)
        {
            DataTable dt = new DataTable("msg");
            dt.Columns.Add("Recordcount", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        [WebMethod(Description = "接口描述：获取某个设备选中日期区间的历史记录和温度曲线：传值：deviceid;timespan=2020-05-14,2020-05-18;")]
        public void Z_getDeviceTempRecordByTimeSpan(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string machineid, string devicetype, string deviceid, string timeSpan, string page, string limit)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel.usertype == "0")
            {
                if (areaid == "" || areaid == null)
                {
                    areaid = usermodel.areaid;
                }
            }
            if (usermodel.usertype == "1")
            {
                if (fenbuid == "" || fenbuid == null)
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                if (ywbid == "" || ywbid == null)
                {
                    ywbid = usermodel.ywbid;
                }
            }
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1) * int.Parse(limit);
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部")
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部")
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部")
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部")
                sqllist.Add("stationid='" + stationid + "'");
            if (buildingid != "" && buildingid != "全部")
                sqllist.Add("buildingid='" + buildingid + "'");
            if (machineid != "" && machineid != "全部")
                sqllist.Add("machineid='" + machineid + "'");
            if (deviceid != "" && deviceid != "全部")
                sqllist.Add("deviceid='" + deviceid + "'");
            if (devicetype != "" && devicetype != "全部")
                sqllist.Add("ysdtype='" + devicetype + "'");
            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql = "";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1];
            }


            string sql1 = sql;
            devicelistjson json1 = new devicelistjson();
            if (timeSpan!="")
            {
                string startDate = timeSpan.Split(',')[0];
                string endDate = timeSpan.Split(',')[1];
                DateTime dateStart, dateEnd;
                DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                dateStart = Convert.ToDateTime(startDate, dtFormat);
                dateEnd = Convert.ToDateTime(endDate, dtFormat);
                int dateSpan = dateEnd.Day - dateStart.Day;
                List<string> datelist = new List<string>();
                for (int i = 0; i < dateSpan + 1; i++)
                {
                    datelist.Add((dateStart.AddDays(i)).ToString("yyyy-MM-dd"));
                }
                Maticsoft.BLL.device_infor devser = new Maticsoft.BLL.device_infor();
                List<Maticsoft.Model.device_infor> devmodel = new List<Maticsoft.Model.device_infor>();
                if (usermodel.usertype == "3" && (areaid == "" || areaid == null))
                {
                    devmodel = devser.GetModelList(sql);

                }
                else
                {
                    devmodel = devser.GetModelList(sql);

                }



                DataTable table = new DataTable("record");
                table.Columns.Add("areaname", Type.GetType("System.String"));
                table.Columns.Add("fenbuname", Type.GetType("System.String"));
                table.Columns.Add("ywbname", Type.GetType("System.String"));
                table.Columns.Add("stationname", Type.GetType("System.String"));
                table.Columns.Add("buildingname", Type.GetType("System.String"));
                table.Columns.Add("devicetype", Type.GetType("System.String"));
                table.Columns.Add("devicename", Type.GetType("System.String"));
                table.Columns.Add("maxvalue", Type.GetType("System.String"));
                table.Columns.Add("minvalue", Type.GetType("System.String"));
                table.Columns.Add("avgvalue", Type.GetType("System.String"));
                table.Columns.Add("createtime", Type.GetType("System.String"));
                int allcount = 0;
                List<Maticsoft.Model.image_record_history> historylistall = new List<Maticsoft.Model.image_record_history>();

                if (devmodel.Count() < 1)
                {
                    devicelistjson json = new devicelistjson();
                    json.Recordcount = "0";
                    json.Recorddt = null;

                    httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));
                }
                else
                {
                    for (int i = 0; i < devmodel.Count(); i++)
                    {
                        string sssid = devmodel[i].deviceid;

                        Maticsoft.BLL.device_infor dser = new Maticsoft.BLL.device_infor();
                        Maticsoft.Model.device_infor dmodel = new Maticsoft.Model.device_infor();
                        dmodel = dser.GetModel(sssid);
                        if (dmodel == null)
                        {
                            devicelistjson json = new devicelistjson();
                            json.Recordcount = "0";
                            json.Recorddt = null;

                            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));
                        }


                        Maticsoft.BLL.image_record_history historyServer = new Maticsoft.BLL.image_record_history();
                        List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();
                        historylist = historyServer.GetModelList("deviceid='" + sssid + "' and createtime>'" + dateStart + "' and createtime<'" + dateEnd + "' order by createtime desc ");
                        DateTime timeold, timenew;
                        if (historylist.Count() > 0)
                        {
                            timeold = Convert.ToDateTime(historylist[0].createtime.Value.ToString(), dtFormat);
                            historylistall.Add(historylist[0]);

                            for (int j = 1; j < historylist.Count(); j++)
                            {
                                timenew = Convert.ToDateTime(historylist[j].createtime.Value.ToString(), dtFormat);
                                if (timenew.Day != timeold.Day)
                                {
                                    historylistall.Add(historylist[j]);
                                    timeold = timenew;
                                    allcount += 1;
                                }

                            }

                        }

                    }
                }
                if (historylistall.Count < 1)
                {
                    devicelistjson json = new devicelistjson();
                    json.Recordcount = "0";
                    json.Recorddt = null;

                    httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));
                }


                for (int i = 0; i < historylistall.Count(); i++)
                {
                    if (i >= npage && i < npage + end)
                    {
                        string sssid = historylistall[i].deviceid;
                        Maticsoft.BLL.device_infor dser = new Maticsoft.BLL.device_infor();
                        Maticsoft.Model.device_infor dmodel = new Maticsoft.Model.device_infor();
                        dmodel = dser.GetModel(sssid);
                        string areaname = dmodel.areaname;
                        string fenbuname = dmodel.fenbuname;
                        string ywbname = dmodel.ywbname;
                        string stationname = dmodel.stationname;
                        string buildingname = dmodel.buildingname;
                        string devicetypename = dmodel.ysdtype;
                        string devicename = dmodel.devicename;
                        string max = historylistall[i].valuemax;
                        string min = historylistall[i].valuemin;
                        string avg = historylistall[i].valueave;
                        string stime = historylistall[i].createtime.Value.ToString();
                        DateTime time = Convert.ToDateTime(stime, dtFormat);
                        table.Rows.Add(new object[] { areaname, fenbuname, ywbname, stationname, buildingname, devicetypename, devicename, max, min, avg, time });

                    }

                }
               
                json1.Recordcount = historylistall.Count().ToString();
                json1.Recorddt = table;
            }
            else
            {
                json1.Recordcount = "0";
            }

            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json1));
        }
        [WebMethod(Description = "接口描述：获取某个设备选中日期和时间点的温度曲线：传值：requestDateList=deviceid;2020-05-14,2020-05-18;4,5,8")]
        public void Z_getDeviceTemplistByTimeSpan(string requestDateList)
        {
            string deviceid = requestDateList.Split(';')[0];

            Maticsoft.BLL.device_infor dser = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor dmodel = new Maticsoft.Model.device_infor();
            dmodel = dser.GetModel(deviceid);
            if (dmodel == null)
                httpsend(strJson("没有查到此设备"));

            string devicename = dmodel.devicename;
            string machineid = dmodel.machineid;
            string machinename = dmodel.machinename;
            List<string> returnlist = new List<string>();

            string startDate = requestDateList.Split(';')[1].Split(',')[0];
            string endDate = requestDateList.Split(';')[1].Split(',')[1];
            string[] stimelist = null;
            if (requestDateList.Split(';')[2] == "全部")
            {
                List<string> testlist = new List<string>();
                for (int i = 0; i < 24; i++)
                {
                    testlist.Add(i.ToString("00"));
                    returnlist.Add(i.ToString("00") + ":00");
                }
                stimelist = testlist.ToArray();
            }
            else
            {
                stimelist = requestDateList.Split(';')[2].Split(',');
                for (int i = 0; i < stimelist.Length; i++)
                {
                    returnlist.Add(stimelist[i] + ":00");
                }
            }
            DateTime dateStart, dateEnd;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            dateStart = Convert.ToDateTime(startDate, dtFormat);
            dateEnd = Convert.ToDateTime(endDate, dtFormat);

            TimeSpan ts1 = new TimeSpan(dateEnd.Ticks);
            TimeSpan ts2 = new TimeSpan(dateStart.Ticks);
            TimeSpan ts = ts1.Subtract(ts2).Duration();
            int dateSpan = ts.Days;



            List<string> datelist = new List<string>();
            for (int i = 0; i < dateSpan + 1; i++)
            {
                datelist.Add((dateStart.AddDays(i).Date).ToString("yyyy-MM-dd"));
            }

            Maticsoft.BLL.image_record_history histryservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> histrymodel = new List<Maticsoft.Model.image_record_history>();
            histrymodel = histryservice.GetModelList("deviceid='" + deviceid + "'and createtime>'" + dateStart + "' and createtime<'" + dateEnd.AddDays(1) + "'");

            List<List<string>> wendulistall = new List<List<string>>();
            for (int i = 0; i < stimelist.Length; i++)
            {
                List<string> newlist = new List<string>();
                for (int k = 0; k < datelist.Count(); k++)
                {
                    string riqi = datelist[k];
                    string shijian = stimelist[i];
                    string svalue = "0.0";
                    for (int m = 0; m < histrymodel.Count(); m++)
                    {
                        string ssriqi = histrymodel[m].createtime.Value.Year.ToString() + "-" + histrymodel[m].createtime.Value.Month.ToString("00") + "-" + histrymodel[m].createtime.Value.Day.ToString("00");
                        string ssshijian = histrymodel[m].createtime.Value.Hour.ToString("00");

                        if (riqi == ssriqi && shijian == ssshijian)
                        {
                            svalue = histrymodel[m].valuemax;
                        }
                    }
                    newlist.Add(svalue);

                }
                double xxx0 = double.Parse(newlist[0]);
                for (int xx = 1; xx < newlist.Count(); xx++)
                {
                    double xxx = double.Parse(newlist[xx]);
                    if (xxx == 0.0)
                    {
                        xxx = double.Parse(newlist[xx - 1]);
                        newlist.RemoveAt(xx);
                        newlist.Insert(xx, xxx.ToString("0.0"));
                    }
                }
                wendulistall.Add(newlist);
            }
            publicAction.shijiandianfenxi_json json = new publicAction.shijiandianfenxi_json();
            json.Timelist = returnlist;
            json.Devicename = dmodel.devicename;
            Maticsoft.BLL.machine_infor bll = new Maticsoft.BLL.machine_infor();
            json.Machinename = bll.GetModel(dmodel.machineid).machinename;
            json.Datelist = datelist;
            json.Wendulist = wendulistall;
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));

        }
        [WebMethod(Description = "接口描述：自用接口，更新设备ysdid")]

        public void Z_updateysdidall()
        {
            UserServices.UserAction ss = new UserServices.UserAction();
            Maticsoft.BLL.device_infor ds = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> ml = new List<Maticsoft.Model.device_infor>();
            ml = ds.GetModelList("");
            for (int i = 0; i < ml.Count(); i++)
            {
                string buildingname = ml[i].buildingname;
                string machinename = ml[i].machinename;
                string ysdname = ml[i].ysdname;
                string ysdindex = ss.getysdidbyysdname(buildingname, machinename, ysdname);
                ds.UpdateYsdindex(ml[i].deviceid, ysdindex);
            }
        }
        [WebMethod(Description = "接口描述：自用接口，更新设备machineid")]
        public void Z_updateMachine()
        {
            Maticsoft.BLL.machine_infor msser = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
            Maticsoft.BLL.device_infor ds = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> ml = new List<Maticsoft.Model.device_infor>();
            UserServices.UserAction ss = new UserAction();
            ml = ds.GetModelList("");
            for (int i = 0; i < ml.Count(); i++)
            {
                string buildingname = ml[i].buildingname;
                string machinename = ml[i].machinename;
                string ysdname = ml[i].ysdname;
                string machineid = ss.getmachinenameid(buildingname, machinename, ysdname);
                ds.UpdateYsdindex(ml[i].deviceid, machineid);
            }
        }
        [WebMethod(Description = "接口描述：获取测温异常设备列表")]

        public void Y_getabnormalDevice(string userid)
        {
            httpsend(ToJson(action.Y_getabnormalDevice(userid)));
        }
        [WebMethod(Description = "接口描述：点击首页变电站进入告警列表")]
        public void Y_getAlarmDeviceByStation(string stationid)
        {
            httpsend(action.Y_getAlarmDeviceByStation(stationid));
        }

        [WebMethod(Description = "接口描述：点击首页变电站进入告警列表传值，stationid，ysdID")]
        public void Y_getAlarmDeviceByStationAndDevice(string userid, string stationid, string deviceid, string page, string limit)
        {
            httpsend(action.Y_getAlarmDeviceByStationAndYsd(userid, stationid, deviceid, page, limit));
        }
        public static bool IsNumber(string s)
        {
            int precision = 32; int scale = 0;
            if ((precision == 0) && (scale == 0))
            {
                return false;
            }
            string pattern = @"(^\d{1," + precision + "}";
            if (scale > 0)
            {
                pattern += @"\.\d{0," + scale + "}$)|" + pattern;
            }
            pattern += "$)";
            return Regex.IsMatch(s, pattern);
        }
        [WebMethod(Description = "接口描述：修改告警阈值，传值：deviceid，offsetvalue，offsethuman")]
        public void App_ModifyOffsetValue(string deviceid, string offsetvalue, string offsethuman)
        {
            if (!IsNumber(offsetvalue))
            {
                httpsend(strJson("输入的数字不合法"));
            }
            else
            {
                Maticsoft.BLL.device_infor devservice = new Maticsoft.BLL.device_infor();
                devservice.modifyAlarmValue(deviceid, offsetvalue, offsethuman);
                httpsend(strJson("修改成功"));
            }
        }
        [WebMethod(Description = "接口描述：告警推送点击我知道了")]
        public void App_SetRead(string alarmid)//告警推送信息
        {
            httpsend(strJson(action.SetKonw(alarmid)));
        }

        [WebMethod(Description = "接口描述：确认某条告警，传值，告警id")]
        public void App_MensureAlarm(string id, string fuhe, string human, string time)
        {
            Maticsoft.BLL.alarm_push_infor dser = new Maticsoft.BLL.alarm_push_infor();
            dser.UpdateIsok(id, fuhe, human, time);
            Maticsoft.BLL.station_infor staser = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stamodel = new List<Maticsoft.Model.station_infor>();
            stamodel = staser.GetModelList("");
            for (int i = 0; i < stamodel.Count(); i++)
            {
                updatestationAlarmcount(stamodel[i].stationid);
            }
            httpsend(strJson("告警已确认"));

        }
        [WebMethod(Description = "接口描述，更新各个变电站告警数量")]
        public void updatealarm_station()
        {
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            stationlist = stationservice.GetModelList("");
            for (int i = 0; i < stationlist.Count; i++)
            {
                updatestationAlarmcount(stationlist[i].stationid);
            }
        }
        public void updatestationAlarmcount(string stationid)
        {
            string isok = "1";
            string alarmcount = "0";
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            DataSet ds = alarmservice.GetList("stationid='" + stationid + "' and isok='" + isok + "'");
            if (ds.Tables[0].Rows.Count > 0)
                alarmcount = ds.Tables[0].Rows.Count.ToString();
            Maticsoft.BLL.station_infor deservice = new Maticsoft.BLL.station_infor();
            deservice.UpdateAlarmcount(stationid, alarmcount);
        }

        [WebMethod(Description = "接口描述：确认某条告警，传值，告警id")]

        public void App_DeleteAlarm(string id)
        {
            Maticsoft.BLL.alarm_push_infor dser = new Maticsoft.BLL.alarm_push_infor();
            dser.Delete(id);
            Maticsoft.BLL.station_infor staser = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stamodel = new List<Maticsoft.Model.station_infor>();
            stamodel = staser.GetModelList("");
            for (int i = 0; i < stamodel.Count(); i++)
            {
                updatestationAlarmcount(stamodel[i].stationid);
            }
            httpsend(strJson("1"));
        }
        [WebMethod(Description = "接口描述：获取告警详情，传值，告警id")]
        public void App_getAlarmDetial(string id)
        {
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("id", Type.GetType("System.String"));
            dt.Columns.Add("deviceid", Type.GetType("System.String"));
            dt.Columns.Add("devicename", Type.GetType("System.String"));
            dt.Columns.Add("stationname", Type.GetType("System.String"));
            dt.Columns.Add("alarmtime", Type.GetType("System.String"));
            dt.Columns.Add("alarmvalue", Type.GetType("System.String"));
            dt.Columns.Add("offsetvalue", Type.GetType("System.String"));
            dt.Columns.Add("offsethuman", Type.GetType("System.String"));
            dt.Columns.Add("fuhe", Type.GetType("System.String"));
            dt.Columns.Add("mensurehuman", Type.GetType("System.String"));
            dt.Columns.Add("mensuretime", Type.GetType("System.String"));
            dt.Columns.Add("isok", Type.GetType("System.String"));
            dt.Columns.Add("isread", Type.GetType("System.String"));
            dt.Columns.Add("imageurl1", Type.GetType("System.String"));
            dt.Columns.Add("imageurl2", Type.GetType("System.String"));
            dt.Columns.Add("imageurl3", Type.GetType("System.String"));


            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            Maticsoft.Model.alarm_push_infor alarmmodel = new Maticsoft.Model.alarm_push_infor();
            Maticsoft.BLL.device_infor devservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devmodel = new Maticsoft.Model.device_infor();
            alarmmodel = alarmservice.GetModel(id);
            if (alarmmodel != null)
            {
                devmodel = devservice.GetModel(alarmmodel.deviceid);
            }
            string imagename = alarmmodel.image_url;
            string image_0 = "";
            string image_1 = "";
            string image_2 = "";
            if (imagename.Contains("~0~"))
            {
                image_0 = imagename;
                image_2 = imagename.Replace("~0~", "~2~");
                image_1 = imagename.Replace("~0~", "~1~");
            }
            if (imagename.Contains("~1~"))
            {
                image_1 = imagename;
                image_2 = imagename.Replace("~1~", "~2~");
                image_0 = imagename.Replace("~1~", "~0~");
            }
            if (imagename.Contains("~2~"))
            {
                image_2 = imagename;
                image_0 = imagename.Replace("~2~", "~0~");
                image_1 = imagename.Replace("~2~", "~1~");
            }
            dt.Rows.Add(new object[] { alarmmodel.id, devmodel.deviceid, devmodel.devicename, devmodel.stationname, alarmmodel.createtime.ToString(), alarmmodel.alarmvalue, devmodel.offsetvalue, devmodel.offsethuman, alarmmodel.fuhe, alarmmodel.mensurehuman, alarmmodel.mensuretime.ToString(), alarmmodel.isok, alarmmodel.isread, image_0, image_1, image_2 });
            httpsend(ToJson(dt));
        }


        [WebMethod(Description = "根据stationid补充station_top_history表中缺失的历史数据")]
        public string get_every_station_top()
        {
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stationmodellist = new List<Maticsoft.Model.station_infor>();
            stationmodellist = stationservice.GetModelList("");
            for (int i = 0; i < stationmodellist.Count; i++)
            {
                if (stationmodellist[i].stationid != null)
                {
                    add_statonTop_history(stationmodellist[i].stationid);
                }

            }
            return "数据更新完成";
        }
        public void add_statonTop_history(string stationid)
        {
            for (int i = -20; i < 0; i++)//从i天以前开始统计每天最高温
            {
                Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
                List<Maticsoft.Model.image_record_history> modellist = historyservice.GetModelList("deviceid in (select deviceid from device_infor where stationid='" + stationid + "')and createtime >'" + System.DateTime.Now.AddDays(i) + "'and createtime < '" + System.DateTime.Now.AddDays(i + 1) + "'");
                //上面        
                List<double> itemvaluelist = new List<double>();
                List<string> itemrecordidlist = new List<string>();
                foreach (var item in modellist)
                {
                    itemvaluelist.Add(double.Parse(item.valuemax));
                    itemrecordidlist.Add(item.recordid);
                }
                if (itemvaluelist.Count > 0)
                {
                    int index = getMaxindex(itemvaluelist);//最大值的索引
                    string maxrecordid = itemrecordidlist[index];//最大值
                    Maticsoft.Model.image_record_history historymodel = new Maticsoft.Model.image_record_history();
                    historymodel = historyservice.GetModel(maxrecordid);
                    Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
                    Maticsoft.Model.station_infor stationmodel = new Maticsoft.Model.station_infor();
                    stationmodel = stationservice.GetModel(stationid);
                    Maticsoft.BLL.station_top_history stationtopservice = new Maticsoft.BLL.station_top_history();
                    Maticsoft.Model.station_top_history stationtopmodel = new Maticsoft.Model.station_top_history();
                    Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
                    Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                    devicemodel = deviceservice.GetModel(historymodel.deviceid);
                    string toprecordid = Guid.NewGuid().ToString("N");//不用记录的id去当表的主键
                    stationtopmodel.toprecordid = toprecordid;
                    stationtopmodel.stationname = stationmodel.stationname;
                    stationtopmodel.stationid = stationid;
                    stationtopmodel.todaytop = historymodel.valuemax;
                    stationtopmodel.toptime = historymodel.createtime;
                    stationtopmodel.topdevicename = historymodel.devicename;
                    stationtopmodel.offsetvalue = devicemodel.offsetvalue;
                    stationtopservice.Add(stationtopmodel);

                }

            }

        }





        [WebMethod(Description = "点击告警变电站，右侧弹出告警的设备列表")]
        public void l_getAlarmStation(string stationid)
        {

            string jsonStr = Newtonsoft.Json.JsonConvert.SerializeObject((action.l_getAlarmStation1(stationid)));
            httpsend(jsonStr);
            //FMeng:方便其他接口调用，封装为两层

            //youcejson json = new youcejson();
            //DataTable dt = new DataTable("machinecount");
            //dt.Columns.Add("id", Type.GetType("System.String"));
            //dt.Columns.Add("deviceid", Type.GetType("System.String"));
            //dt.Columns.Add("devicename", Type.GetType("System.String"));
            //dt.Columns.Add("stationname", Type.GetType("System.String"));
            //dt.Columns.Add("machinecode", Type.GetType("System.String"));
            //dt.Columns.Add("createtime", Type.GetType("System.String"));
            //dt.Columns.Add("value", Type.GetType("System.String"));
            //dt.Columns.Add("imageurl1", Type.GetType("System.String"));
            //dt.Columns.Add("imageurl2", Type.GetType("System.String"));
            //dt.Columns.Add("imageurl3", Type.GetType("System.String"));
            //dt.Columns.Add("note", Type.GetType("System.String"));

            //string isok = "1";
            //Maticsoft.BLL.device_infor devservice = new Maticsoft.BLL.device_infor();
            //Maticsoft.Model.device_infor devmodel = new Maticsoft.Model.device_infor();
            //List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            //Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
            //List<Maticsoft.Model.building_infor> buildingmodellist = new List<Maticsoft.Model.building_infor>();
            //buildingmodellist = buildingservice.GetModelList("stationid='" + stationid + "'");
            //string buildingname = "";
            //for (int i = 0; i < buildingmodellist.Count; i++)
            //{
            //    buildingname += buildingmodellist[i].buildingname + " | ";
            //}
            //buildingname = buildingname.Remove(buildingname.Length - 1, 1);
            //Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            //Maticsoft.Model.station_infor stationmodel = new Maticsoft.Model.station_infor();
            //stationmodel = stationservice.GetModel(stationid);
            //string topvalue = stationmodel.topvalue;
            //string todayid = stationmodel.todayid;
            //Maticsoft.BLL.image_record_history hisservice = new Maticsoft.BLL.image_record_history();
            //Maticsoft.Model.image_record_history hismodel = new Maticsoft.Model.image_record_history();
            //devicelist = devservice.GetModelList(" stationid='" + stationid + "' and todaytop='" + topvalue + "'");
            //hismodel = hisservice.GetModel(todayid);
            //string machinecode = "";
            //if (hismodel != null)
            //{
            //    devmodel = devservice.GetModel(hismodel.deviceid);
            //    Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
            //    machinecode = macser.GetModel(devmodel.machineid).machinecode;
            //    dt.Rows.Add(new object[] { hismodel.recordid, devmodel.deviceid, devmodel.devicename, devmodel.stationname, machinecode, hismodel.createtime.ToString(), hismodel.valuemax, hismodel.image0, hismodel.image1, hismodel.image2 ,"今日最高"});
            //}
            //if (devicelist.Count > 0)
            //{
            //    devmodel = devservice.GetModel(devicelist[0].deviceid);
            //    Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
            //    machinecode = macser.GetModel(devmodel.machineid).machinecode;
            //    dt.Rows.Add(new object[] { devmodel.deviceid, devmodel.deviceid, devmodel.devicename, devmodel.stationname, machinecode, devmodel.createtime.ToString(), devmodel.todaytop, devmodel.image_high, devmodel.image_red, devmodel.image_mix ,"当前最高"});
            //}
            //json.Devicelist = dt;
            //json.Buildinglist = buildingname;



        }


        [WebMethod(Description = "接口描述：获取峰值统计中温度对应的图片，传值recordid（历史图像id）")]
        public void getRoundImageBuid(string recordid,string Time)
        {
            //if (string.IsNullOrEmpty(Time))
            //{
            //    httpsend(strJson("该图片不存在"));
            //}      
            string TableName = "";
            if (Time !=null && Time!="")
            {
                var dateTime=DateTime.Parse(Time);
                var Month = dateTime.Month;
            
               // 获取月份设置新的表名称
                if (Month==9||Month==10||Month==11)
                {
                    // 当前月份是11月
                    if (Month==11)
                    {
                        if (dateTime.Day==1||dateTime.Day==2)
                        {
                            TableName = dateTime.Year + "0910";
                        }
                    }
                    else
                    {
                        TableName = dateTime.Year + "0910";
                    }
                
                }
                else
                {

                    TableName = dateTime.ToString("yyyyMM");
                }

            }
            string SqlWhere = "recordid='"+ recordid+"'";
            Maticsoft.BLL.image_record_history historyser = new Maticsoft.BLL.image_record_history();
            Maticsoft.Model.image_record_history historymodel = new Maticsoft.Model.image_record_history();
            var ModelList = historyser.HisGetModelList(TableName, SqlWhere);
            if (ModelList.Count<=0)
            {
                httpsend(strJson("该图片不存在"));
            }
            historymodel= ModelList.FirstOrDefault();
            string deviceid = historymodel.deviceid;
            Maticsoft.BLL.device_infor devser = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devmodel = devser.GetModel(deviceid);
            Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
            
            var ModelMachine= macser.GetModel(devmodel.machineid);
            string machinecode = "";
            if (ModelMachine!=null)
            {
                machinecode=ModelMachine.machinecode;
            }
            string stationid = devmodel.stationid;
            Maticsoft.BLL.shortname_infor shortser = new Maticsoft.BLL.shortname_infor();
            Maticsoft.Model.shortname_infor shortmodel = new Maticsoft.Model.shortname_infor();
            shortmodel = shortser.GetModel(stationid);
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("recordid", Type.GetType("System.String"));
            dt.Columns.Add("deviceid", Type.GetType("System.String"));
            dt.Columns.Add("devicename", Type.GetType("System.String"));
            dt.Columns.Add("stationname", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname1", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname2", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname3", Type.GetType("System.String"));
            dt.Columns.Add("machinecode", Type.GetType("System.String"));
            dt.Columns.Add("imageurl1", Type.GetType("System.String"));
            dt.Columns.Add("imageurl2", Type.GetType("System.String"));
            dt.Columns.Add("imageurl3", Type.GetType("System.String"));
            dt.Columns.Add("isalarm", Type.GetType("System.String"));
            dt.Columns.Add("valuemax", Type.GetType("System.String"));
            dt.Columns.Add("createtime", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { recordid, deviceid, historymodel.devicename, devser.GetModel(deviceid).stationname, shortmodel.namenew1, shortmodel.namenew2, shortmodel.namenew3, machinecode, historymodel.image0, historymodel.image1, historymodel.image2, historymodel.isalarm, historymodel.valuemax, historymodel.createtime.ToString() });
            httpsend(ToJson(dt));

        }


        [WebMethod(Description = "接口描述：获取某个设备当天检测到的所有时间点的温度，传值deviceid")]
        public void getdeviceTempToday(string deviceid)
        {
            //获取整点数据
            Maticsoft.BLL.image_record_history deviceservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> devicelist = new List<Maticsoft.Model.image_record_history>();
            devicelist = deviceservice.GetModelList("  deviceid='" + deviceid + "' and createtime>'" + System.DateTime.Now.Date + "' group by createtime order by createtime desc");
            //获取15分钟测温数据
            Maticsoft.BLL.device_heart_infor deviceheartservice = new Maticsoft.BLL.device_heart_infor();
            List<Maticsoft.Model.device_heart_infor> deviceheartlist = new List<Maticsoft.Model.device_heart_infor>();
            deviceheartlist = deviceheartservice.GetModelList("  deviceid='" + deviceid + "' and createtime>'" + System.DateTime.Now.Date + "' group by createtime  order by createtime desc");
            //将数据放到一个集合中
            List<deviceTemperatureJson> deviceTemperatureList = new List<deviceTemperatureJson>();
            if (devicelist.Count>0)
            {
                for (int i = 0;i<devicelist.Count;i++)
                {
                    deviceTemperatureJson json = new deviceTemperatureJson();
                    json.datetime = devicelist[i].createtime.Value;
                    json.temperature = double.Parse(devicelist[i].valuemax);
                    deviceTemperatureList.Add(json);
                }
            }
            if (deviceheartlist.Count > 0)
            {
                for (int j=0;j<deviceheartlist.Count;j++)
                {
                    deviceTemperatureJson json = new deviceTemperatureJson();
                    json.datetime = deviceheartlist[j].createtime.Value;
                    json.temperature = double.Parse(deviceheartlist[j].ppmax);
                    deviceTemperatureList.Add(json);
                }
            }
            //对集合进行倒序排序
            deviceTemperatureList = deviceTemperatureList.OrderByDescending(m => m.datetime).ToList();
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("createtime", Type.GetType("System.String"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            if (deviceTemperatureList.Count > 0)
            {
                for (int k = 0; k < deviceTemperatureList.Count; k++)
                {
                    dt.Rows.Add(new object[] { deviceTemperatureList[k].datetime.ToString(), deviceTemperatureList[k].temperature });
                }
            }
            httpsend(ToJson(dt));

        }



        [WebMethod(Description = "接口描述，修改告警值，传值deviceid,value,manager")]
        public void modifyAlarmValue(string deviceid, string value, string manager, string time)
        {
            Maticsoft.BLL.device_infor deser = new Maticsoft.BLL.device_infor();
            deser.modifyAlarmValue(deviceid, value, manager);
            httpsend(strJson("1"));
        }

        [WebMethod(Description = "接口描述：设备在线不在线状态请求")]
        public void OfflineCount()
        {
            Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
            List<Maticsoft.Model.machine_infor> devlist = new List<Maticsoft.Model.machine_infor>();
            devlist = macser.GetModelList("");
            DateTime nowtime = System.DateTime.Now;
            for (int i = 0; i < devlist.Count(); i++)
            {
                try
                {
                    DateTime lastTime = (DateTime)devlist[0].createtime;
                    TimeSpan tsStart = new TimeSpan(lastTime.Ticks);
                    TimeSpan tsEnd = new TimeSpan(nowtime.Ticks);
                    TimeSpan ts = tsEnd.Subtract(tsStart).Duration();
                    double hourspan = ts.Days * 24 + ts.Hours + (double)ts.Minutes / 60;
                    if (hourspan > 24)
                    {
                        macser.UpdateMachineState(devlist[i].machineid, "失联", "0", nowtime.ToString("yyyy-MM-dd hh:mm:ss"));
                    }
                    else
                    {
                        macser.UpdateMachineState(devlist[i].machineid, "在线", "1", "");
                    }
                }
                catch
                {
                    macser.UpdateMachineState(devlist[i].machineid, "失联", "0", nowtime.ToString("yyyy-MM-dd hh:mm:ss"));
                }
            }
            httpsend(strJson("成功"));
        }
        [WebMethod(Description = "接口描述：修改设备的Mac地址")]
        public void updateDeviceMac(string machineid, string machinemac, string machinecode)
        {
            Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
            macmodel = macservice.GetModel(machineid);
            string str = "";
            if (macmodel == null)
            {
                str = "该地址不存在";
                httpsend(strJson(str));
            }
            if (machinemac == "")
            {
                //macservice.UpdateMachineState(machineid, "拆除", "2", nowtime.ToString("yyyy-MM-dd hh:mm:ss"));
                macservice.Delete(machineid);//删除红外设备
                str = "拆除成功";
            }
            else
            {
                DateTime nowtime = System.DateTime.Now;
                macservice.UpdateMachineMac(machineid, machinemac, machinecode);
                macservice.UpdateMachineState(machineid, "在线", "1", nowtime.ToString("yyyy-MM-dd"));
                str = "更换成功";
            }
            httpsend(strJson(str));
        }

        [WebMethod(Description = "接口描述：获取当前登录用户下，变电站各个时间段的最高温度（今日，昨日，本周，本月，历史）")]
        public void getStation_TYWMH(string userid, string areaid, string fenbuid, string ywbid, string stationid)
        {
            UserAction action = new UserAction();
            action.updatestation(userid);
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel.usertype == "0")
            {
                {
                    areaid = usermodel.areaid;
                }
            }
            if (usermodel.usertype == "1")
            {
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                {
                    ywbid = usermodel.ywbid;
                }
            }
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部" && areaid != null)
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部" && fenbuid != null)
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部" && ywbid != null)
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部" && stationid != null)
                sqllist.Add("stationid='" + stationid + "'");

            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql += "1=1 ";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1] + "";
            }
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> modellist = new List<Maticsoft.Model.station_infor>();
            if (usermodel.usertype == "0")
            {
                modellist = stationservice.GetModelList(sql);

            }
            if (usermodel.usertype == "1")
            {
                modellist = stationservice.GetModelList(sql);

            }
            if (usermodel.usertype == "2")
            {
                modellist = stationservice.GetModelList(sql);

            }
            if (usermodel.usertype == "3")
            {
                modellist = stationservice.GetModelList(sql);

            }
            List<string> stationidlist = new List<string>();
            List<string> stationlist = new List<string>();
            List<string> todaylist = new List<string>();
            List<string> yestodaylist = new List<string>();
            List<string> weeklist = new List<string>();
            List<string> monthlist = new List<string>();
            List<string> historylist = new List<string>();
            stationTemJson json = new stationTemJson();
            for (int i = 0; i < modellist.Count(); i++)
            {
                stationidlist.Add(modellist[i].stationid);
                stationlist.Add(modellist[i].stationname);
                todaylist.Add(modellist[i].todaytop);
                yestodaylist.Add(modellist[i].yestodaytop);
                weeklist.Add(modellist[i].weektop);
                monthlist.Add(modellist[i].monthtop);
                historylist.Add(modellist[i].historytop);
            }
            json.Stationidlist = stationidlist;
            json.Stationlist = stationlist;
            json.Todaylist = todaylist;
            json.Yestodaylist = yestodaylist;
            json.Weeklist = weeklist;
            json.Monthlist = monthlist;
            json.Historylist = historylist;
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));
        }
        [WebMethod(Description = "接口描述：获取变电站各个时间段的最高温度（今日，昨日，本周，本月，历史）的图片")]
        public void getStation_image_TYWMH(string stationid)
        {
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            Maticsoft.Model.station_infor stationmodel = new Maticsoft.Model.station_infor();
            stationmodel = stationservice.GetModel(stationid);
            if (stationmodel == null)
            {
                return;
            }
            DataTable dt = new DataTable();
            dt.Columns.Add("devicename", Type.GetType("System.String"));
            dt.Columns.Add("stationname", Type.GetType("System.String"));
            dt.Columns.Add("machinecode", Type.GetType("System.String"));
            dt.Columns.Add("image_red", Type.GetType("System.String"));
            dt.Columns.Add("machinename", Type.GetType("System.String"));
            dt.Columns.Add("topvalue", Type.GetType("System.String"));
            dt.Columns.Add("createtime", Type.GetType("System.String"));
            dt.Columns.Add("date", Type.GetType("System.String"));
            Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devmodel = new Maticsoft.Model.device_infor();
            Maticsoft.BLL.image_record_history hisservice = new Maticsoft.BLL.image_record_history();
            Maticsoft.Model.image_record_history hismodel = new Maticsoft.Model.image_record_history();
            if (stationmodel.todayid != null && stationmodel.todayid != "")
            {
                hismodel = hisservice.GetModel(stationmodel.todayid);
                if (hismodel != null)
                {
                    devmodel = deviceservice.GetModel(hismodel.deviceid);
                    Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                    macmodel = macser.GetModel(devmodel.machineid);
                    dt.Rows.Add(new object[] { devmodel.devicename, stationmodel.stationname, macmodel.machinecode, hismodel.image1, macmodel.machinename, hismodel.valuemax, hismodel.createtime, "今日" });
                }
                //devicelist = deviceservice.GetModelList(" stationid = '" + stationmodel.stationid + " ' and todaytop = '" + stationmodel.todaytop + "'");
                //if (devicelist.Count > 0)
                //{
                //    macmodel = macservice.GetModel(devicelist[0].machineid);
                //    if (macmodel!= null)
                //    {
                //        dt.Rows.Add(new object[] { devicelist[0].devicename, stationmodel.stationname, macmodel.machinecode, devicelist[0].image_red, macmodel.machinename, devicelist[0].todaytop, devicelist[0] .createtime,"今日"}); 
                //    }
                //}
            }
            if (stationmodel.yestodayid != null && stationmodel.yestodayid != "")
            {
                hismodel = hisservice.GetModel(stationmodel.yestodayid);
                if (hismodel != null)
                {
                    devmodel = deviceservice.GetModel(hismodel.deviceid);
                    Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                    macmodel = macser.GetModel(devmodel.machineid);
                    dt.Rows.Add(new object[] { devmodel.devicename, stationmodel.stationname, macmodel.machinecode, hismodel.image1, macmodel.machinename, hismodel.valuemax, hismodel.createtime, "昨日" });
                }

            }
            if (stationmodel.weekid != null && stationmodel.weekid != "")
            {
                hismodel = hisservice.GetModel(stationmodel.weekid);
                if (hismodel != null)
                {
                    devmodel = deviceservice.GetModel(hismodel.deviceid);
                    Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                    macmodel = macser.GetModel(devmodel.machineid);
                    dt.Rows.Add(new object[] { devmodel.devicename, stationmodel.stationname, macmodel.machinecode, hismodel.image1, macmodel.machinename, hismodel.valuemax, hismodel.createtime, "7日" });
                }

            }
            if (stationmodel.monthid != null && stationmodel.monthid != "")
            {
                hismodel = hisservice.GetModel(stationmodel.monthid);
                if (hismodel != null)
                {
                    devmodel = deviceservice.GetModel(hismodel.deviceid);
                    Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                    macmodel = macser.GetModel(devmodel.machineid);
                    dt.Rows.Add(new object[] { devmodel.devicename, stationmodel.stationname, macmodel.machinecode, hismodel.image1, macmodel.machinename, hismodel.valuemax, hismodel.createtime, "30天" });
                }
            }
            httpsend(ToJson(dt));
        }

        public int getMaxindex(List<double> list)
        {
            double a = list[0];
            int index = 0;//把假设的最大值索引赋值非index

            for (int i = 1; i < list.Count; i++)
            {
                if (list[i] > a)
                {
                    a = list[i];
                    index = i;//把较大值的索引赋值非index
                }
            }
            return index;
        }

        [WebMethod(Description = "接口描述：获取一周设备统计，传值userid")]
        public void ZZZ_get_device_tongji_week(string userid)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
                return;
            Maticsoft.BLL.image_record_history imageservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();
            if (usermodel.usertype == "0")
            {
                historylist = imageservice.GetModelList("areaid='" + usermodel.areaid + "' and createtime>'" + System.DateTime.Now.AddDays(-7).ToString() + "' and createtime<'" + System.DateTime.Now.ToString() + "' group by devicename");
            }
            if (usermodel.usertype == "1")
            {
                historylist = imageservice.GetModelList("fenbuid='" + usermodel.fenbuid + "' and createtime>'" + System.DateTime.Now.AddDays(-7).ToString() + "' and createtime<'" + System.DateTime.Now.ToString() + "' group by devicename");
            }
            if (usermodel.usertype == "2")
            {
                historylist = imageservice.GetModelList("ywbid='" + usermodel.ywbid + "' and createtime>'" + System.DateTime.Now.AddDays(-7).ToString() + "' and createtime<'" + System.DateTime.Now.ToString() + "' group by devicename");
            }
            if (usermodel.usertype == "3")
            {
                historylist = imageservice.GetModelList("createtime>'" + System.DateTime.Now.AddDays(-7).ToString() + "' and createtime<'" + System.DateTime.Now.ToString() + "' group by devicename");
            }
            int count_70 = 0;
            int count_80 = 0;
            int count_90 = 0;
            int count_100 = 0;
            //           int count_120 = 0;
            int allcount = 0;
            for (int i = 0; i < historylist.Count; i++)
            {
                string temp = historylist[i].valuemax;
                if (temp != "" && temp != null)
                {
                    double value = double.Parse(temp);
                    if (value >= 70 && value < 80)
                    {
                        count_70 += 1;
                    }
                    if (value >= 80 && value < 90)
                    {
                        count_80 += 1;
                    }
                    if (value >= 90 && value < 100)
                    {
                        count_90 += 1;
                    }
                    if (value >= 100)
                    {
                        count_100 += 1;
                    }
                    //if(value>=120&&value<140)
                    //{
                    //    count_120 += 1;
                    //}
                }
            }
            allcount = count_70 + count_80 + count_90 + count_100;
            DataTable dtx_device = new DataTable("machinecount");
            dtx_device.Columns.Add("allcount", Type.GetType("System.String"));
            dtx_device.Columns.Add("count_70", Type.GetType("System.String"));
            dtx_device.Columns.Add("count_80", Type.GetType("System.String"));
            dtx_device.Columns.Add("count_90", Type.GetType("System.String"));
            dtx_device.Columns.Add("count_100", Type.GetType("System.String"));
            //            dtx_device.Columns.Add("count_120", Type.GetType("System.String"));
            dtx_device.Rows.Add(new object[] { allcount, count_70, count_80, count_90, count_100 });
            httpsend(ToJson(dtx_device));
        }

        [WebMethod(Description = "接口描述：获取本月超80度设备统计，传值userid")]
        public void ZZZ_get_device_80_tongji_month(string userid)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
                return;
            Maticsoft.BLL.alarm_push_infor imageservice = new Maticsoft.BLL.alarm_push_infor();
            List<Maticsoft.Model.alarm_push_infor> historylist = new List<Maticsoft.Model.alarm_push_infor>();
            if (usermodel.usertype == "0")
            {
                historylist = imageservice.GetModelList("areaid='" + usermodel.areaid + "' and createtime>'" + System.DateTime.Now.AddDays(-7).ToString() + "' and createtime<'" + System.DateTime.Now.ToString() + "' group by devicename");
            }
            if (usermodel.usertype == "1")
            {
                historylist = imageservice.GetModelList("fenbuid='" + usermodel.fenbuid + "' and createtime>'" + System.DateTime.Now.AddDays(-7).ToString() + "' and createtime<'" + System.DateTime.Now.ToString() + "' group by devicename");
            }
            if (usermodel.usertype == "2")
            {
                historylist = imageservice.GetModelList("ywbid='" + usermodel.ywbid + "' and createtime>'" + System.DateTime.Now.AddDays(-7).ToString() + "' and createtime<'" + System.DateTime.Now.ToString() + "' group by devicename");
            }
            if (usermodel.usertype == "3")
            {
                historylist = imageservice.GetModelList("1=1 and createtime>'" + System.DateTime.Now.AddDays(-7).ToString() + "' and createtime<'" + System.DateTime.Now.ToString() + "' group by devicename");
            }
            DataTable dtx_device = new DataTable("machinecount");
            dtx_device.Columns.Add("stationname", Type.GetType("System.String"));
            dtx_device.Columns.Add("devicename", Type.GetType("System.String"));
            dtx_device.Columns.Add("alarmvalue", Type.GetType("System.String"));
            dtx_device.Columns.Add("machinename", Type.GetType("System.String"));
            dtx_device.Columns.Add("machinecode", Type.GetType("System.String"));
            dtx_device.Columns.Add("image_high", Type.GetType("System.String"));
            dtx_device.Columns.Add("image_red", Type.GetType("System.String"));
            dtx_device.Columns.Add("image_mix", Type.GetType("System.String"));
            dtx_device.Columns.Add("createtime", Type.GetType("System.String"));


            DataTable dtx_device1 = new DataTable("machinecount");
            dtx_device1.Columns.Add("devicetype", Type.GetType("System.String"));
            dtx_device1.Columns.Add("count", Type.GetType("System.String"));
            int count1 = 0;
            int count2 = 0;
            int count3 = 0;
            int count4 = 0;
            int count5 = 0;
            int count6 = 0;
            int count7 = 0;
            int count8 = 0;
            for (int i = 0; i < historylist.Count; i++)
            {
                string temp = historylist[i].alarmvalue;
                if (temp != "" && temp != null)
                {
                    string deviceid = historylist[i].deviceid;
                    string alarmtime = historylist[i].createtime.ToString();
                    Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
                    Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                    devicemodel = deviceservice.GetModel(deviceid);
                    Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                    Maticsoft.Model.machine_infor machinemodel = new Maticsoft.Model.machine_infor();
                    if (devicemodel != null)
                        machinemodel = machineservice.GetModel(devicemodel.machineid);
                    Maticsoft.BLL.image_record_history recordservice = new Maticsoft.BLL.image_record_history();
                    List<Maticsoft.Model.image_record_history> recordlist = new List<Maticsoft.Model.image_record_history>();
                    recordlist = recordservice.GetModelList("deviceid='" + deviceid + "' and createtime='" + alarmtime + "'");
                    if (recordlist.Count > 0)
                    {
                        dtx_device.Rows.Add(new object[] { historylist[i].stationname, historylist[i].devicename, historylist[i].alarmvalue, machinemodel.machinename, machinemodel.machinecode, recordlist[0].image0, recordlist[0].image1, recordlist[0].image2, recordlist[0].createtime.ToString() });
                        if (historylist[i].devicetype == "主变")
                        {
                            count1 += 1;
                        }
                        if (historylist[i].devicetype == "电抗器")
                        {
                            count2 += 1;
                        }
                        if (historylist[i].devicetype == "站用变")
                        {
                            count3 += 1;
                        }
                        if (historylist[i].devicetype == "电容器")
                        {
                            count4 += 1;
                        }
                        if (historylist[i].devicetype == "消弧线圈")
                        {
                            count5 += 1;
                        }
                        if (historylist[i].devicetype == "开关柜")
                        {
                            count6 += 1;
                        }
                        if (historylist[i].devicetype == "刀闸")
                        {
                            count7 += 1;
                        }
                        if (historylist[i].devicetype == "隔离开关")
                        {
                            count8 += 1;
                        }
                    }

                }
            }
            dtx_device1.Rows.Add(new object[] { "主变", count1 });
            dtx_device1.Rows.Add(new object[] { "电抗器", count2 });
            dtx_device1.Rows.Add(new object[] { "站用变", count3 });
            dtx_device1.Rows.Add(new object[] { "电容器", count4 });
            dtx_device1.Rows.Add(new object[] { "消弧线圈", count5 });
            dtx_device1.Rows.Add(new object[] { "开关柜", count6 });
            dtx_device1.Rows.Add(new object[] { "刀闸", count7 });
            dtx_device1.Rows.Add(new object[] { "隔离开关", count8 });
            device_80_json json = new device_80_json();
            //dtx_device1.DefaultView.Sort = "count DESC";
            json.Device_tongji_all = dtx_device1;
            json.Device_tongji_single = dtx_device;
            json.Tongji = dtx_device.Rows.Count.ToString(); ;
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(json));
        }


        [WebMethod(Description = "接口描述：批量删除历史图片，传值ids[历史图片 id 以逗号隔开]")]
        public void deleteImageByIds(string ids)
        {
            httpsend(action.deleteImageByIds(ids));
        }
    }

    }
 