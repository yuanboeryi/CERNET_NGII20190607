﻿using imfraredservices.HelperServer;
using imfraredservices.ReportServic;
using imfraredservices.UserServices;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Threading;
using System.Web;
using System.Web.Script.Serialization;

namespace imfraredservices.TableService
{
    public class TableAction
    {

        public DataTable getcityWeather()
        {
            return null;
        }


        public youcejson l_getAlarmStation(string stationid)
        {
            youcejson json = new youcejson();
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("id", Type.GetType("System.String"));
            dt.Columns.Add("deviceid", Type.GetType("System.String"));
            dt.Columns.Add("devicename", Type.GetType("System.String"));
            dt.Columns.Add("stationname", Type.GetType("System.String"));
            dt.Columns.Add("machinecode", Type.GetType("System.String"));
            dt.Columns.Add("createtime", Type.GetType("System.String"));
            dt.Columns.Add("value", Type.GetType("System.String"));
            dt.Columns.Add("imageurl1", Type.GetType("System.String"));
            dt.Columns.Add("imageurl2", Type.GetType("System.String"));
            dt.Columns.Add("imageurl3", Type.GetType("System.String"));
            dt.Columns.Add("note", Type.GetType("System.String"));

            DataTable dt1 = new DataTable("todayTop");
            dt1.Columns.Add("id", Type.GetType("System.String"));
            dt1.Columns.Add("deviceid", Type.GetType("System.String"));
            dt1.Columns.Add("devicename", Type.GetType("System.String"));
            dt1.Columns.Add("stationname", Type.GetType("System.String"));
            dt1.Columns.Add("machinecode", Type.GetType("System.String"));
            dt1.Columns.Add("createtime", Type.GetType("System.String"));
            dt1.Columns.Add("value", Type.GetType("System.String"));
            dt1.Columns.Add("imageurl1", Type.GetType("System.String"));
            dt1.Columns.Add("imageurl2", Type.GetType("System.String"));
            dt1.Columns.Add("imageurl3", Type.GetType("System.String"));
            dt1.Columns.Add("note", Type.GetType("System.String"));
            string isok = "1";
            Maticsoft.BLL.device_infor devservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devmodel = new Maticsoft.Model.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
            List<Maticsoft.Model.building_infor> buildingmodellist = new List<Maticsoft.Model.building_infor>();
            buildingmodellist = buildingservice.GetModelList("stationid='" + stationid + "'");
            string buildingname = "";
            for (int i = 0; i < buildingmodellist.Count; i++)
            {
                buildingname += buildingmodellist[i].buildingname + " | ";
            }
            buildingname = buildingname.Remove(buildingname.Length - 1, 1);
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            Maticsoft.Model.station_infor stationmodel = new Maticsoft.Model.station_infor();
            stationmodel = stationservice.GetModel(stationid);
            string topvalue = stationmodel.topvalue;
            string todaytop = stationmodel.todaytop;
            string todayid = stationmodel.todayid;
            Maticsoft.BLL.image_record_history hisservice = new Maticsoft.BLL.image_record_history();
            Maticsoft.Model.image_record_history hismodel = new Maticsoft.Model.image_record_history();
            devicelist = devservice.GetModelList(" stationid='" + stationid + "' and todaytop='" + topvalue + "'");
            string machinecode = "";
            hismodel = hisservice.GetModel(todayid);
            if (hismodel != null)
            {
                devmodel = devservice.GetModel(hismodel.deviceid);
                Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                machinecode = macser.GetModel(devmodel.machineid).machinecode;
                dt.Rows.Add(new object[] { hismodel.recordid, devmodel.deviceid, devmodel.devicename, devmodel.stationname, machinecode, hismodel.createtime.ToString(), hismodel.valuemax, hismodel.image0, hismodel.image1, hismodel.image2, "今日最高" });
            }
            if (devicelist.Count > 0)
            {
                devmodel = devservice.GetModel(devicelist[0].deviceid);
                Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                machinecode = macser.GetModel(devmodel.machineid).machinecode;
                dt1.Rows.Add(new object[] { devmodel.deviceid, devmodel.deviceid, devmodel.devicename, devmodel.stationname, machinecode, devmodel.createtime.ToString(), devmodel.todaytop, devmodel.image_high, devmodel.image_red, devmodel.image_mix, "当前最高" });
            }

            json.Devicelist = dt;
            json.DeviceToplist = dt1;
            //            json.Buildinglist = buildingname;
            json.Buildinglist = "";
            return json;



        }

        public youcejson l_getAlarmStation1(string stationid)
        {
            youcejson json = new youcejson();
            try
            {
                string DataTimeNow = DateTime.Now.ToString("yyyy-MM-dd");
                Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
                Maticsoft.Model.station_infor stationmodel = new Maticsoft.Model.station_infor();
                stationmodel = stationservice.GetModel(stationid);
                if (stationmodel == null)
                {
                    return null;
                }

                Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
                List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
                string isok = "1";
                string alarmcount = "0";
                string todaytop = "";
                string todayid = "";
                string topdayvalue = "";
                string machinemac = "";
                string GetMonth = DateTime.Now.ToString("yyyy-MM");
                alarmlist = alarmservice.GetModelList("stationid = '" + stationid + "'and createtime > '" + GetMonth + "'and isok='" + isok + "'");
                if (alarmlist.Count > 0)
                {
                    alarmcount = alarmlist.Count.ToString();
                }              
                DataTable dt = new DataTable("machinecount");
                dt.Columns.Add("id", Type.GetType("System.String"));
                dt.Columns.Add("deviceid", Type.GetType("System.String"));
                dt.Columns.Add("devicename", Type.GetType("System.String"));
                dt.Columns.Add("stationname", Type.GetType("System.String"));
                dt.Columns.Add("machinecode", Type.GetType("System.String"));
                dt.Columns.Add("createtime", Type.GetType("System.String"));
                dt.Columns.Add("value", Type.GetType("System.String"));
                dt.Columns.Add("imageurl1", Type.GetType("System.String"));
                dt.Columns.Add("imageurl2", Type.GetType("System.String"));
                dt.Columns.Add("imageurl3", Type.GetType("System.String"));
                dt.Columns.Add("note", Type.GetType("System.String"));
                dt.Columns.Add("stationid", Type.GetType("System.String"));
                dt.Columns.Add("alarmcount", Type.GetType("System.String"));

                DataTable dt1 = new DataTable("todayTop");
                dt1.Columns.Add("id", Type.GetType("System.String"));
                dt1.Columns.Add("deviceid", Type.GetType("System.String"));
                dt1.Columns.Add("devicename", Type.GetType("System.String"));
                dt1.Columns.Add("stationname", Type.GetType("System.String"));
                dt1.Columns.Add("machinecode", Type.GetType("System.String"));
                dt1.Columns.Add("createtime", Type.GetType("System.String"));
                dt1.Columns.Add("value", Type.GetType("System.String"));
                dt1.Columns.Add("imageurl1", Type.GetType("System.String"));
                dt1.Columns.Add("imageurl2", Type.GetType("System.String"));
                dt1.Columns.Add("imageurl3", Type.GetType("System.String"));
                dt1.Columns.Add("note", Type.GetType("System.String"));
                dt1.Columns.Add("stationid", Type.GetType("System.String"));
                dt1.Columns.Add("alarmcount", Type.GetType("System.String"));

                Maticsoft.BLL.device_infor BLLDevice = new Maticsoft.BLL.device_infor();
                Maticsoft.BLL.machine_infor machine_Server = new Maticsoft.BLL.machine_infor();
                Maticsoft.Model.machine_infor machine_Model = new Maticsoft.Model.machine_infor();
                // 通过变电站查询设备表
                // 倒叙获取第一条数据
                var GetModelListDevice = BLLDevice.GetModelList("stationid='" + stationmodel.stationid + "'");
                if (GetModelListDevice.Count <= 0)
                {
                    return null;
                }
                string StrJoin = string.Empty;
                for (int i = 0; i < GetModelListDevice.Count; i++)
                {
                    if (i == GetModelListDevice.Count - 1)
                    {
                        StrJoin += "'" + GetModelListDevice[i].deviceid + "'";
                    }
                    else
                    {
                        StrJoin += "'" + GetModelListDevice[i].deviceid + "'" + ",";
                    }
                }
                string MachCode = string.Empty;
                // 查询 image_record_history 通过 deviceid 和 createtime
                Maticsoft.BLL.image_record_history BLLImage = new Maticsoft.BLL.image_record_history();
                Maticsoft.Model.image_record_history ModelImage = new Maticsoft.Model.image_record_history();
                var GetModelIMageList = BLLImage.GetModelList("deviceid in(" + StrJoin + ")" + " And createtime>'" + DataTimeNow + "'");
                if (GetModelIMageList.Count >= 1)
                {
                    // 获取序列中valuemax的最大值
                    var MaxValue = GetModelIMageList.Max(m => Convert.ToDouble(m.valuemax));
                    var ModelHisDesc = GetModelIMageList.Where(m => m.valuemax == MaxValue.ToString()).FirstOrDefault();

                    if (ModelHisDesc != null)
                    {
                        // 更新变电站今日最高温度数据
                        stationmodel.todaytop = ModelHisDesc.valuemax;
                        stationmodel.todayid = ModelHisDesc.recordid;

                        todaytop = ModelHisDesc.valuemax;
                        todayid = ModelHisDesc.recordid;
                        machinemac = ModelHisDesc.machinemac;
                        var ModelMachie = machine_Server.getModelByMac(machinemac);
                        if (ModelMachie != null)
                        {
                            MachCode = ModelMachie.machinecode;
                        }
                        // 今日最高
                        dt1.Rows.Add(new object[] { ModelHisDesc.deviceid, ModelHisDesc.deviceid, ModelHisDesc.devicename, stationmodel.stationname, MachCode, ModelHisDesc.createtime.ToString(), ModelHisDesc.valuemax, ModelHisDesc.image0, ModelHisDesc.image1, ModelHisDesc.image2, "今日最高", stationid, alarmcount });

                    }

                    // 当前最高
                    // 通过时间倒叙获取最新的设备信息
                    GetModelIMageList = GetModelIMageList.OrderByDescending(m => m.createtime).ToList();
                    var FirstModelImage = GetModelIMageList.FirstOrDefault();
                    if (FirstModelImage != null)
                    {
                        // 更新变电站当前温度
                        stationmodel.topvalue = FirstModelImage.valuemax;
                        topdayvalue = FirstModelImage.valuemax;
                        if (ModelHisDesc!=null)
                        {
                            machinemac = ModelHisDesc.machinemac;
                            var ModelMachie = machine_Server.getModelByMac(machinemac);
                            if (ModelMachie != null)
                            {
                                MachCode = ModelMachie.machinecode;
                            }
                            // 当前最高
                            dt.Rows.Add(new object[] { FirstModelImage.deviceid, FirstModelImage.deviceid, FirstModelImage.devicename, stationmodel.stationname, MachCode, FirstModelImage.createtime.ToString(), FirstModelImage.valuemax, FirstModelImage.image0, FirstModelImage.image1, FirstModelImage.image2, "当前最高", stationid, alarmcount });
                        }
                        
                      
                    }
                    // 更新变电站表
                    // var IsBool=stationservice.Update(stationmodel);
                    stationservice.UpdateTodayTopValue(stationid, topdayvalue, todaytop, todayid);
                    //if (!IsBool)
                    //{
                    //    stationservice.UpdateTodayTopValue(stationid, topdayvalue, todaytop, todayid);
                    //}
                    json.Devicelist = dt;
                    json.DeviceToplist = dt1;
                    json.Buildinglist = "";
                }
            }
            catch (Exception e)
            {
                json = new youcejson();
                return json;   
            }
            return json;
        }

        public DataTable getkeyPointdeviceBystation(string stationname, string page, string numbers)//重点监测设备
        {
            string iskey = "1";
            string isopen = "1";
            int end = (int.Parse(numbers));
            int npage = (int.Parse(page) - 1) * int.Parse(numbers);
            Maticsoft.BLL.device_infor bll = new Maticsoft.BLL.device_infor();
            DataTable dt = bll.GetList("stationname='" + stationname + "' and iskeypoint='" + iskey + "'  and isopen='" + isopen + "' order by stationname limit " + npage + "," + end + "").Tables[0];
            publicAction.getShortName pa = new publicAction.getShortName();
            dt.Columns.Add("stationshortname1", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname2", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname3", Type.GetType("System.String"));
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string s1 = dt.Rows[i]["stationid"].ToString().Split(',')[0];
                dt.Rows[i]["stationshortname1"] = pa.getshortname(dt.Rows[i]["stationid"].ToString()).Split(',')[0];
                dt.Rows[i]["stationshortname2"] = pa.getshortname(dt.Rows[i]["stationid"].ToString()).Split(',')[1];
                dt.Rows[i]["stationshortname3"] = pa.getshortname(dt.Rows[i]["stationid"].ToString()).Split(',')[2];

            }
            return dt;
        }

        public string getkeypointdeviceByuser(string userid, string page, string numbers)
        {
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = user.GetModel(userid);
            if (usermodel == null)
                return "0";
            else
            {
                string iskey = "1";
                int end = (int.Parse(numbers));
                int npage = (int.Parse(page) - 1) * int.Parse(numbers);
                List<Maticsoft.Model.device_infor> modellist = new List<Maticsoft.Model.device_infor>();
                Maticsoft.BLL.device_infor bllservice = new Maticsoft.BLL.device_infor();
                DataTable dt = new DataTable();
                DataTable dtall = new DataTable();
                DataSet ds = new DataSet();
                string isopen = "1";
                if (usermodel.usertype == "0")
                {
                    ds = bllservice.GetList("iskeypoint='" + iskey + "' and isopen='" + isopen + "' and areaid='" + usermodel.areaid + "' order by stationname limit " + npage + "," + end + "");
                    dt = ds.Tables[0];
                    dtall = bllservice.GetList("iskeypoint='" + iskey + "' and isopen='" + isopen + "' and areaid='" + usermodel.areaid + "'").Tables[0];
                }
                if (usermodel.usertype == "1")
                {
                    ds = bllservice.GetList("iskeypoint='" + iskey + "' and isopen='" + isopen + "' and fenbuid='" + usermodel.fenbuid + "' order by stationname limit " + npage + "," + end + "");
                    dt = ds.Tables[0];
                    dtall = bllservice.GetList("iskeypoint='" + iskey + "' and isopen='" + isopen + "' and fenbuid='" + usermodel.fenbuid + "'").Tables[0];
                }
                if (usermodel.usertype == "2")
                {
                    ds = bllservice.GetList("iskeypoint='" + iskey + "' and isopen='" + isopen + "' and ywbid='" + usermodel.ywbid + "' order by stationname limit " + npage + "," + end + "");
                    dt = ds.Tables[0];
                    dtall = bllservice.GetList("iskeypoint='" + iskey + "' and isopen='" + isopen + "' and ywbid='" + usermodel.ywbid + "'").Tables[0];
                }
                if (usermodel.usertype == "3")
                {
                    ds = bllservice.GetList("iskeypoint='" + iskey + "' and isopen='" + isopen + "' order by stationname limit " + npage + "," + end + "");
                    dt = ds.Tables[0];
                    dtall = bllservice.GetList("").Tables[0];
                }
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string deviceid = dt.Rows[i]["deviceid"].ToString();
                    update_device_state action = new update_device_state();
                    action.UpdateDevice(deviceid);
                }
                UserServices.devicelistjson l = new UserServices.devicelistjson();
                // DataTable dt = bll.GetList("iskeypoint ='" + iskey + "'").Tables[0];
                int allcount = dtall.Rows.Count;
                if (allcount % int.Parse(numbers) == 0)
                {
                    l.Recordcount = (allcount / int.Parse(numbers)).ToString();

                }
                else
                {
                    l.Recordcount = (allcount / int.Parse(numbers) + 1).ToString();

                }

                DataTable dtnew = new DataTable("keyDevice");
                dtnew.Columns.Add("deviceid", Type.GetType("System.String"));
                dtnew.Columns.Add("devicename", Type.GetType("System.String"));
                dtnew.Columns.Add("machinename", Type.GetType("System.String"));
                dtnew.Columns.Add("stationname", Type.GetType("System.String"));
                dtnew.Columns.Add("stationid", Type.GetType("System.String"));
                dtnew.Columns.Add("image_red", Type.GetType("System.String"));
                dtnew.Columns.Add("image_mix", Type.GetType("System.String"));
                dtnew.Columns.Add("image_high", Type.GetType("System.String"));
                dtnew.Columns.Add("dangqian", Type.GetType("System.String"));
                dtnew.Columns.Add("yestodaytop", Type.GetType("System.String"));
                dtnew.Columns.Add("weektop", Type.GetType("System.String"));
                dtnew.Columns.Add("monthtop", Type.GetType("System.String"));
                dtnew.Columns.Add("historytop", Type.GetType("System.String"));
                dtnew.Columns.Add("machinecode", Type.GetType("System.String"));
                dtnew.Columns.Add("createtime", Type.GetType("System.String"));
                dtnew.Columns.Add("todaymax", Type.GetType("System.String"));
                dtnew.Columns.Add("yestodaymaxid", Type.GetType("System.String"));
                dtnew.Columns.Add("weekmaxid", Type.GetType("System.String"));
                dtnew.Columns.Add("todaymaxid", Type.GetType("System.String"));
                dtnew.Columns.Add("historymaxid", Type.GetType("System.String"));
                dtnew.Columns.Add("monthmax", Type.GetType("System.String"));
                dtnew.Columns.Add("monthmaxid", Type.GetType("System.String"));
                dtnew.Columns.Add("today_image", Type.GetType("System.String"));
                dtnew.Columns.Add("month_image", Type.GetType("System.String"));
                dtnew.Columns.Add("todaymax_time", Type.GetType("System.String"));
                dtnew.Columns.Add("monthmax_time", Type.GetType("System.String"));

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string machineid = dt.Rows[i]["machineid"].ToString();

                    Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                    Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
                    macmodel = macser.GetModel(machineid);
                    Maticsoft.BLL.image_record_history hisser = new Maticsoft.BLL.image_record_history();
                    Maticsoft.Model.image_record_history hismodel = new Maticsoft.Model.image_record_history();
                    Maticsoft.Model.image_record_history hismodel1 = new Maticsoft.Model.image_record_history();
                    string machinename = macmodel.machinename;
                    if (macmodel != null)
                    {
                        string machinecode = macmodel.machinecode;
                        hismodel = hisser.GetModel(dt.Rows[i]["monthmaxid"].ToString());
                        hismodel1 = hisser.GetModel(dt.Rows[i]["todaymaxid"].ToString());
                        string is2 = "";
                        string is2time = "";
                        if (hismodel == null)
                        {
                            is2 = "";
                            is2time = "";
                        }
                        else
                        {
                            is2 = hismodel.image1;
                            is2time = hismodel.createtime.ToString();
                        }
                        string is1 = "";
                        string is1time = "";
                        if (hismodel1 == null)
                        {
                            is1 = "";
                            is1time = "";
                        }
                        else
                        {
                            is1 = hismodel1.image1;
                            is1time = hismodel1.createtime.ToString();
                        }


                        dtnew.Rows.Add(new object[] { dt.Rows[i]["deviceid"].ToString(), dt.Rows[i]["devicename"].ToString(), machinename, dt.Rows[i]["stationname"].ToString(), dt.Rows[i]["stationid"].ToString(), dt.Rows[i]["image_red"].ToString(), dt.Rows[i]["image_high"].ToString(), dt.Rows[i]["image_mix"].ToString(), dt.Rows[i]["todaytop"].ToString(), dt.Rows[i]["yestodaytop"].ToString(), dt.Rows[i]["weektop"].ToString(), dt.Rows[i]["monthtop"].ToString(), dt.Rows[i]["historytop"].ToString(), machinecode, dt.Rows[i]["createtime"].ToString(), dt.Rows[i]["todaymax"].ToString(), dt.Rows[i]["yestodaymaxid"].ToString(), dt.Rows[i]["weekmaxid"].ToString(), dt.Rows[i]["todaymaxid"].ToString(), dt.Rows[i]["historymaxid"].ToString(), dt.Rows[i]["monthmax"].ToString(), dt.Rows[i]["monthmaxid"].ToString(), is1, is2, is1time, is2time });

                    }

                    //dt.Rows.Add(new object[] { allcount.ToString(), count1.ToString(), count2.ToString(), count3.ToString() });

                }

                publicAction.getShortName pa = new publicAction.getShortName();
                dtnew.Columns.Add("stationshortname1", Type.GetType("System.String"));
                dtnew.Columns.Add("stationshortname2", Type.GetType("System.String"));
                dtnew.Columns.Add("stationshortname3", Type.GetType("System.String"));
                for (int i = 0; i < dtnew.Rows.Count; i++)
                {
                    string s1 = dtnew.Rows[i]["stationid"].ToString().Split(',')[0];
                    dtnew.Rows[i]["stationshortname1"] = pa.getshortname(dtnew.Rows[i]["stationid"].ToString()).Split(',')[0];
                    dtnew.Rows[i]["stationshortname2"] = pa.getshortname(dtnew.Rows[i]["stationid"].ToString()).Split(',')[1];
                    dtnew.Rows[i]["stationshortname3"] = pa.getshortname(dtnew.Rows[i]["stationid"].ToString()).Split(',')[2];

                }
                l.Recorddt = dtnew;
                return Newtonsoft.Json.JsonConvert.SerializeObject(l);
            }



        }

        public string getAllRounddevice(string userid, string stationid)//实时监测设备
        {
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = user.GetModel(userid);
            if (usermodel == null)
                return "0";
            string isround = "1";
            Maticsoft.BLL.device_infor bll = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> modellist = new List<Maticsoft.Model.device_infor>();
            string isopen = "1";
            string SqlWhere = " And stationid='" + stationid + "' GROUP By devicename";
            if (stationid == "")
            {
                if (usermodel.usertype == "0")
                {
                    //modellist = bll.GetModelList("isroundpoint='" + isround + "'  and isopen='" + isopen + "' and areaid='" + usermodel.areaid + "' order by stationname");

                    // TODO 之前后面加上 现在去掉
                    //GROUP BY stationname
                    modellist = bll.GetModelList("isroundpoint='" + isround + "'  and isopen='" + isopen + "' and areaid='" + usermodel.areaid + "' GROUP BY stationname");
                }
                if (usermodel.usertype == "1")
                {
                    modellist = bll.GetModelList("isroundpoint='" + isround + "' and isopen='" + isopen + "' and fenbuid='" + usermodel.fenbuid + "' GROUP BY stationname");

                }
                if (usermodel.usertype == "2")
                {
                    modellist = bll.GetModelList("isroundpoint='" + isround + "' and isopen='" + isopen + "' and ywbid='" + usermodel.ywbid + "' GROUP BY stationname" );

                }
                if (usermodel.usertype == "3")
                {
                    modellist = bll.GetModelList("isroundpoint='" + isround + "' and isopen='" + isopen + "' GROUP BY stationname");

                }
            }
            else
            {
                if (usermodel.usertype == "0")
                {
                    modellist = bll.GetModelList("isroundpoint='" + isround + "' and stationid='" + stationid + "'  and isopen='" + isopen + "' and areaid='" + usermodel.areaid + "' " +SqlWhere);

                }
                if (usermodel.usertype == "1")
                {
                    modellist = bll.GetModelList("isroundpoint='" + isround + "' and stationid='" + stationid + "'  and isopen='" + isopen + "' and fenbuid='" + usermodel.fenbuid + "' "+SqlWhere);

                }
                if (usermodel.usertype == "2")
                {
                    modellist = bll.GetModelList("isroundpoint='" + isround + "' and stationid='" + stationid + "'  and isopen='" + isopen + "' and ywbid='" + usermodel.ywbid + "' "+SqlWhere);

                }
                if (usermodel.usertype == "3")
                {
                    modellist = bll.GetModelList("isroundpoint='" + isround + "' and stationid='" + stationid + "'  and isopen='" + isopen + "' "+SqlWhere);

                }
            }

            List<roundDevicejson> jsonlist = new List<roundDevicejson>();
            if (modellist.Count > 0)
            {
                for (int i = 0; i < modellist.Count; i++)
                {
                    publicAction.getShortName pa = new publicAction.getShortName();

                    roundDevicejson json = new roundDevicejson();
                    if (modellist[i] != null)
                    {
                        json.Deviceid = modellist[i].deviceid;
                        json.Devicename = modellist[i].devicename;
                        json.Stationid = modellist[i].stationid;
                        json.Isalarm = modellist[i].isalarm;
                        json.Stationname = modellist[i].stationname;
                        json.Stationshortname1 = pa.getshortname(modellist[i].stationid).Split(',')[0];
                        json.Stationshortname2 = pa.getshortname(modellist[i].stationid).Split(',')[1];
                        json.Stationshortname3 = pa.getshortname(modellist[i].stationid).Split(',')[2];
                        json.Todaytop = modellist[i].todaytop;
                        json.Templist = modellist[i].templist.Split(',').ToList<string>();
                        json.Fuhelist = modellist[i].fuhelist.Split(',').ToList<string>();
                        json.Time = (DateTime)modellist[i].createtime;
                        json.Image_red = modellist[i].image_red;
                        json.Image_high = modellist[i].image_high;
                        json.Image_mix = modellist[i].image_mix;

                        Maticsoft.Model.device_infor dddmodel = bll.GetModel(modellist[i].deviceid);
                        if (dddmodel != null)
                        {
                            Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                            Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();

                            macmodel = macser.GetModel(dddmodel.machineid);
                            if (macmodel != null)
                            {
                                json.Machinecode = macmodel.machinecode;
                                json.Machinename = macmodel.machinename;
                            }

                        }

                    }

                    jsonlist.Add(json);
                }
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist); ;
        }
        public string getAllRound()//实时监测设备
        {
            string isround = "1";
            Maticsoft.BLL.device_infor bll = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> modellist = new List<Maticsoft.Model.device_infor>();
            string isopen = "1";
            modellist = bll.GetModelList("isroundpoint='" + isround + "'  and isopen='" + isopen + "'");

            List<roundDevicejson> jsonlist = new List<roundDevicejson>();
            for (int i = 0; i < modellist.Count(); i++)
            {
                roundDevicejson json = new roundDevicejson();
                json.Deviceid = modellist[i].deviceid;
                json.Devicename = modellist[i].devicename;
                json.Stationid = modellist[i].stationid;
                json.Stationname = modellist[i].stationname;
                json.Todaytop = modellist[i].todaytop;
                json.Templist = modellist[i].templist.Split(',').ToList<string>();
                json.Fuhelist = modellist[i].fuhelist.Split(',').ToList<string>();
                json.Time = System.DateTime.Now;
                json.Image_red = modellist[i].image_red;
                json.Image_high = modellist[i].image_high;
                json.Image_mix = modellist[i].image_mix;
                jsonlist.Add(json);
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist); ;
        }

        public string getRounddeviceBystation(string stationname)//实时监测设备
        {
            string isround = "1";
            Maticsoft.BLL.device_infor bll = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> modellist = new List<Maticsoft.Model.device_infor>();
            string isopen = "1";
            modellist = bll.GetModelList("isroundpoint='" + isround + "'  and isopen='" + isopen + "' and stationname='" + stationname + "'");

            List<roundDevicejson> jsonlist = new List<roundDevicejson>();
            for (int i = 0; i < modellist.Count(); i++)
            {
                roundDevicejson json = new roundDevicejson();
                json.Deviceid = modellist[i].deviceid;
                json.Devicename = modellist[i].devicename;
                json.Stationid = modellist[i].stationid;
                json.Stationname = modellist[i].stationname;
                json.Todaytop = modellist[i].todaytop;
                json.Templist = modellist[i].templist.Split(',').ToList<string>();
                json.Fuhelist = modellist[i].fuhelist.Split(',').ToList<string>();
                jsonlist.Add(json);
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist); ;
        }

        public string getRounddeviceByuser(string userid)
        {
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = user.GetModel(userid);
            if (usermodel == null)
                return "0";
            string isround = "1";
            Maticsoft.BLL.device_infor bll = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> modellist = new List<Maticsoft.Model.device_infor>();
            string isopen = "1";
            if (usermodel.usertype == "0")
            {
                modellist = bll.GetModelList("isroundpoint='" + isround + "' and isopen='" + isopen + "' and areaid='" + usermodel.areaid + "'");

            }
            if (usermodel.usertype == "1")
            {
                modellist = bll.GetModelList("isroundpoint='" + isround + "' and isopen='" + isopen + "' and fenbuid='" + usermodel.fenbuid + "'");

            }
            if (usermodel.usertype == "2")
            {
                modellist = bll.GetModelList("isroundpoint='" + isround + "' and isopen='" + isopen + "' and ywbid='" + usermodel.ywbid + "'");

            }
            if (usermodel.usertype == "3")
            {
                modellist = bll.GetModelList("");

            }
            List<roundDevicejson> jsonlist = new List<roundDevicejson>();
            for (int i = 0; i < modellist.Count(); i++)
            {
                roundDevicejson json = new roundDevicejson();
                json.Deviceid = modellist[i].deviceid;
                json.Devicename = modellist[i].devicename;
                json.Stationid = modellist[i].stationid;
                json.Stationname = modellist[i].stationname;
                json.Todaytop = modellist[i].todaytop;
                json.Templist = modellist[i].templist.Split(',').ToList<string>();
                json.Fuhelist = modellist[i].fuhelist.Split(',').ToList<string>();
                json.Time = System.DateTime.Now;
                json.Image_red = modellist[i].image_red;
                json.Image_high = modellist[i].image_high;
                json.Image_mix = modellist[i].image_mix;
                jsonlist.Add(json);
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(jsonlist); ;
        }

        public DataTable getTopdevice_Three(string userid)//获取当前登录用户下设备最高温
        {
            DateTime dtnow;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd 00:00:00";
            dtnow = Convert.ToDateTime(System.DateTime.Now.AddHours(-1).ToString(), dtFormat);
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = user.GetModel(userid);
            if (usermodel == null)
                return null;
            DataSet ds = new DataSet();
            Maticsoft.BLL.device_infor deviceser = new Maticsoft.BLL.device_infor();
            string isopen = "1";
            //            string maxvalue = "140";
            if (usermodel.usertype == "0")
            {
                ds = deviceser.GetList("areaid='" + usermodel.areaid + "' and isopen='" + isopen + "' and createtime>'" + dtnow + "'" + " order by  CAST(todaytop AS  SIGNED) desc");
            }
            if (usermodel.usertype == "1")
            {
                ds = deviceser.GetList("fenbuid='" + usermodel.fenbuid + "' and isopen='" + isopen + "' and createtime>'" + dtnow + "'" + " order by  CAST(todaytop AS  SIGNED) desc");
            }
            if (usermodel.usertype == "2")
            {
                ds = deviceser.GetList("ywbid='" + usermodel.ywbid + "' and isopen='" + isopen + "' and createtime>'" + dtnow + "'" + " order by  CAST(todaytop AS  SIGNED) desc");
            }
            if (usermodel.usertype == "3")
            {
                //order by  CAST(todaytop AS  SIGNED) desc
                ds = deviceser.GetList("1=1 " + " and createtime>'" + dtnow + "'" + " order by  CAST(todaytop AS  SIGNED) desc");
            }

            DataTable dt = ds.Tables[0];
            dt.Columns.Add("machinecode", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname1", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname2", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname3", Type.GetType("System.String"));
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string id = dt.Rows[i]["deviceid"].ToString();
                Maticsoft.Model.device_infor dddmodel = deviceser.GetModel(id);
                Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
                macmodel = macser.GetModel(dddmodel.machineid);
                if (macmodel != null)
                {
                    dt.Rows[i]["machinecode"] = macmodel.machinecode;
                    publicAction.getShortName pa = new publicAction.getShortName();

                    dt.Rows[i]["stationshortname1"] = pa.getshortname(dt.Rows[i]["stationid"].ToString()).Split(',')[0];
                    dt.Rows[i]["stationshortname2"] = pa.getshortname(dt.Rows[i]["stationid"].ToString()).Split(',')[1];
                    dt.Rows[i]["stationshortname3"] = pa.getshortname(dt.Rows[i]["stationid"].ToString()).Split(',')[2];
                }
            }

            DataTable dtNew = dt.Copy();  //复制dt表数据结构
            dtNew.Clear();  //清楚数据
            if (dt.Rows.Count > 3)
            {
                for (int i = 0; i < 3; i++)
                {
                    dtNew.Rows.Add(dt.Rows[i].ItemArray);  //添加数据行

                }

            }
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dtNew.Rows.Add(dt.Rows[i].ItemArray);  //添加数据行

                }
            }


            return dtNew;

        }
        public DataTable getTopdevice(string userid)//获取当前登录用户下设备最高温
        {
            DateTime dtnow;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd 00:00:00";
            dtnow = Convert.ToDateTime(System.DateTime.Now.AddDays(-1).ToString(), dtFormat);
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = user.GetModel(userid);
            if (usermodel == null)
                return null;
            DataSet ds = new DataSet();
            Maticsoft.BLL.device_infor deviceser = new Maticsoft.BLL.device_infor();
            string isopen = "1";
            if (usermodel.usertype == "0")
            {
                ds = deviceser.GetList("areaid='" + usermodel.areaid + "' and isopen='" + isopen + "' and createtime>'" + dtnow + "'");
            }
            if (usermodel.usertype == "1")
            {
                ds = deviceser.GetList("fenbuid='" + usermodel.fenbuid + "' and isopen='" + isopen + "' and createtime>'" + dtnow + "'");
            }
            if (usermodel.usertype == "2")
            {
                ds = deviceser.GetList("ywbid='" + usermodel.ywbid + "' and isopen='" + isopen + "' and createtime>'" + dtnow + "'");
            }
            if (usermodel.usertype == "3")
            {
                ds = deviceser.GetList("");
            }
            int ncount = ds.Tables[0].Rows.Count;
            List<double> templist = new List<double>();
            List<string> deviceidlist = new List<string>();
            if (ncount > 0)
            {
                for (int i = 0; i < ncount; i++)
                {
                    if (ds.Tables[0].Rows[i]["todaytop"].ToString() != "" && ds.Tables[0].Rows[i]["todaytop"].ToString() != null)
                    {
                        templist.Add(double.Parse(ds.Tables[0].Rows[i]["todaytop"].ToString()));
                        deviceidlist.Add(ds.Tables[0].Rows[i]["deviceid"].ToString());
                    }
                }

            }

            int nindex = getMaxindex(templist);
            string id = deviceidlist[nindex];
            Maticsoft.Model.device_infor dddmodel = deviceser.GetModel(id);
            Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
            macmodel = macser.GetModel(dddmodel.machineid);
            DataTable dt = deviceser.GetList("deviceid='" + id + "'").Tables[0];
            dt.Columns.Add("machinecode", Type.GetType("System.String"));
            dt.Rows[0]["machinecode"] = macmodel.machinecode;
            publicAction.getShortName pa = new publicAction.getShortName();
            dt.Columns.Add("stationshortname1", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname2", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname3", Type.GetType("System.String"));
            dt.Rows[0]["stationshortname1"] = pa.getshortname(dt.Rows[0]["stationid"].ToString()).Split(',')[0];
            dt.Rows[0]["stationshortname2"] = pa.getshortname(dt.Rows[0]["stationid"].ToString()).Split(',')[1];
            dt.Rows[0]["stationshortname3"] = pa.getshortname(dt.Rows[0]["stationid"].ToString()).Split(',')[2];



            return dt;

        }
        public DataTable getHistoryImageByrecordid(string id)
        {
            Maticsoft.BLL.image_record_history historyser = new Maticsoft.BLL.image_record_history();
            return historyser.GetList("recordid='" + id + "'").Tables[0];
        }
        public int getMaxindex(List<double> list)
        {
            // TODO
            var GetMax = list.Max();
            var Indexof = list.IndexOf(GetMax);
            if (Indexof != -1)
            {
                return Indexof;
            }
            return 0;
            //double a = list[0];
            //double b = 140.0;
            //int index = 0;//把假设的最大值索引赋值非index
            //for (int i = 1; i < list.Count; i++)
            //{
            //    if (list[i] > a && list[i] < b)
            //    {
            //        a = list[i];
            //        index = i;//把较大值的索引赋值非index
            //    }
            //}
            //return Indexof;
        }

        public int getMaxindex1(List<double> list)
        {
            double a = list[0];
            int index = 0;//把假设的最大值索引赋值非index
            for (int i = 1; i < list.Count; i++)
            {
                if (list[i] > a)
                {
                    a = list[i];
                    index = i;//把较大值的索引赋值非index
                }
            }
            return index;
        }
        public void updateRoundTable(string areaname, string today)
        {
            Maticsoft.BLL.round_top_infor rs = new Maticsoft.BLL.round_top_infor();
            List<Maticsoft.Model.round_top_infor> rm = new List<Maticsoft.Model.round_top_infor>();
            rm = rs.GetModelList("");
            if (rm.Count() > 0)
            {
                bool ishave = false;
                string yestoday = "";
                string week = "";
                string month = "";
                string sid = "";
                string areaid = "";
                for (int i = 0; i < rm.Count(); i++)
                {
                    if (rm[i].areaname == areaname)
                    {
                        sid = rm[i].id;
                        yestoday = rm[i].yestodayTop;
                        week = rm[i].weekTop;
                        month = rm[i].monthTop;
                        areaid = rm[i].areaid;
                        ishave = true;
                    }
                }

                if (ishave)
                {
                    Maticsoft.Model.round_top_infor model = new Maticsoft.Model.round_top_infor();
                    model.id = sid;
                    model.areaid = areaid;
                    model.areaname = areaname;
                    model.todayTop = today;
                    if (double.Parse(today) >= double.Parse(yestoday))
                    {
                        model.yestodayTop = today;

                    }
                    else
                    {
                        model.yestodayTop = yestoday;
                    }
                    if (double.Parse(today) >= double.Parse(week))
                    {
                        model.weekTop = today;

                    }
                    else
                    {
                        model.weekTop = week;
                    }
                    if (double.Parse(today) >= double.Parse(month))
                    {
                        model.monthTop = today;

                    }
                    else
                    {
                        model.monthTop = month;
                    }
                    rs.Update(model);
                }
                else
                {
                    Maticsoft.Model.round_top_infor model = new Maticsoft.Model.round_top_infor();
                    model.id = Guid.NewGuid().ToString("N");
                    model.areaname = areaname;
                    model.areaid = areaid;
                    model.todayTop = today;
                    if (double.Parse(today) >= double.Parse(yestoday))
                    {
                        model.yestodayTop = today;

                    }
                    else
                    {
                        model.yestodayTop = yestoday;
                    }
                    if (double.Parse(today) >= double.Parse(week))
                    {
                        model.weekTop = today;

                    }
                    else
                    {
                        model.weekTop = week;
                    }
                    if (double.Parse(today) >= double.Parse(month))
                    {
                        model.monthTop = today;

                    }
                    else
                    {
                        model.monthTop = month;
                    }
                    rs.Add(model);
                }
            }

        }

        public string getAlarmPush(string userid, string newesttime)
        {
            if (userid == "")
            {
                DateTime time = new DateTime();
                DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                time = Convert.ToDateTime(newesttime, dtFormat);
                time = time.AddMilliseconds(0);
                Maticsoft.BLL.alarm_push_infor bllservice = new Maticsoft.BLL.alarm_push_infor();
                DataSet ds = new DataSet();
                string isread = "1";
                {
                    ds = bllservice.GetList("   isread='" + isread + "'");
                    string stime = "";
                    if (ds.Tables[0].Rows.Count > 0)
                        stime = ds.Tables[0].Rows[0]["createtime"].ToString();
                    else
                        stime = System.DateTime.Now.ToString();
                    DataTable dt = new DataTable("machinecount");
                    dt.Columns.Add("id", Type.GetType("System.String"));
                    dt.Columns.Add("deviceid", Type.GetType("System.String"));
                    dt.Columns.Add("devicename", Type.GetType("System.String"));
                    dt.Columns.Add("ywbname", Type.GetType("System.String"));
                    dt.Columns.Add("fenbuname", Type.GetType("System.String"));
                    dt.Columns.Add("stationname", Type.GetType("System.String"));
                    dt.Columns.Add("buildingname", Type.GetType("System.String"));

                    dt.Columns.Add("areaname", Type.GetType("System.String"));
                    dt.Columns.Add("machinename", Type.GetType("System.String"));
                    dt.Columns.Add("ysdname", Type.GetType("System.String"));
                    dt.Columns.Add("alarmvalue", Type.GetType("System.String"));
                    dt.Columns.Add("overvalue", Type.GetType("System.String"));
                    dt.Columns.Add("isok", Type.GetType("System.String"));
                    dt.Columns.Add("createtime", Type.GetType("System.String"));
                    dt.Columns.Add("isread", Type.GetType("System.String"));
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string sid = ds.Tables[0].Rows[i]["id"].ToString();
                        string deviceid = ds.Tables[0].Rows[i]["deviceid"].ToString();
                        string devicename = ds.Tables[0].Rows[i]["devicename"].ToString();
                        string ywbname = ds.Tables[0].Rows[i]["ywbname"].ToString();
                        string fenbuname = ds.Tables[0].Rows[i]["fenbuname"].ToString();
                        string stationname = ds.Tables[0].Rows[i]["stationname"].ToString();
                        string buildingname = ds.Tables[0].Rows[i]["buildingname"].ToString();
                        string areaname = ds.Tables[0].Rows[i]["areaname"].ToString();
                        string machinename = ds.Tables[0].Rows[i]["machinename"].ToString();
                        string ysdname = ds.Tables[0].Rows[i]["ysdname"].ToString();
                        string alarmvalue = ds.Tables[0].Rows[i]["alarmvalue"].ToString();
                        string overvalue = ds.Tables[0].Rows[i]["overvalue"].ToString();
                        string isok = ds.Tables[0].Rows[i]["isok"].ToString();
                        string createtime = ds.Tables[0].Rows[i]["createtime"].ToString();
                        string isread1 = ds.Tables[0].Rows[i]["isread"].ToString();
                        dt.Rows.Add(new object[] { sid, deviceid, devicename, ywbname, fenbuname, stationname, buildingname, areaname, machinename, ysdname, alarmvalue, overvalue, isok, createtime, isread1 });
                    }
                    alarmpushjson json = new alarmpushjson();
                    json.Newesttime = stime;
                    json.Dt = dt;
                    return Newtonsoft.Json.JsonConvert.SerializeObject(json);
                }
            }
            else
            {
                DateTime time = new DateTime();
                DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                time = Convert.ToDateTime(newesttime, dtFormat);
                time = time.AddMilliseconds(15);
                Maticsoft.BLL.alarm_push_infor bllservice = new Maticsoft.BLL.alarm_push_infor();
                DataSet ds = new DataSet();
                Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
                Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
                usermodel = user.GetModel(userid);
                string isread = "1";
                if (usermodel == null)
                    return "0";
                else
                {
                    if (usermodel.usertype == "0")
                    {
                        ds = bllservice.GetList("areaid='" + usermodel.areaid + "' and isread='" + isread + "' order by createtime desc");

                    }
                    if (usermodel.usertype == "1")
                    {
                        ds = bllservice.GetList("fenbuid='" + usermodel.fenbuid + "' and isread='" + isread + "'  order by createtime desc");

                    }
                    if (usermodel.usertype == "2")
                    {
                        ds = bllservice.GetList("ywbid='" + usermodel.ywbid + "' and isread='" + isread + "' order by createtime desc");

                    }
                    if (usermodel.usertype == "3")
                    {
                        ds = bllservice.GetList("   isread='" + isread + "' and createtime>'" + time + "'");

                    }
                    string stime = "";
                    if (ds.Tables[0].Rows.Count > 0)
                        stime = ds.Tables[0].Rows[0]["createtime"].ToString();
                    else
                        stime = System.DateTime.Now.ToString();
                    DataTable dt = new DataTable("machinecount");
                    dt.Columns.Add("id", Type.GetType("System.String"));
                    dt.Columns.Add("deviceid", Type.GetType("System.String"));
                    dt.Columns.Add("devicename", Type.GetType("System.String"));
                    dt.Columns.Add("ywbname", Type.GetType("System.String"));
                    dt.Columns.Add("fenbuname", Type.GetType("System.String"));
                    dt.Columns.Add("stationname", Type.GetType("System.String"));
                    dt.Columns.Add("buildingname", Type.GetType("System.String"));

                    dt.Columns.Add("areaname", Type.GetType("System.String"));
                    dt.Columns.Add("machinename", Type.GetType("System.String"));
                    dt.Columns.Add("ysdname", Type.GetType("System.String"));
                    dt.Columns.Add("alarmvalue", Type.GetType("System.String"));
                    dt.Columns.Add("overvalue", Type.GetType("System.String"));
                    dt.Columns.Add("isok", Type.GetType("System.String"));
                    dt.Columns.Add("createtime", Type.GetType("System.String"));
                    dt.Columns.Add("isread", Type.GetType("System.String"));
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string sid = ds.Tables[0].Rows[i]["id"].ToString();
                        string deviceid = ds.Tables[0].Rows[i]["deviceid"].ToString();
                        string devicename = ds.Tables[0].Rows[i]["devicename"].ToString();
                        string ywbname = ds.Tables[0].Rows[i]["ywbname"].ToString();
                        string fenbuname = ds.Tables[0].Rows[i]["fenbuname"].ToString();
                        string stationname = ds.Tables[0].Rows[i]["stationname"].ToString();
                        string buildingname = ds.Tables[0].Rows[i]["buildingname"].ToString();
                        string areaname = ds.Tables[0].Rows[i]["areaname"].ToString();
                        string machinename = ds.Tables[0].Rows[i]["machinename"].ToString();
                        string ysdname = ds.Tables[0].Rows[i]["ysdname"].ToString();
                        string alarmvalue = ds.Tables[0].Rows[i]["alarmvalue"].ToString();
                        string overvalue = ds.Tables[0].Rows[i]["overvalue"].ToString();
                        string isok = ds.Tables[0].Rows[i]["isok"].ToString();
                        string createtime = ds.Tables[0].Rows[i]["createtime"].ToString();
                        string isread1 = ds.Tables[0].Rows[i]["isread"].ToString();
                        dt.Rows.Add(new object[] { sid, deviceid, devicename, ywbname, fenbuname, stationname, buildingname, areaname, machinename, ysdname, alarmvalue, overvalue, isok, createtime, isread1 });

                    }
                    alarmpushjson json = new alarmpushjson();
                    json.Newesttime = stime;
                    json.Dt = dt;
                    return Newtonsoft.Json.JsonConvert.SerializeObject(json);
                }
            }


        }

        public string SetKonw(string alarmid)
        {
            Maticsoft.BLL.alarm_push_infor bllservice = new Maticsoft.BLL.alarm_push_infor();
            bllservice.Updateisread(alarmid);
            return "1";

        }
        public DataTable getAlarm(string userid)
        {
            string isalarm = "1";
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
            DateTime now = DateTime.Now;
            //获取当前月的第一天
            DateTime d1 = new DateTime(now.Year, now.Month, 1);
            //获取当前月的最后一天
            DateTime d2 = d1.AddMonths(1).AddDays(-1);
            if (um.usertype == "0")
            {
                // 没数据
                alarmlist = alarmservice.GetModelList("areaid='" + um.areaid + "' and createtime > '" + d1.ToString("yyyy-MM-dd") + "' and createtime < '" + d2.ToString("yyyy-MM-dd") + "'");
            }
            if (um.usertype == "1")
            {
                alarmlist = alarmservice.GetModelList("fenbuid='" + um.fenbuid + "' and createtime > '" + d1.ToString("yyyy-MM-dd") + "' and createtime < '" + d2.ToString("yyyy-MM-dd") + "'");
            }
            if (um.usertype == "2")
            {
                alarmlist = alarmservice.GetModelList("ywbid='" + um.ywbid + "' and createtime > '" + d1.ToString("yyyy-MM-dd") + "' and createtime < '" + d2.ToString("yyyy-MM-dd") + "'");
            }
            if (um.usertype == "3")
            {
                alarmlist = alarmservice.GetModelList(" createtime > '" + d1.ToString("yyyy-MM-dd") + "' and createtime < '" + d2.ToString("yyyy-MM-dd") + "'");
            }
            Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
            List<Maticsoft.Model.devicetype_infor> typelist = new List<Maticsoft.Model.devicetype_infor>();
            typelist = typeservice.GetModelList("");
            List<device_alarm_tongji> tongji = new List<device_alarm_tongji>();

            // 获取所有的类型设置为0
            for (int i = 0; i < typelist.Count; i++)
            {
                device_alarm_tongji tong = new device_alarm_tongji();
                tong.Devicetype = typelist[i].devicetype;
                tong.Alarmcount = 0;
                tongji.Add(tong);
            }
            for (int i = 0; i < alarmlist.Count; i++)
            {
                string deviceid = alarmlist[i].deviceid;
                Maticsoft.BLL.device_infor deviceser = new Maticsoft.BLL.device_infor();
                Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
                model = deviceser.GetModel(deviceid);
                if (model != null)
                {
                    string devicetype = model.ysdtype;
                    for (int k = 0; k < tongji.Count; k++)
                    {
                        if (tongji[k].Devicetype == devicetype)
                            tongji[k].Alarmcount += 1;
                    }
                }
            }
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("deviceType", Type.GetType("System.String"));
            dt.Columns.Add("count", Type.GetType("System.Int32"));

            for (int i = 0; i < tongji.Count; i++)
            {
                string sx = tongji[i].Devicetype;
                int sy = tongji[i].Alarmcount;
                dt.Rows.Add(new object[] { sx, sy });

            }
            dt.DefaultView.Sort = "count DESC";
            dt = dt.DefaultView.ToTable();
            DataTable dtNew = dt.Copy();  //复制dt表数据结构
            dtNew.Clear();  //清楚数据
            for (int i = 0; i < 4; i++)
            {

                dtNew.Rows.Add(dt.Rows[i].ItemArray);  //添加数据行
            }
            return dtNew;
        }
        public DataTable getAlarm1(string userid)//获取测温告警统计信息
        {
            string isalarm = "1";
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;
            List<Maticsoft.Model.device_infor> modellist1 = new List<Maticsoft.Model.device_infor>();
            Maticsoft.BLL.device_infor bllservice1 = new Maticsoft.BLL.device_infor();
            DataSet ds1 = new DataSet();
            string isopen = "1";
            if (um.usertype == "0")
            {
                ds1 = bllservice1.GetDeviceTongji("areaid='" + um.areaid + "' and isopen='" + isopen + "' and isalarm='" + isalarm + "'");
            }
            if (um.usertype == "1")
            {
                ds1 = bllservice1.GetDeviceTongji("fenbuid='" + um.fenbuid + "' and isopen='" + isopen + "' and isalarm='" + isalarm + "'");
            }
            if (um.usertype == "2")
            {
                ds1 = bllservice1.GetDeviceTongji("ywbid='" + um.ywbid + "' and isopen='" + isopen + "' and isalarm='" + isalarm + "'");
            }
            if (um.usertype == "3")
            {
                ds1 = bllservice1.GetDeviceTongji("isalarm='" + isalarm + "'");
            }
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("deviceType", Type.GetType("System.String"));
            dt.Columns.Add("count", Type.GetType("System.Int32"));
            Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
            List<Maticsoft.Model.devicetype_infor> typemodel = new List<Maticsoft.Model.devicetype_infor>();
            typemodel = typeservice.GetModelList("");
            for (int i = 0; i < typemodel.Count(); i++)
            {
                dt.Rows.Add(new object[] { typemodel[i].devicetype, 0 });
            }
            for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
            {
                string sy = ds1.Tables[0].Rows[i]["deviceType"].ToString();
                string sx = ds1.Tables[0].Rows[i]["devicecount"].ToString();
                if (int.Parse(ds1.Tables[0].Rows[i]["devicecount"].ToString()) > 0)
                {
                    dt.Rows.Add(new object[] { ds1.Tables[0].Rows[i]["deviceType"], int.Parse(ds1.Tables[0].Rows[i]["devicecount"].ToString()) });
                }

            }
            dt.DefaultView.Sort = "count DESC";
            dt = dt.DefaultView.ToTable();
            DataTable dtNew = dt.Copy();  //复制dt表数据结构
            dtNew.Clear();  //清楚数据
            for (int i = 0; i < 4; i++)
            {

                dtNew.Rows.Add(dt.Rows[i].ItemArray);  //添加数据行
            }
            return dtNew;



        }
        public DataTable getAlarmByTemouterSection(string userid)//获取测温告警统计信息
        {
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;

            List<Maticsoft.Model.alarm_push_infor> modellist = new List<Maticsoft.Model.alarm_push_infor>();
            Maticsoft.BLL.alarm_push_infor bllservice = new Maticsoft.BLL.alarm_push_infor();
            // 获取当前的 年--月 不使用当天减去已过去天数 存在Bug
            string GetMonth = DateTime.Now.ToString("yyyy-MM-dd");
            if (um.usertype == "0")
            {
                modellist = bllservice.GetModelList("areaid='" + um.areaid + "'  and createtime>'" + GetMonth + "' ");

            }
            if (um.usertype == "1")
            {
                modellist = bllservice.GetModelList("fenbuid='" + um.fenbuid + "'  and createtime>'" + GetMonth + "' ");

            }
            if (um.usertype == "2")
            {
                modellist = bllservice.GetModelList("ywbid='" + um.ywbid + "'  and createtime>'" + GetMonth + "' ");
            }
            if (um.usertype == "3")
            {

                modellist = bllservice.GetModelList(" createtime>'" + GetMonth + "' ");
            }
            int allcount = 0;
            int count1 = 0; int count2 = 0; int count3 = 0;
            try
            {
                for (int i = 0; i < modellist.Count(); i++)
                {
                    string ss = modellist[i].alarmvalue;
                    if (ss != "" && ss != null)
                    {
                        if (double.Parse(modellist[i].alarmvalue) >= 80 && double.Parse(modellist[i].alarmvalue) < 100)
                        {
                            count1 += 1;
                        }

                        if (double.Parse(modellist[i].alarmvalue) < 120 && double.Parse(modellist[i].alarmvalue) >= 100)
                        {
                            count2 += 1;
                        }

                        if (double.Parse(modellist[i].alarmvalue) >= 120)
                        {
                            count3 += 1;
                        }
                    }

                }
                allcount = count1 + count2 + count3;
                DataTable dt = new DataTable("machinecount");
                dt.Columns.Add("allcount", Type.GetType("System.String"));
                dt.Columns.Add("count_80100", Type.GetType("System.String"));
                dt.Columns.Add("count_100120", Type.GetType("System.String"));
                dt.Columns.Add("count_120", Type.GetType("System.String"));
                dt.Rows.Add(new object[] { allcount.ToString(), count1.ToString(), count2.ToString(), count3.ToString() });
                //select devicename,COUNT(devicename) from alarm_push_infor GROUP by devicename having count(devicename)>1 Order by devicename
                return dt;
            }
            catch
            {
                return null;
            }

        }

        public DataTable getRoundTop(string userid)//获取周期测温峰值统计
        {
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;
            List<Maticsoft.Model.image_record_history> modellist = new List<Maticsoft.Model.image_record_history>();
            Maticsoft.BLL.image_record_history bllservice = new Maticsoft.BLL.image_record_history();
            DataSet dstoday = new DataSet();
            DataSet dsyestoday = new DataSet();
            DataSet week = new DataSet();
            DataSet month = new DataSet();
            string tomorrow = System.DateTime.Now.AddDays(1).Date.ToString("yyyy-MM-dd");
            string todaytime = System.DateTime.Now.Date.ToString("yyyy-MM-dd");
            string yestodaytime = System.DateTime.Now.AddDays(-1).Date.ToString("yyyy-MM-dd");
            string weektime = System.DateTime.Now.AddDays(-5).Date.ToString("yyyy-MM-dd");
            string monthtime = System.DateTime.Now.AddDays(-10).Date.ToString("yyyy-MM-dd");
            //int valuemax = 80;
            if (um.usertype == "0")
            {
                dstoday = bllservice.GetListValuemax("areaid='" + um.areaid + "'    and createtime>'" + todaytime + "' AND createtime<'" + tomorrow + "'");
                dsyestoday = bllservice.GetListValuemax("areaid='" + um.areaid + "' and  createtime  > '" + yestodaytime + "' AND createtime<'" + todaytime + "'");
                week = bllservice.GetListValuemax("areaid='" + um.areaid + "'       and  createtime > '" + weektime + "' AND createtime<'" + todaytime + "'");
                month = bllservice.GetListValuemax("areaid='" + um.areaid + "'      and  createtime  > '" + monthtime + "' AND createtime<'" + todaytime + "'");
            }
            if (um.usertype == "1")
            {
                dstoday = bllservice.GetListValuemax("fenbuid='" + um.fenbuid + "'    and createtime>'" + todaytime + "' AND createtime<'" + tomorrow + "'");
                dsyestoday = bllservice.GetListValuemax("fenbuid='" + um.fenbuid + "' and  createtime  > '" + yestodaytime + "' AND createtime<'" + todaytime + "'");
                week = bllservice.GetListValuemax("fenbuid='" + um.fenbuid + "'       and  createtime > '" + weektime + "' AND createtime<'" + todaytime + "'");
                month = bllservice.GetListValuemax("fenbuid='" + um.fenbuid + "'      and  createtime  > '" + monthtime + "' AND createtime<'" + todaytime + "'");
            }
            if (um.usertype == "2")
            {
                dstoday = bllservice.GetListValuemax("ywbid='" + um.ywbid + "'    and createtime>'" + todaytime + "' AND createtime<'" + tomorrow + "'");
                dsyestoday = bllservice.GetListValuemax("ywbid='" + um.ywbid + "' and  createtime  > '" + yestodaytime + "' AND createtime<'" + todaytime + "'");
                week = bllservice.GetListValuemax("ywbid='" + um.ywbid + "'       and  createtime > '" + weektime + "' AND createtime<'" + todaytime + "'");
                month = bllservice.GetListValuemax("ywbid='" + um.ywbid + "'      and  createtime  > '" + monthtime + "' AND createtime<'" + todaytime + "'");
            }
            if (um.usertype == "3")
            {
                // 今天
                dstoday = bllservice.GetListValuemax("createtime > '" + todaytime + "' AND createtime<'" + tomorrow + "'");
                // 昨天
                dsyestoday = bllservice.GetListValuemax("createtime  > '" + yestodaytime + "' AND createtime<'" + todaytime + "'");
                // 7日
                week = bllservice.GetListValuemax("createtime > '" + weektime + "' AND createtime<'" + todaytime + "'");
                // 30天
                month = bllservice.GetListValuemax("createtime  > '" + monthtime + "' AND createtime<'" + todaytime + "'");
            }
            List<double> templist1 = new List<double>();
            List<string> idlist1 = new List<string>();
            for (int i = 0; i < dstoday.Tables[0].Rows.Count; i++)
            {
                templist1.Add(double.Parse(dstoday.Tables[0].Rows[i]["valuemax"].ToString()));
                idlist1.Add(dstoday.Tables[0].Rows[i]["recordid"].ToString());
            }
            int index1 = 0;
            string id1 = string.Empty;
            if (templist1.Count >= 1)
            {
                index1 = getMaxindex(templist1);

                id1 = idlist1[index1];
            }

            List<double> templist2 = new List<double>();
            List<string> idlist2 = new List<string>();
            for (int i = 0; i < dsyestoday.Tables[0].Rows.Count; i++)
            {
                templist2.Add(double.Parse(dsyestoday.Tables[0].Rows[i]["valuemax"].ToString()));
                idlist2.Add(dsyestoday.Tables[0].Rows[i]["recordid"].ToString());
            }
            int index2 = 0;
            string id2 = string.Empty;
            if (templist2.Count >= 1)
            {
                index2 = getMaxindex(templist2);
                id2 = idlist2[index2];
            }

            List<double> templist3 = new List<double>();
            List<string> idlist3 = new List<string>();
            for (int i = 0; i < week.Tables[0].Rows.Count; i++)
            {
                templist3.Add(double.Parse(week.Tables[0].Rows[i]["valuemax"].ToString()));
                idlist3.Add(week.Tables[0].Rows[i]["recordid"].ToString());
            }
            int index3 = 0;
            string id3 = string.Empty;
            if (templist3.Count >= 1)
            {
                index3 = getMaxindex(templist3);
                id3 = idlist3[index3];
            }


            List<double> templist4 = new List<double>();
            List<string> idlist4 = new List<string>();
            for (int i = 0; i < month.Tables[0].Rows.Count; i++)
            {
                templist4.Add(double.Parse(month.Tables[0].Rows[i]["valuemax"].ToString()));
                idlist4.Add(month.Tables[0].Rows[i]["recordid"].ToString());
            }
            int index4 = 0;
            string id4 = string.Empty;
            if (templist4.Count >= 1)
            {
                index4 = getMaxindex(templist4);
                id4 = idlist4[index4];
            }

            DataTable dtnew = new DataTable("keyDevice");
            dtnew.Columns.Add("id", Type.GetType("System.String"));
            dtnew.Columns.Add("areaid", Type.GetType("System.String"));
            dtnew.Columns.Add("areaname", Type.GetType("System.String"));
            dtnew.Columns.Add("fenbuid", Type.GetType("System.String"));
            dtnew.Columns.Add("fenbuname", Type.GetType("System.String"));
            dtnew.Columns.Add("ywbid", Type.GetType("System.String"));
            dtnew.Columns.Add("ywbname", Type.GetType("System.String"));
            dtnew.Columns.Add("stationid", Type.GetType("System.String"));
            dtnew.Columns.Add("stationname", Type.GetType("System.String"));
            dtnew.Columns.Add("todayTop", Type.GetType("System.String"));
            dtnew.Columns.Add("yestodayTop", Type.GetType("System.String"));
            dtnew.Columns.Add("monthTop", Type.GetType("System.String"));
            dtnew.Columns.Add("weekTop", Type.GetType("System.String"));
            dtnew.Columns.Add("deviceid_today", Type.GetType("System.String"));
            dtnew.Columns.Add("deviceid_yestoday", Type.GetType("System.String"));
            dtnew.Columns.Add("deviceid_month", Type.GetType("System.String"));
            dtnew.Columns.Add("deviceid_week", Type.GetType("System.String"));
            var tempList1 = templist1.Count >= 1 ? templist1.Max().ToString("0.0") : "0.0";
            var tempList2 = templist2.Count >= 1 ? templist2.Max().ToString("0.0") : "0.0";
            var tempList3 = templist3.Count >= 1 ? templist3.Max().ToString("0.0") : "0.0";
            var tempList4 = templist4.Count >= 1 ? templist4.Max().ToString("0.0") : "0.0";
            dtnew.Rows.Add(new object[] { "1010210", um.areaid, um.areaname, um.fenbuid, um.fenbuname, um.ywbid, um.ywbname, "", "", tempList1, tempList2, tempList4, tempList3, id1, id2, id4, id3 });
            return dtnew;
        }
        #region 老周期测温峰值统计
        public DataTable getRoundTop1(string userid)//获取周期测温峰值统计（此接口代码有问题，不再使用）
        {
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;
            List<double> today = new List<double>();
            List<string> deviceidtodaylist = new List<string>();
            List<string> deviceidyestodaylist = new List<string>();
            List<string> deviceidweektoplist = new List<string>();
            List<string> deviceidmonthmaxlist = new List<string>();
            List<double> yestoday = new List<double>();
            List<double> week = new List<double>();
            List<double> month = new List<double>();
            List<Maticsoft.Model.device_infor> modellist = new List<Maticsoft.Model.device_infor>();
            Maticsoft.BLL.device_infor bllservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
            if (um.usertype == "0")
            {
                modellist = bllservice.GetModelList("areaid='" + um.areaid + "'");

            }
            if (um.usertype == "1")
            {
                modellist = bllservice.GetModelList("fenbuid='" + um.fenbuid + "'");

            }
            if (um.usertype == "2")
            {
                modellist = bllservice.GetModelList("ywbid='" + um.ywbid + "'");
            }
            if (um.usertype == "3")
            {
                //string ad = "admin";
                modellist = bllservice.GetModelList("");
            }
            if (modellist.Count() > 0)
            {
                for (int i = 0; i < modellist.Count; i++)
                {
                    if (modellist[i].todaytop != "" && modellist[i].todaytop != null)
                    {
                        today.Add(double.Parse(modellist[i].todaytop));
                        deviceidtodaylist.Add(modellist[i].deviceid);
                    }
                    if (modellist[i].yestodaytop != "" && modellist[i].yestodaytop != null)
                    {
                        yestoday.Add(double.Parse(modellist[i].yestodaytop));
                        deviceidyestodaylist.Add(modellist[i].deviceid);
                    }
                    if (modellist[i].weektop != "" && modellist[i].weektop != null)
                    {
                        week.Add(double.Parse(modellist[i].weektop));
                        deviceidweektoplist.Add(modellist[i].deviceid);
                    }
                    if (modellist[i].monthmax != "" && modellist[i].monthmax != null)
                    {
                        month.Add(double.Parse(modellist[i].monthmax));
                        deviceidmonthmaxlist.Add(modellist[i].deviceid);
                    }
                }
            }
            int today_index = getMaxindex1(today);
            int yestoday_index = getMaxindex1(yestoday);
            int week_index = getMaxindex1(week);
            int month_index = getMaxindex1(month);

            DataTable dtnew = new DataTable("keyDevice");
            dtnew.Columns.Add("id", Type.GetType("System.String"));
            dtnew.Columns.Add("areaid", Type.GetType("System.String"));
            dtnew.Columns.Add("areaname", Type.GetType("System.String"));
            dtnew.Columns.Add("fenbuid", Type.GetType("System.String"));
            dtnew.Columns.Add("fenbuname", Type.GetType("System.String"));
            dtnew.Columns.Add("ywbid", Type.GetType("System.String"));
            dtnew.Columns.Add("ywbname", Type.GetType("System.String"));
            dtnew.Columns.Add("stationid", Type.GetType("System.String"));
            dtnew.Columns.Add("stationname", Type.GetType("System.String"));
            dtnew.Columns.Add("todayTop", Type.GetType("System.String"));
            dtnew.Columns.Add("yestodayTop", Type.GetType("System.String"));
            dtnew.Columns.Add("weekTop", Type.GetType("System.String"));
            dtnew.Columns.Add("monthTop", Type.GetType("System.String"));
            dtnew.Columns.Add("deviceid_today", Type.GetType("System.String"));
            dtnew.Columns.Add("deviceid_yestoday", Type.GetType("System.String"));
            dtnew.Columns.Add("deviceid_month", Type.GetType("System.String"));
            dtnew.Columns.Add("deviceid_week", Type.GetType("System.String"));
            Maticsoft.BLL.image_record_history hisservice = new Maticsoft.BLL.image_record_history();
            string sid0 = "";
            string sid1 = "";
            string sid2 = "";
            string sid3 = "";
            List<Maticsoft.Model.image_record_history> hismodellist0 = new List<Maticsoft.Model.image_record_history>();
            update_device_state action = new update_device_state();
            action.UpdateDevice(deviceidtodaylist[today_index]);
            hismodellist0 = hisservice.GetModelList("deviceid='" + deviceidtodaylist[today_index] + "' and valuemax='" + today.Max().ToString("0.0") + "'");
            if (hismodellist0.Count > 0)
                sid0 = hismodellist0[0].recordid;
            List<Maticsoft.Model.image_record_history> hismodellist1 = new List<Maticsoft.Model.image_record_history>();
            action.UpdateDevice(deviceidyestodaylist[yestoday_index]);

            hismodellist1 = hisservice.GetModelList("deviceid='" + deviceidyestodaylist[yestoday_index] + "' and valuemax='" + yestoday.Max().ToString("0.0") + "'");
            if (hismodellist1.Count > 0)
                sid1 = hismodellist1[0].recordid;
            List<Maticsoft.Model.image_record_history> hismodellist2 = new List<Maticsoft.Model.image_record_history>();
            action.UpdateDevice(deviceidweektoplist[week_index]);

            hismodellist2 = hisservice.GetModelList("deviceid='" + deviceidweektoplist[week_index] + "' and valuemax='" + week.Max().ToString("0.0") + "'");
            if (hismodellist2.Count > 0)
                sid2 = hismodellist2[0].recordid;
            List<Maticsoft.Model.image_record_history> hismodellist3 = new List<Maticsoft.Model.image_record_history>();
            action.UpdateDevice(deviceidmonthmaxlist[month_index]);

            hismodellist3 = hisservice.GetModelList("deviceid='" + deviceidmonthmaxlist[month_index] + "' and valuemax='" + month.Max().ToString("0.0") + "'");
            if (hismodellist3.Count > 0)
                sid3 = hismodellist3[0].recordid;
            dtnew.Rows.Add(new object[] { "1010210", um.areaid, um.areaname, um.fenbuid, um.fenbuname, um.ywbid, um.ywbname, "", "", today.Max().ToString("0.0"), yestoday.Max().ToString("0.0"), week.Max().ToString("0.0"), month.Max().ToString("0.0"), sid0, sid1, sid2, sid3 });
            return dtnew;

        }
        #endregion
        public DataTable getareaAnddevice(string userid)//地区和设备最高温对比 
        {
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;
            List<string> ywbidlist = new List<string>();
            DataSet ds = new DataSet();
            Maticsoft.BLL.ywb_infor ywbser = new Maticsoft.BLL.ywb_infor();
            if (um.usertype == "0")
            {
                ds = ywbser.GetList("areaid='" + um.areaid + "'");
                if (ds.Tables.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        ywbidlist.Add(ds.Tables[0].Rows[i]["ywbid"].ToString());
                    }
                }
            }
            if (um.usertype == "1")
            {
                ds = ywbser.GetList("fenbuid='" + um.fenbuid + "'");
                if (ds.Tables.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        ywbidlist.Add(ds.Tables[0].Rows[i]["ywbid"].ToString());
                    }
                }
            }
            if (um.usertype == "2")
            {
                ds = ywbser.GetList("ywbid='" + um.ywbid + "'");
                if (ds.Tables.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        ywbidlist.Add(ds.Tables[0].Rows[i]["ywbid"].ToString());
                    }
                }
            }
            if (um.usertype == "3")
            {
                ds = ywbser.GetList("");
                if (ds.Tables.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        ywbidlist.Add(ds.Tables[0].Rows[i]["ywbid"].ToString());
                    }
                }
            }

            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("ywbname", Type.GetType("System.String"));
            dt.Columns.Add("devicetopvalue", Type.GetType("System.String"));
            dt.Columns.Add("citytemputer", Type.GetType("System.String"));
            dt.Columns.Add("temprecordid", Type.GetType("System.String"));

            for (int i = 0; i < ywbidlist.Count(); i++)
            {
                Maticsoft.BLL.city_infor bllservice = new Maticsoft.BLL.city_infor();
                Maticsoft.Model.city_infor cimodel = new Maticsoft.Model.city_infor();
                cimodel = bllservice.GetModel(ywbidlist[i]);
                if (cimodel != null)
                {
                    dt.Rows.Add(new object[] { cimodel.ywbname, cimodel.devicetopvalue, cimodel.citytemputer, cimodel.temprecordid });
                }

            }

            UserAction us = new UserAction();
            us.updatestation(userid);
            return dt;
        }
        public DataTable getmachineNumbers(string userid)
        {
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;
            Maticsoft.BLL.machine_infor service = new Maticsoft.BLL.machine_infor();
            List<Maticsoft.Model.machine_infor> modellist = new List<Maticsoft.Model.machine_infor>();
            /////////////////////////////////////////抓拍设备总数//////////////////////////////////////////////////////////////
            if (um.usertype == "0")
            {
                modellist = service.GetModelList("areaid='" + um.areaid + "'");
            }
            if (um.usertype == "1")
            {
                modellist = service.GetModelList("fenbuid='" + um.fenbuid + "'");
            }
            if (um.usertype == "2")
            {
                modellist = service.GetModelList("ywbid='" + um.ywbid + "'");
            }
            if (um.usertype == "3")
            {
                modellist = service.GetModelList("");

            }
            int allcount = modellist.Count();//抓拍设备总数
            //////////////////////////////////////////抓拍设备在线总数/////////////////////////////////////////////////////////
            string isonline = "1";
            if (um.usertype == "0")
            {
                modellist = service.GetModelList("areaid='" + um.areaid + "' and isonline='" + isonline + "'");
            }
            if (um.usertype == "1")
            {
                modellist = service.GetModelList("fenbuid='" + um.fenbuid + "' and isonline='" + isonline + "'");
            }
            if (um.usertype == "2")
            {
                modellist = service.GetModelList("ywbid='" + um.ywbid + "' and isonline='" + isonline + "'");
            }
            if (um.usertype == "3")
            {
                modellist = service.GetModelList("isonline='" + isonline + "'");

            }
            int onlinecount = modellist.Count();
            int offlinecount = allcount - onlinecount;
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("allcount", Type.GetType("System.String"));
            dt.Columns.Add("onlinecount", Type.GetType("System.String"));
            dt.Columns.Add("offlinecount", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { allcount.ToString(), onlinecount.ToString(), offlinecount.ToString() });
            return dt;
        }

        public string setkeypointdevice(string deviceid, string stationid, string iskey)//设定或者取消该设备为重点监测设备 iskey=1表示重点监测，iskey=0表示非重点监测
        {
            Maticsoft.BLL.device_infor dservice = new Maticsoft.BLL.device_infor();
            dservice.UpdateKeyPoint(deviceid, stationid, iskey);
            return "设置成功";
            //一个站只能有一个重点监测设备，勾选某个设备为重点监测设备，其他设备的重点监测状态会被强制取消掉
        }
        public string setrounddevice(string deviceid, string isround)//设定或者取消该设备为实时监测设备 isround=1表示实时监测，isround=0表示非实时监测
        {
            Maticsoft.BLL.device_infor dservice = new Maticsoft.BLL.device_infor();
            dservice.UpdateRound(deviceid, isround);
            return "设置成功";
        }

        public string setopendevice(string deviceid, string isopen)
        {
            Maticsoft.BLL.device_infor dservice = new Maticsoft.BLL.device_infor();
            dservice.UpdateIsopen(deviceid, isopen);
            return "设置成功";
        }

        public string MensureAlarm(string userid, string stationid, string deviceidlist, string human, string time)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
                return "失败";
            string sql = "";
            if (usermodel.usertype == "3")
                sql = "1=1";
            if (usermodel.usertype == "0")
                sql = "areaid='" + usermodel.areaid + "' ";
            if (usermodel.usertype == "1")
                sql = "fenbuid='" + usermodel.fenbuid + "'";
            if (usermodel.usertype == "2")
                sql = "ywbid='" + usermodel.ywbid + "'";
            if (stationid != "")
            {
                sql = sql + " and  stationid='" + stationid + "'";
            }
            Maticsoft.BLL.alarm_push_infor dser = new Maticsoft.BLL.alarm_push_infor();
            if (deviceidlist == "all")
            {
                dser.Updatemenusre(sql, "all", human, time);
            }
            else
            {
                string[] idlist = deviceidlist.Split(',');
                for (int i = 0; i < idlist.Length; i++)
                    dser.Updatemenusre(idlist[i], "noall", human, time);
            }

            Maticsoft.BLL.station_infor staser = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stamodel = new List<Maticsoft.Model.station_infor>();
            stamodel = staser.GetModelList("");
            for (int i = 0; i < stamodel.Count(); i++)
            {
                updatestationAlarmcount(stamodel[i].stationid);
            }
            return "成功";

        }
        public void updatestationAlarmcount(string stationid)
        {
            string isok = "1";
            string alarmcount = "0";
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            DataSet ds = alarmservice.GetList("stationid='" + stationid + "' and isok='" + isok + "'");
            if (ds.Tables[0].Rows.Count > 0)
                alarmcount = ds.Tables[0].Rows.Count.ToString();

            Maticsoft.BLL.station_infor deservice = new Maticsoft.BLL.station_infor();
            deservice.UpdateAlarmcount(stationid, alarmcount);
        }
        public string DeleteAlarm(string idlist)
        {

            Maticsoft.BLL.alarm_push_infor dser = new Maticsoft.BLL.alarm_push_infor();
            string[] sidlist = idlist.Split(',');
            try
            {
                for (int i = 0; i < sidlist.Length; i++)
                {
                    Maticsoft.Model.alarm_push_infor alarmmodel = new Maticsoft.Model.alarm_push_infor();
                    alarmmodel = dser.GetModel(sidlist[i]);
                    if (alarmmodel == null)
                    {
                        //return "失败";
                        continue;
                    }
                    string deviceid = alarmmodel.deviceid;
                    string stationid = alarmmodel.stationid;
                    string alarmtime = alarmmodel.createtime.Value.ToString();
                    string alarmvalue = alarmmodel.alarmvalue;
                    dser.Delete(sidlist[i]);//删除告警记录
                    HttpHelperServer.CreateTxt("DeleteAlarm", "", "删除告警记录成功,被删除的设备Id为:" + sidlist[i]+"被删除的deviceId="+alarmmodel.deviceid);
                    //根据deviceid和alarmtime去删除历史记录
                    Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
                    List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();//存放查询到的数据            
                                                                                                                              //historylist = historyservice.GetModelList("deviceid='" + deviceid + "'and createtime='" + alarmtime + "' and valuemax = '" + alarmvalue + "'");
                    historylist = historyservice.GetModelList("deviceid='" + deviceid + "' and createtime='" + alarmtime + "'");
                    if (historylist.Count > 0)
                    {
                        for (int k = 0; k < historylist.Count; k++)
                        {
                            historyservice.Delete(historylist[k].recordid);//删除查到的对应告警的记录
                            HttpHelperServer.CreateTxt("DeleteAlarm", "", "删除历史图库记录成功,被删除的图片Id为:" + historylist[k].recordid);
                        }
                    }

                    //更新device_infor和station_infor
                    //update_device_state action = new update_device_state();只更新设备表数据
                    //action.UpdateDevice(deviceid);
                    updateDeviceAndStation(deviceid, stationid);

                    #region 注释代码
                    //Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
                    ////deviceservice.Update_every_value(alarmmodel.deviceid); 
                    //List<double> device_double = new List<double>(); device_double.Add(0);
                    //List<string> device_id = new List<string>(); device_id.Add("");
                    ////统计当前设备的最高温进行修改  
                    //string time = DateTime.Now.ToString("yyyy-MM-dd");
                    //List<Maticsoft.Model.image_record_history> historylist1 = new List<Maticsoft.Model.image_record_history>();
                    //historylist1 = historyservice.GetModelList("deviceid='" + deviceid + "'and createtime > '" + time + "'");
                    //if (historylist1.Count > 0)
                    //{
                    //    for (int j = 0; j < historylist1.Count; j++)
                    //    {
                    //        device_double.Add(double.Parse(historylist1[j].valuemax));
                    //        device_id.Add(historylist1[j].recordid);
                    //    }
                    //}
                    //string device_max_value = device_double.Max().ToString();
                    //string device_max_recordid = device_id[getMaxindex(device_double)];
                    //List<double> device_yestodaytop_double = new List<double>(); device_yestodaytop_double.Add(0);
                    //List<string> device_yestodayid = new List<string>(); device_yestodayid.Add("");
                    ////统计设备昨天的最高温并进行修改
                    //string yestodaytime = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
                    //List<Maticsoft.Model.image_record_history> historylist2 = new List<Maticsoft.Model.image_record_history>();
                    //historylist2 = historyservice.GetModelList("deviceid='" + deviceid + "'and createtime > '" + yestodaytime + "'and createtime < '" + time + "'");
                    //if (historylist2.Count > 0)
                    //{
                    //    for (int j = 0; j < historylist2.Count; j++)
                    //    {
                    //        device_yestodaytop_double.Add(double.Parse(historylist2[j].valuemax));
                    //        device_yestodayid.Add(historylist2[j].recordid);
                    //    }
                    //}
                    //string device_yestodaytop = device_yestodaytop_double.Max().ToString();
                    //string yestodaymaxid = device_yestodayid[getMaxindex(device_yestodaytop_double)];
                    //string device_histop = "";
                    //string device_histopid = "";
                    //if (device_yestodaytop_double.Max() >= device_double.Max())
                    //{
                    //    device_histop = device_yestodaytop;
                    //    device_histopid = yestodaymaxid;
                    //}
                    //else
                    //{
                    //    device_histop = device_max_value;
                    //    device_histopid = device_max_recordid;
                    //}
                    //Maticsoft.Model.device_infor deviceModel = deviceservice.GetModel(deviceid);
                    //if (deviceModel != null)
                    //{
                    //    deviceModel.todaymax = device_max_value;
                    //    deviceModel.todaytop = device_max_value;
                    //    deviceModel.todaymaxid = device_max_recordid;
                    //    deviceModel.yestodaytop = device_yestodaytop;
                    //    deviceModel.yestodaymaxid = yestodaymaxid;
                    //    deviceModel.weektop = device_histop;
                    //    deviceModel.weekmaxid = device_histopid;
                    //    deviceModel.monthtop = device_histop;
                    //    deviceModel.monthmax = device_histop;
                    //    deviceModel.monthmaxid = device_histopid;
                    //    deviceModel.historytop = device_histop;
                    //    deviceModel.historymaxid = device_histopid;
                    //    deviceservice.Update(deviceModel);
                    //}
                    ////更新当前变电站数据
                    //Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
                    //Maticsoft.Model.station_infor stamodel = new Maticsoft.Model.station_infor();
                    //stamodel = stationservice.GetModel(stationid);
                    //if (stamodel != null)
                    //{
                    //    string todaytopmax = "";
                    //    string todaytopmaxid = "";
                    //    string yestdaytopmax = "";
                    //    string yestdaytopmaxid = "";
                    //    List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
                    //    devicelist = deviceservice.GetModelList(" stationid='" + stationid + "'");
                    //    List<double> station_todaytop = new List<double>(); station_todaytop.Add(0);
                    //    List<string> station_id = new List<string>(); station_id.Add("");
                    //    List<double> station_yestodaytop_double = new List<double>(); station_yestodaytop_double.Add(0);
                    //    List<string> station_yestodayid = new List<string>(); station_yestodayid.Add("");
                    //    if (devicelist.Count > 0)
                    //    {
                    //        for (int k = 0; k < devicelist.Count; k++)
                    //        {
                    //            station_todaytop.Add(double.Parse(devicelist[k].todaytop));
                    //            station_id.Add(devicelist[k].todaymaxid);
                    //            if (devicelist[k].yestodaytop != null && devicelist[k].yestodaytop!= "")
                    //            {
                    //                station_yestodaytop_double.Add(double.Parse(devicelist[k].yestodaytop));
                    //                station_yestodayid.Add(devicelist[k].yestodaymaxid);
                    //            }
                    //        }
                    //    }
                    //    if (station_todaytop.Count > 0)
                    //    {
                    //        todaytopmax = station_todaytop.Max().ToString();
                    //        todaytopmaxid = station_id[getMaxindex(station_todaytop)];
                    //        yestdaytopmax = station_yestodaytop_double.Max().ToString();
                    //        yestdaytopmaxid = station_yestodayid[getMaxindex(station_yestodaytop_double)];
                    //    }
                    //    string stationMax = "";
                    //    string stationMaxid = "";
                    //    if (station_todaytop.Max() >= station_yestodaytop_double.Max())
                    //    {
                    //        stationMax = todaytopmax;
                    //        stationMaxid = todaytopmaxid;
                    //    }
                    //    else
                    //    {
                    //        stationMax = yestdaytopmax;
                    //        stationMaxid = yestdaytopmaxid;
                    //    }
                    //    if (todaytopmax != "")
                    //    {
                    //        stamodel.todaytop = todaytopmax;                      
                    //        stamodel.todayid = todaytopmaxid;
                    //        stamodel.yestodaytop = yestdaytopmax;
                    //        stamodel.yestodayid = yestdaytopmaxid;
                    //        stamodel.weektop = stationMax;
                    //        stamodel.weekid = stationMaxid;
                    //        stamodel.monthtop = stationMax;
                    //        stamodel.monthid = stationMaxid;
                    //        stamodel.historytop = stationMax;
                    //        stamodel.historyid = stationMaxid;
                    //        //devicelist = deviceservice.GetModelList(" stationid='" + stationid + "' and todaytop='" + todaytopmax + "'");
                    //        //if (devicelist.Count > 0)
                    //        //{
                    //        //    List<Maticsoft.Model.image_record_history> hismodellist = new List<Maticsoft.Model.image_record_history>();
                    //        //    hismodellist = historyservice.GetModelList("deviceid = '" + devicelist[0].deviceid + "' and valuemax = '" + todaytopmax + "' order by createtime desc ");
                    //        //    if (hismodellist.Count > 0)
                    //        //    {
                    //        //        stamodel.todayid = hismodellist[0].recordid;
                    //        //    }
                    //        //}
                    //    }
                    //    stationservice.Update(stamodel);
                    //    updatestationAlarmcount(stationid);
                    //}    
                    #endregion
                }
            }
            catch (Exception e)
            {

                HttpHelperServer.CreateTxt("DeleteAlarm", "", "当前方法执行出错"+e.Message.ToString());
            }
        
            //Maticsoft.BLL.station_infor staser = new Maticsoft.BLL.station_infor();
            //List<Maticsoft.Model.station_infor> stamodel = new List<Maticsoft.Model.station_infor>();
            //stamodel = staser.GetModelList("");
            //for (int i = 0; i < stamodel.Count(); i++)
            //{
            //    updatestationAlarmcount(stamodel[i].stationid);
            //}
            return "成功";

        }

        public string X_getImageListBystation(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string machineid, string isalarm,string StartTime,string EndTime)
        {
            string SetStartTime = string.Empty;
            string SetEndTime = string.Empty;
            if (string.IsNullOrEmpty(StartTime)||string.IsNullOrEmpty(EndTime))
            {
                // 本月的开始时间
                SetStartTime=DateTime.Now.Year + "-01-01 ";
                SetEndTime = DateTime.Now.ToString("yyyy-MM-dd");
            }
            else
            {
                SetStartTime = StartTime;
                SetEndTime = EndTime;
            }

            string SqlWhere = " And CreateTime >='" + SetStartTime +  "' And CreateTime <='" + SetEndTime + "' ";


            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel.usertype == "0")
            {
                {
                    areaid = usermodel.areaid;
                }
            }
            if (usermodel.usertype == "1")
            {
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                {
                    ywbid = usermodel.ywbid;
                }
            }
            if (usermodel.usertype == "3")
            {
                //areaid = "40098b7fd8af43b88cd5db37611d3539";
            }
            string ysdsql = "";
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部" && areaid != null)
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部" && fenbuid != null)
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部" && ywbid != null)
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部" && stationid != null)
                sqllist.Add("stationid='" + stationid + "'");
            if (buildingid != "" && buildingid != "全部" && buildingid != null)
                sqllist.Add("buildingid='" + buildingid + "'");
            if (devicetype != "" && devicetype != "全部" && devicetype != null)
                ysdsql = ("ysdtype='" + devicetype + "'");
            if (machineid != "" && machineid != "全部" && machineid != null)
                sqllist.Add("machineid='" + machineid + "'");

            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql = "1=1 ";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1] + "";
            }

            Maticsoft.BLL.machine_infor machineser = new Maticsoft.BLL.machine_infor();

            List<Maticsoft.Model.machine_infor> machinelistmodel = machineser.GetModelList(sql + " ORDER BY installcode ASC");

            Maticsoft.BLL.device_infor mcservice = new Maticsoft.BLL.device_infor();

            DataSet ds = mcservice.GetList(sql);
            jsonjson json1 = new jsonjson();

            if (machinelistmodel.Count > 0)
            {

                Maticsoft.Model.machine_infor m1 = machinelistmodel[0];


                string areaname = Convert.ToString(m1.areaname);
                string fenbuname = Convert.ToString(m1.fenbuname);
                string ywbname = Convert.ToString(m1.ywbname);
                string stationname = Convert.ToString(m1.stationname);
                string custid = Convert.ToString(m1.stationid);

                List<string> buildinglist = new List<string>();
                List<string> buildingidlist = new List<string>();
                List<string> stationnamelist = new List<string>();
                List<string> stationidlist = new List<string>();
                UserServices.UserAction action1 = new UserServices.UserAction();
                DataTable dbuilding = action1.getbuildingBystation(custid);

                // 这里要加判断！！！by King-1025
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable stationDt = action1.getstationByywb(ds.Tables[0].Rows[0]["ywbid"].ToString());

                    for (int j = 0; j < stationDt.Rows.Count; j++)
                    {
                        stationnamelist.Add(stationDt.Rows[j]["stationname"].ToString());
                        stationidlist.Add(stationDt.Rows[j]["stationid"].ToString());
                    }
                }

                for (int j = 0; j < dbuilding.Rows.Count; j++)
                {
                    buildinglist.Add(dbuilding.Rows[j]["buildingname"].ToString());
                    buildingidlist.Add(dbuilding.Rows[j]["buildingid"].ToString());
                }
                List<string> machinelist = new List<string>();

                for (int j = 0; j < machinelistmodel.Count(); j++)
                {
                    machinelist.Add(machinelistmodel[j].machinename);
                }
                List<string> devicelist = new List<string>();
                DataTable ddevice = action1.getdeviceBystation(custid);
                for (int j = 0; j < ddevice.Rows.Count; j++)
                {
                    devicelist.Add(ddevice.Rows[j]["devicename"].ToString());
                }
                json1.Areaname = areaname;
                json1.Fenbuname = fenbuname;
                json1.Ywbname = ywbname;
                json1.Stationname = stationname;
                json1.Stationnamelist = stationnamelist;
                json1.Stationidlidt = stationidlist;
                json1.Buildinglist = buildinglist;
                json1.Buildingidlist = buildingidlist;
                json1.Machinelist = machinelist;
                json1.Devicelist = devicelist;
                List<stationImagejson> jsonlist = new List<stationImagejson>();
                for (int i = 0; i < machinelistmodel.Count(); i++)
                {
                    string machineid1 = machinelistmodel[i].machineid;
                    string machinename = machinelistmodel[i].machinename;
                    Maticsoft.BLL.device_infor deservice = new Maticsoft.BLL.device_infor();
                    DataTable dt = new DataTable();
                    string isopen = "1";
                    //and isopen = '" + isopen + "'
                    if (ysdsql == "")
                        dt = deservice.GetList("machineid='" + machineid1+ "'"+ SqlWhere +"ORDER BY CAST(ysdname as SIGNED)").Tables[0];
                    else
                        dt = deservice.GetList("machineid='" + machineid1 + "'"+ SqlWhere +" and ysdtype='" + devicetype + "'  ORDER BY CAST(ysdname as SIGNED)").Tables[0];
                    //DataView dv = dt.DefaultView;
                    //dv.Sort = "ysdname ASC";
                    //dt = dv.ToTable();

                    stationImagejson json = new stationImagejson();
                    json.Machineid = machineid1;
                    json.Machinename = machinename;
                    json.Buildingname = machinelistmodel[i].buildingname;
                    json.Stationname = machinelistmodel[i].stationname;
                    json.Imagedt = dt;
                    if (dt.Rows.Count>0)
                    {
                        jsonlist.Add(json);
                    }
                }
                json1.Json = jsonlist;
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(json1);

        }
        public string getmachineidbyname(string stationid, string machinename)
        {
            string sreturn = "";

            List<Maticsoft.Model.machine_infor> list = new List<Maticsoft.Model.machine_infor>();
            Maticsoft.BLL.machine_infor bll = new Maticsoft.BLL.machine_infor();
            list = bll.GetModelList("stationid='" + stationid + "' and machinename='" + machinename + "'");
            if (list.Count() > 0)
            {
                sreturn = list[0].machineid;
            }
            else
                sreturn = "";
            return sreturn;
        }

        public DataTable Y_getHistoryImage(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string machineid, string devicetype, string deviceid, string isok)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel.usertype == "0")
            {
                if (areaid == "" || areaid == null)
                {
                    areaid = usermodel.areaid;
                }
            }
            if (usermodel.usertype == "1")
            {
                if (fenbuid == "" || fenbuid == null)
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                if (ywbid == "" || ywbid == null)
                {
                    ywbid = usermodel.ywbid;
                }
            }
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部")
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部")
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部")
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部")
                sqllist.Add("stationid='" + stationid + "'");
            if (buildingid != "" && buildingid != "全部")
                sqllist.Add("buildingid='" + buildingid + "'");
            if (devicetype != "" && devicetype != "全部")
                sqllist.Add("ysdtype='" + devicetype + "'");
            if (machineid != "" && machineid != "全部")
                sqllist.Add("machineid='" + machineid + "'");
            if (deviceid != "" && deviceid != "全部")
                sqllist.Add("deviceid='" + deviceid + "'");
            if (isok != "" && isok != "全部")
                sqllist.Add("isok='" + isok + "'");
            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql = "";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1];
            }
            return null;
        }

        public DataTable Y_getDeviceHistoryImage(string deviceid)
        {
            Maticsoft.BLL.image_record_history sss = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> sssmodel = new List<Maticsoft.Model.image_record_history>();
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("deviceid", Type.GetType("System.String"));
            dt.Columns.Add("devicename", Type.GetType("System.String"));
            dt.Columns.Add("machineid", Type.GetType("System.String"));
            dt.Columns.Add("machinename", Type.GetType("System.String"));
            dt.Columns.Add("image_red", Type.GetType("System.String"));
            dt.Columns.Add("image_high", Type.GetType("System.String"));
            dt.Columns.Add("image_mix", Type.GetType("System.String"));
            dt.Columns.Add("temputer", Type.GetType("System.String"));
            dt.Columns.Add("createtime", Type.GetType("System.String"));

            Maticsoft.BLL.device_infor sdevice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor modevice = new Maticsoft.Model.device_infor();
            modevice = sdevice.GetModel(deviceid);
            if (modevice != null)
            {
                string devicename = modevice.devicename;
                string machineid = modevice.machineid;
                string machinename = modevice.machinename;

                sssmodel = sss.GetModelList("deviceid='" + deviceid + "'");
                if (sssmodel.Count() > 0)
                {
                    for (int i = 0; i < sssmodel.Count(); i++)
                    {
                        string image_red = sssmodel[i].image0;
                        string image_high = sssmodel[i].image1; ;
                        string image_mix = sssmodel[i].image2; ;
                        string stime = sssmodel[i].createtime.Value.ToString();
                        string stem = sssmodel[i].valuemax;
                        //DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                        //dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                        //DateTime time =  Convert.ToDateTime(stime, dtFormat);
                        dt.Rows.Add(new object[] { deviceid, devicename, machineid, machinename, image_red, image_high, image_mix, stem, stime });
                    }
                }
            }


            return dt;
        }
        public DataTable Y_getDeviceHistoryAlarm(string deviceid)
        {
            Maticsoft.BLL.alarm_push_infor ss = new Maticsoft.BLL.alarm_push_infor();
            return ss.GetList("deviceid='" + deviceid + "' order by createtime desc").Tables[0];
        }

        public DataTable Y_getabnormalDevice(string userid)
        {
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;
            List<string> deviceidlist = new List<string>();
            Maticsoft.BLL.alarm_push_infor service = new Maticsoft.BLL.alarm_push_infor();
            List<Maticsoft.Model.alarm_push_infor> modellist = new List<Maticsoft.Model.alarm_push_infor>();
            DataSet ds = new DataSet();
            if (um.usertype == "0")
            {
                ds = service.GetList("areaid='" + um.areaid + "' and createtime>'" + System.DateTime.Now.AddDays(-30) + "' order by createtime desc  LIMIT 0,10 ");

            }
            if (um.usertype == "1")
            {
                ds = service.GetList("fenbuid='" + um.fenbuid + "' and createtime>'" + System.DateTime.Now.AddDays(-30) + "' order by createtime desc  LIMIT 0,10 ");

            }
            if (um.usertype == "2")
            {
                ds = service.GetList("ywbid='" + um.ywbid + "' and createtime>'" + System.DateTime.Now.AddDays(-30) + "' order by createtime desc  LIMIT 0,10 ");

            }
            if (um.usertype == "3")
            {
                ds = service.GetList("createtime>'" + System.DateTime.Now.AddDays(-30) + "' order by createtime desc  LIMIT 0,10 ");

            }


            return ds.Tables[0];
        }

        public string Y_getAlarmDeviceByStation(string stationid)
        {

            List<string> deviceidlist = new List<string>();
            Maticsoft.BLL.device_infor service = new Maticsoft.BLL.device_infor();
            string isopen = "1";
            List<Maticsoft.Model.device_infor> modellist = new List<Maticsoft.Model.device_infor>();
            modellist = service.GetModelList("stationid='" + stationid + "'  and isopen='" + isopen + "' ");
            for (int i = 0; i < modellist.Count(); i++)
            {
                deviceidlist.Add(modellist[i].deviceid);
            }

            List<DataTable> dtlist = new List<DataTable>();
            for (int i = 0; i < deviceidlist.Count(); i++)
            {
                DataTable testd = Y_getDeviceHistoryAlarm(deviceidlist[i]);
                if (Y_getDeviceHistoryAlarm(deviceidlist[i]).Rows.Count > 0)
                {
                    dtlist.Add(Y_getDeviceHistoryAlarm(deviceidlist[i]));

                }
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(dtlist);
        }
        public string Y_getAlarmDeviceByStationAndYsd(string userid, string stationid, string deviceid, string page, string limit)
        {
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;
            int count = (int.Parse(limit));
            int npage = (int.Parse(page) - 1) * int.Parse(limit);
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("id", Type.GetType("System.String"));
            dt.Columns.Add("areaid", Type.GetType("System.String"));
            dt.Columns.Add("areaname", Type.GetType("System.String"));
            dt.Columns.Add("fenbuid", Type.GetType("System.String"));
            dt.Columns.Add("fenbuname", Type.GetType("System.String"));
            dt.Columns.Add("ywbid", Type.GetType("System.String"));
            dt.Columns.Add("ywbname", Type.GetType("System.String"));
            dt.Columns.Add("stationid", Type.GetType("System.String"));
            dt.Columns.Add("stationname", Type.GetType("System.String"));
            dt.Columns.Add("deviceid", Type.GetType("System.String"));
            dt.Columns.Add("devicename", Type.GetType("System.String"));
            dt.Columns.Add("machineid", Type.GetType("System.String"));
            dt.Columns.Add("machinename", Type.GetType("System.String"));
            dt.Columns.Add("machinecode", Type.GetType("System.String"));
            dt.Columns.Add("image_url", Type.GetType("System.String"));
            dt.Columns.Add("alarmvalue", Type.GetType("System.String"));
            dt.Columns.Add("createtime", Type.GetType("System.String"));
            dt.Columns.Add("isok", Type.GetType("System.String"));
            dt.Columns.Add("overvalue", Type.GetType("System.String"));
            dt.Columns.Add("ysdtype", Type.GetType("System.String"));
            dt.Columns.Add("ysdname", Type.GetType("System.String"));
            dt.Columns.Add("ysdid", Type.GetType("System.String"));
            dt.Columns.Add("buildingname", Type.GetType("System.String"));
            dt.Columns.Add("buildingid", Type.GetType("System.String"));
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            int alarm_count = 0;
            DataTable testd = null;
            if (stationid == "" && deviceid == "")
            {
                if (um.usertype == "0")
                {
                    testd = alarmservice.GetList("areaid='" + um.areaid + "'order by createtime desc LIMIT " + npage + "," + count).Tables[0];
                    alarm_count = alarmservice.GetListCount("areaid='" + um.areaid + "'");

                }
                if (um.usertype == "1")
                {
                    testd = alarmservice.GetList("fenbuid='" + um.fenbuid + "' order by createtime desc LIMIT " + npage + "," + count).Tables[0];
                    alarm_count = alarmservice.GetListCount("fenbuid='" + um.fenbuid + "'");

                }
                if (um.usertype == "2")
                {
                    testd = alarmservice.GetList("ywbid='" + um.ywbid + "'  order by createtime desc LIMIT " + npage + "," + count).Tables[0];
                    alarm_count = alarmservice.GetListCount("ywbid='" + um.ywbid + "'");

                }
                if (um.usertype == "3")
                {
                    testd = alarmservice.GetList("1=1 order by createtime desc LIMIT " + npage + "," + count).Tables[0];
                    alarm_count = alarmservice.GetListCount("1=1 ");

                }
            }
            else
            {
                if (deviceid == "")
                {
                    testd = alarmservice.GetList("stationid='" + stationid + "'  order by createtime desc  LIMIT " + npage + "," + count).Tables[0];
                    alarm_count = alarmservice.GetListCount("stationid='" + stationid + "'");
                }
                else
                {
                    testd = alarmservice.GetList("deviceid='" + deviceid + "'  order by createtime desc LIMIT " + npage + "," + count).Tables[0];
                    alarm_count = alarmservice.GetListCount("deviceid='" + deviceid + "'");

                }
            }

            if (testd.Rows.Count > 0)
            {
                string stime = "";
                string stem = "";
                string machinecode = "";
                for (int k = 0; k < testd.Rows.Count; k++)
                {
                    string image_red = testd.Rows[k]["image_url"].ToString();
                    stime = testd.Rows[k]["createtime"].ToString();
                    stem = testd.Rows[k]["alarmvalue"].ToString();
                    machinecode = getmachinecode(testd.Rows[k]["deviceid"].ToString());
                    //DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                    //dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                    //DateTime time = Convert.ToDateTime(stime, dtFormat);
                    dt.Rows.Add(new object[] { testd.Rows[k]["id"].ToString(), testd.Rows[k]["areaid"].ToString(), testd.Rows[k]["areaname"].ToString(), testd.Rows[k]["fenbuid"].ToString(), testd.Rows[k]["fenbuname"].ToString(), testd.Rows[k]["ywbid"].ToString(), testd.Rows[k]["ywbname"].ToString(), testd.Rows[k]["stationid"].ToString(), testd.Rows[k]["stationname"].ToString(), testd.Rows[k]["deviceid"].ToString(), testd.Rows[k]["devicename"].ToString(), testd.Rows[k]["machineid"].ToString(), testd.Rows[k]["machinename"].ToString(), machinecode, image_red, stem, stime, testd.Rows[k]["isok"].ToString(), testd.Rows[k]["overvalue"].ToString(), testd.Rows[k]["ysdtype"].ToString(), testd.Rows[k]["ysdname"].ToString(), testd.Rows[k]["ysdid"].ToString(), testd.Rows[k]["buildingname"].ToString(), testd.Rows[k]["buildingid"].ToString() });
                }
            }


            //DataTable table = new DataTable();
            //table = dt.Clone();
            //if (dt.Rows.Count > 0)
            //{
            //    for (int i = 0; i < count; i++)
            //    {
            //        if (i < dt.Rows.Count)
            //            table.Rows.Add(dt.Rows[i].ItemArray);
            //    }
            //}
            devicelistjson json1 = new devicelistjson();
            // json1.Recordcount = dt.Rows.Count.ToString();
            json1.Recordcount = alarm_count.ToString();
            json1.Recorddt = dt;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json1);

        }
        public string getmachinecode(string deviceid)
        {
            Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
            Maticsoft.BLL.device_infor devser = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devmodel = new Maticsoft.Model.device_infor();
            Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
            string machinecode = "";
            devmodel = devser.GetModel(deviceid);
            if (devmodel != null)
            {
                macmodel = macser.GetModel(devmodel.machineid);
                if (macmodel != null)
                {
                    machinecode = macmodel.machinecode;
                }
            }
            return machinecode;
        }


        /// <summary>
        /// 一周设备统计查看
        /// </summary>
        /// <param name="userid">userid</param>
        /// <param name="max">最大值</param>
        /// <param name="min">最小值</param>
        /// <param name="month">7/30</param>
        /// <returns></returns>
        public jsonjson temperatureWeekCount(string userid, string max, string min,string month)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
                return null;
            Maticsoft.BLL.image_record_history imageservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();
            //当前月份 
            string nowmonth = System.DateTime.Now.Month.ToString("yyyyMM");// 2020-12，2020-07

            // 重写

            // 当前时间
            var DateTimeMonth = DateTime.Now;
            //当前的时间是Month天
            var SetMonth = Convert.ToInt32(month);
            // 当前时间减去Month天
            var LastMonth = DateTime.Now.AddDays(-SetMonth);
            List<weekCountjson> weekjson = new List<weekCountjson>();
            string MonthDayWhere = string.Empty;
            string ResultWhere = string.Empty;
            string SqlWhere = string.Empty;
            string StorageResult = string.Empty;
            List<string> AddMaxAndMin = new List<string>();
            weekCountjson WeekJson = new weekCountjson();
            //本月数据
            List<Maticsoft.Model.image_record_history> ModelThisMonth = new List<Maticsoft.Model.image_record_history>();
            // 跨表数据
            List<Maticsoft.Model.image_record_history> ModelLastMonth = new List<Maticsoft.Model.image_record_history>();
            string OrderBy = " group by devicename";
            if (max != "")
            {
                SqlWhere += " and valuemax < " + max;
            }
            if (min != "")
            {
                if (min=="120")
                {
                    SqlWhere = string.Empty;
                    SqlWhere += " and valuemax >= " + min;
                }
                else
                {
                    SqlWhere += " and valuemax >= " + min;
                }
               

            }

            if (usermodel.usertype == "0")
            {

                ResultWhere = " areaid='" + usermodel.areaid + "'";
            }
            else if (usermodel.usertype == "1")
            {
                ResultWhere = " fenbuid='" + usermodel.fenbuid + "' ";
            }
            else if (usermodel.usertype == "2")
            {

                ResultWhere = " ywbid='" + usermodel.ywbid + "' ";
            }
            else if (usermodel.usertype == "3")
            {
                ResultWhere = " 1=1 ";
            }

            // 判断是否加载全部
            if (string.IsNullOrEmpty(min)&&string.IsNullOrEmpty(max))
            {
                AddMaxAndMin = new List<string>()
                {
                     "80", 
                    "100", 

                    "100", 
                    "120", 

                    "120", 
                    "120",// 为了凑数 5

                };
            }else if(string.IsNullOrEmpty(max)&&min=="120")// 120度以上
            {
                if (min=="120")
                {
                    AddMaxAndMin = new List<string>()
                    {
                        min,
                        min,
                    };
                }
            }
            else
            {
                AddMaxAndMin = new List<string>()
                    {
                        min,
                        max,
                    };
            }

            StorageResult = ResultWhere;
            //for循环进行遍历 遍历三次 4
            for (int i = 0; i < AddMaxAndMin.Count; i++)
            {
                // 获取i和i+1 i =min ,max=i+1;  0 1 2
                int Min = i;
                int Max = i+1;
                if (i==0)
                {
                   
                   Min = i;  // 0   2  4  6 
                    
                    Max = i + 1; // 1  3  5  7
                }
                else
                {
                    Min = i + 1; 
                    Max = i + 2;
                }
                if (Max%2==0)
                {
                    continue;
                }

                SqlWhere = string.Empty;
                //当前表示120以上
                if (AddMaxAndMin[Min] == "120" && AddMaxAndMin[Max] == "120")
                {
                    SqlWhere += " and valuemax >= " + AddMaxAndMin[Min].ToString();
                }
                else
                {
                    SqlWhere += " and valuemax < " + AddMaxAndMin[Max].ToString();
                    SqlWhere += " and valuemax >= " + AddMaxAndMin[Min].ToString();
                }
                // 当前的月份
                int Month = DateTime.Now.Month;
                // 当前数据存在于同一张表
                if (Month == LastMonth.Month)
                {
                    MonthDayWhere = LastMonth.ToString("yyyy-MM-dd");
                    string MonthTimeWhere = " And createtime>" + "'" + MonthDayWhere + "'"+ " And createtime<"+ "'"+ DateTimeMonth.ToString("yyyy-MM-dd")+"'";
                    // 存在于同一张表   1=1  And createtime>'2020-12-03'  and valuemax < 120 and valuemax >= 100  group by devicename
                    ModelThisMonth = imageservice.GetModelList(ResultWhere + MonthTimeWhere + SqlWhere + OrderBy);
                } //不存在于同一张表
                else if (Month != LastMonth.Month)
                {
                    // 获取需要取出来几天的数据 绝对值 
                    int Abs = DateTime.Now.Day - SetMonth;
                    //获取上个月的最后一天
                    var MonthDay = DateTimeMonth.AddDays(1 - DateTimeMonth.Day).AddDays(-1);
                    // 最后一天减去多出来的值
                    MonthDay = MonthDay.AddDays(Abs);

                    MonthDayWhere = MonthDay.ToString("yyyy-MM-dd");

                    string MonTimeWhere = " And createtime>" + "'" + MonthDayWhere + "' ";
                    //获取到上个月的开始时间MonthDay ~当前的时间 nowmonth
                    //开始查询表 image_record_history
                    //上个月使用的表  image_record_history+DataTime.Now.ToString("yyyyMM");
                    string LastTableName = MonthDay.ToString("yyyyMM");
                    // 查询上个月的数据
                    ModelLastMonth = imageservice.HisGetModelList(LastTableName, StorageResult + MonTimeWhere + SqlWhere + OrderBy);
                    // 再次获取本月的值
                    string  ThisMonthDayWhere = DateTime.Now.ToString("yyyy-MM-dd");
                    string MonthTimeWhere = " And createtime <" + "'" + ThisMonthDayWhere + "'";

                    // 在查询本月的数据  1=1  And createtime>'2020-12-10'
                    ModelThisMonth = imageservice.GetModelList(ResultWhere + MonthTimeWhere + SqlWhere + OrderBy);
                }

                //合并为新的List
                var NewModelList = ModelThisMonth.Concat(ModelLastMonth).ToList();
                WeekJson = new weekCountjson();
                if (min!=""&&max!="")
                {
                    WeekJson.Weekname = min + "℃~" + max + "℃" + "设备统计";
                }
                else if (min=="120"&&max=="")
                {
                    WeekJson.Weekname = "120℃以上" + "设备统计";
                }
                else if (min==""&&max=="")
                {
                    if (AddMaxAndMin[Min].ToString() == "120"&& AddMaxAndMin[Max] == "120")
                    {
                        WeekJson.Weekname =  "120℃以上" + "设备统计";
                    }
                    else
                    {
                        WeekJson.Weekname = AddMaxAndMin[Min].ToString() + "℃~" + AddMaxAndMin[Max].ToString() + "℃" + "设备统计";
                    }
                    
                }
                
                WeekJson.device_count_list = NewModelList;
                weekjson.Add(WeekJson);
                if (AddMaxAndMin.Count==2)
                {
                    break;
                }
                if (Max == AddMaxAndMin.Count - 1)
                {
                    break;
                }
            }

            ////合并为新的List
            //var NewModelList=ModelThisMonth.Concat(ModelLastMonth).ToList();
            //weekCountjson WeekJson = new weekCountjson();
            //WeekJson.Weekname = min + "℃~" + max + "℃" + "设备统计";
            //WeekJson.device_count_list = NewModelList;
            //List<weekCountjson> weekjson = new List<weekCountjson>();
            //weekjson.Add(WeekJson);

            jsonjson json = new jsonjson();
            json.week_json = weekjson;
            return json;

            #region 弃用
            //if (month.Trim() == "")
            //{
            //    month = nowmonth;
            //}

            //string sql = "";
            //if (max != "")
            //{
            //    sql += " and valuemax < " + max;
            //}
            //if (min != "")
            //{
            //    sql += " and valuemax > " + min;
            //}
            //if (usermodel.usertype == "0")
            //{
            //    if (month == nowmonth)
            //    {
            //        historylist = imageservice.GetModelList("areaid='" + usermodel.areaid + "'" + sql + " group by devicename");
            //    }
            //    else
            //    {
            //        historylist = imageservice.HisGetModelList(month, "areaid='" + usermodel.areaid + "' " + sql + " group by devicename");
            //    }
            //}
            //if (usermodel.usertype == "1")
            //{
            //    if (month == nowmonth)
            //    {
            //        historylist = imageservice.GetModelList("fenbuid='" + usermodel.fenbuid + "' " + sql + " group by devicename");
            //    }
            //    else
            //    {
            //        historylist = imageservice.HisGetModelList(month, "fenbuid='" + usermodel.fenbuid + "' " + sql + " group by devicename");
            //    }
            //}
            //if (usermodel.usertype == "2")
            //{
            //    if (month == nowmonth)
            //    {
            //        historylist = imageservice.GetModelList("ywbid='" + usermodel.ywbid + "' " + sql + " group by devicename");
            //    }
            //    else
            //    {
            //        historylist = imageservice.HisGetModelList(month, "ywbid='" + usermodel.ywbid + "' " + sql + " group by devicename");
            //    }
            //}
            //if (usermodel.usertype == "3")
            //{
            //    if (month == nowmonth)
            //    {
            //        historylist = imageservice.GetModelList("1=1 " + sql + " group by devicename");
            //    }
            //    else
            //    {
            //        historylist = imageservice.HisGetModelList(month, "1=1 " + sql + " group by devicename");
            //    }
            //}
            //List<Maticsoft.Model.image_record_history> count_70 = new List<Maticsoft.Model.image_record_history>();
            //List<Maticsoft.Model.image_record_history> count_80 = new List<Maticsoft.Model.image_record_history>();
            //List<Maticsoft.Model.image_record_history> count_90 = new List<Maticsoft.Model.image_record_history>();
            //List<Maticsoft.Model.image_record_history> count_100 = new List<Maticsoft.Model.image_record_history>();
            //for (int i = 0; i < historylist.Count; i++)
            //{
            //    string temp = historylist[i].valuemax;
            //    if (temp != "" && temp != null)
            //    {
            //        double value = double.Parse(temp);
            //        if (value >= 70 && value < 80)
            //        {
            //            count_70.Add(historylist[i]);
            //        }
            //        if (value >= 80 && value < 90)
            //        {
            //            count_80.Add(historylist[i]);
            //        }
            //        if (value >= 90 && value < 100)
            //        {
            //            count_90.Add(historylist[i]);
            //        }
            //        if (value >= 100)
            //        {
            //            count_100.Add(historylist[i]);
            //        }
            //    }
            //}
            //weekCountjson json70 = new weekCountjson();
            //weekCountjson json80 = new weekCountjson();
            //weekCountjson json90 = new weekCountjson();
            //weekCountjson json100 = new weekCountjson();
            //json70.Weekname = "70℃~80℃设备统计";
            //json70.device_count_list = count_70;
            //json80.Weekname = "80℃~90℃设备统计";
            //json80.device_count_list = count_80;
            //json90.Weekname = "90℃~100℃设备统计";
            //json90.device_count_list = count_90;
            //json100.Weekname = "100℃以上设备统计";
            //json100.device_count_list = count_100;
            //List<weekCountjson> weekjson = new List<weekCountjson>();
            //if (count_70.Count > 0)
            //{
            //    weekjson.Add(json70);
            //}
            //if (count_80.Count > 0)
            //{
            //    weekjson.Add(json80);
            //}
            //if (count_90.Count > 0)
            //{
            //    weekjson.Add(json90);
            //}
            //if (count_100.Count > 0)
            //{
            //    weekjson.Add(json100);
            //}
            //jsonjson json = new jsonjson();
            //json.week_json = weekjson;
            //return json;
            #endregion

        }

        public string deleteImageByIds(string ids)
        {
            Newtonsoft.Json.Linq.JArray jsonArr = parseTargetArray(ids);
            List<string> DeleteIdList = new List<string>();
            returnjson json = new returnjson();
            if (jsonArr == null || jsonArr.Count == 0)
            {
                json.msg = "没有可删除的数据";
                json.falg = false;
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            HttpHelperServer.CreateTxt("deleteImageByIds","", "准备删除的ids的集合为:"+ids);
            Maticsoft.BLL.image_record_history imageService = new Maticsoft.BLL.image_record_history();
            Maticsoft.Model.image_record_history imageModel = new Maticsoft.Model.image_record_history();
            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor deviceModel = new Maticsoft.Model.device_infor();
            Maticsoft.BLL.alarm_push_infor alarmService = new Maticsoft.BLL.alarm_push_infor();
            //string delids = "";
            List<Maticsoft.Model.image_record_history> imagelist = new List<Maticsoft.Model.image_record_history>();
            if (jsonArr != null && jsonArr.Count > 0)
            {
                for (int d = 0; d < jsonArr.Count; d++)
                {
                    string id = jsonArr[d].ToString();
                    if (id != null || id != "")
                    {
                        DeleteIdList.Add(id);
                        Maticsoft.Model.image_record_history image = imageService.GetModel(id);
                        if (image != null)
                        {
                            imagelist.Add(image);
                            HttpHelperServer.CreateTxt("deleteImageByIds", "", "判断是否存在告警信息,添加:图片的id为" + id);
                        }
                        var ModelImage = imageService.GetModel(id);
                        if (ModelImage != null)
                        {
                            // 执行删除
                            imageService.Delete(ModelImage.recordid);

                        }
                        else
                        {
                            HttpHelperServer.CreateTxt("deleteImageByIds", "", "执行删除出错,不存在当前的实体,实体传递的Id=" + id);
                        }
                    }
                }

            }
            imageModel = imageService.GetModel(jsonArr[0].ToString());
            string deviceid = "";
            string stationid = "";
            if (imageModel != null)
            {
                deviceid = imageModel.deviceid;
                if (deviceid != "")
                {
                    deviceModel = deviceService.GetModel(deviceid);//获取图片的设备

                    if (deviceModel != null)
                    {
                        stationid = deviceModel.stationid;//获取设备对应的变电站id
                    }
                }
            }

            // 一个个进行删除历史图片
            //if (DeleteIdList.Count>0)
            //{
            //    for (int i = 0; i < DeleteIdList.Count; i++)
            //    {
            //        // 查询图片是否存在
            //        string GetImageId = DeleteIdList[i].ToString();
            //        if (!string.IsNullOrEmpty(GetImageId))
            //        {
            //            var ModelImage=imageService.GetModel(GetImageId);
            //            if (ModelImage!=null)
            //            {
            //                // 执行删除
            //                imageService.Delete(ModelImage.recordid);
            //            }
            //            else
            //            {
            //                HttpHelperServer.CreateTxt("deleteImageByIds","","执行删除出错,不存在当前的实体,实体传递的Id="+GetImageId);
            //            }
            //        }
            //    }
            //}
                if (deviceid != "")
                {
                    updateDeviceAndStation(deviceid, stationid);
                    //判断图片是否含有告警信息
                    if (imagelist.Count > 0)
                    {
                        for (int v = 0; v < imagelist.Count; v++)
                        {
                            if (imagelist[v] != null)//删除对应的告警信息
                            {
                                string dtime = imagelist[v].createtime.Value.ToString("yyyy-mm-dd hh:mm:ss");
                                string sql = "deviceid='" + deviceid + "' and alarmvalue='" + imagelist[v].valuemax + "' and createtime = '" + dtime + "'";
                                List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
                                alarmlist = alarmService.GetModelList(sql);
                                if (alarmlist.Count > 0)
                                {
                                    foreach (var a in alarmlist)
                                    {
                                        if (a != null)
                                        {
                                            alarmService.Delete(a.id);
                                            HttpHelperServer.CreateTxt("deleteImageByIds", "", "同时删除掉的告警id为" + a.id);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            json.msg = "删除成功";
            json.falg = true;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }

        private void updateDeviceAndStation(string deviceid, string stationid)
        {
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            //deviceservice.Update_every_value(alarmmodel.deviceid); 
            List<double> device_double = new List<double>(); device_double.Add(0);
            List<string> device_id = new List<string>(); device_id.Add("");
            //统计当前设备的最高温进行修改  
            string time = DateTime.Now.ToString("yyyy-MM-dd");
            List<Maticsoft.Model.image_record_history> historylist1 = new List<Maticsoft.Model.image_record_history>();
            historylist1 = historyservice.GetModelList("deviceid='" + deviceid + "'and createtime > '" + time + "'");
            if (historylist1.Count > 0)
            {
                for (int j = 0; j < historylist1.Count; j++)
                {
                    device_double.Add(double.Parse(historylist1[j].valuemax));
                    device_id.Add(historylist1[j].recordid);
                }
            }
            string device_max_value = device_double.Max().ToString();
            string device_max_recordid = device_id[getMaxindex(device_double)];
            List<double> device_yestodaytop_double = new List<double>(); device_yestodaytop_double.Add(0);
            List<string> device_yestodayid = new List<string>(); device_yestodayid.Add("");
            //统计设备昨天的最高温并进行修改
            string yestodaytime = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
            List<Maticsoft.Model.image_record_history> historylist2 = new List<Maticsoft.Model.image_record_history>();
            historylist2 = historyservice.GetModelList("deviceid='" + deviceid + "'and createtime > '" + yestodaytime + "'and createtime < '" + time + "'");
            if (historylist2.Count > 0)
            {
                for (int j = 0; j < historylist2.Count; j++)
                {
                    device_yestodaytop_double.Add(double.Parse(historylist2[j].valuemax));
                    device_yestodayid.Add(historylist2[j].recordid);
                }
            }
            string device_yestodaytop = device_yestodaytop_double.Max().ToString();
            string yestodaymaxid = device_yestodayid[getMaxindex(device_yestodaytop_double)];
            string device_histop = "";
            string device_histopid = "";
            if (device_yestodaytop_double.Max() >= device_double.Max())
            {
                device_histop = device_yestodaytop;
                device_histopid = yestodaymaxid;
            }
            else
            {
                device_histop = device_max_value;
                device_histopid = device_max_recordid;
            }
            Maticsoft.Model.device_infor deviceModel = deviceservice.GetModel(deviceid);
            if (deviceModel != null)
            {
                deviceModel.todaymax = device_max_value;
                deviceModel.todaytop = device_max_value;
                deviceModel.todaymaxid = device_max_recordid;
                deviceModel.yestodaytop = device_yestodaytop;
                deviceModel.yestodaymaxid = yestodaymaxid;
                deviceModel.weektop = device_histop;
                deviceModel.weekmaxid = device_histopid;
                deviceModel.monthtop = device_histop;
                deviceModel.monthmax = device_histop;
                deviceModel.monthmaxid = device_histopid;
                deviceModel.historytop = device_histop;
                deviceModel.historymaxid = device_histopid;
                deviceservice.Update(deviceModel);
            }
            //更新当前变电站数据
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            Maticsoft.Model.station_infor stamodel = new Maticsoft.Model.station_infor();
            stamodel = stationservice.GetModel(stationid);
            if (stamodel != null)
            {
                string todaytopmax = "";
                string todaytopmaxid = "";
                string yestdaytopmax = "";
                string yestdaytopmaxid = "";
                List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
                devicelist = deviceservice.GetModelList(" stationid='" + stationid + "'");
                List<double> station_todaytop = new List<double>(); station_todaytop.Add(0);
                List<string> station_id = new List<string>(); station_id.Add("");
                List<double> station_yestodaytop_double = new List<double>(); station_yestodaytop_double.Add(0);
                List<string> station_yestodayid = new List<string>(); station_yestodayid.Add("");
                if (devicelist.Count > 0)
                {
                    for (int k = 0; k < devicelist.Count; k++)
                    {
                        station_todaytop.Add(double.Parse(devicelist[k].todaytop));
                        station_id.Add(devicelist[k].todaymaxid);
                        if (devicelist[k].yestodaytop != null && devicelist[k].yestodaytop != "")
                        {
                            station_yestodaytop_double.Add(double.Parse(devicelist[k].yestodaytop));
                            station_yestodayid.Add(devicelist[k].yestodaymaxid);
                        }
                    }
                }
                if (station_todaytop.Count > 0)
                {
                    todaytopmax = station_todaytop.Max().ToString();
                    todaytopmaxid = station_id[getMaxindex(station_todaytop)];
                    yestdaytopmax = station_yestodaytop_double.Max().ToString();
                    yestdaytopmaxid = station_yestodayid[getMaxindex(station_yestodaytop_double)];
                }
                string stationMax = "";
                string stationMaxid = "";
                if (station_todaytop.Max() >= station_yestodaytop_double.Max())
                {
                    stationMax = todaytopmax;
                    stationMaxid = todaytopmaxid;
                }
                else
                {
                    stationMax = yestdaytopmax;
                    stationMaxid = yestdaytopmaxid;
                }
                if (todaytopmax != "")
                {
                    stamodel.todaytop = todaytopmax;
                    stamodel.todayid = todaytopmaxid;
                    stamodel.yestodaytop = yestdaytopmax;
                    stamodel.yestodayid = yestdaytopmaxid;
                    stamodel.weektop = stationMax;
                    stamodel.weekid = stationMaxid;
                    stamodel.monthtop = stationMax;
                    stamodel.monthid = stationMaxid;
                    stamodel.historytop = stationMax;
                    stamodel.historyid = stationMaxid;
                }
                stationservice.Update(stamodel);
                updatestationAlarmcount(stationid);
            }
        }

        private Newtonsoft.Json.Linq.JArray parseTargetArray(string targetlist)
        {
            Newtonsoft.Json.Linq.JArray arry = null;

            if (targetlist != null && targetlist != "")
            {
                Newtonsoft.Json.Linq.JArray jsonArr = (Newtonsoft.Json.Linq.JArray)JsonConvert.DeserializeObject(targetlist);

                if (jsonArr != null)
                {
                    if (jsonArr.Count > 0)
                    {
                        arry = jsonArr;
                    }
                }
            }

            return arry;
        }

    }
}
