﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class alarm_over_80_device_json
    {
        string station_building = "";

        public string Station_building
        {
            get { return station_building; }
            set { station_building = value; }
        }
        DataTable devicelist = new DataTable();

        public DataTable Devicelist
        {
            get { return devicelist; }
            set { devicelist = value; }
        }
    }
}