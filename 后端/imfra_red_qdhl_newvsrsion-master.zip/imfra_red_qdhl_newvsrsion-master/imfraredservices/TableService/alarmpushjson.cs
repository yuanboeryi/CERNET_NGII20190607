﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class alarmpushjson
    {
        string newesttime = "";

        public string Newesttime
        {
            get { return newesttime; }
            set { newesttime = value; }
        }
        DataTable dt = new DataTable();

        public DataTable Dt
        {
            get { return dt; }
            set { dt = value; }
        }
    }
}