﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class device_80_json
    {
        DataTable device_tongji_all = new DataTable();

        public DataTable Device_tongji_all
        {
            get { return device_tongji_all; }
            set { device_tongji_all = value; }
        }
        DataTable device_tongji_single = new DataTable();

        public DataTable Device_tongji_single
        {
            get { return device_tongji_single; }
            set { device_tongji_single = value; }
        }
        string tongji = "";

        public string Tongji
        {
            get { return tongji; }
            set { tongji = value; }
        }

    }
}