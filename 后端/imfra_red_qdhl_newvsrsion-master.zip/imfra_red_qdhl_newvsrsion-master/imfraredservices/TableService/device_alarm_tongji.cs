﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class device_alarm_tongji
    {
        string devicetype = "";

        public string Devicetype
        {
            get { return devicetype; }
            set { devicetype = value; }
        }
        int alarmcount = 0;

        public int Alarmcount
        {
            get { return alarmcount; }
            set { alarmcount = value; }
        }
    }
}