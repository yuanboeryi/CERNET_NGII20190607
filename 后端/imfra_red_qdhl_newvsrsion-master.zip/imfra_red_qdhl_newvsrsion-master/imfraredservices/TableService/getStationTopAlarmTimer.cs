﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Data;

namespace imfraredservices.TableService
{
    public class getStationTopAlarmTimer
    {
        System.Timers.Timer timer = new System.Timers.Timer();
        protected void Application_Start(object sender, EventArgs e)
        {
            //在应用程序启动时运行的代码
            //在新会话启动时运行的代码
            SetAccount();
            timer.Start();//定时器开始
        }

        private void SetAccount()
        {
            //下面这句看不懂还报错 ，先注释 
            //double.TryParse(ConfigurationManager.AppSettings["TimerInterval"], out iTimerInterval);
            timer.Interval = 1000;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(getMessage);
            //getMessage是个方法(略)
        }
        public void getMessage(object sender, EventArgs e)
        {
           
            DateTime dtnow = System.DateTime.Now;
            if (dtnow.Hour == 0 && dtnow.Minute == 01 && dtnow.Second == 0)//每天00:01执行
            {
                getStationTopAlarm();
            }
        }

        //public void getStationTopAlarm()
        //{
        //    TableAction action = new TableAction();
        //    //获得所有stationid from staion_infor
        //    Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
        //    List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
        //    stationlist = stationservice.GetModelList("");
        //    //通过stationid调用l_getAlarmStation获得今日最高温
        //    for (int i = 0; i < stationlist.Count; i++)
        //    {
        //        string stationid = stationlist[i].stationid;
        //        //通过stationid拿到youcejson
        //        youcejson json  = action.l_getAlarmStation(stationid);
        //        DataTable dt = json.Devicelist;
        //        //station_top_history.add()
        //        Maticsoft.BLL.station_top_history historyservice = new Maticsoft.BLL.station_top_history();
        //        Maticsoft.Model.station_top_history historymodel = new Maticsoft.Model.station_top_history();
        //        Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
        //        Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
        //        devicemodel = deviceservice.GetModel(deviceid);
        //        for (int j = 0; j < dt.Rows.Count; j++)
        //        {
        //            string creattimestr = dt.Rows[j]["createtime"].ToString();
        //            DateTime creattime = Convert.ToDateTime(creattimestr);
        //            historymodel.stationid = stationid;
        //            historymodel.toprecordid = dt.Rows[j]["id"].ToString();
        //            historymodel.stationname = dt.Rows[j]["stationname"].ToString();                  
        //            historymodel.todaytop = dt.Rows[j]["value"].ToString();
        //            historymodel.offsetvalue = devicemodel.offsetvalue;
        //            historymodel.topdevicename = devicemodel.devicename;
        //            historyservice.Add(historymodel);

        //        }
        //    }

        //}

        public string getStationTopAlarm()
        {
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stationmodellist = new List<Maticsoft.Model.station_infor>();
            stationmodellist = stationservice.GetModelList("");
            for (int i = 0; i < stationmodellist.Count; i++)
            {
                if (stationmodellist[i].stationid != null)
                {
                    add_statonTop_history(stationmodellist[i].stationid);
                }

            }
            return "数据更新完成";
        }
        public void add_statonTop_history(string stationid)
        {
            for (int i = -1; i < 0; i++)//统计前一天的最高温
            {
                Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
                List<Maticsoft.Model.image_record_history> modellist = historyservice.GetModelList("deviceid in (select deviceid from device_infor where stationid='" + stationid + "')and createtime >'" + System.DateTime.Now.AddDays(i) + "'and createtime < '" + System.DateTime.Now.AddDays(i + 1) + "'");
                //上面        
                List<double> itemvaluelist = new List<double>();
                List<string> itemrecordidlist = new List<string>();
                foreach (var item in modellist)
                {
                    itemvaluelist.Add(double.Parse(item.valuemax));
                    itemrecordidlist.Add(item.recordid);
                }
                if (itemvaluelist.Count > 0)
                {
                    int index = getMaxindex(itemvaluelist);//最大值的索引
                    string maxrecordid = itemrecordidlist[index];//最大值
                    Maticsoft.Model.image_record_history historymodel = new Maticsoft.Model.image_record_history();
                    historymodel = historyservice.GetModel(maxrecordid);
                    Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
                    Maticsoft.Model.station_infor stationmodel = new Maticsoft.Model.station_infor();
                    stationmodel = stationservice.GetModel(stationid);
                    Maticsoft.BLL.station_top_history stationtopservice = new Maticsoft.BLL.station_top_history();
                    Maticsoft.Model.station_top_history stationtopmodel = new Maticsoft.Model.station_top_history();
                    Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
                    Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                    devicemodel = deviceservice.GetModel(historymodel.deviceid);
                    string toprecordid = Guid.NewGuid().ToString("N");//不用记录的id去当表的主键
                    stationtopmodel.toprecordid = toprecordid;
                    stationtopmodel.stationname = stationmodel.stationname;
                    stationtopmodel.stationid = stationid;
                    stationtopmodel.todaytop = historymodel.valuemax;
                    stationtopmodel.toptime = historymodel.createtime;
                    stationtopmodel.topdevicename = historymodel.devicename;
                    stationtopmodel.offsetvalue = devicemodel.offsetvalue;
                    stationtopservice.Add(stationtopmodel);

                }

            }

        }
        public int getMaxindex(List<double> list)
        {
            double a = list[0];
            int index = 0;//把假设的最大值索引赋值非index

            for (int i = 1; i < list.Count; i++)
            {
                if (list[i] > a)
                {
                    a = list[i];
                    index = i;//把较大值的索引赋值非index
                }
            }
            return index;
        }
    }

}