﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class jsonjson
    {
        string areaname = "";

        public string Areaname
        {
            get { return areaname; }
            set { areaname = value; }
        }
        string fenbuname = "";

        public string Fenbuname
        {
            get { return fenbuname; }
            set { fenbuname = value; }
        }
        string ywbname = "";

        public string Ywbname
        {
            get { return ywbname; }
            set { ywbname = value; }
        }
        string stationname = "";

        public string Stationname
        {
            get { return stationname; }
            set { stationname = value; }
        }

        string buildingname = "";
        public string Buildingname
        {
            get { return buildingname; }
            set { buildingname = value; }
        }
        List<string> stationnamelist = new List<string>();

        public List<string> Stationnamelist
        {
            get { return stationnamelist; }
            set { stationnamelist = value; }
        }
        List<string> stationidlidt = new List<string>();

        public List<string> Stationidlidt
        {
            get { return stationidlidt; }
            set { stationidlidt = value; }
        }
        List<string> buildinglist = new List<string>();

        public List<string> Buildinglist
        {
            get { return buildinglist; }
            set { buildinglist = value; }
        }
        List<string> buildingidlist = new List<string>();

        public List<string> Buildingidlist
        {
            get { return buildingidlist; }
            set { buildingidlist = value; }
        }
        List<string> machinelist = new List<string>();

        public List<string> Machinelist
        {
            get { return machinelist; }
            set { machinelist = value; }
        }
        List<string> devicelist = new List<string>();

        public List<string> Devicelist
        {
            get { return devicelist; }
            set { devicelist = value; }
        }
        List<stationImagejson> json = new List<stationImagejson>();

        public List<stationImagejson> Json
        {
            get { return json; }
            set { json = value; }
        }
        List<weekCountjson> weekjson = new List<weekCountjson>();

        public List<weekCountjson> week_json
        {
            get { return weekjson; }
            set { weekjson = value; }
        }

        int devicecount = 0;
        public int Devicecount
        {
            get { return devicecount; }
            set { devicecount = value; }
        }
    }
}