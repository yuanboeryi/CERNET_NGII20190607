﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.UserServices
{

    public class returnjson
    {
        string _msg = "";

        public string msg
        {
            get { return _msg; }
            set { _msg = value; }
        }
        bool __falg = false;

        public bool falg
        {
            get { return __falg; }
            set { __falg = value; }
        }
    }
}