﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class roundDevicejson
    {
        string deviceid = "";

        public string Deviceid
        {
            get { return deviceid; }
            set { deviceid = value; }
        }
        string devicename = "";

        public string Devicename
        {
            get { return devicename; }
            set { devicename = value; }
        }
        string stationid = "";

        public string Stationid
        {
            get { return stationid; }
            set { stationid = value; }
        }
        string stationname = "";

        public string Stationname
        {
            get { return stationname; }
            set { stationname = value; }
        }
        string stationshortname1 = "";

        public string Stationshortname1
        {
            get { return stationshortname1; }
            set { stationshortname1 = value; }
        }
        string stationshortname2 = "";

        public string Stationshortname2
        {
            get { return stationshortname2; }
            set { stationshortname2 = value; }
        }

        string stationshortname3 = "";

        public string Stationshortname3
        {
            get { return stationshortname3; }
            set { stationshortname3 = value; }
        }


        private string todaytop = "";

        public string Todaytop
        {
            get { return todaytop; }
            set { todaytop = value; }
        }
        private string isalarm = "";

        public string Isalarm
        {
            get { return isalarm; }
            set { isalarm = value; }
        }


        List<string> templist = new List<string>();

        public List<string> Templist
        {
            get { return templist; }
            set { templist = value; }
        }
        List<string> fuhelist = new List<string>();

        public List<string> Fuhelist
        {
            get { return fuhelist; }
            set { fuhelist = value; }
        }

        DateTime time = new DateTime();

        public DateTime Time
        {
            get { return time; }
            set { time = value; }
        }
        string createtime = "";

        public string Createtime
        {
            get { return createtime; }
            set { createtime = value; }
        }

        string image_red = "";

        public string Image_red
        {
            get { return image_red; }
            set { image_red = value; }
        }
        string image_high = "";

        public string Image_high
        {
            get { return image_high; }
            set { image_high = value; }
        }
        string image_mix = "";

        public string Image_mix
        {
            get { return image_mix; }
            set { image_mix = value; }
        }
        string machinecode = "";

        public string Machinecode
        {
            get { return machinecode; }
            set { machinecode = value; }
        }

        string machinename = "";
        public string Machinename
        {
            get { return machinename; }
            set { machinename = value; }
        }

       

    }
}