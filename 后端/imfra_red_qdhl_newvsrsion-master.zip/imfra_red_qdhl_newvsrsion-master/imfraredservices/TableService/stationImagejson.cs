﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class stationImagejson
    {
        
        string machineid = "";

        public string Machineid
        {
            get { return machineid; }
            set { machineid = value; }
        }
        string machinename = "";

        public string Machinename
        {
            get { return machinename; }
            set { machinename = value; }
        }
        string stationname = "";

        public string Stationname
        {
            get { return stationname; }
            set { stationname = value; }
        }
        string buildingname = "";

        public string Buildingname
        {
            get { return buildingname; }
            set { buildingname = value; }
        }
        DataTable imagedt = new DataTable();

        public DataTable Imagedt
        {
            get { return imagedt; }
            set { imagedt = value; }
        }
    }
}