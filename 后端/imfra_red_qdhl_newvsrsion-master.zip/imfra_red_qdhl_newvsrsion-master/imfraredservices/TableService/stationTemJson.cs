﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class stationTemJson
    {
        List<string> stationidlist = new List<string>();

        public List<string> Stationidlist
        {
            get { return stationidlist; }
            set { stationidlist = value; }
        }
        List<string> stationlist = new List<string>();

        public List<string> Stationlist
        {
            get { return stationlist; }
            set { stationlist = value; }
        }
        List<string> todaylist = new List<string>();

        public List<string> Todaylist
        {
            get { return todaylist; }
            set { todaylist = value; }
        }
        List<string> yestodaylist = new List<string>();

        public List<string> Yestodaylist
        {
            get { return yestodaylist; }
            set { yestodaylist = value; }
        }
        List<string> weeklist = new List<string>();

        public List<string> Weeklist
        {
            get { return weeklist; }
            set { weeklist = value; }
        }
        List<string> monthlist = new List<string>();

        public List<string> Monthlist
        {
            get { return monthlist; }
            set { monthlist = value; }
        }
        List<string> historylist = new List<string>();

        public List<string> Historylist
        {
            get { return historylist; }
            set { historylist = value; }
        }
    }
}