﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class temprasejson
    {
        string stationcount = "";

        public string Stationcount
        {
            get { return stationcount; }
            set { stationcount = value; }
        }
        string alarmcount = "";

        public string Alarmcount
        {
            get { return alarmcount; }
            set { alarmcount = value; }
        }
        string maxmachine = "";

        public string Maxmachine
        {
            get { return maxmachine; }
            set { maxmachine = value; }
        }
        string maxdevice = "";

        public string Maxdevice
        {
            get { return maxdevice; }
            set { maxdevice = value; }
        }
        string overvalue = "";

        public string Overvalue
        {
            get { return overvalue; }
            set { overvalue = value; }
        }
        string recordcount = "";

        public string Recordcount
        {
            get { return recordcount; }
            set { recordcount = value; }
        }
        DataTable recordlist = new DataTable();

        public DataTable Recordlist
        {
            get { return recordlist; }
            set { recordlist = value; }
        }
    }
}