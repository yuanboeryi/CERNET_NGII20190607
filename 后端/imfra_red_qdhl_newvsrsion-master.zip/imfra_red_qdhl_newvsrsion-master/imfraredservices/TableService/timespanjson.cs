﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class timespanjson
    {
        string deviceid = "";

        public string Deviceid
        {
            get { return deviceid; }
            set { deviceid = value; }
        }
        string devicename = "";

        public string Devicename
        {
            get { return devicename; }
            set { devicename = value; }
        }
        string machineid = "";

        public string Machineid
        {
            get { return machineid; }
            set { machineid = value; }
        }
        string machinename = "";

        public string Machinename
        {
            get { return machinename; }
            set { machinename = value; }
        }
        List<string> templist = new List<string>();

        public List<string> Templist
        {
            get { return templist; }
            set { templist = value; }
        }
    }
}