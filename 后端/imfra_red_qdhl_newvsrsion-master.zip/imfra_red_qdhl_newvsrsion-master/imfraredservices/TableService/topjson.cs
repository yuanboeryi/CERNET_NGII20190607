﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class topjson
    {
        DataTable topdt = new DataTable();

        public DataTable Topdt
        {
            get { return topdt; }
            set { topdt = value; }
        }
    }
}