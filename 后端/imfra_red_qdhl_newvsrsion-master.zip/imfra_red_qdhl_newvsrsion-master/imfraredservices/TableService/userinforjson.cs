﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class userinforjson
    {
        DataTable dt_area = new DataTable();

        public DataTable Dt_area
        {
            get { return dt_area; }
            set { dt_area = value; }
        }
        DataTable dt_fenbu = new DataTable();

        public DataTable Dt_fenbu
        {
            get { return dt_fenbu; }
            set { dt_fenbu = value; }
        }
        DataTable dt_ywb = new DataTable();

        public DataTable Dt_ywb
        {
            get { return dt_ywb; }
            set { dt_ywb = value; }
        }
        DataTable dt_station = new DataTable();

        public DataTable Dt_station
        {
            get { return dt_station; }
            set { dt_station = value; }
        }
        DataTable dt_building = new DataTable();

        public DataTable Dt_building
        {
            get { return dt_building; }
            set { dt_building = value; }
        }
    }
}