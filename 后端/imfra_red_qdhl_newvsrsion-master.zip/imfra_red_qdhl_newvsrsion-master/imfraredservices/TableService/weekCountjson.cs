﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class weekCountjson
    {
        string weekname = "";

        public string Weekname
        {
            get { return weekname; }
            set { weekname = value; }
        }
        List<Maticsoft.Model.image_record_history> devicecountlist = new List<Maticsoft.Model.image_record_history>();

        public List<Maticsoft.Model.image_record_history> device_count_list
        {
            get { return devicecountlist; }
            set { devicecountlist = value; }
        }
    }
}