﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class youcejson
    {
        DataTable devicelist = new DataTable();

        public DataTable Devicelist
        {
            get { return devicelist; }
            set { devicelist = value; }
        }
        DataTable deviceToplist = new DataTable();

        public DataTable DeviceToplist
        {
            get { return deviceToplist; }
            set { deviceToplist = value; }
        }
        string buildinglist = "";

        public string Buildinglist
        {
            get { return buildinglist; }
            set { buildinglist = value; }
        }
    }
}