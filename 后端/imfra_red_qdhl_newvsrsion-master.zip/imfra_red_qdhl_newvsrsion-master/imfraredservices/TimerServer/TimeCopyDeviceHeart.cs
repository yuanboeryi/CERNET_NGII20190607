﻿using FluentScheduler;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TimerServer
{
    public class TimeCopyDeviceHeart : IJob
    {
        private static string AppSetting = ConfigurationManager.AppSettings["ConnectionString"];



        public TimeCopyDeviceHeart()
        {

        }
        public void Execute()
        {
            /*
             判断是否存在需要创建的表
             */
            string date = DateTime.Now.ToString("yyyyMMdd");

            string TableName = "device_heart_infor" + date;
            int Continus=ContinusTable(TableName);

            // 开始创建表
            if (Continus==0)
            {
                // 创建新的 device_heart_infor ,修改原来的为TableName
                //string CreateSql = "CREATE TABLE  " + TableName + "  SELECT * FROM" + "  device_heart_infor  " + "  WHERE 1=2 ";
                string EditSql = "alter table device_heart_infor rename "+ TableName;
                int EditCount = CreateTable(EditSql);

                // 创建新表
                string CreateSql = "CREATE TABLE   device_heart_infor  SELECT * FROM "+TableName +" WHERE 1=2 ";
                var IsContinus=ContinusTable("device_heart_infor");
                if (IsContinus==0)
                {
                    int CreateCount = CreateTable(CreateSql);
                }
            }

        }



        /// <summary>
        /// 是否存在需要创建的表
        /// </summary>
        /// <returns></returns>
        public int ContinusTable(string CreateTableName)
        {
            int GetIsCreate = 1;
            //获取AppSetting字符串
            string GetAppSetting = ConfigurationManager.AppSettings["ConnectionString"];
            int IndexOf = GetAppSetting.IndexOf("Database=");

            //Database = infrared_net; Charset = utf8
            GetAppSetting = GetAppSetting.Remove(0, IndexOf);
            int IndexOfX = GetAppSetting.IndexOf(";");
            //Database = infrared_net
            GetAppSetting = GetAppSetting.Remove(IndexOfX, GetAppSetting.Length - IndexOfX);
            GetAppSetting = GetAppSetting.Replace("Database", "");
            GetAppSetting = GetAppSetting.Replace("=", "");
            GetAppSetting = GetAppSetting.Trim(); /*infrared_net*/
            string Sql = "SELECT COUNT(*) as Count FROM information_schema.TABLES WHERE table_schema = '" + AppSetting + "' and table_name = '" + CreateTableName + "'";
            //执行Sql
            DataSet dataSet = ExQuerty(Sql);
            if (dataSet.Tables.Count > 0)
            {
                var TableOne = dataSet.Tables[0];
                GetIsCreate = Convert.ToInt32(TableOne.Rows[0]["Count"].ToString());
                if (dataSet.Tables.Count >= 1)
                {
                    // 获取第一个Table
                    var TableOnes = dataSet.Tables[0];
                    GetIsCreate = Convert.ToInt32(TableOne.Rows[0]["Count"].ToString());
                }
            }
            return GetIsCreate;
        }


        /// <summary>
        /// 查询返回DataSet
        /// </summary>
        /// <returns></returns>
        public DataSet ExQuerty(string Sql)
        {
            DataSet dataSet = new DataSet();
            try
            {

                MySqlDataAdapter MySqlAdapter = new MySqlDataAdapter(Sql, AppSetting);
                MySqlAdapter.Fill(dataSet);
            }
            catch (Exception e)
            {

                string Msg = e.Message.ToString();
            }
            return dataSet;
        }

        public static int CreateTable(string Sql)
        {
            using (MySqlConnection connection = new MySqlConnection(AppSetting))
            {

                try
                {
                    connection.Open();
                    MySqlCommand sqlCommand = new MySqlCommand(Sql, connection);

                    int row = sqlCommand.ExecuteNonQuery();
                    connection.Close();
                    return row;
                }
                catch (Exception e)
                {

                    string Str = e.Message.ToString();
                }
                return 0;
            }
        }
    }
}