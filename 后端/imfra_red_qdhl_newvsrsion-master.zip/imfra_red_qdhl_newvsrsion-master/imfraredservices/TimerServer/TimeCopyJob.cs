﻿using FluentScheduler;
using Maticsoft.BLL;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TimerServer
{
    public class TimeCopyJob : IJob
    {


       private static string AppSetting = ConfigurationManager.AppSettings["ConnectionString"];
        /// <summary>
        /// 要做的工作
        /// </summary>
        public void Execute()
        {
            string Name = DateTime.Now.ToString("yyyyMM");
            string NewName = "image_record_history" + Name;
            int IsContions = ConinusTableCreateTable(NewName);
            if (IsContions == 0)
            {
                string EditSql = "alter table image_record_history rename " + NewName;
                int EditCount = CreateTable(EditSql);
                // 创建新表
                string CreateSql = "CREATE TABLE   image_record_history  SELECT * FROM " + NewName + " WHERE 1=2 ";

                var IsContinus = ConinusTableCreateTable("device_heart_infor");
                if (IsContinus == 0)
                {
                    int CreateCount = CreateTable(CreateSql);
                }
                
            }
        }



     
        /// <summary>
        /// 是否存在 image_record_history_copy_copy
        /// </summary>
        /// <returns></returns>
        public int ContinusTableSour()
        {
            return 0;
        }
        /// <summary>
        /// 是否存在需要创建的表
        /// </summary>
        /// <returns></returns>
        public int ConinusTableCreateTable(string CreateTableName)
        {
            int GetIsCreate = 1;
            //获取AppSetting字符串
            string  GetAppSetting = ConfigurationManager.AppSettings["ConnectionString"];
            //AppSetting = "Server=116.255.207.148;User Id=test;Password=test;Persist Security Info=True;Database=infrared_net;Charset=utf8";
            int IndexOf = GetAppSetting.IndexOf("Database=");

            //Database = infrared_net; Charset = utf8
            GetAppSetting = GetAppSetting.Remove(0, IndexOf);
            int IndexOfX = GetAppSetting.IndexOf(";");
            //Database = infrared_net
            GetAppSetting = GetAppSetting.Remove(IndexOfX, GetAppSetting.Length - IndexOfX);
            GetAppSetting = GetAppSetting.Replace("Database", "");
            GetAppSetting = GetAppSetting.Replace("=", "");
            GetAppSetting = GetAppSetting.Trim(); /*infrared_net*/
            string Sql = "SELECT COUNT(*) as Count FROM information_schema.TABLES WHERE table_schema = '" + AppSetting + "' and table_name = '" + CreateTableName + "'";
            //执行Sql
            DataSet dataSet = ExQuerty(Sql);
            if (dataSet.Tables.Count>0)
            {
                var TableOne = dataSet.Tables[0];
                GetIsCreate = Convert.ToInt32(TableOne.Rows[0]["Count"].ToString());
                if (dataSet.Tables.Count >= 1)
                {
                    // 获取第一个Table
                    var TableOnes = dataSet.Tables[0];
                    GetIsCreate = Convert.ToInt32(TableOne.Rows[0]["Count"].ToString());
                }
            }
            return GetIsCreate;
        }

        /// <summary>
        /// 查询返回DataSet
        /// </summary>
        /// <returns></returns>
        public DataSet ExQuerty(string Sql)
        {
            DataSet dataSet = new DataSet();
            try
            {

                MySqlDataAdapter MySqlAdapter = new MySqlDataAdapter(Sql, AppSetting);
                MySqlAdapter.Fill(dataSet);
            }
            catch (Exception e)
            {

                string Msg = e.Message.ToString();
            }
            return dataSet;
        }

        public static int CreateTable(string Sql)
        {
            using (MySqlConnection connection = new MySqlConnection(AppSetting))
            {

                try
                {
                    connection.Open();
                    MySqlCommand sqlCommand = new MySqlCommand(Sql, connection);

                    int row = sqlCommand.ExecuteNonQuery();
                    connection.Close();
                    return row;
                }
                catch (Exception e)
                {

                    string Str = e.Message.ToString();
                }
                return 0;
            }
        }
    }
}