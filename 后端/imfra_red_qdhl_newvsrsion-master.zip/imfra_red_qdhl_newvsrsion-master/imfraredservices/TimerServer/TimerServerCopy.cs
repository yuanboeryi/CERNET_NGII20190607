﻿using FluentScheduler;
using imfraredservices.HelperServer;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading;
using System.Timers;
using System.Web;

namespace imfraredservices.TimerServer
{
    //FluentSchedule 任务调度工具
    /// <summary>
    ///  定时器
    /// </summary>
    public static class TimerServerCopy
    {


        private static string AppSetting = ConfigurationManager.AppSettings["ConnectionString"];
        public static System.Timers.Timer MonthTime = new System.Timers.Timer();
        public static System.Timers.Timer SevenTime = new System.Timers.Timer();
        public static string ImageHisCopy = "image_record_history";
        public static string DeviceHeartCopy = "device_heart_infor";
        //public static DateTime TestTime = DateTime.Parse("2021-01-04");
        public static void Start()
        {
            // 分表月初 image_record_history
            Thread MonthThread = new Thread(MonthDemo);
            MonthThread.Start();

            //分表7天
            Thread SevenDay = new Thread(SenvenDemo);
            SevenDay.Start();
        }

        public static void MonthDemo()
        {
            MonthTime.Elapsed += new System.Timers.ElapsedEventHandler(MonthTime_Elapsed);
            // 3秒 3600000*6
            MonthTime.Interval = 3600000 * 6;
           MonthTime.Start();
        }

        /// <summary>
        /// 月初分表
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void MonthTime_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            int Day=IsOneday();
            Maticsoft.BLL.subtable BLlSubTable = new Maticsoft.BLL.subtable();
            DateTime TimeNow = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd"));
            //当前的时间不是月初的第一天
            if (Day==1)
            {
                SubTableMonth();

            }
            else 
            {
                //查询当前的时间与上次的间隔时间是否大于等于30天
                // 查询当前的数据库中是否存在
                // 获取当前的 所有月份中最后一次分表的数据
                int MonthType = 0;
                var BLLModelList = BLlSubTable.GetModelList("Type='" + MonthType + "' Order By CreateTime Desc");
                // 存在数据
                if (BLLModelList.Count > 0)
                {
                    // 倒叙查询第一条
                    var FirstOne = BLLModelList.FirstOrDefault();
                    // 获取最后一次插入的时间
                    string LastCreate = FirstOne.CreateTime;
                    DateTime LastCreateTime = DateTime.Parse(LastCreate);
                    var GetTimeSpan = TimeNow - LastCreateTime;
                    //var GetTimeSpan = TestTime - LastCreateTime;
                    // 时差已经大于了30天进行分表数据
                    if (GetTimeSpan.Days > 30)
                    {
                        // SubTableMonth(); 查询两个日期是否是同月 防止出现某个月份是31天
                        if (TimeNow.Month!=LastCreateTime.Month)
                        {
                            SubTableMonth();
                        }
                    }
                }
                else
                {
                    // 从开始到现在没有进行添加过数据
                    // 插入一条当前的时间
                    Maticsoft.Model.subtable ModelSubTable = new Maticsoft.Model.subtable();
                    ModelSubTable.CreateTime = DateTime.Now.ToString("yyyy-MM-dd");
                    ModelSubTable.Type = 0;
                    BLlSubTable.Add(ModelSubTable);
                }
            }
        }

        /// <summary>
        /// 判断当前的时间是否是每月的第一天
        /// </summary>
        /// <returns></returns>
        public static int IsOneday()
        {
            DateTime Time=DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd"));
            return Time.Day;
        }

        /// <summary>
        /// 7天执行
        /// </summary>
        public static void SenvenDemo()
        {
            
            SevenTime.Elapsed += new System.Timers.ElapsedEventHandler(SevenTime_Elapsed);
            // 3600000 * 12
            SevenTime.Interval = 3600000 * 6;
            SevenTime.Start();
        }

        /// <summary>
        /// 7天分一次表
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void SevenTime_Elapsed(object sender, ElapsedEventArgs e)
        {
            //获取当前的时间
            DateTime TimeNow = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd"));
            int SevenType = 1;
            Maticsoft.BLL.subtable BLlSubTable = new Maticsoft.BLL.subtable();
            var BLLModelList = BLlSubTable.GetModelList("Type='" + SevenType + "' Order By CreateTime Desc");
            // 存在数据
            if (BLLModelList.Count > 0)
            {
                // 倒叙查询第一条
                var FirstOne = BLLModelList.FirstOrDefault();
                // 获取最后一次插入的时间
                string LastCreate = FirstOne.CreateTime;
                DateTime LastCreateTime = DateTime.Parse(LastCreate);
                var GetTimeSpan = TimeNow - LastCreateTime;
                //var GetTimeSpan = TestTime - LastCreateTime;
                // 时差已经大于了30天进行分表数据
                if (GetTimeSpan.Days > 30)
                {
                    if (TimeNow.Month != LastCreateTime.Month)
                    {
                        SevenSubTable();
                    }
                }
            }
            else
            {
                // 从开始到现在没有进行添加过数据
                // 插入一条当前的时间
                Maticsoft.Model.subtable ModelSubTable = new Maticsoft.Model.subtable();
                ModelSubTable.CreateTime = DateTime.Now.ToString("yyyy-MM-dd");
                ModelSubTable.Type = 1;
                BLlSubTable.Add(ModelSubTable);
            }
        }
        /// <summary>
        /// 是否存在需要创建的表
        /// </summary>
        /// <returns></returns>
        public static int ConinusTableCreateTable(string CreateTableName)
        {
            int GetIsCreate = 1;
            //获取AppSetting字符串
            string GetAppSetting = ConfigurationManager.AppSettings["ConnectionString"];
            //AppSetting = "Server=116.255.207.148;User Id=test;Password=test;Persist Security Info=True;Database=infrared_net;Charset=utf8";
            int IndexOf = GetAppSetting.IndexOf("Database=");
            //Database = infrared_net; Charset = utf8
            GetAppSetting = GetAppSetting.Remove(0, IndexOf);
            int IndexOfX = GetAppSetting.IndexOf(";");
            //Database = infrared_net
            GetAppSetting = GetAppSetting.Remove(IndexOfX, GetAppSetting.Length - IndexOfX);
            GetAppSetting = GetAppSetting.Replace("Database", "");
            GetAppSetting = GetAppSetting.Replace("=", "");
            GetAppSetting = GetAppSetting.Trim(); /*infrared_net*/
            string Sql = "SELECT COUNT(*) as Count FROM information_schema.TABLES WHERE table_schema = '" + GetAppSetting + "' and table_name = '" + CreateTableName + "'";
            //执行Sql
            DataSet dataSet = ExQuerty(Sql);
            if (dataSet.Tables.Count > 0)
            {
                var TableOne = dataSet.Tables[0];
                GetIsCreate = Convert.ToInt32(TableOne.Rows[0]["Count"].ToString());
                if (dataSet.Tables.Count >= 1)
                {
                    // 获取第一个Table
                    var TableOnes = dataSet.Tables[0];
                    GetIsCreate = Convert.ToInt32(TableOne.Rows[0]["Count"].ToString());
                }
            }
            return GetIsCreate;
        }

        /// <summary>
        /// 查询返回DataSet
        /// </summary>
        /// <returns></returns>
        public static DataSet ExQuerty(string Sql)
        {
            DataSet dataSet = new DataSet();
            try
            {

                MySqlDataAdapter MySqlAdapter = new MySqlDataAdapter(Sql, AppSetting);
                MySqlAdapter.Fill(dataSet);
            }
            catch (Exception e)
            {

                string Msg = e.Message.ToString();
            }
            return dataSet;
        }

        public static int CreateTable(string Sql)
        {
            using (MySqlConnection connection = new MySqlConnection(AppSetting))
            {

                try
                {
                    connection.Open();
                    MySqlCommand sqlCommand = new MySqlCommand(Sql, connection);

                    int row = sqlCommand.ExecuteNonQuery();
                    connection.Close();
                    return row;
                }
                catch (Exception e)
                {

                    string Str = e.Message.ToString();
                }
                return 0;
            }
        }

        /// <summary>
        /// 月份分表
        /// </summary>
        public static void SubTableMonth()
        {
            Maticsoft.BLL.subtable BLlSubTable = new Maticsoft.BLL.subtable();
            var Data = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd"));

            var NewData = Data.AddMonths(-1);
            string SetTime = NewData.ToString("yyyyMM");
            string ContiunsCopy = ImageHisCopy + SetTime;
            int ContinusCount = ConinusTableCreateTable(ContiunsCopy);
            // 不存在当前的表;
            if (ContinusCount == 0)
            {
                // 将之前的表进行改名
                string EditSql = "alter table " + ImageHisCopy + " rename " + ContiunsCopy;
                int EditCount = CreateTable(EditSql);
                // 新名字
                string CreateSql = "CREATE TABLE   " + ImageHisCopy + "  SELECT * FROM " + ContiunsCopy + " WHERE 1=2 ";
                int CountNewTable = ConinusTableCreateTable(ImageHisCopy);
                if (CountNewTable == 0)
                {
                    int CreateCount = CreateTable(CreateSql);
                    // 数组定义创建的索引
                    List<string> IndexName = new List<string>()
                    {
                        "ALTER  TABLE "+ImageHisCopy+ " ADD  INDEX createtime (createtime)",
                        "ALTER  TABLE "+ImageHisCopy+ " ADD  INDEX recordid (recordid)",
                        "ALTER  TABLE "+ImageHisCopy+ " ADD  INDEX deviceid (deviceid)",
                        "ALTER  TABLE "+ImageHisCopy+ " ADD  INDEX valuemax (valuemax)",
                    };
                    for (int i = 0; i < IndexName.Count; i++)
                    {
                        string IndexNameI = IndexName[i].ToString();
                        CreateTable(IndexNameI);
                    }

                    Maticsoft.Model.subtable ModelSubTable = new Maticsoft.Model.subtable();
                    ModelSubTable.CreateTime = DateTime.Now.ToString("yyyy-MM-dd");
                    ModelSubTable.Type = 0;
                    BLlSubTable.Add(ModelSubTable);
                }
            }
        }

        /// <summary>
        /// 7 天分表
        /// </summary>
        public static void SevenSubTable()
        {
            Maticsoft.BLL.subtable BLlSubTable = new Maticsoft.BLL.subtable();
            var Data = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd"));
            var NewData = Data.AddMonths(-1);
            string SetTime = NewData.ToString("yyyyMM");
            string ContiunsCopy = DeviceHeartCopy + SetTime;
            int ContinusCount = ConinusTableCreateTable(ContiunsCopy);
            // 不存在当前的表;
            if (ContinusCount == 0)
            {
                // 将之前的表进行改名
                string EditSql = "alter table " + DeviceHeartCopy + " rename " + ContiunsCopy;
                int EditCount = CreateTable(EditSql);
                // 新名字
                string CreateSql = "CREATE TABLE   " + DeviceHeartCopy + "  SELECT * FROM " + ContiunsCopy + " WHERE 1=2 ";
                int CountNewTable = ConinusTableCreateTable(DeviceHeartCopy);
                if (CountNewTable == 0)
                {
                    int CreateCount = CreateTable(CreateSql);

                    // 数组定义创建的索引
                    List<string> IndexName = new List<string>()
                    {
                        "ALTER  TABLE "+DeviceHeartCopy+ " ADD  INDEX createtime (createtime)",
                        "ALTER  TABLE "+DeviceHeartCopy+ " ADD  INDEX deviceid (deviceid)",
                        "ALTER  TABLE "+DeviceHeartCopy+ " ADD  INDEX ppmax (ppmax)",
                    };
                    for (int i = 0; i < IndexName.Count; i++)
                    {
                        string IndexNameI = IndexName[i].ToString();
                        CreateTable(IndexNameI);
                    }

                    Maticsoft.Model.subtable ModelSubTable = new Maticsoft.Model.subtable();
                    ModelSubTable.CreateTime = DateTime.Now.ToString("yyyy-MM-dd");
                    ModelSubTable.Type = 1;
                    BLlSubTable.Add(ModelSubTable);
                }
            }
        }
    }
}