﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.UserServices
{
    public class SystemInfor
    {
        List<string[]> arealist = new List<string[]>();

        public List<string[]> Arealist
        {
            get { return arealist; }
            set { arealist = value; }
        }
        List<string[]> fenbulist = new List<string[]>();

        public List<string[]> Fenbulist
        {
            get { return fenbulist; }
            set { fenbulist = value; }
        }
        List<string[]> ywblist = new List<string[]>();

        public List<string[]> Ywblist
        {
            get { return ywblist; }
            set { ywblist = value; }
        }
        List<string[]> stationlist = new List<string[]>();

        public List<string[]> Stationlist
        {
            get { return stationlist; }
            set { stationlist = value; }
        }
        List<string[]> buildinglist = new List<string[]>();

        public List<string[]> Buildinglist
        {
            get { return buildinglist; }
            set { buildinglist = value; }
        }
        List<string[]> machinelist = new List<string[]>();

        public List<string[]> Machinelist
        {
            get { return machinelist; }
            set { machinelist = value; }
        }
        List<string[]> ysdlist = new List<string[]>();

        public List<string[]> Ysdlist
        {
            get { return ysdlist; }
            set { ysdlist = value; }
        }
        List<string[]> devicelist = new List<string[]>();

        public List<string[]> Devicelist
        {
            get { return devicelist; }
            set { devicelist = value; }
        }
    }
}