﻿using imfraredservices.ReportServic;
using imfraredservices.TableService;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace imfraredservices.UserServices
{
    public class UserAction
    {
        string area_name = "";
        string area_id = "";
        #region 根据名称获取id
        public string getidbyname(string name, string type)
        {
            string sreturn = "";
            if (type == "area")
            {
                List<Maticsoft.Model.area_infor> list = new List<Maticsoft.Model.area_infor>();
                Maticsoft.BLL.area_infor bll = new Maticsoft.BLL.area_infor();
                list = bll.GetModelList("areaname='" + name + "'");
                if (list.Count() > 0)
                {
                    sreturn = list[0].areaid;
                }
                else
                    sreturn = "";
            }
            if (type == "fenbu")
            {
                List<Maticsoft.Model.fenbu_infor> list = new List<Maticsoft.Model.fenbu_infor>();
                Maticsoft.BLL.fenbu_infor bll = new Maticsoft.BLL.fenbu_infor();
                list = bll.GetModelList("fenbuname='" + name + "'");
                if (list.Count() > 0)
                {
                    sreturn = list[0].fenbuid;
                }
                else
                    sreturn = "";
            }
            if (type == "ywb")
            {
                List<Maticsoft.Model.ywb_infor> list = new List<Maticsoft.Model.ywb_infor>();
                Maticsoft.BLL.ywb_infor bll = new Maticsoft.BLL.ywb_infor();
                list = bll.GetModelList("ywbname='" + name + "'");
                if (list.Count() > 0)
                {
                    sreturn = list[0].ywbid;
                }
                else
                    sreturn = "";
            }
            if (type == "station")
            {
                List<Maticsoft.Model.station_infor> list = new List<Maticsoft.Model.station_infor>();
                Maticsoft.BLL.station_infor bll = new Maticsoft.BLL.station_infor();
                list = bll.GetModelList("stationname='" + name + "'");
                if (list.Count() > 0)
                {
                    sreturn = list[0].stationid;
                }
                else
                    sreturn = "";
            }
            if (type == "building")
            {
                List<Maticsoft.Model.building_infor> list = new List<Maticsoft.Model.building_infor>();
                Maticsoft.BLL.building_infor bll = new Maticsoft.BLL.building_infor();
                list = bll.GetModelList("buildingname='" + name + "'");
                if (list.Count() > 0)
                {
                    sreturn = list[0].buildingid;
                }
                else
                    sreturn = "";
            }
            if (type == "machine")
            {
                List<Maticsoft.Model.machine_infor> list = new List<Maticsoft.Model.machine_infor>();
                Maticsoft.BLL.machine_infor bll = new Maticsoft.BLL.machine_infor();
                list = bll.GetModelList("machinename='" + name + "'");
                if (list.Count() > 0)
                {
                    sreturn = list[0].machineid;
                }
                else
                    sreturn = "";
            }
            return sreturn;
        }
        #endregion
        #region 城市接口
        public string getcityweather()
        {
            return "Hello World";
        }
        #endregion
        #region 工区
        Maticsoft.BLL.area_infor areaservice = new Maticsoft.BLL.area_infor();
        public string addarea(string areaname, string manager, string phone, string city, string address)
        {
            if (areaname == "" || areaname == null)
                return "工区名称不能为空";
            if (city == "" || city == null)
                return "城市不能为空";
            List<Maticsoft.Model.area_infor> arealist = new List<Maticsoft.Model.area_infor>();
            arealist = areaservice.GetModelList("");
            bool ishave = false;
            for (int i = 0; i < arealist.Count(); i++)
            {
                if (areaname == arealist[i].areaname)
                {
                    ishave = true;
                }
            }
            if (ishave)
            {
                return "工区名称已存在";
            }
            else
            {
                Maticsoft.Model.area_infor model = new Maticsoft.Model.area_infor();
                model.areaid = Guid.NewGuid().ToString("N");
                model.areaname = areaname;
                model.manager = manager;
                model.phone = phone;
                model.city = city;
                model.address = address;
                model.createtime = System.DateTime.Now;
                areaservice.Add(model);
                return "1";
            }
        }
        public string modifyarea(string areaname, string manager, string phone, string city, string address)
        {
            List<Maticsoft.Model.area_infor> arealist = new List<Maticsoft.Model.area_infor>();
            arealist = areaservice.GetModelList("");
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < arealist.Count(); i++)
            {
                if (areaname == arealist[i].areaname)
                {
                    sid = arealist[i].areaid;
                    ishave = true;
                }
            }
            if (!ishave)
            {
                return "修改失败";
            }
            else
            {
                Maticsoft.Model.area_infor model = new Maticsoft.Model.area_infor();
                model.areaid = sid;
                model.areaname = areaname;
                model.manager = manager;
                model.phone = phone;
                model.city = city;
                model.address = address;
                model.createtime = System.DateTime.Now;
                areaservice.Update(model);
                return "工区名称：" + areaname + "修改成功";
            }
        }
        public string deletearea(string sid)
        {

            areaservice.Delete(sid);
            return "删除成功";
        }
        public DataTable getAllarea(string userid)
        {
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = user.GetModel(userid);
            DataSet ds = new DataSet();

            if (usermodel == null)
                return null;
            else
            {
                area_id = usermodel.areaid;
                area_name = usermodel.areaname;
                if (usermodel.usertype == "0")
                {
                    ds = user.GetList("areaid='" + usermodel.areaid + "' group by areaname");

                }
                if (usermodel.usertype == "1")
                {
                    ds = user.GetList("fenbuid='" + usermodel.fenbuid + "' group by areaname");

                }
                if (usermodel.usertype == "2")
                {
                    ds = user.GetList("ywbid='" + usermodel.ywbid + "' group by areaname");

                }
                if (usermodel.usertype == "3")
                {
                   // string s="";
                   //ds = user.GetList("areaid!='"+s+"'  group by areaname");
                    Maticsoft.BLL.area_infor areaservice = new Maticsoft.BLL.area_infor();
                    ds = areaservice.GetList("");
                }
            }
            return ds.Tables[0];
        }
        public DataTable getareaByname(string id)
        {
            DataSet ds = areaservice.GetList("areaid='" + id + "'");
            return ds.Tables[0];
        }
        #endregion
        #region 分部
        Maticsoft.BLL.fenbu_infor fenbuservice = new Maticsoft.BLL.fenbu_infor();
        public string addfenbu(string areaname, string fenbuname, string manager, string phone, string address)
        {
            if (areaname == "" || areaname == null)
                return "请选择工区";
            if (fenbuname == "" || fenbuname == null)
                return "分部名称不能为空";
            List<Maticsoft.Model.fenbu_infor> fenbulist = new List<Maticsoft.Model.fenbu_infor>();
            fenbulist = fenbuservice.GetModelList("");
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < fenbulist.Count(); i++)
            {
                if (fenbuname == fenbulist[i].fenbuname)
                {
                    sid = fenbulist[i].fenbuid;
                    ishave = true;
                }
            }
            if (ishave)
            {
                return "分部名称已存在";
            }
            else
            {
                Maticsoft.Model.fenbu_infor model = new Maticsoft.Model.fenbu_infor();
                model.fenbuid = Guid.NewGuid().ToString("N");
                model.areaname = areaname;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuname = fenbuname;
                model.manager = manager;
                model.phone = phone;
                model.address = address;
                model.createtime = System.DateTime.Now;
                fenbuservice.Add(model);
                return "1";
            }
        }
        public string modifyfenbu(string areaname, string fenbuname, string manager, string phone, string address)
        {
            List<Maticsoft.Model.fenbu_infor> fenbulist = new List<Maticsoft.Model.fenbu_infor>();
            fenbulist = fenbuservice.GetModelList("");

            bool ishave = false;
            string sid = "";
            for (int i = 0; i < fenbulist.Count(); i++)
            {
                if (fenbuname == fenbulist[i].fenbuname)
                {
                    sid = fenbulist[i].fenbuid;
                    ishave = true;
                }
            }
            if (!ishave)
            {
                return "修改失败";
            }
            else
            {
                Maticsoft.Model.fenbu_infor model = new Maticsoft.Model.fenbu_infor();
                model.fenbuid = sid;
                model.areaname = areaname;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuname = fenbuname;
                model.manager = manager;
                model.phone = phone;
                model.address = address;
                model.createtime = System.DateTime.Now;
                fenbuservice.Update(model);
                return "分部名称：" + fenbuname + "修改成功";
            }
        }
        public string deletefenbu(string sid)
        {
            fenbuservice.Delete(sid);
            return "删除成功";
        }
        public DataTable getAllfenbu(string userid)
        {
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = user.GetModel(userid);
            DataSet ds = new DataSet();

            if (usermodel == null)
                return null;
            else
            {
                if (usermodel.usertype == "0")
                {
                    ds = fenbuservice.GetList("areaid='" + usermodel.areaid + "' ");

                }
                if (usermodel.usertype == "1")
                {
                    ds = fenbuservice.GetList("fenbuid='" + usermodel.fenbuid + "'");

                }
                if (usermodel.usertype == "2")
                {
                    ds = fenbuservice.GetList("ywbid='" + usermodel.ywbid + "'");

                }
                if (usermodel.usertype == "3")
                {
                    ds = fenbuservice.GetList("");

                }
            }
            return ds.Tables[0];
        }
        public DataTable getfenbuByarea(string areaid)
        {
            DataSet ds = fenbuservice.GetList("areaid='" + areaid + "'");
            return ds.Tables[0];
        }
        public DataTable getfenbuByname(string id)
        {
            DataSet ds = fenbuservice.GetList("fenbuid='" + id + "'");
            return ds.Tables[0];
        }
        #endregion
        #region 运维班
        Maticsoft.BLL.ywb_infor ywbservice = new Maticsoft.BLL.ywb_infor();
        public string addywb(string areaname, string fenbuname, string ywbname, string manager, string phone, string address)
        {
            if (areaname == "" || areaname == null)
                return "添请选择工区";
            if (fenbuname == "" || fenbuname == null)
                return "请选择分部";
            if (ywbname == "" || ywbname == null)
                return "运维班名称不能为空";
            List<Maticsoft.Model.ywb_infor> ywblist = new List<Maticsoft.Model.ywb_infor>();
            ywblist = ywbservice.GetModelList("");
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < ywblist.Count(); i++)
            {
                if (ywbname == ywblist[i].ywbname)
                {
                    sid = ywblist[i].ywbid;
                    ishave = true;
                }
            }
            if (ishave)
            {
                return "运维班名称已存在";
            }
            else
            {
                Maticsoft.Model.ywb_infor model = new Maticsoft.Model.ywb_infor();
                model.ywbid = Guid.NewGuid().ToString("N");
                model.areaname = areaname;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.manager = manager;
                model.phone = phone;
                model.address = address;
                model.createtime = System.DateTime.Now;
                ywbservice.Add(model);
                return "1";
            }
        }
        public string modifyywb(string areaname, string fenbuname, string ywbname, string manager, string phone, string address)
        {
            List<Maticsoft.Model.ywb_infor> ywblist = new List<Maticsoft.Model.ywb_infor>();
            ywblist = ywbservice.GetModelList("");

            bool ishave = false;
            string sid = "";
            for (int i = 0; i < ywblist.Count(); i++)
            {
                if (ywbname == ywblist[i].ywbname)
                {
                    sid = ywblist[i].ywbid;
                    ishave = true;
                }
            }
            if (!ishave)
            {
                return "修改失败";
            }
            else
            {
                Maticsoft.Model.ywb_infor model = new Maticsoft.Model.ywb_infor();
                model.ywbid = sid;
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbname = ywbname;
                model.manager = manager;
                model.phone = phone;
                model.address = address;
                model.createtime = System.DateTime.Now;
                ywbservice.Update(model);
                return "运维班名称：" + ywbname + "修改成功";
            }
        }
        public string deleteywb(string sid)
        {

            ywbservice.Delete(sid);
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            stationlist = stationservice.GetModelList("ywbid='"+sid+"'");
            for(int i=0;i<stationlist.Count();i++)
            {
                stationservice.Delete(stationlist[i].stationid);
            }
            List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
            buildinglist = buildingservice.GetModelList("ywbid='" + sid + "'");
            for(int i=0;i<buildinglist.Count();i++)
            {
                buildingservice.Delete(buildinglist[i].buildingid);
            }
            List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
            machinelist = machineservice.GetModelList("ywbid='" + sid + "'");
            for(int i=0;i<machinelist.Count();i++)
            {
                machineservice.Delete(machinelist[i].machineid);
            }
            List<Maticsoft.Model.ysd_infor> ysdlist = new List<Maticsoft.Model.ysd_infor>();
            ysdlist = ysdservice.GetModelList("ywbid='" + sid + "'");
            for(int i=0;i<ysdlist.Count();i++)
            {
                ysdservice.Delete(ysdlist[i].ysdid);
            }
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            devicelist = deviceservice.GetModelList("ywbid='" + sid + "'");
            for (int i = 0; i < devicelist.Count();i++ )
            {
                deviceservice.Delete(devicelist[i].deviceid);
            }
                return "删除成功";

        }
        public DataTable getAllywb(string userid)
        {
            Maticsoft.BLL.user_infor user = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = user.GetModel(userid);
            DataSet ds = new DataSet();

            if (usermodel == null)
                return null;
            else
            {
                if (usermodel.usertype == "0")
                {
                    ds = ywbservice.GetList("areaid='" + usermodel.areaid + "' ");

                }
                if (usermodel.usertype == "1")
                {
                    ds = ywbservice.GetList("fenbuid='" + usermodel.fenbuid + "'");

                }
                if (usermodel.usertype == "2")
                {
                    ds = ywbservice.GetList("ywbid='" + usermodel.ywbid + "'");

                }
                if (usermodel.usertype == "3")
                {
                    ds = ywbservice.GetList("");

                }
            }
            return ds.Tables[0];
        }
        public DataTable getywbByarea(string areaid)
        {
            return ywbservice.GetList("areaid='" + areaid + "'").Tables[0];
        }
        public DataTable getywbByfenbu(string fenbuid)
        {
            return ywbservice.GetList("fenbuid='" + fenbuid + "'").Tables[0];
        }
        public DataTable getywbByname(string id)
        {
            return ywbservice.GetList("ywbid='" + id + "'").Tables[0];
        }
        public DataTable getywbBuser(string userid)
        {
            Maticsoft.BLL.user_infor s1 = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor m1 = new Maticsoft.Model.user_infor();
            m1 = s1.GetModel(userid);
            if (m1 == null)
            {
                return null;
            }
            else
            {
                DataTable dt = new DataTable();
                if (m1.usertype == "0")
                {
                    dt = ywbservice.GetList("areaid='" + m1.areaid + "'").Tables[0];

                }

                if (m1.usertype == "1")
                {
                    dt = ywbservice.GetList("fenbuid='" + m1.fenbuid + "'").Tables[0];

                }
                if (m1.usertype == "2")
                {
                    dt = ywbservice.GetList("ywbid='" + m1.ywbid + "'").Tables[0];

                }
                if (m1.usertype == "3")
                {
                    dt = ywbservice.GetList("").Tables[0];

                }
                return dt;
            }

        }
        #endregion
        #region 用户
        Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
        public string adduser(string areaname, string fenbuname, string ywbname, string username, string password, string usertype, string city, string manager, string phone)
        {
            if (usertype == "" || usertype == null)
                return "请选择用户类型";
            if(usertype=="0")
            {
                if (areaname == "" || areaname == null)
                    return "请选择工区";
            }
            if(usertype=="1")
            {
                if (areaname == "" || areaname == null)
                    return "请选择工区";
                if (fenbuname == "" || fenbuname == null)
                    return "请选择分部";
            }
            if (usertype == "2")
            {
                if (areaname == "" || areaname == null)
                    return "请选择工区";
                if (fenbuname == "" || fenbuname == null)
                    return "请选择分部";
                if (ywbname == "" || ywbname == null)
                    return "请选择运维班";
            }
            if (username == "" || username == null)
                return "用户名称不能为空";
            

            List<Maticsoft.Model.user_infor> userlist = new List<Maticsoft.Model.user_infor>();
            userlist = userservice.GetModelList("");
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < userlist.Count(); i++)
            {
                if ((username == userlist[i].username))
                {
                    sid = userlist[i].userid;
                    ishave = true;
                }
            }
            if (ishave)
            {
                return "改级别下已存在同名用户";
            }
            else
            {
                Maticsoft.Model.user_infor model = new Maticsoft.Model.user_infor();
                model.userid = Guid.NewGuid().ToString("N");
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbid = getidbyname(ywbname, "ywb");
                model.username = username;
                model.password = password;
                model.usertype = usertype;
                model.city = city;
                model.manager = manager;
                model.phone = phone;
                model.createtime = System.DateTime.Now;
                userservice.Add(model);
                return "1";
            }
        }
        public string changepassword(string areaname, string fenbuname, string ywbname, string username, string oldpass, string newpass, string newpassrepeat)
        {
            List<Maticsoft.Model.user_infor> userlist = new List<Maticsoft.Model.user_infor>();
            userlist = userservice.GetModelList("");

            bool ishave = false;
            string sid = "";
            string oldpass1 = "";
            string usertype = "";
            string city = "";
            string manager = "";
            string phone = "";
            for (int i = 0; i < userlist.Count(); i++)
            {
                if ((username == userlist[i].username))
                {
                    oldpass1 = userlist[i].password;
                    usertype = userlist[i].usertype;
                    city = userlist[i].city;
                    manager = userlist[i].manager;
                    phone = userlist[i].phone;
                    sid = userlist[i].userid;
                    ishave = true;
                }
            }
            if (ishave)
            {
                if (oldpass == oldpass1)
                {
                    if (newpass == newpassrepeat)
                    {
                        Maticsoft.Model.user_infor model = new Maticsoft.Model.user_infor();
                        model.userid = sid;
                        model.areaname = areaname;
                        model.fenbuname = fenbuname;
                        model.ywbname = ywbname;
                        model.areaid = getidbyname(areaname, "area");
                        model.fenbuid = getidbyname(fenbuname, "fenbu");
                        model.ywbid = getidbyname(ywbname, "ywb");
                        model.username = username;
                        model.password = newpass;
                        model.usertype = usertype;
                        model.city = city;
                        model.manager = manager;
                        model.phone = phone;
                        model.createtime = System.DateTime.Now;
                        userservice.Update(model);
                        return "用户名称：" + username + "修改成功";
                    }
                    else
                    {
                        return "输入的两次新密码不匹配";
                    }
                }
                else
                {
                    return "原密码不正确";
                }
            }
            else
            {
                return "用户不存在";
            }
        }
        public string modifyuser(string areaname, string fenbuname, string ywbname, string username, string password, string usertype, string city, string manager, string phone,string oldusername)
        {
            List<Maticsoft.Model.user_infor> userlist = new List<Maticsoft.Model.user_infor>();
            userlist = userservice.GetModelList("");
       
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < userlist.Count(); i++)
            {
                if ((oldusername == userlist[i].username))
                {
                    sid = userlist[i].userid;
                    ishave = true;
                }
            }
            if (!ishave)
            {
                return "修改失败";
            }
            else
            {
                Maticsoft.Model.user_infor model = new Maticsoft.Model.user_infor();
                model.userid = sid;
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbid = getidbyname(ywbname, "ywb");
                model.username = username;
                model.password = password;
                model.usertype = usertype;
                model.city = city;
                model.manager = manager;
                model.phone = phone;
                model.createtime = System.DateTime.Now;
                userservice.Update(model);
                return "用户名称：" + username + "修改成功";
            }
        }
        public string deleteuser(string sid)
        {

            userservice.Delete(sid);
            return "删除成功";
        }
        public DataTable getAlluser(string userid)
        {
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("userid", Type.GetType("System.String"));
            dt.Columns.Add("areaid", Type.GetType("System.String"));
            dt.Columns.Add("areaname", Type.GetType("System.String"));
            dt.Columns.Add("fenbuid", Type.GetType("System.String"));
            dt.Columns.Add("fenbuname", Type.GetType("System.String"));
            dt.Columns.Add("ywbid", Type.GetType("System.String"));
            dt.Columns.Add("ywbname", Type.GetType("System.String"));
            dt.Columns.Add("username", Type.GetType("System.String"));
            dt.Columns.Add("password", Type.GetType("System.String"));
            dt.Columns.Add("usertype", Type.GetType("System.String"));
            dt.Columns.Add("show", Type.GetType("System.String"));
            dt.Columns.Add("city", Type.GetType("System.String"));
            dt.Columns.Add("manager", Type.GetType("System.String"));
            dt.Columns.Add("phone", Type.GetType("System.String"));
            dt.Columns.Add("createtime", Type.GetType("System.String"));
            Maticsoft.Model.user_infor usmodel = new Maticsoft.Model.user_infor();
            usmodel = userservice.GetModel(userid);
            DataSet ds = new DataSet();

            if(usmodel.usertype=="3")
            {
                ds= userservice.GetList("");
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    string isshow = "1";
                    dt.Rows.Add(new object[] { ds.Tables[0].Rows[i]["userid"].ToString(), ds.Tables[0].Rows[i]["areaid"].ToString(), ds.Tables[0].Rows[i]["areaname"].ToString(), ds.Tables[0].Rows[i]["fenbuid"].ToString(), ds.Tables[0].Rows[i]["fenbuname"].ToString(), ds.Tables[0].Rows[i]["ywbid"].ToString(), ds.Tables[0].Rows[i]["ywbname"].ToString(), ds.Tables[0].Rows[i]["username"].ToString(), ds.Tables[0].Rows[i]["password"].ToString(), ds.Tables[0].Rows[i]["usertype"].ToString(), isshow, ds.Tables[0].Rows[i]["city"].ToString(), ds.Tables[0].Rows[i]["manager"].ToString(), ds.Tables[0].Rows[i]["phone"].ToString(), ds.Tables[0].Rows[i]["createtime"].ToString(), });
                }
            }
            else
            {
                ds = userservice.GetList("areaid='" + usmodel.areaid + "'");
                if (usmodel.usertype == "0")
                {

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string isshow = "1";
                        dt.Rows.Add(new object[] { ds.Tables[0].Rows[i]["userid"].ToString(), ds.Tables[0].Rows[i]["areaid"].ToString(), ds.Tables[0].Rows[i]["areaname"].ToString(), ds.Tables[0].Rows[i]["fenbuid"].ToString(), ds.Tables[0].Rows[i]["fenbuname"].ToString(), ds.Tables[0].Rows[i]["ywbid"].ToString(), ds.Tables[0].Rows[i]["ywbname"].ToString(), ds.Tables[0].Rows[i]["username"].ToString(), ds.Tables[0].Rows[i]["password"].ToString(), ds.Tables[0].Rows[i]["usertype"].ToString(), isshow, ds.Tables[0].Rows[i]["city"].ToString(), ds.Tables[0].Rows[i]["manager"].ToString(), ds.Tables[0].Rows[i]["phone"].ToString(), ds.Tables[0].Rows[i]["createtime"].ToString(), });
                    }
                }
                if (usmodel.usertype == "1")
                {

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        if (ds.Tables[0].Rows[i]["usertype"].ToString() == "0")
                        {
                            dt.Rows.Add(new object[] { ds.Tables[0].Rows[i]["userid"].ToString(), ds.Tables[0].Rows[i]["areaid"].ToString(), ds.Tables[0].Rows[i]["areaname"].ToString(), ds.Tables[0].Rows[i]["fenbuid"].ToString(), ds.Tables[0].Rows[i]["fenbuname"].ToString(), ds.Tables[0].Rows[i]["ywbid"].ToString(), ds.Tables[0].Rows[i]["ywbname"].ToString(), ds.Tables[0].Rows[i]["username"].ToString(), ds.Tables[0].Rows[i]["password"].ToString(), ds.Tables[0].Rows[i]["usertype"].ToString(), "0", ds.Tables[0].Rows[i]["city"].ToString(), ds.Tables[0].Rows[i]["manager"].ToString(), ds.Tables[0].Rows[i]["phone"].ToString(), ds.Tables[0].Rows[i]["createtime"].ToString(), });
                        }

                        else
                        {
                            dt.Rows.Add(new object[] { ds.Tables[0].Rows[i]["userid"].ToString(), ds.Tables[0].Rows[i]["areaid"].ToString(), ds.Tables[0].Rows[i]["areaname"].ToString(), ds.Tables[0].Rows[i]["fenbuid"].ToString(), ds.Tables[0].Rows[i]["fenbuname"].ToString(), ds.Tables[0].Rows[i]["ywbid"].ToString(), ds.Tables[0].Rows[i]["ywbname"].ToString(), ds.Tables[0].Rows[i]["username"].ToString(), ds.Tables[0].Rows[i]["password"].ToString(), ds.Tables[0].Rows[i]["usertype"].ToString(), "1", ds.Tables[0].Rows[i]["city"].ToString(), ds.Tables[0].Rows[i]["manager"].ToString(), ds.Tables[0].Rows[i]["phone"].ToString(), ds.Tables[0].Rows[i]["createtime"].ToString(), });
                        }
                    }
                }
                if (usmodel.usertype == "2")
                {

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string type = ds.Tables[0].Rows[i]["usertype"].ToString();
                        if (ds.Tables[0].Rows[i]["usertype"].ToString() == "0")
                        {
                            dt.Rows.Add(new object[] { ds.Tables[0].Rows[i]["userid"].ToString(), ds.Tables[0].Rows[i]["areaid"].ToString(), ds.Tables[0].Rows[i]["areaname"].ToString(), ds.Tables[0].Rows[i]["fenbuid"].ToString(), ds.Tables[0].Rows[i]["fenbuname"].ToString(), ds.Tables[0].Rows[i]["ywbid"].ToString(), ds.Tables[0].Rows[i]["ywbname"].ToString(), ds.Tables[0].Rows[i]["username"].ToString(), ds.Tables[0].Rows[i]["password"].ToString(), ds.Tables[0].Rows[i]["usertype"].ToString(), "0", ds.Tables[0].Rows[i]["city"].ToString(), ds.Tables[0].Rows[i]["manager"].ToString(), ds.Tables[0].Rows[i]["phone"].ToString(), ds.Tables[0].Rows[i]["createtime"].ToString(), });
                        }
                        else if (ds.Tables[0].Rows[i]["usertype"].ToString() == "1")
                        {
                            dt.Rows.Add(new object[] { ds.Tables[0].Rows[i]["userid"].ToString(), ds.Tables[0].Rows[i]["areaid"].ToString(), ds.Tables[0].Rows[i]["areaname"].ToString(), ds.Tables[0].Rows[i]["fenbuid"].ToString(), ds.Tables[0].Rows[i]["fenbuname"].ToString(), ds.Tables[0].Rows[i]["ywbid"].ToString(), ds.Tables[0].Rows[i]["ywbname"].ToString(), ds.Tables[0].Rows[i]["username"].ToString(), ds.Tables[0].Rows[i]["password"].ToString(), ds.Tables[0].Rows[i]["usertype"].ToString(), "0", ds.Tables[0].Rows[i]["city"].ToString(), ds.Tables[0].Rows[i]["manager"].ToString(), ds.Tables[0].Rows[i]["phone"].ToString(), ds.Tables[0].Rows[i]["createtime"].ToString(), });
                        }
                        else
                        {
                            dt.Rows.Add(new object[] { ds.Tables[0].Rows[i]["userid"].ToString(), ds.Tables[0].Rows[i]["areaid"].ToString(), ds.Tables[0].Rows[i]["areaname"].ToString(), ds.Tables[0].Rows[i]["fenbuid"].ToString(), ds.Tables[0].Rows[i]["fenbuname"].ToString(), ds.Tables[0].Rows[i]["ywbid"].ToString(), ds.Tables[0].Rows[i]["ywbname"].ToString(), ds.Tables[0].Rows[i]["username"].ToString(), ds.Tables[0].Rows[i]["password"].ToString(), ds.Tables[0].Rows[i]["usertype"].ToString(), "1", ds.Tables[0].Rows[i]["city"].ToString(), ds.Tables[0].Rows[i]["manager"].ToString(), ds.Tables[0].Rows[i]["phone"].ToString(), ds.Tables[0].Rows[i]["createtime"].ToString(), });
                        }
                    }
                }
            }
            return dt;
            
        }
        public DataTable getuserByarea(string areaid)
        {
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("userid", Type.GetType("System.String"));
            dt.Columns.Add("areaid", Type.GetType("System.String"));
            dt.Columns.Add("areaname", Type.GetType("System.String"));
            dt.Columns.Add("fenbuid", Type.GetType("System.String"));
            dt.Columns.Add("fenbuname", Type.GetType("System.String"));
            dt.Columns.Add("ywbid", Type.GetType("System.String"));
            dt.Columns.Add("ywbname", Type.GetType("System.String"));
            dt.Columns.Add("username", Type.GetType("System.String"));
            dt.Columns.Add("password", Type.GetType("System.String"));
            dt.Columns.Add("usertype", Type.GetType("System.String"));
            dt.Columns.Add("show", Type.GetType("System.String"));
            dt.Columns.Add("city", Type.GetType("System.String"));
            dt.Columns.Add("manager", Type.GetType("System.String"));
            dt.Columns.Add("phone", Type.GetType("System.String"));
            dt.Columns.Add("createtime", Type.GetType("System.String"));
            Maticsoft.Model.area_infor aremodel = new Maticsoft.Model.area_infor();
            aremodel = areaservice.GetModel(areaid);
           
            DataSet ds = new DataSet();
            ds = userservice.GetList("areaid='" + areaid + "'");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                string isshow = "1";
                dt.Rows.Add(new object[] { ds.Tables[0].Rows[i]["userid"].ToString(), ds.Tables[0].Rows[i]["areaid"].ToString(), ds.Tables[0].Rows[i]["areaname"].ToString(), ds.Tables[0].Rows[i]["fenbuid"].ToString(), ds.Tables[0].Rows[i]["fenbuname"].ToString(), ds.Tables[0].Rows[i]["ywbid"].ToString(), ds.Tables[0].Rows[i]["ywbname"].ToString(), ds.Tables[0].Rows[i]["username"].ToString(), ds.Tables[0].Rows[i]["password"].ToString(), ds.Tables[0].Rows[i]["usertype"].ToString(), isshow, ds.Tables[0].Rows[i]["city"].ToString(), ds.Tables[0].Rows[i]["manager"].ToString(), ds.Tables[0].Rows[i]["phone"].ToString(), ds.Tables[0].Rows[i]["createtime"].ToString(), });
            }
            
            return dt;
        }
        public DataTable getuserByfenbu(string fenbuid)
        {
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("userid", Type.GetType("System.String"));
            dt.Columns.Add("areaid", Type.GetType("System.String"));
            dt.Columns.Add("areaname", Type.GetType("System.String"));
            dt.Columns.Add("fenbuid", Type.GetType("System.String"));
            dt.Columns.Add("fenbuname", Type.GetType("System.String"));
            dt.Columns.Add("ywbid", Type.GetType("System.String"));
            dt.Columns.Add("ywbname", Type.GetType("System.String"));
            dt.Columns.Add("username", Type.GetType("System.String"));
            dt.Columns.Add("password", Type.GetType("System.String"));
            dt.Columns.Add("usertype", Type.GetType("System.String"));
            dt.Columns.Add("show", Type.GetType("System.String"));
            dt.Columns.Add("city", Type.GetType("System.String"));
            dt.Columns.Add("manager", Type.GetType("System.String"));
            dt.Columns.Add("phone", Type.GetType("System.String"));
            dt.Columns.Add("createtime", Type.GetType("System.String"));
            
            DataSet ds = new DataSet();

        
                    ds = userservice.GetList("fenbuid='" + fenbuid + "'");

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                            dt.Rows.Add(new object[] { ds.Tables[0].Rows[i]["userid"].ToString(), ds.Tables[0].Rows[i]["areaid"].ToString(), ds.Tables[0].Rows[i]["areaname"].ToString(), ds.Tables[0].Rows[i]["fenbuid"].ToString(), ds.Tables[0].Rows[i]["fenbuname"].ToString(), ds.Tables[0].Rows[i]["ywbid"].ToString(), ds.Tables[0].Rows[i]["ywbname"].ToString(), ds.Tables[0].Rows[i]["username"].ToString(), ds.Tables[0].Rows[i]["password"].ToString(), ds.Tables[0].Rows[i]["usertype"].ToString(), "1", ds.Tables[0].Rows[i]["city"].ToString(), ds.Tables[0].Rows[i]["manager"].ToString(), ds.Tables[0].Rows[i]["phone"].ToString(), ds.Tables[0].Rows[i]["createtime"].ToString(), });
                    }
              
            return dt;
        }
        public DataTable getuserByywb(string ywbname)
        {
            return userservice.GetList("ywbname='" + ywbname + "'").Tables[0];
        }
        public DataTable getuserByname(string id)
        {

            return userservice.GetList("userid='" + id + "'").Tables[0];
        }
        #endregion
        #region 变电站
        Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
        Maticsoft.BLL.city_infor cityservice = new Maticsoft.BLL.city_infor();
        public void editcity(string city, string ywbid, string ywbname, string jingdu, string weidu)
        {

            List<Maticsoft.Model.city_infor> citylist = new List<Maticsoft.Model.city_infor>();
            citylist = cityservice.GetModelList("");
            bool ishave = false;
            for (int i = 0; i < citylist.Count(); i++)
            {
                if (ywbid == citylist[i].ywbid)
                {
                    ishave = true;
                }
            }
            if (ishave)
            {
                return;
            }
            else
            {
                Maticsoft.Model.city_infor model = new Maticsoft.Model.city_infor();
                model.cityid = Guid.NewGuid().ToString("N");
                model.ywbid = ywbid;
                model.ywbname = ywbname;
                model.cityname = city;
                model.devicetopvalue = "";
                model.citytemputer = "";
                model.weatnerinfor = "";
                model.weather = "";
                model.humidity = "";
                model.windspeed = "";
                model.jingdu = jingdu;
                model.weidu = weidu;
                cityservice.Add(model);
            }
        }
        public void updatecity(string city, string ywbid, string ywbname, string jingdu, string weidu)
        {
            List<Maticsoft.Model.city_infor> citylist = new List<Maticsoft.Model.city_infor>();
            citylist = cityservice.GetModelList("");
            bool ishave = false;
            string id = "";
            for (int i = 0; i < citylist.Count(); i++)
            {
                if (ywbid == citylist[i].ywbid)
                {
                    ishave = true;
                    id = citylist[i].cityid;
                }
            }
            if (ishave)
            {
                Maticsoft.Model.city_infor model = new Maticsoft.Model.city_infor();
                model.cityid = id;
                model.ywbid = ywbid;
                model.ywbname = ywbname;
                model.cityname = city;
                model.devicetopvalue = "";
                model.citytemputer = "";
                model.weatnerinfor = "";
                model.weather = "";
                model.humidity = "";
                model.windspeed = "";
                model.jingdu = jingdu;
                model.weidu = weidu;
                cityservice.Update(model);
            }

        }
        public string addstation(string areaname, string fenbuname, string ywbname, string stationname, string manager, string phone, string stationlevel, string city, string address, string jingdu, string weidu)
        {
            if (areaname == "" || areaname == null)
                return "请选择工区";
            if (fenbuname == "" || fenbuname == null)
                return "请选择分部";
            if (ywbname == "" || ywbname == null)
                return "添请选择运维班";
            if (stationname == "" || stationname == null)
                return "变电真名称不能为空";
            if (city == "" || city == null)
                return "城市不能为空";

            //此处更新城市列表
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            stationlist = stationservice.GetModelList("");
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < stationlist.Count(); i++)
            {
                if (stationname == stationlist[i].stationname)
                {
                    sid = stationlist[i].stationid;
                    ishave = true;
                }
            }
            if (ishave)
            {
                return "添加的变电站名称已存在";
            }
            else
            {
                Maticsoft.Model.station_infor model = new Maticsoft.Model.station_infor();
                model.stationid = Guid.NewGuid().ToString("N");
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbid = getidbyname(ywbname, "ywb");
                string ywbid = getidbyname(ywbname, "ywb");
                model.stationname = stationname;
                model.manager = manager;
                model.phone = phone;
                model.stationlevel = stationlevel;
                model.city = city;
                model.address = address;
                model.jingdu = jingdu;
                model.weidu = weidu;
                model.topvalue = "0";
                model.alarmcount = "0";
                model.createtime = System.DateTime.Now;
                stationservice.Add(model);
                Maticsoft.BLL.shortname_infor sname = new Maticsoft.BLL.shortname_infor();
                Maticsoft.Model.shortname_infor smodel = new Maticsoft.Model.shortname_infor();
                smodel.nameid = model.stationid;
                smodel.nameold = stationname;
                smodel.namenew1 = stationname;
                smodel.namenew2 = stationname;
                smodel.namenew3 = stationname;
                sname.Add(smodel);
                editcity(city, ywbid, ywbname, jingdu, weidu);
                return "1";
            }
        }
        public string modifystation(string areaname, string fenbuname, string ywbname, string stationname, string manager, string phone, string stationlevel, string city, string address, string jingdu, string weidu)
        {
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            stationlist = stationservice.GetModelList("");
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < stationlist.Count(); i++)
            {
                if (stationname == stationlist[i].stationname)
                {
                    sid = stationlist[i].stationid;
                    ishave = true;
                }
            }
            if (!ishave)
            {
                return "修改失败";
            }
            else
            {
                Maticsoft.Model.station_infor model = new Maticsoft.Model.station_infor();
                model.stationid = sid;
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbid = getidbyname(ywbname, "ywb");
                string ywbid = getidbyname(ywbname, "ywb");
                model.stationname = stationname;
                model.manager = manager;
                model.phone = phone;
                model.stationlevel = stationlevel;
                model.city = city;
                model.address = address;
                model.jingdu = jingdu;
                model.weidu = weidu;
                model.topvalue = "";
                model.alarmcount = "";
                model.createtime = System.DateTime.Now;
                stationservice.Update(model);
                updatecity(city, ywbid, ywbname, jingdu, weidu);
                return "变电站名称：" + stationname + "修改成功";
            }
        }
        public string deletestation(string sid)
        {
            stationservice.Delete(sid);
            List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
            buildinglist = buildingservice.GetModelList("stationid='" + sid + "'");
            for (int i = 0; i < buildinglist.Count(); i++)
            {
                buildingservice.Delete(buildinglist[i].buildingid);
            }
            List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
            machinelist = machineservice.GetModelList("stationid='" + sid + "'");
            for (int i = 0; i < machinelist.Count(); i++)
            {
                machineservice.Delete(machinelist[i].machineid);
            }
            List<Maticsoft.Model.ysd_infor> ysdlist = new List<Maticsoft.Model.ysd_infor>();
            ysdlist = ysdservice.GetModelList("stationid='" + sid + "'");
            for (int i = 0; i < ysdlist.Count(); i++)
            {
                ysdservice.Delete(ysdlist[i].ysdid);
            }
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            devicelist = deviceservice.GetModelList("stationid='" + sid + "'");
            for (int i = 0; i < devicelist.Count(); i++)
            {
                deviceservice.Delete(devicelist[i].deviceid);
            }
            return "删除成功";
        }
        public void updatestation(string userid)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
                return;
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> modellist = new List<Maticsoft.Model.station_infor>();
            if (usermodel.usertype == "0")
            {
                modellist = stationservice.GetModelList("areaid='" + usermodel.areaid + "'");
            }
            if (usermodel.usertype == "1")
            {
                modellist = stationservice.GetModelList("fenbuid='" + usermodel.fenbuid + "'");
            }
            if (usermodel.usertype == "2")
            {
                modellist = stationservice.GetModelList("ywbid='" + usermodel.ywbid + "'");
            }
            if (usermodel.usertype == "3")
            {
                modellist = stationservice.GetModelList("");

            }
            for (int i = 0; i < modellist.Count(); i++)
            {
                updatedevice(modellist[i].stationid);
            }
        }
        public void updatedevice(string stationid)
        {
             Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
                Maticsoft.Model.station_infor model = new Maticsoft.Model.station_infor();
                model = stationservice.GetModel(stationid);
             double nowtopold = 0;
            string today = "0";
            string yestoday = "0";
            string week = "0";
            string month = "0";
            string history = "0";
            string id1 = "";
            string id2 = ""; string id3 = ""; string id4 = ""; string id5 = "";
            Maticsoft.BLL.device_infor devservice = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devlist = new List<Maticsoft.Model.device_infor>();
            devlist = devservice.GetModelList("stationid='" + stationid + "'");
            if (devlist.Count() > 0)
            {
                List<double> todaynowlist = new List<double>(); todaynowlist.Add(0);
                List<string> todaynowid = new List<string>(); todaynowid.Add("");
                List<double> todaylist = new List<double>(); todaylist.Add(0);
                List<string> todayid = new List<string>(); todayid.Add("");
                List<double> yestodaylist = new List<double>(); yestodaylist.Add(0);
                List<string> yestodayid = new List<string>(); yestodayid.Add("");
                List<double> weeklist = new List<double>(); weeklist.Add(0);
                List<string> weekid = new List<string>(); weekid.Add("");
                List<double> monthlist = new List<double>(); monthlist.Add(0);
                List<string> monthid = new List<string>(); monthid.Add("");
                List<double> historylist = new List<double>(); historylist.Add(0);
                List<string> historyid = new List<string>(); historyid.Add("");

                int cunt = devlist.Count > 1 ? 2 : 1; 

                for (int i = 0; i < cunt; i++)
                {
                    double devicemax = 0;
                    if(devlist[i].todaymax!=""&&devlist[i].todaymax!=null)
                    {
                        devicemax = double.Parse(devlist[i].todaymax);
                    }

                    if (model.topvalue != "" && model.topvalue != null)
                    {
                        nowtopold = double.Parse(model.topvalue);
                    }
                    else
                    {
                        nowtopold = 0.0;
                    }
                    if(devicemax>=nowtopold)
                    {
                        getidhis(devlist[i].deviceid);

                    }
                   

                    //update_device_state stateac = new update_device_state();
                    //stateac.UpdateDevice(devlist[i].deviceid);
                    if (devlist[i].todaytop != "" && devlist[i].todaytop != null && devlist[i].todaytop != "0")
                    {
                        todaynowlist.Add(double.Parse(devlist[i].todaytop));
                        todaynowid.Add(devlist[i].todaymaxid);
                    }
                    if (devlist[i].todaymax != "" && devlist[i].todaymax != null && devlist[i].todaymax != "0")
                    {
                        todaylist.Add(double.Parse(devlist[i].todaymax));
                        todayid.Add(devlist[i].todaymaxid);
                    }
                    if (devlist[i].yestodaytop != "" && devlist[i].yestodaytop != null && devlist[i].yestodaytop != "0"&&!string.IsNullOrEmpty(devlist[i].yestodaytop))
                    {
                        yestodaylist.Add(double.Parse(devlist[i].yestodaytop));
                        yestodayid.Add(devlist[i].yestodaymaxid);
                    }
                    if (devlist[i].weektop != "" && devlist[i].weektop != null && devlist[i].weektop != "0")
                    {
                        weeklist.Add(double.Parse(devlist[i].weektop));
                        weekid.Add(devlist[i].weekmaxid);
                    }
                    if (devlist[i].monthmax != "" && devlist[i].monthmax != null && devlist[i].monthmax != "0")
                    {
                        monthlist.Add(double.Parse(devlist[i].monthmax));
                        monthid.Add(devlist[i].monthmaxid);
                    }
                    if (devlist[i].historytop != "" && devlist[i].historytop != null && devlist[i].historytop != "0")
                    {
                        historylist.Add(double.Parse(devlist[i].historytop));
                        historyid.Add(devlist[i].historymaxid);
                    }
                }
                string nowtop = todaynowlist.Max().ToString();
                today = todaylist.Max().ToString();
                id1 = todayid[getMaxindex(todaylist)];
                yestoday = yestodaylist.Max().ToString();
                id2 = yestodayid[getMaxindex(yestodaylist)];
                week = weeklist.Max().ToString();
                id3 = weekid[getMaxindex(weeklist)];
                month = monthlist.Max().ToString();
                id4 = monthid[getMaxindex(monthlist)];
                history = historylist.Max().ToString();
                id5 = historyid[getMaxindex(historylist)];
                string topflag="";
                string nowflag = "";
                if (todaylist.Max() >= yestodaylist.Max())
                    topflag = "0";
                else
                    topflag = "1";
               
              
                if(todaynowlist.Max()>=nowtopold)
                {
                    nowflag = "0";
                }
                else
                {
                    nowflag = "1";
                }
                stationservice.UpdateHistoryValue(stationid, nowtop, today, yestoday, week, month, history, id1, id2, id3, id4, id5, topflag,nowflag);
            }

        }
        public void getidhis(string deviceid)
        {
            string todaymax = "";
            string todaymaxid = "";
            List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            historylist = historyservice.GetModelList("deviceid='" + deviceid + "' and createtime > '" + System.DateTime.Now.Date.ToString() + "'");
            if (historylist.Count > 0)
            {
               
                List<double> templisttoday = new List<double>();
                templisttoday.Add(0);
                List<string> todayidlist = new List<string>();
                todayidlist.Add("");
                for (int i = 0; i < historylist.Count; i++)
                {
                    
                    if (historylist[i].createtime.Value.Ticks > System.DateTime.Now.Date.Ticks)
                    {
                        if (historylist[i].valuemax != "" && historylist[i].valuemax != null)
                        {
                            templisttoday.Add(double.Parse(historylist[i].valuemax));
                            todayidlist.Add(historylist[i].recordid);
                        }
                    }
                }
                todaymax = templisttoday.Max().ToString();
                todaymaxid = todayidlist[getMaxindex(templisttoday)];


            }

            historylist = null;
            deviceservice.UpdateHistorytodaymax(deviceid,todaymax,todaymaxid);
        }
        public int getMaxindex(List<double> list)
        {
            double a = list[0];
            int index = 0;//把假设的最大值索引赋值非index
            for (int i = 1; i < list.Count; i++)
            {
                if (list[i] > a)
                {
                    a = list[i];
                    index = i;//把较大值的索引赋值非index
                }
            }
            return index;
        }
        public int getMax(List<int> list)
        {
            int a = list[0];         
            for (int i = 1; i < list.Count; i++)
            {
                if (list[i] > a)
                {
                    a = list[i];                  
                }
            }
            return a;
        }
        public DataTable getAllstation(string userid)
        {
            //updatestation(userid);

            Maticsoft.BLL.user_infor s1 = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor m1 = new Maticsoft.Model.user_infor();
            m1 = s1.GetModel(userid);
            if (m1 == null)
            {
                return null;
            }
            else
            {
                area_id = m1.areaid;
                area_name = m1.areaname;
                DataTable dt = new DataTable();
                if (m1.usertype == "0")
                {
                    dt = stationservice.GetList("areaid='" + m1.areaid + "' order by CAST(topvalue AS  DECIMAL) desc").Tables[0];
                }
                if (m1.usertype == "1")
                {
                    dt = stationservice.GetList("fenbuid='" + m1.fenbuid + "' order by CAST(topvalue AS  DECIMAL) desc").Tables[0];
                }
                if (m1.usertype == "2")
                {
                    dt = stationservice.GetList("ywbid='" + m1.ywbid + "' order by CAST(topvalue AS  DECIMAL) desc").Tables[0];
                }
                if (m1.usertype == "3")
                {
                    dt = stationservice.GetList("1=1  order by CAST(topvalue AS  DECIMAL) desc").Tables[0];
                }
                Maticsoft.BLL.device_infor devservice = new Maticsoft.BLL.device_infor();
                Maticsoft.Model.device_infor devmodel = new Maticsoft.Model.device_infor();
                List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
                string todaytopmax = "";
                string todaytop = "";
                string todayid = "";             
                Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
                List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
                string isok = "1";
                string alarmcount = "0";
                List<int> DeleteValue = new List<int>();

                string GetMonth = DateTime.Now.ToString("yyyy-MM");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    alarmlist = alarmservice.GetModelList("stationid = '" + dt.Rows[i]["stationid"].ToString() + "'" + " and createtime>'" + GetMonth + "'" + " And IsOk='" + isok + "'");

                    //IEnumerator
                    if (alarmlist.Count > 0)
                    {
                        alarmcount = alarmlist.Count.ToString();
                    }
                    else
                    {
                        dt.Rows[i]["alarmcount"] = "0";
                    }                                 
                    //删除没有设备的变电站 
                    Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                    int count = machineservice.GetRecordCount("stationid = '" + dt.Rows[i]["stationid"].ToString() + "'");
                    int machinemac = machineservice.GetRecordCount("machinemac = '" + "' and stationid = '" + dt.Rows[i]["stationid"].ToString() + "'");
                    if (machinemac == count)
                    {
                        //dt.Rows.RemoveAt(i);
                        DeleteValue.Add(i);
                        continue;
                    }

                    //统计变电站下的今日最高温和当前最高温
                    Maticsoft.Model.station_infor stationmodel = stationservice.GetModel(dt.Rows[i]["stationid"].ToString());
                    todayid = stationmodel.todayid;
                    Maticsoft.BLL.image_record_history hisservice = new Maticsoft.BLL.image_record_history();
                    devicelist = devservice.GetModelList(" stationid='" + dt.Rows[i]["stationid"].ToString() + "'");
                    List<double> device_todaytop = new List<double>(); device_todaytop.Add(0.0);
                    if (devicelist.Count > 0)
                    {
                        for (int k = 0; k < devicelist.Count; k++)
                        {
                            if (devicelist[k].todaytop != "")
                            {
                                device_todaytop.Add(double.Parse(devicelist[k].todaytop));

                            }
                        }
                    }
                    if (device_todaytop.Count > 0)
                    {
                        todaytopmax = device_todaytop.Max().ToString("0.0");
                    }
                    if (todaytopmax != "")
                    {
                        if (stationmodel.todaytop == "")
                        {
                            stationmodel.todaytop = "0.0";
                            todaytop = "0.0";

                        }
                        if (double.Parse(todaytopmax) >= double.Parse(stationmodel.todaytop))
                        {
                            stationmodel.todaytop = todaytopmax;
                            todaytop = todaytopmax;
                            if (double.Parse(stationmodel.topvalue) >= double.Parse(stationmodel.todaytop))
                            {
                                stationmodel.todaytop = stationmodel.topvalue;
                                todaytopmax = stationmodel.topvalue;
                                todaytop = stationmodel.topvalue;
                            }
                            dt.Rows[i]["todaytop"] = stationmodel.todaytop;
                            devicelist = devservice.GetModelList(" stationid='" + dt.Rows[i]["stationid"].ToString() + "' and todaytop='" + todaytopmax + "'");
                            if (devicelist.Count > 0)
                            {
                                List<Maticsoft.Model.image_record_history> hismodellist = new List<Maticsoft.Model.image_record_history>();
                                hismodellist = hisservice.GetModelList("deviceid = '" + devicelist[0].deviceid + "' and valuemax = '" + todaytopmax + "' order by createtime desc ");
                                if (hismodellist.Count > 0)
                                {
                                    stationmodel.todayid = hismodellist[0].recordid;
                                    todayid = hismodellist[0].recordid;

                                    stationmodel.todaytop = hismodellist[0].valuemax;
                                    todaytop = hismodellist[0].valuemax;
                                }
                            }
                        }
                    }
                    bool falg = stationservice.UpdateTodayTopValue(dt.Rows[i]["stationid"].ToString(), stationmodel.topvalue, todaytop, todayid);
                    if (!falg)
                    {
                        stationservice.Update(stationmodel);
                    }
                }

                if (DeleteValue.Count >= 1)
                {
                    // 倒叙删除
                    for (int i = DeleteValue.Count - 1; i >= 0; i--)
                    {
                        var Value = DeleteValue[i];
                        dt.Rows.RemoveAt(DeleteValue[i]);
                    }                   
                }

                //  获取所有的变电站信息 通过变电站信息获取要显示的值
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Maticsoft.BLL.alarm_push_infor ModelAlarmservice = new Maticsoft.BLL.alarm_push_infor();
                    var GetStationid = dt.Rows[i]["stationid"].ToString();                   
                    var GetModelListValue = ModelAlarmservice.GetModelList(" stationid= " + "'" + GetStationid + "'" + " and  createtime>'" + GetMonth + "' And IsOk=1");
                    int Count = GetModelListValue.Count;
                    dt.Rows[i]["alarmcount"] = Count;
                }
                return dt;
            }
        }
        public DataTable getstationByarea(string areaid)
        {
            return stationservice.GetList("areaid='" + areaid + "'").Tables[0];
        }
        public DataTable getstationByfenbu(string fenbuid)
        {
            return stationservice.GetList("fenbuid='" + fenbuid + "'").Tables[0];
        }
        public DataTable getstationByywb(string ywbid)
        {
            return stationservice.GetList("ywbid='" + ywbid + "'").Tables[0];
        }
        public DataTable getstationByname(string id)
        {
            return stationservice.GetList("stationid='" + id + "'").Tables[0];
        }
        public DataTable getstationByUserid(string userid)
        {
            // updatestation(userid);
            Maticsoft.BLL.user_infor usss = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor um = new Maticsoft.Model.user_infor();
            um = usss.GetModel(userid);
            if (um == null)
                return null;
            area_id = um.areaid;
            area_name = um.areaname;
            DataTable dt = new DataTable();
            Maticsoft.BLL.device_infor devservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devmodel = new Maticsoft.Model.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            string todaytopmax = "";
            string todaytop = "";
            string todayid = "";
            string topdayvalue = "";

            if (um.usertype == "0")
            {
                dt = stationservice.GetList("areaid='" + um.areaid + "'").Tables[0];
            }
            if (um.usertype == "1")
            {
                dt = stationservice.GetList("fenbuid='" + um.fenbuid + "'").Tables[0];
            }
            if (um.usertype == "2")
            {
                dt = stationservice.GetList("ywbid='" + um.ywbid + "'").Tables[0];
            }
            if (um.usertype == "3")
            {
                dt = stationservice.GetList("").Tables[0];
            }
            publicAction.getShortName pa = new publicAction.getShortName();
            dt.Columns.Add("stationshortname1", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname2", Type.GetType("System.String"));
            dt.Columns.Add("stationshortname3", Type.GetType("System.String"));          

            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
            string isok = "1";
            string alarmcount = "0";
            List<int> DeleteValue = new List<int>();

            string GetMonth = DateTime.Now.ToString("yyyy-MM");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                alarmlist = alarmservice.GetModelList("stationid = '" + dt.Rows[i]["stationid"].ToString()+"'"+" and createtime>'"+GetMonth+ "'"+ " And IsOk='"+isok+"'");

                //IEnumerator
                if (alarmlist.Count >0)
                {
                    alarmcount = alarmlist.Count.ToString();
                }
                else
                {
                    dt.Rows[i]["alarmcount"] = "0";
                }
                string s1 = dt.Rows[i]["stationid"].ToString().Split(',')[0];
                dt.Rows[i]["stationshortname1"] = pa.getshortname(dt.Rows[i]["stationid"].ToString()).Split(',')[0];
                dt.Rows[i]["stationshortname2"] = pa.getshortname(dt.Rows[i]["stationid"].ToString()).Split(',')[1];
                dt.Rows[i]["stationshortname3"] = pa.getshortname(dt.Rows[i]["stationid"].ToString()).Split(',')[2];
                //删除没有设备的变电站 
                Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                int count = machineservice.GetRecordCount("stationid = '" + dt.Rows[i]["stationid"].ToString() + "'");
                int machinemac = machineservice.GetRecordCount("machinemac = '" + "' and stationid = '" + dt.Rows[i]["stationid"].ToString() + "'");
                if (machinemac == count)
                {
                    //dt.Rows.RemoveAt(i);
                    DeleteValue.Add(i);
                    continue;
                }

                //统计变电站下的今日最高温和当前最高温
                Maticsoft.Model.station_infor stationmodel = stationservice.GetModel(dt.Rows[i]["stationid"].ToString());
                 todayid = stationmodel.todayid;
                Maticsoft.BLL.image_record_history hisservice = new Maticsoft.BLL.image_record_history();
                devicelist = devservice.GetModelList(" stationid='" + dt.Rows[i]["stationid"].ToString() + "'");
                List<double> device_todaytop = new List<double>(); device_todaytop.Add(0.0);
                if (devicelist.Count > 0)
                {
                    for (int k = 0; k < devicelist.Count; k++)
                    {
                        if (devicelist[k].todaytop!="")
                        {
                             device_todaytop.Add(double.Parse(devicelist[k].todaytop));

                        }
                    }
                }
                if (device_todaytop.Count > 0)
                {
                    todaytopmax = device_todaytop.Max().ToString("0.0");
                }
                if (todaytopmax != "")
                {
                    if (stationmodel.todaytop =="")
                    {
                        stationmodel.todaytop = "0.0";
                        todaytop = "0.0";

                    }
                    if (double.Parse(todaytopmax) >= double.Parse(stationmodel.todaytop))
                    {
                        stationmodel.todaytop = todaytopmax;
                        todaytop= todaytopmax;
                        if (double.Parse(stationmodel.topvalue) >= double.Parse(stationmodel.todaytop))
                        {
                            stationmodel.todaytop = stationmodel.topvalue;
                            todaytopmax = stationmodel.topvalue;
                            todaytop= stationmodel.topvalue;
                        }
                        dt.Rows[i]["todaytop"] = stationmodel.todaytop;
                        devicelist = devservice.GetModelList(" stationid='" + dt.Rows[i]["stationid"].ToString() + "' and todaytop='" + todaytopmax + "'");
                        if (devicelist.Count > 0)
                        {
                            List<Maticsoft.Model.image_record_history> hismodellist = new List<Maticsoft.Model.image_record_history>();
                            hismodellist = hisservice.GetModelList("deviceid = '" + devicelist[0].deviceid + "' and valuemax = '" + todaytopmax + "' order by createtime desc ");
                            if (hismodellist.Count > 0)
                            {
                                stationmodel.todayid = hismodellist[0].recordid;
                                todayid= hismodellist[0].recordid;

                                stationmodel.todaytop = hismodellist[0].valuemax;
                                todaytop= hismodellist[0].valuemax;
                            }
                        }
                    }
                }
                bool falg = stationservice.UpdateTodayTopValue(dt.Rows[i]["stationid"].ToString(), stationmodel.topvalue, todaytop,todayid);
                if(!falg){
                    stationservice.Update(stationmodel);
                }
            }

            if (DeleteValue.Count>=1)
            {
                // 倒叙删除
                for (int i = DeleteValue.Count-1; i >=0 ; i--)
                {
                    var Value = DeleteValue[i];
                    dt.Rows.RemoveAt(DeleteValue[i]);
                }
                //for (int i = 0; i < DeleteValue.Count; i++)
                //{
                //    dt.Rows.RemoveAt(DeleteValue[i]);
                //}
            }

            //  获取所有的变电站信息 通过变电站信息获取要显示的值
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Maticsoft.BLL.alarm_push_infor ModelAlarmservice = new Maticsoft.BLL.alarm_push_infor();
                var GetStationid = dt.Rows[i]["stationid"].ToString();
                if (dt.Rows[i]["stationname"].ToString() == "瀛洲变")
                {

                }
                var GetModelListValue=ModelAlarmservice.GetModelList(" stationid= "+ "'"+GetStationid+"'"+" and  createtime>'"+ GetMonth+"' And IsOk=1");
                int Count = GetModelListValue.Count;
                dt.Rows[i]["alarmcount"] = Count;
            }
            var NewDataTable = dt;
           return NewDataTable;
        }
        #endregion
        #region 设备区
        Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
        public string addbuilding(string areaname, string fenbuname, string ywbname, string stationnane, string buildingname)
        {
            if (areaname == "" || areaname == null)
                return "请选择工区";
            if (fenbuname == "" || fenbuname == null)
                return "请选择分部";
            if (ywbname == "" || ywbname == null)
                return "请选择运维班";
            if (stationnane == "" || stationnane == null)
                return "添请选择变电站";
            if (buildingname == "" || buildingname == null)
                return "添设备区名称不能为空";
            List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
            buildinglist = buildingservice.GetModelList("");
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < buildinglist.Count(); i++)
            {
                if ((buildinglist[i].buildingname == buildingname) && (buildinglist[i].stationname == stationnane))
                {
                    sid = buildinglist[i].buildingid;
                    ishave = true;
                }
            }
            if (ishave)
            {
                return "添加的设备区名称已存在";

            }
            else
            {
                Maticsoft.Model.building_infor model = new Maticsoft.Model.building_infor();
                model.buildingid = Guid.NewGuid().ToString("N");
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.stationname = stationnane;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbid = getidbyname(ywbname, "ywb");
                model.stationid = getidbyname(stationnane, "station");
                model.buildingname = buildingname;
                model.topvalue = "0.0";
                model.alarmcount = "0";
                model.createtime = System.DateTime.Now;
                buildingservice.Add(model);
                return "1";
            }
        }

        public string modifybuilding(string areaname, string fenbuname, string ywbname, string stationnane, string buildingname,string buildingid)
        {
            List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
            Maticsoft.Model.building_infor buildmodel = new Maticsoft.Model.building_infor();
            buildmodel = buildingservice.GetModel(buildingid);
            if (buildmodel != null)
            {
                Maticsoft.Model.building_infor model = new Maticsoft.Model.building_infor();
                model.buildingid = buildmodel.buildingid;
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.stationname = stationnane;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbid = getidbyname(ywbname, "ywb");
                model.stationid = getidbyname(stationnane, "station");
                model.buildingname = buildingname;
                model.topvalue = "0.0";
                model.alarmcount = "0";
                model.createtime = System.DateTime.Now;
                buildingservice.Update(model);
                updateysdAnddevice(buildingid, buildingname,buildmodel.buildingid);
                return "设备区名称：" + buildingname + "修改成功";

            }
            else
                return "修改失败";

        }
        public string getidbubuildingname(string buildingname)
        {
            string sid = "";
            List<Maticsoft.Model.building_infor> buildinglist = new List<Maticsoft.Model.building_infor>();
            buildinglist = buildingservice.GetModelList("buildingname='"+buildingname+"'");
            if (buildinglist.Count > 0)
                sid = buildinglist[0].buildingid;
            return sid;
        }
        public void updateysdAnddevice(string buildingid,string buildingname,string idnew)
        {
            deviceservice.UpdateBuilding(buildingid,buildingname,idnew);
            ysdservice.UpdateBuilding1(buildingid, buildingname,idnew);
            machineservice.UpdateBuilding1(buildingid, buildingname,idnew);

        }

        public string deletebuilding(string sid)
        {


            buildingservice.Delete(sid);
            List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
            machinelist = machineservice.GetModelList("buildingid='" + sid + "'");
            for (int i = 0; i < machinelist.Count(); i++)
            {
                machineservice.Delete(machinelist[i].machineid);
            }
            List<Maticsoft.Model.ysd_infor> ysdlist = new List<Maticsoft.Model.ysd_infor>();
            ysdlist = ysdservice.GetModelList("buildingid='" + sid + "'");
            for (int i = 0; i < ysdlist.Count(); i++)
            {
                ysdservice.Delete(ysdlist[i].ysdid);
            }
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            devicelist = deviceservice.GetModelList("buildingid='" + sid + "'");
            for (int i = 0; i < devicelist.Count(); i++)
            {
                deviceservice.Delete(devicelist[i].deviceid);
            }
            return "删除成功";

        }

        public DataTable getAllbuilding(string userid)
        {
            Maticsoft.BLL.user_infor s1 = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor m1 = new Maticsoft.Model.user_infor();
            m1 = s1.GetModel(userid);
            if (m1 == null)
            {
                return null;
            }
            else
            {
                DataTable dt = new DataTable();
                if (m1.usertype == "0")
                {
                    dt = buildingservice.GetList("areaid='" + m1.areaid + "'").Tables[0];

                }

                if (m1.usertype == "1")
                {
                    dt = buildingservice.GetList("fenbuid='" + m1.fenbuid + "'").Tables[0];

                }
                if (m1.usertype == "2")
                {
                    dt = buildingservice.GetList("ywbid='" + m1.ywbid + "'").Tables[0];

                }
                if (m1.usertype == "3")
                {
                    dt = buildingservice.GetList("").Tables[0];

                }
                return dt;
            }

        }

        public DataTable getbuildingByarea(string areaid)
        {
            return buildingservice.GetList("areaid='" + areaid + "'").Tables[0];


        }

        public DataTable getbuildingByfenbu(string fenbuid)
        {
            return buildingservice.GetList("fenbuid='" + fenbuid + "'").Tables[0];
        }

        public DataTable getbuildingByywb(string ywbid)
        {
            return buildingservice.GetList("ywbid='" + ywbid + "'").Tables[0];
        }

        public DataTable getbuildingBystation(string stationid)
        {
            return buildingservice.GetList("stationid='" + stationid + "'").Tables[0];
        }

        public DataTable getbuildingByname(string id)
        {
            return buildingservice.GetList("buildingid='" + id + "'").Tables[0];

        }
        #endregion
        #region 抓拍设备
        Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
        public string addmachine(string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename,
            string machinecompany, string machinemac, string machinecode, string currentversion, string offsetvalue,string machineip,string mediaIndex)
        {
            //if (string.IsNullOrEmpty(areaname))
            //{
            //    return "请选择工区";
            //}

            if (areaname == "" || areaname == null)
            {
                return "请选择工区";
            }

            if (fenbuname == "" || fenbuname == null)
                return "请添加选择分部";
            if (ywbname == "" || ywbname == null)
                return "请添选择运维班";
            if (stationname == "" || stationname == null)
                return "请选择变电站";
            if (buildingname == "" || buildingname == null)
                return "请选择设备区";
            if (machinename == "" || machinename == null)
                return "添设备名称不能为空";
            if (machinecode == "" || machinecode == null)
                return "设备编号不能为空";
            if (mediaIndex == "" || mediaIndex == null)
                return "设备推流不能为空";
            List<Maticsoft.Model.machine_infor> machinelist = new List<Maticsoft.Model.machine_infor>();
            machinelist = machineservice.GetModelList("");
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < machinelist.Count(); i++)
            {
                if (machinecode == machinelist[i].machinecode)
                {
                    sid = machinelist[i].machineid;
                    ishave = true;
                }
            }
            if (ishave)
            {
                return "抓拍设备安装编号已存在";
            }
            else
            {
                Maticsoft.Model.machine_infor model = new Maticsoft.Model.machine_infor();
                model.machineid = Guid.NewGuid().ToString("N");
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.stationname = stationname;
                model.buildingname = buildingname;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbid = getidbyname(ywbname, "ywb");
                model.stationid = getidbyname(stationname, "station");
                DataSet ds1 = buildingservice.GetList("buildingname='" + buildingname + "' and stationname='" + stationname + "'");
                if (ds1.Tables[0].Rows.Count > 0)
                    model.buildingid = ds1.Tables[0].Rows[0]["buildingid"].ToString();
                model.machinename = machinename;
                model.machinecompany = machinecompany;
                model.machinemac = machinemac;
                model.machinecode = machinecode;
                model.currentversion = currentversion;
                model.newversion = "0";
                model.machinestate = "在线";
                model.onlinetime = System.DateTime.Now;
                model.imagecatchspan = "0";
                model.wifiname = "0";
                model.wifipass = "0";
 //               model.fushelv = fushelv;
                model.offsetvalue = offsetvalue;
                model.buchang = "0";
                //model.
                model.runtime = machineip;
                model.createtime = System.DateTime.Now;
                machineservice.Add(model);
                UpdateCompany_infor(machinecompany, "", currentversion);
                return "1"+"#"+model.machineid;
            }

        }

        public void UpdateCompany_infor(string companyname, string devicetype, string verson)
        {
            Maticsoft.BLL.company_infor cs = new Maticsoft.BLL.company_infor();
            List<Maticsoft.Model.company_infor> cmlist = new List<Maticsoft.Model.company_infor>();
            cmlist = cs.GetModelList("");
            bool ishave = false;
            for (int i = 0; i < cmlist.Count(); i++)
            {
                string sname = cmlist[i].companyname;
                if (companyname == sname)
                {
                    ishave = true;
                }
            }
            if (ishave)
                return;
            else
            {
                Maticsoft.Model.company_infor model = new Maticsoft.Model.company_infor();
                model.companyid = Guid.NewGuid().ToString("N");
                model.companyname = companyname;
                model.deviceType = devicetype;
                model.deviceVerson = verson;
                cs.Add(model);
            }
        }

        public string modifymachine(string machineid,string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename,
           string machinecompany, string machinemac, string machinecode, string currentversion, string onlinetime, string offsetvalue, string machineip)
        {
            Maticsoft.Model.machine_infor mcmodel = new Maticsoft.Model.machine_infor();
            mcmodel = machineservice.GetModel(machineid);
            Maticsoft.Model.machine_infor model = new Maticsoft.Model.machine_infor();
            model.machineid = machineid;
            model.areaname = areaname;
            model.fenbuname = fenbuname;
            model.ywbname = ywbname;
            model.stationname = stationname;
            model.buildingname = buildingname;
            model.areaid = mcmodel.areaid;
            model.fenbuid = mcmodel.fenbuid;
            model.ywbid = mcmodel.ywbid;
            model.stationid = mcmodel.stationid;
            model.buildingid = getidbubuildingname(buildingname);
            string buildingid = getidbubuildingname(buildingname);
            model.machinename = machinename;
            model.machinecompany = machinecompany;
            model.machinemac = machinemac;
            model.machinecode = machinecode;
            model.installcode = "1.0";
            model.currentversion = currentversion;
            model.newversion = "0";
            if (machinemac == "")
            {
                model.machinestate = "拆除";
            }
            else
            {
                model.machinestate = "在线";
            }
            DateTime dt;
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
            dt = Convert.ToDateTime(onlinetime, dtFormat);
            model.onlinetime = dt;
            model.imagecatchspan = "0";
            model.wifiname = "";
            model.wifipass = "";
//            model.fushelv = fushelv;
            model.offsetvalue = offsetvalue;
            model.runtime = machineip;
            model.buchang = "0";
            machineservice.Update(model);
            updateysdAnddevice1(mcmodel.buildingid, buildingname, buildingid, machineid);

            return "抓拍设备：" + machinename + "修改成功";
        }
        public void updateysdAnddevice1(string buildingid, string buildingname, string idnew,string machineid)
        {
           
            ysdservice.UpdateBuilding(buildingid, buildingname, idnew,machineid);
            deviceservice.UpdateBuilding1(buildingid, buildingname, idnew,machineid);


        }
        public string deletemachine(string sid)
        {
            machineservice.Delete(sid);
            List<Maticsoft.Model.ysd_infor> ysdlist = new List<Maticsoft.Model.ysd_infor>();
            ysdlist = ysdservice.GetModelList("machineid='" + sid + "'");
            for (int i = 0; i < ysdlist.Count(); i++)
            {
                ysdservice.Delete(ysdlist[i].ysdid);
            }
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            devicelist = deviceservice.GetModelList("machineid='" + sid + "'");
            for (int i = 0; i < devicelist.Count(); i++)
            {
                deviceservice.Delete(devicelist[i].deviceid);
            }
            return "删除成功";
        }

        public DataTable getAllmachine(string userid)
        {
            Maticsoft.BLL.user_infor s1 = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor m1 = new Maticsoft.Model.user_infor();
            m1 = s1.GetModel(userid);
            if (m1 == null)
            {
                return null;
            }
            else
            {
                DataTable dt = new DataTable();
                if (m1.usertype == "0")
                {
                    dt = machineservice.GetList("areaid='" + m1.areaid + "' order by installcode asc").Tables[0];
                }
                if (m1.usertype == "1")
                {
                    dt = machineservice.GetList("fenbuid='" + m1.fenbuid + "' order by installcode asc").Tables[0];
                }
                if (m1.usertype == "2")
                {
                    dt = machineservice.GetList("ywbid='" + m1.ywbid + "' order by installcode asc").Tables[0];
                }
                if (m1.usertype == "3")
                {
                    dt = machineservice.GetList("").Tables[0];
                }
                return dt;
            }
        }

        public DataTable getmachineByarea(string areaid)
        {
            return machineservice.GetList("areaid='" + areaid + "'   order by installcode asc").Tables[0];
        }

        public DataTable getmachineByfenbu(string fenbuid)
        {
            return machineservice.GetList("fenbuid='" + fenbuid + "'  order by installcode asc").Tables[0];
        }

        public DataTable getmachineByywb(string ywbid)
        {
            return machineservice.GetList("ywbid='" + ywbid + "'  order by installcode asc").Tables[0];

        }

        public DataTable getmachineBystation(string stationid)
        {
            return machineservice.GetList("stationid='" + stationid + "' order by installcode asc").Tables[0];

        }

        public DataTable getmachineBybuilding(string buildingid)
        {
            return machineservice.GetList("buildingid='" + buildingid + "' order by installcode asc").Tables[0];
        }

        public DataTable getmachineByname(string id)
        {
            return machineservice.GetList(" machineid='" + id + "' order by installcode asc").Tables[0];

        }
        #endregion
        #region 预设点
        Maticsoft.BLL.ysd_infor ysdservice = new Maticsoft.BLL.ysd_infor();
        public string addysd(string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename, string ysdindex)
        {
            if (areaname == "" || areaname == null)
                return "请选择工区";
            if (fenbuname == "" || fenbuname == null)
                return "请选择分部";
            if (ywbname == "" || ywbname == null)
                return "添请选择运维班";
            if (stationname == "" || stationname == null)
                return "添请选择变电站";
            if (buildingname == "" || buildingname == null)
                return "添请选择设备区";
            if (machinename == "" || machinename == null)
                return "请选择红外设备";
            if (ysdindex == "" || ysdindex == null)
                return "预设点不能为空";
            List<Maticsoft.Model.ysd_infor> ysdlist = new List<Maticsoft.Model.ysd_infor>();
            ysdlist = ysdservice.GetModelList("");
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < ysdlist.Count(); i++)
            {
                if (stationname == ysdlist[i].stationname && buildingname == ysdlist[i].buildingname && machinename == ysdlist[i].machinename && ysdindex == ysdlist[i].ysdname)
                {
                    sid = ysdlist[i].ysdid;
                    ishave = true;
                }
            }
            if (ishave)
            {
                return "该预设点名称已存在";
            }
            else
            {
                Maticsoft.Model.ysd_infor model = new Maticsoft.Model.ysd_infor();
                model.ysdid = Guid.NewGuid().ToString("N");
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.stationname = stationname;
                model.buildingname = buildingname;
                model.machinename = machinename;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbid = getidbyname(ywbname, "ywb");
                model.stationid = getidbyname(stationname, "station");
                DataSet ds1 = buildingservice.GetList("buildingname='" + buildingname + "' and stationname='" + stationname + "'");
                if (ds1.Tables[0].Rows.Count > 0)
                    model.buildingid = ds1.Tables[0].Rows[0]["buildingid"].ToString();
                model.machineid = getmachineidbyname(stationname, buildingname, machinename, "machine");
                model.ysdname = ysdindex;
                model.orderindex = double.Parse(ysdindex);
                model.createtime = System.DateTime.Now;
                ysdservice.Add(model);
                UpdateYsdNUmbers();
                return "1";
            }
        }
        public string addysd_OneKey(string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename, string ysdNumbers)
        {         
            int name = 0;
            if (areaname == "" || areaname == null)
                return "请选择工区";
            if (fenbuname == "" || fenbuname == null)
                return "请选择分部";
            if (ywbname == "" || ywbname == null)
                return "添请选择运维班";
            if (stationname == "" || stationname == null)
                return "添请选择变电站";
            if (buildingname == "" || buildingname == null)
                return "添请选择设备区";
            if (machinename == "" || machinename == null)
                return "请选择红外设备";
            if (ysdNumbers == "" || ysdNumbers == null)
            {
                return "预设点个数不能为空";
            }
            DataSet ds = ysdservice.GetList("areaname='" + areaname + "' and fenbuname='" + fenbuname + "' and ywbname = '" + ywbname + "' and stationname='" + stationname + "' and buildingname='" + buildingname + "' and machinename ='" + machinename + "'");
            int length =  int.Parse(ds.Tables[0].Rows.Count.ToString());
            if (length > 0)
            {
                List<int> ysdnamelist = new List<int>();ysdnamelist.Add(0);
                for (int d = 0; d < length;d++ )
                {
                    ysdnamelist.Add( int.Parse(ds.Tables[0].Rows[d]["ysdname"].ToString()));
                }
                name = getMax(ysdnamelist);
               // ysdname = ds.Tables[0].Rows[0]["ysdname"].ToString();
            }          
            for (int i = 0; i < int.Parse(ysdNumbers); i++)
            {
                Maticsoft.Model.ysd_infor model = new Maticsoft.Model.ysd_infor();
                model.ysdid = Guid.NewGuid().ToString("N");
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.stationname = stationname;
                model.buildingname = buildingname;
                model.machinename = machinename;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbid = getidbyname(ywbname, "ywb");
                model.stationid = getidbyname(stationname, "station");
                DataSet ds1 = buildingservice.GetList("buildingname='" + buildingname + "' and stationname='" + stationname + "'");
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    model.buildingid = ds1.Tables[0].Rows[0]["buildingid"].ToString();
                }
                model.machineid = getmachineidbyname(stationname, buildingname, machinename, "machine");
                name +=1;
                model.ysdname = name.ToString();
                model.orderindex = i+1;
                model.createtime = System.DateTime.Now;
                ysdservice.Add(model);
            }
            UpdateYsdNUmbers();
              
                return "1";
            
        }
        public string getmachineidbyname(string name1, string name2, string name3, string type)
        {
            string sreturn = "";
            if (type == "machine")
            {
                List<Maticsoft.Model.machine_infor> list = new List<Maticsoft.Model.machine_infor>();
                Maticsoft.BLL.machine_infor bll = new Maticsoft.BLL.machine_infor();
                list = bll.GetModelList("stationname='" + name1 + "' and buildingname='" + name2 + "' and machinename='" + name3 + "'");
                if (list.Count() > 0)
                {
                    sreturn = list[0].machineid;
                }
                else
                    sreturn = "";
            }
            return sreturn;
        }
        public void UpdateYsdNUmbers()
        {
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            List<Maticsoft.Model.machine_infor> machinemodel = new List<Maticsoft.Model.machine_infor>();
            Maticsoft.BLL.ysd_infor ysdservice = new Maticsoft.BLL.ysd_infor();

            machinemodel = machineservice.GetModelList("");
            for (int i = 0; i < machinemodel.Count(); i++)
            {
                string machineid = machinemodel[i].machineid;
                List<Maticsoft.Model.ysd_infor> ysdlist = new List<Maticsoft.Model.ysd_infor>();
                ysdlist = ysdservice.GetModelList("machineid='" + machineid + "'");
                int ncount = ysdlist.Count();
                machineservice.UpdateYsdCount(machineid, ncount.ToString());

            }
        }
        public string modifyysd(string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename, string ysdindex)
        {

            {
                List<Maticsoft.Model.ysd_infor> ysdlist = new List<Maticsoft.Model.ysd_infor>();
                ysdlist = ysdservice.GetModelList("stationname='"+stationname+"' and machinename='"+machinename+"' and ysdname='"+ysdindex+"'");
                string ysdid = "";
                if (ysdlist.Count() > 0)
                    ysdid = ysdlist[0].ysdid;
                Maticsoft.Model.ysd_infor ysdmodel = new Maticsoft.Model.ysd_infor();
                ysdmodel = ysdservice.GetModel(ysdid);
                Maticsoft.Model.ysd_infor model = new Maticsoft.Model.ysd_infor();
                model.ysdid = ysdid;
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.stationname = stationname;
                model.buildingname = buildingname;
                model.machinename = machinename;
                model.areaid = ysdmodel.areaid;
                model.fenbuid = ysdmodel.fenbuid;
                model.ywbid = ysdmodel.ywbid;
                model.stationid = ysdmodel.stationid;

                model.buildingid = getidbubuildingname(buildingname);
                model.machineid = ysdmodel.machineid;
                model.ysdname = ysdindex;
                model.orderindex = double.Parse(ysdindex);
                model.createtime = System.DateTime.Now;
                ysdservice.Update(model);
                return "预设点名称：" + ysdindex + "修改成功";
            }

        }
        public string deleteysd(string sid)
        {

            ysdservice.Delete(sid);
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            devicelist = deviceservice.GetModelList("ysdindex='"+sid+"'");
            for (int i = 0; i < devicelist.Count();i++ )
            {
                deviceservice.Delete(devicelist[i].deviceid);
            }
                return "删除成功";

        }
        public DataTable getAllysd(string userid)
        {
            Maticsoft.BLL.user_infor s1 = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor m1 = new Maticsoft.Model.user_infor();
            m1 = s1.GetModel(userid);
            if (m1 == null)
            {
                return null;
            }
            else
            {
                DataTable dt = new DataTable();
                if (m1.usertype == "0")
                {
                    dt = ysdservice.GetList("areaid='" + m1.areaid + "'").Tables[0];

                }

                if (m1.usertype == "1")
                {
                    dt = ysdservice.GetList("fenbuid='" + m1.fenbuid + "'").Tables[0];

                }
                if (m1.usertype == "2")
                {
                    dt = ysdservice.GetList("ywbid='" + m1.ywbid + "'").Tables[0];

                }
                if (m1.usertype == "3")
                {
                    dt = ysdservice.GetList("").Tables[0];

                }
                return dt;
            }

        }
        public DataTable getysdByarea(string areaid)
        {
            return ysdservice.GetList("areaid='" + areaid + "' order by ysdname").Tables[0];

        }
        public DataTable getysdByfenbu(string fenbuid)
        {
            return ysdservice.GetList("fenbuid='" + fenbuid + "' order by ysdname").Tables[0];

        }
        public DataTable getysdByywb(string ywbid)
        {
            return ysdservice.GetList("ywbid='" + ywbid + "' order by ysdname").Tables[0];

        }
        public DataTable getysdBystation(string stationid)
        {
            return ysdservice.GetList("stationid='" + stationid + "' order by ysdname").Tables[0];

        }
        public DataTable getysdBybuilding(string buildingid)
        {
            return ysdservice.GetList("buildingid='" + buildingid + "' order by ysdname").Tables[0];

        }
        public DataTable getysdBymachine(string machineid)
        {
            return ysdservice.GetList("machineid='" + machineid + "'  order by orderindex").Tables[0];


        }
        public DataTable getysdByname(string id)
        {
            return ysdservice.GetList("ysdid='" + id + "'").Tables[0];

        }
        #endregion
        #region 设备
        public string getysdidbyysdname(string buildingname, string machinename, string ysdname)
        {
            Maticsoft.BLL.ysd_infor se = new Maticsoft.BLL.ysd_infor();
            Maticsoft.Model.ysd_infor mo = new Maticsoft.Model.ysd_infor();
            DataSet ds = se.GetList("buildingid='" + buildingname + "' and machineid='" + machinename + "' and ysdname='" + ysdname + "'");
            if (ds.Tables[0].Rows.Count > 0)
                return ds.Tables[0].Rows[0]["ysdid"].ToString();
            else
                return "";
        }
        public string getmachinenameid(string buildingname, string machinename, string ysdname)
        {
            Maticsoft.BLL.machine_infor se = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor mo = new Maticsoft.Model.machine_infor();
            DataSet ds = se.GetList("buildingname='" + buildingname + "' and machinename='" + machinename + "'");
            if (ds.Tables[0].Rows.Count > 0)
                return ds.Tables[0].Rows[0]["machineid"].ToString();
            else
                return "";
        }
        Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
        public string adddevice(string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename, string ysdindex, string devicename,string offsetvaue, string ysdtype, string ysdlevel, string operaterNumber)
        {
            if (areaname == "" || areaname == null)
                return "请选择工区";
            if (fenbuname == "" || fenbuname == null)
                return "添请选择分部";
            if (ywbname == "" || ywbname == null)
                return "添请选择运维班";
            if (stationname == "" || stationname == null)
                return "请选择变电站";
            if (buildingname == "" || buildingname == null)
                return "请选择设备区";
            if (machinename == "" || machinename == null)
                return "请选择红外设备";
            if (ysdindex == "" || ysdindex == null)
                return "请选择预设点编号";
            if (devicename == "" || devicename == null)
                return "变电设备名称不能为空";
            //if (distance == "" || distance == null)
            //    return "预设点距离不能为空，需输入整数或者小数";
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            devicelist = deviceservice.GetModelList("");
            bool ishave = false;
            string sid = "";
            for (int i = 0; i < devicelist.Count(); i++)
            {
                if (stationname == devicelist[i].stationname && buildingname == devicelist[i].buildingname && machinename == devicelist[i].machinename && ysdindex == devicelist[i].ysdname && devicename == devicelist[i].devicename)
                {
                    sid = devicelist[i].deviceid;
                    ishave = true;
                }
            }
            if (ishave)
            {
                return "添加设备名称已存在";
            }
            else
            {
                Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
                model.deviceid = Guid.NewGuid().ToString("N");
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.stationname = stationname;
                model.buildingname = buildingname;
                model.machinename = machinename;
                model.areaid = getidbyname(areaname, "area");
                model.fenbuid = getidbyname(fenbuname, "fenbu");
                model.ywbid = getidbyname(ywbname, "ywb");
                model.stationid = getidbyname(stationname, "station");
                DataSet ds1 = buildingservice.GetList("buildingname='" + buildingname + "' and stationname='" + stationname + "'");
                if(ds1.Tables[0].Rows.Count>0)
                    model.buildingid = ds1.Tables[0].Rows[0]["buildingid"].ToString();
                DataSet ds2 = machineservice.GetList("buildingname='" + buildingname + "' and stationname='" + stationname + "' and machinename='" + machinename + "'");
                if(ds2.Tables[0].Rows.Count>0)
                    model.machineid = ds2.Tables[0].Rows[0]["machineid"].ToString();
                model.ysdname = ysdindex;
                model.ysdindex = getysdidbyysdname(model.buildingid, model.machineid, ysdindex);
                model.devicename = devicename;
                model.iskeypoint = "0";
                model.isroundpoint = "1";
                model.todaytop="0.0";
                model.yestodaytop="0.0";
                model.weektop="0.0";
                model.monthtop="0.0";
                model.historytop="0.0";
                model.todaymax = "0.0";
                model.monthmax = "0.0";
                model.orderindex = int.Parse(ysdindex);
                model.isopen = "1";
//                model.distance = double.Parse(distance);
                model.fuhe = "";
                model.offsetvalue = offsetvaue;
                model.ysdtype = ysdtype;
                model.ysdlevel = ysdlevel;
                model.createtime = System.DateTime.Now;
                model.operaterNumber = operaterNumber;
                deviceservice.Add(model);
                List<Maticsoft.Model.device_infor> ml = new List<Maticsoft.Model.device_infor>();
                ml = deviceservice.GetModelList("stationid='" + getidbyname(stationname, "station") + "'");
                stationservice.UpdateDevicecount(getidbyname(stationname, "station"), ml.Count().ToString());
                return "1";
            }

        }
        public string modifydevice(string deviceid,string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename, string ysdindex, string devicename,string offsetvaue, string ysdtype, string ysdlevel, string operaterNumber,string ysdname)
        {
            Maticsoft.Model.device_infor dm = new Maticsoft.Model.device_infor();
            dm = deviceservice.GetModel(deviceid);
            Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
            if (dm != null)
            {
                model.deviceid = deviceid;
                model.areaname = areaname;
                model.fenbuname = fenbuname;
                model.ywbname = ywbname;
                model.stationname = stationname;
                model.buildingname = buildingname;
                model.machinename = machinename;
                model.areaid = dm.areaid;
                model.fenbuid = dm.fenbuid;
                model.ywbid = dm.ywbid;
                model.stationid = dm.stationid;
                model.buildingid = getidbubuildingname(buildingname);
                model.machineid = dm.machineid;
                model.ysdname =ysdname ;
                model.ysdindex = ysdindex ;
                model.devicename = devicename;
                model.iskeypoint = "0";
                model.isroundpoint = "0";
                model.todaytop = "0.0";
                model.yestodaytop = "0.0";
                model.weektop = "0.0";
                model.monthtop = "0.0";
                model.historytop = "0.0";
                model.todaymax = "0.0";
                model.monthmax = "0.0";
                model.orderindex = int.Parse(ysdname);
                model.isopen = "1";
        //            model.distance = double.Parse(distance);
                model.fuhe = "";
                model.offsetvalue = offsetvaue;
                model.ysdtype = ysdtype;
                model.ysdlevel = ysdlevel;
                model.createtime = System.DateTime.Now;
                model.operaterNumber = operaterNumber;//运行编号
                deviceservice.Update(model);

            }
            return "设备名称：" + devicename + "修改成功";

        }
        public string deletedevice(string sid)
        {
            string[] array = sid.Split(',');
            for (int i = 0; i < array.Length; i++)
            {
                deviceservice.Delete(array[i]);

            }
            return "成功删除" + array.Length + "条数据";

        }
        public DataTable getAlldevice(string userid)
        {
            Maticsoft.BLL.user_infor s1 = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor m1 = new Maticsoft.Model.user_infor();
            m1 = s1.GetModel(userid);
            if (m1 == null)
            {
                return null;
            }
            else
            {
                DataTable dt = new DataTable();
                if (m1.usertype == "0")
                {
                    dt = deviceservice.GetList("areaid='" + m1.areaid + "'").Tables[0];

                }

                if (m1.usertype == "1")
                {
                    dt = deviceservice.GetList("fenbuid='" + m1.fenbuid + "'").Tables[0];

                }
                if (m1.usertype == "2")
                {
                    dt = deviceservice.GetList("ywbid='" + m1.ywbid + "'").Tables[0];

                }
                if (m1.usertype == "3")
                {
                    dt = deviceservice.GetList("").Tables[0];

                }
                return dt;
            }

        }
        public DataTable getdeviceByarea(string areaid)
        {
            return deviceservice.GetList("areaid='" + areaid + "'").Tables[0];

        }
        public DataTable getdeviceByfenbu(string fenbuid)
        {
            return deviceservice.GetList("fenbuid='" + fenbuid + "'").Tables[0];

        }
        public DataTable getdeviceByywb(string ywbid)
        {
            return deviceservice.GetList("ywbid='" + ywbid + "'").Tables[0];

        }
        public DataTable getdeviceBystation(string stationid)
        {
            return deviceservice.GetList("stationid='" + stationid + "'").Tables[0];

        }
        public DataTable getdeviceBybuildingid(string buildingid)
        {
            return deviceservice.GetList("buildingid='" + buildingid + "'").Tables[0];

        }
        public DataTable getdeviceBymachine(string machineid)
        {
            return deviceservice.GetList("machineid='" + machineid + "' ").Tables[0];


        }
        public DataTable getdeviceByysd(string ysdid)
        {
            return deviceservice.GetList("ysdindex='" + ysdid + "'").Tables[0];


        }
        public DataTable getdeviceByname(string id)
        {
            return deviceservice.GetList("deviceid='" + id + "'").Tables[0];
        }
        #endregion
        public DataTable getdevicetype()
        {
            Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
            return typeservice.GetList("").Tables[0];
        }
        public DataTable getdeviceBytype(string stationname, string buildingname, string devicetype)
        {
            return deviceservice.GetList("stationname='" + stationname + "' and buildingname='" + buildingname + "' and ysdtype='" + devicetype + "'").Tables[0];
        }
        public DataTable getdeviceByAlarmOkornot(string stationname, string buildingname, string isok)
        {
            return deviceservice.GetList("stationname='" + stationname + "' and buildingname='" + buildingname + "' and isok='" + isok + "'").Tables[0];

        }
        public string l_getdeviceByUnit(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string machineid, string isok, string page, string limit)
        {
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel.usertype == "0")
                areaid = usermodel.areaid;
            if (usermodel.usertype == "1")
                fenbuid = usermodel.fenbuid;
            if (usermodel.usertype == "2")
                ywbid = usermodel.ywbid;
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1) * int.Parse(limit);
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部")
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部")
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部")
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部")
                sqllist.Add("stationid='" + stationid + "'");
            if (buildingid != "" && buildingid != "全部")
                sqllist.Add("buildingid='" + buildingid + "'");
            if (machineid != "" && machineid != "全部")
                sqllist.Add("machineid='" + machineid + "'");
            if (devicetype != "" && devicetype != "全部")
                sqllist.Add("ysdtype='" + devicetype + "'");
            if (isok != "" && isok != "全部")
                sqllist.Add("isok='" + isok + "'");
            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql = "";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1];
            }
            if(sql=="")
            {
                sql += "1=1 ";
            }
            string sql1 = sql;
            sql += " ORDER BY machinename ,orderindex desc limit " + npage + "," + end + "";
            DataTable dt = null;
            devicelistjson list = new devicelistjson();
            DataTable dt1 = null;
            if (usermodel.usertype == "3" && (areaid == "" || areaid == null))
            {
                dt = deviceservice.GetList(sql).Tables[0];
                dt1 = deviceservice.GetList(sql1).Tables[0];
            }
            else
            {
                dt = deviceservice.GetList(sql).Tables[0];
                dt1 = deviceservice.GetList(sql1).Tables[0];
            }
            dt.Columns.Add("onlinetime", Type.GetType("System.String"));
            Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
            if(dt.Rows.Count>0){//获取每个设备的安装时间
                for (int d = 0; d < dt.Rows.Count;d++ )
                {
                    string machid = dt.Rows[d]["machineid"].ToString();
                    if (machid != "")
                    {
                        macmodel = macservice.GetModel(machid);
                        if (macmodel != null)
                        {
                            dt.Rows[d]["onlinetime"] = macmodel.onlinetime.ToString();
                        }
                    }
                }
            }
            list.Recordcount = dt1.Rows.Count.ToString();
            list.Recorddt = dt;
            return Newtonsoft.Json.JsonConvert.SerializeObject(list);
        }

        public DataTable getAllmachinetype()
        {
            Maticsoft.BLL.machinetype_infor se = new Maticsoft.BLL.machinetype_infor();
            return se.GetList("").Tables[0];
        }

        public DataTable getmachineBytype(string stationname, string buildingname)
        {
            return machineservice.GetList("stationname='" + stationname + "' and buildingname='" + buildingname + "'").Tables[0];
        }
        public void OfflineCount()
        {
            Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
            List<Maticsoft.Model.machine_infor> devlist = new List<Maticsoft.Model.machine_infor>();
            devlist = macser.GetModelList("");
            for (int i = 0; i < devlist.Count(); i++)
            {
                string machinemac = devlist[i].machinemac;
                if (machinemac == null || machinemac == "")
                {
                    macser.UpdateMachineState(devlist[i].machineid, "拆除", "2", "已拆除");
                }
                else
                {
                    try
                    {
                        DateTime lastTime = (DateTime)devlist[i].createtime.Value.Date;
                        DateTime nowtime = System.DateTime.Now;
                        TimeSpan tsStart = new TimeSpan(lastTime.Ticks);
                        TimeSpan tsEnd = new TimeSpan(nowtime.Ticks);
                        TimeSpan ts = tsEnd.Subtract(tsStart).Duration();
                        double hourspan = ts.Days * 24 + ts.Hours + (double)ts.Minutes / 60;
                        if (hourspan > 24)
                        {
                            macser.UpdateMachineState(devlist[i].machineid, "失联", "0","已失联："+hourspan.ToString("0.0")+"小时");
                        }
                        else
                        {
                            macser.UpdateMachineState(devlist[i].machineid, "在线", "1", "未失联");
                        }
                    }
                    catch
                    {
                        macser.UpdateMachineState(devlist[i].machineid, "失联", "0", "无法获取状态");
                    }
                }
            }
        }
        public string l_getmachineByUnit(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string machinetype, string machineid, string isonline, string page, string limit)
        {

            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel.usertype == "0")
            {
                areaid = usermodel.areaid;
            }
            if (usermodel.usertype == "1")
            {
                fenbuid = usermodel.fenbuid;
            }
            if (usermodel.usertype == "2")
            {
                {
                    ywbid = usermodel.ywbid;
                }
            }
            //updatemahcineruntime();
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1) * int.Parse(limit);
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部")
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部")
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部")
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部")
                sqllist.Add("stationid='" + stationid + "'");
            if (buildingid != "" && buildingid != "全部")
                sqllist.Add("buildingid='" + buildingid + "'");
            if (machineid != "" && machineid != "全部")
                sqllist.Add("machineid='" + machineid + "'");
            if (machinetype != "" && machinetype != "全部")
                sqllist.Add("machinetype='" + machinetype + "'");
            if (isonline != "" && isonline != "全部")
                sqllist.Add("isonline='" + isonline + "'");
            //if (stationid != "全部" && stationid != "")
            //    sqllist.Add("stationid='" + stationid + "'");
            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql = "";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1];
            }
            if (sql == "")
            {
                sql += "1=1 ";
            }

            string sql1 = sql;
            sql += "  order by installcode asc limit " + npage + "," + end + "";
            DataTable dt, dt1;
            if (usermodel.usertype == "3" && (areaid == "" || areaid == null))
            {
                dt = machineservice.GetList(sql).Tables[0];
                dt1 = machineservice.GetList(sql1).Tables[0];
            }
            else
            {
                dt = machineservice.GetList(sql).Tables[0];
                dt1 = machineservice.GetList(sql1).Tables[0];
            }
          
            devicelistjson list = new devicelistjson();
            list.Recordcount = dt1.Rows.Count.ToString();
            dt.Columns.Add("installtime", Type.GetType("System.String"));
            for(int i=0;i<dt.Rows.Count;i++)
            {
                string time = dt.Rows[i]["onlinetime"].ToString();
                 DateTime dtime;
                    DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                    dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";
                    dtime = Convert.ToDateTime(time, dtFormat);
                    dt.Rows[i]["installtime"] = dtime.Year.ToString()+"-"+dtime.Month.ToString()+"-"+dtime.Day.ToString();

                #region 定义默认版本 2020.10.27 By King-1025

                string flirVersion = dt.Rows[i]["piflirversion"].ToString();
                string videoVersion = dt.Rows[i]["pivideoversion"].ToString();
                
                if(flirVersion == null || "".Equals(flirVersion)) {
                    flirVersion = "初始版本";
                }

                if (videoVersion == null || "".Equals(videoVersion))
                {
                    videoVersion = "初始版本";
                }

                dt.Rows[i]["piflirversion"] = flirVersion;
                dt.Rows[i]["pivideoversion"] = videoVersion;

                #endregion
            }

            list.Recorddt = dt;
            List<devicelistjson> nn = new List<devicelistjson>();
            nn.Add(list);

            return Newtonsoft.Json.JsonConvert.SerializeObject(list);
        }

        public string l_getDeviceImageByUnit(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string deviceid, string isok, string page, string limit, string startDate, string endDate, string isimagered)
        {
            if (userid != "")
            {
                Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
                usermodel = userservice.GetModel(userid);
                if (usermodel.usertype == "0")
                {
                    {
                        areaid = usermodel.areaid;
                    }
                }
                if (usermodel.usertype == "1")
                {
                    {
                        fenbuid = usermodel.fenbuid;
                    }
                }
                if (usermodel.usertype == "2")
                {
                    {
                        ywbid = usermodel.ywbid;
                    }
                }
            }         
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1);
            if (isimagered=="")
            {
                isimagered = "0";
            }
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部")
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部")
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部")
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部")
                sqllist.Add("stationid='" + stationid + "'");
            if (buildingid != "" && buildingid != "全部")
                sqllist.Add("buildingid='" + buildingid + "'");
            if (deviceid != "" && deviceid != "全部")
                sqllist.Add("deviceid='" + deviceid + "'");
            if (devicetype != "" && devicetype != "全部")
                sqllist.Add("ysdtype='" + devicetype + "'");
            if (isok != "" && isok != "全部")
                sqllist.Add("isok='" + isok + "'");
            string sql = "";
            string isopen = "1";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql = " isopen='"+isopen+"'";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0] + " and isopen='" + isopen + "'";
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1] + " and isopen='" + isopen + "'";
            }

            string sql1 = sql;
            //sql += " limit " + npage + "," + end + "";


            List<string> deviceidlist = new List<string>();
            DataTable dt = deviceservice.GetList(sql).Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                deviceidlist.Add(dt.Rows[i]["deviceid"].ToString());
            }
            int nallcount = 0;
            DataTable dtnew = new DataTable("keyDevice");
            dtnew.Columns.Add("recordid", Type.GetType("System.String"));
            dtnew.Columns.Add("deviceid", Type.GetType("System.String"));
            dtnew.Columns.Add("devicename", Type.GetType("System.String"));
            dtnew.Columns.Add("stationname", Type.GetType("System.String"));
            dtnew.Columns.Add("image", Type.GetType("System.String"));
            //dtnew.Columns.Add("image_red", Type.GetType("System.String"));
            //dtnew.Columns.Add("image_mix", Type.GetType("System.String"));
            //dtnew.Columns.Add("image_high", Type.GetType("System.String"));
            dtnew.Columns.Add("todaytop", Type.GetType("System.String"));

            dtnew.Columns.Add("machinecode", Type.GetType("System.String"));
            dtnew.Columns.Add("createtime", Type.GetType("System.String"));
            string imageSql = "";
            //时间判断
            bool falg = true;
            string startmonth = "";
            string endmonth = "";
            string nowmonth = System.DateTime.Now.ToString("yyyyMM");
            DateTime timeStart = new DateTime();
            DateTime timeEnd = new DateTime();
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy-MM-dd hh:MM:ss";                          
            if (startDate != ""){
                timeStart = Convert.ToDateTime(startDate, dtFormat).AddDays(0).Date;
                startmonth = timeStart.Date.ToString("yyyyMM");
                imageSql += " createtime >= '"+ timeStart + "' and ";
                }
            if (endDate != "")
            {
                string[] array = endDate.Split('-');
                if (array.Length==3)
                {
                    int year = Convert.ToInt32(array[0]);
                    int month = Convert.ToInt32(array[1]);
                    int day = Convert.ToInt32(array[2]);
                    if (month == 2 )//判断2月份
                    {
                        //如果月份是2月，判断年份是否为闰年
                        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
                        {
                            if (day==29)
                            {
                                falg = false;
                            }
                        }
                        else
                        {
                            if (day == 28)
                            {
                                falg = false;
                            }
                        }
                    }
                    else//判断其他月份
                    {
                        switch (month)
                        {
                            case 1:
                            case 3:
                            case 5:
                            case 7:
                            case 8:
                            case 10:
                            case 12:
                                if (day == 31)                                   
                                    falg = false;                                   
                                break;
                            case 4:
                            case 6:
                            case 9:
                            case 11:
                                if (day == 30)
                                    falg = false;
                                break;                               
                        }
                    }                       
                }
                if (falg)
                {
                    timeEnd = Convert.ToDateTime(endDate, dtFormat).AddDays(1);
                    endmonth = timeEnd.Date.ToString("yyyyMM");
                    imageSql += " createtime < '" + timeEnd + "' and ";
                }
                }

            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();

            for (int k = 0; k < deviceidlist.Count; k++)
            {
                string imageSql1 = "deviceid='" + deviceidlist[k] + "'  order by createtime desc ";
                Maticsoft.BLL.image_record_history imagebll = new Maticsoft.BLL.image_record_history();
                //DataTable dimage = imagebll.GetList("deviceid='" + deviceidlist[k] + "' group by createtime order by createtime desc ").Tables[0];
                DataTable dimage = new DataTable();
                DataTable dimage1 = new DataTable();
                DataTable dimage2 = new DataTable();
                if (startmonth !="" &&  endmonth !="")
                {
                    if (startmonth == nowmonth && endmonth== nowmonth)//查询当前月
                    {                           
                        dimage = imagebll.GetList(imageSql + imageSql1).Tables[0];
                    }
                    else if(startmonth != nowmonth && startmonth == endmonth )//查询同月数据
                    {
                        if (startmonth == "202009" || startmonth =="202010")
                        {
                            startmonth = "20200910";
                        }
                        dimage = imagebll.HisGetList(startmonth, imageSql + imageSql1).Tables[0];
                    }else if (startmonth != nowmonth && startmonth != endmonth)//跨月查询数据（都不属于当前月）
                    {
                        if (startmonth == "202009" || startmonth == "202010")
                        {
                            startmonth = "20200910";
                        }
                        dimage1 = imagebll.HisGetList(startmonth, " createtime >= '" + timeStart + "' and " + imageSql1).Tables[0];
                        if (endmonth == nowmonth)
                        {
                            if (falg)
                            {
                                dimage2 = imagebll.GetList(" createtime < '" + timeEnd + "' and " + imageSql1).Tables[0];
                            }
                        }
                        else
                        {
                            if (endmonth == "202009" || endmonth == "202010")
                            {
                                endmonth = "20200910";
                            }
                            if (falg)
                            {
                                dimage2 = imagebll.HisGetList(endmonth, " createtime < '" + timeEnd + "' and " + imageSql1).Tables[0];
                            }
                        }                     
                    }else if (startmonth == nowmonth && startmonth != endmonth)//特殊查询（开始时间属于当前月，结束时间属于下个月）
                    {
                        dimage1 = imagebll.GetList(imageSql + imageSql1).Tables[0];                          
                    }
                }
                else
                {
                    if (startmonth == nowmonth)//查询当前月
                    {
                        dimage = imagebll.GetList(imageSql + imageSql1).Tables[0];
                    }
                    else
                    {
                        if (startmonth == "202009" || startmonth == "202010")
                        {
                            startmonth = "20200910";
                        }
                        dimage = imagebll.HisGetList(startmonth, imageSql + imageSql1).Tables[0];
                    }                     
                }


                if (dimage1.Rows.Count>0 && dimage2.Rows.Count > 0)
                {
                    object[] obj = new object[dimage.Columns.Count];
                    for (int i = 0; i < dimage1.Rows.Count; i++)
                    {
                        dimage1.Rows[i].ItemArray.CopyTo(obj, 0);
                        dimage.Rows.Add(obj);
                    }

                    for (int j = 0; j < dimage2.Rows.Count; j++)
                    {
                        dimage2.Rows[j].ItemArray.CopyTo(obj, 0);
                        dimage.Rows.Add(obj);
                    }
                }
                else if (dimage1.Rows.Count > 0 && dimage2.Rows.Count == 0)
                {
                    dimage = dimage1;
                }else if (dimage2.Rows.Count > 0 && dimage1.Rows.Count == 0)
                {
                    dimage = dimage2;
                }

                nallcount += dimage.Rows.Count;
                string machineid = dt.Rows[k]["machineid"].ToString();
                Maticsoft.BLL.machine_infor macser = new Maticsoft.BLL.machine_infor();
                Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
                macmodel = macser.GetModel(machineid);
                if (macmodel != null)
                {
                    string machinecode = macmodel.machinecode;
                    string stationname = macmodel.stationname;
                    if (dimage.Rows.Count > 0)
                    {
                        #region 同步图片数据到表：device_infor By King-1025

                        //int x = 0; // 最新图片记录
                        //string devid = deviceidlist[k];
                        //string red   = dimage.Rows[x]["image0"].ToString();
                        //string mix   = dimage.Rows[x]["image1"].ToString();
                        //string high  = dimage.Rows[x]["image2"].ToString();
                        //DateTime ctime = (DateTime) dimage.Rows[x]["createtime"];

                        //deviceService.maybeSyncImage(devid, red, mix, high, ctime);
                            
                        #endregion 

                        for (int i = 0; i < dimage.Rows.Count; i++)
                        {
                            if (isimagered == "0")
                            {
                                dtnew.Rows.Add(new object[] { dimage.Rows[i]["recordid"].ToString(), dimage.Rows[i]["deviceid"].ToString(), dimage.Rows[i]["devicename"].ToString(), stationname, dimage.Rows[i]["image0"].ToString(), dimage.Rows[i]["valuemax"].ToString(), machinecode, dimage.Rows[i]["createtime"].ToString() });
                            }else if(isimagered == "1")
                            {
                                dtnew.Rows.Add(new object[] { dimage.Rows[i]["recordid"].ToString(), dimage.Rows[i]["deviceid"].ToString(), dimage.Rows[i]["devicename"].ToString(), stationname, dimage.Rows[i]["image1"].ToString(), dimage.Rows[i]["valuemax"].ToString(), machinecode, dimage.Rows[i]["createtime"].ToString() });
                            }
                            else if(isimagered == "2")
                            {
                                dtnew.Rows.Add(new object[] { dimage.Rows[i]["recordid"].ToString(), dimage.Rows[i]["deviceid"].ToString(), dimage.Rows[i]["devicename"].ToString(), stationname, dimage.Rows[i]["image2"].ToString(), dimage.Rows[i]["valuemax"].ToString(), machinecode, dimage.Rows[i]["createtime"].ToString() });
                            }
                            //dtnew.Rows.Add(new object[] {dimage.Rows[i]["recordid"].ToString(), dimage.Rows[i]["deviceid"].ToString(), dimage.Rows[i]["devicename"].ToString(), stationname, dimage.Rows[i]["image0"].ToString(), dimage.Rows[i]["image1"].ToString(), dimage.Rows[i]["image2"].ToString(), dimage.Rows[i]["valuemax"].ToString(), machinecode, dimage.Rows[i]["createtime"].ToString() });
                        }
                    }

                }
                else//查询拆除设备的图片
                {
                    for (int i = 0; i < dimage.Rows.Count; i++)
                    {
                        if (isimagered == "0")
                        {
                            dtnew.Rows.Add(new object[] { dimage.Rows[i]["recordid"].ToString(), dimage.Rows[i]["deviceid"].ToString(), dimage.Rows[i]["devicename"].ToString(), "", dimage.Rows[i]["image0"].ToString(), dimage.Rows[i]["valuemax"].ToString(), "", dimage.Rows[i]["createtime"].ToString() });
                        }
                        else if (isimagered == "1")
                        {
                            dtnew.Rows.Add(new object[] { dimage.Rows[i]["recordid"].ToString(), dimage.Rows[i]["deviceid"].ToString(), dimage.Rows[i]["devicename"].ToString(), "", dimage.Rows[i]["image1"].ToString(), dimage.Rows[i]["valuemax"].ToString(), "", dimage.Rows[i]["createtime"].ToString() });
                        }
                        else if (isimagered == "2")
                        {
                            dtnew.Rows.Add(new object[] { dimage.Rows[i]["recordid"].ToString(), dimage.Rows[i]["deviceid"].ToString(), dimage.Rows[i]["devicename"].ToString(), "", dimage.Rows[i]["image2"].ToString(), dimage.Rows[i]["valuemax"].ToString(), "", dimage.Rows[i]["createtime"].ToString() });
                        }
                     
                    }
                }

            }

            devicelistjson list = new devicelistjson();
            DataTable dt2 = new DataTable();
            dt2 = dtnew.Copy();
            dt2.Rows.Clear();
            for (int i = (npage) * int.Parse(limit); i < (npage) * int.Parse(limit) + int.Parse(limit); i++)
            {
                if (i < dtnew.Rows.Count)
                {
                    dt2.ImportRow(dtnew.Rows[i]);//这是加入的是第i行

                }
            }
            list.Recordcount = dtnew.Rows.Count.ToString();
            list.Recorddt = dt2;
            List<devicelistjson> nn = new List<devicelistjson>();

            nn.Add(list);

            return Newtonsoft.Json.JsonConvert.SerializeObject(list);
            

        }

        public string l_getAlarmByUnit(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string deviceid, string isok, string page, string limit, string order, string staralarm, string endalarm)
        {
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);

            if (usermodel.usertype == "0")
            {
                {
                    areaid = usermodel.areaid;
                }
            }
            if(usermodel.usertype=="1")
            {
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                {
                    ywbid = usermodel.ywbid;
                }
            }
            //else
            //{
            //    areaid = "";
            //}
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1) * int.Parse(limit);
           
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部")
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部")
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部")
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部")
                sqllist.Add("stationid='" + stationid + "'");
            if (buildingid != "" && buildingid != "全部")
                sqllist.Add("buildingid='" + buildingid + "'");
            if (deviceid != "" && deviceid != "全部")
                sqllist.Add("deviceid='" + deviceid + "'");
            if (devicetype != "" && devicetype != "全部")
                sqllist.Add("devicetype='" + devicetype + "'");
            if (isok != "" && isok != "全部")
                sqllist.Add("isok='" + isok + "'");
            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql = "";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1];
            }
            if (sql == "")
            {
                sql += "1=1 ";
            }
            if(staralarm !=""){
                sql += " and alarmvalue >= "+staralarm+" ";
            }
            if(endalarm != ""){
                sql += " and alarmvalue < " + endalarm+" " ;
            }
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devocemodel = new Maticsoft.Model.device_infor();
            string sql1 = sql;
            string sx = "";
            if (order == "0")
            {
                sx = "     order by  CAST(alarmvalue AS  SIGNED int) desc limit " + npage + "," + end + "";
            }
            if (order == "1")
            {
                sx = "    order by createtime desc limit " + npage + "," + end + "";
            }
            string sx1 = "    order by  CAST(alarmvalue AS  SIGNED int) desc  ";
            DataTable dt = alarmservice.GetList(sql+sx).Tables[0];
            dt.Columns.Add("offsethuman", Type.GetType("System.String"));
            dt.Columns.Add("offsetvalue", Type.GetType("System.String"));
            dt.Columns.Add("offsettime", Type.GetType("System.String"));
            if (dt.Rows.Count > 0)
            {
                for(int i=0;i<dt.Rows.Count;i++)
                {
                    string device_id = dt.Rows[i]["deviceid"].ToString();
                    devocemodel =  deviceservice.GetModel(device_id);
                    if (devocemodel != null)
                    {
                        dt.Rows[i]["offsethuman"] = devocemodel.offsethuman.ToString();//设定人
                        dt.Rows[i]["offsetvalue"] = devocemodel.offsetvalue.ToString();//告警阈值
                        dt.Rows[i]["offsettime"] = devocemodel.createtime.Value.ToString();//设定时间
                    }
                    else
                    {
                        dt.Rows[i]["offsethuman"] = "";
                        dt.Rows[i]["offsetvalue"] = "";
                        dt.Rows[i]["offsettime"] = "";
                    }
                }
            }

            devicelistjson list = new devicelistjson();
            DataTable dt1 = alarmservice.GetList(sql + sx1).Tables[0];
            list.Recordcount = dt1.Rows.Count.ToString();
            list.Recorddt = dt;
            List<devicelistjson> nn = new List<devicelistjson>();
            nn.Add(list);
            return Newtonsoft.Json.JsonConvert.SerializeObject(list);
        }
        #region 获取所有信息
        public string getallInforByUser(string userid)
        {
            string isopen = "1";
            Maticsoft.BLL.user_infor service1 = new Maticsoft.BLL.user_infor();
            DataTable dt = service1.GetList("userid='" + userid + "'").Tables[0];
            if (dt.Rows.Count < 1)
            {
                return "没有此用户";
            }
            string usertype = dt.Rows[0]["usertype"].ToString();
            SystemInfor allinfor = new SystemInfor();
            if (usertype == "0")
            {
                string areaid = dt.Rows[0]["areaid"].ToString();
                string areaname = dt.Rows[0]["areaname"].ToString();
                string[] s1 = new string[2];
                s1[0] = areaid;
                s1[1] = areaname;
                allinfor.Arealist.Add(s1);

                Maticsoft.BLL.fenbu_infor service2 = new Maticsoft.BLL.fenbu_infor();
                DataTable d1 = service2.GetList("areaid='" + areaid + "'").Tables[0];
                if (d1.Rows.Count > 0)
                {
                    for (int i = 0; i < d1.Rows.Count; i++)
                    {
                        string fenbuid = d1.Rows[i]["fenbuid"].ToString();
                        string fenbuname = d1.Rows[i]["fenbuname"].ToString();
                        string[] sfenbu = new string[2];
                        sfenbu[0] = fenbuid; sfenbu[1] = fenbuname;
                        allinfor.Fenbulist.Add(sfenbu);
                    }
                }


                Maticsoft.BLL.ywb_infor service3 = new Maticsoft.BLL.ywb_infor();
                DataTable d2 = service3.GetList("areaid='" + areaid + "'").Tables[0];
                if (d2.Rows.Count > 0)
                {
                    for (int i = 0; i < d2.Rows.Count; i++)
                    {
                        string ywbid = d2.Rows[i]["ywbid"].ToString();
                        string ywbname = d2.Rows[i]["ywbname"].ToString();
                        string[] sywb = new string[2];
                        sywb[0] = ywbid; sywb[1] = ywbname;
                        allinfor.Ywblist.Add(sywb);
                    }
                }


                Maticsoft.BLL.station_infor service4 = new Maticsoft.BLL.station_infor();
                DataTable d3 = service4.GetList("areaid='" + areaid + "'").Tables[0];
                if (d3.Rows.Count > 0)
                {
                    for (int i = 0; i < d3.Rows.Count; i++)
                    {
                        string stationid = d3.Rows[i]["stationid"].ToString();
                        string stationname = d3.Rows[i]["stationname"].ToString();
                        string[] sstation = new string[2];
                        sstation[0] = stationid; sstation[1] = stationname;
                        allinfor.Stationlist.Add(sstation);
                    }
                }

                Maticsoft.BLL.building_infor service5 = new Maticsoft.BLL.building_infor();
                DataTable d4 = service5.GetList("areaid='" + areaid + "'").Tables[0];
                if (d4.Rows.Count > 0)
                {
                    for (int i = 0; i < d4.Rows.Count; i++)
                    {
                        string sid = d4.Rows[i]["buildingid"].ToString();
                        string sname = d4.Rows[i]["buildingname"].ToString();
                        string[] sbuilding = new string[2];
                        sbuilding[0] = sid; sbuilding[1] = sname;
                        allinfor.Buildinglist.Add(sbuilding);
                    }
                }


                Maticsoft.BLL.machine_infor service6 = new Maticsoft.BLL.machine_infor();
                DataTable d5 = service6.GetList("areaid='" + areaid + "'").Tables[0];
                if (d5.Rows.Count > 0)
                {
                    for (int i = 0; i < d5.Rows.Count; i++)
                    {
                        string sid = d5.Rows[i]["machineid"].ToString();
                        string sname = d5.Rows[i]["machinename"].ToString();
                        string[] smachine = new string[2];
                        smachine[0] = sid; smachine[1] = sname;
                        allinfor.Machinelist.Add(smachine);
                    }
                }

                Maticsoft.BLL.ysd_infor service7 = new Maticsoft.BLL.ysd_infor();
                DataTable d7 = service7.GetList("areaid='" + areaid + "'").Tables[0];
                if (d7.Rows.Count > 0)
                {
                    for (int i = 0; i < d7.Rows.Count; i++)
                    {
                        string sid = d7.Rows[i]["ysdid"].ToString();
                        string sname = d7.Rows[i]["ysdname"].ToString();
                        string[] sysd = new string[2];
                        sysd[0] = sid; sysd[1] = sname;
                        allinfor.Ysdlist.Add(sysd);
                    }
                }


                Maticsoft.BLL.device_infor service8 = new Maticsoft.BLL.device_infor();
                DataTable d8 = service8.GetList("areaid='" + areaid + "'  and isopen='" + isopen + "'").Tables[0];
                if (d8.Rows.Count > 0)
                {
                    for (int i = 0; i < d8.Rows.Count; i++)
                    {
                        string sid = d8.Rows[i]["deviceid"].ToString();
                        string sname = d8.Rows[i]["devicename"].ToString();
                        string[] sdevice = new string[2];
                        sdevice[0] = sid; sdevice[1] = sname;
                        allinfor.Devicelist.Add(sdevice);
                    }
                }

            }
            if (usertype == "1")
            {
                string areaid = dt.Rows[0]["areaid"].ToString();
                string areaname = dt.Rows[0]["areaname"].ToString();
                string[] s1 = new string[2];
                s1[0] = areaid;
                s1[1] = areaname;
                allinfor.Arealist.Add(s1);

                string fenbuid = dt.Rows[0]["fenbuid"].ToString();
                string fenbuname = dt.Rows[0]["fenbuname"].ToString();
                string[] sfenbu = new string[2];
                sfenbu[0] = fenbuid; sfenbu[1] = fenbuname;
                allinfor.Fenbulist.Add(sfenbu);


                Maticsoft.BLL.ywb_infor service3 = new Maticsoft.BLL.ywb_infor();
                DataTable d2 = service3.GetList("fenbuid='" + fenbuid + "'").Tables[0];
                if (d2.Rows.Count > 0)
                {
                    for (int i = 0; i < d2.Rows.Count; i++)
                    {
                        string sid = d2.Rows[i]["ywbid"].ToString();
                        string sname = d2.Rows[i]["ywbname"].ToString();
                        string[] sywb = new string[2];
                        sywb[0] = sid; sywb[1] = sname;
                        allinfor.Ywblist.Add(sywb);
                    }
                }


                Maticsoft.BLL.station_infor service4 = new Maticsoft.BLL.station_infor();
                DataTable d3 = service4.GetList("fenbuid='" + fenbuid + "'").Tables[0];
                if (d3.Rows.Count > 0)
                {
                    for (int i = 0; i < d3.Rows.Count; i++)
                    {
                        string sid = d3.Rows[i]["stationid"].ToString();
                        string sname = d3.Rows[i]["stationname"].ToString();
                        string[] sstation = new string[2];
                        sstation[0] = sid; sstation[1] = sname;
                        allinfor.Stationlist.Add(sstation);
                    }
                }

                Maticsoft.BLL.building_infor service5 = new Maticsoft.BLL.building_infor();
                DataTable d4 = service5.GetList("fenbuid='" + fenbuid + "'").Tables[0];
                if (d4.Rows.Count > 0)
                {
                    for (int i = 0; i < d4.Rows.Count; i++)
                    {
                        string sid = d4.Rows[i]["buildingid"].ToString();
                        string sname = d4.Rows[i]["buildingname"].ToString();
                        string[] sbuilding = new string[2];
                        sbuilding[0] = sid; sbuilding[1] = sname;
                        allinfor.Buildinglist.Add(sbuilding);
                    }
                }


                Maticsoft.BLL.machine_infor service6 = new Maticsoft.BLL.machine_infor();
                DataTable d5 = service6.GetList("fenbuid='" + fenbuid + "'").Tables[0];
                if (d5.Rows.Count > 0)
                {
                    for (int i = 0; i < d5.Rows.Count; i++)
                    {
                        string sid = d5.Rows[i]["machineid"].ToString();
                        string sname = d5.Rows[i]["machinename"].ToString();
                        string[] smachine = new string[2];
                        smachine[0] = sid; smachine[1] = sname;
                        allinfor.Machinelist.Add(smachine);
                    }
                }

                Maticsoft.BLL.ysd_infor service7 = new Maticsoft.BLL.ysd_infor();
                DataTable d7 = service7.GetList("fenbuid='" + fenbuid + "'").Tables[0];
                if (d7.Rows.Count > 0)
                {
                    for (int i = 0; i < d7.Rows.Count; i++)
                    {
                        string sid = d7.Rows[i]["ysdid"].ToString();
                        string sname = d7.Rows[i]["ysdname"].ToString();
                        string[] sysd = new string[2];
                        sysd[0] = sid; sysd[1] = sname;
                        allinfor.Ysdlist.Add(sysd);
                    }
                }


                Maticsoft.BLL.device_infor service8 = new Maticsoft.BLL.device_infor();
                DataTable d8 = service8.GetList("fenbuid='" + fenbuid + "' and isopen='" + isopen + "'").Tables[0];
                if (d8.Rows.Count > 0)
                {
                    for (int i = 0; i < d8.Rows.Count; i++)
                    {
                        string sid = d8.Rows[i]["deviceid"].ToString();
                        string sname = d8.Rows[i]["devicename"].ToString();
                        string[] sdevice = new string[2];
                        sdevice[0] = sid; sdevice[1] = sname;
                        allinfor.Devicelist.Add(sdevice);
                    }
                }
            }





            if (usertype == "3")
            {
                DataTable darea = areaservice.GetList("").Tables[0];
                for (int i = 0; i < darea.Rows.Count; i++)
                {
                    string areaid = darea.Rows[i]["areaid"].ToString();
                    string areaname = darea.Rows[i]["areaname"].ToString();
                    string[] s1 = new string[2];
                    s1[0] = areaid;
                    s1[1] = areaname;
                    allinfor.Arealist.Add(s1);
                }

                DataTable dfenbu = fenbuservice.GetList("").Tables[0];
                for (int i = 0; i < dfenbu.Rows.Count; i++)
                {
                    string fenbuid = dfenbu.Rows[i]["fenbuid"].ToString();
                    string fenbuname = dfenbu.Rows[i]["fenbuname"].ToString();
                    string[] sfenbu = new string[2];
                    sfenbu[0] = fenbuid; sfenbu[1] = fenbuname;
                    allinfor.Fenbulist.Add(sfenbu);
                }






                Maticsoft.BLL.ywb_infor service3 = new Maticsoft.BLL.ywb_infor();
                DataTable d2 = service3.GetList("").Tables[0];
                if (d2.Rows.Count > 0)
                {
                    for (int i = 0; i < d2.Rows.Count; i++)
                    {
                        string sid = d2.Rows[i]["ywbid"].ToString();
                        string sname = d2.Rows[i]["ywbname"].ToString();
                        string[] sywb = new string[2];
                        sywb[0] = sid; sywb[1] = sname;
                        allinfor.Ywblist.Add(sywb);
                    }
                }


                Maticsoft.BLL.station_infor service4 = new Maticsoft.BLL.station_infor();
                DataTable d3 = service4.GetList("").Tables[0];
                if (d3.Rows.Count > 0)
                {
                    for (int i = 0; i < d3.Rows.Count; i++)
                    {
                        string sid = d3.Rows[i]["stationid"].ToString();
                        string sname = d3.Rows[i]["stationname"].ToString();
                        string[] sstation = new string[2];
                        sstation[0] = sid; sstation[1] = sname;
                        allinfor.Stationlist.Add(sstation);
                    }
                }

                Maticsoft.BLL.building_infor service5 = new Maticsoft.BLL.building_infor();
                DataTable d4 = service5.GetList("").Tables[0];
                if (d4.Rows.Count > 0)
                {
                    for (int i = 0; i < d4.Rows.Count; i++)
                    {
                        string sid = d4.Rows[i]["buildingid"].ToString();
                        string sname = d4.Rows[i]["buildingname"].ToString();
                        string[] sbuilding = new string[2];
                        sbuilding[0] = sid; sbuilding[1] = sname;
                        allinfor.Buildinglist.Add(sbuilding);
                    }
                }


                Maticsoft.BLL.machine_infor service6 = new Maticsoft.BLL.machine_infor();
                DataTable d5 = service6.GetList("").Tables[0];
                if (d5.Rows.Count > 0)
                {
                    for (int i = 0; i < d5.Rows.Count; i++)
                    {
                        string sid = d5.Rows[i]["machineid"].ToString();
                        string sname = d5.Rows[i]["machinename"].ToString();
                        string[] smachine = new string[2];
                        smachine[0] = sid; smachine[1] = sname;
                        allinfor.Machinelist.Add(smachine);
                    }
                }

                Maticsoft.BLL.ysd_infor service7 = new Maticsoft.BLL.ysd_infor();
                DataTable d7 = service7.GetList("").Tables[0];
                if (d7.Rows.Count > 0)
                {
                    for (int i = 0; i < d7.Rows.Count; i++)
                    {
                        string sid = d7.Rows[i]["ysdid"].ToString();
                        string sname = d7.Rows[i]["ysdname"].ToString();
                        string[] sysd = new string[2];
                        sysd[0] = sid; sysd[1] = sname;
                        allinfor.Ysdlist.Add(sysd);
                    }
                }


                Maticsoft.BLL.device_infor service8 = new Maticsoft.BLL.device_infor();
                DataTable d8 = service8.GetList("  isopen='" + isopen + "'").Tables[0];
                if (d8.Rows.Count > 0)
                {
                    for (int i = 0; i < d8.Rows.Count; i++)
                    {
                        string sid = d8.Rows[i]["deviceid"].ToString();
                        string sname = d8.Rows[i]["devicename"].ToString();
                        string[] sdevice = new string[2];
                        sdevice[0] = sid; sdevice[1] = sname;
                        allinfor.Devicelist.Add(sdevice);
                    }
                }
            }












            if (usertype == "2")
            {
                string areaid = dt.Rows[0]["areaid"].ToString();
                string areaname = dt.Rows[0]["areaname"].ToString();
                string[] s1 = new string[2];
                s1[0] = areaid;
                s1[1] = areaname;
                allinfor.Arealist.Add(s1);

                string fenbuid = dt.Rows[0]["fenbuid"].ToString();
                string fenbuname = dt.Rows[0]["fenbuname"].ToString();
                string[] sfenbu = new string[2];
                sfenbu[0] = fenbuid; sfenbu[1] = fenbuname;
                allinfor.Fenbulist.Add(sfenbu);

                string ywbid = dt.Rows[0]["ywbid"].ToString();
                string ywbname = dt.Rows[0]["ywbname"].ToString();
                string[] sywb = new string[2];
                sywb[0] = ywbid; sywb[1] = ywbname;
                allinfor.Ywblist.Add(sywb);



                Maticsoft.BLL.station_infor service4 = new Maticsoft.BLL.station_infor();
                DataTable d3 = service4.GetList("ywbid='" + ywbid + "'").Tables[0];
                if (d3.Rows.Count > 0)
                {
                    for (int i = 0; i < d3.Rows.Count; i++)
                    {
                        string sid = d3.Rows[i]["stationid"].ToString();
                        string sname = d3.Rows[i]["stationname"].ToString();
                        string[] sstation = new string[2];
                        sstation[0] = sid; sstation[1] = sname;
                        allinfor.Stationlist.Add(sstation);
                    }
                }

                Maticsoft.BLL.building_infor service5 = new Maticsoft.BLL.building_infor();
                DataTable d4 = service5.GetList("ywbid='" + ywbid + "'").Tables[0];
                if (d4.Rows.Count > 0)
                {
                    for (int i = 0; i < d4.Rows.Count; i++)
                    {
                        string sid = d4.Rows[i]["buildingid"].ToString();
                        string sname = d4.Rows[i]["buildingname"].ToString();
                        string[] sbuilding = new string[2];
                        sbuilding[0] = sid; sbuilding[1] = sname;
                        allinfor.Buildinglist.Add(sbuilding);
                    }
                }


                Maticsoft.BLL.machine_infor service6 = new Maticsoft.BLL.machine_infor();
                DataTable d5 = service6.GetList("ywbid='" + ywbid + "'").Tables[0];
                if (d5.Rows.Count > 0)
                {
                    for (int i = 0; i < d5.Rows.Count; i++)
                    {
                        string sid = d5.Rows[i]["machineid"].ToString();
                        string sname = d5.Rows[i]["machinename"].ToString();
                        string[] smachine = new string[2];
                        smachine[0] = sid; smachine[1] = sname;
                        allinfor.Machinelist.Add(smachine);
                    }
                }

                Maticsoft.BLL.ysd_infor service7 = new Maticsoft.BLL.ysd_infor();
                DataTable d7 = service7.GetList("ywbid='" + ywbid + "'").Tables[0];
                if (d7.Rows.Count > 0)
                {
                    for (int i = 0; i < d7.Rows.Count; i++)
                    {
                        string sid = d7.Rows[i]["ysdid"].ToString();
                        string sname = d7.Rows[i]["ysdname"].ToString();
                        string[] sysd = new string[2];
                        sysd[0] = sid; sysd[1] = sname;
                        allinfor.Ysdlist.Add(sysd);
                    }
                }


                Maticsoft.BLL.device_infor service8 = new Maticsoft.BLL.device_infor();
                DataTable d8 = service8.GetList("ywbid='" + ywbid + "' and isopen='" + isopen + "'").Tables[0];
                if (d8.Rows.Count > 0)
                {
                    for (int i = 0; i < d8.Rows.Count; i++)
                    {
                        string sid = d8.Rows[i]["deviceid"].ToString();
                        string sname = d8.Rows[i]["devicename"].ToString();
                        string[] sdevice = new string[2];
                        sdevice[0] = sid; sdevice[1] = sname;
                        allinfor.Devicelist.Add(sdevice);
                    }
                }
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(allinfor);
        }
     
        #endregion


        #region 查询条件             
        public string queryConditions(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string deviceid, string machineid)
        {          
            queryConditionList json = new queryConditionList();
            List<condition> areaconlist = new List<condition>();
            List<condition> fenbuconlist = new List<condition>();
            List<condition> ywbconlist = new List<condition>();
            List<condition> stationconlist = new List<condition>();
            List<condition> buildconlist = new List<condition>();
            List<condition> deviceconlist = new List<condition>();
            List<condition> macconlist = new List<condition>();

            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            Maticsoft.BLL.area_infor areaservice = new Maticsoft.BLL.area_infor();
            List<Maticsoft.Model.area_infor> arealist = new List<Maticsoft.Model.area_infor>();
            Maticsoft.BLL.fenbu_infor fenbuservice = new Maticsoft.BLL.fenbu_infor();
            List<Maticsoft.Model.fenbu_infor> fenbulist= new List<Maticsoft.Model.fenbu_infor>();
            Maticsoft.BLL.ywb_infor ywbservice = new Maticsoft.BLL.ywb_infor();
            List<Maticsoft.Model.ywb_infor> ywblist = new List<Maticsoft.Model.ywb_infor>();
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            Maticsoft.BLL.building_infor buildservice = new Maticsoft.BLL.building_infor();
            List<Maticsoft.Model.building_infor> buildlist = new List<Maticsoft.Model.building_infor>();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
            List<Maticsoft.Model.machine_infor> maclist = new List<Maticsoft.Model.machine_infor>();
            Maticsoft.BLL.devicetype_infor typeservice = new Maticsoft.BLL.devicetype_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
            {
                return null;
            }        
            string sql = "1=1";
            if (usermodel.usertype == "0")
            {
                if (areaid == "")
                {
                    areaid = usermodel.areaid;
                }
                sql += " and areaid='" + areaid + "' ";
                arealist = areaservice.GetModelList(sql);
                fenbulist = fenbuservice.GetModelList(sql);
                if (fenbuid != "" && fenbuid != "全部")
                {
                    sql += " and fenbuid='" + fenbuid + "' ";
                }
                ywblist = ywbservice.GetModelList(sql);
                if (ywbid !="" && ywbid != "全部")
                {
                    sql += " and ywbid='" + ywbid + "' ";
                }
                stationlist = stationservice.GetModelList(sql);
                if (stationid != "" && stationid != "全部")
                {
                    sql += " and stationid='" + stationid + "' ";
                }
                buildlist = buildservice.GetModelList(sql);
                if (buildingid !="" && buildingid != "全部")
                {
                    sql += " and buildingid='" + buildingid + "' ";
                }
                maclist = macservice.GetModelList(sql);
                //if (deviceid !="" && deviceid != "全部")
                //{
                //    sql += " and deviceid='" + deviceid + "' ";
                //}
                if (machineid !="" && machineid != "全部")
                {
                    sql += " and machineid='" + machineid + "' ";
                }
                if (devicetype != "" && devicetype != "全部")
                {
                    sql += " and ysdtype='" + devicetype + "' ";
                }
                devicelist = deviceservice.GetModelList(sql);
            }
            if (usermodel.usertype == "1")
            {
                if (areaid == "")
                {
                    areaid = usermodel.areaid;
                }
                sql += " and areaid='" + areaid + "' ";
                arealist = areaservice.GetModelList(sql);
                if (fenbuid == "")
                {
                    fenbuid = usermodel.fenbuid;
                }
                 sql += " and fenbuid='" + fenbuid + "' ";
                fenbulist = fenbuservice.GetModelList(sql);
                ywblist = ywbservice.GetModelList(sql);
                if (ywbid != "" && ywbid != "全部")
                {
                    sql += " and ywbid='" + ywbid + "' ";
                }
                stationlist = stationservice.GetModelList(sql);
                if (stationid != "" && stationid != "全部")
                {
                    sql += " and stationid='" + stationid + "' ";
                }
                buildlist = buildservice.GetModelList(sql);
                if (buildingid != "" && buildingid != "全部")
                {
                    sql += " and buildingid='" + buildingid + "' ";
                }
                maclist = macservice.GetModelList(sql);
                //if (deviceid != "" && deviceid != "全部")
                //{
                //    sql += " and deviceid='" + deviceid + "' ";
                //}
                if (machineid != "" && machineid != "全部")
                {
                    sql += " and machineid='" + machineid + "' ";
                }
                if (devicetype != "" && devicetype != "全部")
                {

                    sql += " and ysdtype='" + devicetype + "' ";
                }
                devicelist = deviceservice.GetModelList(sql);

            }
            if (usermodel.usertype == "2")
            {
                if (areaid == "")
                {
                    areaid = usermodel.areaid;
                }
                sql += " and areaid='" + areaid + "' ";
                arealist = areaservice.GetModelList(sql);
                if (fenbuid == "")
                {
                    fenbuid = usermodel.fenbuid;
                }
                 sql += " and fenbuid='" + fenbuid + "' ";
                fenbulist = fenbuservice.GetModelList(sql);
                if (ywbid == "")
                {
                    ywbid = usermodel.ywbid;
                }
                 sql += " and ywbid='" + ywbid + "' ";
                ywblist = ywbservice.GetModelList(sql);
                stationlist = stationservice.GetModelList(sql);
                if (stationid != "" && stationid != "全部")
                {
                    sql += " and stationid='" + stationid + "' ";
                }
                buildlist = buildservice.GetModelList(sql);
                if (buildingid != "" && buildingid != "全部")
                {
                    sql += " and buildingid='" + buildingid + "' ";
                }
                maclist = macservice.GetModelList(sql);
                //if (deviceid != ""&& deviceid != "全部")
                //{
                //    sql += " and deviceid='" + deviceid + "' ";
                //}
                if (machineid != "" && machineid != "全部")
                {
                    sql += " and machineid='" + machineid + "' ";
                }
                if (devicetype != "" && devicetype != "全部")
                {
                    sql += " and ysdtype='" + devicetype + "' ";
                }
                devicelist = deviceservice.GetModelList(sql);
            }
            if (usermodel.usertype == "3")
            {              
                arealist = areaservice.GetModelList(sql);
                if (areaid != "" && areaid != "全部")
                {
                    sql += " and areaid='" + areaid + "' ";
                }
                fenbulist = fenbuservice.GetModelList(sql);
                if (fenbuid != "" && fenbuid != "全部")
                {
                    sql += " and fenbuid='" + fenbuid + "' ";
                }
                ywblist = ywbservice.GetModelList(sql);
                if (ywbid != "" && ywbid != "全部")
                {
                    sql += " and ywbid='" + ywbid + "' ";
                }
                stationlist = stationservice.GetModelList(sql);
                if (stationid != "" && stationid != "全部")
                {
                    sql += " and stationid='" + stationid + "' ";
                }
                buildlist = buildservice.GetModelList(sql);
                if (buildingid != "" && buildingid != "全部")
                {
                    sql += " and buildingid='" + buildingid + "' ";
                }
                maclist = macservice.GetModelList(sql);
                if (machineid != "" && machineid != "全部")
                {
                    sql += " and machineid='" + machineid + "' ";
                }
                //if (deviceid != "" && deviceid != "全部")
                //{
                //    sql += " and deviceid='" + deviceid + "' ";
                //}
                if (devicetype != "" && devicetype != "全部")
                {
                    sql += " and ysdtype='" + devicetype + "' ";
                }
                devicelist = deviceservice.GetModelList(sql);
            }

            if (devicelist.Count > 0)//设备数据
            {
                if (deviceid != "")
                {
                    Maticsoft.Model.device_infor devicemodel =  deviceservice.GetModel(deviceid);
                    if (devicemodel!=null)
                    {
                        //选中之后重新给上级赋值（同一个工区的数据）
                        areaid = devicemodel.areaid;
                        fenbuid = devicemodel.fenbuid;
                        ywbid = devicemodel.ywbid;
                        stationid = devicemodel.stationid;
                        buildingid = devicemodel.buildingid;
                        machineid = devicemodel.machineid;
                        devicetype = devicemodel.ysdtype;
                        fenbulist = fenbuservice.GetModelList("areaid='" + areaid + "'");
                        ywblist = ywbservice.GetModelList("fenbuid='" + fenbuid + "'");
                        stationlist = stationservice.GetModelList("ywbid='" + ywbid + "'");
                        buildlist = buildservice.GetModelList("stationid='" + stationid + "'");
                        maclist = macservice.GetModelList("buildingid='" + buildingid + "'order by machinename ");
                        devicelist = deviceservice.GetModelList("buildingid='" + buildingid + "' and ysdtype='" + devicetype + "'");
                    }                                
                }
                for (int a = 0; a < devicelist.Count; a++)
                {
                    condition devicecon = new condition();
                    devicecon.Id = devicelist[a].deviceid;
                    devicecon.Name = devicelist[a].devicename;
                    if (deviceid != "" && deviceid == devicelist[a].deviceid)
                    {
                        devicecon.Show = "1";                   
                    }
                    else
                    {
                        devicecon.Show = "0";
                    }
                    deviceconlist.Add(devicecon);
                }
                json.Devicelist = deviceconlist;
            }

            if (maclist.Count > 0)//红外设备数据
            {
                if (machineid != "")
                {
                    Maticsoft.Model.machine_infor macmodel =  macservice.GetModel(machineid);
                    if (macmodel!=null)
                    {                      
                        //选中之后重新给上级赋值（同一个工区的数据）
                        areaid = macmodel.areaid;
                        fenbuid = macmodel.fenbuid;
                        ywbid = macmodel.ywbid;
                        stationid = macmodel.stationid;
                        buildingid = macmodel.buildingid;
                        fenbulist = fenbuservice.GetModelList("areaid='" + areaid + "'");
                        ywblist = ywbservice.GetModelList("fenbuid='" + fenbuid + "'");
                        stationlist = stationservice.GetModelList("ywbid='" + ywbid + "'");
                        buildlist = buildservice.GetModelList("stationid='" + stationid + "'");
                        maclist = macservice.GetModelList("buildingid='" + buildingid + "' order by machinename ");
                    }
                }
                //对红外设备进行排序
                maclist = maclist.OrderBy(u => u.machinename).ToList();
                for (int a = 0; a < maclist.Count; a++)
                {
                    condition maccon = new condition();
                    maccon.Id = maclist[a].machineid;
                    maccon.Name = maclist[a].machinename;
                    if (machineid != "" && machineid == maclist[a].machineid)
                    {
                        maccon.Show = "1";
                    }
                    else
                    {
                        maccon.Show = "0";
                    }
                    macconlist.Add(maccon);
                }
                json.Machinelist = macconlist;
            }

           

            if (buildlist.Count > 0)//设备区数据
            {
                if (buildingid != "" )
                {
                    Maticsoft.Model.building_infor buildmodel =  buildservice.GetModel(buildingid);
                    if (buildmodel!=null)
                    {
                        //选中之后重新给上级赋值（同一个工区的数据）
                        areaid = buildmodel.areaid;
                        fenbuid = buildmodel.fenbuid;
                        ywbid = buildmodel.ywbid;
                        stationid = buildmodel.stationid;
                        fenbulist = fenbuservice.GetModelList("areaid='" + areaid + "'");
                        ywblist = ywbservice.GetModelList("fenbuid='" + fenbuid + "'");
                        stationlist = stationservice.GetModelList("ywbid='" + ywbid + "'");
                        buildlist = buildservice.GetModelList("stationid='" + stationid + "'");
                    }                
                   
                }
                for (int a = 0; a < buildlist.Count; a++)
                {
                    condition buildcon = new condition();
                    buildcon.Id = buildlist[a].buildingid;
                    buildcon.Name = buildlist[a].buildingname;
                    if (buildingid != "" && buildingid == buildlist[a].buildingid)
                    {
                        buildcon.Show = "1";
                    }
                    else
                    {
                        buildcon.Show = "0";
                    }
                    buildconlist.Add(buildcon);
                }
                json.Buildinglist = buildconlist;
            }

            if (stationlist.Count > 0)//变电站数据
            {
                if (stationid != "" )
                {
                    Maticsoft.Model.station_infor stationmodel = stationservice.GetModel(stationid);
                    if (stationmodel!=null)
                    {
                        //选中之后重新给上级赋值（同一个工区的数据）
                        areaid = stationmodel.areaid;
                        fenbuid = stationmodel.fenbuid;
                        ywbid = stationmodel.ywbid;
                        fenbulist = fenbuservice.GetModelList("areaid='" + areaid + "'");
                        ywblist = ywbservice.GetModelList("fenbuid='" + fenbuid + "'");
                        stationlist = stationservice.GetModelList("ywbid='" + ywbid + "'");

                    }
                }
                for (int a = 0; a < stationlist.Count; a++)
                {
                    condition stationcon = new condition();
                    stationcon.Id = stationlist[a].stationid;
                    stationcon.Name = stationlist[a].stationname;
                    if (stationid != "" && stationid == stationlist[a].stationid)
                    {
                        stationcon.Show = "1";
                    }
                    else
                    {
                        stationcon.Show = "0";
                    }
                    stationconlist.Add(stationcon);
                }
                json.Stationlist = stationconlist;
            }

            if (ywblist.Count > 0)//运维班数据
            {
                if (ywbid != "" )
                {
                    Maticsoft.Model.ywb_infor ywbmodel =  ywbservice.GetModel(ywbid);
                    if (ywbmodel!=null)
                    {
                        //选中之后重新给上级赋值（同一个工区的数据）
                        areaid = ywbmodel.areaid;
                        fenbuid = ywbmodel.fenbuid;
                        fenbulist = fenbuservice.GetModelList("areaid='" + areaid + "'");
                        ywblist = ywbservice.GetModelList("fenbuid='" + fenbuid + "'");
                    }                 
                }
                for (int a = 0; a < ywblist.Count; a++)
                {
                    condition ywbcon = new condition();
                    ywbcon.Id = ywblist[a].ywbid;
                    ywbcon.Name = ywblist[a].ywbname;
                    if (ywbid != "" && ywbid == ywblist[a].ywbid)
                    {
                        ywbcon.Show = "1";         
                    }
                    else
                    {
                        ywbcon.Show = "0";
                    }
                    ywbconlist.Add(ywbcon);
                }
                json.Ywblist = ywbconlist;
            }

            if (fenbulist.Count > 0)//分部数据

            {
                if (fenbuid != "" )
                {
                    Maticsoft.Model.fenbu_infor fenbumodel =  fenbuservice.GetModel(fenbuid);
                    if (fenbumodel!=null)
                    {
                       areaid = fenbumodel.areaid;
                       fenbulist = fenbuservice.GetModelList("areaid='" + areaid + "'");
                    }
                }
                for (int a = 0; a < fenbulist.Count; a++)
                {
                    condition fenbucon = new condition();
                    fenbucon.Id = fenbulist[a].fenbuid;
                    fenbucon.Name = fenbulist[a].fenbuname;
                    if (fenbuid != "" && fenbuid == fenbulist[a].fenbuid)
                    {
                        fenbucon.Show = "1";
                    }
                    else
                    {
                        fenbucon.Show = "0";
                    }
                    fenbuconlist.Add(fenbucon);
                }
                json.Fenbulist = fenbuconlist;
            }

            if (arealist.Count>0)//公司数据
            {
                for (int a = 0; a < arealist.Count;a++ )
                {
                    condition areacon = new condition();
                  
                    areacon.Id = arealist[a].areaid;
                    areacon.Name = arealist[a].areaname;
                    if (areaid !="" && areaid == arealist[a].areaid)
                    {
                        areacon.Show = "1";
                    }
                    else
                    {
                        areacon.Show = "0";
                    }                   
                    areaconlist.Add(areacon);
                }
                json.Arealist = areaconlist;
            }
           
            //设备类型          
            List<Maticsoft.Model.devicetype_infor> typelist = new List<Maticsoft.Model.devicetype_infor>();
            List<condition> devicetypelist = new List<condition>();
            typelist = typeservice.GetModelList("");
            if (typelist.Count > 0)
            {
                 foreach(var type in typelist){
                     if (type != null)
                     {
                         condition con = new condition();
                         con.Id = type.devicetypeid;
                         con.Name = type.devicetype;
                         if (devicetype != "" && devicetype != "全部" && devicetype != null)
                         {
                             if (devicetype == type.devicetype)
                             {
                                 con.Show = "1";//需要显示的名称
                                //重新更换红外设备集合
                                macconlist.Clear();
                                if (devicelist.Count > 0)//设备数据
                                {
                                    if (deviceid != "")
                                    {
                                        Maticsoft.Model.device_infor devicemodel = deviceservice.GetModel(deviceid);
                                        if (devicemodel!=null)
                                        {
                                            string machineid1 = devicemodel.machineid;
                                            Maticsoft.Model.machine_infor macmodel = macservice.GetModel(machineid1);
                                            if (macmodel!=null)
                                            {
                                                condition maccon = new condition();
                                                maccon.Id = macmodel.machineid;
                                                maccon.Name = macmodel.machinename;
                                                maccon.Show = "0";
                                                macconlist.Add(maccon);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        for (int deviceindes = 0; deviceindes < devicelist.Count; deviceindes++)
                                        {
                                            string machineid2 = devicelist[deviceindes].machineid;
                                            Maticsoft.Model.machine_infor macmodel = macservice.GetModel(machineid2);
                                            if (macmodel != null)
                                            {
                                                bool falg = true;
                                                if (macconlist.Count > 0)//去掉重复的红外设备
                                                {
                                                    for (int mac = 0; mac < macconlist.Count; mac++)
                                                    {
                                                        if (macmodel.machineid== macconlist[mac].Id)
                                                        {
                                                            falg = false;
                                                        }
                                                    }
                                                }
                                                if (falg)
                                                {
                                                    condition maccon = new condition();
                                                    maccon.Id = macmodel.machineid;
                                                    maccon.Name = macmodel.machinename;
                                                    maccon.Show = "0";
                                                    macconlist.Add(maccon);
                                                }                                              
                                            }
                                        }
                                    }
                                    json.Machinelist = macconlist;
                                }
                            }
                            else
                            {
                                con.Show = "0";
                            }
                        }
                        else
                        {
                            con.Show = "0";
                        }
                        devicetypelist.Add(con);
                     }
                }
            }
            json.Devicetypelist = devicetypelist;

            json.status = "1";
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            //return json;
        }
        #endregion
        #region 巡视接口
        public string patrol(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string machineid, string nextdevice,string imagetype)

        {
            patroljson json = new patroljson();
            Maticsoft.BLL.user_infor userservicie = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservicie.GetModel(userid);
            if (usermodel == null)
                return "该用户不存在";
            Maticsoft.BLL.area_infor areaservice = new Maticsoft.BLL.area_infor();
            Maticsoft.BLL.fenbu_infor fenbuservice = new Maticsoft.BLL.fenbu_infor();
            Maticsoft.BLL.ywb_infor ywbservice = new Maticsoft.BLL.ywb_infor();
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            Maticsoft.BLL.building_infor buildservice = new Maticsoft.BLL.building_infor();
            Maticsoft.BLL.machine_infor machineser = new Maticsoft.BLL.machine_infor();
            List<Maticsoft.Model.machine_infor> machinelistmodel = new List<Maticsoft.Model.machine_infor>();
            Maticsoft.Model.machine_infor machinemodel = new Maticsoft.Model.machine_infor();
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.BLL.image_record_history imageService = new Maticsoft.BLL.image_record_history();
            if (usermodel.usertype == "0")
            {
                if (areaid =="")
                {
                     areaid = usermodel.areaid;
                }
                json.areaid = usermodel.areaid;
                if (fenbuid == "")
                {
                    List<Maticsoft.Model.fenbu_infor> fenbulist = fenbuservice.GetModelList("areaid='" + areaid + "'");
                    if (fenbulist.Count > 0)
                    {
                        fenbuid = fenbulist[0].fenbuid;
                    }

                }

                 json.fenbuid = fenbuid;              
                if (ywbid == "")
                {
                    List<Maticsoft.Model.ywb_infor> ywblist = ywbservice.GetModelList("fenbuid='" + fenbuid + "'");
                    if (ywblist.Count > 0)
                    {
                        ywbid = ywblist[0].ywbid;                      
                    }
                }
                json.ywbid = ywbid;                                                                    
            }
            if (usermodel.usertype == "1")
            {
                if (areaid == "")
                {
                    areaid = usermodel.areaid;
                }
                fenbuid = usermodel.fenbuid;
                if (fenbuid == "")
                {
                    json.areaid = usermodel.areaid;
                }
                json.fenbuid = usermodel.fenbuid;
                if (ywbid == "")
                {
                    List<Maticsoft.Model.ywb_infor> ywblist = ywbservice.GetModelList("fenbuid='" + fenbuid + "'");
                    if (ywblist.Count > 0)
                    {
                        ywbid = ywblist[0].ywbid;
                    }
                }
                json.ywbid = ywbid;
            }
            if (usermodel.usertype == "2")
            {
                if (areaid == "")
                {
                    areaid = usermodel.areaid;
                }
                if (fenbuid == "")
                {
                    json.areaid = usermodel.areaid;
                }
                if (ywbid == "")
                {
                    ywbid = usermodel.ywbid;
                }
                json.areaid = usermodel.areaid;
                json.fenbuid = usermodel.fenbuid;
                json.ywbid = usermodel.ywbid;                                              
            }
            if (usermodel.usertype == "3")
            {
                if (areaid == "")
                {
                    areaid = areaservice.GetModelList("")[0].areaid;
                }
                json.areaid = areaid;
                if (fenbuid == "")
                {
                    List<Maticsoft.Model.fenbu_infor> fenbulist = fenbuservice.GetModelList("areaid='" + areaid + "'");
                    if (fenbulist.Count > 0)
                    {
                        fenbuid = fenbulist[0].fenbuid;
                    }

                }
                json.fenbuid = fenbuid;
                if (ywbid == "")
                {
                    List<Maticsoft.Model.ywb_infor> ywblist = ywbservice.GetModelList("fenbuid='" + fenbuid + "'");
                    if (ywblist.Count > 0)
                    {
                        ywbid = ywblist[0].ywbid;                
                    }
                }
                json.ywbid = ywbid;
                //machinelistmodel = machineser.GetModelList(" ORDER BY installcode ASC");                        
            }


            //根据ywbid查询红外设备
            if (stationid == "")
            {
                List<Maticsoft.Model.station_infor> stationlist = stationservice.GetModelList("ywbid='" + ywbid + "'");
                if (stationlist.Count > 0)
                {
                    stationid = stationlist[0].stationid;
                }
            }
            json.stationid = stationid;
            //if (buildingid == "")
            //{
            //    List<Maticsoft.Model.building_infor> buildlist = buildservice.GetModelList("stationid = '" + stationid + "'");
            //    if (buildlist.Count > 0)
            //    {
            //        buildingid = buildlist[0].buildingid;
            //    }
            //}
            json.buildingid = buildingid;
            if (machineid !="")
            {
                machinemodel = machineser.GetModel(machineid);
            }else if (buildingid!="")
            {
                //machinelistmodel = machineser.GetModelList("buildingid='" + buildingid + "'" + " ORDER BY installcode ASC");
                machinelistmodel = machineser.GetModelList("buildingid='" + buildingid + "'" );
            }
            else
            {
                //machinelistmodel = machineser.GetModelList("stationid='" + stationid + "'" + " ORDER BY installcode ASC");
                machinelistmodel = machineser.GetModelList("stationid='" + stationid + "'" );
            }

            List<stationImagejson> jsonlist = new List<stationImagejson>();
         
            int index = 0;
            if (nextdevice != "")
            {
                index = Convert.ToInt32(nextdevice);
            }
            json.indexnumber = nextdevice;
            if (imagetype == "")
            {
                imagetype = "0";
            }
            string isopen = "1";
            if (machinelistmodel.Count>0)
            {
                if (index< machinelistmodel.Count)
                {
                    json.machineid = machinelistmodel[index].machineid;
                    json.machinename = machinelistmodel[index].machinename;
                    json.areaid = machinelistmodel[index].areaid;
                    json.fenbuid = machinelistmodel[index].fenbuid;
                    json.ywbid = machinelistmodel[index].ywbid;
                    json.stationid = machinelistmodel[index].stationid;
                    json.buildingid = machinelistmodel[index].buildingid;
                    DataTable dt = new DataTable();
                    dt = deviceservice.GetList("machineid='" + machinelistmodel[index].machineid + "' and isopen='" + isopen + "'").Tables[0];
                    if (dt.Rows.Count > 0)
                    {
                        DataView dv = dt.DefaultView;
                        dv.Sort = "ysdname ASC";
                        dt = dv.ToTable();

                        dt.Columns.Add("machinecode", Type.GetType("System.String"));
                        dt.Columns.Add("image", Type.GetType("System.String"));
                        for (int i=0;i< dt.Rows.Count;i++)
                        {
                           dt.Rows[i]["machinecode"] = machinelistmodel[index].machinecode;
                            //替换可见光图片                         
                            //dt.Rows[i]["image_high"] = dt.Rows[i]["image_red"];
                            //dt.Rows[i]["image_red"] = dt.Rows[i]["image_high"];
                            //dt.Rows[i]["image_mix"] = dt.Rows[i]["image_mix"];                                                  
                            if (imagetype=="0")
                            {
                                dt.Rows[i]["image"] = dt.Rows[i]["image_red"];
                            }
                            else if (imagetype == "1")
                            {
                                dt.Rows[i]["image"] = dt.Rows[i]["image_mix"];
                            }
                            else if (imagetype == "2")
                            {
                                dt.Rows[i]["image"] = dt.Rows[i]["image_high"];
                            }                           
                        }
                        //删除图片三列
                        dt.Columns.Remove("image_high");
                        dt.Columns.Remove("image_red");
                        dt.Columns.Remove("image_mix");
                        if (index == (machinelistmodel.Count - 1))//判断是否为最后一个
                        {
                            json.isLast = "1";
                        }
                        json.Imagedt = dt;
                    }
                }
            } else if (machinemodel != null)
            {
                json.machineid = machinemodel.machineid;
                json.machinename = machinemodel.machinename;
                json.areaid = machinemodel.areaid;
                json.fenbuid = machinemodel.fenbuid;
                json.ywbid = machinemodel.ywbid;
                json.stationid = machinemodel.stationid;
                json.buildingid = machinemodel.buildingid;
                DataTable dt = new DataTable();
                dt = deviceservice.GetList("machineid='" +machineid + "' and isopen='" + isopen + "'").Tables[0];
                if (dt.Rows.Count > 0)
                {
                    //对数据进行预设点排序
                    DataView dv = dt.DefaultView;
                    dv.Sort = "ysdname ASC";
                    dt = dv.ToTable();                  
                    if (index == machinelistmodel.Count - 1)//判断是否为最后一个
                    {
                        json.isLast = "1";
                    }
                    dt.Columns.Add("machinecode", Type.GetType("System.String"));
                    dt.Columns.Add("image", Type.GetType("System.String"));
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dt.Rows[i]["machinecode"] = machinemodel.machinecode;
                       
                        if (imagetype == "0")
                        {
                            dt.Rows[i]["image"] = dt.Rows[i]["image_red"];
                        }
                        else if (imagetype == "1")
                        {
                            dt.Rows[i]["image"] = dt.Rows[i]["image_mix"];
                        }
                        else if (imagetype == "2")
                        {
                            dt.Rows[i]["image"] = dt.Rows[i]["image_high"];
                        }
                        
                    }
                    //删除图片三列
                    dt.Columns.Remove("image_high");
                    dt.Columns.Remove("image_red");
                    dt.Columns.Remove("image_mix");
                    json.Imagedt = dt;
                }
            }         
            //json.Devicecount = devicecountint;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }
      
        public string saveDeviceException(string userid, string deviceid,string typeid)
        {
            returnjson json = new returnjson();
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
            {
                json.msg = "该用户不存在";
                json.falg = false;
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
            devicemodel =  deviceservice.GetModel(deviceid);
            if (devicemodel == null)
            {
                json.msg = "该设备不存在";
                json.falg = false;
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            //修改设备巡视状态为异常
            deviceservice.UpdatePatrolStatus(deviceid,"2");
            Maticsoft.BLL.device_exception_infor deviceExceptionservice = new Maticsoft.BLL.device_exception_infor();
            Maticsoft.Model.device_exception_infor deviceExceptionmodel = new Maticsoft.Model.device_exception_infor();
            deviceExceptionmodel.id = Guid.NewGuid().ToString("N");
            deviceExceptionmodel.areaid = devicemodel.areaid;
            deviceExceptionmodel.areaname = devicemodel.areaname;
            deviceExceptionmodel.fenbuid = devicemodel.fenbuid;
            deviceExceptionmodel.fenbuname = devicemodel.fenbuname;
            deviceExceptionmodel.ywbid = devicemodel.ywbid;
            deviceExceptionmodel.ywbname = devicemodel.ywbname;
            deviceExceptionmodel.stationid = devicemodel.stationid;
            deviceExceptionmodel.stationname = devicemodel.stationname;
            deviceExceptionmodel.buildingid = devicemodel.buildingid;
            deviceExceptionmodel.buildingname = devicemodel.buildingname;
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor machinemodel = machineservice.GetModel(devicemodel.machineid);
            if (machinemodel !=null )
            {
                deviceExceptionmodel.machineid = machinemodel.machineid;
                deviceExceptionmodel.machinecode = machinemodel.machinecode;
                deviceExceptionmodel.machinename = machinemodel.machinename;
            }
            deviceExceptionmodel.operaterNumber = devicemodel.operaterNumber;
            deviceExceptionmodel.ysdindex = devicemodel.ysdindex;
            deviceExceptionmodel.ysdname = devicemodel.ysdname;
            deviceExceptionmodel.deviceid = devicemodel.deviceid;
            deviceExceptionmodel.devicename = devicemodel.devicename;
            deviceExceptionmodel.image_high = devicemodel.image_high;
            deviceExceptionmodel.image_mix = devicemodel.image_mix;
            deviceExceptionmodel.image_red = devicemodel.image_red;
            deviceExceptionmodel.temperature = devicemodel.todaytop;
            if (typeid != null && typeid != "")
            {
                Maticsoft.BLL.exception_type_infor typeService = new Maticsoft.BLL.exception_type_infor();              
                Maticsoft.Model.exception_type_infor typeModel = typeService.GetModel(typeid);
                if (typeModel!=null)
                {
                    deviceExceptionmodel.exceptiontypeid = typeModel.exceptiontypeid;
                    deviceExceptionmodel.typename = typeModel.typename;
                    deviceExceptionmodel.description = typeModel.description;
                }
            }
            deviceExceptionmodel.catchtime = devicemodel.createtime;
            deviceExceptionmodel.createtime = System.DateTime.Now;
            deviceExceptionmodel.discoverer = usermodel.username;
            deviceExceptionmodel.patrolid = userid;
            deviceExceptionmodel.status = "1";//未消除状态
            deviceExceptionservice.Add(deviceExceptionmodel);
            json.msg = "录入异常数据成功";
            json.falg = true;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }

        public string saveDevicePatorl(string userid, string inspector)
        {
            returnjson json = new returnjson();
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
            {
                json.msg = "该用户不存在";
                json.falg = false;
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            //查询正常的数据
            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist1 = new List<Maticsoft.Model.device_infor>();
            devicelist1 = deviceService.GetModelList("temporary = '" + userid + "'");
            //查询异常的数据
            Maticsoft.BLL.device_exception_infor devoceExceptionservice = new Maticsoft.BLL.device_exception_infor();
            List<Maticsoft.Model.device_exception_infor> deviceExceptionlist = new List<Maticsoft.Model.device_exception_infor>();
            deviceExceptionlist = devoceExceptionservice.GetModelList("patrolid = '" + userid + "' GROUP BY stationid");
            Maticsoft.BLL.station_infor stationService = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> stationlist = new List<Maticsoft.Model.station_infor>();
            if (deviceExceptionlist.Count > 0)
            {
                for (int i = 0; i < deviceExceptionlist.Count; i++)
                {
                    string stationid = deviceExceptionlist[i].stationid;
                    Maticsoft.Model.station_infor stationModel = stationService.GetModel(stationid);
                    if (stationModel!=null) {
                        stationlist.Add(stationModel);
                    }
                }
            }
            if (devicelist1.Count>0)
            {
                for(int k=0;k< devicelist1.Count;k++)
                {
                    string deviceid = devicelist1[k].deviceid;
                    //修改无状态的设备为正常
                    deviceService.UpdatePatrolStatus(deviceid, "1");

                    string stationid = devicelist1[k].stationid;
                    Maticsoft.Model.station_infor stationModel = stationService.GetModel(stationid);
                    if (stationModel != null)
                    {
                        if (stationlist.Count>0)
                        {
                            bool falg = true;
                            for (int s=0;s< stationlist.Count;s++)
                            {
                                if (stationModel.stationid == stationlist[s].stationid)
                                {
                                    falg = false;
                                }
                            }
                            if (falg)
                            {
                                stationlist.Add(stationModel);
                            }
                        }
                        else
                        {
                            stationlist.Add(stationModel);
                        }
                    }
                }
            }
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.BLL.device_patrol_infor devicePatrolService = new Maticsoft.BLL.device_patrol_infor();
            if (stationlist.Count>0)
            {
                for (int j=0;j< stationlist.Count;j++)
                {
                    Maticsoft.Model.device_patrol_infor devicePatrolModel = new Maticsoft.Model.device_patrol_infor();
                    devicePatrolModel.patrolid = Guid.NewGuid().ToString("N");
                    //添加变电站数据
                    devicePatrolModel.areaid = stationlist[j].areaid;
                    devicePatrolModel.areaname = stationlist[j].areaname;
                    devicePatrolModel.fenbuid = stationlist[j].fenbuid;
                    devicePatrolModel.fenbuname = stationlist[j].fenbuname;
                    devicePatrolModel.ywbid = stationlist[j].ywbid;
                    devicePatrolModel.ywbname = stationlist[j].ywbname;
                    devicePatrolModel.stationid = stationlist[j].stationid;
                    devicePatrolModel.stationname = stationlist[j].stationname;
                    //该变电站下设备总数量
                    List<Maticsoft.Model.device_infor> devicelist = deviceservice.GetModelList("");
                    devicelist = deviceservice.GetModelList("stationid = '" + stationlist[j].stationid + "'");
                    devicePatrolModel.patrolnumber = devicelist.Count;
                    //该变电站下异常设备数量
                    string status = "1";//未消除状态
                    List<Maticsoft.Model.device_exception_infor> exceptionlist =  devoceExceptionservice.GetModelList("stationid = '" + stationlist[j].stationid + "' and status = '"+status+"'");
                    devicePatrolModel.exceptionnumber = exceptionlist.Count;
                    //修改异常设备的patrolid（刚开始存的值为userid，此时需要修改）
                    if (exceptionlist.Count>0)
                    {
                        for (int e = 0; e < exceptionlist.Count; e++)
                        {
                            exceptionlist[e].patrolid = devicePatrolModel.patrolid;
                            devoceExceptionservice.Update(exceptionlist[e]);
                        }
                        devicePatrolModel.conclusion = "异常";
                    }
                    else
                    {                      
                        devicePatrolModel.conclusion = "正常";
                    }
                    if (devicelist1.Count > 0)
                    {
                        for (int e = 0; e < devicelist1.Count; e++)
                        {
                            deviceService.UpdateTemporary(devicelist1[e].deviceid, "1", devicePatrolModel.patrolid);
                        }
                    }
                    devicePatrolModel.createtime = System.DateTime.Now;
                    devicePatrolModel.inspector = inspector;
                    devicePatrolService.Add(devicePatrolModel);
                }
            }         
            json.msg = "录入巡视数据成功";
            json.falg = true;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }


        public string findDevicePatorl(string userid, string areaid, string fenbuid, string ywbid, string stationid,string inspector, string page, string limit, string starttime,string endtime,string conclusion)
        {
            returnxunshijson json = new returnxunshijson();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
            {
                json.falg = false;
                json.msg = "用户不存在";
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            if (usermodel.usertype == "0")
            {
                {
                    areaid = usermodel.areaid;
                }
            }
            if (usermodel.usertype == "1")
            {
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                {
                    ywbid = usermodel.ywbid;
                }
            }
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部")
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部")
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部")
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部")
                sqllist.Add("stationid='" + stationid + "'");
            if (inspector != "" && inspector != "全部")
                sqllist.Add("inspector='" + inspector + "'");
            if(conclusion != "" && conclusion != "全部")
                sqllist.Add("conclusion='" + conclusion + "'");
            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql = "";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1];
            }
            if (sql == "")
            {
                sql += "1=1 ";
            }
            if (starttime != "")
            {
                sql += "and createtime >'" + starttime + "'";
            }
            if (endtime!="")
            {
                sql += "and createtime <'" + endtime + "'";
            }
            if (limit == "")
            {
                limit = "12";
            }
            if (page == "")
            {
                page = "1";
            }
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1) * int.Parse(limit);
            Maticsoft.BLL.device_patrol_infor devicepatrolService = new Maticsoft.BLL.device_patrol_infor();
            List<Maticsoft.Model.device_patrol_infor> parrollist = devicepatrolService.GetModelList("");
            List <Maticsoft.Model.device_patrol_infor> devicepatrollist = new List<Maticsoft.Model.device_patrol_infor>();
            devicepatrollist = devicepatrolService.GetModelList(sql + " order by createtime desc limit " + npage + "," + end + "");         
            json.falg = true;
            json.msg = "查询成功";
            json.patrollist = devicepatrollist;
            json.count = parrollist.Count;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }
        public string findDeviceException(string userid, string areaid, string fenbuid, string ywbid, string stationid, string page, string limit, string starttime, string endtime, string typename, string typeid, string status)
        {
            returnxunshijson json = new returnxunshijson();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel == null)
            {
                json.falg = false;
                json.msg = "用户不存在";
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            if (usermodel.usertype == "0")
            {
                {
                    areaid = usermodel.areaid;
                }
            }
            if (usermodel.usertype == "1")
            {
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                {
                    ywbid = usermodel.ywbid;
                }
            }
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部")
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部")
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部")
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部")
                sqllist.Add("stationid='" + stationid + "'");
            if (typename != "" && typename != "全部")
                sqllist.Add("typename='" + typename + "'");
            if (typeid != "" && typeid != "全部")
                sqllist.Add("exceptiontypeid='" + typeid + "'");
            if (status != "" && status != "全部")
                sqllist.Add("status='" + status + "'");
            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql = "";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1];
            }
            if (sql == "")
            {
                sql += "1=1 ";
            }
            if (starttime != "")
            {
                sql += "and createtime >'" + starttime + "'";
            }
            if (endtime != "")
            {
                sql += "and createtime <'" + endtime + "'";
            }
            if (limit=="")
            {
                limit = "12";
            }
            if (page=="")
            {
                page = "1";
            }
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1) * int.Parse(limit);
            Maticsoft.BLL.device_exception_infor deviceexceptionService = new Maticsoft.BLL.device_exception_infor();
            List<Maticsoft.Model.device_exception_infor> list = deviceexceptionService.GetModelList(sql);         
            //List<Maticsoft.Model.device_exception_infor> deviceexceptionlist = new List<Maticsoft.Model.device_exception_infor>();
            //deviceexceptionlist =  deviceexceptionService.GetModelList(sql + " order by createtime desc limit " + npage + "," + end + "");
            DataTable dt = new DataTable();
            dt = deviceexceptionService.GetList(sql + " order by createtime desc limit " + npage + "," + end + "").Tables[0];
            if (dt.Rows.Count > 0)
            {
                //对数据进行预设点排序
                DataView dv = dt.DefaultView;
                dv.Sort = "ysdname ASC";
                dt = dv.ToTable();
                dt.Columns.Add("todaytop", Type.GetType("System.String"));
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dt.Rows[i]["todaytop"] = dt.Rows[i]["temperature"];

                }
            }
            json.falg = true;
            json.msg = "查询成功";
            json.exceptionlist = dt;
            json.count = list.Count;
            //json.typelist = typelist;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }

        public string findDeviceExceptionByPatrolid(string patrolid, string page, string limit, string typename)
        {
            returnxunshijson json = new returnxunshijson();
            if (patrolid == "")
            {
                json.falg = false;
                json.msg = "巡视id不存在";
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            if (limit == "")
            {
                limit = "12";
            }
            if (page == "")
            {
                page = "1";
            }
            int end = (int.Parse(limit));
            int npage = (int.Parse(page) - 1) * int.Parse(limit);
            string sql = "patrolid='" + patrolid + "'";
            if (typename != "" && typename != "全部")
                sql += "  and typename='" + typename + "'";
            Maticsoft.BLL.device_exception_infor deviceexceptionService = new Maticsoft.BLL.device_exception_infor();
            List<Maticsoft.Model.device_exception_infor>  list = deviceexceptionService.GetModelList("patrolid='" + patrolid + "'");
            DataTable dt = new DataTable();
            dt = deviceexceptionService.GetList(sql+ " order by createtime desc limit " + npage + "," + end + "").Tables[0];
            if (dt.Rows.Count > 0)
            {
                //对数据进行预设点排序
                DataView dv = dt.DefaultView;
                dv.Sort = "ysdname ASC";
                dt = dv.ToTable();               
                dt.Columns.Add("todaytop", Type.GetType("System.String"));
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dt.Rows[i]["todaytop"] = dt.Rows[i]["temperature"];

                }             
            }
            json.falg = true;
            json.msg = "查询成功";
            json.exceptionlist = dt;
            json.count = list.Count;           
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }

        public string deleteDeviceException(string id)
        {
            returnjson json = new returnjson();

            if (id.Trim() == "")
            {
                json.msg = "参数不能为空";
                json.falg = false;
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            Maticsoft.BLL.device_exception_infor deviceexceptionService = new Maticsoft.BLL.device_exception_infor();
            Maticsoft.Model.device_exception_infor deviceExceptionModel =  deviceexceptionService.GetModel(id);
            if (deviceExceptionModel != null)
            {
                string deviceid = deviceExceptionModel.deviceid;
                if (deviceid!=null && deviceid !="")
                {
                    Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
                    //修改该设备为无状态
                    deviceService.UpdatePatrolStatus(deviceid,"0");
                }
            }
            deviceexceptionService.Delete(id);
            json.msg = "删除成功";
            json.falg = true;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }
        public string deleteDevicePatorl(string patrolid)
        {
            returnjson json = new returnjson();
            if (patrolid.Trim() == "")
            {
                json.msg = "参数不能为空";
                json.falg = false;
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            Maticsoft.BLL.device_exception_infor deviceexceptionService = new Maticsoft.BLL.device_exception_infor();
            List<Maticsoft.Model.device_exception_infor> list = deviceexceptionService.GetModelList("patrolid='" + patrolid + "'");
            if (list.Count>00)
            {
                for (int i=0;i<list.Count;i++)
                {
                    if (list[i]!=null)
                    {
                        string id = list[i].id;
                        deviceexceptionService.Delete(id);
                    }
                }
            }
            Maticsoft.BLL.device_patrol_infor devicepatrolService = new Maticsoft.BLL.device_patrol_infor();
            devicepatrolService.Delete(patrolid);
            json.msg = "删除成功";
            json.falg = true;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }

        public string findDescriptionByTypeName(string typename)
        {
            returnxunshijson json = new returnxunshijson();
            string sql = "";
            if (typename!=null && typename!="")
            {
                sql += "typename='"+ typename+"'";
            }
            Maticsoft.BLL.exception_type_infor exceptionService = new Maticsoft.BLL.exception_type_infor();
            List<Maticsoft.Model.exception_type_infor> exceptionlist = exceptionService.GetModelList("");
            json.falg = true;
            json.msg = "查询成功";
            json.exceptionTypelist = exceptionlist;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }
        public string findDeviceExceptionTypeByCount()
        {
            returnxunshijson json = new returnxunshijson();
            Maticsoft.BLL.device_exception_infor deviceexceptionService = new Maticsoft.BLL.device_exception_infor();
            List<Maticsoft.Model.device_exception_infor> list = deviceexceptionService.GetModelList("");
            Maticsoft.BLL.exception_type_infor exceptionService = new Maticsoft.BLL.exception_type_infor();
            List<Maticsoft.Model.exception_type_infor> exceptionlist = exceptionService.GetModelList("1=1 group by typename");
            List<exceptionjson> typelist = new List<exceptionjson>();
            if (exceptionlist.Count > 0 && list.Count > 0)//统计异常类型的数量
            {
                for (int i = 0; i < exceptionlist.Count; i++)
                {
                    exceptionjson typejson = new exceptionjson();
                    typejson.typename = exceptionlist[i].typename;
                    int typecount = 0;
                    for (int j = 0; j < list.Count; j++)
                    {
                        if (list[j].typename == exceptionlist[i].typename)
                        {
                            typecount += 1;
                        }
                    }
                    typejson.count = typecount;
                    typelist.Add(typejson);
                }
            }
            else
            {
                exceptionjson typejson = new exceptionjson();
                typejson.typename = "硬件异常";
                typejson.count = 0;
                typelist.Add(typejson);
                exceptionjson typejson1 = new exceptionjson();
                typejson1.typename = "软件异常";
                typejson1.count = 0;
                typelist.Add(typejson1);
            }
            json.falg = true;
            json.msg = "查询成功";
            json.typelist = typelist;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }
        public string findDeviceExceptionStatusByCount()
        {
            returnxunshijson json = new returnxunshijson();
            Maticsoft.BLL.device_exception_infor deviceexceptionService = new Maticsoft.BLL.device_exception_infor();
            //未消除
            List<Maticsoft.Model.device_exception_infor> list1 = deviceexceptionService.GetModelList("status=1");
            //已消除
            List<Maticsoft.Model.device_exception_infor> list2 = deviceexceptionService.GetModelList("status=0");
            List<exceptionjson> typelist = new List<exceptionjson>();         
            exceptionjson typejson = new exceptionjson();
            typejson.typename = "未消除";
            typejson.count = list1.Count;
            typelist.Add(typejson);
            exceptionjson typejson1 = new exceptionjson();
            typejson1.typename = "已消除";
            typejson1.count = list2.Count;
            typelist.Add(typejson1);
            json.falg = true;
            json.msg = "查询成功";
            json.typelist = typelist;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }

        public string updateDevicePatrolStatus(string userid, string machineid)
        {
            returnjson json = new returnjson();

            if (machineid==null && machineid=="" && userid==null && userid=="")
            {
                json.msg = "参数不能为空";
                json.falg = false;
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }          
            Maticsoft.BLL.machine_infor macService = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor macModel = macService.GetModel(machineid);
            if (macModel==null)
            {
                json.msg = "该红外设备不存在";
                json.falg = false;
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = deviceService.GetModelList("machineid ='"+ machineid + "'");
            if (devicelist.Count>0)
            {
                for (int i=0;i< devicelist.Count;i++)
                {
                    if (devicelist[i]!=null)
                    {
                        if (devicelist[i].patrolStatus == "0" || devicelist[i].patrolStatus == "")
                        {
                            string deviceid = devicelist[i].deviceid;
                            //修改无状态的设备为正常，并把临时字段值设为userid 
                            deviceService.UpdateTemporary(deviceid, "1", userid);
                            ////修改无状态的设备为用户id，在新增巡视记录时进行状态修改
                            //deviceService.UpdatePatrolStatus(deviceid, "1");
                        }
                    }
                }
            }
            json.msg = "操作成功";
            json.falg = true;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }
        public string updateNormal(string userid, string deviceid)
        {
            returnjson json = new returnjson();

            if (deviceid == null && deviceid == "")
            {
                json.msg = "参数不能为空";
                json.falg = false;
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }          
            Maticsoft.BLL.device_infor deviceService = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor deviceModel = deviceService.GetModel(deviceid);
            if (deviceModel == null)
            {
                json.msg = "设备不存在";
                json.falg = false;
                return Newtonsoft.Json.JsonConvert.SerializeObject(json);
            }
            //修改无状态的设备为正常，并把临时字段值设为userid 
            deviceService.UpdateTemporary(deviceid, "1", userid);
            //修改异常表里的状态为已消除
            Maticsoft.BLL.device_exception_infor deviceExceptionservice = new Maticsoft.BLL.device_exception_infor();
           List<Maticsoft.Model.device_exception_infor> exceptionlist =  deviceExceptionservice.GetModelList("deviceid = '" + deviceid + "'");
            if (exceptionlist.Count>0)
            {
                for (int i=0;i< exceptionlist.Count;i++)
                {
                    if (exceptionlist[i]!=null)
                    {
                        exceptionlist[i].status = "0";//已消除状态
                        deviceExceptionservice.Update(exceptionlist[i]);
                    }
                }
            }
            json.msg = "操作成功";
            json.falg = true;
            return Newtonsoft.Json.JsonConvert.SerializeObject(json);
        }
        public DataTable findDeviceExceptionType()
        {
            Maticsoft.BLL.exception_type_infor typeService = new Maticsoft.BLL.exception_type_infor();
            List<Maticsoft.Model.exception_type_infor> typelist = typeService.GetModelList("1=1 group by typename ");
            DataTable dt = new DataTable();
            dt.Columns.Add("typename", Type.GetType("System.String"));
            if (typelist.Count>0)
            {
                for (int i=0;i< typelist.Count;i++)
                {
                    dt.Rows.Add(new object[] { typelist[i].typename});
                }
            }
            return dt;
        }
        #endregion

        /// <summary>
        /// 通过城市获取经纬度
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        public string GetCityLongitude(string userid)
        {
            string Weather = "https://devapi.qweather.com/v7/weather/now?";
            string ReturnJson = "";
            //location = 101010100 & key = 6a816a4db75c40058131d864b9842e5c
            string PostDataKey = "&key=6a816a4db75c40058131d864b9842e5c";
            if (string.IsNullOrEmpty(userid))
            {
                return string.Empty;
            }

            Maticsoft.BLL.user_infor BLLUserInfor = new Maticsoft.BLL.user_infor();
            var ModelUserInfor = BLLUserInfor.GetModel(userid);
            if (ModelUserInfor==null)
            {
                return string.Empty;
            }


            // 查看经纬度是否存在值
            if (string.IsNullOrEmpty(ModelUserInfor.JingDu)||string.IsNullOrEmpty(ModelUserInfor.WeiDu))
            {
                // 重新请求Http获取经度纬度
                string City = ModelUserInfor.city;
                if (string.IsNullOrEmpty(City))
                {
                    return "";
                }
                else
                {
                    //定义请求的Url
                    string Url = @"http://api.map.baidu.com/geocoder?address=''&output=json&key=37492c0ee6f924cb5e934fa08c6b1676&city="+City;
                    string UrlEnCodeCity=HttpUtility.UrlEncode(City);
                    string Json= HttpPostMessage(Url,"");

                    // 无法进行转换 反射
                    var JArr=JsonConvert.DeserializeObject<ModelResult>(Json);
                    if (JArr.status.Equals("OK",StringComparison.CurrentCultureIgnoreCase))
                    {
                        if (!string.IsNullOrEmpty(JArr.result.location.lng)&&!string.IsNullOrEmpty(JArr.result.location.lat))
                        {
                            // 更新数据库
                            ModelUserInfor.JingDu = JArr.result.location.lng;
                            ModelUserInfor.WeiDu = JArr.result.location.lat;
                            BLLUserInfor.Update(ModelUserInfor);


                             ReturnJson = Weather+ "location="+ JArr.result.location.lng+"," + JArr.result.location.lat+ PostDataKey;
                             string CityWeather = HttpGet(ReturnJson, "");
                             return CityWeather;
                        }
                    }

                }
            }
            else
            {
                ReturnJson = Weather + "location=" +ModelUserInfor.JingDu+ "," + ModelUserInfor.WeiDu+ PostDataKey;
                string CityWeather = HttpGet(ReturnJson, "");
                return CityWeather;
            }
            return "";
        }

        public string HttpPostMessage(string Url, string postDataStr,string ContentType= "text/javascript;charset=utf-8")
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            request.Accept = "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
            request.Headers["Accept-Language"] = "zh-CN,zh;q=0.";
            request.Headers["Accept-Charset"] = "GBK,utf-8;q=0.7,*;q=0.3";
            request.UserAgent = "User-Agent:Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.202 Safari/535.1";
            request.KeepAlive = true;

            //上面的http头看情况而定，但是下面俩必须加  
            request.ContentType = ContentType;
            request.Method = "POST";

            Encoding encoding = Encoding.UTF8;//根据网站的编码自定义 
            byte[] postData = encoding.GetBytes(postDataStr);//postDataStr即为发送的数据，格式还是和上次说的一样  
            request.ContentLength = postData.Length;
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(postData, 0, postData.Length);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader streamReader = new StreamReader(responseStream, encoding);
            string retString = streamReader.ReadToEnd();

            streamReader.Close();
            responseStream.Close();
            return retString;
        }

        public string HttpGet(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url + (postDataStr == "" ? "" : "?") + postDataStr);
            request.Method = "GET";
            request.ContentType = "application/json;charset=UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            var ce = response.ContentEncoding;
            if (ce.ToLower()=="gzip")
            {
                myResponseStream = new GZipStream(myResponseStream, CompressionMode.Decompress);
            }

            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.UTF8);
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();

            return retString;
        }
    }

    public class ModelResult
    {
        public string status { get; set; }
        public Getresult result { get; set; }

    }
    public class Getresult
    {
        public location location { get; set; }
        public string precise { get; set; }

        public string confidence { get; set; }
        public string level { get; set; }

    }
    public class location 
    {
       public string lng { get; set; }
        public string lat { get; set; }
    }


}