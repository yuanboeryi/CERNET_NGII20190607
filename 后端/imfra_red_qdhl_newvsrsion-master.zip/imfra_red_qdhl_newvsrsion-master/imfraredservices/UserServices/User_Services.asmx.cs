﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

using imfraredservices.ConfigTool;

namespace imfraredservices.UserServices
{

    /// <summary>
    /// User_Services 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class User_Services : System.Web.Services.WebService
    {

        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = Int32.MaxValue;
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        //字符串转json
        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msgsend");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[]{jsonText});
            return ToJson(dt);
        }
        public string strJson1(string msg, string jsonText)
        {
            DataTable dt = new DataTable("msgsend");
            dt.Columns.Add("status", Type.GetType("System.String"));
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { msg, jsonText });
            return ToJson(dt);
        }
        UserAction action = new UserAction();
      
        #region 工区
        [WebMethod(Description = "接口描述：添加工区 参数：areaname, manager, phone, city, address【工区名称，员工，电话，城市，地址】")]
        public void a_addarea(string areaname, string manager, string phone, string city, string address)
        {
            string s = (action.addarea(areaname, manager, phone, city, address));
            if (s == "1")
                httpsend(strJson1("1", "添加成功"));
            else
                httpsend(strJson1("0", s));
        }
        [WebMethod(Description = "接口描述：修改工区 areaname, manager, phone, city, address")]
        public void a_modifyarea(string areaname, string manager, string phone, string city, string address)
        {
            httpsend(strJson(action.modifyarea(areaname, manager, phone, city, address)));
        }
        [WebMethod(Description = "接口描述：删除工区 id")]
        public void a_deletearea(string id)
        {
            httpsend(strJson(action.deletearea(id)));
        }
        [WebMethod(Description = "接口描述：获取所有工区")]
        public void a_getAllarea(string userid)
        {
            httpsend(ToJson(action.getAllarea(userid)));
        }
        [WebMethod(Description = "接口描述：获取某一工区 id")]
        public void a_getareaByid(string id)
        {
            httpsend(ToJson(action.getareaByname(id)));
        }
        #endregion
        #region 分部
        [WebMethod(Description = "接口描述：添加分部 参数：areaname, fenbuname, manager, phone, address【工区名称，分部名称，员工，电话，地址】")]
        public void b_addfenbu(string areaname, string fenbuname, string manager, string phone, string address)
        {
            string s = action.addfenbu(areaname, fenbuname, manager, phone, address);
            if (s == "1")
                httpsend(strJson1("1", "添加成功"));
            else
                httpsend(strJson1("0", s));
        }
        [WebMethod(Description = "接口描述：修改分部 areaname, fenbuname, manager, phone, address")]
        public void b_modifyfenbu(string areaname, string fenbuname, string manager, string phone, string address)
        {
            httpsend(strJson(action.modifyfenbu(areaname, fenbuname, manager, phone, address)));
        }
        [WebMethod(Description = "接口描述：删除分部 id")]
        public void b_deletefenbu(string id)
        {
            httpsend(strJson(action.deletefenbu(id)));
        }
        [WebMethod(Description = "接口描述：获取所有分部")]
        public void b_getAllfenbu(string userid)
        {
            httpsend(ToJson(action.getAllfenbu(userid)));
        }
        [WebMethod(Description = "接口描述：获取当前工区下所有分部 areaname")]
        public void b_getfenbuByarea(string areaid)
        {
            httpsend(ToJson(action.getfenbuByarea(areaid)));
        }
        [WebMethod(Description = "接口描述：获取某一分部 id")]
        public void b_getfenbuByid(string id)
        {
            httpsend(ToJson(action.getfenbuByname(id)));
        }
        #endregion
        #region 运维班
        [WebMethod(Description = "接口描述：添加运维班 参数：areaname, fenbuname, ywbname, manager, phone, address【工区名称，分部名称，运维班名称，员工，电话，地址】")]
        public void c_addywb(string areaname, string fenbuname, string ywbname, string manager, string phone, string address)
        {
            string s = action.addywb(areaname, fenbuname, ywbname, manager, phone, address);
            if (s == "1")
                httpsend(strJson1("1", "添加成功"));
            else
                httpsend(strJson1("0", s));
        }
        [WebMethod(Description = "接口描述：修改运维班 areaname, fenbuname, ywbname, manager, phone, address")]
        public void c_modifyywb(string areaname, string fenbuname, string ywbname, string manager, string phone, string address)
        {
            httpsend(strJson(action.modifyywb(areaname, fenbuname, ywbname, manager, phone, address)));

        }
        [WebMethod(Description = "接口描述：删除运维班 id")]
        public void c_deleteywb(string id)
        {
            httpsend(strJson(action.deleteywb(id)));

        }
        [WebMethod(Description = "接口描述：获取所有运维班")]
        public void c_getAllywb(string userid)
        {
            httpsend(ToJson(action.getAllywb(userid)));
        }
        [WebMethod(Description = "接口描述：获取当前工区下所有运维班 areaname")]
        public void c_getywbByarea(string areaid)
        {
            httpsend(ToJson(action.getywbByarea(areaid)));

        }
        [WebMethod(Description = "接口描述：获取当前分部下所有运维班 fenbuname")]
        public void c_getywbByfenbu(string fenbuid)
        {
            httpsend(ToJson(action.getywbByfenbu(fenbuid)));

        }
        [WebMethod(Description = "接口描述：获取某一运维班 id")]
        public void c_getywbByid(string id)
        {
            httpsend(ToJson(action.getywbByname(id)));

        }
        [WebMethod(Description = "接口描述：根据登录用户获取运维班")]
        public void c_getywbByiuser(string userid)
        {
            httpsend(ToJson(action.getywbBuser(userid)));

        }
        #endregion
        #region 用户
        [WebMethod(Description = "接口描述：添加用户，usertype=0表示工区用户，usertype=1表示分部用户，usertype=2表示运维班用户，如果usertype=0表示工区用户，fenbuname,ywbname传空值，反之亦然\r\n" + "参数介绍：areaname, fenbuname, ywbname, username, password, usertype, city, manager, phone【工区名称，分部名称，运维班名称，用户名，密码，用户类型，城市，员工，电话】")]
        public void d_adduser(string areaname, string fenbuname, string ywbname, string username, string password, string usertype, string city, string manager, string phone)
        {
            string s = (action.adduser(areaname, fenbuname, ywbname, username, password, usertype, city, manager, phone));
            if (s == "1")
                httpsend(strJson1("1", "添加成功"));
            else
                httpsend(strJson1("0", s));
        }
        [WebMethod(Description = "接口描述：修改用户密码 areaname,fenbuname,ywbname,username,oldpass,newpass,newpassrepeat【旧密码，新密码，重复新密码】")]

        public void d_changepassword(string areaname, string fenbuname, string ywbname, string username, string oldpass, string newpass, string newpassrepeat)
        {
            httpsend(strJson(action.changepassword(areaname, fenbuname, ywbname, username, oldpass, newpass, newpassrepeat)));
        }
        [WebMethod(Description = "接口描述：修改用户信息 areaname, fenbuname, ywbname, username, password, usertype, city, manager, phone")]
        public void d_modifyuser(string areaname, string fenbuname, string ywbname, string username, string password, string usertype, string city, string manager, string phone,string oldusername)
        {
            httpsend(strJson(action.modifyuser(areaname, fenbuname, ywbname, username, password, usertype, city, manager, phone, oldusername)));
        }
        [WebMethod(Description = "接口描述：删除用户 id")]
        public void d_deleteuser(string id)
        {
            httpsend(strJson(action.deleteuser(id)));
        }
        [WebMethod(Description = "接口描述：获取所有用户")]
        public void d_getAlluser(string userid)
        {
            httpsend(ToJson(action.getAlluser(userid)));
        }
        [WebMethod(Description = "接口描述：获取当前工区下所有用户 areaname")]
        public void d_getuserByarea(string areaid)
        {
            httpsend(ToJson(action.getuserByarea(areaid)));
        }
        [WebMethod(Description = "接口描述：获取当前分部下所有用户 fenbuname")]
        public void d_getuserByfenbu(string fenbuid)
        {
            httpsend(ToJson(action.getuserByfenbu(fenbuid)));

        }
        [WebMethod(Description = "接口描述：获取当前运维班下所有用户 ywbname")]
        public void d_getuserByywb(string ywbname)
        {
            httpsend(ToJson(action.getuserByywb(ywbname)));

        }
        [WebMethod(Description = "接口描述：获取当前用户 id")]
        public void d_getuserByid(string id)
        {
            httpsend(ToJson(action.getuserByname(id)));

        }
        #endregion
        #region 变电站
        [WebMethod(Description = "接口描述：添加变电站 参数：areaname, fenbuname, ywbname, stationname, manager, phone, stationlevel, city, address, jingdu, weidu【工区名称，分部名称，运维版名称，变电站名称，员工，电话，变压等级，城市，地址，经度，纬度】")]
        public void e_addstation(string areaname, string fenbuname, string ywbname, string stationname, string manager, string phone, string stationlevel, string city, string address, string jingdu, string weidu)
        {
            string s = action.addstation(areaname, fenbuname, ywbname, stationname, manager, phone, stationlevel, city, address, jingdu, weidu);
            if (s == "1")
                httpsend(strJson1("1", "添加成功"));
            else
                httpsend(strJson1("0", s));
        }
        [WebMethod(Description = "接口描述：修改变电站 areaname, fenbuname, ywbname, stationname, manager, phone, stationlevel, city, address, jingdu, weidu")]
        public void e_modifystation(string areaname, string fenbuname, string ywbname, string stationname, string manager, string phone, string stationlevel, string city, string address, string jingdu, string weidu)
        {
            httpsend(strJson(action.modifystation(areaname, fenbuname, ywbname, stationname, manager, phone, stationlevel, city, address, jingdu, weidu)));
        }
        [WebMethod(Description = "接口描述：删除变电站 id")]
        public void e_deletestation(string id)
        {
            httpsend(strJson(action.deletestation(id)));
        }
       
        [WebMethod(Description = "接口描述：获取所有变电站")]
        public void e_getAllstation(string userid)
        {
            httpsend(ToJson(action.getAllstation(userid)));
        }
        [WebMethod(Description = "接口描述：获取当前工区下所有变电站 ")]
        public void e_getstationByarea(string areaid)
        {
            httpsend(ToJson(action.getstationByarea(areaid)));

        }
        [WebMethod(Description = "接口描述：获取当前分部下所有变电站")]
        public void e_getstationByfenbu(string fenbuid)
        {
            httpsend(ToJson(action.getstationByfenbu(fenbuid)));

        }
        [WebMethod(Description = "接口描述：获取当前运维班下所有变电站 ")]
        public void e_getstationByywb(string ywbid)
        {
            httpsend(ToJson(action.getstationByywb(ywbid)));

        }
        [WebMethod(Description = "接口描述：获取某一个变电站 id")]
        public void e_getstationByid(string id)
        {
            httpsend(ToJson(action.getstationByname(id)));

        }
        [WebMethod(Description="接口描述：获取当前登录用户下所有的变电站")]
        public void e_getstationByUserid(string userid)
        {
            httpsend(ToJson(action.getstationByUserid(userid)));
        }
        #endregion
        #region 设备区
        [WebMethod(Description = "接口描述：添加设备区 参数：areaname, fenbuname, ywbname, stationnane, buildingname【工区名称，分部名称，运维班名称，变电站名称，设备区名称】")]
        public void f_addbuilding(string areaname, string fenbuname, string ywbname, string stationname, string buildingname)
        {
            string s = action.addbuilding(areaname, fenbuname, ywbname, stationname, buildingname);
            if (s == "1")
                httpsend(strJson1("1", "添加成功"));
            else
                httpsend(strJson1("0", s));
        }
        [WebMethod(Description = "接口描述：修改设备区 areaname, fenbuname, ywbname, stationnane, buildingname")]
        public void f_modifybuilding(string areaname, string fenbuname, string ywbname, string stationname,string buildingname,  string buildingid)
        {
            httpsend(strJson(action.modifybuilding(areaname, fenbuname, ywbname, stationname, buildingname,buildingid)));

        }
        [WebMethod(Description = "接口描述：删除设备区 id")]

        public void f_deletebuilding(string id)
        {
            httpsend(strJson(action.deletebuilding(id)));

        }
        [WebMethod(Description = "接口描述：获取所有设备区")]

        public void f_getAllbuilding(string userid)
        {
            httpsend(ToJson(action.getAllbuilding(userid)));
        }
        [WebMethod(Description = "接口描述：获取当前工区下所有设备区 ")]

        public void f_getbuildingByarea(string areaid)
        {
            httpsend(ToJson(action.getbuildingByarea(areaid)));

        }
        [WebMethod(Description = "接口描述：获取当前分部下所有设备区 ")]

        public void f_getbuildingByfenbu(string fenbuid)
        {
            httpsend(ToJson(action.getbuildingByfenbu(fenbuid)));

        }
        [WebMethod(Description = "接口描述：获取当前运维班下所有设备区 ")]

        public void f_getbuildingByywb(string ywbid)
        {
            httpsend(ToJson(action.getbuildingByywb(ywbid)));

        }
        [WebMethod(Description = "接口描述：获取当前变电站下所有设备区 ")]

        public void f_getbuildingBystation(string stationid)
        {
            httpsend(ToJson(action.getbuildingBystation(stationid)));

        }
        [WebMethod(Description = "接口描述：获取某个变电站下某个设备区 id")]

        public void f_getbuildingByid(string id)
        {
            httpsend(ToJson(action.getbuildingByname(id)));

        }
        #endregion
        #region 抓拍设备
        [WebMethod(Description = "接口描述：添加抓拍设备 参数：areaname, fenbuname, ywbname, stationname, buildingname, machinename, machinecompany, machinemac, machinecode, installcode, currentversion, newversion, machinestate, onlinetime, imagecatchspan, wifiname, wifipass, fushelv, offsetvalue, buchang 【工区名称，分部名称，运维班名称，变电站名称，设备区名称，抓拍设备名称，抓拍设备厂家，mac地址，设备编号，安装编号，当前版本，更新版本，设备状态，上线时间，抓拍间隔，wifi名称，wifi密码，辐射率，报警阈值，补偿值】")]
        public void g_addmachine(string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename,
            string machinecompany, 
            string machinemac, 
            string machinecode, 
            string currentversion, 
            string onlinetime, 
//            string fushelv, 
            string offsetvalue,
            string machineip,
            string mediaIndex
            )
        {
             string s = action.addmachine( areaname,  fenbuname,  ywbname,  stationname,  buildingname,  machinename,
             machinecompany,  machinemac,  machinecode,  currentversion,  offsetvalue,machineip, mediaIndex);
            List<string> AddStrId = new List<string>();
            string Id = string.Empty;
            if (s.Contains("#"))
            {
                AddStrId = s.Split('#').ToList();
            }

            Maticsoft.BLL.machine_infor machineservice = machineservice = new Maticsoft.BLL.machine_infor();
            if (AddStrId.Count>=1)
            {
                Id = AddStrId[1].ToString();
                // 更新当前的设备信息
                machineservice.UpdateMachineState(Id, "在线", "1", "");
            }
            if (!string.IsNullOrEmpty(machinecode))
            {
                string machineid = machineservice.getMachineIdByCode(machinecode);
                if (machineid != null)
                {
                    updateMediaIndex(machineid, mediaIndex);
                }
            }
            if (AddStrId.Count>=1)
            {
                if (AddStrId[0] == "1")
                {
                    httpsend(strJson1("1", "添加成功"));
                }
            }
            else
            {
               httpsend(strJson1("0", s));
            }
        }

        [WebMethod(Description = "接口描述：修改抓拍设备 areaname, fenbuname, ywbname, stationname, buildingname, machinename, machinecompany, machinemac, machinecode, installcode, currentversion, newversion, machinestate, onlinetime, imagecatchspan, wifiname, wifipass, fushelv, offsetvalue, buchang")]

        public void g_modifymachine(
            string machineid,
            string areaname, 
            string fenbuname, 
            string ywbname, 
            string stationname, 
            string buildingname, 
            string machinename,
            string machinecompany, 
            string machinemac, 
            string machinecode, 
            string currentversion,
            string onlinetime,
//            string fushelv, 
            string offsetvalue,
            string machineip,
            string mediaIndex
            )
        {
            updateMediaIndex(machineid, mediaIndex);
           
            httpsend(strJson(action.modifymachine(machineid, areaname,  fenbuname,  ywbname,  stationname,  buildingname,  machinename,
            machinecompany,  machinemac,  machinecode,  currentversion,  onlinetime,  offsetvalue,machineip)));

        }

        private void updateMediaIndex(string machineid, string mediaIndex)
        {
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            deviceservice.UpdateMediaIndex(machineid, mediaIndex);

            Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
            macservice.UpdateMediaIndex(machineid, mediaIndex);
        }

        [WebMethod(Description = "接口描述：删除抓拍设备 id")]

        public void g_deletemachine(string id)
        {
            httpsend(strJson(action.deletemachine(id)));

        }
        [WebMethod(Description = "接口描述：获取所有抓拍设备")]

        public void g_getAllmachine(string userid)
        {
            httpsend(ToJson(action.getAllmachine(userid)));
        }
        [WebMethod(Description = "接口描述：获取当前工区下所有抓拍设备 ")]

        public void g_getmachineByarea(string areaid)
        {
            httpsend(ToJson(action.getmachineByarea(areaid)));

        }
        [WebMethod(Description = "接口描述：获取当前分部下所有抓拍设备 ")]

        public void g_getmachineByfenbu(string fenbuid)
        {
            httpsend(ToJson(action.getmachineByfenbu(fenbuid)));

        }
        [WebMethod(Description = "接口描述：获取当前运维班下所有抓拍设备 ")]

        public void g_getmachineByywb(string ywbid)
        {
            httpsend(ToJson(action.getmachineByywb(ywbid)));

        }
        [WebMethod(Description = "接口描述：获取当前变电站下所有抓拍设备 ")]

        public void g_getmachineBystation(string stationid)
        {
            httpsend(ToJson(action.getmachineBystation(stationid)));

        }
        [WebMethod(Description = "接口描述：获取当前设备区下所有抓拍设备 ")]

        public void g_getmachineBybuilding(string buildingid)
        {
            httpsend(ToJson(action.getmachineBybuilding(buildingid)));

        }

        [WebMethod(Description = "接口描述：获取某个变电站下某个设备区下某一个抓拍设备 id")]
        public void g_getmachineByid(string id)
        {

            MachineResult machineResult = new MachineResult();
            MediaResult mediaResult = new MediaResult();

            machineResult.Machine = action.getmachineByname(id);

            Maticsoft.BLL.media mediaService = new Maticsoft.BLL.media();
            DataTable dt = mediaService.GetAllList().Tables[0];
            ArrayList list = new ArrayList();
            list.Add(new MediaAddress());

            foreach (DataRow dataRow in dt.Rows)
            {
                MediaAddress ma = new MediaAddress();
                ma.Name = dataRow["details"].ToString();
                ma.Value = dataRow["id"].ToString();
                list.Add(ma);
            }

            mediaResult.Data = list;

            mediaResult.Index = getMediaIndex(id);

            machineResult.Media = mediaResult;

            string json = Newtonsoft.Json.JsonConvert.SerializeObject(machineResult);

            httpsend(json);
        }

        private string getMediaIndex(string id)
        {
            string index = "0";

            Maticsoft.BLL.device_infor devService = new Maticsoft.BLL.device_infor();
            string mediaIndex = devService.getMediaIndexByMachineId(id);

            if (mediaIndex != null)
            {
                index = mediaIndex;
            } 
            else
            {
                Maticsoft.BLL.machine_infor macService = new Maticsoft.BLL.machine_infor();
                mediaIndex = macService.getMediaIndexByMachineId(id);
                if (mediaIndex != null)
                {
                    index = mediaIndex;
                }
            }

            return index;
        }


        #endregion
        #region 预设点
        [WebMethod(Description = "接口描述：添加预设点 参数：areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdname【工区名称，分部名称，运维班名称，变电站名称，设备区名称，抓拍设备名称，预设点编号】")]
        public void h_addysd(string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename, string ysdindex)
        {
            string s = action.addysd(areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdindex);
            if (s == "1")
                httpsend(strJson1("1", "添加成功"));
            else
                httpsend(strJson1("0", s));
        }
        [WebMethod(Description = "接口描述：(后台使用)一键添加预设点 参数：areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdNumbers【工区名称，分部名称，运维班名称，变电站名称，设备区名称，抓拍设备名称，预设点个数】")]
        public void h_addysd_OneKey(string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename, string ysdNumbers)
        {
            string s = action.addysd_OneKey(areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdNumbers);
            if (s == "1")
                httpsend(strJson1("1", "添加成功"));
            else
                httpsend(strJson1("0", s));
        }
        [WebMethod(Description = "接口描述：修改预设点 areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdname")]
        public void h_modifyysd(string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename, string ysdindex)
        {
            httpsend(strJson(action.modifyysd(areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdindex)));
        }
        [WebMethod(Description = "接口描述：删除预设点 id")]
        public void h_deleteysd(string id)
        {
            httpsend(strJson(action.deleteysd(id)));
        }
        [WebMethod(Description = "接口描述：获取所有预设点")]
        public void h_getAllysd(string userid)
        {
            httpsend(ToJson(action.getAllysd(userid)));
        }
        [WebMethod(Description = "接口描述：获取当前工区下所有预设点 ")]
        public void h_getysdByarea(string areaid)
        {
            httpsend(ToJson(action.getysdByarea(areaid)));
        }
        [WebMethod(Description = "接口描述：获取当前分部下所有预设点 fenbuid")]
        public void h_getysdByfenbu(string fenbuid)
        {
            httpsend(ToJson(action.getysdByfenbu(fenbuid)));
        }
        [WebMethod(Description = "接口描述：获取当前运维班下所有预设点 ywbid")]
        public void h_getysdByywb(string ywbid)
        {
            httpsend(ToJson(action.getysdByywb(ywbid)));
        }
        [WebMethod(Description = "接口描述：获取当前变电站下所有预设点 stationid")]
        public void h_getysdBystation(string stationid)
        {
            httpsend(ToJson(action.getysdBystation(stationid)));
        }
        [WebMethod(Description = "接口描述：获取当前设备区下所有预设点 ")]
        public void h_getysdBybuilding(string buildingid)
        {
            httpsend(ToJson(action.getysdBybuilding(buildingid)));
        }
        [WebMethod(Description = "接口描述：获取当前抓拍设备下所有预设点")]
        public void h_getysdBymachine(string machineid)
        {
            httpsend(ToJson(action.getysdBymachine(machineid)));
        }
        [WebMethod(Description = "接口描述：获取某个预设点 id")]
        public void h_getysdByid(string id)
        {
            httpsend(ToJson(action.getysdByname(id)));
        }
        #endregion
        #region 设备
        [WebMethod(Description = "接口描述：添加设备 参数：areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdname, devicename, distance, fuhe, offsetvalue, ysdtype, ysdlevel【工区名称，分部名称，运维班名称，变电站名称，设备区名称，抓拍设备名称，预设点编号，设备名称，距离，负荷，告警阈值，预设点类型，预设点等级】")]
        public void i_adddevice(string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename, string ysdindex, string devicename, string offsetvalue, string ysdtype, string ysdlevel,string operaterNumber)
        {

            string s = action.adddevice(areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdindex, devicename, offsetvalue, ysdtype, ysdlevel, operaterNumber);
            if (s == "1")
                httpsend(strJson1("1", "添加成功"));
            else
                httpsend(strJson1("0", s));
        }
        [WebMethod(Description = "接口描述：修改设备 areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdname, devicename, distance, fuhe, offsetvalue, ysdtype, ysdlevel")]
        public void i_modifydevice(string deviceid,string areaname, string fenbuname, string ywbname, string stationname, string buildingname, string machinename, string ysdindex, string devicename, string offsetvalue, string ysdtype, string ysdlevel, string operaterNumber,string ysdname)
        {
            httpsend(strJson(action.modifydevice(deviceid,areaname, fenbuname, ywbname, stationname, buildingname, machinename, ysdindex, devicename, offsetvalue, ysdtype, ysdlevel, operaterNumber, ysdname)));
        }
        [WebMethod(Description = "接口描述：删除设备 id")]
        public void i_deletedevice(string id)
        {
            httpsend(strJson(action.deletedevice(id)));
        }
        [WebMethod(Description = "接口描述：获取所有设备")]
        public void i_getAlldevice(string userid)
        {
            httpsend(ToJson(action.getAlldevice(userid)));
        }
        [WebMethod(Description = "接口描述：获取当前工区下所有设备 ")]
        public void i_getdeviceByarea(string areaid)
        {
            httpsend(ToJson(action.getdeviceByarea(areaid)));
        }
        [WebMethod(Description = "接口描述：获取当前分部下所有设备 fenbuid")]
        public void i_getdeviceByfenbu(string fenbuid)
        {
            httpsend(ToJson(action.getdeviceByfenbu(fenbuid)));
        }
        [WebMethod(Description = "接口描述：获取当前运维班下所有设备 ywbid")]
        public void i_getdeviceByywb(string ywbid)
        {
            httpsend(ToJson(action.getdeviceByywb(ywbid)));
        }
        [WebMethod(Description = "接口描述：获取当前变电站下所有设备 stationid")]
        public void i_getdeviceBystation(string stationid)
        {
            httpsend(ToJson(action.getdeviceBystation(stationid)));
        }
        [WebMethod(Description = "接口描述：获取当前设备区下所有设备")]
        public void i_getdeviceBybuildingid(string buildingid)
        {
            httpsend(ToJson(action.getdeviceBybuildingid( buildingid)));
        }
        [WebMethod(Description = "接口描述："+"\r\n"+"获取当前抓拍设备下所有设备")]
        public void i_getdeviceBymachine(string machineid)
        {
            httpsend(ToJson(action.getdeviceBymachine(machineid)));
        }
        [WebMethod(Description = "接口描述：获取当前预设点下所有设备")]
        public void i_getdeviceByysd(string ysdid)
        {
            httpsend(ToJson(action.getdeviceByysd(ysdid)));
        }
        [WebMethod(Description = "接口描述：获取某个设备 id")]
        public void i_getdeviceByid(string id)
        {
            httpsend(ToJson(action.getdeviceByname(id)));
        }
        #endregion

        #region 查询条件
        [WebMethod(Description = "接口描述：获取查询条件")]
        public void queryConditions(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string deviceid, string machineid)
        {
            httpsend(action.queryConditions(userid,areaid,fenbuid,ywbid,stationid,buildingid,devicetype,deviceid,machineid));
        }
        #endregion

        #region 获取设备类型
        [WebMethod(Description = "接口描述：获取设备类型")]
        public void j_getdevicetype()
        {
            httpsend(ToJson(action.getdevicetype()));
        }
          [WebMethod(Description = "接口描述：根据类型获取变电站下的设备")]
        public void j_getdeviceBytype(string stationname,string buildingname,string devicetype)
        {
            httpsend(ToJson(action.getdeviceBytype(stationname,buildingname,devicetype)));
        }
          [WebMethod(Description = "接口描述：获取告警确认与否的设备 isok=0表示未确认，isok=1表示已确认")]
        public void k_getdeviceByAlarmOkornot(string stationname,string buildingname,string isok)
        {
            httpsend(ToJson(action.getdeviceByAlarmOkornot(stationname,buildingname,isok)));
        }
        #endregion




          [WebMethod(Description = "接口描述：针对变电设备联合查询，多条件查询当前监控设备， 此接口单独对张明月 ，处设备状态外每个条件有三种值：条件名称|null|全部   设备状态有四个值：分别是 0【未确认】 1【已确认】 全部【全部显示】 null【没有值】 page>=1,numbers>0")]
          public void l_getdeviceByUnit(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string machineid, string isok, string page, string limit)
          {
              httpsend((action.l_getdeviceByUnit(userid, areaid, fenbuid, ywbid, stationid, buildingid, devicetype, machineid, isok, page, limit)));
          }
         
          [WebMethod(Description = "接口描述：针对抓拍设备联合查询，多条件查询当前检测设备， 此接口单独对张明月 ，处设备状态外每个条件有三种值：条件名称|null|全部   设备状态有四个值：分别是 0【不在线】 1【在线】 全部【全部显示】 null【没有值】 page>=1,numbers>0")]
        public void  l_getmachineByUnit(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string machinetype, string machineid, string isonline, string page, string limit)
          {
              action.OfflineCount();
              httpsend((action.l_getmachineByUnit(userid, areaid, fenbuid, ywbid, stationid, buildingid, machinetype, machineid, isonline, page, limit)));
          }
          [WebMethod(Description = "获取所有抓拍设备的类型")]
        public void l_getAllmachineType()
          {
              httpsend(ToJson(action.getAllmachinetype()));
          }
         [WebMethod(Description="获得当前变电站设备区下的设备")]
          public void l_getmachineBytype(string stationname, string buildingname)
          {
              httpsend(ToJson(action.getmachineBytype(stationname,buildingname)));
          }

         [WebMethod(Description="接口描述：根据登录用户信息返回当前后台的账户架构，参数：username，usertype[usertype=0或者1或者2]")]
        public void x_getAllInforByUser(string userid)
        {
            httpsend(action.getallInforByUser(userid));
        }


         [WebMethod(Description = "接口描述：编辑抓拍设备的抓拍周期，和巡视周期,参数：machineid,catchSpan，shunshiSpan【，设备id，抓拍周期，巡视周期】")]
         public void y_setMachinetime(string machineid,string catchSpan,string xunshiSpan)
         {
             Maticsoft.BLL.machine_infor ms = new Maticsoft.BLL.machine_infor();
             Maticsoft.Model.machine_infor mmodel = new Maticsoft.Model.machine_infor();
             mmodel = ms.GetModel(machineid);
             if (mmodel == null)
                 httpsend(strJson("没有此设备"));
             else
             {
                 ms.UpdateSpan(machineid,catchSpan,xunshiSpan);
                 httpsend(strJson("更新成功"));
             }
         }
        [WebMethod(Description="接口描述：点击历史图片，获取三张图片的list，传值recordid")]
        public void l_getDiviceHistoryImageList(string recordid)
         {
             Maticsoft.BLL.image_record_history hisservice = new Maticsoft.BLL.image_record_history();
             Maticsoft.Model.image_record_history hismodel = new Maticsoft.Model.image_record_history();
             hismodel = hisservice.GetModel(recordid);
            if(hismodel!=null)
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("image_high", Type.GetType("System.String"));
                dt.Columns.Add("image_red", Type.GetType("System.String"));
                dt.Columns.Add("image_mix", Type.GetType("System.String"));
                dt.Rows.Add(new object[] { hismodel.image0, hismodel.image1,hismodel.image2 });

                httpsend(ToJson(dt));
            }
         }
        [WebMethod(Description="接口描述：获取设备历史图像，联合查询接口")]
        public void l_getDeviceImageByUnit(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string deviceid, string isok, string page, string limit, string startDate, string endDate, string isimagered)
         {
             httpsend(action.l_getDeviceImageByUnit(userid, areaid, fenbuid, ywbid, stationid, buildingid, devicetype, deviceid, isok, page, limit, startDate, endDate, isimagered));
         }
        [WebMethod(Description = "接口描述：获取告警历史，联合查询接口")]
        public void l_getAlarmByUnit(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string devicetype, string deviceid, string isok, string page, string limit, string order,string staralarm, string endalarm)
        {
            httpsend(action.l_getAlarmByUnit(userid, areaid, fenbuid, ywbid, stationid, buildingid, devicetype, deviceid, isok, page, limit, order,staralarm,endalarm));
        }

         //[WebMethod(Description = "接口描述：编辑抓拍设备的抓拍周期，和巡视周期,参数：machineid,catchSpan，shunshiSpan【，设备id，抓拍周期，巡视周期】")]

        public void UpdateYsdNUmbers()
         {
             Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
             List<Maticsoft.Model.machine_infor> machinemodel = new List<Maticsoft.Model.machine_infor>();
             Maticsoft.BLL.ysd_infor ysdservice = new Maticsoft.BLL.ysd_infor();

             machinemodel = machineservice.GetModelList("");
            for(int i=0;i<machinemodel.Count();i++)
            {
                string machineid = machinemodel[i].machineid;
                List<Maticsoft.Model.ysd_infor> ysdlist = new List<Maticsoft.Model.ysd_infor>();
                ysdlist = ysdservice.GetModelList("machineid='"+machineid+"'");
                int ncount = ysdlist.Count();
                machineservice.UpdateYsdCount(machineid, ncount.ToString());
               
            }
         }

        [WebMethod(Description = "接口描述：添加红外设备 type=0,1,2,3,4,5,6  0表示工区id，1表示分部id")]
        public void XXX_getXiedaiParam(string id,string type)
        {
            Maticsoft.BLL.area_infor s1 = new Maticsoft.BLL.area_infor();
            Maticsoft.BLL.fenbu_infor s2=new Maticsoft.BLL.fenbu_infor();
            Maticsoft.BLL.ywb_infor s3 = new Maticsoft.BLL.ywb_infor();
            Maticsoft.BLL.station_infor s4 = new Maticsoft.BLL.station_infor();
            Maticsoft.BLL.building_infor s5 = new Maticsoft.BLL.building_infor();
            Maticsoft.BLL.machine_infor s6 = new Maticsoft.BLL.machine_infor();
            Maticsoft.BLL.ysd_infor s7 = new Maticsoft.BLL.ysd_infor();
            DataTable dt = new DataTable("machinecount");
            dt.Columns.Add("areaname", Type.GetType("System.String"));
            dt.Columns.Add("fenbuname", Type.GetType("System.String"));
            dt.Columns.Add("ywbname", Type.GetType("System.String"));
            dt.Columns.Add("stationname", Type.GetType("System.String"));
            dt.Columns.Add("buildingname", Type.GetType("System.String"));
            dt.Columns.Add("machinename", Type.GetType("System.String"));
            dt.Columns.Add("ysdname", Type.GetType("System.String"));
            dt.Columns.Add("areaid", Type.GetType("System.String"));
            dt.Columns.Add("fenbuid", Type.GetType("System.String"));
            dt.Columns.Add("ywbid", Type.GetType("System.String"));
            dt.Columns.Add("stationid", Type.GetType("System.String"));
            dt.Columns.Add("buildingid", Type.GetType("System.String"));
            dt.Columns.Add("machineid", Type.GetType("System.String"));
            dt.Columns.Add("ysdid", Type.GetType("System.String"));
            string areaname = "";
            string fenbuname = "";
            string ywbname = "";
            string stationnane = "";
            string buildingname = "";
            string machinename = "";
            string ysdname = "";
            string areaid = "";
            string fenbuid = "";
            string ywbid = "";
            string stationid = "";
            string buildingid = "";
            string machineid = "";
            string ysdid = "";
            if(type=="0")
            {
                areaname = s1.GetList("areaid='" + id + "'").Tables[0].Rows[0]["areaname"].ToString();
                areaid = id;
            }
            if (type == "1")
            {
                fenbuname = s2.GetList("fenbuid='" + id + "'").Tables[0].Rows[0]["fenbuname"].ToString();
                Maticsoft.Model.fenbu_infor model = new Maticsoft.Model.fenbu_infor();
                model = s2.GetModel(id);
                areaname = model.areaname;
                fenbuid = id;
                areaid = model.areaid;
            }
            if (type == "2")
            {
                ywbname = s3.GetList("ywbid='" + id + "'").Tables[0].Rows[0]["ywbname"].ToString();
                Maticsoft.Model.ywb_infor model = s3.GetModel(id);
                areaname = model.areaname;
                fenbuname = model.fenbuname;
                ywbid = id;
                areaid = model.areaid;
                fenbuid = model.fenbuid;
            }
            if (type == "3")
            {
                stationnane = s4.GetList("stationid='" + id + "'").Tables[0].Rows[0]["stationname"].ToString();
                Maticsoft.Model.station_infor model = s4.GetModel(id);
                areaname = model.areaname;
                fenbuname = model.fenbuname;
                ywbname = model.ywbname;
                stationid = id;
                areaid = model.areaid;
                fenbuid = model.fenbuid;
                ywbid = model.ywbid;
            }
            if (type == "4")
            {
                buildingname = s5.GetList("buildingid='" + id + "'").Tables[0].Rows[0]["buildingname"].ToString();
                Maticsoft.Model.building_infor model = s5.GetModel(id);
                areaname = model.areaname;
                fenbuname = model.fenbuname;
                ywbname = model.ywbname;
                stationnane = model.stationname;
                buildingid = id;
                areaid = model.areaid;
                fenbuid = model.fenbuid;
                ywbid = model.ywbid;
                stationid = model.stationid;
            }
            if (type == "5")
            {
                machinename = s6.GetList("machineid='" + id + "'").Tables[0].Rows[0]["machinename"].ToString();
                Maticsoft.Model.machine_infor model = s6.GetModel(id);
                areaname = model.areaname;
                fenbuname = model.fenbuname;
                ywbname = model.ywbname;
                stationnane = model.stationname;
                buildingname = model.buildingname;
                machineid = id;
                areaid = model.areaid;
                fenbuid = model.fenbuid;
                ywbid = model.ywbid;
                stationid = model.stationid;
                buildingid = model.buildingid;
            }
            if (type == "6")
            {
                ysdname = s7.GetList("ysdid='" + id + "'").Tables[0].Rows[0]["ysdname"].ToString();
                Maticsoft.Model.ysd_infor model = s7.GetModel(id);
                areaname = model.areaname;
                fenbuname = model.fenbuname;
                ywbname = model.ywbname;
                stationnane = model.stationname;
                buildingname = model.buildingname;
                machinename = model.machinename;
                ysdid = id;
                areaid = model.areaid;
                fenbuid = model.fenbuid;
                ywbid = model.ywbid;
                stationid = model.stationid;
                buildingid = model.buildingid;
                machineid = model.machineid;
            }
            dt.Rows.Add(new object[] {areaname,fenbuname,ywbname,stationnane,buildingname,machinename,ysdname,areaid,fenbuid,ywbid,stationid,buildingid,machineid,ysdid });

            httpsend(ToJson(dt));
        }




        [WebMethod(Description="接口描述：根据变电站获取该站的查询框架")]
        public void XXX_geStationParam(string userid,string station_id)
        {
           
                Maticsoft.BLL.user_infor service1 = new Maticsoft.BLL.user_infor();
                DataTable dt = service1.GetList("userid='" + userid + "'").Tables[0];
                if (dt.Rows.Count < 1)
                {
                    return;
                }
                string usertype = dt.Rows[0]["usertype"].ToString();
                SystemInfor allinfor = new SystemInfor();
                if (usertype == "0")
                {
                    string areaid = dt.Rows[0]["areaid"].ToString();
                    string areaname = dt.Rows[0]["areaname"].ToString();
                    string[] s1 = new string[2];
                    s1[0] = areaid;
                    s1[1] = areaname;
                    allinfor.Arealist.Add(s1);

                    Maticsoft.BLL.fenbu_infor service2 = new Maticsoft.BLL.fenbu_infor();
                    DataTable d1 = service2.GetList("areaid='" + areaid + "'").Tables[0];
                    if (d1.Rows.Count > 0)
                    {
                        for (int i = 0; i < d1.Rows.Count; i++)
                        {
                            string fenbuid = d1.Rows[i]["fenbuid"].ToString();
                            string fenbuname = d1.Rows[i]["fenbuname"].ToString();
                            string[] sfenbu = new string[2];
                            sfenbu[0] = fenbuid; sfenbu[1] = fenbuname;
                            allinfor.Fenbulist.Add(sfenbu);
                        }
                    }


                    Maticsoft.BLL.ywb_infor service3 = new Maticsoft.BLL.ywb_infor();
                    DataTable d2 = service3.GetList("areaid='" + areaid + "'").Tables[0];
                    if (d2.Rows.Count > 0)
                    {
                        for (int i = 0; i < d2.Rows.Count; i++)
                        {
                            string ywbid = d2.Rows[i]["ywbid"].ToString();
                            string ywbname = d2.Rows[i]["ywbname"].ToString();
                            string[] sywb = new string[2];
                            sywb[0] = ywbid; sywb[1] = ywbname;
                            allinfor.Ywblist.Add(sywb);
                        }
                    }


                    Maticsoft.BLL.station_infor service4 = new Maticsoft.BLL.station_infor();
                    DataTable d3 = service4.GetList("areaid='" + areaid + "'").Tables[0];
                    if (d3.Rows.Count > 0)
                    {
                        for (int i = 0; i < d3.Rows.Count; i++)
                        {
                            string stationid = d3.Rows[i]["stationid"].ToString();
                            string stationname = d3.Rows[i]["stationname"].ToString();
                            string[] sstation = new string[2];
                            sstation[0] = stationid; sstation[1] = stationname;
                            allinfor.Stationlist.Add(sstation);
                        }
                    }

                    Maticsoft.BLL.building_infor service5 = new Maticsoft.BLL.building_infor();
                    DataTable d4 = service5.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d4.Rows.Count > 0)
                    {
                        for (int i = 0; i < d4.Rows.Count; i++)
                        {
                            string sid = d4.Rows[i]["buildingid"].ToString();
                            string sname = d4.Rows[i]["buildingname"].ToString();
                            string[] sbuilding = new string[2];
                            sbuilding[0] = sid; sbuilding[1] = sname;
                            allinfor.Buildinglist.Add(sbuilding);
                        }
                    }


                    Maticsoft.BLL.machine_infor service6 = new Maticsoft.BLL.machine_infor();
                    DataTable d5 = service6.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d5.Rows.Count > 0)
                    {
                        for (int i = 0; i < d5.Rows.Count; i++)
                        {
                            string sid = d5.Rows[i]["machineid"].ToString();
                            string sname = d5.Rows[i]["machinename"].ToString();
                            string[] smachine = new string[2];
                            smachine[0] = sid; smachine[1] = sname;
                            allinfor.Machinelist.Add(smachine);
                        }
                    }

                    Maticsoft.BLL.ysd_infor service7 = new Maticsoft.BLL.ysd_infor();
                    DataTable d7 = service7.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d7.Rows.Count > 0)
                    {
                        for (int i = 0; i < d7.Rows.Count; i++)
                        {
                            string sid = d7.Rows[i]["ysdid"].ToString();
                            string sname = d7.Rows[i]["ysdname"].ToString();
                            string[] sysd = new string[2];
                            sysd[0] = sid; sysd[1] = sname;
                            allinfor.Ysdlist.Add(sysd);
                        }
                    }


                    Maticsoft.BLL.device_infor service8 = new Maticsoft.BLL.device_infor();
                    DataTable d8 = service8.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d8.Rows.Count > 0)
                    {
                        for (int i = 0; i < d8.Rows.Count; i++)
                        {
                            string sid = d8.Rows[i]["deviceid"].ToString();
                            string sname = d8.Rows[i]["devicename"].ToString();
                            string[] sdevice = new string[2];
                            sdevice[0] = sid; sdevice[1] = sname;
                            allinfor.Devicelist.Add(sdevice);
                        }
                    }

                }
                if (usertype == "1")
                {
                    string areaid = dt.Rows[0]["areaid"].ToString();
                    string areaname = dt.Rows[0]["areaname"].ToString();
                    string[] s1 = new string[2];
                    s1[0] = areaid;
                    s1[1] = areaname;
                    allinfor.Arealist.Add(s1);

                    string fenbuid = dt.Rows[0]["fenbuid"].ToString();
                    string fenbuname = dt.Rows[0]["fenbuname"].ToString();
                    string[] sfenbu = new string[2];
                    sfenbu[0] = fenbuid; sfenbu[1] = fenbuname;
                    allinfor.Fenbulist.Add(sfenbu);


                    Maticsoft.BLL.ywb_infor service3 = new Maticsoft.BLL.ywb_infor();
                    DataTable d2 = service3.GetList("fenbuid='" + fenbuid + "'").Tables[0];
                    if (d2.Rows.Count > 0)
                    {
                        for (int i = 0; i < d2.Rows.Count; i++)
                        {
                            string sid = d2.Rows[i]["ywbid"].ToString();
                            string sname = d2.Rows[i]["ywbname"].ToString();
                            string[] sywb = new string[2];
                            sywb[0] = sid; sywb[1] = sname;
                            allinfor.Ywblist.Add(sywb);
                        }
                    }


                    Maticsoft.BLL.station_infor service4 = new Maticsoft.BLL.station_infor();
                    DataTable d3 = service4.GetList("fenbuid='" + fenbuid + "'").Tables[0];
                    if (d3.Rows.Count > 0)
                    {
                        for (int i = 0; i < d3.Rows.Count; i++)
                        {
                            string sid = d3.Rows[i]["stationid"].ToString();
                            string sname = d3.Rows[i]["stationname"].ToString();
                            string[] sstation = new string[2];
                            sstation[0] = sid; sstation[1] = sname;
                            allinfor.Stationlist.Add(sstation);
                        }
                    }

                    Maticsoft.BLL.building_infor service5 = new Maticsoft.BLL.building_infor();
                    DataTable d4 = service5.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d4.Rows.Count > 0)
                    {
                        for (int i = 0; i < d4.Rows.Count; i++)
                        {
                            string sid = d4.Rows[i]["buildingid"].ToString();
                            string sname = d4.Rows[i]["buildingname"].ToString();
                            string[] sbuilding = new string[2];
                            sbuilding[0] = sid; sbuilding[1] = sname;
                            allinfor.Buildinglist.Add(sbuilding);
                        }
                    }


                    Maticsoft.BLL.machine_infor service6 = new Maticsoft.BLL.machine_infor();
                    DataTable d5 = service6.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d5.Rows.Count > 0)
                    {
                        for (int i = 0; i < d5.Rows.Count; i++)
                        {
                            string sid = d5.Rows[i]["machineid"].ToString();
                            string sname = d5.Rows[i]["machinename"].ToString();
                            string[] smachine = new string[2];
                            smachine[0] = sid; smachine[1] = sname;
                            allinfor.Machinelist.Add(smachine);
                        }
                    }

                    Maticsoft.BLL.ysd_infor service7 = new Maticsoft.BLL.ysd_infor();
                    DataTable d7 = service7.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d7.Rows.Count > 0)
                    {
                        for (int i = 0; i < d7.Rows.Count; i++)
                        {
                            string sid = d7.Rows[i]["ysdid"].ToString();
                            string sname = d7.Rows[i]["ysdname"].ToString();
                            string[] sysd = new string[2];
                            sysd[0] = sid; sysd[1] = sname;
                            allinfor.Ysdlist.Add(sysd);
                        }
                    }


                    Maticsoft.BLL.device_infor service8 = new Maticsoft.BLL.device_infor();
                    DataTable d8 = service8.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d8.Rows.Count > 0)
                    {
                        for (int i = 0; i < d8.Rows.Count; i++)
                        {
                            string sid = d8.Rows[i]["deviceid"].ToString();
                            string sname = d8.Rows[i]["devicename"].ToString();
                            string[] sdevice = new string[2];
                            sdevice[0] = sid; sdevice[1] = sname;
                            allinfor.Devicelist.Add(sdevice);
                        }
                    }
                }





                if (usertype == "3")
                {
                    Maticsoft.BLL.area_infor areaservice = new Maticsoft.BLL.area_infor();
                    DataTable darea = areaservice.GetList("").Tables[0];
                    for (int i = 0; i < darea.Rows.Count; i++)
                    {
                        string areaid = darea.Rows[i]["areaid"].ToString();
                        string areaname = darea.Rows[i]["areaname"].ToString();
                        string[] s1 = new string[2];
                        s1[0] = areaid;
                        s1[1] = areaname;
                        allinfor.Arealist.Add(s1);
                    }
                    Maticsoft.BLL.fenbu_infor fenbuservice = new Maticsoft.BLL.fenbu_infor();
                    DataTable dfenbu = fenbuservice.GetList("").Tables[0];
                    for (int i = 0; i < dfenbu.Rows.Count; i++)
                    {
                        string fenbuid = dfenbu.Rows[i]["fenbuid"].ToString();
                        string fenbuname = dfenbu.Rows[i]["fenbuname"].ToString();
                        string[] sfenbu = new string[2];
                        sfenbu[0] = fenbuid; sfenbu[1] = fenbuname;
                        allinfor.Fenbulist.Add(sfenbu);
                    }






                    Maticsoft.BLL.ywb_infor service3 = new Maticsoft.BLL.ywb_infor();
                    DataTable d2 = service3.GetList("").Tables[0];
                    if (d2.Rows.Count > 0)
                    {
                        for (int i = 0; i < d2.Rows.Count; i++)
                        {
                            string sid = d2.Rows[i]["ywbid"].ToString();
                            string sname = d2.Rows[i]["ywbname"].ToString();
                            string[] sywb = new string[2];
                            sywb[0] = sid; sywb[1] = sname;
                            allinfor.Ywblist.Add(sywb);
                        }
                    }


                    Maticsoft.BLL.station_infor service4 = new Maticsoft.BLL.station_infor();
                    DataTable d3 = service4.GetList("").Tables[0];
                    if (d3.Rows.Count > 0)
                    {
                        for (int i = 0; i < d3.Rows.Count; i++)
                        {
                            string sid = d3.Rows[i]["stationid"].ToString();
                            string sname = d3.Rows[i]["stationname"].ToString();
                            string[] sstation = new string[2];
                            sstation[0] = sid; sstation[1] = sname;
                            allinfor.Stationlist.Add(sstation);
                        }
                    }

                    Maticsoft.BLL.building_infor service5 = new Maticsoft.BLL.building_infor();
                    DataTable d4 = service5.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d4.Rows.Count > 0)
                    {
                        for (int i = 0; i < d4.Rows.Count; i++)
                        {
                            string sid = d4.Rows[i]["buildingid"].ToString();
                            string sname = d4.Rows[i]["buildingname"].ToString();
                            string[] sbuilding = new string[2];
                            sbuilding[0] = sid; sbuilding[1] = sname;
                            allinfor.Buildinglist.Add(sbuilding);
                        }
                    }


                    Maticsoft.BLL.machine_infor service6 = new Maticsoft.BLL.machine_infor();
                    DataTable d5 = service6.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d5.Rows.Count > 0)
                    {
                        for (int i = 0; i < d5.Rows.Count; i++)
                        {
                            string sid = d5.Rows[i]["machineid"].ToString();
                            string sname = d5.Rows[i]["machinename"].ToString();
                            string[] smachine = new string[2];
                            smachine[0] = sid; smachine[1] = sname;
                            allinfor.Machinelist.Add(smachine);
                        }
                    }

                    Maticsoft.BLL.ysd_infor service7 = new Maticsoft.BLL.ysd_infor();
                    DataTable d7 = service7.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d7.Rows.Count > 0)
                    {
                        for (int i = 0; i < d7.Rows.Count; i++)
                        {
                            string sid = d7.Rows[i]["ysdid"].ToString();
                            string sname = d7.Rows[i]["ysdname"].ToString();
                            string[] sysd = new string[2];
                            sysd[0] = sid; sysd[1] = sname;
                            allinfor.Ysdlist.Add(sysd);
                        }
                    }


                    Maticsoft.BLL.device_infor service8 = new Maticsoft.BLL.device_infor();
                    DataTable d8 = service8.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d8.Rows.Count > 0)
                    {
                        for (int i = 0; i < d8.Rows.Count; i++)
                        {
                            string sid = d8.Rows[i]["deviceid"].ToString();
                            string sname = d8.Rows[i]["devicename"].ToString();
                            string[] sdevice = new string[2];
                            sdevice[0] = sid; sdevice[1] = sname;
                            allinfor.Devicelist.Add(sdevice);
                        }
                    }
                }

                if (usertype == "2")
                {
                    string areaid = dt.Rows[0]["areaid"].ToString();
                    string areaname = dt.Rows[0]["areaname"].ToString();
                    string[] s1 = new string[2];
                    s1[0] = areaid;
                    s1[1] = areaname;
                    allinfor.Arealist.Add(s1);

                    string fenbuid = dt.Rows[0]["fenbuid"].ToString();
                    string fenbuname = dt.Rows[0]["fenbuname"].ToString();
                    string[] sfenbu = new string[2];
                    sfenbu[0] = fenbuid; sfenbu[1] = fenbuname;
                    allinfor.Fenbulist.Add(sfenbu);

                    string ywbid = dt.Rows[0]["ywbid"].ToString();
                    string ywbname = dt.Rows[0]["ywbname"].ToString();
                    string[] sywb = new string[2];
                    sywb[0] = ywbid; sywb[1] = ywbname;
                    allinfor.Ywblist.Add(sywb);



                    Maticsoft.BLL.station_infor service4 = new Maticsoft.BLL.station_infor();
                    DataTable d3 = service4.GetList("ywbid='" + ywbid + "'").Tables[0];
                    if (d3.Rows.Count > 0)
                    {
                        for (int i = 0; i < d3.Rows.Count; i++)
                        {
                            string sid = d3.Rows[i]["stationid"].ToString();
                            string sname = d3.Rows[i]["stationname"].ToString();
                            string[] sstation = new string[2];
                            sstation[0] = sid; sstation[1] = sname;
                            allinfor.Stationlist.Add(sstation);
                        }
                    }

                    Maticsoft.BLL.building_infor service5 = new Maticsoft.BLL.building_infor();
                    DataTable d4 = service5.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d4.Rows.Count > 0)
                    {
                        for (int i = 0; i < d4.Rows.Count; i++)
                        {
                            string sid = d4.Rows[i]["buildingid"].ToString();
                            string sname = d4.Rows[i]["buildingname"].ToString();
                            string[] sbuilding = new string[2];
                            sbuilding[0] = sid; sbuilding[1] = sname;
                            allinfor.Buildinglist.Add(sbuilding);
                        }
                    }


                    Maticsoft.BLL.machine_infor service6 = new Maticsoft.BLL.machine_infor();
                    DataTable d5 = service6.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d5.Rows.Count > 0)
                    {
                        for (int i = 0; i < d5.Rows.Count; i++)
                        {
                            string sid = d5.Rows[i]["machineid"].ToString();
                            string sname = d5.Rows[i]["machinename"].ToString();
                            string[] smachine = new string[2];
                            smachine[0] = sid; smachine[1] = sname;
                            allinfor.Machinelist.Add(smachine);
                        }
                    }

                    Maticsoft.BLL.ysd_infor service7 = new Maticsoft.BLL.ysd_infor();
                    DataTable d7 = service7.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d7.Rows.Count > 0)
                    {
                        for (int i = 0; i < d7.Rows.Count; i++)
                        {
                            string sid = d7.Rows[i]["ysdid"].ToString();
                            string sname = d7.Rows[i]["ysdname"].ToString();
                            string[] sysd = new string[2];
                            sysd[0] = sid; sysd[1] = sname;
                            allinfor.Ysdlist.Add(sysd);
                        }
                    }


                    Maticsoft.BLL.device_infor service8 = new Maticsoft.BLL.device_infor();
                    DataTable d8 = service8.GetList("stationid='" + station_id + "'").Tables[0];
                    if (d8.Rows.Count > 0)
                    {
                        for (int i = 0; i < d8.Rows.Count; i++)
                        {
                            string sid = d8.Rows[i]["deviceid"].ToString();
                            string sname = d8.Rows[i]["devicename"].ToString();
                            string[] sdevice = new string[2];
                            sdevice[0] = sid; sdevice[1] = sname;
                            allinfor.Devicelist.Add(sdevice);
                        }
                    }
                }
                httpsend( Newtonsoft.Json.JsonConvert.SerializeObject(allinfor));
        }

        [WebMethod(Description="接口描述：添加预设点之前，先检查预设点编号，预设点下拉框选项中应显示未添加的预设点")]
        public void getUnaddYsd(string machineid)
        {
            Maticsoft.BLL.ysd_infor ysdser = new Maticsoft.BLL.ysd_infor();
            List<Maticsoft.Model.ysd_infor> ysdmodellist = new List<Maticsoft.Model.ysd_infor>();
            ysdmodellist = ysdser.GetModelList("machineid='"+machineid+"'");
            List<string> ysdlist = new List<string>();
            for(int i=0;i<60;i++)
            {
                ysdlist.Add((i + 1).ToString());
            }
            for(int i=0;i<ysdmodellist.Count();i++)
            {
                ysdlist.Remove(ysdmodellist[i].ysdname);
            }
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(ysdlist));

        }

        [WebMethod(Description = "接口描述：将测试账户下的测试设备移交到某个用户下")]

        public void move_Machine_From_test_To_area(string machineid,string areaid,string fenbuid,string ywbid,string stationid,string buildingid,string machinename)
        {
            
            Maticsoft.Model.machine_infor model = new Maticsoft.Model.machine_infor();
            model.machineid = machineid;
            Maticsoft.BLL.area_infor areaservice = new Maticsoft.BLL.area_infor();
            model.areaid = areaid;
            model.areaname = areaservice.GetModel(areaid).areaname;
            Maticsoft.BLL.fenbu_infor fenbuservice = new Maticsoft.BLL.fenbu_infor();
            model.fenbuid = fenbuid;
            model.fenbuname = fenbuservice.GetModel(fenbuid).fenbuname;
            Maticsoft.BLL.ywb_infor ywbservice = new Maticsoft.BLL.ywb_infor();
            model.ywbid = ywbid;
            model.ywbname = ywbservice.GetModel(ywbid).ywbname;
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            model.stationid = stationid;
            model.stationname = stationservice.GetModel(stationid).stationname;
            Maticsoft.BLL.building_infor buildingservice = new Maticsoft.BLL.building_infor();
            model.buildingid = buildingid;
            model.buildingname = buildingservice.GetModel(buildingid).buildingname;
            Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
            Maticsoft.Model.machine_infor macmodel = new Maticsoft.Model.machine_infor();
            macmodel = machineservice.GetModel(machineid);
            model.machinename = machinename;
            model.machinecompany = macmodel.machinecompany;
            model.machinemac = macmodel.machinemac;
            model.machinecode = macmodel.machinecode;
            model.installcode = macmodel.installcode;
            model.currentversion = macmodel.currentversion;
            model.machinestate = "在线";
            model.ysdcount = "0";
            model.onlinetime = System.DateTime.Now;
            model.imagecatchspan = "0";
            model.fushelv = macmodel.fushelv;
            model.offsetvalue = macmodel.offsetvalue;
            model.createtime = macmodel.createtime;
            machineservice.Update(model);
        }

        #region 巡视接口
        [WebMethod(Description = "接口描述：巡视查询  userid/devicecount/nextdevice必传  nextdevice的值[首次调用值为0，第二次调用值为1，以此类推] ")]
        public void s_patrol(string userid, string areaid, string fenbuid, string ywbid, string stationid, string buildingid, string machineid, string nextdevice, string imagetype)
        {
            httpsend(action.patrol(userid, areaid, fenbuid, ywbid, stationid, buildingid,machineid, nextdevice, imagetype));
        }
        [WebMethod(Description = "接口描述：添加异常信息  userid, deviceid,typeid 参数必传 typeid描述id")]
        public void saveDeviceException(string userid, string deviceid, string typeid)
        {
            httpsend(action.saveDeviceException(userid, deviceid, typeid));
        }
        [WebMethod(Description = "接口描述：添加巡视信息  userid, inspector, stationid必传 inspector [巡视人]  ")]
        public void saveDevicePatorl(string userid, string inspector)
        {
            httpsend(action.saveDevicePatorl(userid, inspector));
        }
        [WebMethod(Description = "接口描述：查询巡视信息  userid必传 inspector [巡视人]  ")]
        public void findDevicePatorl(string userid, string areaid, string fenbuid, string ywbid, string stationid, string inspector, string page, string limit, string starttime, string endtime, string conclusion)
        {
            httpsend(action.findDevicePatorl(userid, areaid, fenbuid, ywbid, stationid, inspector,page,limit, starttime, endtime, conclusion));
        }
        [WebMethod(Description = "接口描述：查询异常信息  userid必传 typeid描述id ")]
        public void findDeviceException(string userid, string areaid, string fenbuid, string ywbid, string stationid, string page, string limit, string starttime, string endtime, string typename, string typeid, string status)
        {
            httpsend(action.findDeviceException(userid, areaid, fenbuid, ywbid, stationid,page,limit, starttime, endtime, typename, typeid,  status));
        }
        [WebMethod(Description = "接口描述：根据巡视表ID查询对应的异常信息  patrolid 巡视表ID 必传")]
        public void findDeviceExceptionByPatrolid(string patrolid, string page, string limit, string typename)
        {
            httpsend(action.findDeviceExceptionByPatrolid(patrolid,page,limit, typename));
        }
        [WebMethod(Description = "接口描述：根据异常类型获取异常描述")]
        public void findDescriptionByTypeName(string typename)
        {
            httpsend(action.findDescriptionByTypeName(typename));
        }
        [WebMethod(Description = "接口描述：查询所有的异常类型")]
        public void findDeviceExceptionType()
        {
            httpsend(ToJson(action.findDeviceExceptionType()));
        }
        [WebMethod(Description = "接口描述：统计所有设备异常类型的数量")]
        public void findDeviceExceptionTypeByCount()
        {
            httpsend(action.findDeviceExceptionTypeByCount());
        }
        [WebMethod(Description = "接口描述：统计所有异常状态的数量")]
        public void findDeviceExceptionStatusByCount()
        {
            httpsend(action.findDeviceExceptionStatusByCount());
        }
        [WebMethod(Description = "接口描述：全部正常接口[将红外设备下巡视状态为无状态设备，修改为正常状态]")]
        public void updateDevicePatrolStatus(string userid, string machineid)
        {
            httpsend(action.updateDevicePatrolStatus(userid, machineid));
        }
        [WebMethod(Description = "接口描述：userid,deviceid 必传 [修改设备的巡视状态为正常状态]")]
        public void updateNormal(string userid, string deviceid)
        {
            httpsend(action.updateNormal(userid, deviceid));
        }
        [WebMethod(Description = "接口描述：删除异常记录 id必传[异常记录表id]")]
        public void deleteDeviceException(string id)
        {
            httpsend(action.deleteDeviceException(id));
        }
        [WebMethod(Description = "接口描述：删除巡视记录 patrolid必传[异常记录表id]")]
        public void deleteDevicePatorl(string patrolid)
        {
            httpsend(action.deleteDevicePatorl(patrolid));
        }
        #endregion


        [WebMethod(Description ="通过登录人的城市获取经度和维度")]
        public void GetCityLongitude(string userid)
        {
            string Json=action.GetCityLongitude(userid);
            httpsend(Json);
        }

    }


    public class MediaResult
    {
        private ArrayList data;
        private string index;

        public ArrayList Data
        {
            get { return data; }
            set { this.data = value; }
        }

        public string Index
        {
            get { return index; }
            set { this.index = value; }
        }

    }

    public class MachineResult
    {
        private DataTable machine;
        private MediaResult media;

        public DataTable Machine
        {
            get { return machine; }
            set { machine = value; }
        }

        public MediaResult Media
        {
            get { return media; }
            set { media = value; }
        }

    }

}
