﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.UserServices
{

    public class condition
    {
        string id = "";

        public string Id
        {
            get { return id; }
            set { id = value; }
        }
        string name = "";

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        string show = "";

        public string Show
        {
            get { return show; }
            set { show = value; }
        }
    }
}