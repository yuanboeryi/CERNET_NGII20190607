﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.UserServices
{

    public class devicelistjson
    {
        string recordcount = "";

        public string Recordcount
        {
            get { return recordcount; }
            set { recordcount = value; }
        }
        DataTable recorddt = new DataTable();

        public DataTable Recorddt
        {
            get { return recorddt; }
            set { recorddt = value; }
        }
    }
}