﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.UserServices
{
    public class exceptionjson
    {
        string _typename = "";
        public string typename
        {
            get { return _typename; }
            set { _typename = value; }
        }
        int _count = 0;
        public int count
        {
            get { return _count; }
            set { _count = value; }
        }
    }
}