﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{
    public class patroljson
    {
        string area_id = "";

        public string areaid
        {
            get { return area_id; }
            set { area_id = value; }
        }
        string _fenbuid = "";

        public string fenbuid
        {
            get { return _fenbuid; }
            set { _fenbuid = value; }
        }
        string _ywbid = "";

        public string ywbid
        {
            get { return _ywbid; }
            set { _ywbid = value; }
        }
        string _stationid = "";

        public string stationid
        {
            get { return _stationid; }
            set { _stationid = value; }
        }

        string _buildingid = "";
        public string buildingid
        {
            get { return _buildingid; }
            set { _buildingid = value; }
        }
 
        string _machineid = "";
        public string machineid
        {
            get { return _machineid; }
            set { _machineid = value; }
        }
        string _machinename = "";
        public string machinename
        {
            get { return _machinename; }
            set { _machinename = value; }
        }     
        DataTable imagedt = new DataTable();
        public DataTable Imagedt
        {
            get { return imagedt; }
            set { imagedt = value; }
        }
        string _isLast = "0";
        public string isLast
        {
            set { _isLast = value; }
            get { return _isLast; }
        }
        string _indexnunber = "";
        public string indexnumber
        {
            get { return _indexnunber; }
            set { _indexnunber = value; }
        }
    }
}