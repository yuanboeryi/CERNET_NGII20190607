﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.UserServices
{
    public class queryConditionList
    {
        List<condition> arealist = new List<condition>();

        public List<condition> Arealist
        {
            get { return arealist; }
            set { arealist = value; }
        }
        List<condition> fenbulist = new List<condition>();

        public List<condition> Fenbulist
        {
            get { return fenbulist; }
            set { fenbulist = value; }
        }
        List<condition> ywblist = new List<condition>();

        public List<condition> Ywblist
        {
            get { return ywblist; }
            set { ywblist = value; }
        }
        List<condition> stationlist = new List<condition>();

        public List<condition> Stationlist
        {
            get { return stationlist; }
            set { stationlist = value; }
        }
       List<condition> buildinglist = new List<condition>();

       public List<condition> Buildinglist
        {
            get { return buildinglist; }
            set { buildinglist = value; }
        }
        List<condition> machinelist = new List<condition>();

        public List<condition> Machinelist
        {
            get { return machinelist; }
            set { machinelist = value; }
        }
       List<condition> ysdlist = new List<condition>();

        public List<condition> Ysdlist
        {
            get { return ysdlist; }
            set { ysdlist = value; }
        }
        List<condition> devicelist = new List<condition>();

        public List<condition> Devicelist
        {
            get { return devicelist; }
            set { devicelist = value; }
        }

        List<condition> devicetypelist = new List<condition>();

        public List<condition> Devicetypelist
        {
            get { return devicetypelist; }
            set { devicetypelist = value; }
        }

        string _status = "0";
        public string status
        {
            get { return _status; }
            set { _status = value; }
        }
    }
}