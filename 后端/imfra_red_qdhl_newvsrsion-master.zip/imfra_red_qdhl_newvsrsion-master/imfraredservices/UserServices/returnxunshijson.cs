﻿using imfraredservices.UserServices;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.TableService
{

    public class returnxunshijson
    {
        List<Maticsoft.Model.exception_type_infor> _exceptiontypelist = new List<Maticsoft.Model.exception_type_infor>();
        public List<Maticsoft.Model.exception_type_infor> exceptionTypelist
        {
            get { return _exceptiontypelist; }
            set { _exceptiontypelist = value; }
        }
        List<exceptionjson> _typelist = new List<exceptionjson>();
        public List<exceptionjson> typelist
        {
            get { return _typelist; }
            set { _typelist = value; }
        }
        List<Maticsoft.Model.device_patrol_infor> _patrollist = new List<Maticsoft.Model.device_patrol_infor>();
        public List<Maticsoft.Model.device_patrol_infor> patrollist
        {
            get { return _patrollist; }
            set { _patrollist = value; }
        }
        DataTable _exceptionlist = new DataTable();
        public DataTable exceptionlist
        {
            get { return _exceptionlist; }
            set { _exceptionlist = value; }
        }
        int _count = 0;
        public int count {
            get { return _count; }
            set { _count = value; }
        }

        string _msg = "";

        public string msg
        {
            get { return _msg; }
            set { _msg = value; }
        }
        bool __falg = false;

        public bool falg
        {
            get { return __falg; }
            set { __falg = value; }
        }
    }
}