﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace imfraredservices.WeatherService
{
    public class WeatherServer
    {
        public string insertWeather(string city,string cityTemp,string windSpeed,string cityhumidity,string weatherInfor,string alarmInfor)
        {
            Maticsoft.BLL.city_infor service = new Maticsoft.BLL.city_infor();
            List<Maticsoft.Model.city_infor> modellist = new List<Maticsoft.Model.city_infor>();
            modellist = service.GetModelList("");
            string id = "";
            string ywbid = "";
            string ywbname = "";
            string cityname="";
            string devicetopvalue = "";
            string jingdu = "";
            string weidu = "";
            bool ishave=false;
            for(int i=0;i<modellist.Count();i++)
            {
                if(modellist[i].cityname.Equals(city))
                {
                    id = modellist[i].cityid;
                    ywbid = modellist[i].ywbid;
                    ywbname = modellist[i].ywbname;
                    cityname = modellist[i].cityname;
                    devicetopvalue = modellist[i].devicetopvalue;
                    jingdu = modellist[i].jingdu;
                    weidu = modellist[i].weidu;
                    string topid = modellist[i].temprecordid;
                    ishave = true;
                    Maticsoft.Model.city_infor model = new Maticsoft.Model.city_infor();
                    model.cityid = id;
                    model.ywbid = ywbid;
                    model.ywbname = ywbname;
                    model.cityname = cityname;
                    model.devicetopvalue = devicetopvalue;
                    model.citytemputer = cityTemp;
                    model.windspeed = windSpeed;
                    model.humidity = cityhumidity;
                    model.weather = weatherInfor;
                    model.weatnerinfor = alarmInfor;
                    model.jingdu = jingdu;
                    model.weidu = weidu;
                    model.temprecordid = topid;
                    service.Update(model);
                }
            }
            return "1";
        }

        public DataTable getCity(string userid)
        {
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermo = new Maticsoft.Model.user_infor();
            usermo = userservice.GetModel(userid);
            string city = usermo.city;
            Maticsoft.BLL.city_infor service = new Maticsoft.BLL.city_infor();
            return service.GetList("cityname like '%"+city+"%'").Tables[0];
        }
    }
}