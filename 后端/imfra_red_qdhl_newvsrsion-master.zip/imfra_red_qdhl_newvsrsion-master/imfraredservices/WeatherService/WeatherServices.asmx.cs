﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace imfraredservices.WeatherService
{
    /// <summary>
    /// WeatherServices 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class WeatherServices : System.Web.Services.WebService
    {
        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        //字符串转json
        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msgsend");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        WeatherServer action = new WeatherServer();
        [WebMethod(Description="接口描述：将前端获取到的天气信息发送给后台：参数描述：city,cityTemp,windSpeed,cityhumidity,weatherInfor,alarmInfor[城市，气温，风速，湿度，阴晴，预警信息]")]
        public void SendWeatherToServer(string city, string cityTemp, string windSpeed, string cityhumidity, string weatherInfor, string alarmInfor)
        { 
            httpsend(strJson(action.insertWeather(city, cityTemp, windSpeed, cityhumidity, weatherInfor, alarmInfor)));
        }

        [WebMethod(Description="接口描述：获取当前用户下的天气信息,参数：userid，登录用户的id")]
        public void getWeather(string userid)
        {

            httpsend(ToJson(action.getCity(userid)));
        }
    }
}
