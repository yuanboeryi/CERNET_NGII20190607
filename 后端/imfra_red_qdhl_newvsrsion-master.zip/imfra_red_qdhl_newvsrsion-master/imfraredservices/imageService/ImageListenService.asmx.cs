﻿using imfraredservices.HelperServer;
using Maticsoft.Common;
using Maticsoft.DBUtility;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace imfraredservices.imageService
{
    /// <summary>
    /// ImageListenService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class ImageListenService : System.Web.Services.WebService
    {

        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        public int UrlToImage(string url)
        {
            try
            {
                WebClient mywebclient = new WebClient();
                byte[] Bytes = mywebclient.GetData(url);
                return Bytes.Length;
            }
            catch
            {
                return -1;
            }
        }
        public void updatequetu(string deviceid, DateTime time, string hour, string type)
        {
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
            devicemodel = deviceservice.GetModel(deviceid);
            if (devicemodel == null)
                return;
            Maticsoft.Model.quetu_infor quetumodel = new Maticsoft.Model.quetu_infor();
            quetumodel.recordid = Guid.NewGuid().ToString("N");
            quetumodel.areaid = devicemodel.areaid;
            quetumodel.areaname = devicemodel.areaname;
            quetumodel.fenbuid = devicemodel.fenbuid;
            quetumodel.fenbuname = devicemodel.fenbuname;
            quetumodel.ywbid = devicemodel.ywbid;
            quetumodel.ywbname = devicemodel.ywbname;
            quetumodel.stationid = devicemodel.stationid;
            quetumodel.stationname = devicemodel.stationname;
            quetumodel.deviceid = deviceid;
            quetumodel.devicename = devicemodel.devicename;
            quetumodel.quetudate = time;
            quetumodel.quetutime = hour;
            quetumodel.queinfor = type;
            Maticsoft.BLL.quetu_infor quetuservice = new Maticsoft.BLL.quetu_infor();
            quetuservice.Add(quetumodel);
        }
        [WebMethod(Description = "接口描述：从图片监听程序中获取最新图片信息，内部接口，前端不用")]
        public void sendImageInfor(string imagename)
        {
            //System.Diagnostics.Debug.WriteLine(imagename);
            //writeLog(imagename);
            try
            {
                string[] array = imagename.Replace(@"\", "\\").Split('~');
                string stime = array[0];
                string mac = array[1];
                Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                Maticsoft.Model.machine_infor machinemodel = new Maticsoft.Model.machine_infor();
                machinemodel = machineservice.GetModelbymac(array[1]);
                if (machinemodel == null)
                    return;
                if (machinemodel.areaname == "郑州供电公司")
                    imageToRecord(imagename);
                else
                    imageToRecord1(imagename);
            }
            catch(Exception ue)
            {
                writeLog(ue.Message);
                return;
            }
        }
      
        private void writeLog(string logtext)
        {
            //string path = ConfigurationManager.AppSettings["ImagePath"];////AppDomain.CurrentDomain.BaseDirectory;
            //path = System.IO.Path.Combine(path,"\\" + DateTime.Now.ToString("yy-MM-dd"));

            //if (!System.IO.Directory.Exists(path))
            //{
            //    System.IO.Directory.CreateDirectory(path);
            //}
            //string fileFullName = System.IO.Path.Combine(path, string.Format("{0}.log", DateTime.Now.ToString("yyMMdd-HHmmss")));


            //using (StreamWriter output = System.IO.File.AppendText(fileFullName))
            //{
            //    output.WriteLine(logtext);

            //    output.Close();
            //}
        }
        public string updateAlarmpush(string deviceid, string max, string offset,string devicetype, string image, DateTime alarmtime,string isalarm1)
        {
            
            DateTime dtnew = alarmtime;
            Maticsoft.BLL.device_infor sss = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor sm = new Maticsoft.Model.device_infor();
            sm = sss.GetModel(deviceid);
            Maticsoft.BLL.alarm_push_infor ser = new Maticsoft.BLL.alarm_push_infor();
            DataSet ds = ser.GetList("deviceid='"+deviceid+"' and alarmvalue='"+max+"'");
            if (ds.Tables[0].Rows.Count < 1)
            {
                Maticsoft.Model.alarm_push_infor smodel = new Maticsoft.Model.alarm_push_infor();
                smodel.id = Guid.NewGuid().ToString("N");
                smodel.areaid = sm.areaid;
                smodel.areaname = sm.areaname;
                smodel.fenbuid = sm.fenbuid;
                smodel.fenbuname = sm.fenbuname;
                smodel.ywbid = sm.ywbid;
                smodel.devicetype = devicetype;
                smodel.ywbname = sm.ywbname;
                smodel.stationid = sm.stationid;
                smodel.stationname = sm.stationname;
                smodel.buildingid = sm.buildingid;
                smodel.buildingname = sm.buildingname;
                smodel.machineid = sm.machineid;
                smodel.machinename = sm.machinename;
                smodel.ysdid = sm.ysdindex;
                smodel.ysdname = sm.ysdname;
                smodel.deviceid = sm.deviceid;
                smodel.devicename = sm.devicename;
                smodel.alarmvalue = max;

                // 是否推送
                smodel.IsPush = "0";
                //if (isalarm1 == "1")//告警
                //{
                //    smodel.isread = "1";
                //    smodel.isok = "1";
                //}
                //else//非告警
                //{
                //    //smodel.isread = "0";
                //    //smodel.isok = "0";
                //    //smodel.mensuretime = alarmtime;
                //}
                smodel.image_url = image;
                smodel.overvalue = (double.Parse(max) - double.Parse(offset)).ToString("0.0");
                smodel.createtime = alarmtime;
                if (isalarm1 == "1")//告警
                {
                    smodel.isread = "1";
                    smodel.isok = "1";
                    ser.Add(smodel);
                }              
                 //ser.Add(smodel);
                smodel = null;

                ser = null;
                return "1";
            }
            else
                return "0";
           
        }
        public void updateRaselist(string lastvalue, string nowvalue, DateTime dt, string deviceid)
        {
            Maticsoft.BLL.device_infor deviceser = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
            model = deviceser.GetModel(deviceid);
            Maticsoft.BLL.temp_rase_infor tempservice = new Maticsoft.BLL.temp_rase_infor();
            Maticsoft.Model.temp_rase_infor tempmodel = new Maticsoft.Model.temp_rase_infor();
            tempmodel.recordid = Guid.NewGuid().ToString("N");
            tempmodel.areaid = model.areaid;
            tempmodel.areaname = model.areaname;
            tempmodel.fenbuid = model.fenbuid;
            tempmodel.fenbuname = model.fenbuname;
            tempmodel.ywbid = model.ywbid;
            tempmodel.ywbname = model.ywbname;
            tempmodel.stationid = model.stationid;
            tempmodel.stationname = model.stationname;
            tempmodel.buildingid = model.buildingid;
            tempmodel.buildingname = model.buildingname;
            tempmodel.deviceid = deviceid;
            tempmodel.devicename = model.devicename;
            tempmodel.lasttemp = lastvalue;
            tempmodel.nowtemp = nowvalue;
            tempmodel.overtemp = model.offsetvalue;
            tempmodel.createtime = model.createtime;
            tempservice.Add(tempmodel);
        }
        [WebMethod(Description = "接口描述：ceshi ")]
        public void updateRaselist1(string lastvalue, string nowvalue, DateTime dt, string deviceid)
        {
            lastvalue = "50";
            nowvalue = "88";
            dt = System.DateTime.Now;
            deviceid = "0072a2577e874cf096f1b674758a7e90";
            Maticsoft.BLL.device_infor deviceser = new Maticsoft.BLL.device_infor();
            Maticsoft.Model.device_infor model = new Maticsoft.Model.device_infor();
            model = deviceser.GetModel(deviceid);
            Maticsoft.BLL.temp_rase_infor tempservice = new Maticsoft.BLL.temp_rase_infor();
            Maticsoft.Model.temp_rase_infor tempmodel = new Maticsoft.Model.temp_rase_infor();
            tempmodel.recordid = Guid.NewGuid().ToString("N");
            tempmodel.areaid = model.areaid;
            tempmodel.areaname = model.areaname;
            tempmodel.fenbuid = model.fenbuid;
            tempmodel.fenbuname = model.fenbuname;
            tempmodel.ywbid = model.ywbid;
            tempmodel.ywbname = model.ywbname;
            tempmodel.stationid = model.stationid;
            tempmodel.stationname = model.stationname;
            tempmodel.buildingid = model.buildingid;
            tempmodel.buildingname = model.buildingname;
            tempmodel.deviceid = deviceid;
            tempmodel.devicename = model.devicename;
            tempmodel.lasttemp = lastvalue;
            tempmodel.nowtemp = nowvalue;
            tempmodel.overtemp = model.offsetvalue;
            tempmodel.createtime = model.createtime.Value;
            tempservice.Add(tempmodel);
        }
        #region 解析线程1
        bool isalready = true;
        public void imageToRecord(string imagename)
        {
            if (isalready)
            {
                isalready = false;
                string image_00 = "";
                string image_11 = "";
                string image_22 = "";
                if (imagename.Contains("~0~"))
                {
                    image_00 = imagename;
                    image_22 = imagename.Replace("~0~", "~2~");
                    image_11 = imagename.Replace("~0~", "~1~");
                }
                if (imagename.Contains("~1~"))
                {
                    image_11 = imagename;
                    image_22 = imagename.Replace("~1~", "~2~");
                    image_00 = imagename.Replace("~1~", "~0~");
                }
                if (imagename.Contains("~2~"))
                {
                    image_22 = imagename;
                    image_00 = imagename.Replace("~2~", "~0~");
                    image_11 = imagename.Replace("~2~", "~1~");
                }
                bool icunzai = false;
                if (icunzai)
                    return;
                else
                {
                    Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                    Maticsoft.Model.machine_infor machinemodel = new Maticsoft.Model.machine_infor();
                    Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
                    Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                    Maticsoft.Model.device_infor devicemodel1 = new Maticsoft.Model.device_infor();
                    Maticsoft.BLL.image_record_history imagerecordservice = new Maticsoft.BLL.image_record_history();
                    Maticsoft.Model.image_record_history imagerecordmodel = new Maticsoft.Model.image_record_history();
                    try
                    {
                        string imagepath0 = image_00.Replace("\\", "/");
                        string imagepath1 = image_11.Replace("\\", "/");

                        string imagepath2 = image_22.Replace("\\", "/");

                        // string imageurl = "http://122.114.204.83/image/";
                        string imageurl = "http://117.159.7.31:8082/image/";
                        string[] array = image_00.Replace(@"\", "\\").Split('~');
                        string stime = array[0];
                        string mac = array[1];

                        machinemodel = machineservice.GetModelbymac(array[1]);

                        string min = array[2];
                        string ave = array[3];
                        string max = array[4];
                        
                        string type = array[5];
                        string machineid = machinemodel.machineid;
                        string ysdindex = array[6].Split('.')[0];
                        string machinemac = machinemodel.machinemac;
                        DateTime dt;
                        DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                        dtFormat.ShortDatePattern = "yyyy-MM-dd hh:mm:ss";                        
                        dt = Convert.ToDateTime(stime.Split('\\')[stime.Split('\\').Length - 1].Replace("&", ":"), dtFormat);

                        int npage = 0; int end = 191;
                        string sqllint = " limit " + npage + "," + end + "";
                        string sid = "";
                        //根据抓拍设备id和预设点编号找到对应设备

                        devicemodel = deviceservice.GetModelByMachine(machineid, ysdindex);
                        string stempall = "";
                        bool ishave = false;
                        if (ishave)
                        {
                            imagerecordmodel.recordid = sid;//保持原来id
                            stempall = devicemodel.templist;

                        }
                        else
                        {
                            #region
                            List<string> list_24 = new List<string>();
                            List<string> time_list = new List<string>();
                            for (int i = dt.Hour + 1; i < 24; i++)
                            {
                                time_list.Add(i.ToString());
                            }
                            for (int i = 0; i < dt.Hour + 1; i++)
                            {
                                time_list.Add(i.ToString());
                            }

                            if (devicemodel.templist == null || devicemodel.templist == "")
                            {
                                list_24.Clear();
                                for (int i = 0; i < 24; i++)
                                {
                                    list_24.Add("0");
                                }
                            }
                            else
                            {
                                list_24.Clear();
                                for (int i = 0; i < devicemodel.templist.Split(',').Length; i++)
                                {
                                    string sx = devicemodel.templist.Split(',')[i].Split(';')[1];
                                    list_24.Add(sx);
                                }
                                if (list_24.Count() != 24)
                                {
                                    list_24.Clear();
                                    for (int i = 0; i < 24; i++)
                                    {
                                        list_24.Add("0");
                                    }
                                }
                            }
                            string shour = dt.Hour.ToString();
                            list_24.RemoveAt(0);
                            list_24.Add(max);

                            for (int i = 0; i < list_24.Count(); i++)
                            {
                                stempall += time_list[i] + ";" + list_24[i] + ",";
                            }
                            stempall = stempall.Remove(stempall.Length - 1, 1);
                            #endregion
                            imagerecordmodel.recordid = Guid.NewGuid().ToString("N");//生成记录id

                        }
                        imagerecordmodel.deviceid = devicemodel.deviceid;
                        imagerecordmodel.devicename = devicemodel.devicename;
                        string alarmimage = "";
                        string insert1 = imageurl + imagepath0;
                        string insert2 = imageurl + imagepath1;
                        string insert3 = imageurl + imagepath2;
                        string queinfor = "";
                        bool isxx = false;
                        if (UrlToImage(insert1) < 0)
                        {
                            isxx = true;
                            queinfor += "高清,";
                        }
                        if (UrlToImage(insert2) < 0)
                        {
                            isxx = true;
                            queinfor += "红外1,";
                        }
                        if (UrlToImage(insert3) < 0)
                        {
                            isxx = true;
                            queinfor += "红外2";
                        }
                        if (isxx)
                            updatequetu(devicemodel.deviceid, dt, dt.Hour.ToString(), queinfor);
                        imagerecordmodel.image0 = insert1;
                        imagerecordmodel.image1 = insert2;
                        imagerecordmodel.image2 = insert3;

                        devicemodel.image_high = insert1;
                        devicemodel.image_red = insert2;
                        devicemodel.image_mix = insert3;
                        deviceservice.UpdateImage(devicemodel.deviceid, insert1, insert2, insert3, dt, stempall);//更新设备表中最新图片
                        alarmimage = insert2;
                        string lastvalue = devicemodel.todaytop;
                        string nowvalue = max;
                        string value = devicemodel.isalarm;
                        string today = devicemodel.todaytop;
                        string yestoday = devicemodel.yestodaytop;
                        string week = devicemodel.weektop;
                        string month = devicemodel.monthtop;
                        string history = devicemodel.historytop;
                        string isalarm = "0";
                        if (devicemodel.offsetvalue != "" && devicemodel.offsetvalue != null)
                        {
                            double maxvalue = double.Parse(max);
                            if (maxvalue >= double.Parse(devicemodel.offsetvalue))//判断是否告警
                            {
                                try
                                {
                                    value = "1";
                                    imagerecordmodel.isalarm = "1";
                                    isalarm = "1";
                                    string sxxx=updateAlarmpush(devicemodel.deviceid, max, devicemodel.offsetvalue,devicemodel.ysdtype, alarmimage, dt,isalarm);
                                    HttpHelperServer.CreateTxt("updateAlarmpush", "", "执行完此方法说明已经添加过告警数据,sxxx的状态是:" + sxxx + "设备Id是:" + devicemodel.deviceid + "设备温度:" + maxvalue);
                                    if (sxxx == "1")
                                        updatestationAlarmcount(devicemodel.stationid);
                                }
                                catch (Exception e)
                                {
                                    HttpHelperServer.CreateTxt("updateAlarmpush", "", "当前方法执行出错,错误信息为:" + e.Message.ToString());
                                }
                            }
                        }

                        today = max; devicemodel.todaytop = max; devicemodel.createtime = dt;
                        if (dt.Hour == 0)//如果是零点就把昨天最高温替换掉
                        {
                            //if (devicemodel.yestodaytop == "" || double.Parse(devicemodel.todaytop) >= double.Parse(devicemodel.yestodaytop))
                            //{
                                yestoday = devicemodel.todaytop; devicemodel.yestodaytop = devicemodel.todaytop; devicemodel.yestodaymaxid = devicemodel.todaymaxid;
                            //}
                        }
                        if (dt.Hour == 0 || devicemodel.todaymax == "" || double.Parse(max) >= double.Parse(devicemodel.todaymax))
                        {
                            devicemodel.todaymax = max; devicemodel.todaymaxid = imagerecordmodel.recordid;
                        }                                             
                        if (devicemodel.weektop == "" || double.Parse(max) >= double.Parse(devicemodel.weektop))
                        {
                            week = max; devicemodel.weektop = max; devicemodel.weekmaxid= imagerecordmodel.recordid;
                        }
                        if (devicemodel.monthtop == "" || double.Parse(max) >= double.Parse(devicemodel.monthtop))
                        {
                            month = max; devicemodel.monthtop = max; devicemodel.monthmaxid = imagerecordmodel.recordid;
                        }
                        if (devicemodel.historytop == "" || double.Parse(max) >= double.Parse(devicemodel.historytop))
                        {
                            history = max; devicemodel.historytop = max; devicemodel.historymaxid = imagerecordmodel.recordid;
                        }
                        string isokok="1";
                        Maticsoft.BLL.alarm_push_infor alarmservice1 = new Maticsoft.BLL.alarm_push_infor();
                        List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
                        alarmlist = alarmservice1.GetModelList("deviceid='"+devicemodel.deviceid+"' and isok='"+isokok+"'");
                        if (alarmlist.Count > 0)
                        {
                            value = "1";
                            devicemodel.isalarm = value;
                        }
                        //deviceservice.UpdateAlarm(devicemodel.deviceid, value, max);
                        bool falg = deviceservice.Update(devicemodel);//更新设备表中的数据
                        if (!falg)
                        {
                            deviceservice.UpdateAlarm(devicemodel.deviceid, value, max);
                            deviceservice.UpdateHistory(devicemodel.deviceid, devicemodel.yestodaytop, week, month, history, devicemodel.todaytop, devicemodel.monthmax, devicemodel.todaymaxid, devicemodel.yestodaymaxid, devicemodel.weekmaxid, devicemodel.monthmaxid, devicemodel.historymaxid);
                        }
                        Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
                        machineservice.Updatetime(machineid, System.DateTime.Now.ToString());
                        imagerecordmodel.areaid = devicemodel.areaid;
                        imagerecordmodel.areaname = devicemodel.areaname;
                        imagerecordmodel.fenbuid = devicemodel.fenbuid;
                        imagerecordmodel.fenbuname = devicemodel.fenbuname;
                        imagerecordmodel.ywbid = devicemodel.ywbid;
                        imagerecordmodel.ywbname = devicemodel.ywbname;
                        imagerecordmodel.deviceindex = ysdindex;
                        imagerecordmodel.machinemac = mac;
                        imagerecordmodel.valuemax = max;
                        imagerecordmodel.valuemin = min;
                        imagerecordmodel.valueave = ave;
                        imagerecordmodel.templist_24 = stempall;
                        imagerecordmodel.isalarm = isalarm;
                        imagerecordmodel.createtime = dt;

                        if (ishave)
                        {
                            imagerecordservice.Update(imagerecordmodel);
                            updatestation(devicemodel.stationid, max, imagerecordmodel.recordid, dt);

                        }
                        else
                        {
                            imagerecordservice.Add(imagerecordmodel);
                            updatestation(devicemodel.stationid, max, imagerecordmodel.recordid, dt);

                        }
                        updatecity(devicemodel.ywbid, today, imagerecordmodel.recordid);


                        // 当前的预警类型默认是其他设备
                        string IsSwitchCabinet = "";
                        // 判断是否是开关柜 升高10°进行预警
                        if (devicemodel.ysdtype.Contains("开关柜"))
                        {
                            if (double.Parse(today) + 10 <= double.Parse(max))
                            {
                                    IsSwitchCabinet = "开关柜";
                                    updateRaselist(lastvalue, nowvalue, System.DateTime.Now, devicemodel.deviceid);
                                    HuaweiPush.HuaweiPushAction acc = new HuaweiPush.HuaweiPushAction();
                                    acc.sendPushMessageOver(devicemodel.areaname, devicemodel.stationname, devicemodel.buildingname, devicemodel.machinename, devicemodel.devicename, max, dt.ToString(), IsSwitchCabinet);
                            }
                        }
                        else
                        {
                            if (double.Parse(today) + 20 <= double.Parse(max))
                            {
                                updateRaselist(lastvalue, nowvalue, System.DateTime.Now, devicemodel.deviceid);
                                HuaweiPush.HuaweiPushAction acc = new HuaweiPush.HuaweiPushAction();
                                acc.sendPushMessageOver(devicemodel.areaname, devicemodel.stationname, devicemodel.buildingname, devicemodel.machinename, devicemodel.devicename, max, dt.ToString(), IsSwitchCabinet);
                            }
                        }
                        isalready = true;

                    }
                    catch (Exception e)
                    {
                        writeLog(e.Message);
                        isalready = true;

                    }
                    finally
                    {
                        isalready = true;
                    }
                }
            }
        }
        #endregion
        #region 解析线程2
        bool isalready1 = true;
        public void imageToRecord1(string imagename)
        {
            if (isalready1)
            {
                isalready1 = false;
                string image_00 = "";
                string image_11 = "";
                string image_22 = "";
                if (imagename.Contains("~0~"))
                {
                    image_00 = imagename;
                    image_22 = imagename.Replace("~0~", "~2~");
                    image_11 = imagename.Replace("~0~", "~1~");
                }
                if (imagename.Contains("~1~"))
                {
                    image_11 = imagename;
                    image_22 = imagename.Replace("~1~", "~2~");
                    image_00 = imagename.Replace("~1~", "~0~");
                }
                if (imagename.Contains("~2~"))
                {
                    image_22 = imagename;
                    image_00 = imagename.Replace("~2~", "~0~");
                    image_11 = imagename.Replace("~2~", "~1~");
                }

                bool icunzai = false;
                if (icunzai)
                    return;
                else
                {
                    Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                    Maticsoft.Model.machine_infor machinemodel = new Maticsoft.Model.machine_infor();
                    Maticsoft.BLL.image_record_history imagerecordservice = new Maticsoft.BLL.image_record_history();
                    Maticsoft.Model.image_record_history imagerecordmodel = new Maticsoft.Model.image_record_history();
                    Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
                    Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                    Maticsoft.Model.device_infor devicemodel1 = new Maticsoft.Model.device_infor();
                    try
                    {
                        string imagepath0 = image_00.Replace("\\", "/");
                        System.Diagnostics.Debug.WriteLine("imagepath0===========" + imagepath0);
                        string imagepath1 = image_11.Replace("\\", "/");
                        System.Diagnostics.Debug.WriteLine("imagepath1===========" + imagepath1);
                        string imagepath2 = image_22.Replace("\\", "/");
                        System.Diagnostics.Debug.WriteLine("imagepath2===========" + imagepath2);

                        // string imageurl = "http://122.114.204.83/image/";
                        string imageurl = "http://117.159.7.31:8082/image/";
                        string[] array = image_00.Replace(@"\", "\\").Split('~');
                        string stime = array[0];
                        System.Diagnostics.Debug.WriteLine("stime===========" + stime);
                        string mac = array[1];

                        machinemodel = machineservice.GetModelbymac(array[1]);

                        string min = array[2];
                        System.Diagnostics.Debug.WriteLine("最小值===========" + min);
                        string ave = array[3];
                        System.Diagnostics.Debug.WriteLine("中间值===========" + ave);
                        string max = array[4];
                        System.Diagnostics.Debug.WriteLine("最大值===========" + max);

                        string type = array[5];
                        string machineid = machinemodel.machineid;
                        string ysdindex = array[6].Split('.')[0];
                        string machinemac = machinemodel.machinemac;
                        DateTime dt;
                        DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                        dtFormat.ShortDatePattern = "yyyy-MM-dd hh:mm:ss";
                        //System.Diagnostics.Debug.WriteLine("时间===========" + stime.Split('\\')[stime.Split('\\').Length - 1].Replace("&", ":"));
                        dt = Convert.ToDateTime(stime.Split('\\')[stime.Split('\\').Length - 1].Replace("&", ":"), dtFormat);

                        int npage = 0; int end = 191;
                        string sqllint = " limit " + npage + "," + end + "";
                        bool ishave = false;
                        string sid = "";
                        //根据抓拍设备id和预设点编号找到对应设备
                        devicemodel = deviceservice.GetModelByMachine(machineid, ysdindex);
                        string stempall = "";


                        if (ishave)
                        {
                            imagerecordmodel.recordid = sid;//保持原来id
                            stempall = devicemodel.templist;

                        }
                        else
                        {
                            #region
                            List<string> list_24 = new List<string>();
                            List<string> time_list = new List<string>();
                            for (int i = dt.Hour + 1; i < 24; i++)
                            {
                                time_list.Add(i.ToString());
                            }
                            for (int i = 0; i < dt.Hour + 1; i++)
                            {
                                time_list.Add(i.ToString());
                            }

                            if (devicemodel.templist == null || devicemodel.templist == "")
                            {
                                list_24.Clear();
                                for (int i = 0; i < 24; i++)
                                {
                                    list_24.Add("0");
                                }
                            }
                            else
                            {
                                list_24.Clear();
                                for (int i = 0; i < devicemodel.templist.Split(',').Length; i++)
                                {
                                    string sx = devicemodel.templist.Split(',')[i].Split(';')[1];
                                    list_24.Add(sx);
                                }
                                if (list_24.Count() != 24)
                                {
                                    list_24.Clear();
                                    for (int i = 0; i < 24; i++)
                                    {
                                        list_24.Add("0");
                                    }
                                }
                            }
                            string shour = dt.Hour.ToString();
                            list_24.RemoveAt(0);
                            list_24.Add(max);

                            for (int i = 0; i < list_24.Count(); i++)
                            {
                                stempall += time_list[i] + ";" + list_24[i] + ",";
                            }
                            stempall = stempall.Remove(stempall.Length - 1, 1);
                            #endregion
                            imagerecordmodel.recordid = Guid.NewGuid().ToString("N");//生成记录id

                        }
                        imagerecordmodel.deviceid = devicemodel.deviceid;
                        imagerecordmodel.devicename = devicemodel.devicename;
                        string insert1 = imageurl + imagepath0;
                        string insert2 = imageurl + imagepath1;
                        string insert3 = imageurl + imagepath2;
                        string queinfor = "";
                        bool isxx = false;
                        if (UrlToImage(insert1) < 0)
                        {
                            isxx = true;
                            queinfor += "高清,";
                        }
                        if (UrlToImage(insert2) < 0)
                        {
                            isxx = true;

                            queinfor += "红外1,";
                        }
                        if (UrlToImage(insert3) < 0)
                        {
                            isxx = true;
                            queinfor += "红外2";
                        }
                        if (isxx)
                            updatequetu(devicemodel.deviceid, dt, dt.Hour.ToString(), queinfor);
                        imagerecordmodel.image0 = insert1;
                        imagerecordmodel.image1 = insert2;
                        imagerecordmodel.image2 = insert3;

                        devicemodel.image_high = insert1;
                        devicemodel.image_red = insert2;
                        devicemodel.image_mix = insert3;
                        deviceservice.UpdateImage(devicemodel.deviceid, insert1, insert2, insert3, dt, stempall);//更新设备表中最新图片
                        string lastvalue = devicemodel.todaytop; string nowvalue = max;
                        string alarmimage = insert2;
                        string value = devicemodel.isalarm;
                        string today = devicemodel.todaytop;
                        string yestoday = devicemodel.yestodaytop;
                        string week = devicemodel.weektop;
                        string month = devicemodel.monthtop;
                        string history = devicemodel.historytop;
                        string isalarm = "0";
                        if (devicemodel.offsetvalue != "" && devicemodel.offsetvalue != null)
                        {
                            double maxvalue = Convert.ToDouble(max);
                            if (maxvalue >= Convert.ToDouble(devicemodel.offsetvalue))//判断是否告警
                            {
                                try 
                                {
                                    value = "1";
                                    imagerecordmodel.isalarm = "1";
                                    isalarm = "1";
                                    string sxxx = updateAlarmpush(devicemodel.deviceid, max, devicemodel.offsetvalue, devicemodel.ysdtype, alarmimage, dt,isalarm);
                                    HttpHelperServer.CreateTxt("updateAlarmpush", "", "执行完此方法说明已经添加过告警数据,sxxx的状态是:"+ sxxx+"设备Id是:"+ devicemodel.deviceid+"设备名称："+ devicemodel.devicename+ "  设备温度:"+ maxvalue);
                                    if (sxxx == "1")
                                        updatestationAlarmcount(devicemodel.stationid);
                                }
                                catch(Exception e)
                                {
                                    HttpHelperServer.CreateTxt("updateAlarmpush", "", "当前方法执行出错,错误信息为:"+e.Message.ToString());
                                }
                            }
                            else if(maxvalue >=200)
                            {
                                HttpHelperServer.CreateTxt("updateAlarmpush", "", "大于200度未产生告警数据，告警阈值是:" + devicemodel.offsetvalue + "设备Id是:" + devicemodel.deviceid + "设备名称：" + devicemodel.devicename + "  设备温度:" + maxvalue);
                            }
                        }
                        updatecity(devicemodel.ywbid, today, imagerecordmodel.recordid);
                       
                        string IsSwitchCabinet = "";
                        // 判断是否是开关柜 升高10°进行预警
                        if (devicemodel.ysdtype.Contains("开关柜"))
                        {
                            if (double.Parse(today) + 10 <= double.Parse(max))
                            {
                                IsSwitchCabinet = "开关柜";
                                updateRaselist(lastvalue, nowvalue, System.DateTime.Now, devicemodel.deviceid);

                                HuaweiPush.HuaweiPushAction acc = new HuaweiPush.HuaweiPushAction();
                                acc.sendPushMessageOver(devicemodel.areaname, devicemodel.stationname, devicemodel.buildingname, devicemodel.machinename, devicemodel.devicename, max, dt.ToString(),IsSwitchCabinet);
                            }

                        }
                        else
                        {
                            if (double.Parse(today) + 20 <= double.Parse(max))
                            {
                                updateRaselist(lastvalue, nowvalue, System.DateTime.Now, devicemodel.deviceid);

                                HuaweiPush.HuaweiPushAction acc = new HuaweiPush.HuaweiPushAction();
                                acc.sendPushMessageOver(devicemodel.areaname, devicemodel.stationname, devicemodel.buildingname, devicemodel.machinename, devicemodel.devicename, max, dt.ToString(), IsSwitchCabinet);
                            }

                        }
                        today = max; devicemodel.todaytop = max;devicemodel.createtime = dt;
                        if (dt.Hour == 0)//如果是零点就把昨天最高温替换掉
                        {
                            //if ( devicemodel.yestodaytop == "" || double.Parse(devicemodel.todaytop) >= double.Parse(devicemodel.yestodaytop))
                            //{
                                yestoday = devicemodel.todaytop; devicemodel.yestodaytop = devicemodel.todaytop; devicemodel.yestodaymaxid = devicemodel.todaymaxid;
                            //}
                        }
                        if (dt.Hour == 0 || devicemodel.todaymax == "" || double.Parse(max) >= double.Parse(devicemodel.todaymax))
                        {
                            devicemodel.todaymax = max; devicemodel.todaymaxid = imagerecordmodel.recordid; 
                        }
                       
                       
                        if (devicemodel.weektop == "" || double.Parse(max) >= double.Parse(devicemodel.weektop))
                        {
                            week = max; devicemodel.weektop = max; devicemodel.weekmaxid = imagerecordmodel.recordid;
                        }
                        if (devicemodel.monthtop == "" || double.Parse(max) >= double.Parse(devicemodel.monthtop))
                        {
                            month = max; devicemodel.monthtop = max; devicemodel.monthmaxid = imagerecordmodel.recordid;
                            if (double.Parse(devicemodel.monthtop) > double.Parse(devicemodel.monthmax))
                            {
                                devicemodel.monthmax = max;
                            }
                        }
                        if (devicemodel.historytop == "" || double.Parse(max) >= double.Parse(devicemodel.historytop))
                        {
                            history = max; devicemodel.historytop = max; devicemodel.historymaxid = imagerecordmodel.recordid;
                        }
                        string isokok = "1";
                        Maticsoft.BLL.alarm_push_infor alarmservice1 = new Maticsoft.BLL.alarm_push_infor();
                        List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
                        alarmlist = alarmservice1.GetModelList("deviceid='" + devicemodel.deviceid + "' and isok='" + isokok + "'");
                        if (alarmlist.Count > 0)
                        {
                            value = "1";
                          devicemodel.isalarm = value;
                       }
                        //deviceservice.UpdateAlarm(devicemodel.deviceid, value, max);
                        bool falg = deviceservice.Update(devicemodel);//更新设备表中的数据
                        if(!falg){
                            deviceservice.UpdateAlarm(devicemodel.deviceid, value, max);
                            deviceservice.UpdateHistory(devicemodel.deviceid, devicemodel.yestodaytop, week, month, history, devicemodel.todaytop, devicemodel.monthmax, devicemodel.todaymaxid, devicemodel.yestodaymaxid, devicemodel.weekmaxid, devicemodel.monthmaxid, devicemodel.historymaxid);
                        }
                        Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
                        machineservice.Updatetime(machineid, System.DateTime.Now.ToString());
                        imagerecordmodel.areaid = devicemodel.areaid;
                        imagerecordmodel.areaname = devicemodel.areaname;
                        imagerecordmodel.fenbuid = devicemodel.fenbuid;
                        imagerecordmodel.fenbuname = devicemodel.fenbuname;
                        imagerecordmodel.ywbid = devicemodel.ywbid;
                        imagerecordmodel.ywbname = devicemodel.ywbname;
                        imagerecordmodel.deviceindex = ysdindex;
                        imagerecordmodel.machinemac = mac;
                        imagerecordmodel.valuemax = max;
                        imagerecordmodel.valuemin = min;
                        imagerecordmodel.valueave = ave;
                        imagerecordmodel.templist_24 = stempall;
                        imagerecordmodel.isalarm = isalarm;
                        imagerecordmodel.createtime = dt;

                        if (ishave)
                        {
                            imagerecordservice.Update(imagerecordmodel);
                            updatestation(devicemodel.stationid, max, imagerecordmodel.recordid, dt);

                        }
                        else
                        {
                            imagerecordservice.Add(imagerecordmodel);
                            updatestation(devicemodel.stationid, max, imagerecordmodel.recordid, dt);

                        }

                        isalready1 = true;

                    }
                    catch (Exception e)
                    {
                        isalready1 = true;
                    }
                    finally
                    {
                        isalready1 = true;
                    }
                }
            }
        }
        #endregion
        #region 更新变电站
        public void updatestation(string stationid, string temo, string recordid, DateTime dtime)
        {
            Maticsoft.BLL.station_infor sss = new Maticsoft.BLL.station_infor();


            Maticsoft.Model.station_infor stationmodel = sss.GetModel(stationid);
            if (stationmodel == null)
            {
                return;
            }
            string sold = stationmodel.topvalue;
            string todaytop = stationmodel.todaytop; if (todaytop == "" || todaytop == null) todaytop = "0.0";
            string yestodaytop = stationmodel.yestodaytop; if (yestodaytop == "" || yestodaytop == null) yestodaytop = "0.0";
            string weektop = stationmodel.weektop; if (weektop == "" || weektop == null) weektop = "0.0";
            string monthtop = stationmodel.monthtop; if (monthtop == "" || monthtop == null) monthtop = "0.0";
            string historytop = stationmodel.historytop; if (historytop == "" || historytop == null) historytop = "0.0";
            DateTime dold = stationmodel.createtime.Value;
            string now_flag = "";
            if (sold != "" && sold != null)
            {
                if (double.Parse(sold) < double.Parse(temo))
                {
                    now_flag = "0";
                    sss.UpdateTopValue(stationid, temo, now_flag);
                }
                else
                {
                    if (dold.Month == dtime.Month && dold.Day == dtime.Day && dold.Hour < dtime.Hour)
                    {
                        now_flag = "1";
                        sss.UpdateTopValue(stationid, sold, now_flag);
                    }
                }
            }
          
            //if (sold != "" && sold != null)
            //{
            //    if (double.Parse(sold) < double.Parse(temo))
            //    {
            //        stationmodel.now_flag = "0";
            //        stationmodel.topvalue = temo;
            //        stationmodel.createtime = dtime;
            //    }
            //    else
            //    {
            //        if (dold.Month == dtime.Month && dold.Day == dtime.Day && dold.Hour < dtime.Hour)
            //        {
            //            stationmodel.now_flag = "1";
            //        }
            //    }
            //}
            stationmodel.topvalue = temo;
            if (dold.Day < dtime.Day)
            {
              stationmodel.todaytop = temo; stationmodel.todayid = recordid; todaytop = temo; stationmodel.createtime = dtime; 
            }
            if (double.Parse(temo) >= double.Parse(todaytop))
            { stationmodel.todaytop = temo; stationmodel.todayid = recordid; todaytop = temo; stationmodel.createtime = dtime; }
            if (double.Parse(temo) >= double.Parse(yestodaytop))
            { stationmodel.yestodaytop = temo; stationmodel.yestodayid = recordid; yestodaytop = temo; }
            if (double.Parse(temo) >= double.Parse(weektop))
            { stationmodel.weektop = temo; stationmodel.weekid = recordid; weektop = temo; }
            if (double.Parse(temo) >= double.Parse(monthtop))
            { stationmodel.monthtop = temo; stationmodel.monthid = recordid; monthtop = temo; }
            if (double.Parse(temo) >= double.Parse(historytop))
            { stationmodel.historytop = temo; stationmodel.historyid = recordid; historytop = temo; }
            string sid1 = stationmodel.todayid;
            string sid2 = stationmodel.yestodayid;
            string sid3 = stationmodel.weekid;
            string sid4 = stationmodel.monthid;
            string sid5 = stationmodel.historyid;
           
            sss.Update(stationmodel);
 //           sss.UpdateHistoryValue(stationid, sold, todaytop, yestodaytop, weektop, monthtop, historytop, sid1, sid2, sid3, sid4, sid5, "0", now_flag);
            updateStationtop(stationid, recordid, temo, dtime);
            stationmodel = null;
            sss = null;
        }
       

        public void updatestationAlarmcount(string stationid)
        {
            string isok = "1";
            string alarmcount = "0";
            Maticsoft.BLL.alarm_push_infor alarmservice = new Maticsoft.BLL.alarm_push_infor();
            DataSet ds = alarmservice.GetList("stationid='" + stationid + "' and isok='" + isok + "'");
            if (ds.Tables[0].Rows.Count > 0)
                alarmcount = ds.Tables[0].Rows.Count.ToString();

            Maticsoft.BLL.station_infor deservice = new Maticsoft.BLL.station_infor();
            deservice.UpdateAlarmcount(stationid, alarmcount);
            ds = null;
            deservice = null;
        }
        #endregion
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            arrayList = null;
            return javaScriptSerializer.Serialize(arrayList);
        }
        public void updatecity(string ywbid, string temp,string id)
        {


            Maticsoft.BLL.city_infor cityservice = new Maticsoft.BLL.city_infor();
            DataTable dt = cityservice.GetList("ywbid='" + ywbid + "'").Tables[0];
            if (dt == null)
                return;
            if(dt.Rows.Count>0){
                string oldtemp = dt.Rows[0]["devicetopvalue"].ToString();
                if (oldtemp == null || oldtemp == "")
                {
                    cityservice.UpdateTemp(ywbid, temp,id);
                }
                else
                {
                    if (temp != "" && temp != null)
                    {
                        if (double.Parse(temp) > double.Parse(oldtemp))
                        {
                            cityservice.UpdateTemp(ywbid, temp,id);
                        }
                    }
                }
            }
            dt = null;
            cityservice = null;
        }

        [WebMethod(Description = "接口描述：查看图片历史记录")]
        public void getimagehistory()
        {
            Maticsoft.BLL.image_record_history ser = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> modellist = new List<Maticsoft.Model.image_record_history>();
            modellist = ser.GetModelList(" createtime>'" + System.DateTime.Now.Date + "' order by createtime desc limit 0,20");
            DataTable dt = new DataTable();
            dt.Columns.Add("time", Type.GetType("System.String"));
            dt.Columns.Add("devicename", Type.GetType("System.String"));
            dt.Columns.Add("count", Type.GetType("System.String"));

            for (int i = 0; i < modellist.Count(); i++)
            {
                dt.Rows.Add(new object[] { modellist[i].createtime.Value.ToString(), modellist[i].devicename, modellist.Count().ToString() });
            }
            httpsend(ToJson(dt));
            dt = null;
            modellist = null;
            ser = null;
        }
        public void updateStationtop(string stationid, string recordid, string topvalue, DateTime time)
        {
            Maticsoft.BLL.station_top_infor topservice = new Maticsoft.BLL.station_top_infor();
            Maticsoft.BLL.station_infor stationservice = new Maticsoft.BLL.station_infor();
            Maticsoft.Model.station_top_infor topmodel = new Maticsoft.Model.station_top_infor();
            topmodel = topservice.GetModel(stationid);
            if (topmodel == null)
                return;
            double oldvalue = double.Parse(topmodel.todaytop);
            double newvalue = double.Parse(topvalue);
            DateTime dtold = topmodel.toptime.Value;
            //if (dtold.Day < time.Day)
            //{
            //    oldvalue = newvalue;

            //    Maticsoft.Model.station_top_infor model = new Maticsoft.Model.station_top_infor();
            //    model.stationid = stationid;
            //    model.stationname = stationservice.GetModel(stationid).stationname;
            //    model.todaytop = oldvalue.ToString("0.0");
            //    model.topdrecord = recordid;
            //    model.toptime = time;
            //    topservice.Update(model);
            //}
            //if (newvalue >= oldvalue)
           // {
                oldvalue = newvalue;

                Maticsoft.Model.station_top_infor model = new Maticsoft.Model.station_top_infor();
                model.stationid = stationid;
                model.stationname = stationservice.GetModel(stationid).stationname;
                model.todaytop = oldvalue.ToString("0.0");
                model.topdrecord = recordid;
                model.toptime = time;
                topservice.Update(model);
            //}

        }



        [WebMethod(Description = "接口描述：从图片监听程序中获取最新图片信息，内部接口，前端不用,最新命名规则解析")]
        public void testImageInfor(string imagename)
        {
            System.Diagnostics.Debug.WriteLine(imagename);
            try
            {
                string[] array = imagename.Replace(@"\", "\\").Split('_');
                string stime = array[0];
                string mac = array[1];
                Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                Maticsoft.Model.machine_infor machinemodel = new Maticsoft.Model.machine_infor();
                machinemodel = machineservice.GetModelbymac(array[1]);
                if (machinemodel == null)
                    return;
                imageToRecordtest(imagename);
            }
            catch (Exception ue)
            {
                writeLog(ue.Message);
                return;
            }
        
        }
        public void imageToRecordtest(string imagename)
        {
            if (isalready1)
            {
                isalready1 = false;
                string image_00 = "";
                string image_11 = "";
                string image_22 = "";
                if (imagename.Contains("_0_"))
                {
                    image_00 = imagename;
                    image_22 = imagename.Replace("_0_", "_2_");
                    image_11 = imagename.Replace("_0_", "_1_");
                }
                if (imagename.Contains("_1_"))
                {
                    image_11 = imagename;
                    image_22 = imagename.Replace("_1_", "_2_");
                    image_00 = imagename.Replace("_1_", "_0_");
                }
                if (imagename.Contains("_2_"))
                {
                    image_22 = imagename;
                    image_00 = imagename.Replace("_2_", "_0_");
                    image_11 = imagename.Replace("_2_", "_1_");
                }

                bool icunzai = false;
                if (icunzai)
                    return;
                else
                {
                    Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                    Maticsoft.Model.machine_infor machinemodel = new Maticsoft.Model.machine_infor();
                    Maticsoft.BLL.image_record_history imagerecordservice = new Maticsoft.BLL.image_record_history();
                    Maticsoft.Model.image_record_history imagerecordmodel = new Maticsoft.Model.image_record_history();
                    Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
                    Maticsoft.Model.device_infor devicemodel = new Maticsoft.Model.device_infor();
                    Maticsoft.Model.device_infor devicemodel1 = new Maticsoft.Model.device_infor();
                    try
                    {
                        string imagepath0 = image_00.Replace("\\", "/");
                        System.Diagnostics.Debug.WriteLine("imagepath0===========" + imagepath0);
                        string imagepath1 = image_11.Replace("\\", "/");
                        System.Diagnostics.Debug.WriteLine("imagepath1===========" + imagepath1);
                        string imagepath2 = image_22.Replace("\\", "/");
                        System.Diagnostics.Debug.WriteLine("imagepath2===========" + imagepath2);

                        // string imageurl = "http://122.114.204.83/image/";
                        string imageurl = "http://117.159.7.31:8082/image/";
                        string[] array = image_00.Replace(@"\", "\\").Split('_');
                        string stime = "";
                        string mac = "";
                        string ysdindex = "";
                        string multiArea = "";//多区域名称
                        string multiAreaTemperature = "";//多区域温度
                        List<double> multiAreatemplist = new List<double>(); 
                        //解析图片名称
                        for (int i=0;i< array.Length;i++)
                        {
                            if (i == 0)
                            {
                                stime = array[i];
                                System.Diagnostics.Debug.WriteLine("stime===========" + stime);
                            }else  if (i==1)
                            {
                                 mac = array[i];
                            }else  if (i== (array.Length-2))
                            {
                                string type = array[i];
                            }else if (i == (array.Length - 1))
                            {
                                 ysdindex = array[11];
                                string[] ysdarray = ysdindex.Split('.');//去掉.jpg
                                ysdindex = ysdarray[0];
                            }
                            else
                            {
                                string str = array[i];
                                if (i < (array.Length - 3))
                                {
                                    if (i%2==0)
                                    {
                                        multiArea += str+",";
                                        str = str + ":";
                                    }
                                    else
                                    {
                                        multiAreatemplist.Add(Convert.ToDouble(str));
                                        str = str + ",";
                                    }

                                }
                                if (i == (array.Length - 3))
                                {
                                    string[] strarray = str.Split(' ');
                                    if (strarray.Length>0)
                                    {
                                        str = strarray[0];
                                        multiAreatemplist.Add(Convert.ToDouble(str));
                                    }
                                }
                                multiAreaTemperature += str;
                            }
                        }
                        multiArea = multiArea.Substring(0, multiArea.Length - 1);
                        System.Diagnostics.Debug.WriteLine("poslist===========" + multiAreaTemperature);
                        System.Diagnostics.Debug.WriteLine("pos===========" + multiArea);
                        string max = "";
                        string min = "";
                        string ave = "";
                        if (multiAreatemplist.Count>0)
                        {
                            //获取多区域测温的最大值
                             max = multiAreatemplist.Max().ToString("0.0");
                            //获取多区域测温最低值
                             min = multiAreatemplist.Min().ToString("0.0");
                            //获取多区域测温平均值
                             ave = multiAreatemplist.Average().ToString("0.0");
                        }
                        
                        machinemodel = machineservice.GetModelbymac(mac);
                        string machineid = machinemodel.machineid;
                        string machinemac = machinemodel.machinemac;
                        DateTime dt;
                        DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
                        dtFormat.ShortDatePattern = "yyyy-MM-dd hh:mm:ss";
                        System.Diagnostics.Debug.WriteLine("时间===========" + stime.Split('\\')[stime.Split('\\').Length - 1].Replace("&", ":"));
                        dt = Convert.ToDateTime(stime.Split('\\')[stime.Split('\\').Length - 1].Replace("&", ":"), dtFormat);

                        int npage = 0; int end = 191;
                        string sqllint = " limit " + npage + "," + end + "";
                        bool ishave = false;
                        string sid = "";
                        //根据抓拍设备id和预设点编号找到对应设备
                        devicemodel = deviceservice.GetModelByMachine(machineid, ysdindex);
                        //保存多区域温度值
                        devicemodel.multiAreaTemperature = multiAreaTemperature;
                        //保存多区域值
                        devicemodel.multiArea = multiArea;
                        string stempall = "";
                        if (ishave)
                        {
                            imagerecordmodel.recordid = sid;//保持原来id
                            stempall = devicemodel.templist;

                        }
                        else
                        {
                            #region
                            List<string> list_24 = new List<string>();
                            List<string> time_list = new List<string>();
                            for (int i = dt.Hour + 1; i < 24; i++)
                            {
                                time_list.Add(i.ToString());
                            }
                            for (int i = 0; i < dt.Hour + 1; i++)
                            {
                                time_list.Add(i.ToString());
                            }

                            if (devicemodel.templist == null || devicemodel.templist == "")
                            {
                                list_24.Clear();
                                for (int i = 0; i < 24; i++)
                                {
                                    list_24.Add("0");
                                }
                            }
                            else
                            {
                                list_24.Clear();
                                for (int i = 0; i < devicemodel.templist.Split(',').Length; i++)
                                {
                                    string sx = devicemodel.templist.Split(',')[i].Split(';')[1];
                                    list_24.Add(sx);
                                }
                                if (list_24.Count() != 24)
                                {
                                    list_24.Clear();
                                    for (int i = 0; i < 24; i++)
                                    {
                                        list_24.Add("0");
                                    }
                                }
                            }
                            string shour = dt.Hour.ToString();
                            list_24.RemoveAt(0);
                            list_24.Add(max);

                            for (int i = 0; i < list_24.Count(); i++)
                            {
                                stempall += time_list[i] + ";" + list_24[i] + ",";
                            }
                            stempall = stempall.Remove(stempall.Length - 1, 1);
                            #endregion
                            imagerecordmodel.recordid = Guid.NewGuid().ToString("N");//生成记录id

                        }
                        imagerecordmodel.deviceid = devicemodel.deviceid;
                        imagerecordmodel.devicename = devicemodel.devicename;
                        string insert1 = imageurl + imagepath0;
                        string insert2 = imageurl + imagepath1;
                        string insert3 = imageurl + imagepath2;
                        string queinfor = "";
                        bool isxx = false;
                        if (UrlToImage(insert1) < 0)
                        {
                            isxx = true;
                            queinfor += "高清,";
                        }
                        if (UrlToImage(insert2) < 0)
                        {
                            isxx = true;

                            queinfor += "红外1,";
                        }
                        if (UrlToImage(insert3) < 0)
                        {
                            isxx = true;
                            queinfor += "红外2";
                        }
                        if (isxx)
                            updatequetu(devicemodel.deviceid, dt, dt.Hour.ToString(), queinfor);
                        imagerecordmodel.image0 = insert1;
                        imagerecordmodel.image1 = insert2;
                        imagerecordmodel.image2 = insert3;

                        devicemodel.image_high = insert1;
                        devicemodel.image_red = insert2;
                        devicemodel.image_mix = insert3;
                        deviceservice.UpdateImage(devicemodel.deviceid, insert1, insert2, insert3, dt, stempall);//更新设备表中最新图片
                        string lastvalue = devicemodel.todaytop; string nowvalue = max;
                        string alarmimage = insert2;
                        string value = devicemodel.isalarm;
                        string today = devicemodel.todaytop;
                        string yestoday = devicemodel.yestodaytop;
                        string week = devicemodel.weektop;
                        string month = devicemodel.monthtop;
                        string history = devicemodel.historytop;
                        string isalarm = "0";
                        if (devicemodel.offsetvalue != "" && devicemodel.offsetvalue != null)
                        {
                            double maxvalue = Convert.ToDouble(max);
                            if (maxvalue >= Convert.ToDouble(devicemodel.offsetvalue))//判断是否告警
                            {
                                try
                                {
                                    value = "1";
                                    imagerecordmodel.isalarm = "1";
                                    isalarm = "1";
                                    string sxxx = updateAlarmpush(devicemodel.deviceid, max, devicemodel.offsetvalue, devicemodel.ysdtype, alarmimage, dt, isalarm);
                                    HttpHelperServer.CreateTxt("updateAlarmpush", "", "执行完此方法说明已经添加过告警数据,sxxx的状态是:" + sxxx + "设备Id是:" + devicemodel.deviceid + "设备温度:" + maxvalue);
                                    if (sxxx == "1")
                                        updatestationAlarmcount(devicemodel.stationid);
                                }
                                catch (Exception e)
                                {
                                    HttpHelperServer.CreateTxt("updateAlarmpush", "", "当前方法执行出错,错误信息为:" + e.Message.ToString());
                                }
                            }                          
                        }
                        updatecity(devicemodel.ywbid, today, imagerecordmodel.recordid);

                        string IsSwitchCabinet = "";
                        // 判断是否是开关柜 升高10°进行预警
                        if (devicemodel.ysdtype.Contains("开关柜"))
                        {
                            if (double.Parse(today) + 10 <= double.Parse(max))
                            {
                                IsSwitchCabinet = "开关柜";
                                updateRaselist(lastvalue, nowvalue, System.DateTime.Now, devicemodel.deviceid);

                                HuaweiPush.HuaweiPushAction acc = new HuaweiPush.HuaweiPushAction();
                                acc.sendPushMessageOver(devicemodel.areaname, devicemodel.stationname, devicemodel.buildingname, devicemodel.machinename, devicemodel.devicename, max, dt.ToString(), IsSwitchCabinet);
                            }

                        }
                        else
                        {
                            if (double.Parse(today) + 20 <= double.Parse(max))
                            {
                                updateRaselist(lastvalue, nowvalue, System.DateTime.Now, devicemodel.deviceid);

                                HuaweiPush.HuaweiPushAction acc = new HuaweiPush.HuaweiPushAction();
                                acc.sendPushMessageOver(devicemodel.areaname, devicemodel.stationname, devicemodel.buildingname, devicemodel.machinename, devicemodel.devicename, max, dt.ToString(), IsSwitchCabinet);
                            }

                        }

                        today = max; devicemodel.todaytop = max; devicemodel.createtime = dt;
                        if (dt.Hour == 0)//如果是零点就把昨天最高温替换掉
                        {                          
                            yestoday = devicemodel.todaytop; devicemodel.yestodaytop = devicemodel.todaytop; devicemodel.yestodaymaxid = devicemodel.todaymaxid;                           
                        }
                        //今日最高
                        if (dt.Hour == 0 || devicemodel.todaymax == "" || double.Parse(max) >= double.Parse(devicemodel.todaymax))
                        {
                            devicemodel.todaymax = max; devicemodel.todaymaxid = imagerecordmodel.recordid;
                        }
                        //7日最高
                        if (devicemodel.weektop == "" || double.Parse(max) >= double.Parse(devicemodel.weektop))
                        {
                            week = max; devicemodel.weektop = max; devicemodel.weekmaxid = imagerecordmodel.recordid;
                        }
                        //30日最高
                        if (devicemodel.monthtop == "" || double.Parse(max) >= double.Parse(devicemodel.monthtop))
                        {
                            month = max; devicemodel.monthtop = max; devicemodel.monthmaxid = imagerecordmodel.recordid;
                            if (double.Parse(devicemodel.monthtop) > double.Parse(devicemodel.monthmax))
                            {
                                //本月最高
                                devicemodel.monthmax = max;
                            }
                        }
                        //历史最高
                        if (devicemodel.historytop == "" || double.Parse(max) >= double.Parse(devicemodel.historytop))
                        {
                            history = max; devicemodel.historytop = max; devicemodel.historymaxid = imagerecordmodel.recordid;
                        }
                        string isokok = "1";
                        Maticsoft.BLL.alarm_push_infor alarmservice1 = new Maticsoft.BLL.alarm_push_infor();
                        List<Maticsoft.Model.alarm_push_infor> alarmlist = new List<Maticsoft.Model.alarm_push_infor>();
                        alarmlist = alarmservice1.GetModelList("deviceid='" + devicemodel.deviceid + "' and isok='" + isokok + "'");
                        if (alarmlist.Count > 0)
                        {
                            value = "1";
                            devicemodel.isalarm = value;
                        }
                        bool falg = deviceservice.Update(devicemodel);//更新设备表中的数据
                        if (!falg)
                        {
                            deviceservice.UpdateAlarm(devicemodel.deviceid, value, max);
                            deviceservice.UpdateHistory(devicemodel.deviceid, devicemodel.yestodaytop, week, month, history, devicemodel.todaytop, devicemodel.monthmax, devicemodel.todaymaxid, devicemodel.yestodaymaxid, devicemodel.weekmaxid, devicemodel.monthmaxid, devicemodel.historymaxid);
                        }
                        Maticsoft.BLL.machine_infor macservice = new Maticsoft.BLL.machine_infor();
                        machineservice.Updatetime(machineid, System.DateTime.Now.ToString());
                        imagerecordmodel.areaid = devicemodel.areaid;
                        imagerecordmodel.areaname = devicemodel.areaname;
                        imagerecordmodel.fenbuid = devicemodel.fenbuid;
                        imagerecordmodel.fenbuname = devicemodel.fenbuname;
                        imagerecordmodel.ywbid = devicemodel.ywbid;
                        imagerecordmodel.ywbname = devicemodel.ywbname;
                        imagerecordmodel.deviceindex = ysdindex;
                        imagerecordmodel.machinemac = mac;
                        imagerecordmodel.valuemax = max;
                        imagerecordmodel.valuemin = min;
                        imagerecordmodel.valueave = ave;
                        imagerecordmodel.templist_24 = stempall;
                        imagerecordmodel.isalarm = isalarm;
                        imagerecordmodel.createtime = dt;

                        if (ishave)
                        {
                            imagerecordservice.Update(imagerecordmodel);
                            updatestation(devicemodel.stationid, max, imagerecordmodel.recordid, dt);

                        }
                        else
                        {
                            imagerecordservice.Add(imagerecordmodel);
                            updatestation(devicemodel.stationid, max, imagerecordmodel.recordid, dt);

                        }

                        isalready1 = true;
                    }
                    catch (Exception e)
                    {
                        isalready1 = true;
                    }
                    finally
                    {
                        isalready1 = true;
                    }
                }
            }
        }
    }
}
