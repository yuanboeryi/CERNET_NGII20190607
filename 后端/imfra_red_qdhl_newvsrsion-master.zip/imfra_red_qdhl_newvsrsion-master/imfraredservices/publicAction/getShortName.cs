﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.publicAction
{
    public class getShortName
    {
        public string getshortname(string id)//根据工区，分部，运维班，变电站等id获取其对应的缩写名称，缩写名称有三个可选
        {
            Maticsoft.BLL.shortname_infor service = new Maticsoft.BLL.shortname_infor();
            Maticsoft.Model.shortname_infor model = new Maticsoft.Model.shortname_infor();
            model = service.GetModel(id);
            if (model == null)
                return "null,null,null";
            string s1, s2, s3;
            if (model.namenew1 == "" || model.namenew1==null)
            {
                s1 = "";
            }
            else
            {
                s1 = model.namenew1;
            }
            if (model.namenew2 == "" || model.namenew2 == null)
            {
                s2 = "";
            }
            else
            {
                s2 = model.namenew2;
            }
            if (model.namenew3 == "" || model.namenew3 == null)
            {
                s3 = "";
            }
            else
            {
                s3 = model.namenew3;
            }
            return s1 + "," +s2 + "," + s3;
        }
    }
}