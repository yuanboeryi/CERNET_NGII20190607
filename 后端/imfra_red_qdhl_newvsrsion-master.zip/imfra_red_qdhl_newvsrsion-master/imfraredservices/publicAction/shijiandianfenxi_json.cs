﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.publicAction
{
    public class shijiandianfenxi_json
    {
        List<string> timelist = new List<string>();

        public List<string> Timelist
        {
            get { return timelist; }
            set { timelist = value; }
        }
        string machinename = "";

        public string Machinename
        {
            get { return machinename; }
            set { machinename = value; }
        }

        string devicename = "";

        public string Devicename
        {
            get { return devicename; }
            set { devicename = value; }
        }
        List<string> datelist = new List<string>();

        public List<string> Datelist
        {
            get { return datelist; }
            set { datelist = value; }
        }
        List<List<string>> wendulist = new List<List<string>>();

        public List<List<string>> Wendulist
        {
            get { return wendulist; }
            set { wendulist = value; }
        }
    }
}