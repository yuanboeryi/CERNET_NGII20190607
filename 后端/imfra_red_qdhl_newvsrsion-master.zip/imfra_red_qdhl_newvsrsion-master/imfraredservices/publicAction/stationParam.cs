﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.publicAction
{
    public class stationParam
    {
        string areaid = "";

        public string Areaid
        {
            get { return areaid; }
            set { areaid = value; }
        }
        string areaname = "";

        public string Areaname
        {
            get { return areaname; }
            set { areaname = value; }
        }
        string fenbuid = "";

        public string Fenbuid
        {
            get { return fenbuid; }
            set { fenbuid = value; }
        }
        string fenbuname = "";

        public string Fenbuname
        {
            get { return fenbuname; }
            set { fenbuname = value; }
        }
        string ywbid = "";

        public string Ywbid
        {
            get { return ywbid; }
            set { ywbid = value; }
        }
        string ywbname = "";

        public string Ywbname
        {
            get { return ywbname; }
            set { ywbname = value; }
        }
        string stationid = "";

        public string Stationid
        {
            get { return stationid; }
            set { stationid = value; }
        }
        string stationname = "";

        public string Stationname
        {
            get { return stationname; }
            set { stationname = value; }
        }
        List<string> buildingidlist = new List<string>();

        public List<string> Buildingidlist
        {
            get { return buildingidlist; }
            set { buildingidlist = value; }
        }
        List<string> buildinglist = new List<string>();

        public List<string> Buildinglist
        {
            get { return buildinglist; }
            set { buildinglist = value; }
        }
        List<string> machineidlist = new List<string>();

        public List<string> Machineidlist
        {
            get { return machineidlist; }
            set { machineidlist = value; }
        }
        List<string> machinelist = new List<string>();

        public List<string> Machinelist
        {
            get { return machinelist; }
            set { machinelist = value; }
        }
        List<string> devicetypelist = new List<string>();

        public List<string> Devicetypelist
        {
            get { return devicetypelist; }
            set { devicetypelist = value; }
        }
    }
}