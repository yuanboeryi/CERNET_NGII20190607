﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace imfraredservices.quetuservice
{
    /// <summary>
    /// quetuServices 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class quetuServices : System.Web.Services.WebService
    {
        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        [WebMethod(Description="接口描述：查看登录用户下设备的缺图信息")]
        public void getQuetu(string userid,string areaid,string fenbuid,string ywbid,string stationid)
        {
            Maticsoft.BLL.quetu_infor quetuservice = new Maticsoft.BLL.quetu_infor();
            List<Maticsoft.Model.quetu_infor> quemodellist = new List<Maticsoft.Model.quetu_infor>();
            DateTime today =System.DateTime.Now.AddDays(-1).Date;
            quemodellist = quetuservice.GetModelList("quetudate<'"+today+"'");
            if(quemodellist.Count>0)
            {
                for(int i=0;i<quemodellist.Count;i++)
                {
                    quetuservice.Delete(quemodellist[i].recordid);//首先删除两天前的数据
                }
            }
            Maticsoft.BLL.user_infor userservice = new Maticsoft.BLL.user_infor();
            Maticsoft.Model.user_infor usermodel = new Maticsoft.Model.user_infor();
            usermodel = userservice.GetModel(userid);
            if (usermodel.usertype == "0")
            {
                {
                    areaid = usermodel.areaid;
                }
            }
            if (usermodel.usertype == "1")
            {
                {
                    fenbuid = usermodel.fenbuid;
                }
            }
            if (usermodel.usertype == "2")
            {
                {
                    ywbid = usermodel.ywbid;
                }
            }
            List<string> sqllist = new List<string>();
            if (areaid != "" && areaid != "全部" && areaid != null)
                sqllist.Add("areaid='" + areaid + "'");
            if (fenbuid != "" && fenbuid != "全部" && fenbuid != null)
                sqllist.Add("fenbuid='" + fenbuid + "'");
            if (ywbid != "" && ywbid != "全部" && ywbid != null)
                sqllist.Add("ywbid='" + ywbid + "'");
            if (stationid != "" && stationid != "全部" && stationid != null)
                sqllist.Add("stationid='" + stationid + "'");

            string sql = "";
            int ncount = sqllist.Count();
            if (ncount < 1)
            {
                sql += "1=1 ";
            }
            else if (ncount == 1)
            {
                sql += sqllist[0];
            }
            else if (ncount > 1)
            {
                for (int i = 0; i < ncount - 1; i++)
                {
                    sql += sqllist[i] + " and ";
                }
                sql += sqllist[ncount - 1] + "";
            }

            quetualljson jsonall = new quetualljson();
            int ncount1 = 0;
            int ncount2 = 0;
            sql += " order by stationname,machinename,ysdname asc";
         
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            devicelist = deviceservice.GetModelList(sql);//根据查询条件查找登录用户下的电力设备列表
            List<string> machinecountlist = new List<string>();
            for(int dev=0;dev<devicelist.Count();dev++)
            {
                DateTime time1 = System.DateTime.Now.Date;//今日日期（不包含时间）
                DateTime time2 = System.DateTime.Now.AddDays(-2).Date;//两天前日期
              
                List<Maticsoft.Model.quetu_infor> quetumodel1 = new List<Maticsoft.Model.quetu_infor>();
                List<Maticsoft.Model.quetu_infor> quetumodel2 = new List<Maticsoft.Model.quetu_infor>();
                quetujson json = new quetujson();//json子集
               
                quetumodel1 = quetuservice.GetModelList("deviceid='"+devicelist[dev].deviceid+"' and quetudate between '" + time2 + "' and '" + time1 + "'");//sql查找电力设备缺图信息
                quetutongji que = new quetutongji();
                que.Quetudate = time1.AddDays(-1).ToString("yyyy-MM-dd");
                List<string> stime1 = new List<string>();
                for (int i = 0; i < 24; i++)//用“-”填充一个24大小的数组
                {
                    stime1.Add("-");
                }
                if (quetumodel1.Count() > 0)
                {
                    for (int i = 0; i < quetumodel1.Count(); i++)
                    {
                        int nhour = int.Parse(quetumodel1[i].quetutime);
                        stime1.RemoveAt(nhour);//根据缺图时间点置换数组中对应位置
                        //html前端web请求数据格式：时间+缺图标志，组装样式>
                        stime1.Insert(nhour, "<span style='font-size:16px;'>" + nhour.ToString() + ":00</span><br/><span style='font-size:12px;'>" + quetumodel1[i].queinfor + "</span>");
                        ncount1 += 1;
                    }
                    que.Quetutime = stime1;
                    json.Quetulist.Add(que);//将que类存入json子集，json子集最终存入json总集
                }
                Maticsoft.BLL.machine_infor machineservice = new Maticsoft.BLL.machine_infor();
                string machineid = "";
                machineid = getmachineidbyname(devicelist[dev].stationname,devicelist[dev].buildingname, devicelist[dev].machinename,"machine");
                if(machineid!="")
                {
                    if(!machinecountlist.Contains(machineid))
                    {
                        machinecountlist.Add(machineid);
                    }
                    json.Device_title = devicelist[dev].stationname + " " + devicelist[dev].buildingname + " " + devicelist[dev].machinename + " " + machineservice.GetModel(machineid).machinecode + " " + devicelist[dev].devicename;//拼装信息：变电站，设备区，红外设备，设备编号，预设点，电力设备
                }
                else
                {
                    json.Device_title = devicelist[dev].stationname + " " + devicelist[dev].buildingname + " " + devicelist[dev].machinename + ""+ " " + devicelist[dev].devicename;//拼装信息：变电站，设备区，红外设备，设备编号，预设点，电力设备
                }

                quetumodel2 = quetuservice.GetModelList("deviceid='" + devicelist[dev].deviceid + "' and quetudate>'" + System.DateTime.Now.Date + "'");
                quetutongji que1 = new quetutongji();
                que1.Quetudate = time1.ToString("yyyy-MM-dd");
                List<string> stime2 = new List<string>();
                for (int i = 0; i < 24; i++)
                {
                    stime2.Add("-");
                }
                if (quetumodel2.Count() > 0)
                {
                    for (int i = 0; i < quetumodel2.Count(); i++)
                    {
                        int nhour = int.Parse(quetumodel2[i].quetutime);
                        stime2.RemoveAt(nhour);
                        stime2.Insert(nhour, "<span style='font-size:16px;'>" + nhour.ToString() + ":00</span><br/><span style='font-size:12px;'>" + quetumodel2[i].queinfor + "</span>");
                        ncount2 += 1;
                    }
                    que1.Quetutime = stime2;
                    json.Quetulist.Add(que1);
                  
                }
                if(quetumodel1.Count()>0||quetumodel2.Count()>0)
                {
                    jsonall.Quetu.Add(json);
                    jsonall.Quetunote2 = "缺图设备总计："+machinecountlist.Count().ToString()+"台，缺图总计：" +(ncount1+ ncount2).ToString() + "张";
                }
            }
            httpsend(Newtonsoft.Json.JsonConvert.SerializeObject(jsonall));
        }

        public string getmachineidbyname(string name1, string name2, string name3, string type)
        {
            string sreturn = "";
            if (type == "machine")
            {
                List<Maticsoft.Model.machine_infor> list = new List<Maticsoft.Model.machine_infor>();
                Maticsoft.BLL.machine_infor bll = new Maticsoft.BLL.machine_infor();
                list = bll.GetModelList("stationname='" + name1 + "' and buildingname='" + name2 + "' and machinename='" + name3 + "'");
                if (list.Count() > 0)
                {
                    sreturn = list[0].machineid;
                }
                else
                    sreturn = "";
            }
            return sreturn;
        }
    }
}
