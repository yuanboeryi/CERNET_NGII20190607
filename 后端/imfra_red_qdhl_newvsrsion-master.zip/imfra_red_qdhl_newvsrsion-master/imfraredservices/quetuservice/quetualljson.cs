﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.quetuservice
{
    public class quetualljson
    {
        List<quetujson> quetu = new List<quetujson>();
        public List<quetujson> Quetu
        {
            get { return quetu; }
            set { quetu = value; }
        }
        string quetunote1 = "";

        public string Quetunote1
        {
            get { return quetunote1; }
            set { quetunote1 = value; }
        }
        string quetunote2 = "";

        public string Quetunote2
        {
            get { return quetunote2; }
            set { quetunote2 = value; }
        }
    }
}