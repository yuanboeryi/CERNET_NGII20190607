﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.quetuservice
{
    public class quetujson
    {
        string device_title = "";

        public string Device_title
        {
            get { return device_title; }
            set { device_title = value; }
        }
        List<quetutongji> quetulist = new List<quetutongji>();

        public List<quetutongji> Quetulist
        {
            get { return quetulist; }
            set { quetulist = value; }
        }
    }
}