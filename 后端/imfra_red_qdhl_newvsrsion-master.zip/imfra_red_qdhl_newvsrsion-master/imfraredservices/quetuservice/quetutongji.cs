﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imfraredservices.quetuservice
{
    public class quetutongji
    {
        string quetudate = "";

        public string Quetudate
        {
            get { return quetudate; }
            set { quetudate = value; }
        }
        List<string> quetutime = new List<string>();

        public List<string> Quetutime
        {
            get { return quetutime; }
            set { quetutime = value; }
        }
    }
}