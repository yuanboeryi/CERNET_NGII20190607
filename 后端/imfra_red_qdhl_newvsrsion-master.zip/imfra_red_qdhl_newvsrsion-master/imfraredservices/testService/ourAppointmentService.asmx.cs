﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace imfraredservices.testService
{
    /// <summary>
    /// ourAppointmentService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class ourAppointmentService : System.Web.Services.WebService
    {
        public void httpsend(string s)
        {
            Context.Response.Charset = "UTF-8";
            Context.Response.ContentType = "text/plain;charset=utf-8";
            Context.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Context.Response.Write(s);
            Context.Response.End();
        }
        public string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }
        public string strJson(string jsonText)
        {
            DataTable dt = new DataTable("msg");
            dt.Columns.Add("msg", Type.GetType("System.String"));
            dt.Rows.Add(new object[] { jsonText });
            return ToJson(dt);
        }
        [WebMethod(Description = "获取所有变电站")]
        public void getallstation(string userid)
        {
            Maticsoft.BLL.station_infor deviceservice = new Maticsoft.BLL.station_infor();
            List<Maticsoft.Model.station_infor> devicelist = new List<Maticsoft.Model.station_infor>();
            devicelist = deviceservice.GetModelList("");
            List<string> list = new List<string>();
            string list_device = "";
            for (int i = 0; i < devicelist.Count; i++)
            {
                list_device += (devicelist[i].stationname) + ";";
            }
            httpsend(list_device);
        }
        [WebMethod(Description="获取设备名称列表")]
        public void getdevice(string stationname)
        {
            Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            devicelist = deviceservice.GetModelList("stationname='" + stationname + "'");
            List<string> list = new List<string>();
            string list_device = "";
            for(int i=0;i<devicelist.Count;i++)
            {
               list_device+=(devicelist[i].devicename)+";";
            }
            httpsend(list_device);
        }
        [WebMethod(Description="下载图片")]
        public void download_image(string deviceid,DateTime startdate,DateTime enddate)
        {
            //Maticsoft.BLL.device_infor deviceservice = new Maticsoft.BLL.device_infor();
            //List<Maticsoft.Model.device_infor> devicelist = new List<Maticsoft.Model.device_infor>();
            //devicelist = deviceservice.GetModelList("");
            List<string> imageurl = new List<string>();
            Maticsoft.BLL.image_record_history historyservice = new Maticsoft.BLL.image_record_history();
            List<Maticsoft.Model.image_record_history> historylist = new List<Maticsoft.Model.image_record_history>();

            historylist = historyservice.GetModelList("devicename='" + deviceid + "' and createtime>'" + startdate.Date.ToString() + "' and createtime<'" + enddate.AddDays(1).Date.ToString() + "'");
                for(int k=0;k<historylist.Count;k++)
                {
                    imageurl.Add(historylist[k].image0);
                    imageurl.Add(historylist[k].image1);
                    imageurl.Add(historylist[k].image2);
                }
                string returns = "";
                for (int i = 0; i < imageurl.Count;i++ )
                {
                    returns += imageurl[i] + ";";
                }
                    httpsend(returns);
        }
    }
}
